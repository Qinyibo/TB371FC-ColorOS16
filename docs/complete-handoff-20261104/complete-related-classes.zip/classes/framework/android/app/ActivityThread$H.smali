.class Landroid/app/ActivityThread$H;
.super Landroid/os/Handler;
.source "ActivityThread.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/ActivityThread;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "H"
.end annotation


# static fields
.field public static final greylist-max-o APPLICATION_INFO_CHANGED:I = 0x9c

.field public static final greylist-max-o ATTACH_AGENT:I = 0x9b

.field public static final blacklist ATTACH_STARTUP_AGENTS:I = 0xa2

.field public static final greylist-max-o BIND_APPLICATION:I = 0x6e

.field public static final greylist BIND_SERVICE:I = 0x79

.field public static final greylist-max-o CLEAN_UP_CONTEXT:I = 0x77

.field public static final greylist-max-o CONFIGURATION_CHANGED:I = 0x76

.field public static final greylist-max-o CREATE_BACKUP_AGENT:I = 0x80

.field public static final greylist CREATE_SERVICE:I = 0x72

.field public static final greylist-max-o DESTROY_BACKUP_AGENT:I = 0x81

.field public static final greylist-max-o DISPATCH_PACKAGE_BROADCAST:I = 0x85

.field public static final greylist-max-o DUMP_ACTIVITY:I = 0x88

.field public static final blacklist DUMP_GFXINFO:I = 0xa5

.field public static final greylist-max-o DUMP_HEAP:I = 0x87

.field public static final greylist DUMP_PROVIDER:I = 0x8d

.field public static final blacklist DUMP_RESOURCES:I = 0xa6

.field public static final greylist-max-o DUMP_SERVICE:I = 0x7b

.field public static final greylist ENTER_ANIMATION_COMPLETE:I = 0x95

.field public static final greylist-max-o EXECUTE_TRANSACTION:I = 0x9f

.field public static final greylist EXIT_APPLICATION:I = 0x6f

.field public static final blacklist FINISH_INSTRUMENTATION_WITHOUT_RESTART:I = 0xab

.field public static final greylist GC_WHEN_IDLE:I = 0x78

.field public static final greylist INSTALL_PROVIDER:I = 0x91

.field public static final blacklist INSTRUMENT_WITHOUT_RESTART:I = 0xaa

.field public static final greylist-max-o LOCAL_VOICE_INTERACTION_STARTED:I = 0x9a

.field public static final greylist-max-o LOW_MEMORY:I = 0x7c

.field public static final blacklist ON_NEW_SCENE_TRANSITION_INFO:I = 0x92

.field public static final blacklist PING:I = 0xa8

.field public static final greylist-max-o PROFILER_CONTROL:I = 0x7f

.field public static final blacklist PURGE_RESOURCES:I = 0xa1

.field public static final greylist RECEIVER:I = 0x71

.field public static final greylist-max-o RELAUNCH_ACTIVITY:I = 0xa0

.field public static final greylist REMOVE_PROVIDER:I = 0x83

.field public static final greylist-max-o REQUEST_ASSIST_CONTEXT_EXTRAS:I = 0x8f

.field public static final greylist-max-o RUN_ISOLATED_ENTRY_POINT:I = 0x9e

.field public static final greylist SCHEDULE_CRASH:I = 0x86

.field public static final greylist SERVICE_ARGS:I = 0x73

.field public static final blacklist SET_CONTENT_CAPTURE_OPTIONS_CALLBACK:I = 0xa4

.field public static final greylist-max-o SET_CORE_SETTINGS:I = 0x8a

.field public static final greylist-max-o SLEEPING:I = 0x89

.field public static final greylist-max-o START_BINDER_TRACKING:I = 0x96

.field public static final greylist-max-o STOP_BINDER_TRACKING_AND_DUMP:I = 0x97

.field public static final greylist STOP_SERVICE:I = 0x74

.field public static final greylist-max-o SUICIDE:I = 0x82

.field public static final blacklist TIMEOUT_SERVICE:I = 0xa7

.field public static final blacklist TIMEOUT_SERVICE_FOR_TYPE:I = 0xac

.field public static final greylist-max-o TRANSLUCENT_CONVERSION_COMPLETE:I = 0x90

.field public static final greylist UNBIND_SERVICE:I = 0x7a

.field public static final greylist-max-o UNSTABLE_PROVIDER_DIED:I = 0x8e

.field public static final greylist-max-o UPDATE_PACKAGE_COMPATIBILITY_INFO:I = 0x8b

.field public static final blacklist UPDATE_UI_TRANSLATION_STATE:I = 0xa3


# instance fields
.field final synthetic blacklist this$0:Landroid/app/ActivityThread;


# direct methods
.method constructor blacklist <init>(Landroid/app/ActivityThread;)V
    .registers 2
    .param p1, "this$0"    # Landroid/app/ActivityThread;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 2635
    iput-object p1, p0, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method greylist-max-o codeToString(I)Ljava/lang/String;
    .registers 3
    .param p1, "code"    # I

    .line 2705
    sget-boolean v0, Landroid/app/ActivityThread;->DEBUG_MESSAGES:Z

    if-eqz v0, :cond_99

    .line 2706
    packed-switch p1, :pswitch_data_9e

    :pswitch_7
    goto/16 :goto_99

    .line 2757
    :pswitch_9
    const-string v0, "TIMEOUT_SERVICE_FOR_TYPE"

    return-object v0

    .line 2753
    :pswitch_c
    const-string v0, "FINISH_INSTRUMENTATION_WITHOUT_RESTART"

    return-object v0

    .line 2751
    :pswitch_f
    const-string v0, "INSTRUMENT_WITHOUT_RESTART"

    return-object v0

    .line 2756
    :pswitch_12
    const-string v0, "PING"

    return-object v0

    .line 2755
    :pswitch_15
    const-string v0, "TIMEOUT_SERVICE"

    return-object v0

    .line 2754
    :pswitch_18
    const-string v0, "DUMP_RESOURCES"

    return-object v0

    .line 2750
    :pswitch_1b
    const-string v0, "DUMP GFXINFO"

    return-object v0

    .line 2749
    :pswitch_1e
    const-string v0, "SET_CONTENT_CAPTURE_OPTIONS_CALLBACK"

    return-object v0

    .line 2747
    :pswitch_21
    const-string v0, "UPDATE_UI_TRANSLATION_STATE"

    return-object v0

    .line 2746
    :pswitch_24
    const-string v0, "ATTACH_STARTUP_AGENTS"

    return-object v0

    .line 2745
    :pswitch_27
    const-string v0, "PURGE_RESOURCES"

    return-object v0

    .line 2744
    :pswitch_2a
    const-string v0, "RELAUNCH_ACTIVITY"

    return-object v0

    .line 2743
    :pswitch_2d
    const-string v0, "EXECUTE_TRANSACTION"

    return-object v0

    .line 2742
    :pswitch_30
    const-string v0, "RUN_ISOLATED_ENTRY_POINT"

    return-object v0

    .line 2741
    :pswitch_33
    const-string v0, "APPLICATION_INFO_CHANGED"

    return-object v0

    .line 2740
    :pswitch_36
    const-string v0, "ATTACH_AGENT"

    return-object v0

    .line 2739
    :pswitch_39
    const-string v0, "LOCAL_VOICE_INTERACTION_STARTED"

    return-object v0

    .line 2738
    :pswitch_3c
    const-string v0, "ENTER_ANIMATION_COMPLETE"

    return-object v0

    .line 2737
    :pswitch_3f
    const-string v0, "ON_NEW_SCENE_TRANSITION_INFO"

    return-object v0

    .line 2736
    :pswitch_42
    const-string v0, "INSTALL_PROVIDER"

    return-object v0

    .line 2735
    :pswitch_45
    const-string v0, "TRANSLUCENT_CONVERSION_COMPLETE"

    return-object v0

    .line 2734
    :pswitch_48
    const-string v0, "REQUEST_ASSIST_CONTEXT_EXTRAS"

    return-object v0

    .line 2733
    :pswitch_4b
    const-string v0, "UNSTABLE_PROVIDER_DIED"

    return-object v0

    .line 2732
    :pswitch_4e
    const-string v0, "DUMP_PROVIDER"

    return-object v0

    .line 2731
    :pswitch_51
    const-string v0, "UPDATE_PACKAGE_COMPATIBILITY_INFO"

    return-object v0

    .line 2729
    :pswitch_54
    const-string v0, "SET_CORE_SETTINGS"

    return-object v0

    .line 2728
    :pswitch_57
    const-string v0, "DUMP_ACTIVITY"

    return-object v0

    .line 2727
    :pswitch_5a
    const-string v0, "DUMP_HEAP"

    return-object v0

    .line 2726
    :pswitch_5d
    const-string v0, "SCHEDULE_CRASH"

    return-object v0

    .line 2725
    :pswitch_60
    const-string v0, "DISPATCH_PACKAGE_BROADCAST"

    return-object v0

    .line 2724
    :pswitch_63
    const-string v0, "REMOVE_PROVIDER"

    return-object v0

    .line 2723
    :pswitch_66
    const-string v0, "SUICIDE"

    return-object v0

    .line 2722
    :pswitch_69
    const-string v0, "DESTROY_BACKUP_AGENT"

    return-object v0

    .line 2721
    :pswitch_6c
    const-string v0, "CREATE_BACKUP_AGENT"

    return-object v0

    .line 2720
    :pswitch_6f
    const-string v0, "PROFILER_CONTROL"

    return-object v0

    .line 2719
    :pswitch_72
    const-string v0, "LOW_MEMORY"

    return-object v0

    .line 2718
    :pswitch_75
    const-string v0, "DUMP_SERVICE"

    return-object v0

    .line 2717
    :pswitch_78
    const-string v0, "UNBIND_SERVICE"

    return-object v0

    .line 2716
    :pswitch_7b
    const-string v0, "BIND_SERVICE"

    return-object v0

    .line 2715
    :pswitch_7e
    const-string v0, "GC_WHEN_IDLE"

    return-object v0

    .line 2714
    :pswitch_81
    const-string v0, "CLEAN_UP_CONTEXT"

    return-object v0

    .line 2713
    :pswitch_84
    const-string v0, "CONFIGURATION_CHANGED"

    return-object v0

    .line 2712
    :pswitch_87
    const-string v0, "STOP_SERVICE"

    return-object v0

    .line 2711
    :pswitch_8a
    const-string v0, "SERVICE_ARGS"

    return-object v0

    .line 2710
    :pswitch_8d
    const-string v0, "CREATE_SERVICE"

    return-object v0

    .line 2709
    :pswitch_90
    const-string v0, "RECEIVER"

    return-object v0

    .line 2708
    :pswitch_93
    const-string v0, "EXIT_APPLICATION"

    return-object v0

    .line 2707
    :pswitch_96
    const-string v0, "BIND_APPLICATION"

    return-object v0

    .line 2760
    :cond_99
    :goto_99
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_9e
    .packed-switch 0x6e
        :pswitch_96
        :pswitch_93
        :pswitch_7
        :pswitch_90
        :pswitch_8d
        :pswitch_8a
        :pswitch_87
        :pswitch_7
        :pswitch_84
        :pswitch_81
        :pswitch_7e
        :pswitch_7b
        :pswitch_78
        :pswitch_75
        :pswitch_72
        :pswitch_7
        :pswitch_7
        :pswitch_6f
        :pswitch_6c
        :pswitch_69
        :pswitch_66
        :pswitch_63
        :pswitch_7
        :pswitch_60
        :pswitch_5d
        :pswitch_5a
        :pswitch_57
        :pswitch_7
        :pswitch_54
        :pswitch_51
        :pswitch_7
        :pswitch_4e
        :pswitch_4b
        :pswitch_48
        :pswitch_45
        :pswitch_42
        :pswitch_3f
        :pswitch_7
        :pswitch_7
        :pswitch_3c
        :pswitch_7
        :pswitch_7
        :pswitch_7
        :pswitch_7
        :pswitch_39
        :pswitch_36
        :pswitch_33
        :pswitch_7
        :pswitch_30
        :pswitch_2d
        :pswitch_2a
        :pswitch_27
        :pswitch_24
        :pswitch_21
        :pswitch_1e
        :pswitch_1b
        :pswitch_18
        :pswitch_15
        :pswitch_12
        :pswitch_7
        :pswitch_f
        :pswitch_c
        :pswitch_9
    .end packed-switch
.end method

.method public whitelist handleMessage(Landroid/os/Message;)V
    .registers 28
    .param p1, "msg"    # Landroid/os/Message;

    .line 2763
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    sget-boolean v0, Landroid/app/ActivityThread;->DEBUG_MESSAGES:Z

    const-string v3, "ActivityThread"

    if-eqz v0, :cond_26

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, ">>> handling: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v4, v2, Landroid/os/Message;->what:I

    invoke-virtual {v1, v4}, Landroid/app/ActivityThread$H;->codeToString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Slog;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 2764
    :cond_26
    const-wide/16 v4, -0x1

    .line 2768
    .local v4, "debugStoreId":J
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v6

    .line 2769
    .local v6, "shouldLogLongMessage":Z
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    .line 2772
    .local v7, "messageStartUptimeMs":J
    const-wide/16 v9, 0x0

    .line 2774
    .local v9, "callStart":J
    iget v0, v2, Landroid/os/Message;->what:I

    const/4 v11, 0x0

    const/4 v14, 0x1

    const-wide/16 v12, 0x40

    packed-switch v0, :pswitch_data_6d8

    :pswitch_3b
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .local v18, "debugStoreId":J
    goto/16 :goto_688

    .line 2948
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_3f
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_5e

    .line 2949
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "serviceTimeoutForType: "

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2952
    :cond_5e
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Landroid/os/IBinder;

    iget v14, v2, Landroid/os/Message;->arg1:I

    iget v15, v2, Landroid/os/Message;->arg2:I

    invoke-static {v0, v11, v14, v15}, Landroid/app/ActivityThread;->-$$Nest$mhandleTimeoutServiceForType(Landroid/app/ActivityThread;Landroid/os/IBinder;II)V

    .line 2953
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2954
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 3137
    :pswitch_72
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0}, Landroid/app/ActivityThread;->-$$Nest$mhandleFinishInstrumentationWithoutRestart(Landroid/app/ActivityThread;)V

    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 3134
    :pswitch_7b
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Landroid/app/ActivityThread$AppBindData;

    invoke-static {v0, v11}, Landroid/app/ActivityThread;->-$$Nest$mhandleInstrumentWithoutRestart(Landroid/app/ActivityThread;Landroid/app/ActivityThread$AppBindData;)V

    .line 3135
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 2945
    :pswitch_88
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/os/RemoteCallback;

    invoke-virtual {v0, v11}, Landroid/os/RemoteCallback;->sendResult(Landroid/os/Bundle;)V

    .line 2946
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 2937
    :pswitch_93
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_b6

    .line 2938
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "serviceTimeout: "

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2939
    invoke-static {v11}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2938
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2941
    :cond_b6
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Landroid/os/IBinder;

    iget v14, v2, Landroid/os/Message;->arg1:I

    invoke-static {v0, v11, v14}, Landroid/app/ActivityThread;->-$$Nest$mhandleTimeoutService(Landroid/app/ActivityThread;Landroid/os/IBinder;I)V

    .line 2942
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2943
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 3019
    :pswitch_c8
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Landroid/app/ActivityThread$DumpResourcesData;

    invoke-static {v0, v11}, Landroid/app/ActivityThread;->-$$Nest$mhandleDumpResources(Landroid/app/ActivityThread;Landroid/app/ActivityThread$DumpResourcesData;)V

    .line 3020
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 2974
    :pswitch_d5
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Landroid/app/ActivityThread$DumpComponentInfo;

    invoke-static {v0, v11}, Landroid/app/ActivityThread;->-$$Nest$mhandleDumpGfxInfo(Landroid/app/ActivityThread;Landroid/app/ActivityThread$DumpComponentInfo;)V

    .line 2975
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 3131
    :pswitch_e2
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v11, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v11, Ljava/lang/String;

    invoke-static {v0, v11}, Landroid/app/ActivityThread;->-$$Nest$mhandleSetContentCaptureOptionsCallback(Landroid/app/ActivityThread;Ljava/lang/String;)V

    .line 3132
    move-wide/from16 v18, v4

    goto/16 :goto_688

    .line 3125
    :pswitch_ef
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/os/SomeArgs;

    .line 3126
    .local v0, "args":Lcom/android/internal/os/SomeArgs;
    iget-object v11, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v12, v0, Lcom/android/internal/os/SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v12, Landroid/os/IBinder;

    iget-object v13, v0, Lcom/android/internal/os/SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v13, Ljava/lang/Integer;

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    iget-object v14, v0, Lcom/android/internal/os/SomeArgs;->arg3:Ljava/lang/Object;

    check-cast v14, Landroid/view/translation/TranslationSpec;

    iget-object v15, v0, Lcom/android/internal/os/SomeArgs;->arg4:Ljava/lang/Object;

    check-cast v15, Landroid/view/translation/TranslationSpec;

    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v4, v0, Lcom/android/internal/os/SomeArgs;->arg5:Ljava/lang/Object;

    move-object/from16 v16, v4

    check-cast v16, Ljava/util/List;

    iget-object v4, v0, Lcom/android/internal/os/SomeArgs;->arg6:Ljava/lang/Object;

    move-object/from16 v17, v4

    check-cast v17, Landroid/view/translation/UiTranslationSpec;

    invoke-static/range {v11 .. v17}, Landroid/app/ActivityThread;->-$$Nest$mupdateUiTranslationState(Landroid/app/ActivityThread;Landroid/os/IBinder;ILandroid/view/translation/TranslationSpec;Landroid/view/translation/TranslationSpec;Ljava/util/List;Landroid/view/translation/UiTranslationSpec;)V

    .line 3129
    goto/16 :goto_688

    .line 3122
    .end local v0    # "args":Lcom/android/internal/os/SomeArgs;
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_11c
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Landroid/app/ActivityThread;->handleAttachStartupAgents(Ljava/lang/String;)V

    .line 3123
    goto/16 :goto_688

    .line 3119
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_127
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->schedulePurgeIdler()V

    .line 3120
    goto/16 :goto_688

    .line 3116
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_130
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    invoke-virtual {v0, v4}, Landroid/app/ActivityThread;->handleRelaunchActivityLocally(Landroid/os/IBinder;)V

    .line 3117
    goto/16 :goto_688

    .line 3099
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_13d
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v0, v0, Landroid/app/ActivityThread;->mOplusActivityThreadExt:Landroid/app/IActivityThreadExt;

    const/16 v15, 0xbb8

    invoke-interface {v0, v14, v15}, Landroid/app/IActivityThreadExt;->callGcSupression(II)V

    .line 3101
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Landroid/app/servertransaction/ClientTransaction;

    .line 3103
    .local v4, "transaction":Landroid/app/servertransaction/ClientTransaction;
    invoke-static {}, Landroid/app/servertransaction/ClientTransactionListenerController;->getInstance()Landroid/app/servertransaction/ClientTransactionListenerController;

    move-result-object v5

    .line 3106
    .local v5, "controller":Landroid/app/servertransaction/ClientTransactionListenerController;
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v0, v0, Landroid/app/ActivityThread;->mOplusActivityThreadExt:Landroid/app/IActivityThreadExt;

    invoke-interface {v0, v14}, Landroid/app/IActivityThreadExt;->setImportMessage(Z)V

    .line 3108
    invoke-virtual {v5}, Landroid/app/servertransaction/ClientTransactionListenerController;->onClientTransactionStarted()V

    .line 3110
    :try_start_15b
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0}, Landroid/app/ActivityThread;->-$$Nest$fgetmTransactionExecutor(Landroid/app/ActivityThread;)Landroid/app/servertransaction/TransactionExecutor;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/app/servertransaction/TransactionExecutor;->execute(Landroid/app/servertransaction/ClientTransaction;)V
    :try_end_164
    .catchall {:try_start_15b .. :try_end_164} :catchall_16a

    .line 3112
    invoke-virtual {v5}, Landroid/app/servertransaction/ClientTransactionListenerController;->onClientTransactionFinished()V

    .line 3113
    nop

    .line 3114
    goto/16 :goto_688

    .line 3112
    :catchall_16a
    move-exception v0

    invoke-virtual {v5}, Landroid/app/servertransaction/ClientTransactionListenerController;->onClientTransactionFinished()V

    .line 3113
    throw v0

    .line 3093
    .end local v5    # "controller":Landroid/app/servertransaction/ClientTransactionListenerController;
    .end local v18    # "debugStoreId":J
    .local v4, "debugStoreId":J
    :pswitch_16f
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Lcom/android/internal/os/SomeArgs;

    iget-object v4, v4, Lcom/android/internal/os/SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    iget-object v5, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v5, Lcom/android/internal/os/SomeArgs;

    iget-object v5, v5, Lcom/android/internal/os/SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v5, [Ljava/lang/String;

    invoke-static {v0, v4, v5}, Landroid/app/ActivityThread;->-$$Nest$mhandleRunIsolatedEntryPoint(Landroid/app/ActivityThread;Ljava/lang/String;[Ljava/lang/String;)V

    .line 3095
    goto/16 :goto_688

    .line 3090
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_188
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mapplyPendingApplicationInfoChanges(Landroid/app/ActivityThread;Ljava/lang/String;)V

    .line 3091
    goto/16 :goto_688

    .line 3085
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_195
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->getApplication()Landroid/app/Application;

    move-result-object v0

    .line 3086
    .local v0, "app":Landroid/app/Application;
    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    if-eqz v0, :cond_1a5

    iget-object v11, v0, Landroid/app/Application;->mLoadedApk:Landroid/app/LoadedApk;

    :cond_1a5
    invoke-static {v4, v11}, Landroid/app/ActivityThread;->handleAttachAgent(Ljava/lang/String;Landroid/app/LoadedApk;)V

    .line 3087
    goto/16 :goto_688

    .line 3081
    .end local v0    # "app":Landroid/app/Application;
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1aa
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Lcom/android/internal/os/SomeArgs;

    iget-object v4, v4, Lcom/android/internal/os/SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    iget-object v5, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v5, Lcom/android/internal/os/SomeArgs;

    iget-object v5, v5, Lcom/android/internal/os/SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v5, Lcom/android/internal/app/IVoiceInteractor;

    invoke-static {v0, v4, v5}, Landroid/app/ActivityThread;->-$$Nest$mhandleLocalVoiceInteractionStarted(Landroid/app/ActivityThread;Landroid/os/IBinder;Lcom/android/internal/app/IVoiceInteractor;)V

    .line 3083
    goto/16 :goto_688

    .line 3078
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1c3
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/ParcelFileDescriptor;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleStopBinderTrackingAndDump(Landroid/app/ActivityThread;Landroid/os/ParcelFileDescriptor;)V

    .line 3079
    goto/16 :goto_688

    .line 3075
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1d0
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0}, Landroid/app/ActivityThread;->-$$Nest$mhandleStartBinderTracking(Landroid/app/ActivityThread;)V

    .line 3076
    goto/16 :goto_688

    .line 3072
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1d9
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleEnterAnimationComplete(Landroid/app/ActivityThread;Landroid/os/IBinder;)V

    .line 3073
    goto/16 :goto_688

    .line 3067
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1e6
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/util/Pair;

    .line 3069
    .local v0, "pair":Landroid/util/Pair;, "Landroid/util/Pair<Landroid/os/IBinder;Landroid/app/ActivityOptions$SceneTransitionInfo;>;"
    iget-object v4, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v5, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Landroid/os/IBinder;

    iget-object v11, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v11, Landroid/app/ActivityOptions$SceneTransitionInfo;

    invoke-virtual {v4, v5, v11}, Landroid/app/ActivityThread;->onNewSceneTransitionInfo(Landroid/os/IBinder;Landroid/app/ActivityOptions$SceneTransitionInfo;)V

    .line 3070
    goto/16 :goto_688

    .line 3048
    .end local v0    # "pair":Landroid/util/Pair;, "Landroid/util/Pair<Landroid/os/IBinder;Landroid/app/ActivityOptions$SceneTransitionInfo;>;"
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_1fb
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_220

    .line 3049
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "providerInstall: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 3050
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3049
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 3055
    :cond_220
    :try_start_220
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v0

    invoke-interface {v0}, Landroid/os/IAnrLogEnhancementHelperExt;->getCallStartTime()J

    move-result-wide v4
    :try_end_228
    .catchall {:try_start_220 .. :try_end_228} :catchall_251

    move-wide/from16 v21, v4

    .line 3057
    .end local v9    # "callStart":J
    .local v21, "callStart":J
    :try_start_22a
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/content/pm/ProviderInfo;

    invoke-virtual {v0, v4}, Landroid/app/ActivityThread;->handleInstallProvider(Landroid/content/pm/ProviderInfo;)V

    .line 3060
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v20

    const-string/jumbo v23, "installProvider"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v24

    const/16 v25, 0x0

    invoke-interface/range {v20 .. v25}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V
    :try_end_243
    .catchall {:try_start_22a .. :try_end_243} :catchall_24d

    .line 3063
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3064
    nop

    .line 3065
    move-wide/from16 v4, v18

    move-wide/from16 v9, v21

    goto/16 :goto_68a

    .line 3063
    :catchall_24d
    move-exception v0

    move-wide/from16 v9, v21

    goto :goto_252

    .end local v21    # "callStart":J
    .restart local v9    # "callStart":J
    :catchall_251
    move-exception v0

    :goto_252
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3064
    throw v0

    .line 3045
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_256
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    iget v5, v2, Landroid/os/Message;->arg1:I

    if-ne v5, v14, :cond_264

    move v13, v14

    goto :goto_265

    :cond_264
    const/4 v13, 0x0

    :goto_265
    invoke-virtual {v0, v4, v13}, Landroid/app/ActivityThread;->handleTranslucentConversionComplete(Landroid/os/IBinder;Z)V

    .line 3046
    goto/16 :goto_688

    .line 3039
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_26a
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string v0, "handleRequestAssistContextExtras"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 3041
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$RequestAssistContextExtras;

    invoke-virtual {v0, v4}, Landroid/app/ActivityThread;->handleRequestAssistContextExtras(Landroid/app/ActivityThread$RequestAssistContextExtras;)V

    .line 3042
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3043
    goto/16 :goto_688

    .line 3036
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_27f
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    const/4 v5, 0x0

    invoke-virtual {v0, v4, v5}, Landroid/app/ActivityThread;->handleUnstableProviderDied(Landroid/os/IBinder;Z)V

    .line 3037
    goto/16 :goto_688

    .line 3025
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_28d
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$DumpComponentInfo;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleDumpProvider(Landroid/app/ActivityThread;Landroid/app/ActivityThread$DumpComponentInfo;)V

    .line 3026
    goto/16 :goto_688

    .line 3033
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_29a
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$UpdateCompatibilityData;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleUpdatePackageCompatibilityInfo(Landroid/app/ActivityThread;Landroid/app/ActivityThread$UpdateCompatibilityData;)V

    .line 3034
    goto/16 :goto_688

    .line 3028
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_2a7
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string/jumbo v0, "setCoreSettings"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 3029
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/Bundle;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleSetCoreSettings(Landroid/app/ActivityThread;Landroid/os/Bundle;)V

    .line 3030
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3031
    goto/16 :goto_688

    .line 3022
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_2bd
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$DumpComponentInfo;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleDumpActivity(Landroid/app/ActivityThread;Landroid/app/ActivityThread$DumpComponentInfo;)V

    .line 3023
    goto/16 :goto_688

    .line 3016
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_2ca
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/app/ActivityThread$DumpHeapData;

    invoke-static {v0}, Landroid/app/ActivityThread;->handleDumpHeap(Landroid/app/ActivityThread$DumpHeapData;)V

    .line 3017
    goto/16 :goto_688

    .line 3008
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_2d5
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/os/SomeArgs;

    .line 3009
    .local v0, "args":Lcom/android/internal/os/SomeArgs;
    iget-object v4, v0, Lcom/android/internal/os/SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    .line 3010
    .local v4, "message":Ljava/lang/String;
    iget-object v5, v0, Lcom/android/internal/os/SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v5, Landroid/os/Bundle;

    .line 3011
    .local v5, "extras":Landroid/os/Bundle;
    invoke-virtual {v0}, Lcom/android/internal/os/SomeArgs;->recycle()V

    .line 3012
    iget-object v11, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget v12, v2, Landroid/os/Message;->arg1:I

    invoke-static {v11, v4, v12, v5}, Landroid/app/ActivityThread;->-$$Nest$mthrowRemoteServiceException(Landroid/app/ActivityThread;Ljava/lang/String;ILandroid/os/Bundle;)V

    .line 3013
    goto/16 :goto_688

    .line 3003
    .end local v0    # "args":Lcom/android/internal/os/SomeArgs;
    .end local v5    # "extras":Landroid/os/Bundle;
    .end local v18    # "debugStoreId":J
    .local v4, "debugStoreId":J
    :pswitch_2ef
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string v0, "broadcastPackage"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 3004
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget v4, v2, Landroid/os/Message;->arg1:I

    iget-object v5, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v5, [Ljava/lang/String;

    invoke-virtual {v0, v4, v5}, Landroid/app/ActivityThread;->handleDispatchPackageBroadcast(I[Ljava/lang/String;)V

    .line 3005
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3006
    goto/16 :goto_688

    .line 2998
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_306
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string/jumbo v0, "providerRemove"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2999
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$ProviderRefCount;

    invoke-virtual {v0, v4}, Landroid/app/ActivityThread;->completeRemoveProvider(Landroid/app/ActivityThread$ProviderRefCount;)V

    .line 3000
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 3001
    goto/16 :goto_688

    .line 2995
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_31c
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 2996
    goto/16 :goto_688

    .line 2990
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_327
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string v0, "backupDestroyAgent"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2991
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$CreateBackupAgentData;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleDestroyBackupAgent(Landroid/app/ActivityThread;Landroid/app/ActivityThread$CreateBackupAgentData;)V

    .line 2992
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2993
    goto/16 :goto_688

    .line 2985
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_33c
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string v0, "backupCreateAgent"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2986
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$CreateBackupAgentData;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleCreateBackupAgent(Landroid/app/ActivityThread;Landroid/app/ActivityThread$CreateBackupAgentData;)V

    .line 2987
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2988
    goto/16 :goto_688

    .line 2982
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_351
    move-wide/from16 v18, v4

    const/4 v5, 0x0

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget v4, v2, Landroid/os/Message;->arg1:I

    if-eqz v4, :cond_35c

    move v13, v14

    goto :goto_35d

    :cond_35c
    move v13, v5

    :goto_35d
    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ProfilerInfo;

    iget v5, v2, Landroid/os/Message;->arg2:I

    invoke-virtual {v0, v13, v4, v5}, Landroid/app/ActivityThread;->handleProfilerControl(ZLandroid/app/ProfilerInfo;I)V

    .line 2983
    goto/16 :goto_688

    .line 2977
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_368
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string/jumbo v0, "lowMemory"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2978
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->handleLowMemory()V

    .line 2979
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2980
    goto/16 :goto_688

    .line 2971
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_37a
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$DumpComponentInfo;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleDumpService(Landroid/app/ActivityThread;Landroid/app/ActivityThread$DumpComponentInfo;)V

    .line 2972
    goto/16 :goto_688

    .line 2898
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_387
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_3ac

    .line 2899
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "serviceUnbind: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2900
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2899
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2902
    :cond_3ac
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/app/ActivityThread$BindServiceData;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleUnbindService(Landroid/app/ActivityThread;Landroid/app/ActivityThread$BindServiceData;)V

    .line 2903
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->schedulePurgeIdler()V

    .line 2904
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2905
    goto/16 :goto_688

    .line 2870
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_3bf
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_3e4

    .line 2871
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "serviceBind: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2872
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2871
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2874
    :cond_3e4
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Landroid/app/ActivityThread$BindServiceData;

    .line 2875
    .local v4, "bindData":Landroid/app/ActivityThread$BindServiceData;
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_3f8

    .line 2876
    iget-boolean v0, v4, Landroid/app/ActivityThread$BindServiceData;->rebind:Z

    iget-object v5, v4, Landroid/app/ActivityThread$BindServiceData;->intent:Landroid/content/Intent;

    .line 2877
    invoke-static {v0, v5}, Lcom/android/internal/os/DebugStore;->recordServiceBind(ZLandroid/content/Intent;)J

    move-result-wide v14

    .end local v18    # "debugStoreId":J
    .local v14, "debugStoreId":J
    goto :goto_3fa

    .line 2875
    .end local v14    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :cond_3f8
    move-wide/from16 v14, v18

    .line 2881
    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    :goto_3fa
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v0

    invoke-interface {v0}, Landroid/os/IAnrLogEnhancementHelperExt;->getCallStartTime()J

    move-result-wide v17

    .line 2884
    .end local v9    # "callStart":J
    .local v17, "callStart":J
    :try_start_402
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleBindService(Landroid/app/ActivityThread;Landroid/app/ActivityThread$BindServiceData;)V
    :try_end_407
    .catchall {:try_start_402 .. :try_end_407} :catchall_428

    .line 2886
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2889
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string v19, "bindService"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2891
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_423

    .line 2892
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2893
    const/4 v6, 0x0

    .line 2896
    :cond_423
    move-wide v4, v14

    move-wide/from16 v9, v17

    goto/16 :goto_68a

    .line 2886
    :catchall_428
    move-exception v0

    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2889
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string v19, "bindService"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2891
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v3

    if-eqz v3, :cond_445

    .line 2892
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2893
    const/4 v6, 0x0

    .line 2895
    :cond_445
    throw v0

    .line 2963
    .end local v14    # "debugStoreId":J
    .end local v17    # "callStart":J
    .local v4, "debugStoreId":J
    .restart local v9    # "callStart":J
    :pswitch_446
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    const-string v0, "gcWhenIdle"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2965
    :try_start_44d
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->scheduleGcIdler()V
    :try_end_452
    .catchall {:try_start_44d .. :try_end_452} :catchall_458

    .line 2967
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2968
    nop

    .line 2969
    goto/16 :goto_688

    .line 2967
    :catchall_458
    move-exception v0

    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2968
    throw v0

    .line 2959
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_45d
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/app/ActivityThread$ContextCleanupInfo;

    .line 2960
    .local v0, "cci":Landroid/app/ActivityThread$ContextCleanupInfo;
    iget-object v4, v0, Landroid/app/ActivityThread$ContextCleanupInfo;->context:Landroid/app/ContextImpl;

    iget-object v5, v0, Landroid/app/ActivityThread$ContextCleanupInfo;->who:Ljava/lang/String;

    iget-object v11, v0, Landroid/app/ActivityThread$ContextCleanupInfo;->what:Ljava/lang/String;

    invoke-virtual {v4, v5, v11}, Landroid/app/ContextImpl;->performFinalCleanup(Ljava/lang/String;Ljava/lang/String;)V

    .line 2961
    goto/16 :goto_688

    .line 2956
    .end local v0    # "cci":Landroid/app/ActivityThread$ContextCleanupInfo;
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_46e
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0}, Landroid/app/ActivityThread;->-$$Nest$fgetmConfigurationController(Landroid/app/ActivityThread;)Landroid/app/ConfigurationController;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/content/res/Configuration;

    invoke-virtual {v0, v4}, Landroid/app/ConfigurationController;->handleConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2957
    goto/16 :goto_688

    .line 2928
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_47f
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_4a4

    .line 2929
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "serviceStop: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2930
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2929
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2932
    :cond_4a4
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, Landroid/os/IBinder;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleStopService(Landroid/app/ActivityThread;Landroid/os/IBinder;)V

    .line 2933
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-virtual {v0}, Landroid/app/ActivityThread;->schedulePurgeIdler()V

    .line 2934
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2935
    goto/16 :goto_688

    .line 2907
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_4b7
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_4dc

    .line 2908
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "serviceStart: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2909
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2908
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2911
    :cond_4dc
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Landroid/app/ActivityThread$ServiceArgsData;

    .line 2912
    .local v4, "serviceData":Landroid/app/ActivityThread$ServiceArgsData;
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_4f2

    .line 2913
    iget v0, v4, Landroid/app/ActivityThread$ServiceArgsData;->startId:I

    iget v5, v4, Landroid/app/ActivityThread$ServiceArgsData;->flags:I

    iget-object v11, v4, Landroid/app/ActivityThread$ServiceArgsData;->args:Landroid/content/Intent;

    invoke-static {v0, v5, v11}, Lcom/android/internal/os/DebugStore;->recordServiceOnStart(IILandroid/content/Intent;)J

    move-result-wide v14

    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    goto :goto_4f4

    .line 2912
    .end local v14    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :cond_4f2
    move-wide/from16 v14, v18

    .line 2918
    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    :goto_4f4
    :try_start_4f4
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleServiceArgs(Landroid/app/ActivityThread;Landroid/app/ActivityThread$ServiceArgsData;)V
    :try_end_4f9
    .catchall {:try_start_4f4 .. :try_end_4f9} :catchall_509

    .line 2920
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2921
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_506

    .line 2922
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2923
    const/4 v6, 0x0

    .line 2926
    :cond_506
    move-wide v4, v14

    goto/16 :goto_68a

    .line 2920
    :catchall_509
    move-exception v0

    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2921
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v3

    if-eqz v3, :cond_517

    .line 2922
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2923
    const/4 v6, 0x0

    .line 2925
    :cond_517
    throw v0

    .line 2842
    .end local v14    # "debugStoreId":J
    .local v4, "debugStoreId":J
    :pswitch_518
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_53d

    .line 2843
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "serviceCreate: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 2844
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2843
    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2846
    :cond_53d
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Landroid/app/ActivityThread$CreateServiceData;

    .line 2847
    .local v4, "createServiceData":Landroid/app/ActivityThread$CreateServiceData;
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_54f

    .line 2848
    iget-object v0, v4, Landroid/app/ActivityThread$CreateServiceData;->info:Landroid/content/pm/ServiceInfo;

    invoke-static {v0}, Lcom/android/internal/os/DebugStore;->recordServiceCreate(Landroid/content/pm/ServiceInfo;)J

    move-result-wide v14

    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    goto :goto_551

    .line 2847
    .end local v14    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :cond_54f
    move-wide/from16 v14, v18

    .line 2853
    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    :goto_551
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v0

    invoke-interface {v0}, Landroid/os/IAnrLogEnhancementHelperExt;->getCallStartTime()J

    move-result-wide v17

    .line 2856
    .end local v9    # "callStart":J
    .restart local v17    # "callStart":J
    :try_start_559
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleCreateService(Landroid/app/ActivityThread;Landroid/app/ActivityThread$CreateServiceData;)V
    :try_end_55e
    .catchall {:try_start_559 .. :try_end_55e} :catchall_57f

    .line 2858
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2861
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string v19, "createService"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2863
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_57a

    .line 2864
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2865
    const/4 v6, 0x0

    .line 2868
    :cond_57a
    move-wide v4, v14

    move-wide/from16 v9, v17

    goto/16 :goto_68a

    .line 2858
    :catchall_57f
    move-exception v0

    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2861
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string v19, "createService"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2863
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v3

    if-eqz v3, :cond_59c

    .line 2864
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2865
    const/4 v6, 0x0

    .line 2867
    :cond_59c
    throw v0

    .line 2805
    .end local v14    # "debugStoreId":J
    .end local v17    # "callStart":J
    .local v4, "debugStoreId":J
    .restart local v9    # "callStart":J
    :pswitch_59d
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    invoke-static {v12, v13}, Landroid/os/Trace;->isTagEnabled(J)Z

    move-result v0

    if-eqz v0, :cond_5cf

    .line 2806
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/app/ActivityThread$ReceiverData;

    .line 2807
    .local v0, "rec":Landroid/app/ActivityThread$ReceiverData;
    iget-object v4, v0, Landroid/app/ActivityThread$ReceiverData;->intent:Landroid/content/Intent;

    if-eqz v4, :cond_5ca

    .line 2808
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "broadcastReceiveComp: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, v0, Landroid/app/ActivityThread$ReceiverData;->intent:Landroid/content/Intent;

    .line 2809
    invoke-virtual {v5}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 2808
    invoke-static {v12, v13, v4}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    goto :goto_5cf

    .line 2811
    :cond_5ca
    const-string v4, "broadcastReceiveComp"

    invoke-static {v12, v13, v4}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2815
    .end local v0    # "rec":Landroid/app/ActivityThread$ReceiverData;
    :cond_5cf
    :goto_5cf
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Landroid/app/ActivityThread$ReceiverData;

    .line 2816
    .local v4, "receiverData":Landroid/app/ActivityThread$ReceiverData;
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_5e5

    .line 2817
    iget-object v0, v4, Landroid/app/ActivityThread$ReceiverData;->intent:Landroid/content/Intent;

    .line 2819
    invoke-static {v4}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v5

    .line 2818
    invoke-static {v0, v5}, Lcom/android/internal/os/DebugStore;->recordBroadcastReceive(Landroid/content/Intent;I)J

    move-result-wide v14

    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    goto :goto_5e7

    .line 2816
    .end local v14    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :cond_5e5
    move-wide/from16 v14, v18

    .line 2823
    .end local v18    # "debugStoreId":J
    .restart local v14    # "debugStoreId":J
    :goto_5e7
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v0

    invoke-interface {v0}, Landroid/os/IAnrLogEnhancementHelperExt;->getCallStartTime()J

    move-result-wide v17

    .line 2826
    .end local v9    # "callStart":J
    .restart local v17    # "callStart":J
    :try_start_5ef
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v0, v4}, Landroid/app/ActivityThread;->-$$Nest$mhandleReceiver(Landroid/app/ActivityThread;Landroid/app/ActivityThread$ReceiverData;)V
    :try_end_5f4
    .catchall {:try_start_5ef .. :try_end_5f4} :catchall_616

    .line 2828
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2831
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string/jumbo v19, "static_receiver"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2833
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_611

    .line 2834
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2835
    const/4 v6, 0x0

    .line 2840
    :cond_611
    move-wide v4, v14

    move-wide/from16 v9, v17

    goto/16 :goto_68a

    .line 2828
    :catchall_616
    move-exception v0

    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2831
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetsAnrLogEnhancementHelper()Landroid/os/IAnrLogEnhancementHelperExt;

    move-result-object v16

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v20

    const/16 v21, 0x0

    const-string/jumbo v19, "static_receiver"

    invoke-interface/range {v16 .. v21}, Landroid/os/IAnrLogEnhancementHelperExt;->printSlowLog(JLjava/lang/String;IZ)V

    .line 2833
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v3

    if-eqz v3, :cond_634

    .line 2834
    invoke-static {v14, v15}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2835
    const/4 v6, 0x0

    .line 2837
    :cond_634
    throw v0

    .line 2799
    .end local v14    # "debugStoreId":J
    .end local v17    # "callStart":J
    .local v4, "debugStoreId":J
    .restart local v9    # "callStart":J
    :pswitch_635
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v0, v0, Landroid/app/ActivityThread;->mInitialApplication:Landroid/app/Application;

    if-eqz v0, :cond_644

    .line 2800
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v0, v0, Landroid/app/ActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/app/Application;->onTerminate()V

    .line 2802
    :cond_644
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    .line 2803
    goto :goto_688

    .line 2778
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :pswitch_64c
    move-wide/from16 v18, v4

    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    sget-boolean v0, Landroid/app/ActivityThread;->DEBUG_PANIC:Z

    if-eqz v0, :cond_657

    .line 2779
    const-string v0, "handle BIND_APPLICATION"

    invoke-static {v3, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2784
    :cond_657
    iget-object v0, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    iget-object v0, v0, Landroid/app/ActivityThread;->mOplusActivityThreadExt:Landroid/app/IActivityThreadExt;

    const/16 v15, 0xbb8

    invoke-interface {v0, v14, v15}, Landroid/app/IActivityThreadExt;->callGcSupression(II)V

    .line 2786
    const-string v0, "bindApplication"

    invoke-static {v12, v13, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2787
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v0

    if-eqz v0, :cond_670

    .line 2789
    invoke-static {}, Lcom/android/internal/os/DebugStore;->recordHandleBindApplication()J

    move-result-wide v4

    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    goto :goto_672

    .line 2787
    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :cond_670
    move-wide/from16 v4, v18

    .line 2791
    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :goto_672
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/app/ActivityThread$AppBindData;

    .line 2792
    .local v0, "data":Landroid/app/ActivityThread$AppBindData;
    iget-object v11, v1, Landroid/app/ActivityThread$H;->this$0:Landroid/app/ActivityThread;

    invoke-static {v11, v0}, Landroid/app/ActivityThread;->-$$Nest$mhandleBindApplication(Landroid/app/ActivityThread;Landroid/app/ActivityThread$AppBindData;)V

    .line 2793
    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetDEBUG_STORE_ENABLED()Z

    move-result v11

    if-eqz v11, :cond_684

    .line 2794
    invoke-static {v4, v5}, Lcom/android/internal/os/DebugStore;->recordEventEnd(J)V

    .line 2796
    :cond_684
    invoke-static {v12, v13}, Landroid/os/Trace;->traceEnd(J)V

    .line 2797
    goto :goto_68a

    .line 3140
    .end local v0    # "data":Landroid/app/ActivityThread$AppBindData;
    .end local v4    # "debugStoreId":J
    .restart local v18    # "debugStoreId":J
    :goto_688
    move-wide/from16 v4, v18

    .end local v18    # "debugStoreId":J
    .restart local v4    # "debugStoreId":J
    :goto_68a
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v11

    sub-long/2addr v11, v7

    .line 3141
    .local v11, "messageElapsedTimeMs":J
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 3142
    .local v0, "obj":Ljava/lang/Object;
    instance-of v13, v0, Lcom/android/internal/os/SomeArgs;

    if-eqz v13, :cond_69b

    .line 3143
    move-object v13, v0

    check-cast v13, Lcom/android/internal/os/SomeArgs;

    invoke-virtual {v13}, Lcom/android/internal/os/SomeArgs;->recycle()V

    .line 3145
    :cond_69b
    sget-boolean v13, Landroid/app/ActivityThread;->DEBUG_MESSAGES:Z

    if-eqz v13, :cond_6bb

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "<<< done: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    iget v14, v2, Landroid/os/Message;->what:I

    invoke-virtual {v1, v14}, Landroid/app/ActivityThread$H;->codeToString(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v3, v13}, Landroid/util/Slog;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 3146
    :cond_6bb
    if-eqz v6, :cond_6d6

    invoke-static {}, Landroid/app/ActivityThread;->-$$Nest$sfgetLONG_MESSAGE_THRESHOLD_MS()J

    move-result-wide v13

    cmp-long v3, v11, v13

    if-lez v3, :cond_6d6

    .line 3148
    iget v3, v2, Landroid/os/Message;->what:I

    invoke-virtual {v2}, Landroid/os/Message;->getTarget()Landroid/os/Handler;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v13

    invoke-static {v3, v13, v11, v12}, Lcom/android/internal/os/DebugStore;->recordLongLooperMessage(ILjava/lang/String;J)V

    .line 3151
    :cond_6d6
    return-void

    nop

    :pswitch_data_6d8
    .packed-switch 0x6e
        :pswitch_64c
        :pswitch_635
        :pswitch_3b
        :pswitch_59d
        :pswitch_518
        :pswitch_4b7
        :pswitch_47f
        :pswitch_3b
        :pswitch_46e
        :pswitch_45d
        :pswitch_446
        :pswitch_3bf
        :pswitch_387
        :pswitch_37a
        :pswitch_368
        :pswitch_3b
        :pswitch_3b
        :pswitch_351
        :pswitch_33c
        :pswitch_327
        :pswitch_31c
        :pswitch_306
        :pswitch_3b
        :pswitch_2ef
        :pswitch_2d5
        :pswitch_2ca
        :pswitch_2bd
        :pswitch_3b
        :pswitch_2a7
        :pswitch_29a
        :pswitch_3b
        :pswitch_28d
        :pswitch_27f
        :pswitch_26a
        :pswitch_256
        :pswitch_1fb
        :pswitch_1e6
        :pswitch_3b
        :pswitch_3b
        :pswitch_1d9
        :pswitch_1d0
        :pswitch_1c3
        :pswitch_3b
        :pswitch_3b
        :pswitch_1aa
        :pswitch_195
        :pswitch_188
        :pswitch_3b
        :pswitch_16f
        :pswitch_13d
        :pswitch_130
        :pswitch_127
        :pswitch_11c
        :pswitch_ef
        :pswitch_e2
        :pswitch_d5
        :pswitch_c8
        :pswitch_93
        :pswitch_88
        :pswitch_3b
        :pswitch_7b
        :pswitch_72
        :pswitch_3f
    .end packed-switch
.end method
