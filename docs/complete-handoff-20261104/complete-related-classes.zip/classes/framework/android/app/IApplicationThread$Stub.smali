.class public abstract Landroid/app/IApplicationThread$Stub;
.super Landroid/os/Binder;
.source "IApplicationThread.java"

# interfaces
.implements Landroid/app/IApplicationThread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/IApplicationThread;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/app/IApplicationThread$Stub$Proxy;
    }
.end annotation


# static fields
.field public static final greylist-max-o DESCRIPTOR:Ljava/lang/String; = "android.app.IApplicationThread"

.field static final greylist-max-o TRANSACTION_attachAgent:I = 0x33

.field static final blacklist TRANSACTION_attachStartupAgents:I = 0x34

.field static final greylist-max-o TRANSACTION_bindApplication:I = 0x6

.field static final greylist-max-o TRANSACTION_clearDnsCache:I = 0x1c

.field static final greylist-max-o TRANSACTION_dispatchPackageBroadcast:I = 0x17

.field static final greylist-max-o TRANSACTION_dumpActivity:I = 0x1a

.field static final blacklist TRANSACTION_dumpCacheInfo:I = 0x24

.field static final greylist-max-o TRANSACTION_dumpDbInfo:I = 0x26

.field static final greylist-max-o TRANSACTION_dumpGfxInfo:I = 0x23

.field static final greylist-max-o TRANSACTION_dumpHeap:I = 0x19

.field static final blacklist TRANSACTION_dumpMainLooperTrackedMsg:I = 0x47

.field static final greylist-max-o TRANSACTION_dumpMemInfo:I = 0x21

.field static final greylist-max-o TRANSACTION_dumpMemInfoProto:I = 0x22

.field static final blacklist TRANSACTION_dumpMessage:I = 0x3d

.field static final greylist-max-o TRANSACTION_dumpProvider:I = 0x25

.field static final blacklist TRANSACTION_dumpResources:I = 0x1b

.field static final greylist-max-o TRANSACTION_dumpService:I = 0xe

.field static final blacklist TRANSACTION_enableActivityThreadLog:I = 0x3b

.field static final blacklist TRANSACTION_enableProcessMainThreadLooperLog:I = 0x3c

.field static final blacklist TRANSACTION_getBroadcastState:I = 0x40

.field static final blacklist TRANSACTION_getExecutableMethodFileOffsets:I = 0x48

.field static final greylist-max-o TRANSACTION_handleTrustStorageUpdate:I = 0x32

.field static final blacklist TRANSACTION_instrumentWithoutRestart:I = 0x42

.field static final greylist-max-o TRANSACTION_notifyCleartextNetwork:I = 0x2e

.field static final blacklist TRANSACTION_notifyContentProviderPublishStatus:I = 0x41

.field static final blacklist TRANSACTION_notifyGcSupression:I = 0x49

.field static final blacklist TRANSACTION_oplusScheduleReceiver:I = 0x3

.field static final blacklist TRANSACTION_performDirectAction:I = 0x3a

.field static final greylist-max-o TRANSACTION_processInBackground:I = 0xb

.field static final greylist-max-o TRANSACTION_profilerControl:I = 0x11

.field static final greylist-max-o TRANSACTION_requestAssistContextExtras:I = 0x28

.field static final blacklist TRANSACTION_requestDirectActions:I = 0x39

.field static final greylist-max-o TRANSACTION_runIsolatedEntryPoint:I = 0x7

.field static final greylist-max-o TRANSACTION_scheduleApplicationInfoChanged:I = 0x35

.field static final greylist-max-o TRANSACTION_scheduleBindService:I = 0xc

.field static final greylist-max-o TRANSACTION_scheduleCrash:I = 0x18

.field static final greylist-max-o TRANSACTION_scheduleCreateBackupAgent:I = 0x13

.field static final greylist-max-o TRANSACTION_scheduleCreateService:I = 0x4

.field static final greylist-max-o TRANSACTION_scheduleDestroyBackupAgent:I = 0x14

.field static final greylist-max-o TRANSACTION_scheduleEnterAnimationComplete:I = 0x2d

.field static final greylist-max-o TRANSACTION_scheduleExit:I = 0x8

.field static final greylist-max-o TRANSACTION_scheduleInstallProvider:I = 0x2b

.field static final greylist-max-o TRANSACTION_scheduleLocalVoiceInteractionStarted:I = 0x31

.field static final greylist-max-o TRANSACTION_scheduleLowMemory:I = 0x10

.field static final blacklist TRANSACTION_scheduleOnNewSceneTransitionInfo:I = 0x15

.field static final blacklist TRANSACTION_schedulePing:I = 0x46

.field static final greylist-max-o TRANSACTION_scheduleReceiver:I = 0x1

.field static final blacklist TRANSACTION_scheduleReceiverList:I = 0x2

.field static final greylist-max-o TRANSACTION_scheduleRegisteredReceiver:I = 0xf

.field static final greylist-max-o TRANSACTION_scheduleServiceArgs:I = 0x9

.field static final greylist-max-o TRANSACTION_scheduleStopService:I = 0x5

.field static final greylist-max-o TRANSACTION_scheduleSuicide:I = 0x16

.field static final blacklist TRANSACTION_scheduleTaskFragmentTransaction:I = 0x38

.field static final blacklist TRANSACTION_scheduleTimeoutService:I = 0x44

.field static final blacklist TRANSACTION_scheduleTimeoutServiceForType:I = 0x45

.field static final greylist-max-o TRANSACTION_scheduleTransaction:I = 0x37

.field static final greylist-max-o TRANSACTION_scheduleTranslucentConversionComplete:I = 0x29

.field static final greylist-max-o TRANSACTION_scheduleTrimMemory:I = 0x20

.field static final greylist-max-o TRANSACTION_scheduleUnbindService:I = 0xd

.field static final greylist-max-o TRANSACTION_setCoreSettings:I = 0x1e

.field static final blacklist TRANSACTION_setDynamicalLogConfig:I = 0x3f

.field static final blacklist TRANSACTION_setDynamicalLogEnable:I = 0x3e

.field static final greylist-max-o TRANSACTION_setNetworkBlockSeq:I = 0x36

.field static final greylist-max-o TRANSACTION_setProcessState:I = 0x2a

.field static final greylist-max-o TRANSACTION_setSchedulingGroup:I = 0x12

.field static final greylist-max-o TRANSACTION_startBinderTracking:I = 0x2f

.field static final greylist-max-o TRANSACTION_stopBinderTrackingAndDump:I = 0x30

.field static final greylist-max-o TRANSACTION_unstableProviderDied:I = 0x27

.field static final blacklist TRANSACTION_updateHttpProxy:I = 0x1d

.field static final greylist-max-o TRANSACTION_updatePackageCompatibilityInfo:I = 0x1f

.field static final greylist-max-o TRANSACTION_updateTimePrefs:I = 0x2c

.field static final greylist-max-o TRANSACTION_updateTimeZone:I = 0xa

.field static final blacklist TRANSACTION_updateUiTranslationState:I = 0x43


# direct methods
.method public constructor greylist-max-o <init>()V
    .registers 2

    .line 586
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 587
    const-string v0, "android.app.IApplicationThread"

    invoke-virtual {p0, p0, v0}, Landroid/app/IApplicationThread$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 588
    return-void
.end method

.method public static greylist-max-o asInterface(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    .registers 3
    .param p0, "obj"    # Landroid/os/IBinder;

    .line 595
    if-nez p0, :cond_4

    .line 596
    const/4 v0, 0x0

    return-object v0

    .line 598
    :cond_4
    const-string v0, "android.app.IApplicationThread"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 599
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_14

    instance-of v1, v0, Landroid/app/IApplicationThread;

    if-eqz v1, :cond_14

    .line 600
    move-object v1, v0

    check-cast v1, Landroid/app/IApplicationThread;

    return-object v1

    .line 602
    :cond_14
    new-instance v1, Landroid/app/IApplicationThread$Stub$Proxy;

    invoke-direct {v1, p0}, Landroid/app/IApplicationThread$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method

.method public static blacklist getDefaultTransactionName(I)Ljava/lang/String;
    .registers 2
    .param p0, "transactionCode"    # I

    .line 611
    packed-switch p0, :pswitch_data_114

    .line 907
    const/4 v0, 0x0

    return-object v0

    .line 903
    :pswitch_5
    const-string/jumbo v0, "notifyGcSupression"

    return-object v0

    .line 899
    :pswitch_9
    const-string v0, "getExecutableMethodFileOffsets"

    return-object v0

    .line 895
    :pswitch_c
    const-string v0, "dumpMainLooperTrackedMsg"

    return-object v0

    .line 891
    :pswitch_f
    const-string/jumbo v0, "schedulePing"

    return-object v0

    .line 887
    :pswitch_13
    const-string/jumbo v0, "scheduleTimeoutServiceForType"

    return-object v0

    .line 883
    :pswitch_17
    const-string/jumbo v0, "scheduleTimeoutService"

    return-object v0

    .line 879
    :pswitch_1b
    const-string/jumbo v0, "updateUiTranslationState"

    return-object v0

    .line 875
    :pswitch_1f
    const-string/jumbo v0, "instrumentWithoutRestart"

    return-object v0

    .line 871
    :pswitch_23
    const-string/jumbo v0, "notifyContentProviderPublishStatus"

    return-object v0

    .line 867
    :pswitch_27
    const-string v0, "getBroadcastState"

    return-object v0

    .line 863
    :pswitch_2a
    const-string/jumbo v0, "setDynamicalLogConfig"

    return-object v0

    .line 859
    :pswitch_2e
    const-string/jumbo v0, "setDynamicalLogEnable"

    return-object v0

    .line 855
    :pswitch_32
    const-string v0, "dumpMessage"

    return-object v0

    .line 851
    :pswitch_35
    const-string v0, "enableProcessMainThreadLooperLog"

    return-object v0

    .line 847
    :pswitch_38
    const-string v0, "enableActivityThreadLog"

    return-object v0

    .line 843
    :pswitch_3b
    const-string/jumbo v0, "performDirectAction"

    return-object v0

    .line 839
    :pswitch_3f
    const-string/jumbo v0, "requestDirectActions"

    return-object v0

    .line 835
    :pswitch_43
    const-string/jumbo v0, "scheduleTaskFragmentTransaction"

    return-object v0

    .line 831
    :pswitch_47
    const-string/jumbo v0, "scheduleTransaction"

    return-object v0

    .line 827
    :pswitch_4b
    const-string/jumbo v0, "setNetworkBlockSeq"

    return-object v0

    .line 823
    :pswitch_4f
    const-string/jumbo v0, "scheduleApplicationInfoChanged"

    return-object v0

    .line 819
    :pswitch_53
    const-string v0, "attachStartupAgents"

    return-object v0

    .line 815
    :pswitch_56
    const-string v0, "attachAgent"

    return-object v0

    .line 811
    :pswitch_59
    const-string v0, "handleTrustStorageUpdate"

    return-object v0

    .line 807
    :pswitch_5c
    const-string/jumbo v0, "scheduleLocalVoiceInteractionStarted"

    return-object v0

    .line 803
    :pswitch_60
    const-string/jumbo v0, "stopBinderTrackingAndDump"

    return-object v0

    .line 799
    :pswitch_64
    const-string/jumbo v0, "startBinderTracking"

    return-object v0

    .line 795
    :pswitch_68
    const-string/jumbo v0, "notifyCleartextNetwork"

    return-object v0

    .line 791
    :pswitch_6c
    const-string/jumbo v0, "scheduleEnterAnimationComplete"

    return-object v0

    .line 787
    :pswitch_70
    const-string/jumbo v0, "updateTimePrefs"

    return-object v0

    .line 783
    :pswitch_74
    const-string/jumbo v0, "scheduleInstallProvider"

    return-object v0

    .line 779
    :pswitch_78
    const-string/jumbo v0, "setProcessState"

    return-object v0

    .line 775
    :pswitch_7c
    const-string/jumbo v0, "scheduleTranslucentConversionComplete"

    return-object v0

    .line 771
    :pswitch_80
    const-string/jumbo v0, "requestAssistContextExtras"

    return-object v0

    .line 767
    :pswitch_84
    const-string/jumbo v0, "unstableProviderDied"

    return-object v0

    .line 763
    :pswitch_88
    const-string v0, "dumpDbInfo"

    return-object v0

    .line 759
    :pswitch_8b
    const-string v0, "dumpProvider"

    return-object v0

    .line 755
    :pswitch_8e
    const-string v0, "dumpCacheInfo"

    return-object v0

    .line 751
    :pswitch_91
    const-string v0, "dumpGfxInfo"

    return-object v0

    .line 747
    :pswitch_94
    const-string v0, "dumpMemInfoProto"

    return-object v0

    .line 743
    :pswitch_97
    const-string v0, "dumpMemInfo"

    return-object v0

    .line 739
    :pswitch_9a
    const-string/jumbo v0, "scheduleTrimMemory"

    return-object v0

    .line 735
    :pswitch_9e
    const-string/jumbo v0, "updatePackageCompatibilityInfo"

    return-object v0

    .line 731
    :pswitch_a2
    const-string/jumbo v0, "setCoreSettings"

    return-object v0

    .line 727
    :pswitch_a6
    const-string/jumbo v0, "updateHttpProxy"

    return-object v0

    .line 723
    :pswitch_aa
    const-string v0, "clearDnsCache"

    return-object v0

    .line 719
    :pswitch_ad
    const-string v0, "dumpResources"

    return-object v0

    .line 715
    :pswitch_b0
    const-string v0, "dumpActivity"

    return-object v0

    .line 711
    :pswitch_b3
    const-string v0, "dumpHeap"

    return-object v0

    .line 707
    :pswitch_b6
    const-string/jumbo v0, "scheduleCrash"

    return-object v0

    .line 703
    :pswitch_ba
    const-string v0, "dispatchPackageBroadcast"

    return-object v0

    .line 699
    :pswitch_bd
    const-string/jumbo v0, "scheduleSuicide"

    return-object v0

    .line 695
    :pswitch_c1
    const-string/jumbo v0, "scheduleOnNewSceneTransitionInfo"

    return-object v0

    .line 691
    :pswitch_c5
    const-string/jumbo v0, "scheduleDestroyBackupAgent"

    return-object v0

    .line 687
    :pswitch_c9
    const-string/jumbo v0, "scheduleCreateBackupAgent"

    return-object v0

    .line 683
    :pswitch_cd
    const-string/jumbo v0, "setSchedulingGroup"

    return-object v0

    .line 679
    :pswitch_d1
    const-string/jumbo v0, "profilerControl"

    return-object v0

    .line 675
    :pswitch_d5
    const-string/jumbo v0, "scheduleLowMemory"

    return-object v0

    .line 671
    :pswitch_d9
    const-string/jumbo v0, "scheduleRegisteredReceiver"

    return-object v0

    .line 667
    :pswitch_dd
    const-string v0, "dumpService"

    return-object v0

    .line 663
    :pswitch_e0
    const-string/jumbo v0, "scheduleUnbindService"

    return-object v0

    .line 659
    :pswitch_e4
    const-string/jumbo v0, "scheduleBindService"

    return-object v0

    .line 655
    :pswitch_e8
    const-string/jumbo v0, "processInBackground"

    return-object v0

    .line 651
    :pswitch_ec
    const-string/jumbo v0, "updateTimeZone"

    return-object v0

    .line 647
    :pswitch_f0
    const-string/jumbo v0, "scheduleServiceArgs"

    return-object v0

    .line 643
    :pswitch_f4
    const-string/jumbo v0, "scheduleExit"

    return-object v0

    .line 639
    :pswitch_f8
    const-string/jumbo v0, "runIsolatedEntryPoint"

    return-object v0

    .line 635
    :pswitch_fc
    const-string v0, "bindApplication"

    return-object v0

    .line 631
    :pswitch_ff
    const-string/jumbo v0, "scheduleStopService"

    return-object v0

    .line 627
    :pswitch_103
    const-string/jumbo v0, "scheduleCreateService"

    return-object v0

    .line 623
    :pswitch_107
    const-string/jumbo v0, "oplusScheduleReceiver"

    return-object v0

    .line 619
    :pswitch_10b
    const-string/jumbo v0, "scheduleReceiverList"

    return-object v0

    .line 615
    :pswitch_10f
    const-string/jumbo v0, "scheduleReceiver"

    return-object v0

    nop

    :pswitch_data_114
    .packed-switch 0x1
        :pswitch_10f
        :pswitch_10b
        :pswitch_107
        :pswitch_103
        :pswitch_ff
        :pswitch_fc
        :pswitch_f8
        :pswitch_f4
        :pswitch_f0
        :pswitch_ec
        :pswitch_e8
        :pswitch_e4
        :pswitch_e0
        :pswitch_dd
        :pswitch_d9
        :pswitch_d5
        :pswitch_d1
        :pswitch_cd
        :pswitch_c9
        :pswitch_c5
        :pswitch_c1
        :pswitch_bd
        :pswitch_ba
        :pswitch_b6
        :pswitch_b3
        :pswitch_b0
        :pswitch_ad
        :pswitch_aa
        :pswitch_a6
        :pswitch_a2
        :pswitch_9e
        :pswitch_9a
        :pswitch_97
        :pswitch_94
        :pswitch_91
        :pswitch_8e
        :pswitch_8b
        :pswitch_88
        :pswitch_84
        :pswitch_80
        :pswitch_7c
        :pswitch_78
        :pswitch_74
        :pswitch_70
        :pswitch_6c
        :pswitch_68
        :pswitch_64
        :pswitch_60
        :pswitch_5c
        :pswitch_59
        :pswitch_56
        :pswitch_53
        :pswitch_4f
        :pswitch_4b
        :pswitch_47
        :pswitch_43
        :pswitch_3f
        :pswitch_3b
        :pswitch_38
        :pswitch_35
        :pswitch_32
        :pswitch_2e
        :pswitch_2a
        :pswitch_27
        :pswitch_23
        :pswitch_1f
        :pswitch_1b
        :pswitch_17
        :pswitch_13
        :pswitch_f
        :pswitch_c
        :pswitch_9
        :pswitch_5
    .end packed-switch
.end method


# virtual methods
.method public whitelist asBinder()Landroid/os/IBinder;
    .registers 1

    .line 606
    return-object p0
.end method

.method public blacklist getMaxTransactionId()I
    .registers 2

    .line 2892
    const/16 v0, 0x48

    return v0
.end method

.method public blacklist getTransactionName(I)Ljava/lang/String;
    .registers 3
    .param p1, "transactionCode"    # I

    .line 914
    invoke-static {p1}, Landroid/app/IApplicationThread$Stub;->getDefaultTransactionName(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 40
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 918
    move-object/from16 v0, p0

    move/from16 v13, p1

    move-object/from16 v14, p2

    const-string v15, "android.app.IApplicationThread"

    .line 919
    .local v15, "descriptor":Ljava/lang/String;
    const/4 v10, 0x1

    if-lt v13, v10, :cond_13

    const v1, 0xffffff

    if-gt v13, v1, :cond_13

    .line 920
    invoke-virtual {v14, v15}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 922
    :cond_13
    const v1, 0x5f4e5446

    if-ne v13, v1, :cond_1e

    .line 923
    move-object/from16 v11, p3

    invoke-virtual {v11, v15}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 924
    return v10

    .line 926
    :cond_1e
    move-object/from16 v11, p3

    packed-switch v13, :pswitch_data_820

    .line 1768
    invoke-super/range {p0 .. p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    return v0

    .line 1757
    :pswitch_28
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1759
    .local v1, "_arg0":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1761
    .local v2, "_arg1":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1762
    .local v3, "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1763
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->notifyGcSupression(ZII)V

    .line 1764
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1747
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    :pswitch_40
    sget-object v1, Landroid/os/instrumentation/MethodDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/instrumentation/MethodDescriptor;

    .line 1749
    .local v1, "_arg0":Landroid/os/instrumentation/MethodDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Landroid/os/instrumentation/IOffsetCallback$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/instrumentation/IOffsetCallback;

    move-result-object v2

    .line 1750
    .local v2, "_arg1":Landroid/os/instrumentation/IOffsetCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1751
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->getExecutableMethodFileOffsets(Landroid/os/instrumentation/MethodDescriptor;Landroid/os/instrumentation/IOffsetCallback;)V

    .line 1752
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1741
    .end local v1    # "_arg0":Landroid/os/instrumentation/MethodDescriptor;
    .end local v2    # "_arg1":Landroid/os/instrumentation/IOffsetCallback;
    :pswitch_5c
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->dumpMainLooperTrackedMsg()V

    .line 1742
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1734
    :pswitch_65
    sget-object v1, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/RemoteCallback;

    .line 1735
    .local v1, "_arg0":Landroid/os/RemoteCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1736
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->schedulePing(Landroid/os/RemoteCallback;)V

    .line 1737
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1722
    .end local v1    # "_arg0":Landroid/os/RemoteCallback;
    :pswitch_79
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1724
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1726
    .local v2, "_arg1":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1727
    .restart local v3    # "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1728
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->scheduleTimeoutServiceForType(Landroid/os/IBinder;II)V

    .line 1729
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1712
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    :pswitch_91
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1714
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1715
    .restart local v2    # "_arg1":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1716
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleTimeoutService(Landroid/os/IBinder;I)V

    .line 1717
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1694
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    :pswitch_a5
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1696
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1698
    .restart local v2    # "_arg1":I
    sget-object v3, Landroid/view/translation/TranslationSpec;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/translation/TranslationSpec;

    .line 1700
    .local v3, "_arg2":Landroid/view/translation/TranslationSpec;
    sget-object v4, Landroid/view/translation/TranslationSpec;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/translation/TranslationSpec;

    .line 1702
    .local v4, "_arg3":Landroid/view/translation/TranslationSpec;
    sget-object v5, Landroid/view/autofill/AutofillId;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v5}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v5

    .line 1704
    .local v5, "_arg4":Ljava/util/List;, "Ljava/util/List<Landroid/view/autofill/AutofillId;>;"
    sget-object v6, Landroid/view/translation/UiTranslationSpec;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/view/translation/UiTranslationSpec;

    .line 1705
    .local v6, "_arg5":Landroid/view/translation/UiTranslationSpec;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1706
    invoke-virtual/range {v0 .. v6}, Landroid/app/IApplicationThread$Stub;->updateUiTranslationState(Landroid/os/IBinder;ILandroid/view/translation/TranslationSpec;Landroid/view/translation/TranslationSpec;Ljava/util/List;Landroid/view/translation/UiTranslationSpec;)V

    .line 1707
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1678
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/view/translation/TranslationSpec;
    .end local v4    # "_arg3":Landroid/view/translation/TranslationSpec;
    .end local v5    # "_arg4":Ljava/util/List;, "Ljava/util/List<Landroid/view/autofill/AutofillId;>;"
    .end local v6    # "_arg5":Landroid/view/translation/UiTranslationSpec;
    :pswitch_d7
    sget-object v0, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/content/ComponentName;

    .line 1680
    .local v1, "_arg0":Landroid/content/ComponentName;
    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Landroid/os/Bundle;

    .line 1682
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Landroid/app/IInstrumentationWatcher$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IInstrumentationWatcher;

    move-result-object v3

    .line 1684
    .local v3, "_arg2":Landroid/app/IInstrumentationWatcher;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Landroid/app/IUiAutomationConnection$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IUiAutomationConnection;

    move-result-object v4

    .line 1686
    .local v4, "_arg3":Landroid/app/IUiAutomationConnection;
    sget-object v0, Landroid/content/pm/ApplicationInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Landroid/content/pm/ApplicationInfo;

    .line 1687
    .local v5, "_arg4":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1688
    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IApplicationThread$Stub;->instrumentWithoutRestart(Landroid/content/ComponentName;Landroid/os/Bundle;Landroid/app/IInstrumentationWatcher;Landroid/app/IUiAutomationConnection;Landroid/content/pm/ApplicationInfo;)V

    .line 1689
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1664
    .end local v1    # "_arg0":Landroid/content/ComponentName;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Landroid/app/IInstrumentationWatcher;
    .end local v4    # "_arg3":Landroid/app/IUiAutomationConnection;
    .end local v5    # "_arg4":Landroid/content/pm/ApplicationInfo;
    :pswitch_110
    sget-object v1, Landroid/app/ContentProviderHolder;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/ContentProviderHolder;

    .line 1666
    .local v1, "_arg0":Landroid/app/ContentProviderHolder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1668
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1670
    .local v3, "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 1671
    .local v4, "_arg3":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1672
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/IApplicationThread$Stub;->notifyContentProviderPublishStatus(Landroid/app/ContentProviderHolder;Ljava/lang/String;IZ)V

    .line 1673
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1656
    .end local v1    # "_arg0":Landroid/app/ContentProviderHolder;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Z
    :pswitch_130
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1657
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1658
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->getBroadcastState(I)V

    .line 1659
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1648
    .end local v1    # "_arg0":I
    :pswitch_140
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 1649
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1650
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->setDynamicalLogConfig(Ljava/util/List;)V

    .line 1651
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1640
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_150
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1641
    .local v1, "_arg0":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1642
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->setDynamicalLogEnable(Z)V

    .line 1643
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1632
    .end local v1    # "_arg0":Z
    :pswitch_160
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1633
    .restart local v1    # "_arg0":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1634
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->dumpMessage(Z)V

    .line 1635
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1626
    .end local v1    # "_arg0":Z
    :pswitch_170
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->enableProcessMainThreadLooperLog()V

    .line 1627
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1619
    :pswitch_179
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1620
    .restart local v1    # "_arg0":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1621
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->enableActivityThreadLog(Z)V

    .line 1622
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1603
    .end local v1    # "_arg0":Z
    :pswitch_189
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1605
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1607
    .restart local v2    # "_arg1":Ljava/lang/String;
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 1609
    .local v3, "_arg2":Landroid/os/Bundle;
    sget-object v4, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/RemoteCallback;

    .line 1611
    .local v4, "_arg3":Landroid/os/RemoteCallback;
    sget-object v5, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/RemoteCallback;

    .line 1612
    .local v5, "_arg4":Landroid/os/RemoteCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1613
    invoke-virtual/range {v0 .. v5}, Landroid/app/IApplicationThread$Stub;->performDirectAction(Landroid/os/IBinder;Ljava/lang/String;Landroid/os/Bundle;Landroid/os/RemoteCallback;Landroid/os/RemoteCallback;)V

    .line 1614
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1589
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Landroid/os/Bundle;
    .end local v4    # "_arg3":Landroid/os/RemoteCallback;
    .end local v5    # "_arg4":Landroid/os/RemoteCallback;
    :pswitch_1b5
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1591
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/app/IVoiceInteractor$Stub;->asInterface(Landroid/os/IBinder;)Lcom/android/internal/app/IVoiceInteractor;

    move-result-object v2

    .line 1593
    .local v2, "_arg1":Lcom/android/internal/app/IVoiceInteractor;
    sget-object v3, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/RemoteCallback;

    .line 1595
    .local v3, "_arg2":Landroid/os/RemoteCallback;
    sget-object v4, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/RemoteCallback;

    .line 1596
    .restart local v4    # "_arg3":Landroid/os/RemoteCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1597
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/IApplicationThread$Stub;->requestDirectActions(Landroid/os/IBinder;Lcom/android/internal/app/IVoiceInteractor;Landroid/os/RemoteCallback;Landroid/os/RemoteCallback;)V

    .line 1598
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1579
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Lcom/android/internal/app/IVoiceInteractor;
    .end local v3    # "_arg2":Landroid/os/RemoteCallback;
    .end local v4    # "_arg3":Landroid/os/RemoteCallback;
    :pswitch_1dd
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/window/ITaskFragmentOrganizer$Stub;->asInterface(Landroid/os/IBinder;)Landroid/window/ITaskFragmentOrganizer;

    move-result-object v1

    .line 1581
    .local v1, "_arg0":Landroid/window/ITaskFragmentOrganizer;
    sget-object v2, Landroid/window/TaskFragmentTransaction;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/window/TaskFragmentTransaction;

    .line 1582
    .local v2, "_arg1":Landroid/window/TaskFragmentTransaction;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1583
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleTaskFragmentTransaction(Landroid/window/ITaskFragmentOrganizer;Landroid/window/TaskFragmentTransaction;)V

    .line 1584
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1571
    .end local v1    # "_arg0":Landroid/window/ITaskFragmentOrganizer;
    .end local v2    # "_arg1":Landroid/window/TaskFragmentTransaction;
    :pswitch_1f9
    sget-object v1, Landroid/app/servertransaction/ClientTransaction;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/servertransaction/ClientTransaction;

    .line 1572
    .local v1, "_arg0":Landroid/app/servertransaction/ClientTransaction;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1573
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleTransaction(Landroid/app/servertransaction/ClientTransaction;)V

    .line 1574
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1563
    .end local v1    # "_arg0":Landroid/app/servertransaction/ClientTransaction;
    :pswitch_20d
    invoke-virtual {v14}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 1564
    .local v1, "_arg0":J
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1565
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->setNetworkBlockSeq(J)V

    .line 1566
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1555
    .end local v1    # "_arg0":J
    :pswitch_21d
    sget-object v1, Landroid/content/pm/ApplicationInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ApplicationInfo;

    .line 1556
    .local v1, "_arg0":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1557
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleApplicationInfoChanged(Landroid/content/pm/ApplicationInfo;)V

    .line 1558
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1547
    .end local v1    # "_arg0":Landroid/content/pm/ApplicationInfo;
    :pswitch_231
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1548
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1549
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->attachStartupAgents(Ljava/lang/String;)V

    .line 1550
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1539
    .end local v1    # "_arg0":Ljava/lang/String;
    :pswitch_241
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1540
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1541
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->attachAgent(Ljava/lang/String;)V

    .line 1542
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1533
    .end local v1    # "_arg0":Ljava/lang/String;
    :pswitch_251
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->handleTrustStorageUpdate()V

    .line 1534
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1524
    :pswitch_25a
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1526
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/app/IVoiceInteractor$Stub;->asInterface(Landroid/os/IBinder;)Lcom/android/internal/app/IVoiceInteractor;

    move-result-object v2

    .line 1527
    .local v2, "_arg1":Lcom/android/internal/app/IVoiceInteractor;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1528
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleLocalVoiceInteractionStarted(Landroid/os/IBinder;Lcom/android/internal/app/IVoiceInteractor;)V

    .line 1529
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1516
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Lcom/android/internal/app/IVoiceInteractor;
    :pswitch_272
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1517
    .local v1, "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1518
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->stopBinderTrackingAndDump(Landroid/os/ParcelFileDescriptor;)V

    .line 1519
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1510
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    :pswitch_286
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->startBinderTracking()V

    .line 1511
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1503
    :pswitch_28f
    invoke-virtual {v14}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v1

    .line 1504
    .local v1, "_arg0":[B
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1505
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->notifyCleartextNetwork([B)V

    .line 1506
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1495
    .end local v1    # "_arg0":[B
    :pswitch_29f
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1496
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1497
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleEnterAnimationComplete(Landroid/os/IBinder;)V

    .line 1498
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1487
    .end local v1    # "_arg0":Landroid/os/IBinder;
    :pswitch_2af
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1488
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1489
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->updateTimePrefs(I)V

    .line 1490
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1479
    .end local v1    # "_arg0":I
    :pswitch_2bf
    sget-object v1, Landroid/content/pm/ProviderInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ProviderInfo;

    .line 1480
    .local v1, "_arg0":Landroid/content/pm/ProviderInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1481
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleInstallProvider(Landroid/content/pm/ProviderInfo;)V

    .line 1482
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1471
    .end local v1    # "_arg0":Landroid/content/pm/ProviderInfo;
    :pswitch_2d3
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1472
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1473
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->setProcessState(I)V

    .line 1474
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1461
    .end local v1    # "_arg0":I
    :pswitch_2e3
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1463
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 1464
    .local v2, "_arg1":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1465
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleTranslucentConversionComplete(Landroid/os/IBinder;Z)V

    .line 1466
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1445
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Z
    :pswitch_2f7
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1447
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    .line 1449
    .local v2, "_arg1":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1451
    .local v3, "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1453
    .local v4, "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 1454
    .local v5, "_arg4":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1455
    invoke-virtual/range {v0 .. v5}, Landroid/app/IApplicationThread$Stub;->requestAssistContextExtras(Landroid/os/IBinder;Landroid/os/IBinder;III)V

    .line 1456
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1437
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/os/IBinder;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":I
    :pswitch_317
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1438
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1439
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->unstableProviderDied(Landroid/os/IBinder;)V

    .line 1440
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1427
    .end local v1    # "_arg0":Landroid/os/IBinder;
    :pswitch_327
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1429
    .local v1, "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 1430
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1431
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->dumpDbInfo(Landroid/os/ParcelFileDescriptor;[Ljava/lang/String;)V

    .line 1432
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1415
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_33f
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1417
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    .line 1419
    .local v2, "_arg1":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v3

    .line 1420
    .local v3, "_arg2":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1421
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->dumpProvider(Landroid/os/ParcelFileDescriptor;Landroid/os/IBinder;[Ljava/lang/String;)V

    .line 1422
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1405
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/IBinder;
    .end local v3    # "_arg2":[Ljava/lang/String;
    :pswitch_35b
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1407
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 1408
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1409
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->dumpCacheInfo(Landroid/os/ParcelFileDescriptor;[Ljava/lang/String;)V

    .line 1410
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1395
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_373
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1397
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 1398
    .restart local v2    # "_arg1":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1399
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->dumpGfxInfo(Landroid/os/ParcelFileDescriptor;[Ljava/lang/String;)V

    .line 1400
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1375
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_38b
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1377
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    sget-object v2, Landroid/os/Debug$MemoryInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Debug$MemoryInfo;

    .line 1379
    .local v2, "_arg1":Landroid/os/Debug$MemoryInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 1381
    .local v3, "_arg2":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 1383
    .local v4, "_arg3":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v5

    .line 1385
    .local v5, "_arg4":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v6

    .line 1387
    .local v6, "_arg5":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v7

    .line 1388
    .local v7, "_arg6":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1389
    invoke-virtual/range {v0 .. v7}, Landroid/app/IApplicationThread$Stub;->dumpMemInfoProto(Landroid/os/ParcelFileDescriptor;Landroid/os/Debug$MemoryInfo;ZZZZ[Ljava/lang/String;)V

    .line 1390
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1351
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/Debug$MemoryInfo;
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    .end local v5    # "_arg4":Z
    .end local v6    # "_arg5":Z
    .end local v7    # "_arg6":[Ljava/lang/String;
    :pswitch_3bb
    sget-object v0, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1353
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    sget-object v0, Landroid/os/Debug$MemoryInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Landroid/os/Debug$MemoryInfo;

    .line 1355
    .restart local v2    # "_arg1":Landroid/os/Debug$MemoryInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 1357
    .restart local v3    # "_arg2":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 1359
    .restart local v4    # "_arg3":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v5

    .line 1361
    .restart local v5    # "_arg4":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v6

    .line 1363
    .restart local v6    # "_arg5":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v7

    .line 1365
    .local v7, "_arg6":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v8

    .line 1367
    .local v8, "_arg7":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v9

    .line 1368
    .local v9, "_arg8":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1369
    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v9}, Landroid/app/IApplicationThread$Stub;->dumpMemInfo(Landroid/os/ParcelFileDescriptor;Landroid/os/Debug$MemoryInfo;ZZZZZZ[Ljava/lang/String;)V

    .line 1370
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1343
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/Debug$MemoryInfo;
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    .end local v5    # "_arg4":Z
    .end local v6    # "_arg5":Z
    .end local v7    # "_arg6":Z
    .end local v8    # "_arg7":Z
    .end local v9    # "_arg8":[Ljava/lang/String;
    :pswitch_3f7
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1344
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1345
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleTrimMemory(I)V

    .line 1346
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1333
    .end local v1    # "_arg0":I
    :pswitch_407
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1335
    .local v1, "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/content/res/CompatibilityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/res/CompatibilityInfo;

    .line 1336
    .local v2, "_arg1":Landroid/content/res/CompatibilityInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1337
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->updatePackageCompatibilityInfo(Ljava/lang/String;Landroid/content/res/CompatibilityInfo;)V

    .line 1338
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1325
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/content/res/CompatibilityInfo;
    :pswitch_41f
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 1326
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1327
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->setCoreSettings(Landroid/os/Bundle;)V

    .line 1328
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1319
    .end local v1    # "_arg0":Landroid/os/Bundle;
    :pswitch_433
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->updateHttpProxy()V

    .line 1320
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1314
    :pswitch_43c
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->clearDnsCache()V

    .line 1315
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1305
    :pswitch_445
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1307
    .local v1, "_arg0":Landroid/os/ParcelFileDescriptor;
    sget-object v2, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/RemoteCallback;

    .line 1308
    .local v2, "_arg1":Landroid/os/RemoteCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1309
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->dumpResources(Landroid/os/ParcelFileDescriptor;Landroid/os/RemoteCallback;)V

    .line 1310
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1291
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/RemoteCallback;
    :pswitch_461
    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1293
    .restart local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    .line 1295
    .local v2, "_arg1":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 1297
    .local v3, "_arg2":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v4

    .line 1298
    .local v4, "_arg3":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1299
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/IApplicationThread$Stub;->dumpActivity(Landroid/os/ParcelFileDescriptor;Landroid/os/IBinder;Ljava/lang/String;[Ljava/lang/String;)V

    .line 1300
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1271
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/IBinder;
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_arg3":[Ljava/lang/String;
    :pswitch_481
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1273
    .local v1, "_arg0":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 1275
    .local v2, "_arg1":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 1277
    .local v3, "_arg2":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 1279
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 1281
    .local v5, "_arg4":Ljava/lang/String;
    sget-object v6, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/os/ParcelFileDescriptor;

    .line 1283
    .local v6, "_arg5":Landroid/os/ParcelFileDescriptor;
    sget-object v7, Landroid/os/RemoteCallback;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v7}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/os/RemoteCallback;

    .line 1284
    .local v7, "_arg6":Landroid/os/RemoteCallback;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1285
    invoke-virtual/range {v0 .. v7}, Landroid/app/IApplicationThread$Stub;->dumpHeap(ZZZLjava/lang/String;Ljava/lang/String;Landroid/os/ParcelFileDescriptor;Landroid/os/RemoteCallback;)V

    .line 1286
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1259
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Ljava/lang/String;
    .end local v6    # "_arg5":Landroid/os/ParcelFileDescriptor;
    .end local v7    # "_arg6":Landroid/os/RemoteCallback;
    :pswitch_4b1
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1261
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1263
    .local v2, "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 1264
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1265
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->scheduleCrash(Ljava/lang/String;ILandroid/os/Bundle;)V

    .line 1266
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1249
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    :pswitch_4cd
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1251
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 1252
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1253
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->dispatchPackageBroadcast(I[Ljava/lang/String;)V

    .line 1254
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1243
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_4e1
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->scheduleSuicide()V

    .line 1244
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1234
    :pswitch_4ea
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1236
    .local v1, "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/app/ActivityOptions$SceneTransitionInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/ActivityOptions$SceneTransitionInfo;

    .line 1237
    .local v2, "_arg1":Landroid/app/ActivityOptions$SceneTransitionInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1238
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleOnNewSceneTransitionInfo(Landroid/os/IBinder;Landroid/app/ActivityOptions$SceneTransitionInfo;)V

    .line 1239
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1224
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/app/ActivityOptions$SceneTransitionInfo;
    :pswitch_502
    sget-object v1, Landroid/content/pm/ApplicationInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ApplicationInfo;

    .line 1226
    .local v1, "_arg0":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1227
    .local v2, "_arg1":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1228
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleDestroyBackupAgent(Landroid/content/pm/ApplicationInfo;I)V

    .line 1229
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1210
    .end local v1    # "_arg0":Landroid/content/pm/ApplicationInfo;
    .end local v2    # "_arg1":I
    :pswitch_51a
    sget-object v1, Landroid/content/pm/ApplicationInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ApplicationInfo;

    .line 1212
    .restart local v1    # "_arg0":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1214
    .restart local v2    # "_arg1":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1216
    .local v3, "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1217
    .local v4, "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1218
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/IApplicationThread$Stub;->scheduleCreateBackupAgent(Landroid/content/pm/ApplicationInfo;III)V

    .line 1219
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1202
    .end local v1    # "_arg0":Landroid/content/pm/ApplicationInfo;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    :pswitch_53a
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1203
    .local v1, "_arg0":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1204
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->setSchedulingGroup(I)V

    .line 1205
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1190
    .end local v1    # "_arg0":I
    :pswitch_54a
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1192
    .local v1, "_arg0":Z
    sget-object v2, Landroid/app/ProfilerInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/ProfilerInfo;

    .line 1194
    .local v2, "_arg1":Landroid/app/ProfilerInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1195
    .restart local v3    # "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1196
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->profilerControl(ZLandroid/app/ProfilerInfo;I)V

    .line 1197
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1184
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":Landroid/app/ProfilerInfo;
    .end local v3    # "_arg2":I
    :pswitch_566
    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->scheduleLowMemory()V

    .line 1185
    move/from16 v32, v10

    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1155
    :pswitch_56f
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/content/IIntentReceiver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/content/IIntentReceiver;

    move-result-object v1

    .line 1157
    .local v1, "_arg0":Landroid/content/IIntentReceiver;
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/Intent;

    .line 1159
    .local v2, "_arg1":Landroid/content/Intent;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1161
    .restart local v3    # "_arg2":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 1163
    .local v4, "_arg3":Ljava/lang/String;
    sget-object v5, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/Bundle;

    .line 1165
    .local v5, "_arg4":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v6

    .line 1167
    .local v6, "_arg5":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v7

    .line 1169
    .local v7, "_arg6":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v8

    .line 1171
    .restart local v8    # "_arg7":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v9

    .line 1173
    .local v9, "_arg8":I
    move v12, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v10

    .line 1175
    .local v10, "_arg9":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v11

    .line 1177
    .local v11, "_arg10":I
    move/from16 v16, v12

    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v12

    .line 1178
    .local v12, "_arg11":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1179
    move/from16 v32, v16

    invoke-virtual/range {v0 .. v12}, Landroid/app/IApplicationThread$Stub;->scheduleRegisteredReceiver(Landroid/content/IIntentReceiver;Landroid/content/Intent;ILjava/lang/String;Landroid/os/Bundle;ZZZIIILjava/lang/String;)V

    .line 1180
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1143
    .end local v1    # "_arg0":Landroid/content/IIntentReceiver;
    .end local v2    # "_arg1":Landroid/content/Intent;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Landroid/os/Bundle;
    .end local v6    # "_arg5":Z
    .end local v7    # "_arg6":Z
    .end local v8    # "_arg7":Z
    .end local v9    # "_arg8":I
    .end local v10    # "_arg9":I
    .end local v11    # "_arg10":I
    .end local v12    # "_arg11":Ljava/lang/String;
    :pswitch_5ba
    move/from16 v32, v10

    sget-object v1, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/ParcelFileDescriptor;

    .line 1145
    .local v1, "_arg0":Landroid/os/ParcelFileDescriptor;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    .line 1147
    .local v2, "_arg1":Landroid/os/IBinder;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v3

    .line 1148
    .local v3, "_arg2":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1149
    invoke-virtual {v0, v1, v2, v3}, Landroid/app/IApplicationThread$Stub;->dumpService(Landroid/os/ParcelFileDescriptor;Landroid/os/IBinder;[Ljava/lang/String;)V

    .line 1150
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1133
    .end local v1    # "_arg0":Landroid/os/ParcelFileDescriptor;
    .end local v2    # "_arg1":Landroid/os/IBinder;
    .end local v3    # "_arg2":[Ljava/lang/String;
    :pswitch_5d6
    move/from16 v32, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1135
    .local v1, "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/Intent;

    .line 1136
    .local v2, "_arg1":Landroid/content/Intent;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1137
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleUnbindService(Landroid/os/IBinder;Landroid/content/Intent;)V

    .line 1138
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1117
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/content/Intent;
    :pswitch_5ee
    move/from16 v32, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1119
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/Intent;

    .line 1121
    .restart local v2    # "_arg1":Landroid/content/Intent;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 1123
    .local v3, "_arg2":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1125
    .local v4, "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 1126
    .local v5, "_arg4":J
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1127
    invoke-virtual/range {v0 .. v6}, Landroid/app/IApplicationThread$Stub;->scheduleBindService(Landroid/os/IBinder;Landroid/content/Intent;ZIJ)V

    .line 1128
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1111
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/content/Intent;
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":J
    :pswitch_612
    move/from16 v32, v10

    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->processInBackground()V

    .line 1112
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1106
    :pswitch_61b
    move/from16 v32, v10

    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->updateTimeZone()V

    .line 1107
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1097
    :pswitch_624
    move/from16 v32, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1099
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/content/pm/ParceledListSlice;->CREATOR:Landroid/os/Parcelable$ClassLoaderCreator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ParceledListSlice;

    .line 1100
    .local v2, "_arg1":Landroid/content/pm/ParceledListSlice;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1101
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->scheduleServiceArgs(Landroid/os/IBinder;Landroid/content/pm/ParceledListSlice;)V

    .line 1102
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1091
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/content/pm/ParceledListSlice;
    :pswitch_63c
    move/from16 v32, v10

    invoke-virtual {v0}, Landroid/app/IApplicationThread$Stub;->scheduleExit()V

    .line 1092
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1082
    :pswitch_645
    move/from16 v32, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1084
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 1085
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1086
    invoke-virtual {v0, v1, v2}, Landroid/app/IApplicationThread$Stub;->runIsolatedEntryPoint(Ljava/lang/String;[Ljava/lang/String;)V

    .line 1087
    move-object/from16 v33, v15

    goto/16 :goto_81e

    .line 1017
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_659
    move/from16 v32, v10

    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1019
    .restart local v1    # "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/content/pm/ApplicationInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ApplicationInfo;

    .line 1021
    .local v2, "_arg1":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 1023
    .local v3, "_arg2":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 1025
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v5

    .line 1027
    .local v5, "_arg4":Z
    sget-object v6, Landroid/content/pm/ProviderInfoList;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/pm/ProviderInfoList;

    .line 1029
    .local v6, "_arg5":Landroid/content/pm/ProviderInfoList;
    sget-object v7, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v7}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/content/ComponentName;

    .line 1031
    .local v7, "_arg6":Landroid/content/ComponentName;
    sget-object v8, Landroid/app/ProfilerInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v8}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/app/ProfilerInfo;

    .line 1033
    .local v8, "_arg7":Landroid/app/ProfilerInfo;
    sget-object v9, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v9}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/os/Bundle;

    .line 1035
    .local v9, "_arg8":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v10

    invoke-static {v10}, Landroid/app/IInstrumentationWatcher$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IInstrumentationWatcher;

    move-result-object v10

    .line 1037
    .local v10, "_arg9":Landroid/app/IInstrumentationWatcher;
    invoke-virtual {v14}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v11

    invoke-static {v11}, Landroid/app/IUiAutomationConnection$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IUiAutomationConnection;

    move-result-object v11

    .line 1039
    .local v11, "_arg10":Landroid/app/IUiAutomationConnection;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v12

    .line 1041
    .local v12, "_arg11":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v13

    .line 1043
    .local v13, "_arg12":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v16

    .line 1045
    .local v16, "_arg13":Z
    move-object/from16 v17, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .local v17, "descriptor":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v15

    .line 1047
    .local v15, "_arg14":Z
    move/from16 v18, v16

    .end local v16    # "_arg13":Z
    .local v18, "_arg13":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v16

    .line 1049
    .local v16, "_arg15":Z
    sget-object v0, Landroid/content/res/Configuration;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/res/Configuration;

    .line 1051
    .local v0, "_arg16":Landroid/content/res/Configuration;
    move-object/from16 v19, v0

    .end local v0    # "_arg16":Landroid/content/res/Configuration;
    .local v19, "_arg16":Landroid/content/res/Configuration;
    sget-object v0, Landroid/content/res/CompatibilityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/res/CompatibilityInfo;

    .line 1053
    .local v0, "_arg17":Landroid/content/res/CompatibilityInfo;
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v20

    move-object/from16 v21, v0

    .end local v0    # "_arg17":Landroid/content/res/CompatibilityInfo;
    .local v21, "_arg17":Landroid/content/res/CompatibilityInfo;
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 1054
    .local v0, "cl":Ljava/lang/ClassLoader;
    move-object/from16 v20, v17

    move-object/from16 v17, v19

    .end local v19    # "_arg16":Landroid/content/res/Configuration;
    .local v17, "_arg16":Landroid/content/res/Configuration;
    .local v20, "descriptor":Ljava/lang/String;
    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readHashMap(Ljava/lang/ClassLoader;)Ljava/util/HashMap;

    move-result-object v19

    .line 1056
    .local v19, "_arg18":Ljava/util/Map;
    move-object/from16 v22, v0

    .end local v0    # "cl":Ljava/lang/ClassLoader;
    .local v22, "cl":Ljava/lang/ClassLoader;
    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Bundle;

    .line 1058
    .local v0, "_arg19":Landroid/os/Bundle;
    move/from16 v23, v18

    move-object/from16 v18, v21

    .end local v21    # "_arg17":Landroid/content/res/CompatibilityInfo;
    .local v18, "_arg17":Landroid/content/res/CompatibilityInfo;
    .local v23, "_arg13":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v21

    .line 1060
    .local v21, "_arg20":Ljava/lang/String;
    move-object/from16 v24, v0

    .end local v0    # "_arg19":Landroid/os/Bundle;
    .local v24, "_arg19":Landroid/os/Bundle;
    sget-object v0, Landroid/content/AutofillOptions;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/AutofillOptions;

    .line 1062
    .local v0, "_arg21":Landroid/content/AutofillOptions;
    move-object/from16 v25, v0

    .end local v0    # "_arg21":Landroid/content/AutofillOptions;
    .local v25, "_arg21":Landroid/content/AutofillOptions;
    sget-object v0, Landroid/content/ContentCaptureOptions;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ContentCaptureOptions;

    .line 1064
    .local v0, "_arg22":Landroid/content/ContentCaptureOptions;
    move-object/from16 v26, v20

    move-object/from16 v20, v24

    .end local v24    # "_arg19":Landroid/os/Bundle;
    .local v20, "_arg19":Landroid/os/Bundle;
    .local v26, "descriptor":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->createLongArray()[J

    move-result-object v24

    .line 1066
    .local v24, "_arg23":[J
    move-object/from16 v27, v22

    move-object/from16 v22, v25

    .end local v25    # "_arg21":Landroid/content/AutofillOptions;
    .local v22, "_arg21":Landroid/content/AutofillOptions;
    .local v27, "cl":Ljava/lang/ClassLoader;
    invoke-virtual {v14}, Landroid/os/Parcel;->createLongArray()[J

    move-result-object v25

    .line 1068
    .local v25, "_arg24":[J
    move-object/from16 v28, v0

    .end local v0    # "_arg22":Landroid/content/ContentCaptureOptions;
    .local v28, "_arg22":Landroid/content/ContentCaptureOptions;
    sget-object v0, Landroid/os/SharedMemory;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/SharedMemory;

    .line 1070
    .local v0, "_arg25":Landroid/os/SharedMemory;
    move-object/from16 v29, v27

    .end local v27    # "cl":Ljava/lang/ClassLoader;
    .local v29, "cl":Ljava/lang/ClassLoader;
    invoke-virtual {v14}, Landroid/os/Parcel;->readRawFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v27

    .line 1072
    .local v27, "_arg26":Ljava/io/FileDescriptor;
    move/from16 v14, v23

    move-object/from16 v23, v28

    move-object/from16 v30, v29

    .end local v28    # "_arg22":Landroid/content/ContentCaptureOptions;
    .end local v29    # "cl":Ljava/lang/ClassLoader;
    .local v14, "_arg13":Z
    .local v23, "_arg22":Landroid/content/ContentCaptureOptions;
    .local v30, "cl":Ljava/lang/ClassLoader;
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v28

    .line 1074
    .local v28, "_arg27":J
    move-object/from16 v33, v30

    .end local v30    # "cl":Ljava/lang/ClassLoader;
    .local v33, "cl":Ljava/lang/ClassLoader;
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v30

    .line 1075
    .local v30, "_arg28":J
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1076
    move-object/from16 v34, v33

    move-object/from16 v33, v26

    move-object/from16 v26, v0

    move-object/from16 v0, p0

    .end local v0    # "_arg25":Landroid/os/SharedMemory;
    .local v26, "_arg25":Landroid/os/SharedMemory;
    .local v33, "descriptor":Ljava/lang/String;
    .local v34, "cl":Ljava/lang/ClassLoader;
    invoke-virtual/range {v0 .. v31}, Landroid/app/IApplicationThread$Stub;->bindApplication(Ljava/lang/String;Landroid/content/pm/ApplicationInfo;Ljava/lang/String;Ljava/lang/String;ZLandroid/content/pm/ProviderInfoList;Landroid/content/ComponentName;Landroid/app/ProfilerInfo;Landroid/os/Bundle;Landroid/app/IInstrumentationWatcher;Landroid/app/IUiAutomationConnection;IZZZZLandroid/content/res/Configuration;Landroid/content/res/CompatibilityInfo;Ljava/util/Map;Landroid/os/Bundle;Ljava/lang/String;Landroid/content/AutofillOptions;Landroid/content/ContentCaptureOptions;[J[JLandroid/os/SharedMemory;Ljava/io/FileDescriptor;JJ)V

    .line 1077
    move-object/from16 v14, p2

    goto/16 :goto_81e

    .line 1009
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/content/pm/ApplicationInfo;
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Z
    .end local v6    # "_arg5":Landroid/content/pm/ProviderInfoList;
    .end local v7    # "_arg6":Landroid/content/ComponentName;
    .end local v8    # "_arg7":Landroid/app/ProfilerInfo;
    .end local v9    # "_arg8":Landroid/os/Bundle;
    .end local v10    # "_arg9":Landroid/app/IInstrumentationWatcher;
    .end local v11    # "_arg10":Landroid/app/IUiAutomationConnection;
    .end local v12    # "_arg11":I
    .end local v13    # "_arg12":Z
    .end local v14    # "_arg13":Z
    .end local v16    # "_arg15":Z
    .end local v17    # "_arg16":Landroid/content/res/Configuration;
    .end local v18    # "_arg17":Landroid/content/res/CompatibilityInfo;
    .end local v19    # "_arg18":Ljava/util/Map;
    .end local v20    # "_arg19":Landroid/os/Bundle;
    .end local v21    # "_arg20":Ljava/lang/String;
    .end local v22    # "_arg21":Landroid/content/AutofillOptions;
    .end local v23    # "_arg22":Landroid/content/ContentCaptureOptions;
    .end local v24    # "_arg23":[J
    .end local v25    # "_arg24":[J
    .end local v26    # "_arg25":Landroid/os/SharedMemory;
    .end local v27    # "_arg26":Ljava/io/FileDescriptor;
    .end local v28    # "_arg27":J
    .end local v30    # "_arg28":J
    .end local v33    # "descriptor":Ljava/lang/String;
    .end local v34    # "cl":Ljava/lang/ClassLoader;
    .local v15, "descriptor":Ljava/lang/String;
    :pswitch_747
    move/from16 v32, v10

    move-object/from16 v33, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .restart local v33    # "descriptor":Ljava/lang/String;
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 1010
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1011
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleStopService(Landroid/os/IBinder;)V

    .line 1012
    move-object/from16 v14, p2

    goto/16 :goto_81e

    .line 995
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v33    # "descriptor":Ljava/lang/String;
    .restart local v15    # "descriptor":Ljava/lang/String;
    :pswitch_759
    move/from16 v32, v10

    move-object/from16 v33, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .restart local v33    # "descriptor":Ljava/lang/String;
    invoke-virtual/range {p2 .. p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 997
    .restart local v1    # "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/content/pm/ServiceInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    move-object/from16 v14, p2

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ServiceInfo;

    .line 999
    .local v2, "_arg1":Landroid/content/pm/ServiceInfo;
    sget-object v3, Landroid/content/res/CompatibilityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/res/CompatibilityInfo;

    .line 1001
    .local v3, "_arg2":Landroid/content/res/CompatibilityInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1002
    .local v4, "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1003
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/IApplicationThread$Stub;->scheduleCreateService(Landroid/os/IBinder;Landroid/content/pm/ServiceInfo;Landroid/content/res/CompatibilityInfo;I)V

    .line 1004
    goto/16 :goto_81e

    .line 969
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/content/pm/ServiceInfo;
    .end local v3    # "_arg2":Landroid/content/res/CompatibilityInfo;
    .end local v4    # "_arg3":I
    .end local v33    # "descriptor":Ljava/lang/String;
    .restart local v15    # "descriptor":Ljava/lang/String;
    :pswitch_77f
    move/from16 v32, v10

    move-object/from16 v33, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .restart local v33    # "descriptor":Ljava/lang/String;
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 971
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/content/pm/ActivityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ActivityInfo;

    .line 973
    .local v2, "_arg1":Landroid/content/pm/ActivityInfo;
    sget-object v3, Landroid/content/res/CompatibilityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/res/CompatibilityInfo;

    .line 975
    .restart local v3    # "_arg2":Landroid/content/res/CompatibilityInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 977
    .restart local v4    # "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 979
    .local v5, "_arg4":Ljava/lang/String;
    sget-object v6, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/os/Bundle;

    .line 981
    .local v6, "_arg5":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v7

    .line 983
    .local v7, "_arg6":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v8

    .line 985
    .local v8, "_arg7":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v9

    .line 987
    .local v9, "_arg8":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v10

    .line 988
    .local v10, "_arg9":I
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 989
    invoke-virtual/range {v0 .. v10}, Landroid/app/IApplicationThread$Stub;->oplusScheduleReceiver(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/content/res/CompatibilityInfo;ILjava/lang/String;Landroid/os/Bundle;ZIII)V

    .line 990
    goto :goto_81e

    .line 961
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/content/pm/ActivityInfo;
    .end local v3    # "_arg2":Landroid/content/res/CompatibilityInfo;
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":Ljava/lang/String;
    .end local v6    # "_arg5":Landroid/os/Bundle;
    .end local v7    # "_arg6":Z
    .end local v8    # "_arg7":I
    .end local v9    # "_arg8":I
    .end local v10    # "_arg9":I
    .end local v33    # "descriptor":Ljava/lang/String;
    .restart local v15    # "descriptor":Ljava/lang/String;
    :pswitch_7c2
    move/from16 v32, v10

    move-object/from16 v33, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .restart local v33    # "descriptor":Ljava/lang/String;
    sget-object v1, Landroid/app/ReceiverInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    .line 962
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/app/ReceiverInfo;>;"
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 963
    invoke-virtual {v0, v1}, Landroid/app/IApplicationThread$Stub;->scheduleReceiverList(Ljava/util/List;)V

    .line 964
    goto :goto_81e

    .line 931
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/app/ReceiverInfo;>;"
    .end local v33    # "descriptor":Ljava/lang/String;
    .restart local v15    # "descriptor":Ljava/lang/String;
    :pswitch_7d3
    move/from16 v32, v10

    move-object/from16 v33, v15

    .end local v15    # "descriptor":Ljava/lang/String;
    .restart local v33    # "descriptor":Ljava/lang/String;
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 933
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/content/pm/ActivityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ActivityInfo;

    .line 935
    .restart local v2    # "_arg1":Landroid/content/pm/ActivityInfo;
    sget-object v3, Landroid/content/res/CompatibilityInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/res/CompatibilityInfo;

    .line 937
    .restart local v3    # "_arg2":Landroid/content/res/CompatibilityInfo;
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 939
    .restart local v4    # "_arg3":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 941
    .restart local v5    # "_arg4":Ljava/lang/String;
    sget-object v6, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v14, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/os/Bundle;

    .line 943
    .restart local v6    # "_arg5":Landroid/os/Bundle;
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v7

    .line 945
    .restart local v7    # "_arg6":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readBoolean()Z

    move-result v8

    .line 947
    .local v8, "_arg7":Z
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v9

    .line 949
    .restart local v9    # "_arg8":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v10

    .line 951
    .restart local v10    # "_arg9":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readInt()I

    move-result v11

    .line 953
    .local v11, "_arg10":I
    invoke-virtual {v14}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v12

    .line 954
    .local v12, "_arg11":Ljava/lang/String;
    invoke-virtual {v14}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 955
    invoke-virtual/range {v0 .. v12}, Landroid/app/IApplicationThread$Stub;->scheduleReceiver(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/content/res/CompatibilityInfo;ILjava/lang/String;Landroid/os/Bundle;ZZIIILjava/lang/String;)V

    .line 956
    nop

    .line 1771
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/content/pm/ActivityInfo;
    .end local v3    # "_arg2":Landroid/content/res/CompatibilityInfo;
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":Ljava/lang/String;
    .end local v6    # "_arg5":Landroid/os/Bundle;
    .end local v7    # "_arg6":Z
    .end local v8    # "_arg7":Z
    .end local v9    # "_arg8":I
    .end local v10    # "_arg9":I
    .end local v11    # "_arg10":I
    .end local v12    # "_arg11":Ljava/lang/String;
    :goto_81e
    return v32

    nop

    :pswitch_data_820
    .packed-switch 0x1
        :pswitch_7d3
        :pswitch_7c2
        :pswitch_77f
        :pswitch_759
        :pswitch_747
        :pswitch_659
        :pswitch_645
        :pswitch_63c
        :pswitch_624
        :pswitch_61b
        :pswitch_612
        :pswitch_5ee
        :pswitch_5d6
        :pswitch_5ba
        :pswitch_56f
        :pswitch_566
        :pswitch_54a
        :pswitch_53a
        :pswitch_51a
        :pswitch_502
        :pswitch_4ea
        :pswitch_4e1
        :pswitch_4cd
        :pswitch_4b1
        :pswitch_481
        :pswitch_461
        :pswitch_445
        :pswitch_43c
        :pswitch_433
        :pswitch_41f
        :pswitch_407
        :pswitch_3f7
        :pswitch_3bb
        :pswitch_38b
        :pswitch_373
        :pswitch_35b
        :pswitch_33f
        :pswitch_327
        :pswitch_317
        :pswitch_2f7
        :pswitch_2e3
        :pswitch_2d3
        :pswitch_2bf
        :pswitch_2af
        :pswitch_29f
        :pswitch_28f
        :pswitch_286
        :pswitch_272
        :pswitch_25a
        :pswitch_251
        :pswitch_241
        :pswitch_231
        :pswitch_21d
        :pswitch_20d
        :pswitch_1f9
        :pswitch_1dd
        :pswitch_1b5
        :pswitch_189
        :pswitch_179
        :pswitch_170
        :pswitch_160
        :pswitch_150
        :pswitch_140
        :pswitch_130
        :pswitch_110
        :pswitch_d7
        :pswitch_a5
        :pswitch_91
        :pswitch_79
        :pswitch_65
        :pswitch_5c
        :pswitch_40
        :pswitch_28
    .end packed-switch
.end method
