.class public interface abstract Lcom/android/internal/os/IRuntimeInitExt;
.super Ljava/lang/Object;
.source "IRuntimeInitExt.java"


# virtual methods
.method public blacklist collectHeapdump(Ljava/lang/Throwable;)V
    .registers 2
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 30
    return-void
.end method

.method public blacklist uncaughtExceptionExt(Ljava/lang/Thread;Ljava/lang/Throwable;Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .registers 4
    .param p1, "t"    # Ljava/lang/Thread;
    .param p2, "e"    # Ljava/lang/Throwable;
    .param p3, "eh"    # Ljava/lang/Thread$UncaughtExceptionHandler;

    .line 25
    return-void
.end method
