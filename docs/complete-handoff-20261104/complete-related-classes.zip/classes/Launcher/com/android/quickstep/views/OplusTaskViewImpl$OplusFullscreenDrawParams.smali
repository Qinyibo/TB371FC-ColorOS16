.class public final Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;
.super Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/quickstep/views/OplusTaskViewImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "OplusFullscreenDrawParams"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u000b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005JA\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\u000c2\u0008\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0016\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\r\u0010\u0013\u001a\u00020\u0010\u00a2\u0006\u0004\u0008\u0013\u0010\u0014R\u0014\u0010\u0015\u001a\u00020\u00068\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0015\u0010\u0016R\u0016\u0010\u0018\u001a\u00020\u00178\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0018\u0010\u0019R\u001b\u0010\u001e\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u001a\u0010\u001b\u001a\u0004\u0008\u001c\u0010\u001dR\u001b\u0010!\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u001f\u0010\u001b\u001a\u0004\u0008 \u0010\u001d\u00a8\u0006\""
    }
    d2 = {
        "Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;",
        "Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;",
        "Landroid/content/Context;",
        "context",
        "<init>",
        "(Landroid/content/Context;)V",
        "",
        "fullscreenProgress",
        "parentScale",
        "taskViewScale",
        "",
        "previewWidth",
        "Lcom/android/launcher3/DeviceProfile;",
        "dp",
        "Lcom/android/quickstep/views/TaskThumbnailView$PreviewPositionHelper;",
        "pph",
        "Lq5/b0;",
        "setProgress",
        "(FFFILcom/android/launcher3/DeviceProfile;Lcom/android/quickstep/views/TaskThumbnailView$PreviewPositionHelper;)V",
        "forceUseSplitScreenCornerRadius",
        "()V",
        "splitScreenWindowCornerRadius",
        "F",
        "",
        "forceUseSplitScreenWindowCornerRadius",
        "Z",
        "mTabletCornerRaduius$delegate",
        "Lq5/g;",
        "getMTabletCornerRaduius",
        "()F",
        "mTabletCornerRaduius",
        "mFoldExpandCornerRadius$delegate",
        "getMFoldExpandCornerRadius",
        "mFoldExpandCornerRadius",
        "OplusLauncher_OPPOPallDomesticAallRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private forceUseSplitScreenWindowCornerRadius:Z

.field private final mFoldExpandCornerRadius$delegate:Lq5/g;

.field private final mTabletCornerRaduius$delegate:Lq5/g;

.field private final splitScreenWindowCornerRadius:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mCornerRadius:F

    sget-object v1, Lcom/oplus/quickstep/utils/RoundCornerLoader;->INSTANCE:Lcom/oplus/quickstep/utils/RoundCornerLoader$INSTANCE;

    invoke-virtual {v1, p1}, Lcom/oplus/quickstep/utils/RoundCornerLoader$INSTANCE;->get(Landroid/content/Context;)Lcom/oplus/quickstep/utils/RoundCornerLoader;

    move-result-object v2

    invoke-virtual {v2}, Lcom/oplus/quickstep/utils/RoundCornerLoader;->getScreenRoundCornerRadiusPx()I

    move-result v2

    int-to-float v2, v2

    iput v2, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mWindowCornerRadius:F

    invoke-virtual {v1, p1}, Lcom/oplus/quickstep/utils/RoundCornerLoader$INSTANCE;->get(Landroid/content/Context;)Lcom/oplus/quickstep/utils/RoundCornerLoader;

    move-result-object p1

    invoke-virtual {p1}, Lcom/oplus/quickstep/utils/RoundCornerLoader;->getSplitScreenWindowRoundCornerRadiusPx()I

    move-result p1

    int-to-float p1, p1

    iput p1, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->splitScreenWindowCornerRadius:F

    iput v0, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mCurrentDrawnCornerRadius:F

    sget-object p1, Lq5/h;->c:Lq5/h;

    sget-object v0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams$mTabletCornerRaduius$2;->INSTANCE:Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams$mTabletCornerRaduius$2;

    invoke-static {p1, v0}, Lcom/heytap/nearx/protobuff/wire/e;->b(Lq5/h;Lkotlin/jvm/functions/Function0;)Lq5/g;

    move-result-object v0

    iput-object v0, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->mTabletCornerRaduius$delegate:Lq5/g;

    sget-object v0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams$mFoldExpandCornerRadius$2;->INSTANCE:Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams$mFoldExpandCornerRadius$2;

    invoke-static {p1, v0}, Lcom/heytap/nearx/protobuff/wire/e;->b(Lq5/h;Lkotlin/jvm/functions/Function0;)Lq5/g;

    move-result-object p1

    iput-object p1, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->mFoldExpandCornerRadius$delegate:Lq5/g;

    return-void
.end method

.method private final getMFoldExpandCornerRadius()F
    .registers 1

    iget-object p0, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->mFoldExpandCornerRadius$delegate:Lq5/g;

    invoke-interface {p0}, Lq5/g;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method

.method private final getMTabletCornerRaduius()F
    .registers 1

    iget-object p0, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->mTabletCornerRaduius$delegate:Lq5/g;

    invoke-interface {p0}, Lq5/g;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method


# virtual methods
.method public final forceUseSplitScreenCornerRadius()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->forceUseSplitScreenWindowCornerRadius:Z

    return-void
.end method

.method public setProgress(FFFILcom/android/launcher3/DeviceProfile;Lcom/android/quickstep/views/TaskThumbnailView$PreviewPositionHelper;)V
    .registers 13

    const-string v0, "dp"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super/range {p0 .. p6}, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->setProgress(FFFILcom/android/launcher3/DeviceProfile;Lcom/android/quickstep/views/TaskThumbnailView$PreviewPositionHelper;)V

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->isStartAndEndEqual()Z

    move-result p3

    if-eqz p3, :cond_13

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getTaskViewWeight()F

    move-result p3

    goto :goto_3d

    :cond_13
    sget-boolean p3, Lcom/android/quickstep/views/OplusTaskViewImpl;->sIsTaskViewLaunchWithoutDrag:Z

    const p4, 0x3f8ccccd    # 1.1f

    if-eqz p3, :cond_35

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getNonWindowWeight()F

    move-result v4

    sget-object v5, Lcom/android/launcher3/anim/Interpolators;->LINEAR:Landroid/view/animation/Interpolator;

    const/4 v1, 0x0

    const v2, 0x3dcccccd    # 0.1f

    const v3, 0x3f8ccccd    # 1.1f

    move v0, p1

    invoke-static/range {v0 .. v5}, Lcom/android/launcher3/Utilities;->mapToRange(FFFFFLandroid/view/animation/Interpolator;)F

    move-result p3

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getNonWindowWeight()F

    move-result p6

    invoke-static {p3, p4, p6}, Lcom/android/launcher3/Utilities;->boundToRange(FFF)F

    move-result p3

    goto :goto_3d

    :cond_35
    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getFullWindowWeight()F

    move-result p3

    invoke-static {p1, p4, p3}, Lcom/android/launcher3/Utilities;->mapRange(FFF)F

    move-result p3

    :goto_3d
    iput p3, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mCurrentTaskViewWeight:F

    invoke-virtual {p5}, Lcom/android/launcher3/DeviceProfile;->config()Lcom/android/launcher/layoutparam/ConfigParam;

    move-result-object p3

    invoke-virtual {p3}, Lcom/android/launcher/layoutparam/ConfigParam;->isMultiWindowMode()Z

    move-result p3

    if-eqz p3, :cond_51

    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isFoldScreenExpanded()Z

    move-result p3

    if-nez p3, :cond_51

    const/4 p3, 0x0

    goto :goto_53

    :cond_51
    iget p3, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mWindowCornerRadius:F

    :goto_53
    invoke-static {}, Lcom/android/common/util/AppFeatureUtils;->isTablet()Z

    move-result p4

    if-eqz p4, :cond_65

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getTaskViewRadius()F

    move-result p4

    invoke-static {p1, p4, p3}, Lcom/android/launcher3/Utilities;->mapRange(FFF)F

    move-result p1

    div-float/2addr p1, p2

    iput p1, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mCurrentDrawnCornerRadius:F

    return-void

    :cond_65
    const p4, 0x3f7d70a4    # 0.99f

    cmpl-float p4, p1, p4

    if-gtz p4, :cond_7c

    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isFoldScreenExpanded()Z

    move-result p4

    if-eqz p4, :cond_7a

    const p4, 0x3f4ccccd    # 0.8f

    cmpl-float p4, p1, p4

    if-lez p4, :cond_7a

    goto :goto_7c

    :cond_7a
    const/4 p4, 0x0

    goto :goto_7d

    :cond_7c
    :goto_7c
    const/4 p4, 0x1

    :goto_7d
    iget-boolean p5, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->forceUseSplitScreenWindowCornerRadius:Z

    if-eqz p5, :cond_a1

    if-eqz p4, :cond_a1

    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isFoldScreenExpanded()Z

    move-result p4

    if-eqz p4, :cond_9f

    const/high16 v4, 0x3f800000    # 1.0f

    sget-object v5, Lcom/android/launcher3/anim/Interpolators;->LINEAR:Landroid/view/animation/Interpolator;

    const v1, 0x3f4ccccd    # 0.8f

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move v0, p1

    invoke-static/range {v0 .. v5}, Lcom/android/launcher3/Utilities;->mapBoundToRange(FFFFFLandroid/view/animation/Interpolator;)F

    move-result p4

    iget p5, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->splitScreenWindowCornerRadius:F

    invoke-static {p4, p3, p5}, Lcom/android/launcher3/Utilities;->mapRange(FFF)F

    move-result p3

    goto :goto_a1

    :cond_9f
    iget p3, p0, Lcom/android/quickstep/views/OplusTaskViewImpl$OplusFullscreenDrawParams;->splitScreenWindowCornerRadius:F

    :cond_a1
    :goto_a1
    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isFoldScreenExpanded()Z

    move-result p4

    if-eqz p4, :cond_ac

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getTaskViewRadius()F

    move-result p4

    goto :goto_b1

    :cond_ac
    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getTaskViewRadius()F

    move-result p4

    mul-float/2addr p4, p2

    :goto_b1
    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->isStartAndEndEqual()Z

    move-result p5

    if-eqz p5, :cond_bc

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getTaskViewRadius()F

    move-result p1

    goto :goto_ca

    :cond_bc
    sget-boolean p5, Lcom/android/quickstep/views/OplusTaskViewImpl;->sIsTaskViewLaunchWithoutDrag:Z

    if-nez p5, :cond_c5

    invoke-static {}, Lcom/android/launcher3/util/SmoothRoundedManager;->getFullWindowRadiusRatio()F

    move-result p5

    mul-float/2addr p3, p5

    :cond_c5
    invoke-static {p1, p4, p3}, Lcom/android/launcher3/Utilities;->mapRange(FFF)F

    move-result p1

    div-float/2addr p1, p2

    :goto_ca
    iput p1, p0, Lcom/android/quickstep/views/TaskView$FullscreenDrawParams;->mCurrentDrawnCornerRadius:F

    return-void
.end method
