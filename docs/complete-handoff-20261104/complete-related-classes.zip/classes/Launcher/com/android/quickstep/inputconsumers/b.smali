.class public final synthetic Lcom/android/quickstep/inputconsumers/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(ILandroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/quickstep/inputconsumers/b;->a:I

    iput-object p2, p0, Lcom/android/quickstep/inputconsumers/b;->b:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/android/quickstep/inputconsumers/b;->a:I

    iget-object p0, p0, Lcom/android/quickstep/inputconsumers/b;->b:Landroid/content/Context;

    invoke-static {v0, p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->a(ILandroid/content/Context;)V

    return-void
.end method
