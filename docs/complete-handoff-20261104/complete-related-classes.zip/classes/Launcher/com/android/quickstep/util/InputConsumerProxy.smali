.class public Lcom/android/quickstep/util/InputConsumerProxy;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final TAG:Ljava/lang/String; = "InputConsumerProxy"

.field private static sInstanceHolder:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/android/quickstep/util/InputConsumerProxy;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mCallback:Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;"
        }
    .end annotation
.end field

.field private mConsumerSupplier:Ljava/util/function/Supplier;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Supplier<",
            "Lcom/android/quickstep/InputConsumer;",
            ">;"
        }
    .end annotation
.end field

.field private final mContext:Landroid/content/Context;

.field private mDestroyPending:Z

.field private mDestroyed:Z

.field private mInputConsumer:Lcom/android/quickstep/InputConsumer;

.field private final mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

.field private mKeyEventCallback:Ljava/util/function/Consumer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;"
        }
    .end annotation
.end field

.field private mLastOrientationRectRotation:I

.field private mNonDownMotionEventConsumer:Lcom/android/quickstep/InputConsumer;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private mRotationSupplier:Ljava/util/function/Supplier;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/function/Supplier<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mTaskAnimationManager:Lcom/android/quickstep/TaskAnimationManager;

.field private mTouchInProgress:Z


# direct methods
.method private constructor <init>(Landroid/content/Context;Ljava/util/function/Supplier;Lcom/android/systemui/shared/system/InputConsumerController;Ljava/util/function/Consumer;Ljava/util/function/Consumer;Ljava/util/function/Supplier;Lcom/android/quickstep/TaskAnimationManager;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/function/Supplier<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/android/systemui/shared/system/InputConsumerController;",
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;",
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;",
            "Ljava/util/function/Supplier<",
            "Lcom/android/quickstep/InputConsumer;",
            ">;",
            "Lcom/android/quickstep/TaskAnimationManager;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyed:Z

    iput-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    iput-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    iput v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mLastOrientationRectRotation:I

    iput-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    iput-object p2, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mRotationSupplier:Ljava/util/function/Supplier;

    iput-object p3, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    iput-object p4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mCallback:Ljava/util/function/Consumer;

    iput-object p5, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mKeyEventCallback:Ljava/util/function/Consumer;

    iput-object p6, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mConsumerSupplier:Ljava/util/function/Supplier;

    iput-object p7, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTaskAnimationManager:Lcom/android/quickstep/TaskAnimationManager;

    return-void
.end method

.method public static synthetic a(Lcom/android/quickstep/util/InputConsumerProxy;Landroid/view/InputEvent;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->onInputConsumerEvent(Landroid/view/InputEvent;)Z

    move-result p0

    return p0
.end method

.method public static createInstance(Landroid/content/Context;Ljava/util/function/Supplier;Lcom/android/systemui/shared/system/InputConsumerController;Ljava/util/function/Consumer;Ljava/util/function/Consumer;Ljava/util/function/Supplier;Lcom/android/quickstep/TaskAnimationManager;)Lcom/android/quickstep/util/InputConsumerProxy;
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/function/Supplier<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/android/systemui/shared/system/InputConsumerController;",
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;",
            "Ljava/util/function/Consumer<",
            "Landroid/view/InputEvent;",
            ">;",
            "Ljava/util/function/Supplier<",
            "Lcom/android/quickstep/InputConsumer;",
            ">;",
            "Lcom/android/quickstep/TaskAnimationManager;",
            ")",
            "Lcom/android/quickstep/util/InputConsumerProxy;"
        }
    .end annotation

    new-instance v8, Lcom/android/quickstep/util/InputConsumerProxy;

    move-object v0, v8

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object v7, p6

    invoke-direct/range {v0 .. v7}, Lcom/android/quickstep/util/InputConsumerProxy;-><init>(Landroid/content/Context;Ljava/util/function/Supplier;Lcom/android/systemui/shared/system/InputConsumerController;Ljava/util/function/Consumer;Ljava/util/function/Consumer;Ljava/util/function/Supplier;Lcom/android/quickstep/TaskAnimationManager;)V

    new-instance p0, Ljava/lang/ref/WeakReference;

    invoke-direct {p0, v8}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object p0, Lcom/android/quickstep/util/InputConsumerProxy;->sInstanceHolder:Ljava/lang/ref/WeakReference;

    return-object v8
.end method

.method public static getInstance()Lcom/android/quickstep/util/InputConsumerProxy;
    .registers 1

    sget-object v0, Lcom/android/quickstep/util/InputConsumerProxy;->sInstanceHolder:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/quickstep/util/InputConsumerProxy;

    return-object v0

    :cond_b
    const/4 v0, 0x0

    return-object v0
.end method

.method private getRotation()I
    .registers 4

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mRotationSupplier:Ljava/util/function/Supplier;

    if-eqz v0, :cond_f

    invoke-interface {v0}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    :cond_f
    sget-object v0, Lcom/android/launcher3/util/DisplayController;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    iget-object v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/launcher3/util/DisplayController;

    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p0}, Lcom/android/launcher3/util/DisplayController;->getInfo(Landroid/content/Context;)Lcom/android/launcher3/util/DisplayController$Info;

    move-result-object p0

    iget p0, p0, Lcom/android/launcher3/util/DisplayController$Info;->rotation:I

    invoke-static {}, Lcom/oplus/basecommon/log/LogUtils;->isLoggableDebug()Z

    move-result v0

    if-eqz v0, :cond_35

    const-string v0, "getRotation rotation:"

    const-string v1, "getCallers:"

    invoke-static {p0, v0, v1}, Landroidx/appcompat/widget/e;->a(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/4 v1, 0x7

    const-string v2, "InputConsumerProxy"

    invoke-static {v0, v1, v2}, Lcom/android/common/util/j;->a(Ljava/lang/StringBuilder;ILjava/lang/String;)V

    :cond_35
    return p0
.end method

.method private initInputConsumerIfNeeded(Landroid/view/InputEvent;)V
    .registers 3

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    if-nez v0, :cond_24

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mCallback:Ljava/util/function/Consumer;

    if-eqz v0, :cond_b

    invoke-interface {v0, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_b
    iget-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mConsumerSupplier:Ljava/util/function/Supplier;

    if-eqz p1, :cond_18

    invoke-interface {p1}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/quickstep/InputConsumer;

    iput-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    goto :goto_20

    :cond_18
    const-string p1, "InputConsumerProxy"

    const-string/jumbo v0, "mConsumerSupplier is null"

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :goto_20
    const/4 p1, 0x0

    iput-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mConsumerSupplier:Ljava/util/function/Supplier;

    goto :goto_2b

    :cond_24
    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mKeyEventCallback:Ljava/util/function/Consumer;

    if-eqz p0, :cond_2b

    invoke-interface {p0, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_2b
    :goto_2b
    return-void
.end method

.method private onInputConsumerEvent(Landroid/view/InputEvent;)Z
    .registers 7

    instance-of v0, p1, Landroid/view/MotionEvent;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_63

    check-cast p1, Landroid/view/MotionEvent;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/16 v3, 0x9

    const-string v4, "InputConsumerProxy"

    if-eq v0, v3, :cond_48

    const/4 v3, 0x7

    if-eq v0, v3, :cond_48

    const/16 v3, 0xa

    if-ne v0, v3, :cond_1a

    goto :goto_48

    :cond_1a
    if-eqz v0, :cond_23

    if-eq v0, v1, :cond_23

    const/4 v3, 0x3

    if-ne v0, v3, :cond_22

    goto :goto_23

    :cond_22
    move v1, v2

    :cond_23
    :goto_23
    sget-object v0, Lcom/oplus/quickstep/gesture/helper/SystemAutoRotateHelper;->INSTANCE:Lcom/oplus/quickstep/gesture/helper/SystemAutoRotateHelper$INSTANCE;

    invoke-virtual {v0}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/oplus/quickstep/gesture/helper/SystemAutoRotateHelper;

    invoke-virtual {v0, v1}, Lcom/oplus/quickstep/gesture/helper/SystemAutoRotateHelper;->shouldInterceptInput(Z)Z

    move-result v0

    if-eqz v0, :cond_44

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTaskAnimationManager:Lcom/android/quickstep/TaskAnimationManager;

    if-eqz v0, :cond_44

    invoke-virtual {v0}, Lcom/android/quickstep/TaskAnimationManager;->isRecentsAnimationRunning()Z

    move-result v0

    if-eqz v0, :cond_44

    if-eqz v1, :cond_43

    const-string/jumbo p0, "intercept touch when landscape app swipe to recent"

    invoke-static {v4, p0}, Lcom/oplus/basecommon/log/LogUtils;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_43
    return v2

    :cond_44
    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->onInputConsumerMotionEvent(Landroid/view/MotionEvent;)Z

    goto :goto_74

    :cond_48
    :goto_48
    invoke-static {}, Lcom/android/common/util/AppFeatureUtils;->isTablet()Z

    move-result v0

    if-eqz v0, :cond_5f

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTaskAnimationManager:Lcom/android/quickstep/TaskAnimationManager;

    if-eqz v0, :cond_5f

    invoke-virtual {v0}, Lcom/android/quickstep/TaskAnimationManager;->isRecentsAnimationRunning()Z

    move-result v0

    if-eqz v0, :cond_5f

    const-string/jumbo p0, "recent animation is running, do not consume the hover event."

    invoke-static {v4, p0}, Lcom/oplus/basecommon/log/LogUtils;->d(Ljava/lang/String;Ljava/lang/String;)V

    return v2

    :cond_5f
    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->onInputConsumerHoverEvent(Landroid/view/MotionEvent;)V

    goto :goto_74

    :cond_63
    instance-of v0, p1, Landroid/view/KeyEvent;

    if-eqz v0, :cond_74

    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->initInputConsumerIfNeeded(Landroid/view/InputEvent;)V

    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    if-eqz p0, :cond_73

    check-cast p1, Landroid/view/KeyEvent;

    invoke-interface {p0, p1}, Lcom/android/quickstep/InputConsumer;->onKeyEvent(Landroid/view/KeyEvent;)V

    :cond_73
    return v1

    :cond_74
    :goto_74
    return v2
.end method

.method private onInputConsumerHoverEvent(Landroid/view/MotionEvent;)V
    .registers 4

    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->initInputConsumerIfNeeded(Landroid/view/InputEvent;)V

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    if-eqz v0, :cond_1d

    sget-object v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    iget-object v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;

    invoke-direct {p0}, Lcom/android/quickstep/util/InputConsumerProxy;->getRotation()I

    move-result v1

    invoke-virtual {v0, p1, v1}, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->transform(Landroid/view/MotionEvent;I)V

    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    invoke-interface {p0, p1}, Lcom/android/quickstep/InputConsumer;->onHoverEvent(Landroid/view/MotionEvent;)V

    :cond_1d
    return-void
.end method

.method private onInputConsumerMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 8

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    iget-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    const/4 v2, 0x0

    const-string v3, "InputConsumerProxy"

    if-nez v1, :cond_1a

    if-eqz v0, :cond_1a

    const-string v1, "Received non-down motion before down motion: "

    invoke-static {v0, v1, v3}, Landroidx/appcompat/view/menu/a;->c(ILjava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mNonDownMotionEventConsumer:Lcom/android/quickstep/InputConsumer;

    if-eqz p0, :cond_19

    invoke-interface {p0, p1}, Lcom/android/quickstep/InputConsumer;->onMotionEvent(Landroid/view/MotionEvent;)V

    :cond_19
    return v2

    :cond_1a
    if-eqz v1, :cond_24

    if-nez v0, :cond_24

    const-string p0, "Received down motion while touch was already in progress"

    invoke-static {v3, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v2

    :cond_24
    const/4 v1, 0x1

    if-nez v0, :cond_82

    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {v0}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->removeDelayRunnable()Z

    move-result v0

    if-eqz v0, :cond_39

    const-string/jumbo v0, "onInputConsumerMotionEvent(), removeDelayRunnable"

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    :cond_39
    sget-object v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    iget-object v4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v4}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/quickstep/SimpleOrientationTouchTransformer;

    invoke-virtual {v4}, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->updateLastOrientationRectF()V

    iget-object v4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v4}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;

    invoke-virtual {v0}, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->getOrientationRectRotation()I

    move-result v0

    iput v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mLastOrientationRectRotation:I

    invoke-direct {p0, p1}, Lcom/android/quickstep/util/InputConsumerProxy;->initInputConsumerIfNeeded(Landroid/view/InputEvent;)V

    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    if-eqz v0, :cond_6e

    instance-of v4, v0, Lcom/android/quickstep/inputconsumers/OverviewInputConsumer;

    if-eqz v4, :cond_6e

    check-cast v0, Lcom/android/quickstep/inputconsumers/OverviewInputConsumer;

    invoke-virtual {v0}, Lcom/android/quickstep/inputconsumers/OverviewInputConsumer;->getTarget()Lcom/android/launcher3/views/BaseDragLayer;

    move-result-object v0

    iget-object v4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {v4}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->getSideBarRegion()Landroid/graphics/Rect;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/android/launcher3/views/BaseDragLayer;->updateSideBarSceneRegion(Landroid/graphics/Rect;)V

    :cond_6e
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "InputConsumerProxy#onInputConsumerMotionEvent mInputConsumer DOWN: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_a3

    :cond_82
    const/4 v4, 0x3

    if-eq v0, v4, :cond_87

    if-ne v0, v1, :cond_a3

    :cond_87
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "InputConsumerProxy#onInputConsumerMotionEvent mInputConsumer UP || CANCEL: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iput-boolean v2, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    iget-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    if-eqz v0, :cond_a3

    invoke-virtual {p0}, Lcom/android/quickstep/util/InputConsumerProxy;->destroy()V

    :cond_a3
    :goto_a3
    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    if-eqz v0, :cond_e1

    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isTablet()Z

    move-result v0

    if-nez v0, :cond_dc

    sget-object v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    iget-object v3, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v3}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/quickstep/SimpleOrientationTouchTransformer;

    invoke-virtual {v3}, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->getOrientationRectRotation()I

    move-result v3

    invoke-direct {p0}, Lcom/android/quickstep/util/InputConsumerProxy;->getRotation()I

    move-result v4

    invoke-static {}, Lcom/android/common/util/ScreenUtils;->isFoldScreenExpanded()Z

    move-result v5

    if-eqz v5, :cond_c6

    move v3, v4

    :cond_c6
    iget v5, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mLastOrientationRectRotation:I

    if-eq v5, v3, :cond_d1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSurfaceRotation()I

    move-result v5

    if-eq v5, v3, :cond_d1

    move v2, v1

    :cond_d1
    iget-object v3, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v3}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/quickstep/SimpleOrientationTouchTransformer;

    invoke-virtual {v0, p1, v4, v2}, Lcom/android/quickstep/SimpleOrientationTouchTransformer;->transform(Landroid/view/MotionEvent;IZ)V

    :cond_dc
    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumer:Lcom/android/quickstep/InputConsumer;

    invoke-interface {p0, p1}, Lcom/android/quickstep/InputConsumer;->onMotionEvent(Landroid/view/MotionEvent;)V

    :cond_e1
    return v1
.end method


# virtual methods
.method public destroy()V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    .line 2
    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    return-void

    :cond_8
    const/4 v0, 0x0

    .line 3
    iput-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    .line 4
    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyed:Z

    .line 5
    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setInputListener(Lcom/android/systemui/shared/system/InputConsumerController$InputListener;)V

    .line 6
    iget-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {v0, v1}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setRecentsAnimationInputConsumerCallback(Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController$RecentsAnimationInputConsumerCallback;)V

    .line 7
    iput-object v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mRotationSupplier:Ljava/util/function/Supplier;

    return-void
.end method

.method public destroy(Z)V
    .registers 4

    .line 8
    iget-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mTouchInProgress:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    .line 9
    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    return-void

    :cond_8
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyPending:Z

    .line 11
    iput-boolean v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyed:Z

    if-eqz p1, :cond_15

    .line 12
    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {p0}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->delayRemoveListener()V

    goto :goto_1b

    .line 13
    :cond_15
    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setInputListener(Lcom/android/systemui/shared/system/InputConsumerController$InputListener;)V

    :goto_1b
    return-void
.end method

.method public disable()V
    .registers 2

    iget-boolean v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyed:Z

    if-eqz v0, :cond_c

    const-string p0, "InputConsumerProxy"

    const-string v0, "disable fails due to already destroyed"

    invoke-static {p0, v0}, Lcom/oplus/basecommon/log/LogUtils;->i(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_c
    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setInputListener(Lcom/android/systemui/shared/system/InputConsumerController$InputListener;)V

    return-void
.end method

.method public enable(Z)V
    .registers 3

    if-nez p1, :cond_e

    iget-boolean p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mDestroyed:Z

    if-eqz p1, :cond_e

    const-string p0, "InputConsumerProxy"

    const-string p1, "enable fails due to already destroyed"

    invoke-static {p0, p1}, Lcom/oplus/basecommon/log/LogUtils;->i(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_e
    iget-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    new-instance v0, Lcom/android/launcher3/card/b;

    invoke-direct {v0, p0}, Lcom/android/launcher3/card/b;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p1, v0}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setInputListener(Lcom/android/systemui/shared/system/InputConsumerController$InputListener;)V

    return-void
.end method

.method public setNonDownMotionEventConsumer(Lcom/android/quickstep/InputConsumer;)V
    .registers 2
    .param p1    # Lcom/android/quickstep/InputConsumer;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    iput-object p1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mNonDownMotionEventConsumer:Lcom/android/quickstep/InputConsumer;

    return-void
.end method

.method public setRecentsAnimationInputConsumerCallback(Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController$RecentsAnimationInputConsumerCallback;)V
    .registers 2

    iget-object p0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {p0, p1}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setRecentsAnimationInputConsumerCallback(Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController$RecentsAnimationInputConsumerCallback;)V

    return-void
.end method

.method public unregisterCallback()V
    .registers 3

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mCallback:Ljava/util/function/Consumer;

    iget-object v1, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mInputConsumerController:Lcom/android/systemui/shared/system/InputConsumerController;

    invoke-virtual {v1, v0}, Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController;->setRecentsAnimationInputConsumerCallback(Lcom/oplus/systemui/shared/system/OplusBaseInputConsumerController$RecentsAnimationInputConsumerCallback;)V

    iput-object v0, p0, Lcom/android/quickstep/util/InputConsumerProxy;->mKeyEventCallback:Ljava/util/function/Consumer;

    return-void
.end method
