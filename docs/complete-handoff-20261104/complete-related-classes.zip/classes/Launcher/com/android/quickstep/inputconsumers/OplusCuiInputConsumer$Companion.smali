.class public final Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0013\n\u0002\u0010\t\n\u0002\u0008\u0004\n\u0002\u0010\u000e\n\u0002\u0008\u000f\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\'\u0010\n\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\'\u0010\u000e\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u001f\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u001f\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008\u0016\u0010\u0015J-\u0010\u0019\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u00062\u0006\u0010\u0018\u001a\u00020\u0017\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u001d\u0010\u001b\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u001b\u0010\u0015J\r\u0010\u001c\u001a\u00020\t\u00a2\u0006\u0004\u0008\u001c\u0010\u001dR\u001b\u0010\"\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u001e\u0010\u001f\u001a\u0004\u0008 \u0010!R\"\u0010#\u001a\u00020\t8\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008#\u0010$\u001a\u0004\u0008%\u0010\u001d\"\u0004\u0008&\u0010\'R\u0014\u0010(\u001a\u00020\u00068\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008(\u0010)R\u0014\u0010*\u001a\u00020\u00068\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008*\u0010)R\u0014\u0010,\u001a\u00020+8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008,\u0010-R\u0014\u0010.\u001a\u00020\u000c8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008.\u0010/R\u0014\u00101\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00081\u00102R\u0014\u00103\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00083\u00102R\u0014\u00104\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00084\u00102R\u0014\u00105\u001a\u00020\u00068\u0006X\u0086T\u00a2\u0006\u0006\n\u0004\u00085\u0010)R\u0014\u00106\u001a\u00020\u00068\u0006X\u0086T\u00a2\u0006\u0006\n\u0004\u00086\u0010)R\u0014\u00107\u001a\u00020\u00068\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00087\u0010)R\u0014\u00108\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00088\u00102R\u0014\u00109\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u00089\u00102R\u0014\u0010:\u001a\u0002008\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008:\u00102R\u0016\u0010;\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008;\u0010)R\u0016\u0010<\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008<\u0010)R\u0016\u0010=\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008=\u0010)R\u0016\u0010>\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008>\u0010)\u00a8\u0006?"
    }
    d2 = {
        "Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;",
        "",
        "<init>",
        "()V",
        "Landroid/view/MotionEvent;",
        "ev",
        "",
        "rotation",
        "density",
        "",
        "isInCuiTouchRegion",
        "(Landroid/view/MotionEvent;II)Z",
        "",
        "defaultValue",
        "updateGestureBarWidth",
        "(FII)I",
        "Landroid/content/Context;",
        "context",
        "type",
        "Lq5/b0;",
        "startBreenoService",
        "(Landroid/content/Context;I)V",
        "startCircleToSearch",
        "Lcom/android/quickstep/RecentsAnimationDeviceState;",
        "deviceState",
        "canTriggerCui",
        "(Landroid/view/MotionEvent;IILcom/android/quickstep/RecentsAnimationDeviceState;)Z",
        "startService",
        "isCUISupport",
        "()Z",
        "systemUICompatVersion$delegate",
        "Lq5/g;",
        "getSystemUICompatVersion",
        "()I",
        "systemUICompatVersion",
        "mSystemUiLongPressed",
        "Z",
        "getMSystemUiLongPressed",
        "setMSystemUiLongPressed",
        "(Z)V",
        "INVOCATION_TYPE_CIRCLE_TO_SEARCH_TASKBAR_BUTTON_CLICK",
        "I",
        "INVOCATION_TYPE_NAV_HANDLE_LONG_PRESS",
        "",
        "KEYGUARD_SHOWING_SYSUI_FLAGS",
        "J",
        "MOVE_THRESHOLD",
        "F",
        "",
        "NAME_TYPE_CUI",
        "Ljava/lang/String;",
        "RESOURCE_NAVI_WIDTH",
        "RESOURCE_NAVI_WIDTH_LANDSCAPE",
        "START_TYPE_CLICK",
        "START_TYPE_LONG_PRESS",
        "SYSTEM_UI_CUI_COMPAT_VERSION",
        "SYSTEM_UI_CUI_FEATURE",
        "SYSTEM_UI_PACKAGE_NAME",
        "TAG",
        "lastDensity",
        "lastDisplayRotation",
        "lastDisplayWidth",
        "lastGestureWidth",
        "OplusLauncher_OPPOPallDomesticAallRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;-><init>()V

    return-void
.end method

.method public static synthetic a(ILandroid/content/Context;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->startCircleToSearch$lambda$4(ILandroid/content/Context;)V

    return-void
.end method

.method private final getSystemUICompatVersion()I
    .registers 1

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getSystemUICompatVersion$delegate$cp()Lq5/g;

    move-result-object p0

    invoke-interface {p0}, Lq5/g;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method private final isInCuiTouchRegion(Landroid/view/MotionEvent;II)Z
    .registers 8

    sget-object v0, Lcom/android/launcher3/util/DisplayController;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    invoke-static {}, Lcom/android/common/LauncherApplication;->getAppContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/launcher3/util/DisplayController;

    invoke-virtual {v0}, Lcom/android/launcher3/util/DisplayController;->getInfo()Lcom/android/launcher3/util/DisplayController$Info;

    move-result-object v0

    iget-object v0, v0, Lcom/android/launcher3/util/DisplayController$Info;->currentSize:Landroid/graphics/Point;

    iget v0, v0, Landroid/graphics/Point;->x:I

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastGestureWidth$cp()I

    move-result v1

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarStateUtils;->isTaskbarPresent()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_33

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object p0

    if-eqz p0, :cond_31

    invoke-virtual {p0}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->getStashedHandleController()Lcom/android/launcher3/taskbar/stashedhandleview/OplusStashedHandleViewController;

    move-result-object p0

    if-eqz p0, :cond_31

    invoke-virtual {p0}, Lcom/android/launcher3/taskbar/StashedHandleViewController;->getStashedHandleWidth()I

    move-result p0

    move v1, p0

    goto :goto_57

    :cond_31
    move v1, v3

    goto :goto_57

    :cond_33
    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastDisplayRotation$cp()I

    move-result v2

    if-ne p2, v2, :cond_45

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastDensity$cp()I

    move-result v2

    if-ne p3, v2, :cond_45

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastDisplayWidth$cp()I

    move-result v2

    if-eq v0, v2, :cond_57

    :cond_45
    invoke-static {v0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$setLastDisplayWidth$cp(I)V

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastGestureWidth$cp()I

    move-result v1

    int-to-float v1, v1

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getLastDensity$cp()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-direct {p0, v1, p2, p3}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->updateGestureBarWidth(FII)I

    move-result v1

    :cond_57
    :goto_57
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result p0

    sub-int p1, v0, v1

    int-to-float p1, p1

    const/high16 p2, 0x40000000    # 2.0f

    div-float/2addr p1, p2

    cmpl-float p2, p0, p1

    if-lez p2, :cond_6c

    int-to-float p2, v0

    sub-float/2addr p2, p1

    cmpg-float p1, p0, p2

    if-gez p1, :cond_6c

    const/4 v3, 0x1

    :cond_6c
    invoke-static {}, Lcom/oplus/basecommon/log/LogUtils;->isLoggableInfo()Z

    move-result p1

    if-eqz p1, :cond_90

    const-string p1, "downX: "

    const-string p2, ", displayWidth: "

    const-string p3, ", gestureBar width: "

    invoke-static {p0, v0, p1, p2, p3}, Lb0/a;->b(FILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ", result: "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "OplusCuiInputConsumer"

    invoke-static {p1, p0}, Lcom/oplus/basecommon/log/LogUtils;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_90
    return v3
.end method

.method private final startBreenoService(Landroid/content/Context;I)V
    .registers 6

    :try_start_0
    new-instance p0, Landroid/content/Intent;

    const-string v0, "heytap.intent.action.ACTIVATE_SPEECH_ASSIST"

    invoke-direct {p0, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v0, Landroid/content/ComponentName;

    const-string v1, "com.heytap.speechassist"

    const-string v2, "com.heytap.speechassist.core.SpeechService"

    invoke-direct {v0, v1, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const-string v0, "caller_package"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "start_type"

    invoke-virtual {p0, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    sget-object p2, Landroid/os/UserHandle;->CURRENT:Landroid/os/UserHandle;

    invoke-virtual {p1, p0, p2}, Landroid/content/Context;->startForegroundServiceAsUser(Landroid/content/Intent;Landroid/os/UserHandle;)Landroid/content/ComponentName;

    move-result-object p0
    :try_end_28
    .catchall {:try_start_0 .. :try_end_28} :catchall_29

    goto :goto_2e

    :catchall_29
    move-exception p0

    invoke-static {p0}, Lq5/m;->a(Ljava/lang/Throwable;)Lq5/l$a;

    move-result-object p0

    :goto_2e
    invoke-static {p0}, Lq5/l;->b(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p0

    if-eqz p0, :cond_3c

    const-string/jumbo p1, "startBreenoService, fail: "

    const-string p2, "OplusCuiInputConsumer"

    invoke-static {p1, p2, p0}, Lcom/android/common/debug/c;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3c
    return-void
.end method

.method private final startCircleToSearch(Landroid/content/Context;I)V
    .registers 4

    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "startCircleToSearch, type: "

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "OplusCuiInputConsumer"

    invoke-static {v0, p0}, Lcom/oplus/basecommon/log/LogUtils;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p0, Lcom/android/quickstep/inputconsumers/b;

    invoke-direct {p0, p2, p1}, Lcom/android/quickstep/inputconsumers/b;-><init>(ILandroid/content/Context;)V

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object p1

    if-eqz p1, :cond_5e

    invoke-virtual {p1}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->isRecentsAnimRealFinish()Z

    move-result p1

    if-nez p1, :cond_5e

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarStateUtils;->isTransientTaskbarPresent()Z

    move-result p1

    if-eqz p1, :cond_54

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object p1

    if-eqz p1, :cond_3c

    invoke-virtual {p1}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->getTaskbarStashController()Lcom/android/launcher3/taskbar/OplusTaskbarStashController;

    move-result-object p1

    if-eqz p1, :cond_3c

    invoke-virtual {p1}, Lcom/android/launcher3/taskbar/OplusTaskbarStashController;->getCurResumeLastTaskAnim()Landroid/animation/Animator;

    move-result-object p1

    goto :goto_3d

    :cond_3c
    const/4 p1, 0x0

    :goto_3d
    if-eqz p1, :cond_54

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object p1

    if-eqz p1, :cond_54

    invoke-virtual {p1}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->getTaskbarStashController()Lcom/android/launcher3/taskbar/OplusTaskbarStashController;

    move-result-object p1

    if-eqz p1, :cond_54

    invoke-virtual {p1}, Lcom/android/launcher3/taskbar/OplusTaskbarStashController;->getCurResumeLastTaskAnim()Landroid/animation/Animator;

    move-result-object p1

    if-eqz p1, :cond_54

    invoke-virtual {p1}, Landroid/animation/Animator;->end()V

    :cond_54
    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object p1

    if-eqz p1, :cond_5d

    invoke-virtual {p1, p0}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->runOnRecentsAnimationRealFinished(Ljava/lang/Runnable;)V

    :cond_5d
    return-void

    :cond_5e
    invoke-virtual {p0}, Lcom/android/quickstep/inputconsumers/b;->run()V

    return-void
.end method

.method private static final startCircleToSearch$lambda$4(ILandroid/content/Context;)V
    .registers 4

    const-string v0, "$context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0x5d

    if-ne p0, v0, :cond_c

    const/16 p0, 0x8

    goto :goto_e

    :cond_c
    const/16 p0, 0x3e8

    :goto_e
    :try_start_e
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "invocation_type"

    invoke-virtual {v0, v1, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    sget-object p0, Lcom/android/quickstep/SystemUiProxy;->INSTANCE:Lcom/android/launcher3/util/MainThreadInitializedObject;

    invoke-virtual {p0, p1}, Lcom/android/launcher3/util/MainThreadInitializedObject;->get(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/quickstep/SystemUiProxy;

    invoke-virtual {p0, v0}, Lcom/android/quickstep/SystemUiProxy;->startAssistant(Landroid/os/Bundle;)V

    sget-object p0, Lq5/b0;->a:Lq5/b0;
    :try_end_25
    .catchall {:try_start_e .. :try_end_25} :catchall_26

    goto :goto_2b

    :catchall_26
    move-exception p0

    invoke-static {p0}, Lq5/m;->a(Ljava/lang/Throwable;)Lq5/l$a;

    move-result-object p0

    :goto_2b
    invoke-static {p0}, Lq5/l;->b(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p0

    if-eqz p0, :cond_39

    const-string/jumbo p1, "startCircleToSearch, fail: "

    const-string v0, "OplusCuiInputConsumer"

    invoke-static {p1, v0, p0}, Lcom/android/common/debug/c;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_39
    return-void
.end method

.method private final updateGestureBarWidth(FII)I
    .registers 4

    if-eqz p2, :cond_9

    const/4 p0, 0x2

    if-eq p2, p0, :cond_9

    const-string/jumbo p0, "navigation_gesture_view_landscape_width"

    goto :goto_c

    :cond_9
    const-string/jumbo p0, "navigation_gesture_view_width"

    :goto_c
    invoke-static {p0, p1}, Lcom/android/launcher3/ResourceUtils;->getOplusDimenByName(Ljava/lang/String;F)I

    move-result p0

    invoke-static {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$setLastGestureWidth$cp(I)V

    invoke-static {p2}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$setLastDisplayRotation$cp(I)V

    invoke-static {p3}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$setLastDensity$cp(I)V

    return p0
.end method


# virtual methods
.method public final canTriggerCui(Landroid/view/MotionEvent;IILcom/android/quickstep/RecentsAnimationDeviceState;)Z
    .registers 16

    const-string v0, "ev"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "deviceState"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->setMSystemUiLongPressed(Z)V

    invoke-virtual {p4}, Lcom/android/quickstep/RecentsAnimationDeviceState;->getSystemUiStateFlags()J

    move-result-wide v1

    const-wide/16 v3, 0x248

    and-long/2addr v1, v3

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    const/4 v2, 0x1

    if-eqz v1, :cond_1e

    move v1, v2

    goto :goto_1f

    :cond_1e
    move v1, v0

    :goto_1f
    invoke-virtual {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->isCUISupport()Z

    move-result v5

    if-eqz v5, :cond_40

    sget-object v5, Lcom/oplus/quickstep/navigation/NavigationController;->INSTANCE:Lcom/oplus/quickstep/navigation/NavigationController$INSTANCE;

    invoke-virtual {v5}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/oplus/quickstep/navigation/NavigationController;

    invoke-virtual {v6}, Lcom/oplus/quickstep/navigation/NavigationController;->getSpeechAssistCuiSupportType()I

    move-result v6

    const/4 v7, 0x2

    if-ne v6, v7, :cond_40

    invoke-virtual {v5}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/oplus/quickstep/navigation/NavigationController;

    invoke-virtual {v5}, Lcom/oplus/quickstep/navigation/NavigationController;->getCuiLongPressEnable()I

    move-result v5

    if-eq v5, v2, :cond_51

    :cond_40
    sget-object v5, Lcom/oplus/quickstep/navigation/NavigationController;->INSTANCE:Lcom/oplus/quickstep/navigation/NavigationController$INSTANCE;

    invoke-virtual {v5}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/oplus/quickstep/navigation/NavigationController;

    invoke-virtual {v5}, Lcom/oplus/quickstep/navigation/NavigationController;->isCircleToSearchGestureEnable()Z

    move-result v5

    if-eqz v5, :cond_53

    if-eqz v1, :cond_51

    goto :goto_53

    :cond_51
    move v1, v0

    goto :goto_54

    :cond_53
    :goto_53
    move v1, v2

    :goto_54
    invoke-virtual {p4}, Lcom/android/quickstep/RecentsAnimationDeviceState;->canStartSystemGesture()Z

    move-result v5

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarStateUtils;->isTaskbarPresent()Z

    move-result v6

    if-eqz v6, :cond_89

    invoke-static {}, Lcom/android/launcher3/taskbar/TaskbarUtils;->getTaskbarActivityContext()Lcom/android/launcher3/taskbar/TaskbarActivityContext;

    move-result-object v6

    if-eqz v6, :cond_6f

    invoke-virtual {v6}, Lcom/android/launcher3/taskbar/TaskbarActivityContext;->getStashedHandleController()Lcom/android/launcher3/taskbar/stashedhandleview/OplusStashedHandleViewController;

    move-result-object v6

    if-eqz v6, :cond_6f

    invoke-virtual {v6}, Lcom/android/launcher3/taskbar/stashedhandleview/OplusStashedHandleViewController;->isStashViewInHiddenState()Z

    move-result v6

    goto :goto_70

    :cond_6f
    move v6, v2

    :goto_70
    invoke-virtual {p4}, Lcom/android/quickstep/RecentsAnimationDeviceState;->getSystemUiStateFlags()J

    move-result-wide v7

    const-wide/16 v9, 0x2

    and-long/2addr v7, v9

    cmp-long p4, v7, v3

    if-eqz p4, :cond_7d

    move p4, v2

    goto :goto_7e

    :cond_7d
    move p4, v0

    :goto_7e
    if-nez v6, :cond_87

    if-nez p4, :cond_87

    if-nez v5, :cond_85

    goto :goto_87

    :cond_85
    move p4, v0

    goto :goto_a1

    :cond_87
    :goto_87
    move p4, v2

    goto :goto_a1

    :cond_89
    invoke-direct {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->getSystemUICompatVersion()I

    move-result p4

    const/4 v3, 0x3

    if-lt p4, v3, :cond_87

    sget-object p4, Lcom/oplus/quickstep/navigation/NavigationController;->INSTANCE:Lcom/oplus/quickstep/navigation/NavigationController$INSTANCE;

    invoke-virtual {p4}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lcom/oplus/quickstep/navigation/NavigationController;

    invoke-virtual {p4}, Lcom/oplus/quickstep/navigation/NavigationController;->getNavBarGestureVisibility()I

    move-result p4

    if-nez p4, :cond_87

    if-nez v5, :cond_85

    goto :goto_87

    :goto_a1
    if-nez v1, :cond_ab

    if-eqz p4, :cond_a6

    goto :goto_ab

    :cond_a6
    invoke-direct {p0, p1, p2, p3}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->isInCuiTouchRegion(Landroid/view/MotionEvent;II)Z

    move-result p0

    return p0

    :cond_ab
    :goto_ab
    invoke-static {}, Lcom/oplus/basecommon/log/LogUtils;->isLoggableInfo()Z

    move-result p1

    if-eqz p1, :cond_d8

    invoke-virtual {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->isCUISupport()Z

    move-result p1

    xor-int/2addr p1, v2

    invoke-direct {p0}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->getSystemUICompatVersion()I

    move-result p0

    const-string p2, "cui not response, isCUISupport: "

    const-string p3, ", speechassist: "

    const-string v2, ", systemui: "

    invoke-static {p2, p1, p3, v1, v2}, Landroidx/room/s;->a(Ljava/lang/String;ZLjava/lang/String;ZLjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ", navbar: "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "OplusCuiInputConsumer"

    invoke-static {p1, p0}, Lcom/oplus/basecommon/log/LogUtils;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_d8
    return v0
.end method

.method public final getMSystemUiLongPressed()Z
    .registers 1

    invoke-static {}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$getMSystemUiLongPressed$cp()Z

    move-result p0

    return p0
.end method

.method public final isCUISupport()Z
    .registers 3

    sget-boolean p0, Lcom/android/common/config/FeatureOption;->isExp:Z

    if-nez p0, :cond_21

    sget-object p0, Lcom/android/common/util/AppFeatureUtils;->INSTANCE:Lcom/android/common/util/AppFeatureUtils;

    invoke-virtual {p0}, Lcom/android/common/util/AppFeatureUtils;->isLightWeightOS()Z

    move-result p0

    if-nez p0, :cond_21

    sget-object p0, Lcom/android/common/util/PackageUtils;->Companion:Lcom/android/common/util/PackageUtils$Companion;

    invoke-static {}, Lcom/android/common/LauncherApplication;->getAppContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "getAppContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "com.heytap.speechassist"

    invoke-virtual {p0, v0, v1}, Lcom/android/common/util/PackageUtils$Companion;->isPackageInstalled(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_21

    const/4 p0, 0x1

    goto :goto_22

    :cond_21
    const/4 p0, 0x0

    :goto_22
    return p0
.end method

.method public final setMSystemUiLongPressed(Z)V
    .registers 2

    invoke-static {p1}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer;->access$setMSystemUiLongPressed$cp(Z)V

    return-void
.end method

.method public final startService(Landroid/content/Context;I)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/android/common/config/FeatureOption;->isSupportCircleToSearch()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-direct {p0, p1, p2}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->startCircleToSearch(Landroid/content/Context;I)V

    goto :goto_12

    :cond_f
    invoke-direct {p0, p1, p2}, Lcom/android/quickstep/inputconsumers/OplusCuiInputConsumer$Companion;->startBreenoService(Landroid/content/Context;I)V

    :goto_12
    return-void
.end method
