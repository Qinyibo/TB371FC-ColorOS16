.class public final Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;
.super Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\r\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0018\u0000 (2\u00020\u0001:\u0001(B7\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0006\u0012\u0008\u0010\t\u001a\u0004\u0018\u00010\u0008\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0004\u0008\u000c\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0014\u00a2\u0006\u0004\u0008\u000f\u0010\u0010J\u0017\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0011H\u0016\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u0017\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0011H\u0014\u00a2\u0006\u0004\u0008\u0016\u0010\u0015J\u000f\u0010\u0018\u001a\u00020\u0017H\u0014\u00a2\u0006\u0004\u0008\u0018\u0010\u0019R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\u001a\u001a\u0004\u0008\u001b\u0010\u001cR\u0019\u0010\t\u001a\u0004\u0018\u00010\u00088\u0006\u00a2\u0006\u000c\n\u0004\u0008\t\u0010\u001d\u001a\u0004\u0008\u001e\u0010\u001fR\u0014\u0010 \u001a\u00020\u00178\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008 \u0010!R\u0018\u0010\"\u001a\u0004\u0018\u00010\u00118\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\"\u0010#R\u0018\u0010$\u001a\u0004\u0018\u00010\u00118\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008$\u0010#R\u0018\u0010&\u001a\u0004\u0018\u00010%8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008&\u0010\'\u00a8\u0006)"
    }
    d2 = {
        "Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;",
        "Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;",
        "Landroid/content/Context;",
        "context",
        "Lcom/android/quickstep/RecentsAnimationDeviceState;",
        "deviceState",
        "Lcom/android/quickstep/TaskAnimationManager;",
        "taskAnimationManager",
        "Lcom/android/quickstep/GestureState;",
        "gestureState",
        "Lcom/android/systemui/shared/system/InputMonitorCompat;",
        "inputMonitorCompat",
        "<init>",
        "(Landroid/content/Context;Lcom/android/quickstep/RecentsAnimationDeviceState;Lcom/android/quickstep/TaskAnimationManager;Lcom/android/quickstep/GestureState;Lcom/android/systemui/shared/system/InputMonitorCompat;)V",
        "Landroid/content/Intent;",
        "createRecentsIntent",
        "()Landroid/content/Intent;",
        "Landroid/view/MotionEvent;",
        "ev",
        "Lq5/b0;",
        "onMotionEvent",
        "(Landroid/view/MotionEvent;)V",
        "finishTouchTracking",
        "",
        "injectBackKey",
        "()Z",
        "Landroid/content/Context;",
        "getContext",
        "()Landroid/content/Context;",
        "Lcom/android/quickstep/GestureState;",
        "getGestureState",
        "()Lcom/android/quickstep/GestureState;",
        "isGestureNavbarHidden",
        "Z",
        "downEvent",
        "Landroid/view/MotionEvent;",
        "upEvent",
        "Landroid/content/ComponentName;",
        "mmVoipComponentName",
        "Landroid/content/ComponentName;",
        "Companion",
        "OplusLauncher_OPPOPallDomesticAallRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final COMPONENT_NAME_WEIXIN_VOIP:Ljava/lang/String; = "com.tencent.mm/com.tencent.mm.plugin.voip.ui.VideoActivity"

.field public static final Companion:Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer$Companion;

.field private static final TAG:Ljava/lang/String; = "OplusDeviceLockedInputConsumer"


# instance fields
.field private final context:Landroid/content/Context;

.field private downEvent:Landroid/view/MotionEvent;

.field private final gestureState:Lcom/android/quickstep/GestureState;

.field private final isGestureNavbarHidden:Z

.field private mmVoipComponentName:Landroid/content/ComponentName;

.field private upEvent:Landroid/view/MotionEvent;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->Companion:Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer$Companion;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/android/quickstep/RecentsAnimationDeviceState;Lcom/android/quickstep/TaskAnimationManager;Lcom/android/quickstep/GestureState;Lcom/android/systemui/shared/system/InputMonitorCompat;)V
    .registers 7

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct/range {p0 .. p5}, Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;-><init>(Landroid/content/Context;Lcom/android/quickstep/RecentsAnimationDeviceState;Lcom/android/quickstep/TaskAnimationManager;Lcom/android/quickstep/GestureState;Lcom/android/systemui/shared/system/InputMonitorCompat;)V

    iput-object p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->context:Landroid/content/Context;

    iput-object p4, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->gestureState:Lcom/android/quickstep/GestureState;

    sget-object p1, Lcom/oplus/quickstep/navigation/NavigationController;->INSTANCE:Lcom/oplus/quickstep/navigation/NavigationController$INSTANCE;

    invoke-virtual {p1}, Lcom/oplus/quickstep/utils/SingletonHolder;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/oplus/quickstep/navigation/NavigationController;

    invoke-virtual {p1}, Lcom/oplus/quickstep/navigation/NavigationController;->isGestureNavbarHidden()Z

    move-result p1

    iput-boolean p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->isGestureNavbarHidden:Z

    const-string p1, "com.tencent.mm/com.tencent.mm.plugin.voip.ui.VideoActivity"

    invoke-static {p1}, Landroid/content/ComponentName;->unflattenFromString(Ljava/lang/String;)Landroid/content/ComponentName;

    move-result-object p1

    iput-object p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->mmVoipComponentName:Landroid/content/ComponentName;

    return-void
.end method


# virtual methods
.method public createRecentsIntent()Landroid/content/Intent;
    .registers 5

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.MAIN"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.intent.category.DEFAULT"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    iget-object v2, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->context:Landroid/content/Context;

    const-string v3, "LockScreenRecentsActivity."

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    iget-object p0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->gestureState:Lcom/android/quickstep/GestureState;

    if-eqz p0, :cond_27

    invoke-virtual {p0}, Lcom/android/quickstep/GestureState;->getGestureId()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    goto :goto_28

    :cond_27
    const/4 p0, 0x0

    :goto_28
    const-string v1, "INTENT_EXTRA_LOG_TRACE_ID"

    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    move-result-object p0

    const v0, 0x10008000

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    move-result-object p0

    const-string/jumbo v0, "setFlags(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/android/systemui/shared/system/ActivityManagerWrapper;->getInstance()Lcom/android/systemui/shared/system/ActivityManagerWrapper;

    move-result-object v0

    const-string/jumbo v1, "recentapps"

    invoke-virtual {v0, v1}, Lcom/android/systemui/shared/system/ActivityManagerWrapper;->closeSystemWindows(Ljava/lang/String;)V

    return-object p0
.end method

.method public finishTouchTracking(Landroid/view/MotionEvent;)V
    .registers 6

    const-string v0, "ev"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-super {p0, p1}, Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;->finishTouchTracking(Landroid/view/MotionEvent;)V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    iget-boolean v0, p0, Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;->mThresholdCrossed:Z

    const-string v1, "finishTouchTracking(), action="

    const-string v2, ", mThresholdCrossed="

    const-string v3, "OplusDeviceLockedInputConsumer"

    invoke-static {v1, v2, v3, p1, v0}, Landroidx/collection/e;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V

    iget-boolean v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->isGestureNavbarHidden:Z

    if-eqz v0, :cond_1f

    iget-boolean v0, p0, Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;->mThresholdCrossed:Z

    if-eqz v0, :cond_22

    :cond_1f
    const/4 v0, 0x1

    if-eq p1, v0, :cond_29

    :cond_22
    iget-object p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->downEvent:Landroid/view/MotionEvent;

    iget-object v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->upEvent:Landroid/view/MotionEvent;

    invoke-static {p1, v0}, Lcom/oplus/quickstep/utils/OplusInputInjectorUtils;->notifyInjectEvent(Landroid/view/MotionEvent;Landroid/view/MotionEvent;)V

    :cond_29
    const/4 p1, 0x0

    iput-object p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->downEvent:Landroid/view/MotionEvent;

    iput-object p1, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->upEvent:Landroid/view/MotionEvent;

    return-void
.end method

.method public final getContext()Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->context:Landroid/content/Context;

    return-object p0
.end method

.method public final getGestureState()Lcom/android/quickstep/GestureState;
    .registers 1

    iget-object p0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->gestureState:Lcom/android/quickstep/GestureState;

    return-object p0
.end method

.method public injectBackKey()Z
    .registers 2

    iget-object v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->mmVoipComponentName:Landroid/content/ComponentName;

    iget-object p0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->gestureState:Lcom/android/quickstep/GestureState;

    if-eqz p0, :cond_15

    invoke-virtual {p0}, Lcom/android/quickstep/GestureState;->getRunningTask()Lcom/android/quickstep/TopTaskTracker$CachedTaskInfo;

    move-result-object p0

    if-eqz p0, :cond_15

    invoke-virtual {p0}, Lcom/android/quickstep/TopTaskTracker$CachedTaskInfo;->getTopTask()Landroid/app/ActivityManager$RunningTaskInfo;

    move-result-object p0

    if-eqz p0, :cond_15

    iget-object p0, p0, Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;

    goto :goto_16

    :cond_15
    const/4 p0, 0x0

    :goto_16
    invoke-static {v0, p0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public onMotionEvent(Landroid/view/MotionEvent;)V
    .registers 4

    const-string v0, "ev"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    iget-boolean v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->isGestureNavbarHidden:Z

    if-eqz v0, :cond_23

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v1, 0x1

    if-eq v0, v1, :cond_16

    const/4 v1, 0x3

    if-eq v0, v1, :cond_16

    goto :goto_23

    :cond_16
    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v0

    iput-object v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->upEvent:Landroid/view/MotionEvent;

    goto :goto_23

    :cond_1d
    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v0

    iput-object v0, p0, Lcom/android/quickstep/inputconsumers/OplusDeviceLockedInputConsumer;->downEvent:Landroid/view/MotionEvent;

    :cond_23
    :goto_23
    invoke-super {p0, p1}, Lcom/android/quickstep/inputconsumers/DeviceLockedInputConsumer;->onMotionEvent(Landroid/view/MotionEvent;)V

    return-void
.end method
