.class public final Lcom/android/keyguardservice/ScreenLockStateMonitor$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/keyguardservice/ScreenLockStateMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\tH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"
    }
    d2 = {
        "Lcom/android/keyguardservice/ScreenLockStateMonitor$Companion;",
        "",
        "()V",
        "TAG",
        "",
        "mInstance",
        "Lcom/android/keyguardservice/ScreenLockStateMonitor;",
        "getInstance",
        "context",
        "Landroid/content/Context;",
        "OplusLauncher_OPPOPallDomesticAallRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/android/keyguardservice/ScreenLockStateMonitor$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getInstance(Landroid/content/Context;)Lcom/android/keyguardservice/ScreenLockStateMonitor;
    .registers 4
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    const-string p0, "context"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/android/keyguardservice/ScreenLockStateMonitor;->access$getMInstance$cp()Lcom/android/keyguardservice/ScreenLockStateMonitor;

    move-result-object p0

    if-nez p0, :cond_2e

    const-class p0, Lcom/android/keyguardservice/ScreenLockStateMonitor;

    monitor-enter p0

    :try_start_e
    invoke-static {}, Lcom/android/keyguardservice/ScreenLockStateMonitor;->access$getMInstance$cp()Lcom/android/keyguardservice/ScreenLockStateMonitor;

    move-result-object v0

    if-nez v0, :cond_28

    new-instance v0, Lcom/android/keyguardservice/ScreenLockStateMonitor;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v1, "getApplicationContext(...)"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, p1}, Lcom/android/keyguardservice/ScreenLockStateMonitor;-><init>(Landroid/content/Context;)V

    invoke-static {v0}, Lcom/android/keyguardservice/ScreenLockStateMonitor;->access$setMInstance$cp(Lcom/android/keyguardservice/ScreenLockStateMonitor;)V

    goto :goto_28

    :catchall_26
    move-exception p1

    goto :goto_2c

    :cond_28
    :goto_28
    sget-object p1, Lq5/b0;->a:Lq5/b0;
    :try_end_2a
    .catchall {:try_start_e .. :try_end_2a} :catchall_26

    monitor-exit p0

    goto :goto_2e

    :goto_2c
    monitor-exit p0

    throw p1

    :cond_2e
    :goto_2e
    invoke-static {}, Lcom/android/keyguardservice/ScreenLockStateMonitor;->access$getMInstance$cp()Lcom/android/keyguardservice/ScreenLockStateMonitor;

    move-result-object p0

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    return-object p0
.end method
