.class public final Lcom/android/keyguardservice/FastUnlockManager;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/keyguardservice/FastUnlockManager$Companion;,
        Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0018\u0000 !2\u00020\u0001:\u0002!\"B\u0011\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0002\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u0017\u0010\u000b\u001a\u00020\u00062\u0008\u0008\u0002\u0010\n\u001a\u00020\t\u00a2\u0006\u0004\u0008\u000b\u0010\u000cJ\u0015\u0010\u000e\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\t\u00a2\u0006\u0004\u0008\u000e\u0010\u000cJ\r\u0010\u000f\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u000f\u0010\u0008J\r\u0010\u0010\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0010\u0010\u0008J\r\u0010\u0011\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0011\u0010\u0008J\r\u0010\u0012\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0012\u0010\u0008J\u0015\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\t\u00a2\u0006\u0004\u0008\u0014\u0010\u000cR\u001c\u0010\u0016\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00158\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0016\u0010\u0017R\u0016\u0010\u0018\u001a\u00020\t8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0018\u0010\u0019R\u0016\u0010\u001a\u001a\u00020\t8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u001a\u0010\u0019R\u0018\u0010\u001c\u001a\u00060\u001bR\u00020\u00008\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u001c\u0010\u001dR\u0018\u0010\u001f\u001a\u0004\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u001f\u0010 \u00a8\u0006#"
    }
    d2 = {
        "Lcom/android/keyguardservice/FastUnlockManager;",
        "",
        "Lcom/android/launcher/Launcher;",
        "launcher",
        "<init>",
        "(Lcom/android/launcher/Launcher;)V",
        "Lq5/b0;",
        "skipFastUnlockIfNeeded",
        "()V",
        "",
        "needCheckByRemote",
        "requestUpdateScreenLockState",
        "(Z)V",
        "ignore",
        "setIgnoreSkipByLauncher",
        "onLauncherResume",
        "onLauncherOnStop",
        "onScreenOffReceiver",
        "onLauncherDestroy",
        "hasFocus",
        "onWindowFocusChanged",
        "Ljava/lang/ref/WeakReference;",
        "launcherRef",
        "Ljava/lang/ref/WeakReference;",
        "mSkipFastUnlockByLauncher",
        "Z",
        "mIgnoreSkipByLauncher",
        "Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;",
        "mKeyGuardDismissedServiceConnection",
        "Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;",
        "Landroid/os/Messenger;",
        "mKeyGuardDismissedServiceMessenger",
        "Landroid/os/Messenger;",
        "Companion",
        "KeyGuardDismissedServiceConnection",
        "OplusLauncher_OPPOPallDomesticAallRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nFastUnlockManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FastUnlockManager.kt\ncom/android/keyguardservice/FastUnlockManager\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,212:1\n1#2:213\n*E\n"
    }
.end annotation


# static fields
.field public static final Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

.field private static final SKIP_SPEED_UNLOCK:Ljava/lang/String; = "skip_speed_unlock"

.field private static final TAG:Ljava/lang/String; = "FastUnlockManager"


# instance fields
.field private final launcherRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/android/launcher/Launcher;",
            ">;"
        }
    .end annotation
.end field

.field private mIgnoreSkipByLauncher:Z

.field private final mKeyGuardDismissedServiceConnection:Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;

.field private mKeyGuardDismissedServiceMessenger:Landroid/os/Messenger;

.field private mSkipFastUnlockByLauncher:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/keyguardservice/FastUnlockManager$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/keyguardservice/FastUnlockManager$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/android/keyguardservice/FastUnlockManager;->Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

    return-void
.end method

.method public constructor <init>(Lcom/android/launcher/Launcher;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->launcherRef:Ljava/lang/ref/WeakReference;

    new-instance v0, Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;

    invoke-direct {v0, p0}, Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;-><init>(Lcom/android/keyguardservice/FastUnlockManager;)V

    iput-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mKeyGuardDismissedServiceConnection:Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;

    if-eqz p1, :cond_1e

    new-instance p0, Landroid/content/Intent;

    const-class v1, Lcom/android/keyguardservice/KeyGuardDismissedService;

    invoke-direct {p0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, 0x1

    invoke-virtual {p1, p0, v0, v1}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    :cond_1e
    return-void
.end method

.method public static final synthetic access$setMKeyGuardDismissedServiceMessenger$p(Lcom/android/keyguardservice/FastUnlockManager;Landroid/os/Messenger;)V
    .registers 2

    iput-object p1, p0, Lcom/android/keyguardservice/FastUnlockManager;->mKeyGuardDismissedServiceMessenger:Landroid/os/Messenger;

    return-void
.end method

.method public static final notifySkipFastUnlock(Landroid/content/Context;Z)V
    .registers 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    sget-object v0, Lcom/android/keyguardservice/FastUnlockManager;->Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

    invoke-virtual {v0, p0, p1}, Lcom/android/keyguardservice/FastUnlockManager$Companion;->notifySkipFastUnlock(Landroid/content/Context;Z)V

    return-void
.end method

.method public static synthetic requestUpdateScreenLockState$default(Lcom/android/keyguardservice/FastUnlockManager;ZILjava/lang/Object;)V
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_5

    const/4 p1, 0x0

    :cond_5
    invoke-virtual {p0, p1}, Lcom/android/keyguardservice/FastUnlockManager;->requestUpdateScreenLockState(Z)V

    return-void
.end method

.method private final skipFastUnlockIfNeeded()V
    .registers 4

    invoke-static {}, Lcom/oplus/basecommon/log/LogUtils;->isLoggableDebug()Z

    move-result v0

    if-eqz v0, :cond_10

    iget-boolean v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mIgnoreSkipByLauncher:Z

    const-string/jumbo v1, "skipFastUnlockIfNeeded, mIgnoreSkipByLauncher = "

    const-string v2, "FastUnlockManager"

    invoke-static {v1, v2, v0}, Landroidx/compose/foundation/c;->b(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_10
    iget-boolean v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mIgnoreSkipByLauncher:Z

    if-eqz v0, :cond_15

    return-void

    :cond_15
    iget-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->launcherRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/launcher/Launcher;

    if-eqz v0, :cond_45

    sget-object v1, Lcom/android/launcher3/LauncherState;->NORMAL:Lcom/android/launcher3/LauncherState;

    invoke-virtual {v0, v1}, Lcom/android/launcher3/statemanager/StatefulActivity;->isInState(Lcom/android/launcher3/statemanager/BaseState;)Z

    move-result v1

    if-nez v1, :cond_2f

    sget-object v1, Lcom/android/launcher3/LauncherState;->ALL_APPS:Lcom/android/launcher3/LauncherState;

    invoke-virtual {v0, v1}, Lcom/android/launcher3/statemanager/StatefulActivity;->isInState(Lcom/android/launcher3/statemanager/BaseState;)Z

    move-result v1

    if-eqz v1, :cond_3d

    :cond_2f
    invoke-static {v0}, Lcom/android/launcher3/AbstractFloatingView;->getOpenFolder(Lcom/android/launcher3/views/ActivityContext;)Lcom/android/launcher3/folder/Folder;

    move-result-object v1

    if-nez v1, :cond_3d

    sget-object v1, Lcom/android/launcher3/stack/view/Stack;->Companion:Lcom/android/launcher3/stack/view/Stack$Companion;

    invoke-virtual {v1, v0}, Lcom/android/launcher3/stack/view/Stack$Companion;->getOpen(Lcom/android/launcher3/views/ActivityContext;)Lcom/android/launcher3/stack/view/Stack;

    move-result-object v1

    if-eqz v1, :cond_45

    :cond_3d
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/android/keyguardservice/FastUnlockManager;->mSkipFastUnlockByLauncher:Z

    sget-object p0, Lcom/android/keyguardservice/FastUnlockManager;->Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

    invoke-virtual {p0, v0, v1}, Lcom/android/keyguardservice/FastUnlockManager$Companion;->notifySkipFastUnlock(Landroid/content/Context;Z)V

    :cond_45
    return-void
.end method


# virtual methods
.method public final onLauncherDestroy()V
    .registers 4

    iget-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->launcherRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/launcher/Launcher;

    if-eqz v0, :cond_15

    sget-object v1, Lcom/android/keyguardservice/FastUnlockManager;->Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Lcom/android/keyguardservice/FastUnlockManager$Companion;->notifySkipFastUnlock(Landroid/content/Context;Z)V

    iget-object p0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mKeyGuardDismissedServiceConnection:Lcom/android/keyguardservice/FastUnlockManager$KeyGuardDismissedServiceConnection;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_15
    return-void
.end method

.method public final onLauncherOnStop()V
    .registers 2

    invoke-direct {p0}, Lcom/android/keyguardservice/FastUnlockManager;->skipFastUnlockIfNeeded()V

    sget-object v0, Lcom/android/common/util/LauncherAnimConfig;->INSTANCE:Lcom/android/common/util/LauncherAnimConfig;

    invoke-virtual {v0}, Lcom/android/common/util/LauncherAnimConfig;->isUnLockAnimDisable()Z

    move-result v0

    if-eqz v0, :cond_2b

    iget-object p0, p0, Lcom/android/keyguardservice/FastUnlockManager;->launcherRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/launcher/Launcher;

    if-eqz p0, :cond_2a

    sget-object v0, Lcom/android/launcher3/LauncherState;->NORMAL:Lcom/android/launcher3/LauncherState;

    invoke-virtual {p0, v0}, Lcom/android/launcher3/statemanager/StatefulActivity;->isInState(Lcom/android/launcher3/statemanager/BaseState;)Z

    move-result v0

    if-eqz v0, :cond_1e

    goto :goto_1f

    :cond_1e
    const/4 p0, 0x0

    :goto_1f
    if-eqz p0, :cond_2a

    invoke-virtual {p0}, Lcom/android/launcher3/Launcher;->getWorkspace()Lcom/android/launcher3/OplusWorkspace;

    move-result-object p0

    if-eqz p0, :cond_2a

    invoke-virtual {p0}, Lcom/android/launcher3/OplusWorkspace;->resetFinalScroll()V

    :cond_2a
    return-void

    :cond_2b
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/android/keyguardservice/FastUnlockManager;->requestUpdateScreenLockState(Z)V

    return-void
.end method

.method public final onLauncherResume()V
    .registers 4

    iget-boolean v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mSkipFastUnlockByLauncher:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_16

    iput-boolean v1, p0, Lcom/android/keyguardservice/FastUnlockManager;->mSkipFastUnlockByLauncher:Z

    iget-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->launcherRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/launcher/Launcher;

    if-eqz v0, :cond_16

    sget-object v2, Lcom/android/keyguardservice/FastUnlockManager;->Companion:Lcom/android/keyguardservice/FastUnlockManager$Companion;

    invoke-virtual {v2, v0, v1}, Lcom/android/keyguardservice/FastUnlockManager$Companion;->notifySkipFastUnlock(Landroid/content/Context;Z)V

    :cond_16
    invoke-virtual {p0, v1}, Lcom/android/keyguardservice/FastUnlockManager;->setIgnoreSkipByLauncher(Z)V

    return-void
.end method

.method public final onScreenOffReceiver()V
    .registers 1

    invoke-direct {p0}, Lcom/android/keyguardservice/FastUnlockManager;->skipFastUnlockIfNeeded()V

    return-void
.end method

.method public final onWindowFocusChanged(Z)V
    .registers 4

    invoke-static {}, Lcom/oplus/basecommon/log/LogUtils;->isLoggableDebug()Z

    move-result v0

    if-eqz v0, :cond_e

    const-string/jumbo v0, "onWindowFocusChanged hasFocus = "

    const-string v1, "FastUnlockManager"

    invoke-static {v0, v1, p1}, Landroidx/compose/foundation/c;->b(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_e
    if-eqz p1, :cond_14

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lcom/android/keyguardservice/FastUnlockManager;->requestUpdateScreenLockState(Z)V

    :cond_14
    return-void
.end method

.method public final requestUpdateScreenLockState(Z)V
    .registers 6

    sget-object v0, Lcom/android/common/util/LauncherAnimConfig;->INSTANCE:Lcom/android/common/util/LauncherAnimConfig;

    invoke-virtual {v0}, Lcom/android/common/util/LauncherAnimConfig;->isUnLockAnimDisable()Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    iget-object v0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mKeyGuardDismissedServiceMessenger:Landroid/os/Messenger;

    const-string v1, "FastUnlockManager"

    if-eqz v0, :cond_58

    invoke-virtual {v0}, Landroid/os/Messenger;->getBinder()Landroid/os/IBinder;

    move-result-object v0

    if-eqz v0, :cond_58

    invoke-interface {v0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_58

    sget-object v0, Lcom/android/keyguardservice/ScreenLockState;->Companion:Lcom/android/keyguardservice/ScreenLockState$Companion;

    invoke-virtual {v0}, Lcom/android/keyguardservice/ScreenLockState$Companion;->isLoggableVerbose()Z

    move-result v0

    if-eqz v0, :cond_3b

    const/4 v0, 0x5

    invoke-static {v0}, Lcom/oplus/wrapper/os/Debug;->getCallers(I)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "requestUpdateScreenLockState,Caller="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/oplus/basecommon/log/LogUtils;->v(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3b
    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    const/4 v2, 0x6

    iput v2, v0, Landroid/os/Message;->what:I

    iput p1, v0, Landroid/os/Message;->arg1:I

    :try_start_44
    iget-object p0, p0, Lcom/android/keyguardservice/FastUnlockManager;->mKeyGuardDismissedServiceMessenger:Landroid/os/Messenger;

    if-eqz p0, :cond_5e

    invoke-virtual {p0, v0}, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    :try_end_4b
    .catch Landroid/os/DeadObjectException; {:try_start_44 .. :try_end_4b} :catch_4c

    goto :goto_5e

    :catch_4c
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "requestUpdateScreenLockState : binder dead ,"

    invoke-static {p1, p0, v1}, Landroidx/compose/foundation/layout/d;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5e

    :cond_58
    const-string/jumbo p0, "requestUpdateScreenLockState: mKeyGuardDismissedServiceMessenger is null or binder dead"

    invoke-static {v1, p0}, Lcom/oplus/basecommon/log/LogUtils;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5e
    :goto_5e
    return-void
.end method

.method public final setIgnoreSkipByLauncher(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/keyguardservice/FastUnlockManager;->mIgnoreSkipByLauncher:Z

    return-void
.end method
