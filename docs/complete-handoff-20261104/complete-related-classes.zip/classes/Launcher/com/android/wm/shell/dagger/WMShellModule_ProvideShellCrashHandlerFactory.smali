.class public final Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln5/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ln5/d;"
    }
.end annotation


# instance fields
.field private final contextProvider:Lp5/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lp5/a<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private final homeIntentProvider:Lp5/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lp5/a<",
            "Lcom/android/wm/shell/common/HomeIntentProvider;",
            ">;"
        }
    .end annotation
.end field

.field private final shellInitProvider:Lp5/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lp5/a<",
            "Lcom/android/wm/shell/sysui/ShellInit;",
            ">;"
        }
    .end annotation
.end field

.field private final shellTaskOrganizerProvider:Lp5/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lp5/a<",
            "Lcom/android/wm/shell/ShellTaskOrganizer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lp5/a;Lp5/a;Lp5/a;Lp5/a;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lp5/a<",
            "Landroid/content/Context;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/ShellTaskOrganizer;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/common/HomeIntentProvider;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/sysui/ShellInit;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->contextProvider:Lp5/a;

    iput-object p2, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->shellTaskOrganizerProvider:Lp5/a;

    iput-object p3, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->homeIntentProvider:Lp5/a;

    iput-object p4, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->shellInitProvider:Lp5/a;

    return-void
.end method

.method public static create(Lp5/a;Lp5/a;Lp5/a;Lp5/a;)Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lp5/a<",
            "Landroid/content/Context;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/ShellTaskOrganizer;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/common/HomeIntentProvider;",
            ">;",
            "Lp5/a<",
            "Lcom/android/wm/shell/sysui/ShellInit;",
            ">;)",
            "Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;"
        }
    .end annotation

    new-instance v0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;-><init>(Lp5/a;Lp5/a;Lp5/a;Lp5/a;)V

    return-object v0
.end method

.method public static provideShellCrashHandler(Landroid/content/Context;Lcom/android/wm/shell/ShellTaskOrganizer;Lcom/android/wm/shell/common/HomeIntentProvider;Lcom/android/wm/shell/sysui/ShellInit;)Lcom/android/wm/shell/crashhandling/ShellCrashHandler;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/android/wm/shell/dagger/WMShellModule;->provideShellCrashHandler(Landroid/content/Context;Lcom/android/wm/shell/ShellTaskOrganizer;Lcom/android/wm/shell/common/HomeIntentProvider;Lcom/android/wm/shell/sysui/ShellInit;)Lcom/android/wm/shell/crashhandling/ShellCrashHandler;

    move-result-object p0

    invoke-static {p0}, Ln5/c;->a(Ljava/lang/Object;)V

    return-object p0
.end method


# virtual methods
.method public get()Lcom/android/wm/shell/crashhandling/ShellCrashHandler;
    .registers 4

    .line 2
    iget-object v0, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->contextProvider:Lp5/a;

    invoke-interface {v0}, Lp5/a;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->shellTaskOrganizerProvider:Lp5/a;

    invoke-interface {v1}, Lp5/a;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/wm/shell/ShellTaskOrganizer;

    iget-object v2, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->homeIntentProvider:Lp5/a;

    invoke-interface {v2}, Lp5/a;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/wm/shell/common/HomeIntentProvider;

    iget-object p0, p0, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->shellInitProvider:Lp5/a;

    invoke-interface {p0}, Lp5/a;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/wm/shell/sysui/ShellInit;

    invoke-static {v0, v1, v2, p0}, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->provideShellCrashHandler(Landroid/content/Context;Lcom/android/wm/shell/ShellTaskOrganizer;Lcom/android/wm/shell/common/HomeIntentProvider;Lcom/android/wm/shell/sysui/ShellInit;)Lcom/android/wm/shell/crashhandling/ShellCrashHandler;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lcom/android/wm/shell/dagger/WMShellModule_ProvideShellCrashHandlerFactory;->get()Lcom/android/wm/shell/crashhandling/ShellCrashHandler;

    move-result-object p0

    return-object p0
.end method
