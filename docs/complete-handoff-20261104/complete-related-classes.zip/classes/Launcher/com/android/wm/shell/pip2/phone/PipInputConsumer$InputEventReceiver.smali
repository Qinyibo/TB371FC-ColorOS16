.class final Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputEventReceiver;
.super Landroid/view/BatchedInputEventReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/wm/shell/pip2/phone/PipInputConsumer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "InputEventReceiver"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/wm/shell/pip2/phone/PipInputConsumer;


# direct methods
.method public constructor <init>(Lcom/android/wm/shell/pip2/phone/PipInputConsumer;Landroid/view/InputChannel;Landroid/os/Looper;Landroid/view/Choreographer;)V
    .registers 5

    iput-object p1, p0, Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputEventReceiver;->this$0:Lcom/android/wm/shell/pip2/phone/PipInputConsumer;

    invoke-direct {p0, p2, p3, p4}, Landroid/view/BatchedInputEventReceiver;-><init>(Landroid/view/InputChannel;Landroid/os/Looper;Landroid/view/Choreographer;)V

    return-void
.end method


# virtual methods
.method public onInputEvent(Landroid/view/InputEvent;)V
    .registers 4

    const/4 v0, 0x1

    :try_start_1
    iget-object v1, p0, Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputEventReceiver;->this$0:Lcom/android/wm/shell/pip2/phone/PipInputConsumer;

    invoke-static {v1}, Lcom/android/wm/shell/pip2/phone/PipInputConsumer;->d(Lcom/android/wm/shell/pip2/phone/PipInputConsumer;)Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputListener;

    move-result-object v1

    if-eqz v1, :cond_16

    iget-object v1, p0, Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputEventReceiver;->this$0:Lcom/android/wm/shell/pip2/phone/PipInputConsumer;

    invoke-static {v1}, Lcom/android/wm/shell/pip2/phone/PipInputConsumer;->d(Lcom/android/wm/shell/pip2/phone/PipInputConsumer;)Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputListener;

    move-result-object v1

    invoke-interface {v1, p1}, Lcom/android/wm/shell/pip2/phone/PipInputConsumer$InputListener;->onInputEvent(Landroid/view/InputEvent;)Z

    move-result v0
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_14

    goto :goto_16

    :catchall_14
    move-exception v1

    goto :goto_1a

    :cond_16
    :goto_16
    invoke-virtual {p0, p1, v0}, Landroid/view/BatchedInputEventReceiver;->finishInputEvent(Landroid/view/InputEvent;Z)V

    return-void

    :goto_1a
    invoke-virtual {p0, p1, v0}, Landroid/view/BatchedInputEventReceiver;->finishInputEvent(Landroid/view/InputEvent;Z)V

    throw v1
.end method
