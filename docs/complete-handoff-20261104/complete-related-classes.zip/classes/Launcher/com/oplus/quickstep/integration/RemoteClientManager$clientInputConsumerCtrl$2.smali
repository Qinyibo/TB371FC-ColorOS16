.class final Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;
.super Lkotlin/jvm/internal/Lambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/quickstep/integration/RemoteClientManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function0<",
        "Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\u0008\u0002"
    }
    d2 = {
        "<anonymous>",
        "Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;",
        "invoke"
    }
    k = 0x3
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;

    invoke-direct {v0}, Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;-><init>()V

    sput-object v0, Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;->INSTANCE:Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;
    .registers 3

    .line 2
    new-instance p0, Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;

    sget-object v0, Lcom/oplus/quickstep/integration/RemoteClientManager;->INSTANCE:Lcom/oplus/quickstep/integration/RemoteClientManager;

    invoke-static {v0}, Lcom/oplus/quickstep/integration/RemoteClientManager;->access$getIWm(Lcom/oplus/quickstep/integration/RemoteClientManager;)Landroid/view/IWindowManager;

    move-result-object v1

    invoke-static {v0}, Lcom/oplus/quickstep/integration/RemoteClientManager;->access$getOplusWm(Lcom/oplus/quickstep/integration/RemoteClientManager;)Landroid/view/OplusWindowManager;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;-><init>(Landroid/view/IWindowManager;Landroid/view/OplusWindowManager;)V

    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lcom/oplus/quickstep/integration/RemoteClientManager$clientInputConsumerCtrl$2;->invoke()Lcom/oplus/quickstep/integration/ClientInputConsumerCtrl;

    move-result-object p0

    return-object p0
.end method
