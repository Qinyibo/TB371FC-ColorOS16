.class final Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;
.super Lkotlin/jvm/internal/Lambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function0<",
        "Landroid/app/OplusActivityManager;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\u0008\u0002"
    }
    d2 = {
        "<anonymous>",
        "Landroid/app/OplusActivityManager;",
        "invoke"
    }
    k = 0x3
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;

    invoke-direct {v0}, Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;-><init>()V

    sput-object v0, Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;->INSTANCE:Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Landroid/app/OplusActivityManager;
    .registers 1

    .line 1
    new-instance p0, Landroid/app/OplusActivityManager;

    invoke-direct {p0}, Landroid/app/OplusActivityManager;-><init>()V

    return-object p0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 1

    .line 2
    invoke-virtual {p0}, Lcom/oplus/quickstep/mistouch/observer/MistouchGameModeObserver$mOplusActivityManager$2;->invoke()Landroid/app/OplusActivityManager;

    move-result-object p0

    return-object p0
.end method
