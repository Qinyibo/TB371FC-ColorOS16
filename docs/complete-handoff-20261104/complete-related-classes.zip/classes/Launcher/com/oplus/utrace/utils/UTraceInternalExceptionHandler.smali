.class public final Lcom/oplus/utrace/utils/UTraceInternalExceptionHandler;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008\u0000\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u001f\u0010\t\u001a\u00020\u00082\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0003\u00a2\u0006\u0004\u0008\t\u0010\nJ\u001f\u0010\u000b\u001a\u00020\u00082\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0016\u00a2\u0006\u0004\u0008\u000b\u0010\n\u00a8\u0006\u000c"
    }
    d2 = {
        "Lcom/oplus/utrace/utils/UTraceInternalExceptionHandler;",
        "Ljava/lang/Thread$UncaughtExceptionHandler;",
        "<init>",
        "()V",
        "Ljava/lang/Thread;",
        "t",
        "",
        "e",
        "Lq5/b0;",
        "report",
        "(Ljava/lang/Thread;Ljava/lang/Throwable;)V",
        "uncaughtException",
        "utrace-sdk_fullRelease"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nUTraceInternalExceptionHandler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UTraceInternalExceptionHandler.kt\ncom/oplus/utrace/utils/UTraceInternalExceptionHandler\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,67:1\n1#2:68\n1282#3:69\n12744#3,2:70\n1283#3:72\n*S KotlinDebug\n*F\n+ 1 UTraceInternalExceptionHandler.kt\ncom/oplus/utrace/utils/UTraceInternalExceptionHandler\n*L\n32#1:69\n33#1:70,2\n32#1:72\n*E\n"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lcom/oplus/utrace/sdk/UTraceApp;->getContext$utrace_sdk_fullRelease()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_e

    sget-object v0, Lcom/oplus/utrace/utils/DcsWrapper;->INSTANCE:Lcom/oplus/utrace/utils/DcsWrapper;

    invoke-virtual {v0, p0}, Lcom/oplus/utrace/utils/DcsWrapper;->init(Landroid/content/Context;)V

    :cond_e
    return-void
.end method

.method private final report(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 15
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SimpleDateFormat"
        }
    .end annotation

    invoke-static {}, Lcom/oplus/utrace/sdk/UTraceApp;->getContext$utrace_sdk_fullRelease()Landroid/content/Context;

    move-result-object p0

    if-nez p0, :cond_7

    return-void

    :cond_7
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/Reflection;->getOrCreateKotlinClass(Ljava/lang/Class;)Li6/d;

    move-result-object v0

    invoke-interface {v0}, Li6/d;->getQualifiedName()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_18

    const-string/jumbo v0, "unknown"

    :cond_18
    new-instance v1, Lq5/k;

    const-string v2, "exception_class"

    invoke-direct {v1, v2, v0}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_29

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_29
    new-instance v2, Lq5/k;

    const-string v3, "exception_message"

    invoke-direct {v2, v3, v0}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p2}, Lq5/a;->b(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    new-instance v3, Lq5/k;

    const-string v0, "callstack"

    invoke-direct {v3, v0, p2}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p1

    new-instance v4, Lq5/k;

    const-string/jumbo p2, "thread_name"

    invoke-direct {v4, p2, p1}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p0}, Lcom/oplus/utrace/utils/UtilsKt;->getProcessName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    new-instance v5, Lq5/k;

    const-string p2, "process_name"

    invoke-direct {v5, p2, p1}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v6, Lq5/k;

    const-string p1, "sdk_version"

    const-string p2, "2.0.26-f348910-20250805-214400"

    invoke-direct {v6, p1, p2}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    new-instance v7, Lq5/k;

    const-string p2, "app_name"

    invoke-direct {v7, p2, p1}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const-string p2, "context.packageName"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Lcom/oplus/utrace/utils/UtilsKt;->getAppVersionName(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    new-instance v8, Lq5/k;

    const-string p1, "app_version"

    invoke-direct {v8, p1, p0}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lcom/oplus/utrace/sdk/UTraceApp;->getModuleName$utrace_sdk_fullRelease()Ljava/lang/String;

    move-result-object p0

    new-instance v9, Lq5/k;

    const-string p1, "module_name"

    invoke-direct {v9, p1, p0}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance p0, Ljava/text/SimpleDateFormat;

    const-string/jumbo p1, "yyyyMMddHHmmssSSS"

    invoke-direct {p0, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance p1, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-direct {p1, v10, v11}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {p0, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    new-instance v10, Lq5/k;

    const-string p1, "exception_timestamp"

    invoke-direct {v10, p1, p0}, Lq5/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    filled-new-array/range {v1 .. v10}, [Lq5/k;

    move-result-object p0

    invoke-static {p0}, Lr5/s0;->h([Lq5/k;)Ljava/util/LinkedHashMap;

    move-result-object p0

    sget-object p1, Lcom/oplus/utrace/utils/DcsWrapper;->INSTANCE:Lcom/oplus/utrace/utils/DcsWrapper;

    const-string p2, "UTRACE_INTERNAL"

    const-string v0, "1001"

    invoke-virtual {p1, p2, v0, p0}, Lcom/oplus/utrace/utils/DcsWrapper;->report(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    return-void
.end method


# virtual methods
.method public uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 15

    const-string v0, "UTrace.Sdk.Exception"

    const-string/jumbo v1, "t"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "e"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v1

    const-string v2, "e.stackTrace"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_19
    const/4 v5, 0x0

    if-ge v4, v2, :cond_53

    aget-object v6, v1, v4

    const-string v7, "com.oplus.utrace"

    const-string v8, "com.heytap.log"

    filled-new-array {v7, v8}, [Ljava/lang/String;

    move-result-object v7

    move v8, v3

    :goto_27
    const/4 v9, 0x2

    if-ge v8, v9, :cond_50

    aget-object v9, v7, v8

    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v10

    const-string v11, "element.className"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x2e

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v10, v9, v3}, Lt8/s;->v(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v9

    if-eqz v9, :cond_4d

    goto :goto_54

    :cond_4d
    add-int/lit8 v8, v8, 0x1

    goto :goto_27

    :cond_50
    add-int/lit8 v4, v4, 0x1

    goto :goto_19

    :cond_53
    move-object v6, v5

    :goto_54
    if-eqz v6, :cond_6e

    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-class v2, Lcom/oplus/utrace/utils/SafeHandlerThread;

    invoke-static {v2}, Lkotlin/jvm/internal/Reflection;->getOrCreateKotlinClass(Ljava/lang/Class;)Li6/d;

    move-result-object v2

    invoke-interface {v2}, Li6/d;->getQualifiedName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    :cond_6e
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v5, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c3

    :try_start_76
    sget-object v1, Lcom/oplus/utrace/utils/Logs;->INSTANCE:Lcom/oplus/utrace/utils/Logs;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "caught exception in thread \'"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\': "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v0, v2, p2}, Lcom/oplus/utrace/utils/Logs;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-direct {p0, p1, p2}, Lcom/oplus/utrace/utils/UTraceInternalExceptionHandler;->report(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    sget-object p0, Lq5/b0;->a:Lq5/b0;
    :try_end_9d
    .catchall {:try_start_76 .. :try_end_9d} :catchall_9e

    goto :goto_a3

    :catchall_9e
    move-exception p0

    invoke-static {p0}, Lq5/m;->a(Ljava/lang/Throwable;)Lq5/l$a;

    move-result-object p0

    :goto_a3
    invoke-static {p0}, Lq5/l;->b(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p0

    if-eqz p0, :cond_c2

    sget-object p0, Lcom/oplus/utrace/utils/Logs;->INSTANCE:Lcom/oplus/utrace/utils/Logs;

    invoke-virtual {p0}, Lcom/oplus/utrace/utils/Logs;->getDebuggable()Z

    move-result p0

    if-eqz p0, :cond_c2

    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "caught exception in uncaughtException: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_c2
    return-void

    :cond_c3
    throw p2
.end method
