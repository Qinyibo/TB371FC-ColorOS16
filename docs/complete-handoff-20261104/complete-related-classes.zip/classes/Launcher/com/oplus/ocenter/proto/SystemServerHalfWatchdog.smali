.class public final Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
.super Lcom/google/protobuf/GeneratedMessageV3;
.source "SourceFile"

# interfaces
.implements Lcom/oplus/ocenter/proto/SystemServerHalfWatchdogOrBuilder;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    }
.end annotation


# static fields
.field public static final DCS_APP_ID_FIELD_NUMBER:I = 0x1

.field public static final DCS_EVENT_ID_FIELD_NUMBER:I = 0x3

.field public static final DCS_LOG_TAG_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

.field public static final FAULT_TIMESTAMP_MS_FIELD_NUMBER:I = 0x4

.field public static final LOG_TYPE_FIELD_NUMBER:I = 0x5

.field public static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final PROCESS_PID_FIELD_NUMBER:I = 0x6

.field public static final PROCESS_UID_FIELD_NUMBER:I = 0x7

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private dcsAppId_:I

.field private volatile dcsEventId_:Ljava/lang/Object;

.field private volatile dcsLogTag_:Ljava/lang/Object;

.field private faultTimestampMs_:J

.field private volatile logType_:Ljava/lang/Object;

.field private processPid_:I

.field private processUid_:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    invoke-direct {v0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;-><init>()V

    sput-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    new-instance v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$1;

    invoke-direct {v0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$1;-><init>()V

    sput-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    return-void
.end method

.method private constructor <init>()V
    .registers 5

    .line 10
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v0, 0x0

    .line 11
    iput v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsAppId_:I

    .line 12
    const-string v1, ""

    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    .line 13
    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    const-wide/16 v2, 0x0

    .line 14
    iput-wide v2, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->faultTimestampMs_:J

    .line 15
    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    .line 16
    iput v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processPid_:I

    .line 17
    iput v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processUid_:I

    .line 18
    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    .line 19
    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    .line 20
    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    .line 2
    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 p1, 0x0

    .line 3
    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsAppId_:I

    .line 4
    const-string v0, ""

    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    .line 5
    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    const-wide/16 v1, 0x0

    .line 6
    iput-wide v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->faultTimestampMs_:J

    .line 7
    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    .line 8
    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processPid_:I

    .line 9
    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processUid_:I

    return-void
.end method

.method public synthetic constructor <init>(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    return-void
.end method

.method public static bridge synthetic a(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;)I
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic b(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;I)V
    .registers 2

    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic c(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;I)V
    .registers 2

    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsAppId_:I

    return-void
.end method

.method public static bridge synthetic d(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;Ljava/lang/Object;)V
    .registers 2

    iput-object p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    return-void
.end method

.method public static bridge synthetic e(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;Ljava/lang/Object;)V
    .registers 2

    iput-object p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    return-void
.end method

.method public static bridge synthetic f(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;J)V
    .registers 3

    iput-wide p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->faultTimestampMs_:J

    return-void
.end method

.method public static bridge synthetic g(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;Ljava/lang/Object;)V
    .registers 2

    iput-object p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    return-void
.end method

.method public static getDefaultInstance()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 1

    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .registers 1

    sget-object v0, Lcom/oplus/ocenter/proto/AtomsProto;->internal_static_android_os_statsd_SystemServerHalfWatchdog_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    return-object v0
.end method

.method public static bridge synthetic h(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;I)V
    .registers 2

    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processPid_:I

    return-void
.end method

.method public static bridge synthetic i(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;I)V
    .registers 2

    iput p1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processUid_:I

    return-void
.end method

.method public static newBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    .registers 1

    .line 1
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    invoke-virtual {v0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->toBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object v0

    return-object v0
.end method

.method public static newBuilder(Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    .registers 2

    .line 2
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    invoke-virtual {v0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->toBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 2
    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 4
    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 12
    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 14
    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 8
    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    .line 10
    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    return-object v0
.end method


# virtual methods
.method public getDcsAppId()I
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsAppId_:I

    return p0
.end method

.method public getDcsEventId()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_9

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_9
    check-cast v0, Lcom/google/protobuf/ByteString;

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    if-eqz v0, :cond_17

    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    :cond_17
    return-object v1
.end method

.method public getDcsEventIdBytes()Lcom/google/protobuf/ByteString;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_f

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsEventId_:Ljava/lang/Object;

    return-object v0

    :cond_f
    check-cast v0, Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getDcsLogTag()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_9

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_9
    check-cast v0, Lcom/google/protobuf/ByteString;

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    if-eqz v0, :cond_17

    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    :cond_17
    return-object v1
.end method

.method public getDcsLogTagBytes()Lcom/google/protobuf/ByteString;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_f

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->dcsLogTag_:Ljava/lang/Object;

    return-object v0

    :cond_f
    check-cast v0, Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->getDefaultInstanceForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .registers 1

    .line 2
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->getDefaultInstanceForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    move-result-object p0

    return-object p0
.end method

.method public getDefaultInstanceForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;
    .registers 1

    .line 3
    sget-object p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    return-object p0
.end method

.method public getFaultTimestampMs()J
    .registers 3

    iget-wide v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->faultTimestampMs_:J

    return-wide v0
.end method

.method public getLogType()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_9

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_9
    check-cast v0, Lcom/google/protobuf/ByteString;

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    if-eqz v0, :cond_17

    iput-object v1, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    :cond_17
    return-object v1
.end method

.method public getLogTypeBytes()Lcom/google/protobuf/ByteString;
    .registers 3

    iget-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_f

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->logType_:Ljava/lang/Object;

    return-object v0

    :cond_f
    check-cast v0, Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;",
            ">;"
        }
    .end annotation

    sget-object p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->PARSER:Lcom/google/protobuf/Parser;

    return-object p0
.end method

.method public getProcessPid()I
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processPid_:I

    return p0
.end method

.method public getProcessUid()I
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->processUid_:I

    return p0
.end method

.method public hasDcsAppId()Z
    .registers 2

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-eqz p0, :cond_7

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    return v0
.end method

.method public hasDcsEventId()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public hasDcsLogTag()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x2

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public hasFaultTimestampMs()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x8

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public hasLogType()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x10

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public hasProcessPid()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x20

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public hasProcessUid()Z
    .registers 1

    iget p0, p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->bitField0_:I

    and-int/lit8 p0, p0, 0x40

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    goto :goto_9

    :cond_8
    const/4 p0, 0x0

    :goto_9
    return p0
.end method

.method public internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .registers 3

    sget-object p0, Lcom/oplus/ocenter/proto/AtomsProto;->internal_static_android_os_statsd_SystemServerHalfWatchdog_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const-class v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    const-class v1, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->newBuilderForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .registers 1

    .line 3
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->newBuilderForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public newBuilderForType()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    .registers 1

    .line 4
    invoke-static {}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->newBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    .registers 3

    .line 5
    new-instance p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;I)V

    return-object p0
.end method

.method public newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .registers 2

    new-instance p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    invoke-direct {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;-><init>()V

    return-object p0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->toBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .registers 1

    .line 2
    invoke-virtual {p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->toBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    move-result-object p0

    return-object p0
.end method

.method public toBuilder()Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;
    .registers 3

    .line 3
    sget-object v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;->DEFAULT_INSTANCE:Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog;

    const/4 v1, 0x0

    if-ne p0, v0, :cond_b

    .line 4
    new-instance p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    invoke-direct {p0, v1}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;-><init>(I)V

    goto :goto_16

    :cond_b
    new-instance v0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    invoke-direct {v0, v1}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;-><init>(I)V

    invoke-virtual {v0, p0}, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object p0

    check-cast p0, Lcom/oplus/ocenter/proto/SystemServerHalfWatchdog$Builder;

    :goto_16
    return-object p0
.end method
