.class public interface abstract Landroid/system/suspend/IWakelockCallback;
.super Ljava/lang/Object;
.source "IWakelockCallback.java"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/system/suspend/IWakelockCallback$Stub;,
        Landroid/system/suspend/IWakelockCallback$Default;
    }
.end annotation


# static fields
.field public static final blacklist DESCRIPTOR:Ljava/lang/String; = "android.system.suspend.IWakelockCallback"


# virtual methods
.method public abstract blacklist notifyAcquired()V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method

.method public abstract blacklist notifyReleased()V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation
.end method
