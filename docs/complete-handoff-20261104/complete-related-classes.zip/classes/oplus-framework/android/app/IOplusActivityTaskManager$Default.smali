.class public Landroid/app/IOplusActivityTaskManager$Default;
.super Ljava/lang/Object;
.source "IOplusActivityTaskManager.java"

# interfaces
.implements Landroid/app/IOplusActivityTaskManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/IOplusActivityTaskManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor blacklist <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public blacklist addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 775
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist addFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 69
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 220
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist adjustEndAbsForFlexibleMinimize()Landroid/graphics/Rect;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1158
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist adjustEndAbsForFlexibleMinimizeIfNeed(Landroid/window/TransitionInfo$Change;)Landroid/graphics/Rect;
    .registers 3
    .param p1, "change"    # Landroid/window/TransitionInfo$Change;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1152
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist adjustFlexibleTask(Landroid/os/Bundle;)Z
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1216
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist adjustWindowFrame(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 5
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1078
    return-void
.end method

.method public blacklist adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 5
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 842
    return-void
.end method

.method public whitelist asBinder()Landroid/os/IBinder;
    .registers 2

    .line 1314
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V
    .registers 2
    .param p1, "callback"    # Lcom/oplus/quickreply/IQuickReplyCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 793
    return-void
.end method

.method public blacklist calculateCanvasLayoutRect(Ljava/util/List;IIZ)Ljava/util/List;
    .registers 6
    .param p2, "focusIndex"    # I
    .param p3, "layoutOrientation"    # I
    .param p4, "panoramaMode"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/Intent;",
            ">;IIZ)",
            "Ljava/util/List<",
            "Landroid/graphics/Rect;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1011
    .local p1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist calculateFlexibleWindowBoundList(Ljava/util/List;ILandroid/os/Bundle;)Landroid/os/Bundle;
    .registers 5
    .param p2, "layoutOrientation"    # I
    .param p3, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/Intent;",
            ">;I",
            "Landroid/os/Bundle;",
            ")",
            "Landroid/os/Bundle;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 917
    .local p1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist calculateFlexibleWindowBounds(Landroid/content/Intent;II)Landroid/os/Bundle;
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "appOrientation"    # I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 913
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist calculateReplaceCanvasLayoutRect(Ljava/util/List;IIIZ)Ljava/util/List;
    .registers 7
    .param p2, "focusIndex"    # I
    .param p3, "replace"    # I
    .param p4, "displayId"    # I
    .param p5, "panoramaMode"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/Intent;",
            ">;IIIZ)",
            "Ljava/util/List<",
            "Landroid/graphics/Rect;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1015
    .local p1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 8
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "packageName"    # Ljava/lang/String;
    .param p3, "param1"    # I
    .param p4, "param2"    # Z
    .param p5, "param3"    # Ljava/lang/String;
    .param p6, "object"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 764
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist clearEmbeddedContainerTask([II)V
    .registers 3
    .param p1, "embeddedTaskIdList"    # [I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 986
    return-void
.end method

.method public blacklist clientTransactionComplete(Landroid/os/IBinder;I)V
    .registers 3
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "seq"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 683
    return-void
.end method

.method public blacklist closeSplitTask(ILandroid/os/Bundle;)V
    .registers 3
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 962
    return-void
.end method

.method public blacklist createMirageDisplay(Landroid/view/Surface;)I
    .registers 3
    .param p1, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 535
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;
    .registers 3
    .param p1, "callback"    # Lcom/oplus/miragewindow/IOplusMirageSessionCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 600
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist createVirtualDisplayDevice(Landroid/os/Bundle;)I
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1115
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist dismissSplitScreenMode(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 419
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist exitCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 713
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist exitFlexibleEmbeddedTask(I)V
    .registers 2
    .param p1, "embeddedTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 974
    return-void
.end method

.method public blacklist exitSplitTask(ILandroid/os/Bundle;)V
    .registers 3
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 965
    return-void
.end method

.method public blacklist expandToFullScreen()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 570
    return-void
.end method

.method public blacklist feedbackUserSelection(IILandroid/os/Bundle;)V
    .registers 4
    .param p1, "eventId"    # I
    .param p2, "selection"    # I
    .param p3, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 608
    return-void
.end method

.method public blacklist findTargetTaskByIntent(Landroid/content/Intent;ILandroid/os/Bundle;Landroid/view/ITargetTaskCallBack;)V
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .param p3, "bOptions"    # Landroid/os/Bundle;
    .param p4, "callback"    # Landroid/view/ITargetTaskCallBack;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1030
    return-void
.end method

.method public blacklist getActivityConfigs(Landroid/os/IBinder;Ljava/lang/String;)Landroid/os/Bundle;
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1070
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getAllTopAppInfos()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/app/OplusAppInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 50
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "change"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 695
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getConfineMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 312
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getCurrentZoomToSplitState(I)I
    .registers 3
    .param p1, "zoomTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1019
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 136
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getEmbeddedChildren(I)Ljava/util/List;
    .registers 3
    .param p1, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1142
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getEmbeddedChildrenSnapshot(IZZ)Landroid/window/TaskSnapshot;
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "isLowResolution"    # Z
    .param p3, "takeSnapshotIfNeeded"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1146
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getEmbeddedTaskSnapshot(Landroid/content/Intent;Landroid/window/WindowContainerToken;ZZLandroid/graphics/Rect;)Landroid/window/TaskSnapshot;
    .registers 7
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "windowContainerToken"    # Landroid/window/WindowContainerToken;
    .param p3, "useCache"    # Z
    .param p4, "updateCache"    # Z
    .param p5, "launchBounds"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1255
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getEnterPuttAppInfos()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/putt/OplusPuttEnterInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 890
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getFlexibleMinimizedTaskId()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1162
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getFlexibleWindowConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1288
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getFocusBounds(Z)Landroid/graphics/Rect;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 752
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getFocusComponent(Z)Landroid/content/ComponentName;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 756
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getFocusMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 748
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getFreeformConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 55
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getGetDisplayIdForPackageName(Ljava/lang/String;)I
    .registers 3
    .param p1, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 604
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 509
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getLastEvent()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/graphics/Point;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 354
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getLeftRightBoundsForIme()Landroid/os/Bundle;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 480
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getMinimizedBounds(I)Landroid/graphics/Rect;
    .registers 3
    .param p1, "dockedSide"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 462
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getMirageDisplayCastMode(I)I
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 566
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 580
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 812
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getPWAppInfo()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 737
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getPackagesState()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 393
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getPauseInRecentsAnimPkgList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 859
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getPocketStudioTaskRegion(I)Ljava/util/Map;
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 936
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getRealSize()Landroid/graphics/Point;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 760
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getRecentEmbeddedTasksForContainer(I)Ljava/util/List;
    .registers 3
    .param p1, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RecentTaskInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 989
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getRenderThreadTid(I)I
    .registers 3
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 830
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getSecurityFlagCurrentPage()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 185
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 466
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getSplitScreenState(Landroid/content/Intent;)I
    .registers 3
    .param p1, "intent"    # Landroid/content/Intent;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 42
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 3
    .param p1, "event"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 431
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getTaskDescriptionLabel(I)Ljava/lang/String;
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1274
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;
    .registers 3
    .param p1, "name"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 539
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getTopActivityComponentName()Landroid/content/ComponentName;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 32
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 37
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getUriForFlexibleWindow(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1281
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getVisibleTasks(I)Ljava/util/List;
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1184
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getZoomAppConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 143
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getZoomBounds(ZI)Landroid/graphics/Rect;
    .registers 4
    .param p1, "landApp"    # Z
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1231
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getZoomBoundsByTaskId(II)Landroid/graphics/Rect;
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1238
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 825
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 204
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z
    .registers 7
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .param p5, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 151
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist hasColorSplitFeature()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 487
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist hasLargeScreenFeature()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 454
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist hideZoomWindow(I)V
    .registers 2
    .param p1, "flag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 140
    return-void
.end method

.method public blacklist invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "params"    # Ljava/lang/String;
    .param p4, "objects"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 768
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist isAppSupportPocketStudio(Landroid/content/Intent;I)Z
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 921
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isClickAtPocketStudioArea(III)Z
    .registers 5
    .param p1, "displayId"    # I
    .param p2, "rowX"    # I
    .param p3, "rowY"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1007
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isCurrentAppSupportCompactMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 717
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isFlexibleTaskEnabled(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1127
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isFolderInnerScreen()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 458
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isFreeformEnabled()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 60
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isInAppInnerSplitScreen(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1039
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isInPocketStudio(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 928
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isInPocketStudioForStandard(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 932
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isInSplitScreenMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 415
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isLockDeviceMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 243
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isMinimizedPocketStudio(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 943
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isMirageWindowShow()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 550
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z
    .registers 3
    .param p1, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 786
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isPowerKeyPressed()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 340
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isSupportEdgeTouchPrevent()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 292
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isSupportMirageWindowMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 576
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isSupportPuttMode(ILjava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 7
    .param p1, "type"    # I
    .param p2, "target"    # Ljava/lang/String;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .param p5, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 898
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 6
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 147
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isSupportZoomWindowMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 200
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isTaskExist(IIILandroid/content/Intent;Landroid/os/Bundle;)Z
    .registers 7
    .param p1, "matchMode"    # I
    .param p2, "taskId"    # I
    .param p3, "userId"    # I
    .param p4, "baseIntent"    # Landroid/content/Intent;
    .param p5, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1204
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isTouchNodeSupport(II)Z
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 657
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isZoomSimpleModeEnable()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 274
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 846
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist lockRotationInGame(I[Ljava/lang/String;)Z
    .registers 4
    .param p1, "state"    # I
    .param p2, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 702
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist moveActivityTaskToBack(IZ)V
    .registers 3
    .param p1, "taskId"    # I
    .param p2, "cancleAnim"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1269
    return-void
.end method

.method public blacklist moveCompactWindowToLeft()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 721
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist moveCompactWindowToRight()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 725
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist moveTaskToDisplay(IIZ)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "displayId"    # I
    .param p3, "top"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1122
    return-void
.end method

.method public blacklist notifyEmbeddedTasksChangeFocus(ZI)V
    .registers 3
    .param p1, "isStateSteady"    # Z
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1046
    return-void
.end method

.method public blacklist notifyFlexibleBlurAttachEvent(Landroid/content/Intent;IILjava/lang/String;Landroid/view/SurfaceControl;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .param p3, "flag"    # I
    .param p4, "callerPkg"    # Ljava/lang/String;
    .param p5, "extraLeash"    # Landroid/view/SurfaceControl;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1033
    return-void
.end method

.method public blacklist notifyFlexibleSplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;I)V
    .registers 4
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1052
    return-void
.end method

.method public blacklist notifyFlexibleTaskEvent(IILandroid/os/Bundle;)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "event"    # I
    .param p3, "extra"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1169
    return-void
.end method

.method public blacklist notifyMinimizedReady(ILandroid/os/Bundle;Lcom/oplus/flexiblewindow/IMinimizedCallback;)Z
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "callback"    # Lcom/oplus/flexiblewindow/IMinimizedCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1023
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V
    .registers 4
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "broadcast"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 408
    return-void
.end method

.method public blacklist notifyTouchNodeChange(IJIIILjava/lang/String;)Z
    .registers 9
    .param p1, "clientFlag"    # I
    .param p2, "time"    # J
    .param p4, "deviceId"    # I
    .param p5, "nodeFlag"    # I
    .param p6, "data"    # I
    .param p7, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 668
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist notifyUiSwitched(Ljava/lang/String;I)V
    .registers 3
    .param p1, "uiInfo"    # Ljava/lang/String;
    .param p2, "status"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 851
    return-void
.end method

.method public blacklist notifyZoomStateChange(Ljava/lang/String;I)V
    .registers 3
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "action"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 158
    return-void
.end method

.method public blacklist onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V
    .registers 2
    .param p1, "cvInfo"    # Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 164
    return-void
.end method

.method public blacklist onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V
    .registers 2
    .param p1, "floatHandleInfo"    # Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 196
    return-void
.end method

.method public blacklist onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V
    .registers 2
    .param p1, "inputEventInfo"    # Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 161
    return-void
.end method

.method public blacklist onProtocolUpdated(Ljava/lang/String;)Z
    .registers 3
    .param p1, "content"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 741
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist pauseInRecentsAnim(I)V
    .registers 2
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 856
    return-void
.end method

.method public blacklist preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "extra"    # Landroid/os/Bundle;
    .param p3, "surface"    # Landroid/view/SurfaceControl;
    .param p4, "callback"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1311
    return-void
.end method

.method public blacklist readNodeFile(I)Ljava/lang/String;
    .registers 3
    .param p1, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 641
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist readNodeFileByDevice(II)Ljava/lang/String;
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 645
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist rebindDisplayIfNeeded(II)Z
    .registers 4
    .param p1, "castDisplayId"    # I
    .param p2, "mirageDisplayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 615
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "observer"    # Lcom/oplus/app/IOplusAppSwitchObserver;
    .param p3, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 90
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 729
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 626
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/globaldrag/IDragAndDropListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 102
    return-void
.end method

.method public blacklist registerEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V
    .registers 3
    .param p1, "callback"    # Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1058
    return-void
.end method

.method public blacklist registerEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/os/IOplusTouchNodeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 672
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V
    .registers 2
    .param p1, "listener"    # Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1261
    return-void
.end method

.method public blacklist registerFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;I)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 905
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z
    .registers 5
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .param p3, "configs"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 498
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z
    .registers 5
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .param p3, "listenFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 326
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 397
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 527
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 519
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;[II)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/app/IOplusTaskStackListener;
    .param p2, "typeList"    # [I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1196
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttEventObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 874
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 866
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z
    .registers 4
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/ILongPressScreenshotCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 358
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 177
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 423
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V
    .registers 2
    .param p1, "observer"    # Lcom/oplus/app/IOplusStartingWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1303
    return-void
.end method

.method public blacklist registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 373
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;II)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/app/IOplusTaskInfoChangeListener;
    .param p2, "type"    # I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1188
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerWindowChangeListener(Ljava/lang/String;Ljava/lang/String;Lcom/oplus/app/OplusWindowChangeRegisterParam;Lcom/oplus/app/IOplusWindowChangeObserver;)Z
    .registers 6
    .param p1, "packageInfo"    # Ljava/lang/String;
    .param p2, "Sence"    # Ljava/lang/String;
    .param p3, "param"    # Lcom/oplus/app/OplusWindowChangeRegisterParam;
    .param p4, "observer"    # Lcom/oplus/app/IOplusWindowChangeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1298
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 167
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1175
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 124
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist releaseScreenshotRegion()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 350
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist releaseVirtualDisplayDevice(I)V
    .registers 2
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1119
    return-void
.end method

.method public blacklist removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 779
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist removeEmbeddedContainerTask(II)V
    .registers 3
    .param p1, "embeddedTaskId"    # I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 971
    return-void
.end method

.method public blacklist removeFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 78
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist removePuttTask(ILjava/lang/String;I)Z
    .registers 5
    .param p1, "action"    # I
    .param p2, "pkg"    # Ljava/lang/String;
    .param p3, "puttTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 894
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 231
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist replaceLockTaskPackages([Ljava/lang/String;)V
    .registers 2
    .param p1, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 269
    return-void
.end method

.method public blacklist replaceSplitTask(ILandroid/content/Intent;ILandroid/os/Bundle;)V
    .registers 5
    .param p1, "oldTaskId"    # I
    .param p2, "intent"    # Landroid/content/Intent;
    .param p3, "newTaskId"    # I
    .param p4, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 968
    return-void
.end method

.method public blacklist reportViewExtractResult(Landroid/os/Bundle;)V
    .registers 2
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1095
    return-void
.end method

.method public blacklist requestViewExtractData(Landroid/app/IAssistDataReceiver;Landroid/os/Bundle;Landroid/os/IBinder;I)V
    .registers 5
    .param p1, "receiver"    # Landroid/app/IAssistDataReceiver;
    .param p2, "receiverExtras"    # Landroid/os/Bundle;
    .param p3, "activityToken"    # Landroid/os/IBinder;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1098
    return-void
.end method

.method public blacklist resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z
    .registers 3
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 288
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist resetFlexibleTask(IZZZ)V
    .registers 5
    .param p1, "embeddedTaskId"    # I
    .param p2, "needResize"    # Z
    .param p3, "doAnimation"    # Z
    .param p4, "isFromSplit"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 982
    return-void
.end method

.method public blacklist resetNoReparentTask(I)V
    .registers 2
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1064
    return-void
.end method

.method public blacklist sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z
    .registers 4
    .param p1, "weChatIntent"    # Landroid/app/PendingIntent;
    .param p2, "message"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 799
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist sendMirageEvents(ILandroid/os/Bundle;)V
    .registers 3
    .param p1, "eventId"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1222
    return-void
.end method

.method public blacklist setBackInvokePolicyForPredictive(Landroid/os/IBinder;Landroid/os/Bundle;)V
    .registers 3
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1245
    return-void
.end method

.method public blacklist setConfineMode(IZLandroid/os/IBinder;)V
    .registers 4
    .param p1, "mode"    # I
    .param p2, "on"    # Z
    .param p3, "token"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 309
    return-void
.end method

.method public blacklist setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V
    .registers 3
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 285
    .local p2, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    return-void
.end method

.method public blacklist setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V
    .registers 3
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 296
    .local p2, "rulesMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    return-void
.end method

.method public blacklist setEmbeddedContainerTask(II)V
    .registers 3
    .param p1, "embeddedTaskId"    # I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 955
    return-void
.end method

.method public blacklist setFlexibleFrame(ILandroid/os/Bundle;)V
    .registers 3
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 947
    return-void
.end method

.method public blacklist setFlexibleTaskEmbedding(IZ)V
    .registers 3
    .param p1, "taskId"    # I
    .param p2, "state"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 977
    return-void
.end method

.method public blacklist setFlexibleTaskEnabled(IZ)Z
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1131
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist setFocusAppForEmbeddedTask(I)V
    .registers 2
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 959
    return-void
.end method

.method public blacklist setGimbalLaunchPkg(Ljava/lang/String;)V
    .registers 2
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 384
    return-void
.end method

.method public blacklist setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V
    .registers 2
    .param p1, "config"    # Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 513
    return-void
.end method

.method public blacklist setInputConsumerEnabled(Z)V
    .registers 2
    .param p1, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 837
    return-void
.end method

.method public blacklist setIsInFocusAnimating(Z)V
    .registers 2
    .param p1, "isInFocusAnimating"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 950
    return-void
.end method

.method public blacklist setMinimizedPocketStudio(ZI)V
    .registers 3
    .param p1, "minimized"    # Z
    .param p2, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 940
    return-void
.end method

.method public blacklist setMirageDisplaySurfaceById(ILandroid/view/Surface;)V
    .registers 3
    .param p1, "displyId"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 560
    return-void
.end method

.method public blacklist setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V
    .registers 3
    .param p1, "mode"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 563
    return-void
.end method

.method public blacklist setMirageDisplayUserRotation(IILandroid/os/Bundle;)V
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "userRotation"    # I
    .param p3, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1225
    return-void
.end method

.method public blacklist setMirageWindowSilent(Ljava/lang/String;)V
    .registers 2
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 573
    return-void
.end method

.method public blacklist setPackagesState(Ljava/util/Map;)V
    .registers 2
    .param p1, "packageMap"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 390
    return-void
.end method

.method public blacklist setPermitList(IILjava/util/List;Z)V
    .registers 5
    .param p1, "mode"    # I
    .param p2, "type"    # I
    .param p4, "isMultiApp"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 316
    .local p3, "permits":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    return-void
.end method

.method public blacklist setRegionScreenshot(Z)V
    .registers 2
    .param p1, "following"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 347
    return-void
.end method

.method public blacklist setSecureController(Landroid/app/IActivityController;)V
    .registers 2
    .param p1, "controller"    # Landroid/app/IActivityController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 28
    return-void
.end method

.method public blacklist setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 411
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist setTaskInsensibleParams(Landroid/content/Intent;IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .param p3, "insensibleFlag"    # I
    .param p4, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 996
    return-void
.end method

.method public blacklist setTaskWindowingModeSplitScreen(I)I
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 443
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V
    .registers 2
    .param p1, "config"    # Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 208
    return-void
.end method

.method public blacklist shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z
    .registers 4
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "down"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 807
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist shouldSkipStartPocketStudio(Ljava/util/List;[I[ILandroid/os/Bundle;Landroid/os/Bundle;)Z
    .registers 7
    .param p2, "taskIdList"    # [I
    .param p3, "userIdList"    # [I
    .param p4, "activityBundle"    # Landroid/os/Bundle;
    .param p5, "canvasExtra"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/Intent;",
            ">;[I[I",
            "Landroid/os/Bundle;",
            "Landroid/os/Bundle;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1108
    .local p1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist splitScreenForApplication(Landroid/app/PendingIntent;I)Z
    .registers 4
    .param p1, "intent"    # Landroid/app/PendingIntent;
    .param p2, "position"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 473
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist splitScreenForEdgePanel(Landroid/content/Intent;I)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 302
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist splitScreenForEdgePanelExt(Landroid/content/Intent;ZI)Z
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "launchToPrimary"    # Z
    .param p3, "launchArea"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 450
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist splitScreenForRecentTasks(I)Z
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 439
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist splitScreenForTopApp(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 435
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startActivityFromRecentsForFlexible(ILandroid/os/Bundle;)I
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1138
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startActivityInTask(Landroid/content/Intent;I)V
    .registers 3
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 993
    return-void
.end method

.method public blacklist startAnyActivity(Landroid/content/Intent;Landroid/os/Bundle;)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 999
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 709
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startDragFullscreenAnimation(Landroid/os/Bundle;Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;)V
    .registers 3
    .param p1, "bOptions"    # Landroid/os/Bundle;
    .param p2, "callback"    # Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1027
    return-void
.end method

.method public blacklist startFlexibleWindowForRecentTasks(ILandroid/graphics/Rect;)Z
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "rect"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1003
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startLockDeviceMode(Ljava/lang/String;[Ljava/lang/String;)V
    .registers 3
    .param p1, "rootPkg"    # Ljava/lang/String;
    .param p2, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 237
    return-void
.end method

.method public blacklist startLockDeviceModeWithFlag(Ljava/lang/String;[Ljava/lang/String;I)V
    .registers 4
    .param p1, "rootPkg"    # Ljava/lang/String;
    .param p2, "packages"    # [Ljava/lang/String;
    .param p3, "flag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 258
    return-void
.end method

.method public blacklist startMiniZoomFromZoom(I)V
    .registers 2
    .param p1, "startWay"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 155
    return-void
.end method

.method public blacklist startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 546
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startMirageWindowModeWithName(Landroid/content/ComponentName;IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "cpnName"    # Landroid/content/ComponentName;
    .param p2, "taskId"    # I
    .param p3, "flags"    # I
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 543
    return-void
.end method

.method public blacklist startPutt(Lcom/oplus/putt/PuttParams;)Z
    .registers 3
    .param p1, "params"    # Lcom/oplus/putt/PuttParams;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 886
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startTaskToSplit(Landroid/content/Intent;ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .param p3, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 925
    return-void
.end method

.method public blacklist startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 111
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "pendingIntent"    # Landroid/app/PendingIntent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 116
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist stopLockDeviceMode()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 240
    return-void
.end method

.method public blacklist stopMirageWindowMode(Landroid/os/Bundle;)V
    .registers 2
    .param p1, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 557
    return-void
.end method

.method public blacklist stopMirageWindowModeOld()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 554
    return-void
.end method

.method public blacklist stopPutt(Ljava/lang/String;ILandroid/os/Bundle;)Z
    .registers 5
    .param p1, "puttHash"    # Ljava/lang/String;
    .param p2, "action"    # I
    .param p3, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 882
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist takeScreenshot(Landroid/window/WindowContainerToken;Landroid/view/SurfaceControl;)Landroid/view/SurfaceControl;
    .registers 4
    .param p1, "windowContainerToken"    # Landroid/window/WindowContainerToken;
    .param p2, "outSurfaceControl"    # Landroid/view/SurfaceControl;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 817
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist toggleFlexibleWindow(Ljava/lang/String;)Z
    .registers 3
    .param p1, "toType"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1208
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist toggleFlexibleWindowByApp(Landroid/os/IBinder;IZZ)Z
    .registers 6
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "taskId"    # I
    .param p3, "isNeedAnimation"    # Z
    .param p4, "isEnterZoom"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1212
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unRegisterRegionScreenshot(Ljava/lang/String;Z)Z
    .registers 4
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .param p2, "isBinderDied"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 362
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unbindQuickReplyService()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 796
    return-void
.end method

.method public blacklist unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 95
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 733
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 634
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/globaldrag/IDragAndDropListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 105
    return-void
.end method

.method public blacklist unregisterEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V
    .registers 3
    .param p1, "callback"    # Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1061
    return-void
.end method

.method public blacklist unregisterEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/os/IOplusTouchNodeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 676
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V
    .registers 2
    .param p1, "listener"    # Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1264
    return-void
.end method

.method public blacklist unregisterFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 909
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterKeyEventInterceptor(Ljava/lang/String;)Z
    .registers 3
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 502
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterKeyEventObserver(Ljava/lang/String;)Z
    .registers 3
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 330
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 401
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 531
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 523
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusTaskStackListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1200
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttEventObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 878
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 870
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 181
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 427
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V
    .registers 2
    .param p1, "observer"    # Lcom/oplus/app/IOplusStartingWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1306
    return-void
.end method

.method public blacklist unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 377
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusTaskInfoChangeListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1192
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterWindowChangeListener(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 4
    .param p1, "packageInfo"    # Ljava/lang/String;
    .param p2, "Sence"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1294
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 171
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1179
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 132
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 369
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z
    .registers 3
    .param p1, "list"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 611
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updateDeferStartingWindowApps(Ljava/util/List;Z)V
    .registers 3
    .param p2, "removeImmdiately"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 191
    .local p1, "packages":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    return-void
.end method

.method public blacklist updateLockTaskFeatures(II)V
    .registers 3
    .param p1, "userId"    # I
    .param p2, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1249
    return-void
.end method

.method public blacklist updateLockTaskPackages(I[Ljava/lang/String;)V
    .registers 3
    .param p1, "userId"    # I
    .param p2, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1252
    return-void
.end method

.method public blacklist updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z
    .registers 4
    .param p1, "castFlag"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 584
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updatePrivacyProtectionList(Ljava/util/List;Z)Z
    .registers 4
    .param p2, "append"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 588
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updatePrivacyProtectionListWithBundle(Ljava/util/List;ZZLandroid/os/Bundle;)Z
    .registers 6
    .param p2, "append"    # Z
    .param p3, "isDefault"    # Z
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ",
            "Landroid/os/Bundle;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 592
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist updateRecordSurfaceViewState(Landroid/os/IBinder;ZZ)V
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "surfaceState"    # Z
    .param p3, "attachedToWindow"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1091
    return-void
.end method

.method public blacklist updateTaskVisibility(Landroid/window/WindowContainerToken;IZZZLandroid/os/Bundle;)V
    .registers 7
    .param p1, "windowContainerToken"    # Landroid/window/WindowContainerToken;
    .param p2, "containerTaskId"    # I
    .param p3, "visible"    # Z
    .param p4, "skipBackToPrevTask"    # Z
    .param p5, "force"    # Z
    .param p6, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1102
    return-void
.end method

.method public blacklist updateUntrustedTouchConfig(Ljava/lang/String;Z)V
    .registers 3
    .param p1, "configData"    # Ljava/lang/String;
    .param p2, "isRus"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 689
    return-void
.end method

.method public blacklist writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z
    .registers 5
    .param p1, "callPkg"    # Ljava/lang/String;
    .param p2, "scenePkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 281
    .local p3, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist writeNodeFile(ILjava/lang/String;)Z
    .registers 4
    .param p1, "nodeFlag"    # I
    .param p2, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 649
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist writeNodeFileByDevice(IILjava/lang/String;)Z
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 653
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist writeNodeFileFromBt(IILjava/lang/String;)Z
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 661
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist writeNodeFileOneWay(IILjava/lang/String;)V
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 665
    return-void
.end method
