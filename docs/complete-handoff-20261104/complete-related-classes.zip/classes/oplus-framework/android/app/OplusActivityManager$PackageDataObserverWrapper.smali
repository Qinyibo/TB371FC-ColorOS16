.class Landroid/app/OplusActivityManager$PackageDataObserverWrapper;
.super Landroid/content/pm/IPackageDataObserver$Stub;
.source "OplusActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/OplusActivityManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "PackageDataObserverWrapper"
.end annotation


# instance fields
.field private final blacklist mObserver:Landroid/app/OplusActivityManager$IPackageDataObserver;


# direct methods
.method public constructor blacklist <init>(Landroid/app/OplusActivityManager$IPackageDataObserver;)V
    .registers 2
    .param p1, "observer"    # Landroid/app/OplusActivityManager$IPackageDataObserver;

    .line 338
    invoke-direct {p0}, Landroid/content/pm/IPackageDataObserver$Stub;-><init>()V

    .line 339
    iput-object p1, p0, Landroid/app/OplusActivityManager$PackageDataObserverWrapper;->mObserver:Landroid/app/OplusActivityManager$IPackageDataObserver;

    .line 340
    return-void
.end method


# virtual methods
.method public blacklist onRemoveCompleted(Ljava/lang/String;Z)V
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "succeeded"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 344
    iget-object v0, p0, Landroid/app/OplusActivityManager$PackageDataObserverWrapper;->mObserver:Landroid/app/OplusActivityManager$IPackageDataObserver;

    if-eqz v0, :cond_9

    .line 345
    iget-object v0, p0, Landroid/app/OplusActivityManager$PackageDataObserverWrapper;->mObserver:Landroid/app/OplusActivityManager$IPackageDataObserver;

    invoke-interface {v0, p1, p2}, Landroid/app/OplusActivityManager$IPackageDataObserver;->onRemoveCompleted(Ljava/lang/String;Z)V

    .line 347
    :cond_9
    return-void
.end method
