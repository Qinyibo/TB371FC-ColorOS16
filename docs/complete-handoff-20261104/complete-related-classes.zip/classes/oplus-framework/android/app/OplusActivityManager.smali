.class public Landroid/app/OplusActivityManager;
.super Ljava/lang/Object;
.source "OplusActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/app/OplusActivityManager$LazyHolder;,
        Landroid/app/OplusActivityManager$ITaskStackListenerWrapper;,
        Landroid/app/OplusActivityManager$PackageDataObserverWrapper;,
        Landroid/app/OplusActivityManager$IPackageDataObserver;,
        Landroid/app/OplusActivityManager$TaskSnapshotWrapper;
    }
.end annotation


# static fields
.field public static final whitelist COMPLEX_SCENE_FLOAT_WINDOW:I = 0x2

.field public static final whitelist COMPLEX_SCENE_FOCUS_CHANGED:I = 0x3

.field public static final whitelist COMPLEX_SCENE_SPLIT_SCREEN:I = 0x1

.field public static final whitelist FLAG_PROCOB_FGACTIVITY:I = 0x2

.field public static final whitelist FLAG_PROCOB_FGSERVICE:I = 0x4

.field public static final whitelist FLAG_PROCOB_PROC_DIED:I = 0x8

.field public static final whitelist FLAG_PROCOB_PROC_START:I = 0x1

.field private static final blacklist IOplusActivityManagerSingleton:Landroid/util/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Singleton<",
            "Landroid/app/IOplusActivityManager;",
            ">;"
        }
    .end annotation
.end field

.field public static final whitelist PAYJOY_OPEN:I = 0x1

.field private static final blacklist TAG:Ljava/lang/String; = "OplusActivityManager"


# instance fields
.field private final blacklist mOplusAtm:Landroid/app/OplusActivityTaskManager;

.field private final blacklist mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

.field private final blacklist mProcessObserverMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/oplus/wrapper/app/IProcessObserver;",
            "Landroid/app/IProcessObserver;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic blacklist $r8$lambda$FhW38koaD_m3YwPTV2FklwgKERw(Landroid/app/OplusActivityManager;Lcom/oplus/wrapper/app/IProcessObserver;)Landroid/app/IProcessObserver;
    .registers 2

    invoke-direct {p0, p1}, Landroid/app/OplusActivityManager;->lambda$registerProcessObserver$0(Lcom/oplus/wrapper/app/IProcessObserver;)Landroid/app/IProcessObserver;

    move-result-object p0

    return-object p0
.end method

.method static constructor blacklist <clinit>()V
    .registers 1

    .line 292
    new-instance v0, Landroid/app/OplusActivityManager$1;

    invoke-direct {v0}, Landroid/app/OplusActivityManager$1;-><init>()V

    sput-object v0, Landroid/app/OplusActivityManager;->IOplusActivityManagerSingleton:Landroid/util/Singleton;

    return-void
.end method

.method public constructor whitelist <init>()V
    .registers 2

    .line 350
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 309
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Landroid/app/OplusActivityManager;->mProcessObserverMap:Ljava/util/Map;

    .line 354
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getInstance()Landroid/app/OplusActivityTaskManager;

    move-result-object v0

    iput-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    .line 359
    invoke-static {}, Lcom/oplus/multiapp/OplusMultiAppManager;->getInstance()Lcom/oplus/multiapp/OplusMultiAppManager;

    move-result-object v0

    iput-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    .line 360
    return-void
.end method

.method private blacklist StringToSpareArrayLong(Ljava/lang/String;)Landroid/util/SparseArray;
    .registers 9
    .param p1, "spareArrayStr"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .line 2628
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    .line 2629
    .local v0, "sparray":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/Long;>;"
    const-string v1, "empty"

    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_47

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_14

    goto :goto_47

    .line 2633
    :cond_14
    :try_start_14
    const-string v1, ";"

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 2634
    .local v1, "spStrs":[Ljava/lang/String;
    if-nez v1, :cond_1d

    .line 2635
    return-object v0

    .line 2637
    :cond_1d
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1e
    array-length v3, v1

    if-ge v2, v3, :cond_44

    .line 2638
    aget-object v3, v1, v2

    const-string v4, "="

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 2639
    .local v3, "keyValue":[Ljava/lang/String;
    if-nez v3, :cond_2c

    .line 2640
    goto :goto_41

    .line 2642
    :cond_2c
    const/4 v4, 0x0

    aget-object v4, v3, v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const/4 v5, 0x1

    aget-object v5, v3, v5

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_41} :catch_45

    .line 2637
    .end local v3    # "keyValue":[Ljava/lang/String;
    :goto_41
    add-int/lit8 v2, v2, 0x1

    goto :goto_1e

    .line 2645
    .end local v1    # "spStrs":[Ljava/lang/String;
    .end local v2    # "i":I
    :cond_44
    goto :goto_46

    .line 2644
    :catch_45
    move-exception v1

    .line 2646
    :goto_46
    return-object v0

    .line 2630
    :cond_47
    :goto_47
    return-object v0
.end method

.method public static whitelist getFilteredTasks(IZ)Ljava/util/List;
    .registers 3
    .param p0, "num"    # I
    .param p1, "filterOnlyVisibleRecents"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .line 1131
    const/4 v0, 0x0

    .line 1137
    .local v0, "infos":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    return-object v0
.end method

.method public static whitelist getInstance()Landroid/app/OplusActivityManager;
    .registers 1

    .line 365
    invoke-static {}, Landroid/app/OplusActivityManager$LazyHolder;->-$$Nest$sfgetINSTANCE()Landroid/app/OplusActivityManager;

    move-result-object v0

    return-object v0
.end method

.method private static blacklist getService()Landroid/app/IOplusActivityManager;
    .registers 1

    .line 289
    sget-object v0, Landroid/app/OplusActivityManager;->IOplusActivityManagerSingleton:Landroid/util/Singleton;

    invoke-virtual {v0}, Landroid/util/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/IOplusActivityManager;

    return-object v0
.end method

.method private synthetic blacklist lambda$registerProcessObserver$0(Lcom/oplus/wrapper/app/IProcessObserver;)Landroid/app/IProcessObserver;
    .registers 3
    .param p1, "observer"    # Lcom/oplus/wrapper/app/IProcessObserver;

    .line 4300
    new-instance v0, Landroid/app/OplusActivityManager$3;

    invoke-direct {v0, p0, p1}, Landroid/app/OplusActivityManager$3;-><init>(Landroid/app/OplusActivityManager;Lcom/oplus/wrapper/app/IProcessObserver;)V

    return-object v0
.end method

.method public static whitelist registerTaskStackListener(Landroid/app/OplusActivityManager$ITaskStackListenerWrapper;)V
    .registers 5
    .param p0, "listener"    # Landroid/app/OplusActivityManager$ITaskStackListenerWrapper;

    .line 1103
    new-instance v0, Landroid/app/OplusActivityManager$2;

    invoke-direct {v0, p0}, Landroid/app/OplusActivityManager$2;-><init>(Landroid/app/OplusActivityManager$ITaskStackListenerWrapper;)V

    .line 1121
    .local v0, "taskStackListener":Landroid/app/TaskStackListener;
    :try_start_5
    invoke-static {}, Landroid/app/ActivityTaskManager;->getService()Landroid/app/IActivityTaskManager;

    move-result-object v1

    invoke-interface {v1, v0}, Landroid/app/IActivityTaskManager;->registerTaskStackListener(Landroid/app/ITaskStackListener;)V
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_5 .. :try_end_c} :catch_d

    .line 1124
    goto :goto_16

    .line 1122
    :catch_d
    move-exception v1

    .line 1123
    .local v1, "e":Landroid/os/RemoteException;
    const-string v2, "OplusActivityManager"

    const-string/jumbo v3, "registerTaskStackListener failed."

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1125
    .end local v1    # "e":Landroid/os/RemoteException;
    :goto_16
    return-void
.end method


# virtual methods
.method public whitelist activeGc([I)V
    .registers 4
    .param p1, "pids"    # [I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2403
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2404
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->activeGc([I)V

    goto :goto_15

    .line 2406
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcCmdline failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2408
    :goto_15
    return-void
.end method

.method public whitelist addBackgroundRestrictedInfo(Ljava/lang/String;Ljava/util/List;)V
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2125
    .local p2, "targetPkgList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2126
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->addBackgroundRestrictedInfo(Ljava/lang/String;Ljava/util/List;)V

    goto :goto_16

    .line 2128
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "removeFastAppThirdLogin failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2130
    :goto_16
    return-void
.end method

.method public blacklist addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3064
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v0

    return v0
.end method

.method public whitelist addFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "replacePkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2095
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2096
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->addFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 2098
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "addFastAppThirdLogin failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2100
    :goto_15
    return-void
.end method

.method public whitelist addFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "originAppCpn"    # Ljava/lang/String;
    .param p2, "fastAppCpn"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2052
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2053
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->addFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 2055
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "addFastAppWCPay failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2057
    :goto_15
    return-void
.end method

.method public blacklist addFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    .line 808
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "shareAppPkgName"    # Ljava/lang/String;
    .param p2, "miniProgramPkgName"    # Ljava/lang/String;
    .param p3, "miniProgramSignature"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2004
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2005
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 2007
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "addMiniProgramShare failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2009
    :goto_15
    return-void
.end method

.method public blacklist addOplusLoopLoadTime(JLjava/lang/String;)V
    .registers 6
    .param p1, "timeEnd"    # J
    .param p3, "msg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3559
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3560
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->addOplusLoopLoadTime(JLjava/lang/String;)V

    goto :goto_15

    .line 3562
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "get Looper cpu load failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3564
    :goto_15
    return-void
.end method

.method public blacklist addOrRemoveOplusVerifyCodeListener(ZLcom/oplus/verifycode/IOplusVerifyCodeListener;)Z
    .registers 5
    .param p1, "add"    # Z
    .param p2, "listener"    # Lcom/oplus/verifycode/IOplusVerifyCodeListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2983
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2984
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->addOrRemoveOplusVerifyCodeListener(ZLcom/oplus/verifycode/IOplusVerifyCodeListener;)Z

    move-result v0

    return v0

    .line 2986
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "addOrRemoveOplusVerifyCodeListener failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2988
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist addPreventIndulgeList(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2145
    .local p1, "pkgNames":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2146
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->addPreventIndulgeList(Ljava/util/List;)V

    goto :goto_15

    .line 2148
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "addPreventIndulgeList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2150
    :goto_15
    return-void
.end method

.method public whitelist addStageProtectInfo(Ljava/lang/String;Ljava/lang/String;J)V
    .registers 7
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "fromPkg"    # Ljava/lang/String;
    .param p3, "timeout"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1859
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "failed to add self-protect, pkg: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " fromPkg: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusSelfProtectManager"

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1860
    return-void
.end method

.method public whitelist addStageProtectInfo(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;JLcom/oplus/app/IOplusProtectConnection;)V
    .registers 17
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "protectPkg"    # Ljava/lang/String;
    .param p4, "reason"    # Ljava/lang/String;
    .param p5, "timeout"    # J
    .param p7, "connection"    # Lcom/oplus/app/IOplusProtectConnection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J",
            "Lcom/oplus/app/IOplusProtectConnection;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1865
    .local p3, "processList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 1866
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-wide v6, p5

    move-object/from16 v8, p7

    invoke-interface/range {v1 .. v8}, Landroid/app/IOplusActivityManager;->addStageProtectInfo(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;JLcom/oplus/app/IOplusProtectConnection;)V

    goto :goto_1c

    .line 1869
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "addStageProtectInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1871
    :goto_1c
    return-void
.end method

.method public blacklist addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1024
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 6
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 976
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 977
    return-void
.end method

.method public whitelist anrViaTheiaEvent(ILjava/lang/String;)V
    .registers 5
    .param p1, "pid"    # I
    .param p2, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2806
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2807
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->anrViaTheiaEvent(ILjava/lang/String;)V

    goto :goto_15

    .line 2809
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "anrViaTheiaEvent failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2811
    :goto_15
    return-void
.end method

.method public blacklist asyncReportDalvikMem(Landroid/os/Bundle;IJJJ)V
    .registers 19
    .param p1, "activityThread"    # Landroid/os/Bundle;
    .param p2, "pid"    # I
    .param p3, "dalvikMax"    # J
    .param p5, "dalvikUsed"    # J
    .param p7, "uptime"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3467
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 3468
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move v3, p2

    move-wide v4, p3

    move-wide v6, p5

    move-wide/from16 v8, p7

    invoke-interface/range {v1 .. v9}, Landroid/app/IOplusActivityManager;->asyncReportDalvikMem(Landroid/os/Bundle;IJJJ)V

    goto :goto_1b

    .line 3470
    :cond_14
    const-string v0, "OplusActivityManager"

    const-string v1, "asyncReportDalvikMem failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3472
    :goto_1b
    return-void
.end method

.method public blacklist asyncReportFrames(Ljava/lang/String;I)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "skippedFrames"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3204
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3205
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->asyncReportFrames(Ljava/lang/String;I)V

    goto :goto_15

    .line 3207
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "asyncReportFrames failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3209
    :goto_15
    return-void
.end method

.method public blacklist autoLayoutCall(Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 4
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3573
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3574
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->autoLayoutCall(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 3576
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "autoLayoutCall failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3578
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V
    .registers 3
    .param p1, "callback"    # Lcom/oplus/quickreply/IQuickReplyCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3091
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V

    .line 3092
    return-void
.end method

.method public whitelist callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 14
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "packageName"    # Ljava/lang/String;
    .param p3, "param1"    # I
    .param p4, "param2"    # Z
    .param p5, "param3"    # Ljava/lang/String;
    .param p6, "object"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3010
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    move-object v6, p6

    .end local p1    # "method":Ljava/lang/String;
    .end local p2    # "packageName":Ljava/lang/String;
    .end local p3    # "param1":I
    .end local p4    # "param2":Z
    .end local p5    # "param3":Ljava/lang/String;
    .end local p6    # "object":Landroid/os/Bundle;
    .local v1, "method":Ljava/lang/String;
    .local v2, "packageName":Ljava/lang/String;
    .local v3, "param1":I
    .local v4, "param2":Z
    .local v5, "param3":Ljava/lang/String;
    .local v6, "object":Landroid/os/Bundle;
    invoke-virtual/range {v0 .. v6}, Landroid/app/OplusActivityTaskManager;->callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object p1

    return-object p1
.end method

.method public whitelist cleanPackageResources(Ljava/lang/String;I)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3231
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3232
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->cleanPackageResources(Ljava/lang/String;I)V

    goto :goto_15

    .line 3234
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "cleanPackageResources failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3236
    :goto_15
    return-void
.end method

.method public whitelist clearApplicationUserData(Ljava/lang/String;ZLandroid/app/OplusActivityManager$IPackageDataObserver;I)Z
    .registers 7
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "keepState"    # Z
    .param p3, "observer"    # Landroid/app/OplusActivityManager$IPackageDataObserver;
    .param p4, "userId"    # I

    .line 3788
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_1e

    .line 3790
    const/4 v0, 0x0

    .line 3791
    .local v0, "packageDataObserver":Landroid/app/OplusActivityManager$PackageDataObserverWrapper;
    if-eqz p3, :cond_f

    .line 3792
    :try_start_9
    new-instance v1, Landroid/app/OplusActivityManager$PackageDataObserverWrapper;

    invoke-direct {v1, p3}, Landroid/app/OplusActivityManager$PackageDataObserverWrapper;-><init>(Landroid/app/OplusActivityManager$IPackageDataObserver;)V

    move-object v0, v1

    .line 3794
    :cond_f
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1, p2, v0, p4}, Landroid/app/IOplusActivityManager;->clearApplicationUserData(Ljava/lang/String;ZLandroid/content/pm/IPackageDataObserver;I)Z

    move-result v1
    :try_end_17
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_17} :catch_18

    return v1

    .line 3795
    .end local v0    # "packageDataObserver":Landroid/app/OplusActivityManager$PackageDataObserverWrapper;
    :catch_18
    move-exception v0

    .line 3796
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3799
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_1e
    const-string v0, "OplusActivityManager"

    const-string v1, "clearApplicationUserData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3801
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist clearFastStartConfig()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4112
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4113
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->clearFastStartConfig()Z

    move-result v0

    return v0

    .line 4115
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "clearFastStartConfig failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4116
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist clientTransactionComplete(Landroid/os/IBinder;I)V
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "seq"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2763
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->clientTransactionComplete(Landroid/os/IBinder;I)V

    .line 2764
    return-void
.end method

.method public whitelist compactProcess(Ljava/util/ArrayList;II)V
    .registers 6
    .param p2, "compactionFlags"    # I
    .param p3, "advice"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;II)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2892
    .local p1, "pids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_18

    .line 2893
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2894
    .local v0, "inBundle":Landroid/os/Bundle;
    const-string v1, "compactProcess"

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 2895
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, v0, p2, p3}, Landroid/app/IOplusActivityManager;->compactProcess(Landroid/os/Bundle;II)V

    .line 2896
    .end local v0    # "inBundle":Landroid/os/Bundle;
    goto :goto_1f

    .line 2897
    :cond_18
    const-string v0, "OplusActivityManager"

    const-string v1, "compactProcess failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2899
    :goto_1f
    return-void
.end method

.method public whitelist createMirageDisplay(Landroid/view/Surface;)I
    .registers 4
    .param p1, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1464
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager createMirageDisplay"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1465
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->createMirageDisplay(Landroid/view/Surface;)I

    move-result v0

    return v0
.end method

.method public blacklist createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;
    .registers 4
    .param p1, "callback"    # Lcom/oplus/miragewindow/IOplusMirageSessionCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1556
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager createMirageWindowSession"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1557
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;

    move-result-object v0

    return-object v0
.end method

.method public blacklist createVirtualDisplayDevice(Landroid/os/Bundle;)I
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1636
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->createVirtualDisplayDevice(Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public whitelist dismissSplitScreenMode(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1284
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->dismissSplitScreenMode(I)Z

    move-result v0

    return v0
.end method

.method public whitelist dumpProcPerfData(Landroid/os/Bundle;)Z
    .registers 4
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2307
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2308
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->dumpProcPerfData(Landroid/os/Bundle;)Z

    move-result v0

    return v0

    .line 2310
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "dumpProcPerfData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2312
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist enterFastFreezer(Ljava/lang/String;[IJLjava/lang/String;)V
    .registers 13
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "uids"    # [I
    .param p3, "timeout"    # J
    .param p5, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2603
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_12

    .line 2604
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move-object v3, p2

    move-wide v4, p3

    move-object v6, p5

    .end local p1    # "callerPkg":Ljava/lang/String;
    .end local p2    # "uids":[I
    .end local p3    # "timeout":J
    .end local p5    # "reason":Ljava/lang/String;
    .local v2, "callerPkg":Ljava/lang/String;
    .local v3, "uids":[I
    .local v4, "timeout":J
    .local v6, "reason":Ljava/lang/String;
    invoke-interface/range {v1 .. v6}, Landroid/app/IOplusActivityManager;->enterFastFreezer(Ljava/lang/String;[IJLjava/lang/String;)V

    goto :goto_1d

    .line 2606
    .end local v2    # "callerPkg":Ljava/lang/String;
    .end local v3    # "uids":[I
    .end local v4    # "timeout":J
    .end local v6    # "reason":Ljava/lang/String;
    .restart local p1    # "callerPkg":Ljava/lang/String;
    .restart local p2    # "uids":[I
    .restart local p3    # "timeout":J
    .restart local p5    # "reason":Ljava/lang/String;
    :cond_12
    move-object v2, p1

    move-object v3, p2

    move-wide v4, p3

    move-object v6, p5

    .end local p1    # "callerPkg":Ljava/lang/String;
    .end local p2    # "uids":[I
    .end local p3    # "timeout":J
    .end local p5    # "reason":Ljava/lang/String;
    .restart local v2    # "callerPkg":Ljava/lang/String;
    .restart local v3    # "uids":[I
    .restart local v4    # "timeout":J
    .restart local v6    # "reason":Ljava/lang/String;
    const-string p1, "OplusActivityManager"

    const-string p2, "enterFastFreezer failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2608
    :goto_1d
    return-void
.end method

.method public whitelist enterFastStart(Ljava/util/List;ILandroid/os/IBinder;)Z
    .registers 6
    .param p2, "duration"    # I
    .param p3, "binder"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I",
            "Landroid/os/IBinder;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4132
    .local p1, "pkgList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4133
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->enterFastStart(Ljava/util/List;ILandroid/os/IBinder;)Z

    move-result v0

    return v0

    .line 4135
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "enterFastStart failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4136
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist executeResPreload(Ljava/lang/String;IILjava/lang/String;)V
    .registers 7
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "preloadType"    # I
    .param p4, "preloadReason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2543
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2544
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityManager;->executeResPreload(Ljava/lang/String;IILjava/lang/String;)V

    goto :goto_15

    .line 2546
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "executeResPreload failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2548
    :goto_15
    return-void
.end method

.method public whitelist exitCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3025
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->exitCompactWindow()I

    move-result v0

    return v0
.end method

.method public whitelist exitFastFreezer(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2611
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2612
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->exitFastFreezer(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 2614
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "exitFastFreezer failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2616
    :goto_15
    return-void
.end method

.method public whitelist exitFastStart(Landroid/os/IBinder;)Z
    .registers 4
    .param p1, "binder"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4166
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4167
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->exitFastStart(Landroid/os/IBinder;)Z

    move-result v0

    return v0

    .line 4169
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "exitFastStart failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4170
    const/4 v0, 0x0

    return v0
.end method

.method public final whitelist exitOplusosFreeform(Landroid/os/Bundle;)V
    .registers 2
    .param p1, "bOptions"    # Landroid/os/Bundle;

    .line 878
    return-void
.end method

.method public whitelist expandToFullScreen()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1517
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager expandTofullscreen"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1518
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->expandToFullScreen()V

    .line 1519
    return-void
.end method

.method public whitelist favoriteQueryRule(Ljava/lang/String;Lcom/oplus/favorite/IOplusFavoriteQueryCallback;)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/favorite/IOplusFavoriteQueryCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2115
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2116
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->favoriteQueryRule(Ljava/lang/String;Lcom/oplus/favorite/IOplusFavoriteQueryCallback;)V

    goto :goto_15

    .line 2118
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "favoriteQueryRule failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2120
    :goto_15
    return-void
.end method

.method public whitelist feedbackUserSelection(IILandroid/os/Bundle;)V
    .registers 6
    .param p1, "eventId"    # I
    .param p2, "selection"    # I
    .param p3, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1566
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager feedbackUserSelection"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1567
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->feedbackUserSelection(IILandroid/os/Bundle;)V

    .line 1568
    return-void
.end method

.method public blacklist finishFlexibleActivityOnTouchOutside(Landroid/os/IBinder;)Z
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3633
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3634
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->finishFlexibleActivityOnTouchOutside(Landroid/os/IBinder;)Z

    move-result v0

    return v0

    .line 3636
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "finishFlexibleActivityOnTouchOutside failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3638
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist finishNotOrderReceiver(Landroid/os/IBinder;IILjava/lang/String;Landroid/os/Bundle;Z)V
    .registers 15
    .param p1, "who"    # Landroid/os/IBinder;
    .param p2, "hasCode"    # I
    .param p3, "resultCode"    # I
    .param p4, "resultData"    # Ljava/lang/String;
    .param p5, "resultExtras"    # Landroid/os/Bundle;
    .param p6, "resultAbort"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2414
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 2415
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p5

    move v7, p6

    .end local p1    # "who":Landroid/os/IBinder;
    .end local p2    # "hasCode":I
    .end local p3    # "resultCode":I
    .end local p4    # "resultData":Ljava/lang/String;
    .end local p5    # "resultExtras":Landroid/os/Bundle;
    .end local p6    # "resultAbort":Z
    .local v2, "who":Landroid/os/IBinder;
    .local v3, "hasCode":I
    .local v4, "resultCode":I
    .local v5, "resultData":Ljava/lang/String;
    .local v6, "resultExtras":Landroid/os/Bundle;
    .local v7, "resultAbort":Z
    invoke-interface/range {v1 .. v7}, Landroid/app/IOplusActivityManager;->finishNotOrderReceiver(Landroid/os/IBinder;IILjava/lang/String;Landroid/os/Bundle;Z)V

    goto :goto_21

    .line 2417
    .end local v2    # "who":Landroid/os/IBinder;
    .end local v3    # "hasCode":I
    .end local v4    # "resultCode":I
    .end local v5    # "resultData":Ljava/lang/String;
    .end local v6    # "resultExtras":Landroid/os/Bundle;
    .end local v7    # "resultAbort":Z
    .restart local p1    # "who":Landroid/os/IBinder;
    .restart local p2    # "hasCode":I
    .restart local p3    # "resultCode":I
    .restart local p4    # "resultData":Ljava/lang/String;
    .restart local p5    # "resultExtras":Landroid/os/Bundle;
    .restart local p6    # "resultAbort":Z
    :cond_14
    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p5

    move v7, p6

    .end local p1    # "who":Landroid/os/IBinder;
    .end local p2    # "hasCode":I
    .end local p3    # "resultCode":I
    .end local p4    # "resultData":Ljava/lang/String;
    .end local p5    # "resultExtras":Landroid/os/Bundle;
    .end local p6    # "resultAbort":Z
    .restart local v2    # "who":Landroid/os/IBinder;
    .restart local v3    # "hasCode":I
    .restart local v4    # "resultCode":I
    .restart local v5    # "resultData":Ljava/lang/String;
    .restart local v6    # "resultExtras":Landroid/os/Bundle;
    .restart local v7    # "resultAbort":Z
    const-string p1, "OplusActivityManager"

    const-string p2, "getProcCmdline failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2419
    :goto_21
    return-void
.end method

.method public whitelist forceStopPackageAndSaveActivity(Ljava/lang/String;I)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3239
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3240
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->forceStopPackageAndSaveActivity(Ljava/lang/String;I)V

    goto :goto_15

    .line 3242
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "forceStopPackageAndSaveActivity failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3244
    :goto_15
    return-void
.end method

.method public whitelist forceTrimAppMemory(I)V
    .registers 4
    .param p1, "level"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2245
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2246
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->forceTrimAppMemory(I)V

    goto :goto_15

    .line 2248
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "forceTrimAppMemory failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2250
    :goto_15
    return-void
.end method

.method public whitelist gameBgPureModeSwitch(Z)Z
    .registers 4
    .param p1, "on"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4239
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4240
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->gameBgPureModeSwitch(Z)Z

    move-result v0

    return v0

    .line 4242
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "gameBgPureModeSwitch failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4243
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist getAccidentallyTouchData()Lcom/oplus/util/OplusAccidentallyTouchData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1811
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1812
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getAccidentallyTouchData()Lcom/oplus/util/OplusAccidentallyTouchData;

    move-result-object v0

    return-object v0

    .line 1814
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getAccidentallyTouchData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1816
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getAllDarkModeData()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/darkmode/OplusDarkModeData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2294
    const/4 v0, 0x0

    .line 2295
    .local v0, "darkModeData":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/darkmode/OplusDarkModeData;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_10

    .line 2296
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/app/IOplusActivityManager;->getAllDarkModeData()Ljava/util/List;

    move-result-object v0

    goto :goto_17

    .line 2298
    :cond_10
    const-string v1, "OplusActivityManager"

    const-string v2, "getAllDarkModeData failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2300
    :goto_17
    return-object v0
.end method

.method public whitelist getAllTopAppInfos()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/app/OplusAppInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 789
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getAllTopAppInfos()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getAllTopPkgName()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 859
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getAllVisibleTasksInfo(I)Ljava/util/List;
    .registers 4
    .param p1, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RecentTaskInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2794
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2795
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getAllVisibleTasksInfo(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2797
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getTrafficPacketList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2799
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "change"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2885
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getCompatModeSession()Lcom/oplus/compatmode/IOplusCompatModeSession;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3307
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3308
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getCompatModeSession()Lcom/oplus/compatmode/IOplusCompatModeSession;

    move-result-object v0

    return-object v0

    .line 3310
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getCompatModeSession failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3312
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getConfigInfo(Ljava/lang/String;II)Landroid/os/Bundle;
    .registers 6
    .param p1, "configName"    # Ljava/lang/String;
    .param p2, "flag"    # I
    .param p3, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2167
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2168
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->getConfigInfo(Ljava/lang/String;II)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 2170
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "putConfigInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2172
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    return-object v0
.end method

.method public whitelist getConfineMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1209
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getConfineMode()I

    move-result v0

    return v0
.end method

.method public whitelist getCpuLimitLatestInfos(Ljava/lang/String;)Landroid/os/SharedMemory;
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2204
    const/4 v0, 0x0

    .line 2205
    .local v0, "infos":Landroid/os/SharedMemory;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_10

    .line 2206
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1}, Landroid/app/IOplusActivityManager;->getCpuLimitLatestLogs(Ljava/lang/String;)Landroid/os/SharedMemory;

    move-result-object v0

    goto :goto_17

    .line 2208
    :cond_10
    const-string v1, "OplusActivityManager"

    const-string v2, "getCpuLimitLatestLogs failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2211
    :goto_17
    return-object v0
.end method

.method public whitelist getCpuTotalLoad()J
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2219
    const-wide/16 v0, 0x1

    .line 2220
    .local v0, "percent":J
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_11

    .line 2221
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    invoke-interface {v2}, Landroid/app/IOplusActivityManager;->getTotalCpuLoadPercent()J

    move-result-wide v0

    goto :goto_18

    .line 2223
    :cond_11
    const-string v2, "OplusActivityManager"

    const-string v3, "getTotalCpuLoadPercent failed because service has not been created"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2226
    :goto_18
    return-wide v0
.end method

.method public whitelist getCpuWorkingStats()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2191
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2192
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getCpuWorkingStats()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2194
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "putConfigInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2196
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getCurrentUser()I
    .registers 3

    .line 3812
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3814
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getCurrentUser()I

    move-result v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return v0

    .line 3815
    :catch_f
    move-exception v0

    .line 3816
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3819
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "getCurrentUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3821
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 920
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getDarkModeData(Ljava/lang/String;)Lcom/oplus/darkmode/OplusDarkModeData;
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2277
    const/4 v0, 0x0

    .line 2278
    .local v0, "darkModeData":Lcom/oplus/darkmode/OplusDarkModeData;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_10

    .line 2279
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1}, Landroid/app/IOplusActivityManager;->getDarkModeData(Ljava/lang/String;)Lcom/oplus/darkmode/OplusDarkModeData;

    move-result-object v0

    goto :goto_17

    .line 2281
    :cond_10
    const-string v1, "OplusActivityManager"

    const-string v2, "getDarkModeData failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2283
    :goto_17
    return-object v0
.end method

.method public whitelist getDisplayCompatData()Lcom/oplus/util/OplusDisplayCompatData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1936
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1937
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getDisplayCompatData()Lcom/oplus/util/OplusDisplayCompatData;

    move-result-object v0

    return-object v0

    .line 1939
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getDisplayCompatData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1941
    new-instance v0, Lcom/oplus/util/OplusDisplayCompatData;

    invoke-direct {v0}, Lcom/oplus/util/OplusDisplayCompatData;-><init>()V

    return-object v0
.end method

.method public whitelist getDisplayOptimizationData()Lcom/oplus/util/OplusDisplayOptimizationData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
        since = "No longer use"
    .end annotation

    .line 1887
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1888
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getDisplayOptimizationData()Lcom/oplus/util/OplusDisplayOptimizationData;

    move-result-object v0

    return-object v0

    .line 1890
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getDisplayOptimizationData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1892
    new-instance v0, Lcom/oplus/util/OplusDisplayOptimizationData;

    invoke-direct {v0}, Lcom/oplus/util/OplusDisplayOptimizationData;-><init>()V

    return-object v0
.end method

.method public whitelist getDockTopAppName()Landroid/content/ComponentName;
    .registers 2

    .line 850
    const/4 v0, 0x0

    .line 851
    .local v0, "cn":Landroid/content/ComponentName;
    return-object v0
.end method

.method public whitelist getDownloadingList(IZ)Ljava/util/List;
    .registers 5
    .param p1, "thresholdSpeed"    # I
    .param p2, "rough"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2914
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2915
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getDownloadingList(IZ)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2917
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getDownloadingList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2919
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getFastAppReplacePkg(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p1, "callerPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3532
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3533
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getFastAppReplacePkg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 3535
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getFastAppReplacePkg failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3537
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getFocusBounds(Z)Landroid/graphics/Rect;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2998
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getFocusBounds(Z)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getFocusComponent(Z)Landroid/content/ComponentName;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3002
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getFocusComponent(Z)Landroid/content/ComponentName;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getFocusMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2994
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getFocusMode()I

    move-result v0

    return v0
.end method

.method public whitelist getFontVariationAdaption(Ljava/lang/String;)I
    .registers 3
    .param p1, "packagename"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1227
    invoke-virtual {p0, p1}, Landroid/app/OplusActivityManager;->getFontVariationAdaptionData(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist getFontVariationAdaptionData(Ljava/lang/String;)I
    .registers 4
    .param p1, "packagename"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2483
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2484
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getFontVariationAdaptionData(Ljava/lang/String;)I

    move-result v0

    return v0

    .line 2486
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getFontVariationAdaptionData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2488
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist getFreeFormAppInfo()Landroid/content/pm/ApplicationInfo;
    .registers 2

    .line 865
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getFreeformConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 794
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getGetDisplayIdForPackageName(Ljava/lang/String;)I
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1561
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager getGetDisplayIdForPackageName"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1562
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getGetDisplayIdForPackageName(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1435
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getGlobalPkgWhiteList(I)Ljava/util/List;
    .registers 4
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1836
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1837
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getGlobalPkgWhiteList(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 1839
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getGlobalPkgWhiteList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1841
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getGlobalProcessWhiteList()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1845
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1846
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getGlobalProcessWhiteList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 1848
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getGlobalProcessWhiteList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1850
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getIsSupportMultiApp()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1946
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0}, Lcom/oplus/multiapp/OplusMultiAppManager;->isMultiAppSupport()Z

    move-result v0

    return v0
.end method

.method public blacklist getLastEvent()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/graphics/Point;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1399
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getLastEvent()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getLeftRightBoundsForIme()Landroid/os/Bundle;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1346
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getLeftRightBoundsForIme()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getLoopCpuLoad()I
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3547
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3548
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getLoopCpuLoad()I

    move-result v0

    return v0

    .line 3550
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "get Looper cpu load failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3552
    const/4 v0, -0x1

    return v0
.end method

.method public whitelist getMinimizedBounds(I)Landroid/graphics/Rect;
    .registers 3
    .param p1, "dockedSide"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1330
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getMinimizedBounds(I)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMirageDisplayCastMode(I)I
    .registers 4
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1512
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager getMirageDisplayCastMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1513
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getMirageDisplayCastMode(I)I

    move-result v0

    return v0
.end method

.method public whitelist getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1532
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager getMirageWindowInfo"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1533
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMultiAppAccessMode(Ljava/lang/String;)I
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1976
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMultiAppAccessMode(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist getMultiAppAlias(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1954
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMultiAppAlias(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMultiAppAllAccessMode()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1981
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMultiAppAllAccessMode()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMultiAppConfig()Lcom/oplus/multiapp/OplusMultiAppConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1962
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMultiAppConfig()Lcom/oplus/multiapp/OplusMultiAppConfig;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMultiAppList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1950
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMultiAppList(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMultiAppMaxCreateNum()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1994
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0}, Lcom/oplus/multiapp/OplusMultiAppManager;->getMaxCreateNum()I

    move-result v0

    return v0
.end method

.method public blacklist getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2787
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getNavbarSettingsConfigs()Landroid/os/Bundle;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4379
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getNavbarSettingsConfigs()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPWAppInfo()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3049
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getPWAppInfo()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPackageFreezeDataInfos(Ljava/util/List;)Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2953
    .local p1, "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_25

    .line 2954
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2955
    .local v0, "inBundle":Landroid/os/Bundle;
    const/4 v1, 0x0

    .line 2956
    .local v1, "temp":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    if-eqz p1, :cond_17

    .line 2957
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v2

    .line 2958
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 2960
    :cond_17
    const-string v2, "getPackageFreezeDataInfos"

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 2961
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    invoke-interface {v2, v0}, Landroid/app/IOplusActivityManager;->getPackageFreezeDataInfos(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object v2

    return-object v2

    .line 2963
    .end local v0    # "inBundle":Landroid/os/Bundle;
    .end local v1    # "temp":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    :cond_25
    const-string v0, "OplusActivityManager"

    const-string v1, "getPackageFreezeDataInfos failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2965
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getPackagesState()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1248
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getPackagesState()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPayJoyFlag()I
    .registers 3

    .line 3713
    :try_start_0
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getPayJoyFlag()I

    move-result v0
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_8} :catch_9

    return v0

    .line 3714
    :catch_9
    move-exception v0

    .line 3715
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public whitelist getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2589
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2590
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2592
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getPkgPreloadFiles failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2594
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPreloadIOSize()J
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2559
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2560
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getPreloadIOSize()J

    move-result-wide v0

    return-wide v0

    .line 2562
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getResPreloadInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2564
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public whitelist getPreloadPkgList()Landroid/os/Bundle;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2580
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2581
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getPreloadPkgList()Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 2583
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getPreloadPkgList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2585
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    return-object v0
.end method

.method public whitelist getPreloadStatus(Ljava/lang/String;I)Z
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2568
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2569
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getPreloadStatus(Ljava/lang/String;I)Z

    move-result v0

    return v0

    .line 2571
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getResPreloadInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2573
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist getProcCmdline([I)Ljava/util/List;
    .registers 4
    .param p1, "pids"    # [I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2388
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_18

    .line 2389
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getProcCmdline([I)Ljava/util/List;

    move-result-object v0

    .line 2390
    .local v0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz v0, :cond_17

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-eqz v1, :cond_17

    .line 2391
    return-object v0

    .line 2393
    .end local v0    # "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :cond_17
    goto :goto_1f

    .line 2394
    :cond_18
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcCmdline failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2396
    :goto_1f
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getProcCommonInfoList(I)Ljava/util/List;
    .registers 4
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2320
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2321
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getProcCommonInfoList(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2323
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcCommonInfoList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2325
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getProcDependency(I)Ljava/util/List;
    .registers 4
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusProcDependData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2332
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2333
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getProcDependency(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2335
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcDependency failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2337
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getProcDependency(Ljava/lang/String;I)Ljava/util/List;
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusProcDependData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2341
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2342
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getProcDependencyByUserId(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2344
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcDependency failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2346
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;
    .registers 4
    .param p1, "pids"    # [I

    .line 3855
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3857
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;

    move-result-object v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return-object v0

    .line 3858
    :catch_f
    move-exception v0

    .line 3859
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3862
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "getProcessMemoryInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3864
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getRealSize()Landroid/graphics/Point;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3006
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getRealSize()Landroid/graphics/Point;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getReflectData()Lcom/oplus/util/OplusReflectData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2040
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2041
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getReflectData()Lcom/oplus/util/OplusReflectData;

    move-result-object v0

    return-object v0

    .line 2043
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getReflectData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2045
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getRenderThreadTid(I)I
    .registers 3
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 958
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getRenderThreadTid(I)I

    move-result v0

    return v0
.end method

.method public whitelist getResPreloadInfo(II)Landroid/os/Bundle;
    .registers 5
    .param p1, "days"    # I
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2551
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2552
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getResPreloadInfo(II)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 2554
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getResPreloadInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2556
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    return-object v0
.end method

.method public whitelist getResolveData()Lcom/oplus/util/OplusResolveData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2026
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2027
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getResolveData()Lcom/oplus/util/OplusResolveData;

    move-result-object v0

    return-object v0

    .line 2029
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getResolveData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2031
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getRunningAppProcessInfos(Ljava/util/List;)Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningAppProcessInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2936
    .local p1, "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_25

    .line 2937
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2938
    .local v0, "inBundle":Landroid/os/Bundle;
    const/4 v1, 0x0

    .line 2939
    .local v1, "temp":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    if-eqz p1, :cond_17

    .line 2940
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v2

    .line 2941
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 2943
    :cond_17
    const-string v2, "getRunningAppProcessInfos"

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 2944
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    invoke-interface {v2, v0}, Landroid/app/IOplusActivityManager;->getRunningAppProcessInfos(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object v2

    return-object v2

    .line 2946
    .end local v0    # "inBundle":Landroid/os/Bundle;
    .end local v1    # "temp":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    :cond_25
    const-string v0, "OplusActivityManager"

    const-string v1, "getRunningAppProcessInfos failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2948
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getRunningAppProcesses()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningAppProcessInfo;",
            ">;"
        }
    .end annotation

    .line 3877
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3879
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return-object v0

    .line 3880
    :catch_f
    move-exception v0

    .line 3881
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3884
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "getRunningAppProcesses failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3886
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getRunningPidsByUid(I)[I
    .registers 4
    .param p1, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3247
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3248
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getRunningPidsByUid(I)[I

    move-result-object v0

    return-object v0

    .line 3250
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getRunningPidsByUid failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3251
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getRunningProcesses()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2072
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2073
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getRunningProcesses()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2075
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "removeFastAppWCPay failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2077
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getRunningServices(I)Ljava/util/List;
    .registers 4
    .param p1, "maxNum"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningServiceInfo;",
            ">;"
        }
    .end annotation

    .line 3922
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3924
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return-object v0

    .line 3925
    :catch_f
    move-exception v0

    .line 3926
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3929
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "getRunningServices failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3931
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getRunningTasks(I)Ljava/util/List;
    .registers 4
    .param p1, "maxValue"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .line 3764
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3766
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getRunningTasks(I)Ljava/util/List;

    move-result-object v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return-object v0

    .line 3767
    :catch_f
    move-exception v0

    .line 3768
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3771
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string v1, "getRunningTasks failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3773
    const/4 v0, 0x0

    return-object v0
.end method

.method public blacklist getSecureKeyboardData()Lcom/oplus/util/OplusSecureKeyboardData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1902
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1903
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getSecureKeyboardData()Lcom/oplus/util/OplusSecureKeyboardData;

    move-result-object v0

    return-object v0

    .line 1905
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getSecureKeyboardData failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1907
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getSecurityFlagCurrentPage()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2827
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager getSecurityFlagCurrentPage"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 2828
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getSecurityFlagCurrentPage()Z

    move-result v0

    return v0
.end method

.method public blacklist getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1336
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getSplitScreenState(Landroid/content/Intent;)I
    .registers 3
    .param p1, "intent"    # Landroid/content/Intent;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 840
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getSplitScreenState(Landroid/content/Intent;)I

    move-result v0

    return v0
.end method

.method public whitelist getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 3
    .param p1, "event"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1296
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getStageProtectList(I)Ljava/util/List;
    .registers 4
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2844
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2845
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getStageProtectList(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2847
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStageProtectList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2849
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getStageProtectListAsUser(II)Ljava/util/List;
    .registers 5
    .param p1, "type"    # I
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2853
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2854
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getStageProtectListAsUser(II)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2856
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStageProtectListAsUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2858
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/List;
    .registers 5
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1914
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1915
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 1917
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStageProtectListFromPkg failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1919
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getStageProtectListFromPkgAsUser(Ljava/lang/String;II)Ljava/util/List;
    .registers 6
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "type"    # I
    .param p3, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "II)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2836
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2837
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->getStageProtectListFromPkgAsUser(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2839
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStageProtectListFromPkgAsUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2841
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getStartPermission(Ljava/util/List;)Landroid/os/Bundle;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Landroid/os/Bundle;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4075
    .local p1, "packageList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4076
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getStartPermission(Ljava/util/List;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 4078
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStartPermission failed"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4079
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    return-object v0
.end method

.method public blacklist getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;
    .registers 4
    .param p1, "name"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1472
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager getTaskInfo"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1473
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTaskPkgList(I)Ljava/util/List;
    .registers 4
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2350
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2351
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->getTaskPkgList(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2353
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getTaskPkgList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2355
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getTerminateObservers()[I
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3419
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3420
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getTerminateObservers()[I

    move-result-object v0

    return-object v0

    .line 3422
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getTerminateObservers failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3423
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getTopActivityComponentName()Landroid/content/ComponentName;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 777
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getTopActivityComponentName()Landroid/content/ComponentName;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 782
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTopPidsLoadInfos(I)Ljava/util/List;
    .registers 5
    .param p1, "topNum"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2231
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2232
    .local v0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_14

    .line 2233
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1}, Landroid/app/IOplusActivityManager;->getTopLoadPidsInfos(I)Ljava/util/List;

    move-result-object v0

    goto :goto_1b

    .line 2235
    :cond_14
    const-string v1, "OplusActivityManager"

    const-string v2, "getTopLoadPidsInfos failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2238
    :goto_1b
    return-object v0
.end method

.method public whitelist getTrafficBytesList(Ljava/util/ArrayList;)Landroid/util/SparseArray;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2649
    .local p1, "uids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_22

    .line 2650
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2651
    .local v0, "inBundle":Landroid/os/Bundle;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 2652
    .local v1, "outBundle":Landroid/os/Bundle;
    const-string v2, "getTrafficBytesList"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 2653
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    invoke-interface {v2, v0, v1}, Landroid/app/IOplusActivityManager;->getTrafficBytesList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    .line 2654
    .local v2, "spareArrayStr":Ljava/lang/String;
    invoke-direct {p0, v2}, Landroid/app/OplusActivityManager;->StringToSpareArrayLong(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v3

    return-object v3

    .line 2656
    .end local v0    # "inBundle":Landroid/os/Bundle;
    .end local v1    # "outBundle":Landroid/os/Bundle;
    .end local v2    # "spareArrayStr":Ljava/lang/String;
    :cond_22
    const-string v0, "OplusActivityManager"

    const-string v1, "getTrafficBytesList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2658
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getTrafficPacketList(Ljava/util/ArrayList;)Landroid/util/SparseArray;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2662
    .local p1, "uids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_22

    .line 2663
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2664
    .local v0, "inBundle":Landroid/os/Bundle;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 2665
    .local v1, "outBundle":Landroid/os/Bundle;
    const-string v2, "getTrafficPacketList"

    invoke-virtual {v0, v2, p1}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 2666
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    invoke-interface {v2, v0, v1}, Landroid/app/IOplusActivityManager;->getTrafficPacketList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    .line 2667
    .local v2, "spareArrayStr":Ljava/lang/String;
    invoke-direct {p0, v2}, Landroid/app/OplusActivityManager;->StringToSpareArrayLong(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v3

    return-object v3

    .line 2669
    .end local v0    # "inBundle":Landroid/os/Bundle;
    .end local v1    # "outBundle":Landroid/os/Bundle;
    .end local v2    # "spareArrayStr":Ljava/lang/String;
    :cond_22
    const-string v0, "OplusActivityManager"

    const-string v1, "getTrafficPacketList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2671
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getTsaInfo(Ljava/lang/String;IJJ)Landroid/os/Bundle;
    .registers 15
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "tid"    # I
    .param p3, "startNanoTime"    # J
    .param p5, "endNanoTime"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4054
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 4055
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move v3, p2

    move-wide v4, p3

    move-wide v6, p5

    .end local p1    # "packageName":Ljava/lang/String;
    .end local p2    # "tid":I
    .end local p3    # "startNanoTime":J
    .end local p5    # "endNanoTime":J
    .local v2, "packageName":Ljava/lang/String;
    .local v3, "tid":I
    .local v4, "startNanoTime":J
    .local v6, "endNanoTime":J
    invoke-interface/range {v1 .. v7}, Landroid/app/IOplusActivityManager;->getTsaInfo(Ljava/lang/String;IJJ)Landroid/os/Bundle;

    move-result-object p1

    return-object p1

    .line 4057
    .end local v2    # "packageName":Ljava/lang/String;
    .end local v3    # "tid":I
    .end local v4    # "startNanoTime":J
    .end local v6    # "endNanoTime":J
    .restart local p1    # "packageName":Ljava/lang/String;
    .restart local p2    # "tid":I
    .restart local p3    # "startNanoTime":J
    .restart local p5    # "endNanoTime":J
    :cond_13
    move-object v2, p1

    move v3, p2

    .end local p1    # "packageName":Ljava/lang/String;
    .end local p2    # "tid":I
    .restart local v2    # "packageName":Ljava/lang/String;
    .restart local v3    # "tid":I
    const-string p1, "OplusActivityManager"

    const-string p2, "getTsaInfo failed"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4058
    const/4 p1, 0x0

    return-object p1
.end method

.method public whitelist getUXIconData()Lcom/oplus/util/OplusUXIconData;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2866
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2867
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getUXIconData()Lcom/oplus/util/OplusUXIconData;

    move-result-object v0

    return-object v0

    .line 2869
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getStageProtectListAsUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2871
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getUidCpuWorkingStats()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2378
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2379
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->getUidCpuWorkingStats()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 2381
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "getUidCpuWorkingStats failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2383
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getZoomAppConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 928
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->getZoomAppConfigList(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomBounds(ZI)Landroid/graphics/Rect;
    .registers 4
    .param p1, "landApp"    # Z
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3725
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->getZoomBounds(ZI)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomBoundsByTaskId(II)Landroid/graphics/Rect;
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3735
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->getZoomBoundsByTaskId(II)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 949
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1006
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    move-result-object v0

    return-object v0
.end method

.method public whitelist grantOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1783
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1784
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->grantOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 1786
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "grantOplusPermissionByGroup failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1788
    :goto_15
    return-void
.end method

.method public greylist grantUriPermissionToUser(Landroid/content/Context;Ljava/lang/String;Landroid/net/Uri;II)V
    .registers 12
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "targetPkg"    # Ljava/lang/String;
    .param p3, "uri"    # Landroid/net/Uri;
    .param p4, "modeFlags"    # I
    .param p5, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3590
    invoke-virtual {p1}, Landroid/content/Context;->getIApplicationThread()Landroid/app/IApplicationThread;

    move-result-object v1

    .line 3591
    .local v1, "caller":Landroid/app/IApplicationThread;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_16

    .line 3592
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move v5, p5

    .end local p2    # "targetPkg":Ljava/lang/String;
    .end local p3    # "uri":Landroid/net/Uri;
    .end local p4    # "modeFlags":I
    .end local p5    # "userId":I
    .local v2, "targetPkg":Ljava/lang/String;
    .local v3, "uri":Landroid/net/Uri;
    .local v4, "modeFlags":I
    .local v5, "userId":I
    invoke-interface/range {v0 .. v5}, Landroid/app/IOplusActivityManager;->grantUriPermissionToUser(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/net/Uri;II)V

    goto :goto_21

    .line 3594
    .end local v2    # "targetPkg":Ljava/lang/String;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v4    # "modeFlags":I
    .end local v5    # "userId":I
    .restart local p2    # "targetPkg":Ljava/lang/String;
    .restart local p3    # "uri":Landroid/net/Uri;
    .restart local p4    # "modeFlags":I
    .restart local p5    # "userId":I
    :cond_16
    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move v5, p5

    .end local p2    # "targetPkg":Ljava/lang/String;
    .end local p3    # "uri":Landroid/net/Uri;
    .end local p4    # "modeFlags":I
    .end local p5    # "userId":I
    .restart local v2    # "targetPkg":Ljava/lang/String;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v4    # "modeFlags":I
    .restart local v5    # "userId":I
    const-string p2, "OplusActivityManager"

    const-string p3, "grantUriPermissionToUser failed because service has not been created"

    invoke-static {p2, p3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3596
    :goto_21
    return-void
.end method

.method public whitelist handleAppForNotification(Ljava/lang/String;II)V
    .registers 6
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .param p3, "otherInfo"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1799
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1800
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->handleAppForNotification(Ljava/lang/String;II)V

    goto :goto_16

    .line 1802
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "revokeOplusPermissionByGroup failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1804
    :goto_16
    return-void
.end method

.method public whitelist handleAppFromControlCenter(Ljava/lang/String;I)V
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1925
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1926
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->handleAppFromControlCenter(Ljava/lang/String;I)V

    goto :goto_15

    .line 1928
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "handleAppFromControlCenter failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1930
    :goto_15
    return-void
.end method

.method public whitelist handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z
    .registers 12
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .param p5, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 998
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    .end local p1    # "target":Ljava/lang/String;
    .end local p2    # "userId":I
    .end local p3    # "callPkg":Ljava/lang/String;
    .end local p4    # "extension":Landroid/os/Bundle;
    .end local p5    # "type":I
    .local v1, "target":Ljava/lang/String;
    .local v2, "userId":I
    .local v3, "callPkg":Ljava/lang/String;
    .local v4, "extension":Landroid/os/Bundle;
    .local v5, "type":I
    invoke-virtual/range {v0 .. v5}, Landroid/app/OplusActivityTaskManager;->handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z

    move-result p1

    return p1
.end method

.method public whitelist hasLargeScreenFeature()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1322
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->hasLargeScreenFeature()Z

    move-result v0

    return v0
.end method

.method public whitelist hideZoomWindow(I)V
    .registers 3
    .param p1, "flag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 924
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->hideZoomWindow(I)V

    .line 925
    return-void
.end method

.method public blacklist hookAfterBindApplicationFinished(Ljava/lang/String;IIILjava/lang/String;)V
    .registers 13
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "pid"    # I
    .param p4, "uid"    # I
    .param p5, "processName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3175
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 3176
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .end local p1    # "pkgName":Ljava/lang/String;
    .end local p2    # "userId":I
    .end local p3    # "pid":I
    .end local p4    # "uid":I
    .end local p5    # "processName":Ljava/lang/String;
    .local v2, "pkgName":Ljava/lang/String;
    .local v3, "userId":I
    .local v4, "pid":I
    .local v5, "uid":I
    .local v6, "processName":Ljava/lang/String;
    invoke-interface/range {v1 .. v6}, Landroid/app/IOplusActivityManager;->hookAfterBindApplicationFinished(Ljava/lang/String;IIILjava/lang/String;)V

    goto :goto_1f

    .line 3178
    .end local v2    # "pkgName":Ljava/lang/String;
    .end local v3    # "userId":I
    .end local v4    # "pid":I
    .end local v5    # "uid":I
    .end local v6    # "processName":Ljava/lang/String;
    .restart local p1    # "pkgName":Ljava/lang/String;
    .restart local p2    # "userId":I
    .restart local p3    # "pid":I
    .restart local p4    # "uid":I
    .restart local p5    # "processName":Ljava/lang/String;
    :cond_13
    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .end local p1    # "pkgName":Ljava/lang/String;
    .end local p2    # "userId":I
    .end local p3    # "pid":I
    .end local p4    # "uid":I
    .end local p5    # "processName":Ljava/lang/String;
    .restart local v2    # "pkgName":Ljava/lang/String;
    .restart local v3    # "userId":I
    .restart local v4    # "pid":I
    .restart local v5    # "uid":I
    .restart local v6    # "processName":Ljava/lang/String;
    const-string p1, "OplusActivityManager"

    const-string p2, "hookAfterBindApplicationFinished failed because service has not been created "

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3180
    :goto_1f
    return-void
.end method

.method public whitelist inDownloading(IIZ)Z
    .registers 6
    .param p1, "uid"    # I
    .param p2, "thresholdSpeed"    # I
    .param p3, "rough"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2905
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2906
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->inDownloading(IIZ)Z

    move-result v0

    return v0

    .line 2908
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "inDownloading failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2910
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "params"    # Ljava/lang/String;
    .param p4, "object"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3014
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist isAppCallRefuseMode()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1183
    invoke-virtual {p0}, Landroid/app/OplusActivityManager;->getConfineMode()I

    move-result v0

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_9

    goto :goto_a

    :cond_9
    const/4 v1, 0x0

    :goto_a
    return v1
.end method

.method public whitelist isCurrentAppSupportCompactMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3029
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isCurrentAppSupportCompactMode()Z

    move-result v0

    return v0
.end method

.method public whitelist isFolderInnerScreen()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1326
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isFolderInnerScreen()Z

    move-result v0

    return v0
.end method

.method public whitelist isFreeformEnabled()Z
    .registers 2

    .line 799
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist isFrozenByHans(Ljava/lang/String;I)Z
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2619
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2620
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->isFrozenByHans(Ljava/lang/String;I)Z

    move-result v0

    return v0

    .line 2622
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "isFrozenByHans failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2624
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist isInSplitScreenMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1280
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isInSplitScreenMode()Z

    move-result v0

    return v0
.end method

.method public whitelist isMirageWindowShow()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1487
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager isMirageWindowShow"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1488
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isMirageWindowShow()Z

    move-result v0

    return v0
.end method

.method public whitelist isMultiApp(ILjava/lang/String;)Z
    .registers 4
    .param p1, "userId"    # I
    .param p2, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1986
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1, p2}, Lcom/oplus/multiapp/OplusMultiAppManager;->isMultiApp(ILjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public blacklist isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z
    .registers 3
    .param p1, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3081
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z

    move-result v0

    return v0
.end method

.method public whitelist isNightMode()Z
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2265
    const/4 v0, 0x0

    .line 2266
    .local v0, "success":Z
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_10

    .line 2267
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/app/IOplusActivityManager;->isNightMode()Z

    move-result v0

    goto :goto_17

    .line 2269
    :cond_10
    const-string v1, "OplusActivityManager"

    const-string v2, "isNightMode failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2271
    :goto_17
    return v0
.end method

.method public whitelist isPermissionInterceptEnabled()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1711
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 1712
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->isPermissionInterceptEnabled()Z

    move-result v0

    return v0

    .line 1714
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string v1, "isPermissionInterceptEnabled failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1716
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist isProcessRunning(ILjava/lang/String;)Z
    .registers 6
    .param p1, "uid"    # I
    .param p2, "processName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4188
    const/4 v0, 0x0

    const-string v1, "OplusActivityManager"

    if-gtz p1, :cond_b

    .line 4189
    const-string v2, "isProcessRunning failed because uid is less than zero"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 4190
    return v0

    .line 4192
    :cond_b
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_1a

    .line 4193
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->isUidProcessRunning(ILjava/lang/String;)Z

    move-result v0

    return v0

    .line 4195
    :cond_1a
    const-string v2, "isProcessRunning failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4196
    return v0
.end method

.method public whitelist isProcessRunning(Ljava/lang/String;Ljava/lang/String;I)Z
    .registers 7
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "processName"    # Ljava/lang/String;
    .param p3, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4212
    const/4 v0, 0x0

    const-string v1, "OplusActivityManager"

    if-eqz p1, :cond_29

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_c

    goto :goto_29

    .line 4216
    :cond_c
    if-gez p3, :cond_14

    .line 4217
    const-string v2, "isProcessRunning failed because wrong userId"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 4218
    return v0

    .line 4220
    :cond_14
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_23

    .line 4221
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->isPkgProcessRunning(Ljava/lang/String;Ljava/lang/String;I)Z

    move-result v0

    return v0

    .line 4223
    :cond_23
    const-string v2, "isProcessRunning failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4224
    return v0

    .line 4213
    :cond_29
    :goto_29
    const-string v2, "isProcessRunning failed because pkgName is empty"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 4214
    return v0
.end method

.method public whitelist isSupportEdgeTouchPrevent()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1156
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isSupportEdgeTouchPrevent()Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportMirageWindowMode()Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1527
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager isSupportMirageWindowMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1528
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isSupportMirageWindowMode()Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 6
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 993
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportZoomWindowMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 988
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isSupportZoomWindowMode()Z

    move-result v0

    return v0
.end method

.method public whitelist isTouchNodeSupport(II)Z
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1626
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->isTouchNodeSupport(II)Z

    move-result v0

    return v0
.end method

.method public whitelist isZoomSimpleModeEnable()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1040
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->isZoomSimpleModeEnable()Z

    move-result v0

    return v0
.end method

.method public blacklist isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 983
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z

    move-result v0

    return v0
.end method

.method public whitelist killPidForce(I)V
    .registers 4
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1755
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1756
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->killPidForce(I)V

    goto :goto_16

    .line 1758
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "killPidForce failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1761
    :goto_16
    return-void
.end method

.method public whitelist moveCompactWindowToLeft()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3033
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->moveCompactWindowToLeft()I

    move-result v0

    return v0
.end method

.method public whitelist moveCompactWindowToRight()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3037
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->moveCompactWindowToRight()I

    move-result v0

    return v0
.end method

.method public blacklist moveTaskToDisplay(IIZ)V
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "displayId"    # I
    .param p3, "top"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1650
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->moveTaskToDisplay(IIZ)V

    .line 1651
    return-void
.end method

.method public whitelist notifyAppKillReason(IIIILjava/lang/String;)V
    .registers 13
    .param p1, "pid"    # I
    .param p2, "uid"    # I
    .param p3, "reason"    # I
    .param p4, "subReason"    # I
    .param p5, "msg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2471
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 2472
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .end local p1    # "pid":I
    .end local p2    # "uid":I
    .end local p3    # "reason":I
    .end local p4    # "subReason":I
    .end local p5    # "msg":Ljava/lang/String;
    .local v2, "pid":I
    .local v3, "uid":I
    .local v4, "reason":I
    .local v5, "subReason":I
    .local v6, "msg":Ljava/lang/String;
    invoke-interface/range {v1 .. v6}, Landroid/app/IOplusActivityManager;->notifyAppKillReason(IIIILjava/lang/String;)V

    goto :goto_20

    .line 2474
    .end local v2    # "pid":I
    .end local v3    # "uid":I
    .end local v4    # "reason":I
    .end local v5    # "subReason":I
    .end local v6    # "msg":Ljava/lang/String;
    .restart local p1    # "pid":I
    .restart local p2    # "uid":I
    .restart local p3    # "reason":I
    .restart local p4    # "subReason":I
    .restart local p5    # "msg":Ljava/lang/String;
    :cond_13
    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .end local p1    # "pid":I
    .end local p2    # "uid":I
    .end local p3    # "reason":I
    .end local p4    # "subReason":I
    .end local p5    # "msg":Ljava/lang/String;
    .restart local v2    # "pid":I
    .restart local v3    # "uid":I
    .restart local v4    # "reason":I
    .restart local v5    # "subReason":I
    .restart local v6    # "msg":Ljava/lang/String;
    const-string p1, "OplusActivityManager"

    const-string/jumbo p2, "queryProcessNameFromPid failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2476
    :goto_20
    return-void
.end method

.method public whitelist notifyAthenaOnekeyClearRunning(I)V
    .registers 4
    .param p1, "state"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2531
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2532
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->notifyAthenaOnekeyClearRunning(I)V

    goto :goto_16

    .line 2534
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "notifyAthenaOnekeyClearRunning failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2536
    :goto_16
    return-void
.end method

.method public whitelist notifyGameStatus(Landroid/os/Bundle;)I
    .registers 4
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3663
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3664
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->notifyGameStatus(Landroid/os/Bundle;)I

    move-result v0

    return v0

    .line 3666
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "notifyGameStatus failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3668
    const/4 v0, -0x1

    return v0
.end method

.method public blacklist notifyProcessTerminate([ILjava/lang/String;)V
    .registers 5
    .param p1, "pids"    # [I
    .param p2, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3430
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3431
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->notifyProcessTerminate([ILjava/lang/String;)V

    goto :goto_16

    .line 3433
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "notifyProcessTerminate failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3435
    :goto_16
    return-void
.end method

.method public whitelist notifyProcessTerminateFinish(Lcom/oplus/app/OplusProcessTerminateObserver;)V
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/OplusProcessTerminateObserver;

    .line 3380
    if-nez p1, :cond_3

    .line 3381
    return-void

    .line 3383
    :cond_3
    :try_start_3
    invoke-virtual {p1}, Lcom/oplus/app/OplusProcessTerminateObserver;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v0

    .line 3384
    .local v0, "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_19

    .line 3385
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1}, Landroid/app/IOplusActivityManager;->notifyProcessTerminateFinish(Lcom/oplus/app/IProcessTerminateObserver;)V

    goto :goto_21

    .line 3387
    :cond_19
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "notifyProcessTerminateFinish failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_21
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_21} :catch_23

    .line 3391
    .end local v0    # "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    :goto_21
    nop

    .line 3392
    return-void

    .line 3389
    :catch_23
    move-exception v0

    .line 3390
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public whitelist notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V
    .registers 5
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "broadcast"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1272
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V

    .line 1273
    return-void
.end method

.method public whitelist notifyUiSwitched(Ljava/lang/String;I)V
    .registers 5
    .param p1, "uiInfo"    # Ljava/lang/String;
    .param p2, "status"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2971
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2972
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->notifyUiSwitched(Ljava/lang/String;I)V

    goto :goto_16

    .line 2974
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "notifyUiSwitched failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2976
    :goto_16
    return-void
.end method

.method public blacklist notifyZoomStateChange(Ljava/lang/String;I)V
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "action"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1049
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->notifyZoomStateChange(Ljava/lang/String;I)V

    .line 1050
    return-void
.end method

.method public blacklist onBackPressedOnTheiaMonitor(J)V
    .registers 5
    .param p1, "pressNow"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3139
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3140
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->onBackPressedOnTheiaMonitor(J)V

    goto :goto_16

    .line 3142
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "onBackPressedOnTheiaMonitor failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3144
    :goto_16
    return-void
.end method

.method public whitelist onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V
    .registers 3
    .param p1, "cvInfo"    # Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 936
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V

    .line 937
    return-void
.end method

.method public whitelist onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V
    .registers 3
    .param p1, "floatHandleInfo"    # Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 941
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V

    .line 942
    return-void
.end method

.method public whitelist onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V
    .registers 3
    .param p1, "inputEventInfo"    # Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 932
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V

    .line 933
    return-void
.end method

.method public whitelist onProtocolUpdated(Ljava/lang/String;)Z
    .registers 3
    .param p1, "content"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3053
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->onProtocolUpdated(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "extra"    # Landroid/os/Bundle;
    .param p3, "surface"    # Landroid/view/SurfaceControl;
    .param p4, "callback"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4400
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V

    .line 4401
    return-void
.end method

.method public whitelist putConfigInfo(Ljava/lang/String;Landroid/os/Bundle;II)Z
    .registers 7
    .param p1, "configName"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "flag"    # I
    .param p4, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2156
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2157
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityManager;->putConfigInfo(Ljava/lang/String;Landroid/os/Bundle;II)Z

    move-result v0

    return v0

    .line 2159
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "putConfigInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2161
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist putFastStartConfig(Ljava/lang/String;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4095
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4096
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->putFastStartConfig(Ljava/lang/String;)Z

    move-result v0

    return v0

    .line 4098
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "putFastStartConfig failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4099
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist queryProcessNameFromPid(I)Ljava/lang/String;
    .registers 4
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2459
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2460
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->queryProcessNameFromPid(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 2462
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "queryProcessNameFromPid failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2464
    const-string v0, ""

    return-object v0
.end method

.method public whitelist queryUsageStats(IJJ)Ljava/util/List;
    .registers 13
    .param p1, "intervalType"    # I
    .param p2, "beginTime"    # J
    .param p4, "endTime"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJJ)",
            "Ljava/util/List<",
            "Landroid/app/usage/UsageStats;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2923
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_12

    .line 2924
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move v2, p1

    move-wide v3, p2

    move-wide v5, p4

    .end local p1    # "intervalType":I
    .end local p2    # "beginTime":J
    .end local p4    # "endTime":J
    .local v2, "intervalType":I
    .local v3, "beginTime":J
    .local v5, "endTime":J
    invoke-interface/range {v1 .. v6}, Landroid/app/IOplusActivityManager;->queryUsageStats(IJJ)Ljava/util/List;

    move-result-object p1

    return-object p1

    .line 2926
    .end local v2    # "intervalType":I
    .end local v3    # "beginTime":J
    .end local v5    # "endTime":J
    .restart local p1    # "intervalType":I
    .restart local p2    # "beginTime":J
    .restart local p4    # "endTime":J
    :cond_12
    move v2, p1

    move-wide v3, p2

    .end local p1    # "intervalType":I
    .end local p2    # "beginTime":J
    .restart local v2    # "intervalType":I
    .restart local v3    # "beginTime":J
    const-string p1, "OplusActivityManager"

    const-string/jumbo p2, "queryUsageStats failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2928
    const/4 p1, 0x0

    return-object p1
.end method

.method public whitelist readNodeFile(I)Ljava/lang/String;
    .registers 3
    .param p1, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1610
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->readNodeFile(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist readNodeFileByDevice(II)Ljava/lang/String;
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1614
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->readNodeFileByDevice(II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist rebindDisplayIfNeeded(II)Z
    .registers 5
    .param p1, "castDisplayId"    # I
    .param p2, "mirageDisplayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1576
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager rebindDisplayIfNeeded"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1577
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->rebindDisplayIfNeeded(II)Z

    move-result v0

    return v0
.end method

.method public whitelist registerAbConfigCallback(Lcom/oplus/eventhub/sdk/EventCallback;Landroid/content/Context;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/EventCallback;
    .param p2, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2717
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    if-eqz p2, :cond_14

    .line 2718
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, p1, v1}, Landroid/app/IOplusActivityManager;->registerAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;Ljava/lang/String;)V

    goto :goto_1c

    .line 2720
    :cond_14
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerAbConfigCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2722
    :goto_1c
    return-void
.end method

.method public blacklist registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "observer"    # Lcom/oplus/app/IOplusAppSwitchObserver;
    .param p3, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 829
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3041
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/OplusComplexSceneObserver;)Z
    .registers 6
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "observer"    # Lcom/oplus/osense/complexscene/OplusComplexSceneObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3489
    const/4 v0, 0x0

    const-string v1, "OplusActivityManager"

    if-eqz p1, :cond_1e

    if-nez p2, :cond_8

    goto :goto_1e

    .line 3493
    :cond_8
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_17

    .line 3494
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->registerComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z

    move-result v0

    return v0

    .line 3496
    :cond_17
    const-string/jumbo v2, "registerComplexSceneObserver failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 3497
    return v0

    .line 3490
    :cond_1e
    :goto_1e
    const-string/jumbo v2, "registerComplexSceneObserver failed! bundle or observer is null"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 3491
    return v0
.end method

.method public blacklist registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1588
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/eap/IOplusEapDataCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2683
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2684
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->registerEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    goto :goto_16

    .line 2686
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerEapDataCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2688
    :goto_16
    return-void
.end method

.method public whitelist registerErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2743
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2744
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->registerErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    goto :goto_16

    .line 2746
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerErrorInfoCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2748
    :goto_16
    return-void
.end method

.method public blacklist registerHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/app/IOplusHansListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2498
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2499
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->registerHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v0

    return v0

    .line 2501
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerHansListener failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2503
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z
    .registers 5
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroid/os/IOplusKeyEventObserver;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1374
    .local p3, "configs":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z
    .registers 5
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .param p3, "listenFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1358
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z

    move-result v0

    return v0
.end method

.method public whitelist registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1252
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1455
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager registerMirageDisplayObserver"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1456
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1446
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager registerMirageWindowObserver"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1447
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerProcessObserver(Lcom/oplus/wrapper/app/IProcessObserver;I)V
    .registers 5
    .param p1, "oplusObserver"    # Lcom/oplus/wrapper/app/IProcessObserver;
    .param p2, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4294
    const-string v0, "OplusActivityManager"

    if-gtz p2, :cond_b

    .line 4295
    const-string/jumbo v1, "registerProcessObserver failed because flag is zero or more little"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4296
    return-void

    .line 4298
    :cond_b
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_26

    .line 4299
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mProcessObserverMap:Ljava/util/Map;

    new-instance v1, Landroid/app/OplusActivityManager$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Landroid/app/OplusActivityManager$$ExternalSyntheticLambda0;-><init>(Landroid/app/OplusActivityManager;)V

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/IProcessObserver;

    .line 4321
    .local v0, "processObserver":Landroid/app/IProcessObserver;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, v0, p2}, Landroid/app/IOplusActivityManager;->registerProcessObserver(Landroid/app/IProcessObserver;I)V

    .line 4322
    .end local v0    # "processObserver":Landroid/app/IProcessObserver;
    goto :goto_2c

    .line 4323
    :cond_26
    const-string/jumbo v1, "registerProcessObserver failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4325
    :goto_2c
    return-void
.end method

.method public blacklist registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z
    .registers 4
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/ILongPressScreenshotCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1407
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2817
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager registerSecurityPageCallback"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 2818
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1288
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1424
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/IProcessTerminateObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3397
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3398
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0

    .line 3400
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerTerminateObserver failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3401
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist registerTerminateObserver(Lcom/oplus/app/OplusProcessTerminateObserver;)Z
    .registers 6
    .param p1, "observer"    # Lcom/oplus/app/OplusProcessTerminateObserver;

    .line 3331
    const/4 v0, 0x0

    if-nez p1, :cond_4

    .line 3332
    return v0

    .line 3334
    :cond_4
    :try_start_4
    invoke-virtual {p1}, Lcom/oplus/app/OplusProcessTerminateObserver;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v1

    .line 3335
    .local v1, "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_1b

    .line 3336
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, v1}, Landroid/app/IOplusActivityManager;->registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0

    .line 3338
    :cond_1b
    const-string v2, "OplusActivityManager"

    const-string/jumbo v3, "registerTerminateObserver failed because service has not been created"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_23
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_23} :catch_24

    .line 3339
    return v0

    .line 3341
    .end local v1    # "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    :catch_24
    move-exception v0

    .line 3342
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public blacklist registerTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/ITerminateObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3440
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3441
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->registerTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v0

    return v0

    .line 3443
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "registerTerminateStateObserver failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3444
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 912
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3678
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 899
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist releaseScreenshotRegion()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1392
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->releaseScreenshotRegion()Z

    move-result v0

    return v0
.end method

.method public blacklist releaseVirtualDisplayDevice(I)V
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1643
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->releaseVirtualDisplayDevice(I)V

    .line 1644
    return-void
.end method

.method public blacklist removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3071
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v0

    return v0
.end method

.method public whitelist removeFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "replacePkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2104
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2105
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->removeFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    .line 2107
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "removeFastAppThirdLogin failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2109
    :goto_16
    return-void
.end method

.method public whitelist removeFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "originAppCpn"    # Ljava/lang/String;
    .param p2, "fastAppCpn"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2061
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2062
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->removeFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    .line 2064
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "removeFastAppWCPay failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2066
    :goto_16
    return-void
.end method

.method public blacklist removeFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    .line 817
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist removeMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "shareAppPkgName"    # Ljava/lang/String;
    .param p2, "miniProgramPkgName"    # Ljava/lang/String;
    .param p3, "miniProgramSignature"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2014
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2015
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_15

    .line 2017
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string v1, "addMiniProgramShare failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2019
    :goto_15
    return-void
.end method

.method public whitelist removeStageProtectInfo(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "protectPkg"    # Ljava/lang/String;
    .param p2, "callerPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1874
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1875
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->removeStageProtectInfo(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    .line 1877
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "removeStageProtectInfo failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1879
    :goto_16
    return-void
.end method

.method public whitelist removeTask(I)Z
    .registers 4
    .param p1, "taskId"    # I

    .line 3749
    :try_start_0
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->removeTask(I)Z

    move-result v0
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_8} :catch_9

    return v0

    .line 3750
    :catch_9
    move-exception v0

    .line 3751
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public blacklist removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1036
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist reportBindApplicationFinished(Ljava/lang/String;II)V
    .registers 6
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3164
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3165
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->reportBindApplicationFinished(Ljava/lang/String;II)V

    goto :goto_16

    .line 3167
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "reportBindApplicationFinished failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3169
    :goto_16
    return-void
.end method

.method public whitelist reportSkippedFrames(JJ)V
    .registers 12
    .param p1, "currentTime"    # J
    .param p3, "skippedFrames"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2423
    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    move-wide v1, p1

    move-wide v5, p3

    .end local p1    # "currentTime":J
    .end local p3    # "skippedFrames":J
    .local v1, "currentTime":J
    .local v5, "skippedFrames":J
    invoke-virtual/range {v0 .. v6}, Landroid/app/OplusActivityManager;->reportSkippedFrames(JZZJ)V

    .line 2424
    return-void
.end method

.method public whitelist reportSkippedFrames(JZZJ)V
    .registers 15
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2429
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_12

    .line 2430
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-wide v2, p1

    move v4, p3

    move v5, p4

    move-wide v6, p5

    .end local p1    # "currentTime":J
    .end local p3    # "isAnimation":Z
    .end local p4    # "isForeground":Z
    .end local p5    # "skippedFrames":J
    .local v2, "currentTime":J
    .local v4, "isAnimation":Z
    .local v5, "isForeground":Z
    .local v6, "skippedFrames":J
    invoke-interface/range {v1 .. v7}, Landroid/app/IOplusActivityManager;->reportSkippedFrames(JZZJ)V

    goto :goto_1e

    .line 2432
    .end local v2    # "currentTime":J
    .end local v4    # "isAnimation":Z
    .end local v5    # "isForeground":Z
    .end local v6    # "skippedFrames":J
    .restart local p1    # "currentTime":J
    .restart local p3    # "isAnimation":Z
    .restart local p4    # "isForeground":Z
    .restart local p5    # "skippedFrames":J
    :cond_12
    move-wide v2, p1

    move v4, p3

    move v5, p4

    move-wide v6, p5

    .end local p1    # "currentTime":J
    .end local p3    # "isAnimation":Z
    .end local p4    # "isForeground":Z
    .end local p5    # "skippedFrames":J
    .restart local v2    # "currentTime":J
    .restart local v4    # "isAnimation":Z
    .restart local v5    # "isForeground":Z
    .restart local v6    # "skippedFrames":J
    const-string p1, "OplusActivityManager"

    const-string/jumbo p2, "reportSkippedFrames failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2434
    :goto_1e
    return-void
.end method

.method public whitelist reportSkippedFrames(JZZJLjava/lang/String;)V
    .registers 17
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J
    .param p7, "pckName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2438
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 2439
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-wide v2, p1

    move v4, p3

    move v5, p4

    move-wide v6, p5

    move-object/from16 v8, p7

    invoke-interface/range {v1 .. v8}, Landroid/app/IOplusActivityManager;->reportSkippedFramesProcName(JZZJLjava/lang/String;)V

    goto :goto_1c

    .line 2441
    :cond_14
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "reportSkippedFrames failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2443
    :goto_1c
    return-void
.end method

.method public blacklist reportSkippedFrames(JZZJLjava/lang/String;Ljava/lang/String;)V
    .registers 19
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J
    .param p7, "pckName"    # Ljava/lang/String;
    .param p8, "activityName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2449
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_16

    .line 2450
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move-wide v2, p1

    move v4, p3

    move v5, p4

    move-wide v6, p5

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    invoke-interface/range {v1 .. v9}, Landroid/app/IOplusActivityManager;->reportSkippedFramesActivityName(JZZJLjava/lang/String;Ljava/lang/String;)V

    goto :goto_1e

    .line 2452
    :cond_16
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "reportSkippedFrames failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2454
    :goto_1e
    return-void
.end method

.method public whitelist requestDeviceFolded(IZ)Z
    .registers 5
    .param p1, "folded"    # I
    .param p2, "enableSecDisplay"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3270
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3271
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->requestDeviceFolded(IZ)Z

    move-result v0

    return v0

    .line 3273
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "requestDeviceFolded failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3275
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z
    .registers 3
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1152
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist revokeOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1791
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1792
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->revokeOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    .line 1794
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "revokeOplusPermissionByGroup failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1796
    :goto_16
    return-void
.end method

.method public whitelist scanFileIfNeed(ILjava/lang/String;)V
    .registers 4
    .param p1, "userId"    # I
    .param p2, "path"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1998
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1, p2}, Lcom/oplus/multiapp/OplusMultiAppManager;->scanFileIfNeed(ILjava/lang/String;)V

    .line 1999
    return-void
.end method

.method public blacklist sendFlingTransit(Landroid/view/MotionEvent;I)V
    .registers 5
    .param p1, "ev"    # Landroid/view/MotionEvent;
    .param p2, "duration"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3283
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3284
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->sendFlingTransit(Landroid/view/MotionEvent;I)V

    goto :goto_16

    .line 3286
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "sendFlingTransit failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3288
    :goto_16
    return-void
.end method

.method public blacklist sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z
    .registers 4
    .param p1, "weChatIntent"    # Landroid/app/PendingIntent;
    .param p2, "message"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3105
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public blacklist sendMirageEvents(ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "eventId"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1665
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->sendMirageEvents(ILandroid/os/Bundle;)V

    .line 1666
    return-void
.end method

.method public blacklist sendTheiaEvent(JLandroid/content/Intent;)V
    .registers 6
    .param p1, "category"    # J
    .param p3, "args"    # Landroid/content/Intent;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3150
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3151
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->sendTheiaEvent(JLandroid/content/Intent;)V

    goto :goto_16

    .line 3153
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "sendTheiaEvent failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3155
    :goto_16
    return-void
.end method

.method public whitelist setAllowLaunchApps(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1195
    .local p1, "allowLaunchApps":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v1, v2, p1, v0}, Landroid/app/OplusActivityManager;->setPermitList(IILjava/util/List;Z)V

    .line 1199
    const/4 v0, 0x1

    invoke-virtual {p0, v1, v2, p1, v0}, Landroid/app/OplusActivityManager;->setPermitList(IILjava/util/List;Z)V

    .line 1202
    return-void
.end method

.method public whitelist setAppCallRefuseMode(Z)V
    .registers 3
    .param p1, "enable"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1187
    const/4 v0, 0x1

    invoke-virtual {p0, v0, p1}, Landroid/app/OplusActivityManager;->setConfineMode(IZ)V

    .line 1188
    return-void
.end method

.method public whitelist setAppFreeze(Ljava/lang/String;Landroid/os/Bundle;)Z
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2519
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2520
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->setAppFreeze(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0

    .line 2522
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setAppFreeze failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2524
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist setAppStartMonitorController(Lcom/oplus/app/IOplusAppStartController;)V
    .registers 4
    .param p1, "watcher"    # Lcom/oplus/app/IOplusAppStartController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2083
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2084
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setAppStartMonitorController(Lcom/oplus/app/IOplusAppStartController;)V

    goto :goto_16

    .line 2086
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setAppStartMonitorController failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2088
    :goto_16
    return-void
.end method

.method public whitelist setChildSpaceMode(Z)V
    .registers 3
    .param p1, "mode"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1191
    const/4 v0, 0x2

    invoke-virtual {p0, v0, p1}, Landroid/app/OplusActivityManager;->setConfineMode(IZ)V

    .line 1192
    return-void
.end method

.method public whitelist setConfineMode(IZ)V
    .registers 4
    .param p1, "mode"    # I
    .param p2, "on"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1205
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->setConfineMode(IZ)V

    .line 1206
    return-void
.end method

.method public whitelist setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V
    .registers 4
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1148
    .local p2, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V

    .line 1149
    return-void
.end method

.method public whitelist setDynamicBlackList(Ljava/util/List;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4149
    .local p1, "blackList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4150
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setDynamicBlackList(Ljava/util/List;)Z

    move-result v0

    return v0

    .line 4152
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setDynamicBlackList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4153
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V
    .registers 4
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1160
    .local p2, "rulesMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V

    .line 1161
    return-void
.end method

.method public whitelist setGameBgPureGameScene(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 5
    .param p1, "gamePkg"    # Ljava/lang/String;
    .param p2, "gameAssistantPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4274
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4275
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->setGameBgPureGameScene(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0

    .line 4277
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setGameBgPureGameScene failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4278
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist setGameBgPureModeBlackList(Ljava/util/List;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4256
    .local p1, "blackList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4257
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setGameBgPureModeBlackList(Ljava/util/List;)Z

    move-result v0

    return v0

    .line 4259
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setGameBgPureModeBlackList failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4260
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist setGameSpaceController(Lcom/oplus/app/IOplusGameSpaceController;)V
    .registers 4
    .param p1, "watcher"    # Lcom/oplus/app/IOplusGameSpaceController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1826
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1827
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setGameSpaceController(Lcom/oplus/app/IOplusGameSpaceController;)V

    goto :goto_16

    .line 1829
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setGameSpaceController failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1831
    :goto_16
    return-void
.end method

.method public whitelist setGimbalLaunchPkg(Ljava/lang/String;)V
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1234
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setGimbalLaunchPkg(Ljava/lang/String;)V

    .line 1235
    return-void
.end method

.method public blacklist setGlThreads(II)V
    .registers 5
    .param p1, "glID"    # I
    .param p2, "tid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3126
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3127
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->setGlThreads(II)V

    goto :goto_16

    .line 3129
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setGlThreads failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3131
    :goto_16
    return-void
.end method

.method public whitelist setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V
    .registers 3
    .param p1, "config"    # Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1439
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V

    .line 1440
    return-void
.end method

.method public blacklist setHwuiTaskThreads(II)V
    .registers 5
    .param p1, "pid"    # I
    .param p2, "tid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3115
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3116
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->setHwuiTaskThreads(II)V

    goto :goto_16

    .line 3118
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setHwuiTaskThreads failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3120
    :goto_16
    return-void
.end method

.method public blacklist setInputConsumerEnabled(Z)Z
    .registers 3
    .param p1, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 967
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setInputConsumerEnabled(Z)Z

    move-result v0

    return v0
.end method

.method public whitelist setMirageDisplaySurfaceById(ILandroid/view/Surface;)V
    .registers 5
    .param p1, "displayId"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1502
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager setMirageDisplaySurfaceById"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1503
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->setMirageDisplaySurfaceById(ILandroid/view/Surface;)V

    .line 1504
    return-void
.end method

.method public whitelist setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V
    .registers 5
    .param p1, "mode"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1507
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager setMirageDisplaySurfaceByMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1508
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V

    .line 1509
    return-void
.end method

.method public blacklist setMirageDisplayUserRotation(IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "displayId"    # I
    .param p2, "userRotation"    # I
    .param p3, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1658
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->setMirageDisplayUserRotation(IILandroid/os/Bundle;)V

    .line 1659
    return-void
.end method

.method public whitelist setMirageWindowSilent(Ljava/lang/String;)V
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1522
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager setMirageWindowSilent"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1523
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setMirageWindowSilent(Ljava/lang/String;)V

    .line 1524
    return-void
.end method

.method public whitelist setMultiAppAccessMode(Ljava/lang/String;I)I
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "accessMode"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1971
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1, p2}, Lcom/oplus/multiapp/OplusMultiAppManager;->setMultiAppAccessModeInner(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public whitelist setMultiAppAlias(Ljava/lang/String;Ljava/lang/String;)I
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "alias"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1966
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1, p2}, Lcom/oplus/multiapp/OplusMultiAppManager;->setMultiAppAliasInner(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist setMultiAppConfig(Lcom/oplus/multiapp/OplusMultiAppConfig;)I
    .registers 3
    .param p1, "config"    # Lcom/oplus/multiapp/OplusMultiAppConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1958
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1}, Lcom/oplus/multiapp/OplusMultiAppManager;->setMultiAppConfigInner(Lcom/oplus/multiapp/OplusMultiAppConfig;)I

    move-result v0

    return v0
.end method

.method public whitelist setMultiAppStatus(Ljava/lang/String;I)I
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "status"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1990
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusMultiApp:Lcom/oplus/multiapp/OplusMultiAppManager;

    invoke-virtual {v0, p1, p2}, Lcom/oplus/multiapp/OplusMultiAppManager;->setMultiAppStatus(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public whitelist setPackagesState(Ljava/util/Map;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1241
    .local p1, "packageMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setPackagesState(Ljava/util/Map;)V

    .line 1242
    return-void
.end method

.method public whitelist setPayJoyFlag(I)Z
    .registers 4
    .param p1, "payjoyFlag"    # I

    .line 3699
    :try_start_0
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroid/app/IOplusActivityManager;->setPayJoyFlag(I)Z

    move-result v0
    :try_end_9
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_9} :catch_a

    return v0

    .line 3700
    :catch_a
    move-exception v0

    .line 3701
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public whitelist setPermissionInterceptEnable(Z)V
    .registers 4
    .param p1, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1703
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1704
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setPermissionInterceptEnable(Z)V

    goto :goto_16

    .line 1706
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setPermissionInterceptEnable failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1708
    :goto_16
    return-void
.end method

.method public whitelist setPermissionRecordController(Lcom/oplus/app/IOplusPermissionRecordController;)V
    .registers 4
    .param p1, "watcher"    # Lcom/oplus/app/IOplusPermissionRecordController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2255
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2256
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setPermissionRecordController(Lcom/oplus/app/IOplusPermissionRecordController;)V

    goto :goto_16

    .line 2258
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setPermissionRecordController failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2260
    :goto_16
    return-void
.end method

.method public whitelist setPermitList(IILjava/util/List;Z)V
    .registers 6
    .param p1, "mode"    # I
    .param p2, "type"    # I
    .param p4, "isMultiApp"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1213
    .local p3, "permits":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->setPermitList(IILjava/util/List;Z)V

    .line 1214
    return-void
.end method

.method public whitelist setPreventIndulgeController(Lcom/oplus/app/IOplusAppStartController;)V
    .registers 4
    .param p1, "controller"    # Lcom/oplus/app/IOplusAppStartController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2136
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2137
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->setPreventIndulgeController(Lcom/oplus/app/IOplusAppStartController;)V

    goto :goto_16

    .line 2139
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setPreventIndulgeController failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2141
    :goto_16
    return-void
.end method

.method public blacklist setRegionScreenshot(Z)V
    .registers 3
    .param p1, "following"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1385
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setRegionScreenshot(Z)V

    .line 1386
    return-void
.end method

.method public blacklist setSceneActionTransit(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 6
    .param p1, "scene"    # Ljava/lang/String;
    .param p2, "action"    # Ljava/lang/String;
    .param p3, "timeout"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3294
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3295
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->setSceneActionTransit(Ljava/lang/String;Ljava/lang/String;I)V

    goto :goto_16

    .line 3297
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "setSceneActionTransit failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3299
    :goto_16
    return-void
.end method

.method public blacklist setSecureController(Landroid/app/IActivityController;)V
    .registers 3
    .param p1, "controller"    # Landroid/app/IActivityController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 772
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setSecureController(Landroid/app/IActivityController;)V

    .line 773
    return-void
.end method

.method public whitelist setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1276
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist setSystemProperties(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3
    .param p1, "properties"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1732
    return-void
.end method

.method public blacklist setTaskWindowingModeSplitScreen(I)I
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1311
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setTaskWindowingModeSplitScreen(I)I

    move-result v0

    return v0
.end method

.method public whitelist setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V
    .registers 3
    .param p1, "config"    # Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1010
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V

    .line 1011
    return-void
.end method

.method public blacklist shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z
    .registers 4
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "down"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2780
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForEdgePanel(Landroid/content/Intent;I)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1168
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->splitScreenForEdgePanel(Landroid/content/Intent;I)I

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForEdgePanel(Landroid/content/Intent;ZI)Z
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "launchToPrimary"    # Z
    .param p3, "launchArea"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1318
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->splitScreenForEdgePanelExt(Landroid/content/Intent;ZI)Z

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForRecentTasks(I)Z
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1304
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->splitScreenForRecentTasks(I)Z

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForTopApp(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1300
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->splitScreenForTopApp(I)Z

    move-result v0

    return v0
.end method

.method public whitelist startActivity(Landroid/content/Intent;)V
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;

    .line 3964
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 3966
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->startActivity(Landroid/content/Intent;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_d} :catch_e

    .line 3969
    goto :goto_1c

    .line 3967
    :catch_e
    move-exception v0

    .line 3968
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3971
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_14
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "startActivity failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3973
    :goto_1c
    return-void
.end method

.method public whitelist startActivityAsUser(Landroid/content/Intent;Landroid/os/Bundle;Landroid/os/UserHandle;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userHandle"    # Landroid/os/UserHandle;

    .line 3990
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_14

    .line 3992
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->startActivityAsUser(Landroid/content/Intent;Landroid/os/Bundle;Landroid/os/UserHandle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_d} :catch_e

    .line 3995
    goto :goto_1c

    .line 3993
    :catch_e
    move-exception v0

    .line 3994
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3997
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_14
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "startActivityAsUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3999
    :goto_1c
    return-void
.end method

.method public final whitelist startActivityForFreeform(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;

    .line 872
    const/4 v0, -0x1

    return v0
.end method

.method public whitelist startCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3021
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->startCompactWindow()I

    move-result v0

    return v0
.end method

.method public whitelist startMiniZoomFromZoom(I)V
    .registers 3
    .param p1, "startWay"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1002
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->startMiniZoomFromZoom(I)V

    .line 1003
    return-void
.end method

.method public whitelist startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1482
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager startMirageWindowMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1483
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public whitelist startMirageWindowMode(Landroid/content/ComponentName;IILandroid/os/Bundle;)V
    .registers 7
    .param p1, "cpnName"    # Landroid/content/ComponentName;
    .param p2, "taskId"    # I
    .param p3, "flags"    # I
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1477
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager startMirageWindowMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1478
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->startMirageWindowModeWithName(Landroid/content/ComponentName;IILandroid/os/Bundle;)V

    .line 1479
    return-void
.end method

.method public whitelist startProcess(Ljava/lang/String;I)I
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4013
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4014
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->startProcess(Ljava/lang/String;I)I

    move-result v0

    return v0

    .line 4016
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "startProcess failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4017
    const/4 v0, -0x1

    return v0
.end method

.method public whitelist startProcessWithFreeze(Ljava/lang/String;I)Z
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4363
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 4364
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->startProcessWithFreeze(Ljava/lang/String;I)Z

    move-result v0

    return v0

    .line 4366
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "startProcess failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4367
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist startUserInBackground(I)Z
    .registers 4
    .param p1, "userId"    # I

    .line 3943
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3945
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->startUserInBackground(I)Z

    move-result v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return v0

    .line 3946
    :catch_f
    move-exception v0

    .line 3947
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3950
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "startUserInBackground failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3952
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 884
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public blacklist startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "pendingIntent"    # Landroid/app/PendingIntent;
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 890
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist stopMirageWindowMode()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1492
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager stopMirageWindowMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1493
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->stopMirageWindowModeOld()V

    .line 1494
    return-void
.end method

.method public whitelist stopMirageWindowMode(Landroid/os/Bundle;)V
    .registers 4
    .param p1, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1497
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager stopMirageWindowMode"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1498
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->stopMirageWindowMode(Landroid/os/Bundle;)V

    .line 1499
    return-void
.end method

.method public whitelist swapDockedFullscreenStack()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 622
    return-void
.end method

.method public whitelist switchUser(I)Z
    .registers 4
    .param p1, "userId"    # I

    .line 3898
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3900
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->switchUser(I)Z

    move-result v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return v0

    .line 3901
    :catch_f
    move-exception v0

    .line 3902
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3905
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "switchUser failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3907
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist syncPermissionRecord()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2361
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2362
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->syncPermissionRecord()V

    goto :goto_16

    .line 2364
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "syncPermissionRecord failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2366
    :goto_16
    return-void
.end method

.method public whitelist trimSystemMemory(IZ)V
    .registers 5
    .param p1, "level"    # I
    .param p2, "needGc"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3619
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 3620
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->trimSystemMemory(IZ)V

    goto :goto_16

    .line 3622
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "trimSystemMemory failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3624
    :goto_16
    return-void
.end method

.method public blacklist unRegisterRegionScreenshot(Ljava/lang/String;Z)Z
    .registers 5
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "isBinderDied"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1414
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/app/OplusActivityTaskManager;->unRegisterRegionScreenshot(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method public blacklist unbindQuickReplyService()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3098
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityTaskManager;->unbindQuickReplyService()V

    .line 3099
    return-void
.end method

.method public blacklist unfreezeForKernel(IIILjava/lang/String;I)V
    .registers 13
    .param p1, "type"    # I
    .param p2, "callerPid"    # I
    .param p3, "targetUid"    # I
    .param p4, "rpcName"    # Ljava/lang/String;
    .param p5, "code"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3190
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 3191
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move v6, p5

    .end local p1    # "type":I
    .end local p2    # "callerPid":I
    .end local p3    # "targetUid":I
    .end local p4    # "rpcName":Ljava/lang/String;
    .end local p5    # "code":I
    .local v2, "type":I
    .local v3, "callerPid":I
    .local v4, "targetUid":I
    .local v5, "rpcName":Ljava/lang/String;
    .local v6, "code":I
    invoke-interface/range {v1 .. v6}, Landroid/app/IOplusActivityManager;->unfreezeForKernel(IIILjava/lang/String;I)V

    goto :goto_20

    .line 3193
    .end local v2    # "type":I
    .end local v3    # "callerPid":I
    .end local v4    # "targetUid":I
    .end local v5    # "rpcName":Ljava/lang/String;
    .end local v6    # "code":I
    .restart local p1    # "type":I
    .restart local p2    # "callerPid":I
    .restart local p3    # "targetUid":I
    .restart local p4    # "rpcName":Ljava/lang/String;
    .restart local p5    # "code":I
    :cond_13
    move v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move v6, p5

    .end local p1    # "type":I
    .end local p2    # "callerPid":I
    .end local p3    # "targetUid":I
    .end local p4    # "rpcName":Ljava/lang/String;
    .end local p5    # "code":I
    .restart local v2    # "type":I
    .restart local v3    # "callerPid":I
    .restart local v4    # "targetUid":I
    .restart local v5    # "rpcName":Ljava/lang/String;
    .restart local v6    # "code":I
    const-string p1, "OplusActivityManager"

    const-string/jumbo p2, "unfreezeForKernel failed because service has not been created"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3195
    :goto_20
    return-void
.end method

.method public blacklist unfreezeForKernelTargetPid(IIIIILjava/lang/String;I)V
    .registers 17
    .param p1, "type"    # I
    .param p2, "callerPid"    # I
    .param p3, "callerUid"    # I
    .param p4, "targetPid"    # I
    .param p5, "targetUid"    # I
    .param p6, "rpcName"    # Ljava/lang/String;
    .param p7, "code"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3221
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_16

    .line 3222
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    move-object v7, p6

    move/from16 v8, p7

    invoke-interface/range {v1 .. v8}, Landroid/app/IOplusActivityManager;->unfreezeForKernelTargetPid(IIIIILjava/lang/String;I)V

    goto :goto_1e

    .line 3224
    :cond_16
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unfreezeForKernelTargetPid failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3225
    :goto_1e
    return-void
.end method

.method public whitelist unregisterAbConfigCallback(Lcom/oplus/eventhub/sdk/EventCallback;)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/EventCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2734
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2735
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->unregisterAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    goto :goto_16

    .line 2737
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterAbConfigCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2739
    :goto_16
    return-void
.end method

.method public whitelist unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 834
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3045
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/OplusComplexSceneObserver;)Z
    .registers 6
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "observer"    # Lcom/oplus/osense/complexscene/OplusComplexSceneObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3513
    const/4 v0, 0x0

    const-string v1, "OplusActivityManager"

    if-eqz p1, :cond_1e

    if-nez p2, :cond_8

    goto :goto_1e

    .line 3517
    :cond_8
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_17

    .line 3518
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->unregisterComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z

    move-result v0

    return v0

    .line 3520
    :cond_17
    const-string/jumbo v2, "unregisterComplexSceneObserver failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3521
    return v0

    .line 3514
    :cond_1e
    :goto_1e
    const-string/jumbo v2, "unregisterComplexSceneObserver failed! bundle or observer is null"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 3515
    return v0
.end method

.method public blacklist unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1596
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/eap/IOplusEapDataCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2691
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2692
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->unregisterEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    goto :goto_16

    .line 2694
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterEapDataCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2696
    :goto_16
    return-void
.end method

.method public whitelist unregisterErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2751
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2752
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->unregisterErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    goto :goto_16

    .line 2754
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterErrorInfoCallback failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2757
    :goto_16
    return-void
.end method

.method public blacklist unregisterHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z
    .registers 5
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/app/IOplusHansListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2510
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 2511
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityManager;->unregisterHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v0

    return v0

    .line 2513
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterHansListener failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2515
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist unregisterKeyEventInterceptor(Ljava/lang/String;)Z
    .registers 3
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1378
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterKeyEventInterceptor(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterKeyEventObserver(Ljava/lang/String;)Z
    .registers 3
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1362
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterKeyEventObserver(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1257
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1460
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1451
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterProcessObserver(Lcom/oplus/wrapper/app/IProcessObserver;)V
    .registers 5
    .param p1, "oplusObserver"    # Lcom/oplus/wrapper/app/IProcessObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4336
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mProcessObserverMap:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/IProcessObserver;

    .line 4337
    .local v0, "processObserver":Landroid/app/IProcessObserver;
    if-nez v0, :cond_13

    .line 4338
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "unregisterProcessObserver failed! Make sure use API registerProcessObserver(observer, flags)"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4339
    return-void

    .line 4341
    :cond_13
    iget-object v1, p0, Landroid/app/OplusActivityManager;->mProcessObserverMap:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4342
    invoke-static {}, Landroid/app/ActivityManager;->getService()Landroid/app/IActivityManager;

    move-result-object v1

    invoke-interface {v1, v0}, Landroid/app/IActivityManager;->unregisterProcessObserver(Landroid/app/IProcessObserver;)V

    .line 4344
    return-void
.end method

.method public whitelist unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2822
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager unregisterSecurityPageCallback"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 2823
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1292
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1428
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/IProcessTerminateObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3408
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3409
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0

    .line 3411
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterTerminateObserver failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3412
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist unregisterTerminateObserver(Lcom/oplus/app/OplusProcessTerminateObserver;)Z
    .registers 6
    .param p1, "observer"    # Lcom/oplus/app/OplusProcessTerminateObserver;

    .line 3356
    const/4 v0, 0x0

    if-nez p1, :cond_4

    .line 3357
    return v0

    .line 3359
    :cond_4
    :try_start_4
    invoke-virtual {p1}, Lcom/oplus/app/OplusProcessTerminateObserver;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v1

    .line 3360
    .local v1, "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v2

    if-eqz v2, :cond_1b

    .line 3361
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, v1}, Landroid/app/IOplusActivityManager;->unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0

    .line 3363
    :cond_1b
    const-string v2, "OplusActivityManager"

    const-string/jumbo v3, "unregisterTerminateObserver failed because service has not been created"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_23
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_23} :catch_24

    .line 3364
    return v0

    .line 3366
    .end local v1    # "iptObserver":Lcom/oplus/app/IProcessTerminateObserver;
    :catch_24
    move-exception v0

    .line 3367
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public blacklist unregisterTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/app/ITerminateObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3451
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_f

    .line 3452
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->unregisterTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v0

    return v0

    .line 3454
    :cond_f
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "unregisterTerminateStateObserver failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3455
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 916
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 3685
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 908
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateANRDumpState(Landroid/os/SharedMemory;)V
    .registers 4
    .param p1, "sharedMemory"    # Landroid/os/SharedMemory;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2699
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2700
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->updateANRDumpState(Landroid/os/SharedMemory;)V

    goto :goto_16

    .line 2702
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "updateANRDumpState failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2704
    :goto_16
    return-void
.end method

.method public whitelist updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1420
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z
    .registers 4
    .param p1, "list"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1571
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager updateCarModeMultiLaunchWhiteList"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1572
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityTaskManager;->updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateConfiguration(Landroid/content/res/Configuration;)Z
    .registers 4
    .param p1, "configuration"    # Landroid/content/res/Configuration;

    .line 3834
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_15

    .line 3836
    :try_start_6
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityManager;->updateConfiguration(Landroid/content/res/Configuration;)Z

    move-result v0
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_e} :catch_f

    return v0

    .line 3837
    :catch_f
    move-exception v0

    .line 3838
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1

    .line 3841
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_15
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "updateConfiguration failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 3843
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist updateCpuTracker(J)F
    .registers 6
    .param p1, "lastUpdateTime"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2180
    const/high16 v0, 0x3f800000    # 1.0f

    .line 2181
    .local v0, "percent":F
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    if-eqz v1, :cond_11

    .line 2182
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v1

    invoke-interface {v1, p1, p2}, Landroid/app/IOplusActivityManager;->updateCpuTracker(J)F

    move-result v1

    return v1

    .line 2184
    :cond_11
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "putConfigInfo failed because service has not been created"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2186
    return v0
.end method

.method public whitelist updateDeferStartingWindowApps(Ljava/util/List;Z)V
    .registers 4
    .param p2, "removeImmdiately"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2878
    .local p1, "packages":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->updateDeferStartingWindowApps(Ljava/util/List;Z)V

    .line 2879
    return-void
.end method

.method public whitelist updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z
    .registers 5
    .param p1, "castFlag"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1537
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager updateMirageWindowCastFlag"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1538
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist updatePermissionChoice(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .param p3, "choice"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1695
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 1696
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->updatePermissionChoice(Ljava/lang/String;Ljava/lang/String;I)V

    goto :goto_16

    .line 1698
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "updatePermissionChoice failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1700
    :goto_16
    return-void
.end method

.method public whitelist updatePrivacyProtectionList(Ljava/util/List;Z)Z
    .registers 5
    .param p2, "append"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1542
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager updatePrivacyProtectionList"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1543
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->updatePrivacyProtectionList(Ljava/util/List;Z)Z

    move-result v0

    return v0
.end method

.method public whitelist updatePrivacyProtectionList(Ljava/util/List;ZZLandroid/os/Bundle;)Z
    .registers 7
    .param p2, "append"    # Z
    .param p3, "isDefault"    # Z
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ",
            "Landroid/os/Bundle;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1547
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const-string v0, "MirageDisplayWindow"

    const-string v1, "OplusActivityManager default updatePrivacyProtectionList"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1548
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityTaskManager;->updatePrivacyProtectionListWithBundle(Ljava/util/List;ZZLandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public blacklist updateTsaMap(Ljava/lang/String;IZ)V
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "tid"    # I
    .param p3, "toTop"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4035
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 4036
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityManager;->updateTsaMap(Ljava/lang/String;IZ)V

    goto :goto_16

    .line 4038
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "updateTsaMap failed"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4040
    :goto_16
    return-void
.end method

.method public whitelist updateUidCpuTracker()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2370
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 2371
    invoke-static {}, Landroid/app/OplusActivityManager;->getService()Landroid/app/IOplusActivityManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityManager;->updateUidCpuTracker()V

    goto :goto_16

    .line 2373
    :cond_e
    const-string v0, "OplusActivityManager"

    const-string/jumbo v1, "updateUidCpuTracker failed because service has not been created"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2375
    :goto_16
    return-void
.end method

.method public whitelist updateUntrustedTouchConfig(Ljava/lang/String;Z)V
    .registers 4
    .param p1, "configData"    # Ljava/lang/String;
    .param p2, "isRus"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2770
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->updateUntrustedTouchConfig(Ljava/lang/String;Z)V

    .line 2771
    return-void
.end method

.method public whitelist writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z
    .registers 5
    .param p1, "callPkg"    # Ljava/lang/String;
    .param p2, "scenePkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1144
    .local p3, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFile(ILjava/lang/String;)Z
    .registers 4
    .param p1, "nodeFlag"    # I
    .param p2, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1618
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityTaskManager;->writeNodeFile(ILjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFileByDevice(IILjava/lang/String;)Z
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1622
    iget-object v0, p0, Landroid/app/OplusActivityManager;->mOplusAtm:Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/OplusActivityTaskManager;->writeNodeFileByDevice(IILjava/lang/String;)Z

    move-result v0

    return v0
.end method
