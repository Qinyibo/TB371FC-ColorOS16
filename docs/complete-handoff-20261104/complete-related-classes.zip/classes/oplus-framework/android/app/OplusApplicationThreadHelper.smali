.class public Landroid/app/OplusApplicationThreadHelper;
.super Ljava/lang/Object;
.source "OplusApplicationThreadHelper.java"

# interfaces
.implements Landroid/app/IOplusApplicationThread;


# static fields
.field private static final blacklist TAG:Ljava/lang/String; = "OplusApplicationThreadH"


# instance fields
.field private blacklist mOplusApplicationThread:Landroid/app/OplusBaseApplicationThread;


# direct methods
.method constructor blacklist <init>(Landroid/app/OplusBaseApplicationThread;)V
    .registers 2
    .param p1, "oplusApplicationThread"    # Landroid/app/OplusBaseApplicationThread;

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 54
    iput-object p1, p0, Landroid/app/OplusApplicationThreadHelper;->mOplusApplicationThread:Landroid/app/OplusBaseApplicationThread;

    .line 55
    return-void
.end method


# virtual methods
.method public blacklist onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 8
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I

    .line 58
    const/4 v0, 0x0

    const-string v1, "android.app.IApplicationThread"

    const/4 v2, 0x1

    packed-switch p1, :pswitch_data_2c

    .line 75
    return v0

    .line 66
    :pswitch_8
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 67
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 68
    .local v0, "configs":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-eqz v1, :cond_19

    .line 69
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->readStringList(Ljava/util/List;)V

    .line 71
    :cond_19
    invoke-virtual {p0, v0}, Landroid/app/OplusApplicationThreadHelper;->setDynamicalLogConfig(Ljava/util/List;)V

    .line 72
    return v2

    .line 60
    .end local v0    # "configs":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_1d
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 61
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    if-ne v2, v1, :cond_27

    move v0, v2

    .line 62
    .local v0, "on":Z
    :cond_27
    invoke-virtual {p0, v0}, Landroid/app/OplusApplicationThreadHelper;->setDynamicalLogEnable(Z)V

    .line 63
    return v2

    nop

    :pswitch_data_2c
    .packed-switch 0x2712
        :pswitch_1d
        :pswitch_8
    .end packed-switch
.end method

.method public blacklist scheduleForceGc(Ljava/lang/String;)V
    .registers 4
    .param p1, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 112
    const-string v0, "OplusApplicationThreadH"

    const-string/jumbo v1, "scheduleForceGc do noting"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 113
    return-void
.end method

.method public blacklist sendBracketModeUnitData(Landroid/app/OplusBracketModeUnit;)V
    .registers 4
    .param p1, "bracketModeUnit"    # Landroid/app/OplusBracketModeUnit;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 120
    const-string v0, "OplusApplicationThreadH"

    const-string/jumbo v1, "sendBracketModeUnitData do nothing"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 121
    return-void
.end method

.method public blacklist sendGfxTrim(I)V
    .registers 4
    .param p1, "level"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 105
    const-string v0, "OplusApplicationThreadH"

    const-string/jumbo v1, "sendGfxTrim in OplusApplicationThreadHelper"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 106
    return-void
.end method

.method public blacklist setDynamicalLogConfig(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 90
    .local p1, "configs":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setDynamicalLogConfig: server: on "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusApplicationThreadH"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    invoke-static {}, Landroid/app/AppDynamicalLogEnabler;->getInstance()Landroid/app/AppDynamicalLogEnabler;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/app/AppDynamicalLogEnabler;->setDynamicalLogConfig(Ljava/util/List;)V

    .line 92
    return-void
.end method

.method public blacklist setDynamicalLogEnable(Z)V
    .registers 4
    .param p1, "on"    # Z

    .line 84
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setDynamicalLogEnable on "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusApplicationThreadH"

    invoke-static {v1, v0}, Landroid/util/Slog;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 85
    invoke-static {p1}, Landroid/app/ActivityDynamicLogHelper;->setDynamicalLogEnable(Z)V

    .line 86
    return-void
.end method

.method public blacklist setViewExtractData(Landroid/os/Bundle;Landroid/os/IBinder;)V
    .registers 5
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "activityToken"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 128
    const-string v0, "OplusApplicationThreadH"

    const-string/jumbo v1, "setViewExtractData do nothing"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    return-void
.end method

.method public blacklist setZoomSensorState(Z)V
    .registers 2
    .param p1, "isZoom"    # Z

    .line 99
    sput-boolean p1, Landroid/hardware/SystemSensorManager;->mInMirage:Z

    .line 100
    return-void
.end method
