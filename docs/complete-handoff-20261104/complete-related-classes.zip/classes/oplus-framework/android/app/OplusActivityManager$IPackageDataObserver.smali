.class public interface abstract Landroid/app/OplusActivityManager$IPackageDataObserver;
.super Ljava/lang/Object;
.source "OplusActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/OplusActivityManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "IPackageDataObserver"
.end annotation


# virtual methods
.method public abstract whitelist onRemoveCompleted(Ljava/lang/String;Z)V
.end method
