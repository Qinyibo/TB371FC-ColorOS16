.class public Landroid/app/OplusActivityTaskManager;
.super Ljava/lang/Object;
.source "OplusActivityTaskManager.java"


# static fields
.field private static final blacklist IOplusActivityTaskManagerSingleton:Landroid/util/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Singleton<",
            "Landroid/app/IOplusActivityTaskManager;",
            ">;"
        }
    .end annotation
.end field

.field public static final blacklist MATCH_ATTACHED_TASK_ONLY:I = 0x0

.field public static final blacklist MATCH_ATTACHED_TASK_OR_RECENT_TASKS:I = 0x1

.field public static final blacklist MATCH_RECENT_TASKS_ONLY:I = 0x2

.field private static final blacklist TAG:Ljava/lang/String;

.field private static final blacklist TAG_WINDOW_CHANGE:Ljava/lang/String; = "OplusWindowChangeInfo"

.field public static final blacklist TYPE_SPLIT_TASK_CHANGED:I = 0x4

.field public static final blacklist TYPE_TASK_FOCUS_CHANGED:I = 0x8

.field public static final blacklist TYPE_TASK_LISTENER_RECENT_TASK_REMOVED_FOR_ADD:I = 0x1

.field public static final blacklist TYPE_TASK_NUM_CHANGED:I = 0x1

.field public static final blacklist TYPE_TASK_POSITION_CHANGED:I = 0x2

.field private static final blacklist sInstance:Landroid/util/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Singleton<",
            "Landroid/app/OplusActivityTaskManager;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private blacklist mPackageInfo:Ljava/lang/String;


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 1

    .line 245
    const-class v0, Landroid/app/OplusActivityTaskManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroid/app/OplusActivityTaskManager;->TAG:Ljava/lang/String;

    .line 252
    new-instance v0, Landroid/app/OplusActivityTaskManager$1;

    invoke-direct {v0}, Landroid/app/OplusActivityTaskManager$1;-><init>()V

    sput-object v0, Landroid/app/OplusActivityTaskManager;->sInstance:Landroid/util/Singleton;

    .line 278
    new-instance v0, Landroid/app/OplusActivityTaskManager$2;

    invoke-direct {v0}, Landroid/app/OplusActivityTaskManager$2;-><init>()V

    sput-object v0, Landroid/app/OplusActivityTaskManager;->IOplusActivityTaskManagerSingleton:Landroid/util/Singleton;

    return-void
.end method

.method public constructor whitelist <init>()V
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 261
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 262
    return-void
.end method

.method private blacklist generatePackageInfo(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"    # Landroid/content/Context;

    .line 2442
    iget-object v0, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    if-nez v0, :cond_34

    if-nez p1, :cond_7

    goto :goto_34

    .line 2445
    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 2446
    .local v0, "builder":Ljava/lang/StringBuilder;
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2447
    const-string v1, "_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2448
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2449
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2450
    invoke-virtual {p1}, Landroid/content/Context;->getUserId()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2451
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    .line 2452
    return-void

    .line 2443
    .end local v0    # "builder":Ljava/lang/StringBuilder;
    :cond_34
    :goto_34
    return-void
.end method

.method public static whitelist getInstance()Landroid/app/OplusActivityTaskManager;
    .registers 1

    .line 265
    sget-object v0, Landroid/app/OplusActivityTaskManager;->sInstance:Landroid/util/Singleton;

    invoke-virtual {v0}, Landroid/util/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/OplusActivityTaskManager;

    return-object v0
.end method

.method public static blacklist getService()Landroid/app/IOplusActivityTaskManager;
    .registers 1

    .line 272
    sget-object v0, Landroid/app/OplusActivityTaskManager;->IOplusActivityTaskManagerSingleton:Landroid/util/Singleton;

    invoke-virtual {v0}, Landroid/util/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/IOplusActivityTaskManager;

    return-object v0
.end method


# virtual methods
.method public blacklist addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1797
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist addFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    .line 343
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 571
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist adjustEndAbsForFlexibleMinimize()Landroid/graphics/Rect;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2071
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->adjustEndAbsForFlexibleMinimize()Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist adjustEndAbsForFlexibleMinimizeIfNeed(Landroid/window/TransitionInfo$Change;)Landroid/graphics/Rect;
    .registers 3
    .param p1, "change"    # Landroid/window/TransitionInfo$Change;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2061
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->adjustEndAbsForFlexibleMinimizeIfNeed(Landroid/window/TransitionInfo$Change;)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist adjustFlexibleTask(Landroid/os/Bundle;)Z
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1597
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->adjustFlexibleTask(Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public blacklist adjustWindowFrame(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 6
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1961
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->adjustWindowFrame(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 1962
    return-void
.end method

.method public blacklist adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 6
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 521
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 522
    return-void
.end method

.method public blacklist bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V
    .registers 3
    .param p1, "callback"    # Lcom/oplus/quickreply/IQuickReplyCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1772
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V

    .line 1773
    return-void
.end method

.method public blacklist calculateFlexibleWindowBounds(Landroid/content/Intent;II)Landroid/os/Bundle;
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "appOrientation"    # I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1297
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->calculateFlexibleWindowBounds(Landroid/content/Intent;II)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 14
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "packageName"    # Ljava/lang/String;
    .param p3, "param1"    # I
    .param p4, "param2"    # Z
    .param p5, "param3"    # Ljava/lang/String;
    .param p6, "object"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1758
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    move-object v6, p6

    .end local p1    # "method":Ljava/lang/String;
    .end local p2    # "packageName":Ljava/lang/String;
    .end local p3    # "param1":I
    .end local p4    # "param2":Z
    .end local p5    # "param3":Ljava/lang/String;
    .end local p6    # "object":Landroid/os/Bundle;
    .local v1, "method":Ljava/lang/String;
    .local v2, "packageName":Ljava/lang/String;
    .local v3, "param1":I
    .local v4, "param2":Z
    .local v5, "param3":Ljava/lang/String;
    .local v6, "object":Landroid/os/Bundle;
    invoke-interface/range {v0 .. v6}, Landroid/app/IOplusActivityTaskManager;->callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object p1

    return-object p1
.end method

.method public blacklist clearEmbeddedContainerTask([II)V
    .registers 4
    .param p1, "embeddedTaskIdList"    # [I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1527
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->clearEmbeddedContainerTask([II)V

    .line 1528
    return-void
.end method

.method public whitelist clientTransactionComplete(Landroid/os/IBinder;I)V
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "seq"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1248
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->clientTransactionComplete(Landroid/os/IBinder;I)V

    .line 1249
    return-void
.end method

.method public blacklist closeSplitTask(ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1423
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->closeSplitTask(ILandroid/os/Bundle;)V

    .line 1424
    return-void
.end method

.method public whitelist createMirageDisplay(Landroid/view/Surface;)I
    .registers 3
    .param p1, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1003
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->createMirageDisplay(Landroid/view/Surface;)I

    move-result v0

    return v0
.end method

.method public blacklist createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;
    .registers 3
    .param p1, "callback"    # Lcom/oplus/miragewindow/IOplusMirageSessionCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1082
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;

    move-result-object v0

    return-object v0
.end method

.method public blacklist createVirtualDisplayDevice(Landroid/os/Bundle;)I
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2011
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->createVirtualDisplayDevice(Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public whitelist dismissSplitScreenMode(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 744
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->dismissSplitScreenMode(I)Z

    move-result v0

    return v0
.end method

.method public whitelist exitCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1706
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->exitCompactWindow()I

    move-result v0

    return v0
.end method

.method public blacklist exitFlexibleEmbeddedTask(I)V
    .registers 3
    .param p1, "embeddedTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1486
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->exitFlexibleEmbeddedTask(I)V

    .line 1487
    return-void
.end method

.method public blacklist exitSplitTask(ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1434
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->exitSplitTask(ILandroid/os/Bundle;)V

    .line 1435
    return-void
.end method

.method public whitelist expandToFullScreen()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1046
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->expandToFullScreen()V

    .line 1047
    return-void
.end method

.method public whitelist feedbackUserSelection(IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "eventId"    # I
    .param p2, "selection"    # I
    .param p3, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 995
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->feedbackUserSelection(IILandroid/os/Bundle;)V

    .line 996
    return-void
.end method

.method public blacklist getActivityConfigs(Landroid/os/IBinder;Ljava/lang/String;)Landroid/os/Bundle;
    .registers 4
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1635
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->getActivityConfigs(Landroid/os/IBinder;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getAllTopAppInfos()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/app/OplusAppInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 324
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getAllTopAppInfos()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "change"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1664
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getConfineMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 690
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getConfineMode()I

    move-result v0

    return v0
.end method

.method public whitelist getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 434
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getEmbeddedChildren(I)Ljava/util/List;
    .registers 3
    .param p1, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 828
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getEmbeddedChildren(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getEmbeddedChildrenSnapshot(IZZ)Landroid/window/TaskSnapshot;
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "isLowResolution"    # Z
    .param p3, "takeSnapshotIfNeeded"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 815
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->getEmbeddedChildrenSnapshot(IZZ)Landroid/window/TaskSnapshot;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getEnterPuttAppInfos()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/putt/OplusPuttEnterInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1909
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getEnterPuttAppInfos()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getFlexibleMinimizedTaskId()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2088
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getFlexibleMinimizedTaskId()I

    move-result v0

    return v0
.end method

.method public whitelist getFocusBounds(Z)Landroid/graphics/Rect;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1745
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getFocusBounds(Z)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getFocusComponent(Z)Landroid/content/ComponentName;
    .registers 3
    .param p1, "isPrimary"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1749
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getFocusComponent(Z)Landroid/content/ComponentName;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getFocusMode()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1741
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getFocusMode()I

    move-result v0

    return v0
.end method

.method public whitelist getFreeformConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 330
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getGetDisplayIdForPackageName(Ljava/lang/String;)I
    .registers 3
    .param p1, "packageName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1086
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getGetDisplayIdForPackageName(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 966
    new-instance v0, Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;

    invoke-direct {v0}, Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;-><init>()V

    .line 967
    .local v0, "config":Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/app/IOplusActivityTaskManager;->getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;

    move-result-object v0

    .line 968
    return-object v0
.end method

.method public blacklist getLastEvent()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/graphics/Point;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 910
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getLastEvent()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getLeftRightBoundsForIme()Landroid/os/Bundle;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 852
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getLeftRightBoundsForIme()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMinimizedBounds(I)Landroid/graphics/Rect;
    .registers 3
    .param p1, "dockedSide"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 836
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getMinimizedBounds(I)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getMirageDisplayCastMode(I)I
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1042
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getMirageDisplayCastMode(I)I

    move-result v0

    return v0
.end method

.method public whitelist getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1058
    new-instance v0, Lcom/oplus/miragewindow/OplusMirageWindowInfo;

    invoke-direct {v0}, Lcom/oplus/miragewindow/OplusMirageWindowInfo;-><init>()V

    .line 1059
    .local v0, "info":Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/app/IOplusActivityTaskManager;->getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;

    move-result-object v0

    .line 1060
    return-object v0
.end method

.method public blacklist getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1688
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPWAppInfo()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1730
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getPWAppInfo()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getPackagesState()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 716
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getPackagesState()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getPauseInRecentsAnimPkgList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1857
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getPauseInRecentsAnimPkgList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getPocketStudioTaskRegion(I)Ljava/util/Map;
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Landroid/graphics/Rect;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1350
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getPocketStudioTaskRegion(I)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getRealSize()Landroid/graphics/Point;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1753
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getRealSize()Landroid/graphics/Point;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getRecentEmbeddedTasksForContainer(I)Ljava/util/List;
    .registers 3
    .param p1, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RecentTaskInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1538
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getRecentEmbeddedTasksForContainer(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getRenderThreadTid(I)I
    .registers 3
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 500
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getRenderThreadTid(I)I

    move-result v0

    return v0
.end method

.method public whitelist getSecurityFlagCurrentPage()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1651
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getSecurityFlagCurrentPage()Z

    move-result v0

    return v0
.end method

.method public blacklist getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 842
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getSplitScreenState(Landroid/content/Intent;)I
    .registers 3
    .param p1, "intent"    # Landroid/content/Intent;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 318
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getSplitScreenState(Landroid/content/Intent;)I

    move-result v0

    return v0
.end method

.method public whitelist getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 3
    .param p1, "event"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 758
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTaskDescriptionLabel(I)Ljava/lang/String;
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2382
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getTaskDescriptionLabel(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;
    .registers 3
    .param p1, "name"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1010
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTopActivityComponentName()Landroid/content/ComponentName;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 303
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getTopActivityComponentName()Landroid/content/ComponentName;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 307
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getUriForFlexibleWindow(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p1, "key"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2104
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getUriForFlexibleWindow(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getVisibleTasks(I)Ljava/util/List;
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2174
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getVisibleTasks(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getZoomAppConfigList(I)Ljava/util/List;
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 444
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->getZoomAppConfigList(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomBounds(ZI)Landroid/graphics/Rect;
    .registers 4
    .param p1, "landApp"    # Z
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2307
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->getZoomBounds(ZI)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomBoundsByTaskId(II)Landroid/graphics/Rect;
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2320
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->getZoomBoundsByTaskId(II)Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 492
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;

    move-result-object v0

    return-object v0
.end method

.method public whitelist getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 470
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    move-result-object v0

    return-object v0
.end method

.method public whitelist handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z
    .registers 12
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .param p5, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 541
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    .end local p1    # "target":Ljava/lang/String;
    .end local p2    # "userId":I
    .end local p3    # "callPkg":Ljava/lang/String;
    .end local p4    # "extension":Landroid/os/Bundle;
    .end local p5    # "type":I
    .local v1, "target":Ljava/lang/String;
    .local v2, "userId":I
    .local v3, "callPkg":Ljava/lang/String;
    .local v4, "extension":Landroid/os/Bundle;
    .local v5, "type":I
    invoke-interface/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager;->handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z

    move-result p1

    return p1
.end method

.method public whitelist hasColorSplitFeature()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 859
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->hasColorSplitFeature()Z

    move-result v0

    return v0
.end method

.method public whitelist hasLargeScreenFeature()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 785
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->hasLargeScreenFeature()Z

    move-result v0

    return v0
.end method

.method public whitelist hideZoomWindow(I)V
    .registers 3
    .param p1, "flag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 439
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->hideZoomWindow(I)V

    .line 440
    return-void
.end method

.method public whitelist invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "params"    # Ljava/lang/String;
    .param p4, "objects"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1762
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public blacklist isClickAtPocketStudioArea(III)Z
    .registers 5
    .param p1, "displayId"    # I
    .param p2, "rowX"    # I
    .param p3, "rowY"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1622
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->isClickAtPocketStudioArea(III)Z

    move-result v0

    return v0
.end method

.method public whitelist isCurrentAppSupportCompactMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1710
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isCurrentAppSupportCompactMode()Z

    move-result v0

    return v0
.end method

.method public blacklist isFlexibleTaskEnabled(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2039
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isFlexibleTaskEnabled(I)Z

    move-result v0

    return v0
.end method

.method public whitelist isFolderInnerScreen()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 832
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isFolderInnerScreen()Z

    move-result v0

    return v0
.end method

.method public whitelist isFreeformEnabled()Z
    .registers 2

    .line 334
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isInAppInnerSplitScreen(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1933
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isInAppInnerSplitScreen(I)Z

    move-result v0

    return v0
.end method

.method public blacklist isInPocketStudio(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1308
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isInPocketStudio(I)Z

    move-result v0

    return v0
.end method

.method public blacklist isInPocketStudioForStandard(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1340
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isInPocketStudioForStandard(I)Z

    move-result v0

    return v0
.end method

.method public whitelist isInSplitScreenMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 740
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isInSplitScreenMode()Z

    move-result v0

    return v0
.end method

.method public whitelist isLockDeviceMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 627
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isLockDeviceMode()Z

    move-result v0

    return v0
.end method

.method public blacklist isMinimizedPocketStudio(I)Z
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1330
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isMinimizedPocketStudio(I)Z

    move-result v0

    return v0
.end method

.method public whitelist isMirageWindowShow()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1022
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isMirageWindowShow()Z

    move-result v0

    return v0
.end method

.method public blacklist isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z
    .registers 3
    .param p1, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1815
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z

    move-result v0

    return v0
.end method

.method public blacklist isPowerKeyPressed()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 888
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isPowerKeyPressed()Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportEdgeTouchPrevent()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 648
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isSupportEdgeTouchPrevent()Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportMirageWindowMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1054
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isSupportMirageWindowMode()Z

    move-result v0

    return v0
.end method

.method public blacklist isSupportPuttMode(ILjava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 12
    .param p1, "type"    # I
    .param p2, "target"    # Ljava/lang/String;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .param p5, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1923
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    .end local p1    # "type":I
    .end local p2    # "target":Ljava/lang/String;
    .end local p3    # "userId":I
    .end local p4    # "callPkg":Ljava/lang/String;
    .end local p5    # "options":Landroid/os/Bundle;
    .local v1, "type":I
    .local v2, "target":Ljava/lang/String;
    .local v3, "userId":I
    .local v4, "callPkg":Ljava/lang/String;
    .local v5, "options":Landroid/os/Bundle;
    invoke-interface/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager;->isSupportPuttMode(ILjava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public whitelist isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 6
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 466
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist isSupportZoomWindowMode()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 461
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isSupportZoomWindowMode()Z

    move-result v0

    return v0
.end method

.method public blacklist isTaskExist(IIILandroid/content/Intent;Landroid/os/Bundle;)Z
    .registers 12
    .param p1, "matchMode"    # I
    .param p2, "taskId"    # I
    .param p3, "userId"    # I
    .param p4, "baseIntent"    # Landroid/content/Intent;
    .param p5, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2249
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    .end local p1    # "matchMode":I
    .end local p2    # "taskId":I
    .end local p3    # "userId":I
    .end local p4    # "baseIntent":Landroid/content/Intent;
    .end local p5    # "options":Landroid/os/Bundle;
    .local v1, "matchMode":I
    .local v2, "taskId":I
    .local v3, "userId":I
    .local v4, "baseIntent":Landroid/content/Intent;
    .local v5, "options":Landroid/os/Bundle;
    invoke-interface/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager;->isTaskExist(IIILandroid/content/Intent;Landroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public whitelist isTouchNodeSupport(II)Z
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1136
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->isTouchNodeSupport(II)Z

    move-result v0

    return v0
.end method

.method public whitelist isZoomSimpleModeEnable()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 549
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->isZoomSimpleModeEnable()Z

    move-result v0

    return v0
.end method

.method public blacklist isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "componentName"    # Landroid/content/ComponentName;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 528
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z

    move-result v0

    return v0
.end method

.method public whitelist lockRotationInGame(I[Ljava/lang/String;)Z
    .registers 4
    .param p1, "state"    # I
    .param p2, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1671
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->lockRotationInGame(I[Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist moveCompactWindowToLeft()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1714
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->moveCompactWindowToLeft()I

    move-result v0

    return v0
.end method

.method public whitelist moveCompactWindowToRight()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1718
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->moveCompactWindowToRight()I

    move-result v0

    return v0
.end method

.method public whitelist moveTaskToBack(IZ)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "cancelAnim"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2369
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->moveActivityTaskToBack(IZ)V

    .line 2370
    return-void
.end method

.method public blacklist moveTaskToDisplay(IIZ)V
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "displayId"    # I
    .param p3, "top"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2025
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->moveTaskToDisplay(IIZ)V

    .line 2026
    return-void
.end method

.method public blacklist notifyEmbeddedTasksChangeFocus(ZI)V
    .registers 4
    .param p1, "isStateSteady"    # Z
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1380
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->notifyEmbeddedTasksChangeFocus(ZI)V

    .line 1381
    return-void
.end method

.method public blacklist notifyFlexibleSplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;I)V
    .registers 5
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1390
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->notifyFlexibleSplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;I)V

    .line 1391
    return-void
.end method

.method public blacklist notifyFlexibleTaskEvent(IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "taskId"    # I
    .param p2, "event"    # I
    .param p3, "extra"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2117
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->notifyFlexibleTaskEvent(IILandroid/os/Bundle;)V

    .line 2118
    return-void
.end method

.method public whitelist notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V
    .registers 5
    .param p1, "event"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "broadcast"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 732
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V

    .line 733
    return-void
.end method

.method public whitelist notifyTouchNodeChange(IJIIILjava/lang/String;)Z
    .registers 16
    .param p1, "clientFlag"    # I
    .param p2, "time"    # J
    .param p4, "deviceId"    # I
    .param p5, "nodeFlag"    # I
    .param p6, "data"    # I
    .param p7, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1189
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move v1, p1

    move-wide v2, p2

    move v4, p4

    move v5, p5

    move v6, p6

    move-object v7, p7

    .end local p1    # "clientFlag":I
    .end local p2    # "time":J
    .end local p4    # "deviceId":I
    .end local p5    # "nodeFlag":I
    .end local p6    # "data":I
    .end local p7    # "info":Ljava/lang/String;
    .local v1, "clientFlag":I
    .local v2, "time":J
    .local v4, "deviceId":I
    .local v5, "nodeFlag":I
    .local v6, "data":I
    .local v7, "info":Ljava/lang/String;
    invoke-interface/range {v0 .. v7}, Landroid/app/IOplusActivityTaskManager;->notifyTouchNodeChange(IJIIILjava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public whitelist notifyUiSwitched(Ljava/lang/String;I)V
    .registers 4
    .param p1, "uiInfo"    # Ljava/lang/String;
    .param p2, "status"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1829
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->notifyUiSwitched(Ljava/lang/String;I)V

    .line 1830
    return-void
.end method

.method public blacklist notifyZoomStateChange(Ljava/lang/String;I)V
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "action"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 556
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->notifyZoomStateChange(Ljava/lang/String;I)V

    .line 557
    return-void
.end method

.method public whitelist onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V
    .registers 3
    .param p1, "cvInfo"    # Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 452
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V

    .line 453
    return-void
.end method

.method public whitelist onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V
    .registers 3
    .param p1, "floatHandleInfo"    # Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 482
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V

    .line 483
    return-void
.end method

.method public whitelist onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V
    .registers 3
    .param p1, "inputEventInfo"    # Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 448
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V

    .line 449
    return-void
.end method

.method public whitelist onProtocolUpdated(Ljava/lang/String;)Z
    .registers 3
    .param p1, "content"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1734
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->onProtocolUpdated(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist pauseInRecentsAnim(I)V
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1844
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->pauseInRecentsAnim(I)V

    .line 1845
    return-void
.end method

.method public blacklist preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "extra"    # Landroid/os/Bundle;
    .param p3, "surface"    # Landroid/view/SurfaceControl;
    .param p4, "callback"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2487
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V

    .line 2488
    return-void
.end method

.method public whitelist readNodeFile(I)Ljava/lang/String;
    .registers 3
    .param p1, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1120
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->readNodeFile(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist readNodeFileByDevice(II)Ljava/lang/String;
    .registers 4
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1124
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->readNodeFileByDevice(II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist rebindDisplayIfNeeded(II)Z
    .registers 4
    .param p1, "castDisplayId"    # I
    .param p2, "mirageDisplayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1090
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->rebindDisplayIfNeeded(II)Z

    move-result v0

    return v0
.end method

.method public blacklist registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "observer"    # Lcom/oplus/app/IOplusAppSwitchObserver;
    .param p3, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 367
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1722
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1104
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/globaldrag/IDragAndDropListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 383
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V

    .line 384
    return-void
.end method

.method public blacklist registerEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1943
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V

    .line 1944
    return-void
.end method

.method public blacklist registerEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/os/IOplusTouchNodeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1225
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V
    .registers 3
    .param p1, "listener"    # Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2129
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V

    .line 2130
    return-void
.end method

.method public blacklist registerFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;I)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1273
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;I)Z

    move-result v0

    return v0
.end method

.method public blacklist registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z
    .registers 5
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroid/os/IOplusKeyEventObserver;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 954
    .local p3, "configs":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z
    .registers 5
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/IOplusKeyEventObserver;
    .param p3, "listenFlag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 873
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z

    move-result v0

    return v0
.end method

.method public whitelist registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 720
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 987
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 979
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerOplusTaskStackListener(Lcom/oplus/app/OplusTaskStackListener;[II)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/app/OplusTaskStackListener;
    .param p2, "typeList"    # [I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2220
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->registerOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;[II)Z

    move-result v0

    return v0
.end method

.method public blacklist registerPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttEventObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1881
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1867
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z
    .registers 4
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "observer"    # Landroid/os/ILongPressScreenshotCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 918
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1643
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 749
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerStartingWindowObserver(Lcom/oplus/app/OplusStartingWindowObserver;)V
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/OplusStartingWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2465
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V

    .line 2466
    return-void
.end method

.method public whitelist registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 936
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist registerTaskInfoChangeListener(Lcom/oplus/app/OplusTaskInfoChangeListener;II)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/app/OplusTaskInfoChangeListener;
    .param p2, "type"    # I
    .param p3, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2190
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->registerTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;II)Z

    move-result v0

    return v0
.end method

.method public whitelist registerWindowChangeListener(Landroid/content/Context;Ljava/lang/String;Lcom/oplus/app/OplusWindowChangeRegisterParam;Lcom/oplus/app/OplusWindowChangeObserver;)Z
    .registers 8
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "sence"    # Ljava/lang/String;
    .param p3, "param"    # Lcom/oplus/app/OplusWindowChangeRegisterParam;
    .param p4, "observer"    # Lcom/oplus/app/OplusWindowChangeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2402
    const/4 v0, 0x0

    const-string v1, "OplusWindowChangeInfo"

    if-eqz p1, :cond_23

    if-eqz p3, :cond_23

    if-nez p4, :cond_a

    goto :goto_23

    .line 2406
    :cond_a
    invoke-direct {p0, p1}, Landroid/app/OplusActivityTaskManager;->generatePackageInfo(Landroid/content/Context;)V

    .line 2407
    iget-object v2, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    if-nez v2, :cond_18

    .line 2408
    const-string/jumbo v2, "registerWindowChangeListener fail, the package info is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2409
    return v0

    .line 2412
    :cond_18
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    iget-object v1, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    invoke-interface {v0, v1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->registerWindowChangeListener(Ljava/lang/String;Ljava/lang/String;Lcom/oplus/app/OplusWindowChangeRegisterParam;Lcom/oplus/app/IOplusWindowChangeObserver;)Z

    move-result v0

    return v0

    .line 2403
    :cond_23
    :goto_23
    const-string/jumbo v2, "registerWindowChangeListener fail, the input parameter is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2404
    return v0
.end method

.method public whitelist registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1255
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2150
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 418
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist releaseScreenshotRegion()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 903
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->releaseScreenshotRegion()Z

    move-result v0

    return v0
.end method

.method public blacklist releaseVirtualDisplayDevice(I)V
    .registers 3
    .param p1, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2018
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->releaseVirtualDisplayDevice(I)V

    .line 2019
    return-void
.end method

.method public blacklist removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1804
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist removeEmbeddedContainerTask(II)V
    .registers 4
    .param p1, "embeddedTaskId"    # I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1476
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->removeEmbeddedContainerTask(II)V

    .line 1477
    return-void
.end method

.method public blacklist removeFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    .line 352
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist removePuttTask(ILjava/lang/String;I)Z
    .registers 5
    .param p1, "exitAction"    # I
    .param p2, "pkg"    # Ljava/lang/String;
    .param p3, "puttTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1916
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->removePuttTask(ILjava/lang/String;I)Z

    move-result v0

    return v0
.end method

.method public blacklist removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 584
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist replaceLockTaskPackages([Ljava/lang/String;)V
    .registers 3
    .param p1, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 618
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->replaceLockTaskPackages([Ljava/lang/String;)V

    .line 619
    return-void
.end method

.method public blacklist replaceSplitTask(ILandroid/content/Intent;ILandroid/os/Bundle;)V
    .registers 6
    .param p1, "oldTaskId"    # I
    .param p2, "intent"    # Landroid/content/Intent;
    .param p3, "newTaskId"    # I
    .param p4, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1447
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->replaceSplitTask(ILandroid/content/Intent;ILandroid/os/Bundle;)V

    .line 1448
    return-void
.end method

.method public blacklist reportViewExtractResult(Landroid/os/Bundle;)V
    .registers 3
    .param p1, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1982
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->reportViewExtractResult(Landroid/os/Bundle;)V

    .line 1983
    return-void
.end method

.method public blacklist requestViewExtractData(Landroid/app/IAssistDataReceiver;Landroid/os/Bundle;Landroid/os/IBinder;I)V
    .registers 6
    .param p1, "receiver"    # Landroid/app/IAssistDataReceiver;
    .param p2, "receiverExtras"    # Landroid/os/Bundle;
    .param p3, "activityToken"    # Landroid/os/IBinder;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1990
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->requestViewExtractData(Landroid/app/IAssistDataReceiver;Landroid/os/Bundle;Landroid/os/IBinder;I)V

    .line 1991
    return-void
.end method

.method public whitelist resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z
    .registers 3
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 644
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public blacklist resetFlexibleTask(IZZZ)V
    .registers 6
    .param p1, "embeddedTaskId"    # I
    .param p2, "needResize"    # Z
    .param p3, "doAnimation"    # Z
    .param p4, "isFromSplit"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1514
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->resetFlexibleTask(IZZZ)V

    .line 1515
    return-void
.end method

.method public blacklist resetNoReparentTask(I)V
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2081
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->resetNoReparentTask(I)V

    .line 2082
    return-void
.end method

.method public blacklist sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z
    .registers 4
    .param p1, "weChatIntent"    # Landroid/app/PendingIntent;
    .param p2, "message"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1786
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public blacklist sendMirageEvents(ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "eventId"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2293
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->sendMirageEvents(ILandroid/os/Bundle;)V

    .line 2294
    return-void
.end method

.method public whitelist setBackInvokePolicyForPredictive(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 6
    .param p1, "activity"    # Landroid/app/Activity;
    .param p2, "bundle"    # Landroid/os/Bundle;

    .line 1202
    const/4 v0, 0x0

    .line 1203
    .local v0, "activityToken":Landroid/os/IBinder;
    if-eqz p1, :cond_8

    .line 1204
    :try_start_3
    invoke-virtual {p1}, Landroid/app/Activity;->getActivityToken()Landroid/os/IBinder;

    move-result-object v1

    move-object v0, v1

    .line 1206
    :cond_8
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v1

    invoke-interface {v1, v0, p2}, Landroid/app/IOplusActivityTaskManager;->setBackInvokePolicyForPredictive(Landroid/os/IBinder;Landroid/os/Bundle;)V
    :try_end_f
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_f} :catch_10

    .line 1209
    .end local v0    # "activityToken":Landroid/os/IBinder;
    goto :goto_19

    .line 1207
    :catch_10
    move-exception v0

    .line 1208
    .local v0, "e":Landroid/os/RemoteException;
    sget-object v1, Landroid/app/OplusActivityTaskManager;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "setBackInvokePolicyForPredictive remoteException "

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 1210
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_19
    return-void
.end method

.method public whitelist setConfineMode(IZ)V
    .registers 5
    .param p1, "mode"    # I
    .param p2, "on"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 677
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, p1, p2, v1}, Landroid/app/IOplusActivityTaskManager;->setConfineMode(IZLandroid/os/IBinder;)V

    .line 678
    return-void
.end method

.method public blacklist setConfineModeAsLink(IZLandroid/os/IBinder;)V
    .registers 5
    .param p1, "mode"    # I
    .param p2, "on"    # Z
    .param p3, "token"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 686
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->setConfineMode(IZLandroid/os/IBinder;)V

    .line 687
    return-void
.end method

.method public whitelist setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V
    .registers 4
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 640
    .local p2, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V

    .line 641
    return-void
.end method

.method public whitelist setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V
    .registers 4
    .param p1, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 653
    .local p2, "rulesMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V

    .line 654
    return-void
.end method

.method public blacklist setEmbeddedContainerTask(II)V
    .registers 4
    .param p1, "embeddedTaskId"    # I
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1402
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setEmbeddedContainerTask(II)V

    .line 1403
    return-void
.end method

.method public blacklist setFlexibleFrame(ILandroid/os/Bundle;)V
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1361
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setFlexibleFrame(ILandroid/os/Bundle;)V

    .line 1362
    return-void
.end method

.method public blacklist setFlexibleTaskEmbedding(IZ)V
    .registers 4
    .param p1, "embeddedTaskId"    # I
    .param p2, "state"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1498
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setFlexibleTaskEmbedding(IZ)V

    .line 1499
    return-void
.end method

.method public blacklist setFlexibleTaskEnabled(IZ)Z
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2051
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setFlexibleTaskEnabled(IZ)Z

    move-result v0

    return v0
.end method

.method public blacklist setFocusAppForEmbeddedTask(I)V
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1412
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setFocusAppForEmbeddedTask(I)V

    .line 1413
    return-void
.end method

.method public whitelist setGimbalLaunchPkg(Ljava/lang/String;)V
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 702
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setGimbalLaunchPkg(Ljava/lang/String;)V

    .line 703
    return-void
.end method

.method public whitelist setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V
    .registers 3
    .param p1, "config"    # Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 972
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V

    .line 973
    return-void
.end method

.method public blacklist setInputConsumerEnabled(Z)Z
    .registers 3
    .param p1, "enabled"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 509
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setInputConsumerEnabled(Z)V

    .line 510
    const/4 v0, 0x1

    return v0
.end method

.method public blacklist setIsInFocusAnimating(Z)V
    .registers 3
    .param p1, "isInFocusAnimating"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1371
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setIsInFocusAnimating(Z)V

    .line 1372
    return-void
.end method

.method public blacklist setMinimizedPocketStudio(ZI)V
    .registers 4
    .param p1, "minimized"    # Z
    .param p2, "displayId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1319
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setMinimizedPocketStudio(ZI)V

    .line 1320
    return-void
.end method

.method public whitelist setMirageDisplaySurfaceById(ILandroid/view/Surface;)V
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1034
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setMirageDisplaySurfaceById(ILandroid/view/Surface;)V

    .line 1035
    return-void
.end method

.method public whitelist setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V
    .registers 4
    .param p1, "mode"    # I
    .param p2, "surface"    # Landroid/view/Surface;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1038
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V

    .line 1039
    return-void
.end method

.method public blacklist setMirageDisplayUserRotation(IILandroid/os/Bundle;)V
    .registers 5
    .param p1, "displayId"    # I
    .param p2, "userRotation"    # I
    .param p3, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2286
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->setMirageDisplayUserRotation(IILandroid/os/Bundle;)V

    .line 2287
    return-void
.end method

.method public whitelist setMirageWindowSilent(Ljava/lang/String;)V
    .registers 3
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1050
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setMirageWindowSilent(Ljava/lang/String;)V

    .line 1051
    return-void
.end method

.method public whitelist setPackagesState(Ljava/util/Map;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 709
    .local p1, "packageMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setPackagesState(Ljava/util/Map;)V

    .line 710
    return-void
.end method

.method public whitelist setPermitList(IILjava/util/List;Z)V
    .registers 6
    .param p1, "mode"    # I
    .param p2, "type"    # I
    .param p4, "isMultiApp"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 695
    .local p3, "permits":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->setPermitList(IILjava/util/List;Z)V

    .line 696
    return-void
.end method

.method public blacklist setRegionScreenshot(Z)V
    .registers 3
    .param p1, "following"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 896
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setRegionScreenshot(Z)V

    .line 897
    return-void
.end method

.method public blacklist setSecureController(Landroid/app/IActivityController;)V
    .registers 3
    .param p1, "watcher"    # Landroid/app/IActivityController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 299
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setSecureController(Landroid/app/IActivityController;)V

    .line 300
    return-void
.end method

.method public whitelist setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 736
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist setTaskInsensibleParams(Landroid/content/Intent;IILandroid/os/Bundle;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .param p3, "insensibleFlag"    # I
    .param p4, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1565
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->setTaskInsensibleParams(Landroid/content/Intent;IILandroid/os/Bundle;)V

    .line 1566
    return-void
.end method

.method public blacklist setTaskWindowingModeSplitScreen(I)I
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 773
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setTaskWindowingModeSplitScreen(I)I

    move-result v0

    return v0
.end method

.method public whitelist setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V
    .registers 3
    .param p1, "config"    # Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 474
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V

    .line 475
    return-void
.end method

.method public blacklist shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z
    .registers 4
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "down"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1681
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z

    move-result v0

    return v0
.end method

.method public blacklist shouldSkipStartPocketStudio(Ljava/util/List;[I[ILandroid/os/Bundle;Landroid/os/Bundle;)Z
    .registers 12
    .param p2, "taskIdList"    # [I
    .param p3, "userIdList"    # [I
    .param p4, "activityBundle"    # Landroid/os/Bundle;
    .param p5, "canvasExtra"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/Intent;",
            ">;[I[I",
            "Landroid/os/Bundle;",
            "Landroid/os/Bundle;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2001
    .local p1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    .end local p1    # "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .end local p2    # "taskIdList":[I
    .end local p3    # "userIdList":[I
    .end local p4    # "activityBundle":Landroid/os/Bundle;
    .end local p5    # "canvasExtra":Landroid/os/Bundle;
    .local v1, "intentList":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .local v2, "taskIdList":[I
    .local v3, "userIdList":[I
    .local v4, "activityBundle":Landroid/os/Bundle;
    .local v5, "canvasExtra":Landroid/os/Bundle;
    invoke-interface/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager;->shouldSkipStartPocketStudio(Ljava/util/List;[I[ILandroid/os/Bundle;Landroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public blacklist splitScreenForApplication(Landroid/content/Context;Landroid/content/Intent;I)Z
    .registers 7
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;
    .param p3, "position"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 670
    const/high16 v0, 0x44000000    # 512.0f

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v2, p2, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;ILandroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object v0

    .line 671
    .local v0, "pendingIntent":Landroid/app/PendingIntent;
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v1

    invoke-interface {v1, v0, p3}, Landroid/app/IOplusActivityTaskManager;->splitScreenForApplication(Landroid/app/PendingIntent;I)Z

    move-result v1

    return v1
.end method

.method public whitelist splitScreenForEdgePanel(Landroid/content/Intent;I)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 660
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->splitScreenForEdgePanel(Landroid/content/Intent;I)I

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForEdgePanelExt(Landroid/content/Intent;ZI)Z
    .registers 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "launchToPrimary"    # Z
    .param p3, "launchArea"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 781
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->splitScreenForEdgePanelExt(Landroid/content/Intent;ZI)Z

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForRecentTasks(I)Z
    .registers 3
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 766
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->splitScreenForRecentTasks(I)Z

    move-result v0

    return v0
.end method

.method public whitelist splitScreenForTopApp(I)Z
    .registers 3
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 762
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->splitScreenForTopApp(I)Z

    move-result v0

    return v0
.end method

.method public blacklist startActivityFromRecentsForFlexible(ILandroid/os/Bundle;)I
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 800
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startActivityFromRecentsForFlexible(ILandroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public blacklist startActivityInTask(Landroid/content/Intent;I)V
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1549
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startActivityInTask(Landroid/content/Intent;I)V

    .line 1550
    return-void
.end method

.method public blacklist startAnyActivity(Landroid/content/Intent;Landroid/os/Bundle;)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1577
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startAnyActivity(Landroid/content/Intent;Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public whitelist startCompactWindow()I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1702
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->startCompactWindow()I

    move-result v0

    return v0
.end method

.method public blacklist startDragFullscreenAnimation(Landroid/os/Bundle;Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;)V
    .registers 4
    .param p1, "bOptions"    # Landroid/os/Bundle;
    .param p2, "callback"    # Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1585
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startDragFullscreenAnimation(Landroid/os/Bundle;Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;)V

    .line 1586
    return-void
.end method

.method public blacklist startFlexibleWindowForRecentTasks(ILandroid/graphics/Rect;)Z
    .registers 4
    .param p1, "taskId"    # I
    .param p2, "rect"    # Landroid/graphics/Rect;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1609
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startFlexibleWindowForRecentTasks(ILandroid/graphics/Rect;)Z

    move-result v0

    return v0
.end method

.method public whitelist startLockDeviceMode(Ljava/lang/String;[Ljava/lang/String;)V
    .registers 4
    .param p1, "rootPkg"    # Ljava/lang/String;
    .param p2, "packages"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 592
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startLockDeviceMode(Ljava/lang/String;[Ljava/lang/String;)V

    .line 593
    return-void
.end method

.method public whitelist startLockDeviceModeWithFlag(Ljava/lang/String;[Ljava/lang/String;I)V
    .registers 5
    .param p1, "rootPkg"    # Ljava/lang/String;
    .param p2, "packages"    # [Ljava/lang/String;
    .param p3, "flag"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 606
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->startLockDeviceModeWithFlag(Ljava/lang/String;[Ljava/lang/String;I)V

    .line 607
    return-void
.end method

.method public whitelist startMiniZoomFromZoom(I)V
    .registers 3
    .param p1, "startWay"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 545
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->startMiniZoomFromZoom(I)V

    .line 546
    return-void
.end method

.method public whitelist startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I
    .registers 4
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1018
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public whitelist startMirageWindowModeWithName(Landroid/content/ComponentName;IILandroid/os/Bundle;)V
    .registers 6
    .param p1, "cpnName"    # Landroid/content/ComponentName;
    .param p2, "taskId"    # I
    .param p3, "flags"    # I
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1014
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->startMirageWindowModeWithName(Landroid/content/ComponentName;IILandroid/os/Bundle;)V

    .line 1015
    return-void
.end method

.method public blacklist startPutt(Lcom/oplus/putt/PuttParams;)Z
    .registers 3
    .param p1, "params"    # Lcom/oplus/putt/PuttParams;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1902
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->startPutt(Lcom/oplus/putt/PuttParams;)Z

    move-result v0

    return v0
.end method

.method public whitelist startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 399
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public blacklist startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 6
    .param p1, "pendingIntent"    # Landroid/app/PendingIntent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 409
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0

    return v0
.end method

.method public whitelist stopLockDeviceMode()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 623
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->stopLockDeviceMode()V

    .line 624
    return-void
.end method

.method public whitelist stopMirageWindowMode(Landroid/os/Bundle;)V
    .registers 3
    .param p1, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1030
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->stopMirageWindowMode(Landroid/os/Bundle;)V

    .line 1031
    return-void
.end method

.method public whitelist stopMirageWindowModeOld()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1026
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->stopMirageWindowModeOld()V

    .line 1027
    return-void
.end method

.method public blacklist stopPutt(Ljava/lang/String;ILandroid/os/Bundle;)Z
    .registers 5
    .param p1, "puttHash"    # Ljava/lang/String;
    .param p2, "exitAction"    # I
    .param p3, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1895
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->stopPutt(Ljava/lang/String;ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist swapDockedFullscreenStack()V
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 314
    return-void
.end method

.method public blacklist takeScreenshot(Landroid/window/WindowContainerToken;Landroid/view/SurfaceControl;)Landroid/view/SurfaceControl;
    .registers 4
    .param p1, "windowContainerToken"    # Landroid/window/WindowContainerToken;
    .param p2, "outSurfaceControl"    # Landroid/view/SurfaceControl;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1695
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->takeScreenshot(Landroid/window/WindowContainerToken;Landroid/view/SurfaceControl;)Landroid/view/SurfaceControl;

    move-result-object v0

    return-object v0
.end method

.method public blacklist toggleFlexibleWindow(Landroid/os/IBinder;IZZ)Z
    .registers 6
    .param p1, "activityToken"    # Landroid/os/IBinder;
    .param p2, "taskId"    # I
    .param p3, "isNeedAnimation"    # Z
    .param p4, "isEnterZoom"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2279
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->toggleFlexibleWindowByApp(Landroid/os/IBinder;IZZ)Z

    move-result v0

    return v0
.end method

.method public blacklist toggleFlexibleWindow(Ljava/lang/String;)Z
    .registers 3
    .param p1, "toType"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2262
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->toggleFlexibleWindow(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public blacklist unRegisterRegionScreenshot(Ljava/lang/String;Z)Z
    .registers 5
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .param p2, "isBinderDied"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 925
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1}, Landroid/app/IOplusActivityTaskManager;->unRegisterRegionScreenshot(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method public blacklist unbindQuickReplyService()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1779
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0}, Landroid/app/IOplusActivityTaskManager;->unbindQuickReplyService()V

    .line 1780
    return-void
.end method

.method public whitelist unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "config"    # Lcom/oplus/app/OplusAppSwitchConfig;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 373
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1726
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1113
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/globaldrag/IDragAndDropListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 390
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V

    .line 391
    return-void
.end method

.method public blacklist unregisterEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V
    .registers 4
    .param p1, "callback"    # Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .param p2, "containerTaskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1950
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V

    .line 1951
    return-void
.end method

.method public blacklist unregisterEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/os/IOplusTouchNodeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1241
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V
    .registers 3
    .param p1, "listener"    # Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2138
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V

    .line 2139
    return-void
.end method

.method public blacklist unregisterFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1284
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterKeyEventInterceptor(Ljava/lang/String;)Z
    .registers 3
    .param p1, "interceptorFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 958
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterKeyEventInterceptor(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterKeyEventObserver(Ljava/lang/String;)Z
    .registers 3
    .param p1, "observerFingerPrint"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 877
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterKeyEventObserver(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z
    .registers 3
    .param p1, "callback"    # Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 724
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 991
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 983
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterOplusTaskStackListener(Lcom/oplus/app/OplusTaskStackListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/OplusTaskStackListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2234
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttEventObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1888
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/putt/IPuttObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1874
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/ISecurityPageController;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1647
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z
    .registers 4
    .param p1, "observerId"    # I
    .param p2, "observer"    # Lcom/oplus/app/IOplusSplitScreenObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 754
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterStartingWindowObserver(Lcom/oplus/app/OplusStartingWindowObserver;)V
    .registers 3
    .param p1, "observer"    # Lcom/oplus/app/OplusStartingWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2477
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V

    .line 2478
    return-void
.end method

.method public whitelist unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/datasync/ISysStateChangeCallback;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 940
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterTaskInfoChangeListener(Lcom/oplus/app/OplusTaskInfoChangeListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/app/OplusTaskInfoChangeListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2204
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterWindowChangeListener(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 6
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "sence"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2429
    const/4 v0, 0x0

    const-string v1, "OplusWindowChangeInfo"

    if-nez p1, :cond_c

    .line 2430
    const-string/jumbo v2, "unregisterWindowChangeListener fail, the context is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2431
    return v0

    .line 2433
    :cond_c
    invoke-direct {p0, p1}, Landroid/app/OplusActivityTaskManager;->generatePackageInfo(Landroid/content/Context;)V

    .line 2434
    iget-object v2, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    if-nez v2, :cond_1a

    .line 2435
    const-string/jumbo v2, "unregisterWindowChangeListener fail, the package info is null"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2436
    return v0

    .line 2438
    :cond_1a
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    iget-object v1, p0, Landroid/app/OplusActivityTaskManager;->mPackageInfo:Ljava/lang/String;

    invoke-interface {v0, v1, p2}, Landroid/app/IOplusActivityTaskManager;->unregisterWindowChangeListener(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1259
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 3
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2159
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0

    return v0
.end method

.method public blacklist unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 3
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 429
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z
    .registers 4
    .param p1, "module"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 931
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z
    .registers 3
    .param p1, "list"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 999
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/app/IOplusActivityTaskManager;->updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist updateDeferStartingWindowApps(Ljava/util/List;Z)V
    .registers 4
    .param p2, "removeImmdiately"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1657
    .local p1, "packages":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateDeferStartingWindowApps(Ljava/util/List;Z)V

    .line 1658
    return-void
.end method

.method public whitelist updateLockTaskFeatures(II)V
    .registers 5
    .param p1, "userId"    # I
    .param p2, "flags"    # I

    .line 2333
    :try_start_0
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateLockTaskFeatures(II)V
    :try_end_7
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_7} :catch_9

    .line 2336
    nop

    .line 2337
    return-void

    .line 2334
    :catch_9
    move-exception v0

    .line 2335
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public whitelist updateLockTaskPackages(I[Ljava/lang/String;)V
    .registers 5
    .param p1, "userId"    # I
    .param p2, "packages"    # [Ljava/lang/String;

    .line 2348
    if-nez p2, :cond_b

    .line 2349
    sget-object v0, Landroid/app/OplusActivityTaskManager;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "packages is null!"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2350
    return-void

    .line 2353
    :cond_b
    :try_start_b
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateLockTaskPackages(I[Ljava/lang/String;)V
    :try_end_12
    .catch Landroid/os/RemoteException; {:try_start_b .. :try_end_12} :catch_14

    .line 2356
    nop

    .line 2357
    return-void

    .line 2354
    :catch_14
    move-exception v0

    .line 2355
    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->rethrowFromSystemServer()Ljava/lang/RuntimeException;

    move-result-object v1

    throw v1
.end method

.method public whitelist updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z
    .registers 4
    .param p1, "castFlag"    # I
    .param p2, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1064
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public whitelist updatePrivacyProtectionList(Ljava/util/List;Z)Z
    .registers 4
    .param p2, "replace"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1068
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updatePrivacyProtectionList(Ljava/util/List;Z)Z

    move-result v0

    return v0
.end method

.method public whitelist updatePrivacyProtectionListWithBundle(Ljava/util/List;ZZLandroid/os/Bundle;)Z
    .registers 6
    .param p2, "append"    # Z
    .param p3, "isDefault"    # Z
    .param p4, "options"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ",
            "Landroid/os/Bundle;",
            ")Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1073
    .local p1, "name":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Landroid/app/IOplusActivityTaskManager;->updatePrivacyProtectionListWithBundle(Ljava/util/List;ZZLandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public blacklist updateRecordSurfaceViewState(Landroid/os/IBinder;ZZ)V
    .registers 5
    .param p1, "token"    # Landroid/os/IBinder;
    .param p2, "surfaceState"    # Z
    .param p3, "attachedToWindow"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1972
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->updateRecordSurfaceViewState(Landroid/os/IBinder;ZZ)V

    .line 1973
    return-void
.end method

.method public blacklist updateTaskVisibility(Landroid/window/WindowContainerToken;IZZZLandroid/os/Bundle;)V
    .registers 14
    .param p1, "windowContainerToken"    # Landroid/window/WindowContainerToken;
    .param p2, "containerTaskId"    # I
    .param p3, "visible"    # Z
    .param p4, "skipBackToPrevTask"    # Z
    .param p5, "force"    # Z
    .param p6, "bundle"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1464
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move-object v6, p6

    .end local p1    # "windowContainerToken":Landroid/window/WindowContainerToken;
    .end local p2    # "containerTaskId":I
    .end local p3    # "visible":Z
    .end local p4    # "skipBackToPrevTask":Z
    .end local p5    # "force":Z
    .end local p6    # "bundle":Landroid/os/Bundle;
    .local v1, "windowContainerToken":Landroid/window/WindowContainerToken;
    .local v2, "containerTaskId":I
    .local v3, "visible":Z
    .local v4, "skipBackToPrevTask":Z
    .local v5, "force":Z
    .local v6, "bundle":Landroid/os/Bundle;
    invoke-interface/range {v0 .. v6}, Landroid/app/IOplusActivityTaskManager;->updateTaskVisibility(Landroid/window/WindowContainerToken;IZZZLandroid/os/Bundle;)V

    .line 1466
    return-void
.end method

.method public whitelist updateUntrustedTouchConfig(Ljava/lang/String;Z)V
    .registers 4
    .param p1, "configData"    # Ljava/lang/String;
    .param p2, "isRus"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 535
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->updateUntrustedTouchConfig(Ljava/lang/String;Z)V

    .line 536
    return-void
.end method

.method public whitelist writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z
    .registers 5
    .param p1, "callPkg"    # Ljava/lang/String;
    .param p2, "scenePkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 635
    .local p3, "paramCmdList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFile(ILjava/lang/String;)Z
    .registers 4
    .param p1, "nodeFlag"    # I
    .param p2, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1128
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/app/IOplusActivityTaskManager;->writeNodeFile(ILjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFileByDevice(IILjava/lang/String;)Z
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1132
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->writeNodeFileByDevice(IILjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFileFromBt(IILjava/lang/String;)Z
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1153
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->writeNodeFileFromBt(IILjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public whitelist writeNodeFileOneWay(IILjava/lang/String;)V
    .registers 5
    .param p1, "deviceId"    # I
    .param p2, "nodeFlag"    # I
    .param p3, "info"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1169
    invoke-static {}, Landroid/app/OplusActivityTaskManager;->getService()Landroid/app/IOplusActivityTaskManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/app/IOplusActivityTaskManager;->writeNodeFileOneWay(IILjava/lang/String;)V

    .line 1170
    return-void
.end method
