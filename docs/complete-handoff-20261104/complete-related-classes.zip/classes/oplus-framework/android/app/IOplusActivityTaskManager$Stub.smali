.class public abstract Landroid/app/IOplusActivityTaskManager$Stub;
.super Landroid/os/Binder;
.source "IOplusActivityTaskManager.java"

# interfaces
.implements Landroid/app/IOplusActivityTaskManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/IOplusActivityTaskManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/app/IOplusActivityTaskManager$Stub$Proxy;
    }
.end annotation


# static fields
.field static final blacklist TRANSACTION_addBracketWindowConfigChangedListener:I = 0x95

.field static final blacklist TRANSACTION_addFreeformConfigChangedListener:I = 0x8

.field static final blacklist TRANSACTION_addZoomWindowConfigChangedListener:I = 0x25

.field static final blacklist TRANSACTION_adjustEndAbsForFlexibleMinimize:I = 0xe9

.field static final blacklist TRANSACTION_adjustEndAbsForFlexibleMinimizeIfNeed:I = 0xe8

.field static final blacklist TRANSACTION_adjustFlexibleTask:I = 0xf6

.field static final blacklist TRANSACTION_adjustWindowFrame:I = 0xda

.field static final blacklist TRANSACTION_adjustWindowFrameForZoom:I = 0xa1

.field static final blacklist TRANSACTION_bindQuickReplyService:I = 0x98

.field static final blacklist TRANSACTION_calculateCanvasLayoutRect:I = 0xcc

.field static final blacklist TRANSACTION_calculateFlexibleWindowBoundList:I = 0xb2

.field static final blacklist TRANSACTION_calculateFlexibleWindowBounds:I = 0xb1

.field static final blacklist TRANSACTION_calculateReplaceCanvasLayoutRect:I = 0xcd

.field static final blacklist TRANSACTION_callMethod:I = 0x93

.field static final blacklist TRANSACTION_clearEmbeddedContainerTask:I = 0xc5

.field static final blacklist TRANSACTION_clientTransactionComplete:I = 0x82

.field static final blacklist TRANSACTION_closeSplitTask:I = 0xbe

.field static final blacklist TRANSACTION_createMirageDisplay:I = 0x60

.field static final blacklist TRANSACTION_createMirageWindowSession:I = 0x71

.field static final blacklist TRANSACTION_createVirtualDisplayDevice:I = 0xe0

.field static final blacklist TRANSACTION_dismissSplitScreenMode:I = 0x49

.field static final blacklist TRANSACTION_exitCompactWindow:I = 0x87

.field static final blacklist TRANSACTION_exitFlexibleEmbeddedTask:I = 0xc2

.field static final blacklist TRANSACTION_exitSplitTask:I = 0xbf

.field static final blacklist TRANSACTION_expandToFullScreen:I = 0x6a

.field static final blacklist TRANSACTION_feedbackUserSelection:I = 0x73

.field static final blacklist TRANSACTION_findTargetTaskByIntent:I = 0xd1

.field static final blacklist TRANSACTION_getActivityConfigs:I = 0xd9

.field static final blacklist TRANSACTION_getAllTopAppInfos:I = 0x5

.field static final blacklist TRANSACTION_getAppThemeVersion:I = 0x84

.field static final blacklist TRANSACTION_getConfineMode:I = 0x34

.field static final blacklist TRANSACTION_getCurrentZoomToSplitState:I = 0xce

.field static final blacklist TRANSACTION_getCurrentZoomWindowState:I = 0x12

.field static final blacklist TRANSACTION_getEmbeddedChildren:I = 0xe6

.field static final blacklist TRANSACTION_getEmbeddedChildrenSnapshot:I = 0xe7

.field static final blacklist TRANSACTION_getEmbeddedTaskSnapshot:I = 0xfe

.field static final blacklist TRANSACTION_getEnterPuttAppInfos:I = 0xac

.field static final blacklist TRANSACTION_getFlexibleMinimizedTaskId:I = 0xea

.field static final blacklist TRANSACTION_getFlexibleWindowConfigList:I = 0x104

.field static final blacklist TRANSACTION_getFocusBounds:I = 0x90

.field static final blacklist TRANSACTION_getFocusComponent:I = 0x91

.field static final blacklist TRANSACTION_getFocusMode:I = 0x8f

.field static final blacklist TRANSACTION_getFreeformConfigList:I = 0x6

.field static final blacklist TRANSACTION_getGetDisplayIdForPackageName:I = 0x72

.field static final blacklist TRANSACTION_getGlobalDragAndDropConfig:I = 0x5a

.field static final blacklist TRANSACTION_getLastEvent:I = 0x3b

.field static final blacklist TRANSACTION_getLeftRightBoundsForIme:I = 0x56

.field static final blacklist TRANSACTION_getMinimizedBounds:I = 0x53

.field static final blacklist TRANSACTION_getMirageDisplayCastMode:I = 0x69

.field static final blacklist TRANSACTION_getMirageWindowInfo:I = 0x6d

.field static final blacklist TRANSACTION_getMultiSearchSession:I = 0x9c

.field static final blacklist TRANSACTION_getPWAppInfo:I = 0x8d

.field static final blacklist TRANSACTION_getPackagesState:I = 0x43

.field static final blacklist TRANSACTION_getPauseInRecentsAnimPkgList:I = 0xa5

.field static final blacklist TRANSACTION_getPocketStudioTaskRegion:I = 0xb7

.field static final blacklist TRANSACTION_getRealSize:I = 0x92

.field static final blacklist TRANSACTION_getRecentEmbeddedTasksForContainer:I = 0xc6

.field static final blacklist TRANSACTION_getRenderThreadTid:I = 0x9f

.field static final blacklist TRANSACTION_getSecurityFlagCurrentPage:I = 0x1f

.field static final blacklist TRANSACTION_getSplitScreenSession:I = 0x54

.field static final blacklist TRANSACTION_getSplitScreenState:I = 0x4

.field static final blacklist TRANSACTION_getSplitScreenStatus:I = 0x4c

.field static final blacklist TRANSACTION_getTaskDescriptionLabel:I = 0x102

.field static final blacklist TRANSACTION_getTaskInfo:I = 0x61

.field static final blacklist TRANSACTION_getTopActivityComponentName:I = 0x2

.field static final blacklist TRANSACTION_getTopApplicationInfo:I = 0x3

.field static final blacklist TRANSACTION_getUriForFlexibleWindow:I = 0x103

.field static final blacklist TRANSACTION_getVisibleTasks:I = 0xee

.field static final blacklist TRANSACTION_getZoomAppConfigList:I = 0x14

.field static final blacklist TRANSACTION_getZoomBounds:I = 0xf9

.field static final blacklist TRANSACTION_getZoomBoundsByTaskId:I = 0xfa

.field static final blacklist TRANSACTION_getZoomTaskController:I = 0x9e

.field static final blacklist TRANSACTION_getZoomWindowConfig:I = 0x23

.field static final blacklist TRANSACTION_handleShowCompatibilityToast:I = 0x16

.field static final blacklist TRANSACTION_hasColorSplitFeature:I = 0x57

.field static final blacklist TRANSACTION_hasLargeScreenFeature:I = 0x51

.field static final blacklist TRANSACTION_hideZoomWindow:I = 0x13

.field static final blacklist TRANSACTION_invokeSync:I = 0x94

.field static final blacklist TRANSACTION_isAppSupportPocketStudio:I = 0xb3

.field static final blacklist TRANSACTION_isClickAtPocketStudioArea:I = 0xcb

.field static final blacklist TRANSACTION_isCurrentAppSupportCompactMode:I = 0x88

.field static final blacklist TRANSACTION_isFlexibleTaskEnabled:I = 0xe3

.field static final blacklist TRANSACTION_isFolderInnerScreen:I = 0x52

.field static final blacklist TRANSACTION_isFreeformEnabled:I = 0x7

.field static final blacklist TRANSACTION_isInAppInnerSplitScreen:I = 0xd3

.field static final blacklist TRANSACTION_isInPocketStudio:I = 0xb5

.field static final blacklist TRANSACTION_isInPocketStudioForStandard:I = 0xb6

.field static final blacklist TRANSACTION_isInSplitScreenMode:I = 0x48

.field static final blacklist TRANSACTION_isLockDeviceMode:I = 0x29

.field static final blacklist TRANSACTION_isMinimizedPocketStudio:I = 0xb9

.field static final blacklist TRANSACTION_isMirageWindowShow:I = 0x64

.field static final blacklist TRANSACTION_isNeedDisableWindowLayoutInfo:I = 0x97

.field static final blacklist TRANSACTION_isPowerKeyPressed:I = 0x38

.field static final blacklist TRANSACTION_isSupportEdgeTouchPrevent:I = 0x30

.field static final blacklist TRANSACTION_isSupportMirageWindowMode:I = 0x6c

.field static final blacklist TRANSACTION_isSupportPuttMode:I = 0xae

.field static final blacklist TRANSACTION_isSupportZoomMode:I = 0x15

.field static final blacklist TRANSACTION_isSupportZoomWindowMode:I = 0x22

.field static final blacklist TRANSACTION_isTaskExist:I = 0xf3

.field static final blacklist TRANSACTION_isTouchNodeSupport:I = 0x7c

.field static final blacklist TRANSACTION_isZoomSimpleModeEnable:I = 0x2c

.field static final blacklist TRANSACTION_isZoomSupportMultiWindow:I = 0xa2

.field static final blacklist TRANSACTION_lockRotationInGame:I = 0x85

.field static final blacklist TRANSACTION_moveActivityTaskToBack:I = 0x101

.field static final blacklist TRANSACTION_moveCompactWindowToLeft:I = 0x89

.field static final blacklist TRANSACTION_moveCompactWindowToRight:I = 0x8a

.field static final blacklist TRANSACTION_moveTaskToDisplay:I = 0xe2

.field static final blacklist TRANSACTION_notifyEmbeddedTasksChangeFocus:I = 0xd4

.field static final blacklist TRANSACTION_notifyFlexibleBlurAttachEvent:I = 0xd2

.field static final blacklist TRANSACTION_notifyFlexibleSplitScreenStateChanged:I = 0xd5

.field static final blacklist TRANSACTION_notifyFlexibleTaskEvent:I = 0xeb

.field static final blacklist TRANSACTION_notifyMinimizedReady:I = 0xcf

.field static final blacklist TRANSACTION_notifySplitScreenStateChanged:I = 0x46

.field static final blacklist TRANSACTION_notifyTouchNodeChange:I = 0x7f

.field static final blacklist TRANSACTION_notifyUiSwitched:I = 0xa3

.field static final blacklist TRANSACTION_notifyZoomStateChange:I = 0x18

.field static final blacklist TRANSACTION_onControlViewChanged:I = 0x1a

.field static final blacklist TRANSACTION_onFloatHandleViewChanged:I = 0x21

.field static final blacklist TRANSACTION_onInputEvent:I = 0x19

.field static final blacklist TRANSACTION_onProtocolUpdated:I = 0x8e

.field static final blacklist TRANSACTION_pauseInRecentsAnim:I = 0xa4

.field static final blacklist TRANSACTION_preStartActivity:I = 0x109

.field static final blacklist TRANSACTION_readNodeFile:I = 0x78

.field static final blacklist TRANSACTION_readNodeFileByDevice:I = 0x79

.field static final blacklist TRANSACTION_rebindDisplayIfNeeded:I = 0x75

.field static final blacklist TRANSACTION_registerAppSwitchObserver:I = 0xa

.field static final blacklist TRANSACTION_registerCompactWindowObserver:I = 0x8b

.field static final blacklist TRANSACTION_registerConfineModeObserver:I = 0x76

.field static final blacklist TRANSACTION_registerDragAndDropListener:I = 0xc

.field static final blacklist TRANSACTION_registerEmbeddedWindowContainerCallback:I = 0xd6

.field static final blacklist TRANSACTION_registerEventCallback:I = 0x80

.field static final blacklist TRANSACTION_registerFlexibleTaskListener:I = 0xff

.field static final blacklist TRANSACTION_registerFlexibleWindowObserver:I = 0xaf

.field static final blacklist TRANSACTION_registerKeyEventInterceptor:I = 0x58

.field static final blacklist TRANSACTION_registerKeyEventObserver:I = 0x36

.field static final blacklist TRANSACTION_registerLockScreenCallback:I = 0x44

.field static final blacklist TRANSACTION_registerMirageDisplayObserver:I = 0x5e

.field static final blacklist TRANSACTION_registerMirageWindowObserver:I = 0x5c

.field static final blacklist TRANSACTION_registerOplusTaskStackListener:I = 0xf1

.field static final blacklist TRANSACTION_registerPuttEventObserver:I = 0xa8

.field static final blacklist TRANSACTION_registerPuttObserver:I = 0xa6

.field static final blacklist TRANSACTION_registerRegionScreenshot:I = 0x3c

.field static final blacklist TRANSACTION_registerSecurityPageCallback:I = 0x1d

.field static final blacklist TRANSACTION_registerSplitScreenObserver:I = 0x4a

.field static final blacklist TRANSACTION_registerStartingWindowObserver:I = 0x107

.field static final blacklist TRANSACTION_registerSysStateChangeObserver:I = 0x3f

.field static final blacklist TRANSACTION_registerTaskInfoChangeListener:I = 0xef

.field static final blacklist TRANSACTION_registerWindowChangeListener:I = 0x106

.field static final blacklist TRANSACTION_registerZoomAppObserver:I = 0x1b

.field static final blacklist TRANSACTION_registerZoomStateListener:I = 0xec

.field static final blacklist TRANSACTION_registerZoomWindowObserver:I = 0x10

.field static final blacklist TRANSACTION_releaseScreenshotRegion:I = 0x3a

.field static final blacklist TRANSACTION_releaseVirtualDisplayDevice:I = 0xe1

.field static final blacklist TRANSACTION_removeBracketWindowConfigChangedListener:I = 0x96

.field static final blacklist TRANSACTION_removeEmbeddedContainerTask:I = 0xc1

.field static final blacklist TRANSACTION_removeFreeformConfigChangedListener:I = 0x9

.field static final blacklist TRANSACTION_removePuttTask:I = 0xad

.field static final blacklist TRANSACTION_removeZoomWindowConfigChangedListener:I = 0x26

.field static final blacklist TRANSACTION_replaceLockTaskPackages:I = 0x2b

.field static final blacklist TRANSACTION_replaceSplitTask:I = 0xc0

.field static final blacklist TRANSACTION_reportViewExtractResult:I = 0xdc

.field static final blacklist TRANSACTION_requestViewExtractData:I = 0xdd

.field static final blacklist TRANSACTION_resetDefaultEdgeTouchPreventParam:I = 0x2f

.field static final blacklist TRANSACTION_resetFlexibleTask:I = 0xc4

.field static final blacklist TRANSACTION_resetNoReparentTask:I = 0xd8

.field static final blacklist TRANSACTION_sendMessage:I = 0x9a

.field static final blacklist TRANSACTION_sendMirageEvents:I = 0xf7

.field static final blacklist TRANSACTION_setBackInvokePolicyForPredictive:I = 0xfb

.field static final blacklist TRANSACTION_setConfineMode:I = 0x33

.field static final blacklist TRANSACTION_setDefaultEdgeTouchPreventParam:I = 0x2e

.field static final blacklist TRANSACTION_setEdgeTouchCallRules:I = 0x31

.field static final blacklist TRANSACTION_setEmbeddedContainerTask:I = 0xbc

.field static final blacklist TRANSACTION_setFlexibleFrame:I = 0xba

.field static final blacklist TRANSACTION_setFlexibleTaskEmbedding:I = 0xc3

.field static final blacklist TRANSACTION_setFlexibleTaskEnabled:I = 0xe4

.field static final blacklist TRANSACTION_setFocusAppForEmbeddedTask:I = 0xbd

.field static final blacklist TRANSACTION_setGimbalLaunchPkg:I = 0x41

.field static final blacklist TRANSACTION_setGlobalDragAndDropConfig:I = 0x5b

.field static final blacklist TRANSACTION_setInputConsumerEnabled:I = 0xa0

.field static final blacklist TRANSACTION_setIsInFocusAnimating:I = 0xbb

.field static final blacklist TRANSACTION_setMinimizedPocketStudio:I = 0xb8

.field static final blacklist TRANSACTION_setMirageDisplaySurfaceById:I = 0x67

.field static final blacklist TRANSACTION_setMirageDisplaySurfaceByMode:I = 0x68

.field static final blacklist TRANSACTION_setMirageDisplayUserRotation:I = 0xf8

.field static final blacklist TRANSACTION_setMirageWindowSilent:I = 0x6b

.field static final blacklist TRANSACTION_setPackagesState:I = 0x42

.field static final blacklist TRANSACTION_setPermitList:I = 0x35

.field static final blacklist TRANSACTION_setRegionScreenshot:I = 0x39

.field static final blacklist TRANSACTION_setSecureController:I = 0x1

.field static final blacklist TRANSACTION_setSplitScreenObserver:I = 0x47

.field static final blacklist TRANSACTION_setTaskInsensibleParams:I = 0xc8

.field static final blacklist TRANSACTION_setTaskWindowingModeSplitScreen:I = 0x4f

.field static final blacklist TRANSACTION_setZoomWindowConfig:I = 0x24

.field static final blacklist TRANSACTION_shouldInterceptBackKeyForMultiSearch:I = 0x9b

.field static final blacklist TRANSACTION_shouldSkipStartPocketStudio:I = 0xdf

.field static final blacklist TRANSACTION_splitScreenForApplication:I = 0x55

.field static final blacklist TRANSACTION_splitScreenForEdgePanel:I = 0x32

.field static final blacklist TRANSACTION_splitScreenForEdgePanelExt:I = 0x50

.field static final blacklist TRANSACTION_splitScreenForRecentTasks:I = 0x4e

.field static final blacklist TRANSACTION_splitScreenForTopApp:I = 0x4d

.field static final blacklist TRANSACTION_startActivityFromRecentsForFlexible:I = 0xe5

.field static final blacklist TRANSACTION_startActivityInTask:I = 0xc7

.field static final blacklist TRANSACTION_startAnyActivity:I = 0xc9

.field static final blacklist TRANSACTION_startCompactWindow:I = 0x86

.field static final blacklist TRANSACTION_startDragFullscreenAnimation:I = 0xd0

.field static final blacklist TRANSACTION_startFlexibleWindowForRecentTasks:I = 0xca

.field static final blacklist TRANSACTION_startLockDeviceMode:I = 0x27

.field static final blacklist TRANSACTION_startLockDeviceModeWithFlag:I = 0x2a

.field static final blacklist TRANSACTION_startMiniZoomFromZoom:I = 0x17

.field static final blacklist TRANSACTION_startMirageWindowMode:I = 0x63

.field static final blacklist TRANSACTION_startMirageWindowModeWithName:I = 0x62

.field static final blacklist TRANSACTION_startPutt:I = 0xab

.field static final blacklist TRANSACTION_startTaskToSplit:I = 0xb4

.field static final blacklist TRANSACTION_startZoomWindow:I = 0xe

.field static final blacklist TRANSACTION_startZoomWindowByPendingIntent:I = 0xf

.field static final blacklist TRANSACTION_stopLockDeviceMode:I = 0x28

.field static final blacklist TRANSACTION_stopMirageWindowMode:I = 0x66

.field static final blacklist TRANSACTION_stopMirageWindowModeOld:I = 0x65

.field static final blacklist TRANSACTION_stopPutt:I = 0xaa

.field static final blacklist TRANSACTION_takeScreenshot:I = 0x9d

.field static final blacklist TRANSACTION_toggleFlexibleWindow:I = 0xf4

.field static final blacklist TRANSACTION_toggleFlexibleWindowByApp:I = 0xf5

.field static final blacklist TRANSACTION_unRegisterRegionScreenshot:I = 0x3d

.field static final blacklist TRANSACTION_unbindQuickReplyService:I = 0x99

.field static final blacklist TRANSACTION_unregisterAppSwitchObserver:I = 0xb

.field static final blacklist TRANSACTION_unregisterCompactWindowObserver:I = 0x8c

.field static final blacklist TRANSACTION_unregisterConfineModeObserver:I = 0x77

.field static final blacklist TRANSACTION_unregisterDragAndDropListener:I = 0xd

.field static final blacklist TRANSACTION_unregisterEmbeddedWindowContainerCallback:I = 0xd7

.field static final blacklist TRANSACTION_unregisterEventCallback:I = 0x81

.field static final blacklist TRANSACTION_unregisterFlexibleTaskListener:I = 0x100

.field static final blacklist TRANSACTION_unregisterFlexibleWindowObserver:I = 0xb0

.field static final blacklist TRANSACTION_unregisterKeyEventInterceptor:I = 0x59

.field static final blacklist TRANSACTION_unregisterKeyEventObserver:I = 0x37

.field static final blacklist TRANSACTION_unregisterLockScreenCallback:I = 0x45

.field static final blacklist TRANSACTION_unregisterMirageDisplayObserver:I = 0x5f

.field static final blacklist TRANSACTION_unregisterMirageWindowObserver:I = 0x5d

.field static final blacklist TRANSACTION_unregisterOplusTaskStackListener:I = 0xf2

.field static final blacklist TRANSACTION_unregisterPuttEventObserver:I = 0xa9

.field static final blacklist TRANSACTION_unregisterPuttObserver:I = 0xa7

.field static final blacklist TRANSACTION_unregisterSecurityPageCallback:I = 0x1e

.field static final blacklist TRANSACTION_unregisterSplitScreenObserver:I = 0x4b

.field static final blacklist TRANSACTION_unregisterStartingWindowObserver:I = 0x108

.field static final blacklist TRANSACTION_unregisterSysStateChangeObserver:I = 0x40

.field static final blacklist TRANSACTION_unregisterTaskInfoChangeListener:I = 0xf0

.field static final blacklist TRANSACTION_unregisterWindowChangeListener:I = 0x105

.field static final blacklist TRANSACTION_unregisterZoomAppObserver:I = 0x1c

.field static final blacklist TRANSACTION_unregisterZoomStateListener:I = 0xed

.field static final blacklist TRANSACTION_unregisterZoomWindowObserver:I = 0x11

.field static final blacklist TRANSACTION_updateAppData:I = 0x3e

.field static final blacklist TRANSACTION_updateCarModeMultiLaunchWhiteList:I = 0x74

.field static final blacklist TRANSACTION_updateDeferStartingWindowApps:I = 0x20

.field static final blacklist TRANSACTION_updateLockTaskFeatures:I = 0xfc

.field static final blacklist TRANSACTION_updateLockTaskPackages:I = 0xfd

.field static final blacklist TRANSACTION_updateMirageWindowCastFlag:I = 0x6e

.field static final blacklist TRANSACTION_updatePrivacyProtectionList:I = 0x6f

.field static final blacklist TRANSACTION_updatePrivacyProtectionListWithBundle:I = 0x70

.field static final blacklist TRANSACTION_updateRecordSurfaceViewState:I = 0xdb

.field static final blacklist TRANSACTION_updateTaskVisibility:I = 0xde

.field static final blacklist TRANSACTION_updateUntrustedTouchConfig:I = 0x83

.field static final blacklist TRANSACTION_writeEdgeTouchPreventParam:I = 0x2d

.field static final blacklist TRANSACTION_writeNodeFile:I = 0x7a

.field static final blacklist TRANSACTION_writeNodeFileByDevice:I = 0x7b

.field static final blacklist TRANSACTION_writeNodeFileFromBt:I = 0x7d

.field static final blacklist TRANSACTION_writeNodeFileOneWay:I = 0x7e


# direct methods
.method public constructor blacklist <init>()V
    .registers 2

    .line 1323
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 1324
    const-string v0, "android.app.IOplusActivityTaskManager"

    invoke-virtual {p0, p0, v0}, Landroid/app/IOplusActivityTaskManager$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 1325
    return-void
.end method

.method public static blacklist asInterface(Landroid/os/IBinder;)Landroid/app/IOplusActivityTaskManager;
    .registers 3
    .param p0, "obj"    # Landroid/os/IBinder;

    .line 1332
    if-nez p0, :cond_4

    .line 1333
    const/4 v0, 0x0

    return-object v0

    .line 1335
    :cond_4
    const-string v0, "android.app.IOplusActivityTaskManager"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 1336
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_14

    instance-of v1, v0, Landroid/app/IOplusActivityTaskManager;

    if-eqz v1, :cond_14

    .line 1337
    move-object v1, v0

    check-cast v1, Landroid/app/IOplusActivityTaskManager;

    return-object v1

    .line 1339
    :cond_14
    new-instance v1, Landroid/app/IOplusActivityTaskManager$Stub$Proxy;

    invoke-direct {v1, p0}, Landroid/app/IOplusActivityTaskManager$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method

.method public static blacklist getDefaultTransactionName(I)Ljava/lang/String;
    .registers 2
    .param p0, "transactionCode"    # I

    .line 1348
    packed-switch p0, :pswitch_data_3cc

    .line 2412
    const/4 v0, 0x0

    return-object v0

    .line 2408
    :pswitch_5
    const-string/jumbo v0, "preStartActivity"

    return-object v0

    .line 2404
    :pswitch_9
    const-string/jumbo v0, "unregisterStartingWindowObserver"

    return-object v0

    .line 2400
    :pswitch_d
    const-string/jumbo v0, "registerStartingWindowObserver"

    return-object v0

    .line 2396
    :pswitch_11
    const-string/jumbo v0, "registerWindowChangeListener"

    return-object v0

    .line 2392
    :pswitch_15
    const-string/jumbo v0, "unregisterWindowChangeListener"

    return-object v0

    .line 2388
    :pswitch_19
    const-string v0, "getFlexibleWindowConfigList"

    return-object v0

    .line 2384
    :pswitch_1c
    const-string v0, "getUriForFlexibleWindow"

    return-object v0

    .line 2380
    :pswitch_1f
    const-string v0, "getTaskDescriptionLabel"

    return-object v0

    .line 2376
    :pswitch_22
    const-string/jumbo v0, "moveActivityTaskToBack"

    return-object v0

    .line 2372
    :pswitch_26
    const-string/jumbo v0, "unregisterFlexibleTaskListener"

    return-object v0

    .line 2368
    :pswitch_2a
    const-string/jumbo v0, "registerFlexibleTaskListener"

    return-object v0

    .line 2364
    :pswitch_2e
    const-string v0, "getEmbeddedTaskSnapshot"

    return-object v0

    .line 2360
    :pswitch_31
    const-string/jumbo v0, "updateLockTaskPackages"

    return-object v0

    .line 2356
    :pswitch_35
    const-string/jumbo v0, "updateLockTaskFeatures"

    return-object v0

    .line 2352
    :pswitch_39
    const-string/jumbo v0, "setBackInvokePolicyForPredictive"

    return-object v0

    .line 2348
    :pswitch_3d
    const-string v0, "getZoomBoundsByTaskId"

    return-object v0

    .line 2344
    :pswitch_40
    const-string v0, "getZoomBounds"

    return-object v0

    .line 2340
    :pswitch_43
    const-string/jumbo v0, "setMirageDisplayUserRotation"

    return-object v0

    .line 2336
    :pswitch_47
    const-string/jumbo v0, "sendMirageEvents"

    return-object v0

    .line 2332
    :pswitch_4b
    const-string v0, "adjustFlexibleTask"

    return-object v0

    .line 2328
    :pswitch_4e
    const-string/jumbo v0, "toggleFlexibleWindowByApp"

    return-object v0

    .line 2324
    :pswitch_52
    const-string/jumbo v0, "toggleFlexibleWindow"

    return-object v0

    .line 2320
    :pswitch_56
    const-string/jumbo v0, "isTaskExist"

    return-object v0

    .line 2316
    :pswitch_5a
    const-string/jumbo v0, "unregisterOplusTaskStackListener"

    return-object v0

    .line 2312
    :pswitch_5e
    const-string/jumbo v0, "registerOplusTaskStackListener"

    return-object v0

    .line 2308
    :pswitch_62
    const-string/jumbo v0, "unregisterTaskInfoChangeListener"

    return-object v0

    .line 2304
    :pswitch_66
    const-string/jumbo v0, "registerTaskInfoChangeListener"

    return-object v0

    .line 2300
    :pswitch_6a
    const-string v0, "getVisibleTasks"

    return-object v0

    .line 2296
    :pswitch_6d
    const-string/jumbo v0, "unregisterZoomStateListener"

    return-object v0

    .line 2292
    :pswitch_71
    const-string/jumbo v0, "registerZoomStateListener"

    return-object v0

    .line 2288
    :pswitch_75
    const-string/jumbo v0, "notifyFlexibleTaskEvent"

    return-object v0

    .line 2284
    :pswitch_79
    const-string v0, "getFlexibleMinimizedTaskId"

    return-object v0

    .line 2280
    :pswitch_7c
    const-string v0, "adjustEndAbsForFlexibleMinimize"

    return-object v0

    .line 2276
    :pswitch_7f
    const-string v0, "adjustEndAbsForFlexibleMinimizeIfNeed"

    return-object v0

    .line 2272
    :pswitch_82
    const-string v0, "getEmbeddedChildrenSnapshot"

    return-object v0

    .line 2268
    :pswitch_85
    const-string v0, "getEmbeddedChildren"

    return-object v0

    .line 2264
    :pswitch_88
    const-string/jumbo v0, "startActivityFromRecentsForFlexible"

    return-object v0

    .line 2260
    :pswitch_8c
    const-string/jumbo v0, "setFlexibleTaskEnabled"

    return-object v0

    .line 2256
    :pswitch_90
    const-string v0, "isFlexibleTaskEnabled"

    return-object v0

    .line 2252
    :pswitch_93
    const-string/jumbo v0, "moveTaskToDisplay"

    return-object v0

    .line 2248
    :pswitch_97
    const-string/jumbo v0, "releaseVirtualDisplayDevice"

    return-object v0

    .line 2244
    :pswitch_9b
    const-string v0, "createVirtualDisplayDevice"

    return-object v0

    .line 2240
    :pswitch_9e
    const-string/jumbo v0, "shouldSkipStartPocketStudio"

    return-object v0

    .line 2236
    :pswitch_a2
    const-string/jumbo v0, "updateTaskVisibility"

    return-object v0

    .line 2232
    :pswitch_a6
    const-string/jumbo v0, "requestViewExtractData"

    return-object v0

    .line 2228
    :pswitch_aa
    const-string/jumbo v0, "reportViewExtractResult"

    return-object v0

    .line 2224
    :pswitch_ae
    const-string/jumbo v0, "updateRecordSurfaceViewState"

    return-object v0

    .line 2220
    :pswitch_b2
    const-string v0, "adjustWindowFrame"

    return-object v0

    .line 2216
    :pswitch_b5
    const-string v0, "getActivityConfigs"

    return-object v0

    .line 2212
    :pswitch_b8
    const-string/jumbo v0, "resetNoReparentTask"

    return-object v0

    .line 2208
    :pswitch_bc
    const-string/jumbo v0, "unregisterEmbeddedWindowContainerCallback"

    return-object v0

    .line 2204
    :pswitch_c0
    const-string/jumbo v0, "registerEmbeddedWindowContainerCallback"

    return-object v0

    .line 2200
    :pswitch_c4
    const-string/jumbo v0, "notifyFlexibleSplitScreenStateChanged"

    return-object v0

    .line 2196
    :pswitch_c8
    const-string/jumbo v0, "notifyEmbeddedTasksChangeFocus"

    return-object v0

    .line 2192
    :pswitch_cc
    const-string v0, "isInAppInnerSplitScreen"

    return-object v0

    .line 2188
    :pswitch_cf
    const-string/jumbo v0, "notifyFlexibleBlurAttachEvent"

    return-object v0

    .line 2184
    :pswitch_d3
    const-string v0, "findTargetTaskByIntent"

    return-object v0

    .line 2180
    :pswitch_d6
    const-string/jumbo v0, "startDragFullscreenAnimation"

    return-object v0

    .line 2176
    :pswitch_da
    const-string/jumbo v0, "notifyMinimizedReady"

    return-object v0

    .line 2172
    :pswitch_de
    const-string v0, "getCurrentZoomToSplitState"

    return-object v0

    .line 2168
    :pswitch_e1
    const-string v0, "calculateReplaceCanvasLayoutRect"

    return-object v0

    .line 2164
    :pswitch_e4
    const-string v0, "calculateCanvasLayoutRect"

    return-object v0

    .line 2160
    :pswitch_e7
    const-string v0, "isClickAtPocketStudioArea"

    return-object v0

    .line 2156
    :pswitch_ea
    const-string/jumbo v0, "startFlexibleWindowForRecentTasks"

    return-object v0

    .line 2152
    :pswitch_ee
    const-string/jumbo v0, "startAnyActivity"

    return-object v0

    .line 2148
    :pswitch_f2
    const-string/jumbo v0, "setTaskInsensibleParams"

    return-object v0

    .line 2144
    :pswitch_f6
    const-string/jumbo v0, "startActivityInTask"

    return-object v0

    .line 2140
    :pswitch_fa
    const-string v0, "getRecentEmbeddedTasksForContainer"

    return-object v0

    .line 2136
    :pswitch_fd
    const-string v0, "clearEmbeddedContainerTask"

    return-object v0

    .line 2132
    :pswitch_100
    const-string/jumbo v0, "resetFlexibleTask"

    return-object v0

    .line 2128
    :pswitch_104
    const-string/jumbo v0, "setFlexibleTaskEmbedding"

    return-object v0

    .line 2124
    :pswitch_108
    const-string v0, "exitFlexibleEmbeddedTask"

    return-object v0

    .line 2120
    :pswitch_10b
    const-string/jumbo v0, "removeEmbeddedContainerTask"

    return-object v0

    .line 2116
    :pswitch_10f
    const-string/jumbo v0, "replaceSplitTask"

    return-object v0

    .line 2112
    :pswitch_113
    const-string v0, "exitSplitTask"

    return-object v0

    .line 2108
    :pswitch_116
    const-string v0, "closeSplitTask"

    return-object v0

    .line 2104
    :pswitch_119
    const-string/jumbo v0, "setFocusAppForEmbeddedTask"

    return-object v0

    .line 2100
    :pswitch_11d
    const-string/jumbo v0, "setEmbeddedContainerTask"

    return-object v0

    .line 2096
    :pswitch_121
    const-string/jumbo v0, "setIsInFocusAnimating"

    return-object v0

    .line 2092
    :pswitch_125
    const-string/jumbo v0, "setFlexibleFrame"

    return-object v0

    .line 2088
    :pswitch_129
    const-string v0, "isMinimizedPocketStudio"

    return-object v0

    .line 2084
    :pswitch_12c
    const-string/jumbo v0, "setMinimizedPocketStudio"

    return-object v0

    .line 2080
    :pswitch_130
    const-string v0, "getPocketStudioTaskRegion"

    return-object v0

    .line 2076
    :pswitch_133
    const-string v0, "isInPocketStudioForStandard"

    return-object v0

    .line 2072
    :pswitch_136
    const-string v0, "isInPocketStudio"

    return-object v0

    .line 2068
    :pswitch_139
    const-string/jumbo v0, "startTaskToSplit"

    return-object v0

    .line 2064
    :pswitch_13d
    const-string v0, "isAppSupportPocketStudio"

    return-object v0

    .line 2060
    :pswitch_140
    const-string v0, "calculateFlexibleWindowBoundList"

    return-object v0

    .line 2056
    :pswitch_143
    const-string v0, "calculateFlexibleWindowBounds"

    return-object v0

    .line 2052
    :pswitch_146
    const-string/jumbo v0, "unregisterFlexibleWindowObserver"

    return-object v0

    .line 2048
    :pswitch_14a
    const-string/jumbo v0, "registerFlexibleWindowObserver"

    return-object v0

    .line 2044
    :pswitch_14e
    const-string/jumbo v0, "isSupportPuttMode"

    return-object v0

    .line 2040
    :pswitch_152
    const-string/jumbo v0, "removePuttTask"

    return-object v0

    .line 2036
    :pswitch_156
    const-string v0, "getEnterPuttAppInfos"

    return-object v0

    .line 2032
    :pswitch_159
    const-string/jumbo v0, "startPutt"

    return-object v0

    .line 2028
    :pswitch_15d
    const-string/jumbo v0, "stopPutt"

    return-object v0

    .line 2024
    :pswitch_161
    const-string/jumbo v0, "unregisterPuttEventObserver"

    return-object v0

    .line 2020
    :pswitch_165
    const-string/jumbo v0, "registerPuttEventObserver"

    return-object v0

    .line 2016
    :pswitch_169
    const-string/jumbo v0, "unregisterPuttObserver"

    return-object v0

    .line 2012
    :pswitch_16d
    const-string/jumbo v0, "registerPuttObserver"

    return-object v0

    .line 2008
    :pswitch_171
    const-string v0, "getPauseInRecentsAnimPkgList"

    return-object v0

    .line 2004
    :pswitch_174
    const-string/jumbo v0, "pauseInRecentsAnim"

    return-object v0

    .line 2000
    :pswitch_178
    const-string/jumbo v0, "notifyUiSwitched"

    return-object v0

    .line 1996
    :pswitch_17c
    const-string/jumbo v0, "isZoomSupportMultiWindow"

    return-object v0

    .line 1992
    :pswitch_180
    const-string v0, "adjustWindowFrameForZoom"

    return-object v0

    .line 1988
    :pswitch_183
    const-string/jumbo v0, "setInputConsumerEnabled"

    return-object v0

    .line 1984
    :pswitch_187
    const-string v0, "getRenderThreadTid"

    return-object v0

    .line 1980
    :pswitch_18a
    const-string v0, "getZoomTaskController"

    return-object v0

    .line 1976
    :pswitch_18d
    const-string/jumbo v0, "takeScreenshot"

    return-object v0

    .line 1972
    :pswitch_191
    const-string v0, "getMultiSearchSession"

    return-object v0

    .line 1968
    :pswitch_194
    const-string/jumbo v0, "shouldInterceptBackKeyForMultiSearch"

    return-object v0

    .line 1964
    :pswitch_198
    const-string/jumbo v0, "sendMessage"

    return-object v0

    .line 1960
    :pswitch_19c
    const-string/jumbo v0, "unbindQuickReplyService"

    return-object v0

    .line 1956
    :pswitch_1a0
    const-string v0, "bindQuickReplyService"

    return-object v0

    .line 1952
    :pswitch_1a3
    const-string v0, "isNeedDisableWindowLayoutInfo"

    return-object v0

    .line 1948
    :pswitch_1a6
    const-string/jumbo v0, "removeBracketWindowConfigChangedListener"

    return-object v0

    .line 1944
    :pswitch_1aa
    const-string v0, "addBracketWindowConfigChangedListener"

    return-object v0

    .line 1940
    :pswitch_1ad
    const-string v0, "invokeSync"

    return-object v0

    .line 1936
    :pswitch_1b0
    const-string v0, "callMethod"

    return-object v0

    .line 1932
    :pswitch_1b3
    const-string v0, "getRealSize"

    return-object v0

    .line 1928
    :pswitch_1b6
    const-string v0, "getFocusComponent"

    return-object v0

    .line 1924
    :pswitch_1b9
    const-string v0, "getFocusBounds"

    return-object v0

    .line 1920
    :pswitch_1bc
    const-string v0, "getFocusMode"

    return-object v0

    .line 1916
    :pswitch_1bf
    const-string/jumbo v0, "onProtocolUpdated"

    return-object v0

    .line 1912
    :pswitch_1c3
    const-string v0, "getPWAppInfo"

    return-object v0

    .line 1908
    :pswitch_1c6
    const-string/jumbo v0, "unregisterCompactWindowObserver"

    return-object v0

    .line 1904
    :pswitch_1ca
    const-string/jumbo v0, "registerCompactWindowObserver"

    return-object v0

    .line 1900
    :pswitch_1ce
    const-string/jumbo v0, "moveCompactWindowToRight"

    return-object v0

    .line 1896
    :pswitch_1d2
    const-string/jumbo v0, "moveCompactWindowToLeft"

    return-object v0

    .line 1892
    :pswitch_1d6
    const-string v0, "isCurrentAppSupportCompactMode"

    return-object v0

    .line 1888
    :pswitch_1d9
    const-string v0, "exitCompactWindow"

    return-object v0

    .line 1884
    :pswitch_1dc
    const-string/jumbo v0, "startCompactWindow"

    return-object v0

    .line 1880
    :pswitch_1e0
    const-string/jumbo v0, "lockRotationInGame"

    return-object v0

    .line 1876
    :pswitch_1e4
    const-string v0, "getAppThemeVersion"

    return-object v0

    .line 1872
    :pswitch_1e7
    const-string/jumbo v0, "updateUntrustedTouchConfig"

    return-object v0

    .line 1868
    :pswitch_1eb
    const-string v0, "clientTransactionComplete"

    return-object v0

    .line 1864
    :pswitch_1ee
    const-string/jumbo v0, "unregisterEventCallback"

    return-object v0

    .line 1860
    :pswitch_1f2
    const-string/jumbo v0, "registerEventCallback"

    return-object v0

    .line 1856
    :pswitch_1f6
    const-string/jumbo v0, "notifyTouchNodeChange"

    return-object v0

    .line 1852
    :pswitch_1fa
    const-string/jumbo v0, "writeNodeFileOneWay"

    return-object v0

    .line 1848
    :pswitch_1fe
    const-string/jumbo v0, "writeNodeFileFromBt"

    return-object v0

    .line 1844
    :pswitch_202
    const-string/jumbo v0, "isTouchNodeSupport"

    return-object v0

    .line 1840
    :pswitch_206
    const-string/jumbo v0, "writeNodeFileByDevice"

    return-object v0

    .line 1836
    :pswitch_20a
    const-string/jumbo v0, "writeNodeFile"

    return-object v0

    .line 1832
    :pswitch_20e
    const-string/jumbo v0, "readNodeFileByDevice"

    return-object v0

    .line 1828
    :pswitch_212
    const-string/jumbo v0, "readNodeFile"

    return-object v0

    .line 1824
    :pswitch_216
    const-string/jumbo v0, "unregisterConfineModeObserver"

    return-object v0

    .line 1820
    :pswitch_21a
    const-string/jumbo v0, "registerConfineModeObserver"

    return-object v0

    .line 1816
    :pswitch_21e
    const-string/jumbo v0, "rebindDisplayIfNeeded"

    return-object v0

    .line 1812
    :pswitch_222
    const-string/jumbo v0, "updateCarModeMultiLaunchWhiteList"

    return-object v0

    .line 1808
    :pswitch_226
    const-string v0, "feedbackUserSelection"

    return-object v0

    .line 1804
    :pswitch_229
    const-string v0, "getGetDisplayIdForPackageName"

    return-object v0

    .line 1800
    :pswitch_22c
    const-string v0, "createMirageWindowSession"

    return-object v0

    .line 1796
    :pswitch_22f
    const-string/jumbo v0, "updatePrivacyProtectionListWithBundle"

    return-object v0

    .line 1792
    :pswitch_233
    const-string/jumbo v0, "updatePrivacyProtectionList"

    return-object v0

    .line 1788
    :pswitch_237
    const-string/jumbo v0, "updateMirageWindowCastFlag"

    return-object v0

    .line 1784
    :pswitch_23b
    const-string v0, "getMirageWindowInfo"

    return-object v0

    .line 1780
    :pswitch_23e
    const-string/jumbo v0, "isSupportMirageWindowMode"

    return-object v0

    .line 1776
    :pswitch_242
    const-string/jumbo v0, "setMirageWindowSilent"

    return-object v0

    .line 1772
    :pswitch_246
    const-string v0, "expandToFullScreen"

    return-object v0

    .line 1768
    :pswitch_249
    const-string v0, "getMirageDisplayCastMode"

    return-object v0

    .line 1764
    :pswitch_24c
    const-string/jumbo v0, "setMirageDisplaySurfaceByMode"

    return-object v0

    .line 1760
    :pswitch_250
    const-string/jumbo v0, "setMirageDisplaySurfaceById"

    return-object v0

    .line 1756
    :pswitch_254
    const-string/jumbo v0, "stopMirageWindowMode"

    return-object v0

    .line 1752
    :pswitch_258
    const-string/jumbo v0, "stopMirageWindowModeOld"

    return-object v0

    .line 1748
    :pswitch_25c
    const-string v0, "isMirageWindowShow"

    return-object v0

    .line 1744
    :pswitch_25f
    const-string/jumbo v0, "startMirageWindowMode"

    return-object v0

    .line 1740
    :pswitch_263
    const-string/jumbo v0, "startMirageWindowModeWithName"

    return-object v0

    .line 1736
    :pswitch_267
    const-string v0, "getTaskInfo"

    return-object v0

    .line 1732
    :pswitch_26a
    const-string v0, "createMirageDisplay"

    return-object v0

    .line 1728
    :pswitch_26d
    const-string/jumbo v0, "unregisterMirageDisplayObserver"

    return-object v0

    .line 1724
    :pswitch_271
    const-string/jumbo v0, "registerMirageDisplayObserver"

    return-object v0

    .line 1720
    :pswitch_275
    const-string/jumbo v0, "unregisterMirageWindowObserver"

    return-object v0

    .line 1716
    :pswitch_279
    const-string/jumbo v0, "registerMirageWindowObserver"

    return-object v0

    .line 1712
    :pswitch_27d
    const-string/jumbo v0, "setGlobalDragAndDropConfig"

    return-object v0

    .line 1708
    :pswitch_281
    const-string v0, "getGlobalDragAndDropConfig"

    return-object v0

    .line 1704
    :pswitch_284
    const-string/jumbo v0, "unregisterKeyEventInterceptor"

    return-object v0

    .line 1700
    :pswitch_288
    const-string/jumbo v0, "registerKeyEventInterceptor"

    return-object v0

    .line 1696
    :pswitch_28c
    const-string v0, "hasColorSplitFeature"

    return-object v0

    .line 1692
    :pswitch_28f
    const-string v0, "getLeftRightBoundsForIme"

    return-object v0

    .line 1688
    :pswitch_292
    const-string/jumbo v0, "splitScreenForApplication"

    return-object v0

    .line 1684
    :pswitch_296
    const-string v0, "getSplitScreenSession"

    return-object v0

    .line 1680
    :pswitch_299
    const-string v0, "getMinimizedBounds"

    return-object v0

    .line 1676
    :pswitch_29c
    const-string v0, "isFolderInnerScreen"

    return-object v0

    .line 1672
    :pswitch_29f
    const-string v0, "hasLargeScreenFeature"

    return-object v0

    .line 1668
    :pswitch_2a2
    const-string/jumbo v0, "splitScreenForEdgePanelExt"

    return-object v0

    .line 1664
    :pswitch_2a6
    const-string/jumbo v0, "setTaskWindowingModeSplitScreen"

    return-object v0

    .line 1660
    :pswitch_2aa
    const-string/jumbo v0, "splitScreenForRecentTasks"

    return-object v0

    .line 1656
    :pswitch_2ae
    const-string/jumbo v0, "splitScreenForTopApp"

    return-object v0

    .line 1652
    :pswitch_2b2
    const-string v0, "getSplitScreenStatus"

    return-object v0

    .line 1648
    :pswitch_2b5
    const-string/jumbo v0, "unregisterSplitScreenObserver"

    return-object v0

    .line 1644
    :pswitch_2b9
    const-string/jumbo v0, "registerSplitScreenObserver"

    return-object v0

    .line 1640
    :pswitch_2bd
    const-string v0, "dismissSplitScreenMode"

    return-object v0

    .line 1636
    :pswitch_2c0
    const-string v0, "isInSplitScreenMode"

    return-object v0

    .line 1632
    :pswitch_2c3
    const-string/jumbo v0, "setSplitScreenObserver"

    return-object v0

    .line 1628
    :pswitch_2c7
    const-string/jumbo v0, "notifySplitScreenStateChanged"

    return-object v0

    .line 1624
    :pswitch_2cb
    const-string/jumbo v0, "unregisterLockScreenCallback"

    return-object v0

    .line 1620
    :pswitch_2cf
    const-string/jumbo v0, "registerLockScreenCallback"

    return-object v0

    .line 1616
    :pswitch_2d3
    const-string v0, "getPackagesState"

    return-object v0

    .line 1612
    :pswitch_2d6
    const-string/jumbo v0, "setPackagesState"

    return-object v0

    .line 1608
    :pswitch_2da
    const-string/jumbo v0, "setGimbalLaunchPkg"

    return-object v0

    .line 1604
    :pswitch_2de
    const-string/jumbo v0, "unregisterSysStateChangeObserver"

    return-object v0

    .line 1600
    :pswitch_2e2
    const-string/jumbo v0, "registerSysStateChangeObserver"

    return-object v0

    .line 1596
    :pswitch_2e6
    const-string/jumbo v0, "updateAppData"

    return-object v0

    .line 1592
    :pswitch_2ea
    const-string/jumbo v0, "unRegisterRegionScreenshot"

    return-object v0

    .line 1588
    :pswitch_2ee
    const-string/jumbo v0, "registerRegionScreenshot"

    return-object v0

    .line 1584
    :pswitch_2f2
    const-string v0, "getLastEvent"

    return-object v0

    .line 1580
    :pswitch_2f5
    const-string/jumbo v0, "releaseScreenshotRegion"

    return-object v0

    .line 1576
    :pswitch_2f9
    const-string/jumbo v0, "setRegionScreenshot"

    return-object v0

    .line 1572
    :pswitch_2fd
    const-string v0, "isPowerKeyPressed"

    return-object v0

    .line 1568
    :pswitch_300
    const-string/jumbo v0, "unregisterKeyEventObserver"

    return-object v0

    .line 1564
    :pswitch_304
    const-string/jumbo v0, "registerKeyEventObserver"

    return-object v0

    .line 1560
    :pswitch_308
    const-string/jumbo v0, "setPermitList"

    return-object v0

    .line 1556
    :pswitch_30c
    const-string v0, "getConfineMode"

    return-object v0

    .line 1552
    :pswitch_30f
    const-string/jumbo v0, "setConfineMode"

    return-object v0

    .line 1548
    :pswitch_313
    const-string/jumbo v0, "splitScreenForEdgePanel"

    return-object v0

    .line 1544
    :pswitch_317
    const-string/jumbo v0, "setEdgeTouchCallRules"

    return-object v0

    .line 1540
    :pswitch_31b
    const-string/jumbo v0, "isSupportEdgeTouchPrevent"

    return-object v0

    .line 1536
    :pswitch_31f
    const-string/jumbo v0, "resetDefaultEdgeTouchPreventParam"

    return-object v0

    .line 1532
    :pswitch_323
    const-string/jumbo v0, "setDefaultEdgeTouchPreventParam"

    return-object v0

    .line 1528
    :pswitch_327
    const-string/jumbo v0, "writeEdgeTouchPreventParam"

    return-object v0

    .line 1524
    :pswitch_32b
    const-string/jumbo v0, "isZoomSimpleModeEnable"

    return-object v0

    .line 1520
    :pswitch_32f
    const-string/jumbo v0, "replaceLockTaskPackages"

    return-object v0

    .line 1516
    :pswitch_333
    const-string/jumbo v0, "startLockDeviceModeWithFlag"

    return-object v0

    .line 1512
    :pswitch_337
    const-string v0, "isLockDeviceMode"

    return-object v0

    .line 1508
    :pswitch_33a
    const-string/jumbo v0, "stopLockDeviceMode"

    return-object v0

    .line 1504
    :pswitch_33e
    const-string/jumbo v0, "startLockDeviceMode"

    return-object v0

    .line 1500
    :pswitch_342
    const-string/jumbo v0, "removeZoomWindowConfigChangedListener"

    return-object v0

    .line 1496
    :pswitch_346
    const-string v0, "addZoomWindowConfigChangedListener"

    return-object v0

    .line 1492
    :pswitch_349
    const-string/jumbo v0, "setZoomWindowConfig"

    return-object v0

    .line 1488
    :pswitch_34d
    const-string v0, "getZoomWindowConfig"

    return-object v0

    .line 1484
    :pswitch_350
    const-string/jumbo v0, "isSupportZoomWindowMode"

    return-object v0

    .line 1480
    :pswitch_354
    const-string/jumbo v0, "onFloatHandleViewChanged"

    return-object v0

    .line 1476
    :pswitch_358
    const-string/jumbo v0, "updateDeferStartingWindowApps"

    return-object v0

    .line 1472
    :pswitch_35c
    const-string v0, "getSecurityFlagCurrentPage"

    return-object v0

    .line 1468
    :pswitch_35f
    const-string/jumbo v0, "unregisterSecurityPageCallback"

    return-object v0

    .line 1464
    :pswitch_363
    const-string/jumbo v0, "registerSecurityPageCallback"

    return-object v0

    .line 1460
    :pswitch_367
    const-string/jumbo v0, "unregisterZoomAppObserver"

    return-object v0

    .line 1456
    :pswitch_36b
    const-string/jumbo v0, "registerZoomAppObserver"

    return-object v0

    .line 1452
    :pswitch_36f
    const-string/jumbo v0, "onControlViewChanged"

    return-object v0

    .line 1448
    :pswitch_373
    const-string/jumbo v0, "onInputEvent"

    return-object v0

    .line 1444
    :pswitch_377
    const-string/jumbo v0, "notifyZoomStateChange"

    return-object v0

    .line 1440
    :pswitch_37b
    const-string/jumbo v0, "startMiniZoomFromZoom"

    return-object v0

    .line 1436
    :pswitch_37f
    const-string v0, "handleShowCompatibilityToast"

    return-object v0

    .line 1432
    :pswitch_382
    const-string/jumbo v0, "isSupportZoomMode"

    return-object v0

    .line 1428
    :pswitch_386
    const-string v0, "getZoomAppConfigList"

    return-object v0

    .line 1424
    :pswitch_389
    const-string v0, "hideZoomWindow"

    return-object v0

    .line 1420
    :pswitch_38c
    const-string v0, "getCurrentZoomWindowState"

    return-object v0

    .line 1416
    :pswitch_38f
    const-string/jumbo v0, "unregisterZoomWindowObserver"

    return-object v0

    .line 1412
    :pswitch_393
    const-string/jumbo v0, "registerZoomWindowObserver"

    return-object v0

    .line 1408
    :pswitch_397
    const-string/jumbo v0, "startZoomWindowByPendingIntent"

    return-object v0

    .line 1404
    :pswitch_39b
    const-string/jumbo v0, "startZoomWindow"

    return-object v0

    .line 1400
    :pswitch_39f
    const-string/jumbo v0, "unregisterDragAndDropListener"

    return-object v0

    .line 1396
    :pswitch_3a3
    const-string/jumbo v0, "registerDragAndDropListener"

    return-object v0

    .line 1392
    :pswitch_3a7
    const-string/jumbo v0, "unregisterAppSwitchObserver"

    return-object v0

    .line 1388
    :pswitch_3ab
    const-string/jumbo v0, "registerAppSwitchObserver"

    return-object v0

    .line 1384
    :pswitch_3af
    const-string/jumbo v0, "removeFreeformConfigChangedListener"

    return-object v0

    .line 1380
    :pswitch_3b3
    const-string v0, "addFreeformConfigChangedListener"

    return-object v0

    .line 1376
    :pswitch_3b6
    const-string v0, "isFreeformEnabled"

    return-object v0

    .line 1372
    :pswitch_3b9
    const-string v0, "getFreeformConfigList"

    return-object v0

    .line 1368
    :pswitch_3bc
    const-string v0, "getAllTopAppInfos"

    return-object v0

    .line 1364
    :pswitch_3bf
    const-string v0, "getSplitScreenState"

    return-object v0

    .line 1360
    :pswitch_3c2
    const-string v0, "getTopApplicationInfo"

    return-object v0

    .line 1356
    :pswitch_3c5
    const-string v0, "getTopActivityComponentName"

    return-object v0

    .line 1352
    :pswitch_3c8
    const-string/jumbo v0, "setSecureController"

    return-object v0

    :pswitch_data_3cc
    .packed-switch 0x1
        :pswitch_3c8
        :pswitch_3c5
        :pswitch_3c2
        :pswitch_3bf
        :pswitch_3bc
        :pswitch_3b9
        :pswitch_3b6
        :pswitch_3b3
        :pswitch_3af
        :pswitch_3ab
        :pswitch_3a7
        :pswitch_3a3
        :pswitch_39f
        :pswitch_39b
        :pswitch_397
        :pswitch_393
        :pswitch_38f
        :pswitch_38c
        :pswitch_389
        :pswitch_386
        :pswitch_382
        :pswitch_37f
        :pswitch_37b
        :pswitch_377
        :pswitch_373
        :pswitch_36f
        :pswitch_36b
        :pswitch_367
        :pswitch_363
        :pswitch_35f
        :pswitch_35c
        :pswitch_358
        :pswitch_354
        :pswitch_350
        :pswitch_34d
        :pswitch_349
        :pswitch_346
        :pswitch_342
        :pswitch_33e
        :pswitch_33a
        :pswitch_337
        :pswitch_333
        :pswitch_32f
        :pswitch_32b
        :pswitch_327
        :pswitch_323
        :pswitch_31f
        :pswitch_31b
        :pswitch_317
        :pswitch_313
        :pswitch_30f
        :pswitch_30c
        :pswitch_308
        :pswitch_304
        :pswitch_300
        :pswitch_2fd
        :pswitch_2f9
        :pswitch_2f5
        :pswitch_2f2
        :pswitch_2ee
        :pswitch_2ea
        :pswitch_2e6
        :pswitch_2e2
        :pswitch_2de
        :pswitch_2da
        :pswitch_2d6
        :pswitch_2d3
        :pswitch_2cf
        :pswitch_2cb
        :pswitch_2c7
        :pswitch_2c3
        :pswitch_2c0
        :pswitch_2bd
        :pswitch_2b9
        :pswitch_2b5
        :pswitch_2b2
        :pswitch_2ae
        :pswitch_2aa
        :pswitch_2a6
        :pswitch_2a2
        :pswitch_29f
        :pswitch_29c
        :pswitch_299
        :pswitch_296
        :pswitch_292
        :pswitch_28f
        :pswitch_28c
        :pswitch_288
        :pswitch_284
        :pswitch_281
        :pswitch_27d
        :pswitch_279
        :pswitch_275
        :pswitch_271
        :pswitch_26d
        :pswitch_26a
        :pswitch_267
        :pswitch_263
        :pswitch_25f
        :pswitch_25c
        :pswitch_258
        :pswitch_254
        :pswitch_250
        :pswitch_24c
        :pswitch_249
        :pswitch_246
        :pswitch_242
        :pswitch_23e
        :pswitch_23b
        :pswitch_237
        :pswitch_233
        :pswitch_22f
        :pswitch_22c
        :pswitch_229
        :pswitch_226
        :pswitch_222
        :pswitch_21e
        :pswitch_21a
        :pswitch_216
        :pswitch_212
        :pswitch_20e
        :pswitch_20a
        :pswitch_206
        :pswitch_202
        :pswitch_1fe
        :pswitch_1fa
        :pswitch_1f6
        :pswitch_1f2
        :pswitch_1ee
        :pswitch_1eb
        :pswitch_1e7
        :pswitch_1e4
        :pswitch_1e0
        :pswitch_1dc
        :pswitch_1d9
        :pswitch_1d6
        :pswitch_1d2
        :pswitch_1ce
        :pswitch_1ca
        :pswitch_1c6
        :pswitch_1c3
        :pswitch_1bf
        :pswitch_1bc
        :pswitch_1b9
        :pswitch_1b6
        :pswitch_1b3
        :pswitch_1b0
        :pswitch_1ad
        :pswitch_1aa
        :pswitch_1a6
        :pswitch_1a3
        :pswitch_1a0
        :pswitch_19c
        :pswitch_198
        :pswitch_194
        :pswitch_191
        :pswitch_18d
        :pswitch_18a
        :pswitch_187
        :pswitch_183
        :pswitch_180
        :pswitch_17c
        :pswitch_178
        :pswitch_174
        :pswitch_171
        :pswitch_16d
        :pswitch_169
        :pswitch_165
        :pswitch_161
        :pswitch_15d
        :pswitch_159
        :pswitch_156
        :pswitch_152
        :pswitch_14e
        :pswitch_14a
        :pswitch_146
        :pswitch_143
        :pswitch_140
        :pswitch_13d
        :pswitch_139
        :pswitch_136
        :pswitch_133
        :pswitch_130
        :pswitch_12c
        :pswitch_129
        :pswitch_125
        :pswitch_121
        :pswitch_11d
        :pswitch_119
        :pswitch_116
        :pswitch_113
        :pswitch_10f
        :pswitch_10b
        :pswitch_108
        :pswitch_104
        :pswitch_100
        :pswitch_fd
        :pswitch_fa
        :pswitch_f6
        :pswitch_f2
        :pswitch_ee
        :pswitch_ea
        :pswitch_e7
        :pswitch_e4
        :pswitch_e1
        :pswitch_de
        :pswitch_da
        :pswitch_d6
        :pswitch_d3
        :pswitch_cf
        :pswitch_cc
        :pswitch_c8
        :pswitch_c4
        :pswitch_c0
        :pswitch_bc
        :pswitch_b8
        :pswitch_b5
        :pswitch_b2
        :pswitch_ae
        :pswitch_aa
        :pswitch_a6
        :pswitch_a2
        :pswitch_9e
        :pswitch_9b
        :pswitch_97
        :pswitch_93
        :pswitch_90
        :pswitch_8c
        :pswitch_88
        :pswitch_85
        :pswitch_82
        :pswitch_7f
        :pswitch_7c
        :pswitch_79
        :pswitch_75
        :pswitch_71
        :pswitch_6d
        :pswitch_6a
        :pswitch_66
        :pswitch_62
        :pswitch_5e
        :pswitch_5a
        :pswitch_56
        :pswitch_52
        :pswitch_4e
        :pswitch_4b
        :pswitch_47
        :pswitch_43
        :pswitch_40
        :pswitch_3d
        :pswitch_39
        :pswitch_35
        :pswitch_31
        :pswitch_2e
        :pswitch_2a
        :pswitch_26
        :pswitch_22
        :pswitch_1f
        :pswitch_1c
        :pswitch_19
        :pswitch_15
        :pswitch_11
        :pswitch_d
        :pswitch_9
        :pswitch_5
    .end packed-switch
.end method

.method static synthetic blacklist lambda$onTransact$0(Landroid/os/Parcel;Ljava/util/Map;I)V
    .registers 5
    .param p0, "data"    # Landroid/os/Parcel;
    .param p1, "_arg1"    # Ljava/util/Map;
    .param p2, "i"    # I

    .line 2921
    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    .line 2923
    .local v0, "k":Ljava/lang/String;
    invoke-virtual {p0}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 2924
    .local v1, "v":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2925
    return-void
.end method


# virtual methods
.method public whitelist asBinder()Landroid/os/IBinder;
    .registers 1

    .line 1343
    return-object p0
.end method

.method public blacklist getMaxTransactionId()I
    .registers 2

    .line 10568
    const/16 v0, 0x108

    return v0
.end method

.method public blacklist getTransactionName(I)Ljava/lang/String;
    .registers 3
    .param p1, "transactionCode"    # I

    .line 2419
    invoke-static {p1}, Landroid/app/IOplusActivityTaskManager$Stub;->getDefaultTransactionName(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 18
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 2423
    move-object v8, p2

    move-object/from16 v9, p3

    const-string v10, "android.app.IOplusActivityTaskManager"

    .line 2424
    .local v10, "descriptor":Ljava/lang/String;
    const/4 v11, 0x1

    if-lt p1, v11, :cond_10

    const v1, 0xffffff

    if-gt p1, v1, :cond_10

    .line 2425
    invoke-virtual {p2, v10}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 2427
    :cond_10
    const v1, 0x5f4e5446

    if-ne p1, v1, :cond_19

    .line 2428
    invoke-virtual {v9, v10}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2429
    return v11

    .line 2431
    :cond_19
    packed-switch p1, :pswitch_data_171a

    .line 5297
    invoke-super/range {p0 .. p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1

    return v1

    .line 5284
    :pswitch_21
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 5286
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 5288
    .local v2, "_arg1":Landroid/os/Bundle;
    sget-object v3, Landroid/view/SurfaceControl;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/SurfaceControl;

    .line 5290
    .local v3, "_arg2":Landroid/view/SurfaceControl;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v4

    .line 5291
    .local v4, "_arg3":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5292
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->preStartActivity(Landroid/content/Intent;Landroid/os/Bundle;Landroid/view/SurfaceControl;Landroid/os/IBinder;)V

    .line 5293
    goto/16 :goto_1719

    .line 5275
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Landroid/view/SurfaceControl;
    .end local v4    # "_arg3":Landroid/os/IBinder;
    :pswitch_45
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusStartingWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusStartingWindowObserver;

    move-result-object v1

    .line 5276
    .local v1, "_arg0":Lcom/oplus/app/IOplusStartingWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5277
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V

    .line 5278
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5279
    goto/16 :goto_1719

    .line 5266
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusStartingWindowObserver;
    :pswitch_58
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusStartingWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusStartingWindowObserver;

    move-result-object v1

    .line 5267
    .restart local v1    # "_arg0":Lcom/oplus/app/IOplusStartingWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5268
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerStartingWindowObserver(Lcom/oplus/app/IOplusStartingWindowObserver;)V

    .line 5269
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5270
    goto/16 :goto_1719

    .line 5250
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusStartingWindowObserver;
    :pswitch_6b
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 5252
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 5254
    .local v2, "_arg1":Ljava/lang/String;
    sget-object v3, Lcom/oplus/app/OplusWindowChangeRegisterParam;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/oplus/app/OplusWindowChangeRegisterParam;

    .line 5256
    .local v3, "_arg2":Lcom/oplus/app/OplusWindowChangeRegisterParam;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v4

    invoke-static {v4}, Lcom/oplus/app/IOplusWindowChangeObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusWindowChangeObserver;

    move-result-object v4

    .line 5257
    .local v4, "_arg3":Lcom/oplus/app/IOplusWindowChangeObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5258
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->registerWindowChangeListener(Ljava/lang/String;Ljava/lang/String;Lcom/oplus/app/OplusWindowChangeRegisterParam;Lcom/oplus/app/IOplusWindowChangeObserver;)Z

    move-result v5

    .line 5259
    .local v5, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5260
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5261
    goto/16 :goto_1719

    .line 5238
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Lcom/oplus/app/OplusWindowChangeRegisterParam;
    .end local v4    # "_arg3":Lcom/oplus/app/IOplusWindowChangeObserver;
    .end local v5    # "_result":Z
    :pswitch_92
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 5240
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 5241
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5242
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterWindowChangeListener(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    .line 5243
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5244
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5245
    goto/16 :goto_1719

    .line 5228
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_a9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5229
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5230
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getFlexibleWindowConfigList(I)Ljava/util/List;

    move-result-object v2

    .line 5231
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5232
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 5233
    goto/16 :goto_1719

    .line 5218
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_bc
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 5219
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5220
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getUriForFlexibleWindow(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 5221
    .local v2, "_result":Ljava/lang/String;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5222
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 5223
    goto/16 :goto_1719

    .line 5208
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Ljava/lang/String;
    :pswitch_cf
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5209
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5210
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getTaskDescriptionLabel(I)Ljava/lang/String;

    move-result-object v2

    .line 5211
    .restart local v2    # "_result":Ljava/lang/String;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5212
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 5213
    goto/16 :goto_1719

    .line 5197
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/lang/String;
    :pswitch_e2
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5199
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 5200
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5201
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->moveActivityTaskToBack(IZ)V

    .line 5202
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5203
    goto/16 :goto_1719

    .line 5188
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    :pswitch_f5
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IFlexibleTaskListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IFlexibleTaskListener;

    move-result-object v1

    .line 5189
    .local v1, "_arg0":Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5190
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V

    .line 5191
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5192
    goto/16 :goto_1719

    .line 5179
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    :pswitch_108
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IFlexibleTaskListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IFlexibleTaskListener;

    move-result-object v1

    .line 5180
    .restart local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5181
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerFlexibleTaskListener(Lcom/oplus/flexiblewindow/IFlexibleTaskListener;)V

    .line 5182
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5183
    goto/16 :goto_1719

    .line 5161
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleTaskListener;
    :pswitch_11b
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 5163
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/window/WindowContainerToken;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/window/WindowContainerToken;

    .line 5165
    .local v2, "_arg1":Landroid/window/WindowContainerToken;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 5167
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 5169
    .local v4, "_arg3":Z
    sget-object v5, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/Rect;

    .line 5170
    .local v5, "_arg4":Landroid/graphics/Rect;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5171
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->getEmbeddedTaskSnapshot(Landroid/content/Intent;Landroid/window/WindowContainerToken;ZZLandroid/graphics/Rect;)Landroid/window/TaskSnapshot;

    move-result-object v6

    .line 5172
    .local v6, "_result":Landroid/window/TaskSnapshot;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5173
    invoke-virtual {v9, v6, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 5174
    goto/16 :goto_1719

    .line 5150
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/window/WindowContainerToken;
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    .end local v5    # "_arg4":Landroid/graphics/Rect;
    .end local v6    # "_result":Landroid/window/TaskSnapshot;
    :pswitch_14b
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5152
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 5153
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5154
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateLockTaskPackages(I[Ljava/lang/String;)V

    .line 5155
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5156
    goto/16 :goto_1719

    .line 5139
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_15e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5141
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5142
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5143
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateLockTaskFeatures(II)V

    .line 5144
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5145
    goto/16 :goto_1719

    .line 5128
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    :pswitch_171
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 5130
    .local v1, "_arg0":Landroid/os/IBinder;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 5131
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5132
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setBackInvokePolicyForPredictive(Landroid/os/IBinder;Landroid/os/Bundle;)V

    .line 5133
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5134
    goto/16 :goto_1719

    .line 5116
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    :pswitch_188
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5118
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5119
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5120
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->getZoomBoundsByTaskId(II)Landroid/graphics/Rect;

    move-result-object v3

    .line 5121
    .local v3, "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5122
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 5123
    goto/16 :goto_1719

    .line 5104
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Landroid/graphics/Rect;
    :pswitch_19f
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 5106
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5107
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5108
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->getZoomBounds(ZI)Landroid/graphics/Rect;

    move-result-object v3

    .line 5109
    .restart local v3    # "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5110
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 5111
    goto/16 :goto_1719

    .line 5091
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Landroid/graphics/Rect;
    :pswitch_1b6
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5093
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5095
    .restart local v2    # "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 5096
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5097
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->setMirageDisplayUserRotation(IILandroid/os/Bundle;)V

    .line 5098
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5099
    goto/16 :goto_1719

    .line 5080
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    :pswitch_1d1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5082
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 5083
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5084
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->sendMirageEvents(ILandroid/os/Bundle;)V

    .line 5085
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5086
    goto/16 :goto_1719

    .line 5070
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    :pswitch_1e8
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 5071
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5072
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->adjustFlexibleTask(Landroid/os/Bundle;)Z

    move-result v2

    .line 5073
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5074
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5075
    goto/16 :goto_1719

    .line 5054
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":Z
    :pswitch_1ff
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 5056
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5058
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 5060
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 5061
    .restart local v4    # "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5062
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->toggleFlexibleWindowByApp(Landroid/os/IBinder;IZZ)Z

    move-result v5

    .line 5063
    .local v5, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5064
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5065
    goto/16 :goto_1719

    .line 5044
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    .end local v5    # "_result":Z
    :pswitch_21e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 5045
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5046
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->toggleFlexibleWindow(Ljava/lang/String;)Z

    move-result v2

    .line 5047
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5048
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5049
    goto/16 :goto_1719

    .line 5026
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_231
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 5028
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 5030
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 5032
    .local v3, "_arg2":I
    sget-object v4, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/Intent;

    .line 5034
    .local v4, "_arg3":Landroid/content/Intent;
    sget-object v5, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/Bundle;

    .line 5035
    .local v5, "_arg4":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5036
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->isTaskExist(IIILandroid/content/Intent;Landroid/os/Bundle;)Z

    move-result v6

    .line 5037
    .local v6, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5038
    invoke-virtual {v9, v6}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5039
    goto/16 :goto_1719

    .line 5016
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Landroid/content/Intent;
    .end local v5    # "_arg4":Landroid/os/Bundle;
    .end local v6    # "_result":Z
    :pswitch_25d
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusTaskStackListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusTaskStackListener;

    move-result-object v1

    .line 5017
    .local v1, "_arg0":Lcom/oplus/app/IOplusTaskStackListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5018
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;)Z

    move-result v2

    .line 5019
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5020
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5021
    goto/16 :goto_1719

    .line 5002
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusTaskStackListener;
    .end local v2    # "_result":Z
    :pswitch_274
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusTaskStackListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusTaskStackListener;

    move-result-object v1

    .line 5004
    .restart local v1    # "_arg0":Lcom/oplus/app/IOplusTaskStackListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v2

    .line 5006
    .local v2, "_arg1":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 5007
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 5008
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->registerOplusTaskStackListener(Lcom/oplus/app/IOplusTaskStackListener;[II)Z

    move-result v4

    .line 5009
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 5010
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 5011
    goto/16 :goto_1719

    .line 4992
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusTaskStackListener;
    .end local v2    # "_arg1":[I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_293
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusTaskInfoChangeListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusTaskInfoChangeListener;

    move-result-object v1

    .line 4993
    .local v1, "_arg0":Lcom/oplus/app/IOplusTaskInfoChangeListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4994
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;)Z

    move-result v2

    .line 4995
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4996
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4997
    goto/16 :goto_1719

    .line 4978
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusTaskInfoChangeListener;
    .end local v2    # "_result":Z
    :pswitch_2aa
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusTaskInfoChangeListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusTaskInfoChangeListener;

    move-result-object v1

    .line 4980
    .restart local v1    # "_arg0":Lcom/oplus/app/IOplusTaskInfoChangeListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4982
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4983
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4984
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->registerTaskInfoChangeListener(Lcom/oplus/app/IOplusTaskInfoChangeListener;II)Z

    move-result v4

    .line 4985
    .restart local v4    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4986
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4987
    goto/16 :goto_1719

    .line 4968
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusTaskInfoChangeListener;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_2c9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4969
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4970
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getVisibleTasks(I)Ljava/util/List;

    move-result-object v2

    .line 4971
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4972
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 4973
    goto/16 :goto_1719

    .line 4958
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    :pswitch_2dc
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomStateListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomStateListener;

    move-result-object v1

    .line 4959
    .local v1, "_arg0":Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4960
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v2

    .line 4961
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4962
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4963
    goto/16 :goto_1719

    .line 4948
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .end local v2    # "_result":Z
    :pswitch_2f3
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomStateListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomStateListener;

    move-result-object v1

    .line 4949
    .restart local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4950
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v2

    .line 4951
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4952
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4953
    goto/16 :goto_1719

    .line 4935
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomStateListener;
    .end local v2    # "_result":Z
    :pswitch_30a
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4937
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4939
    .local v2, "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 4940
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4941
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyFlexibleTaskEvent(IILandroid/os/Bundle;)V

    .line 4942
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4943
    goto/16 :goto_1719

    .line 4927
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    :pswitch_325
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getFlexibleMinimizedTaskId()I

    move-result v1

    .line 4928
    .local v1, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4929
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 4930
    goto/16 :goto_1719

    .line 4920
    .end local v1    # "_result":I
    :pswitch_331
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->adjustEndAbsForFlexibleMinimize()Landroid/graphics/Rect;

    move-result-object v1

    .line 4921
    .local v1, "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4922
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4923
    goto/16 :goto_1719

    .line 4911
    .end local v1    # "_result":Landroid/graphics/Rect;
    :pswitch_33d
    sget-object v1, Landroid/window/TransitionInfo$Change;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/window/TransitionInfo$Change;

    .line 4912
    .local v1, "_arg0":Landroid/window/TransitionInfo$Change;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4913
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->adjustEndAbsForFlexibleMinimizeIfNeed(Landroid/window/TransitionInfo$Change;)Landroid/graphics/Rect;

    move-result-object v2

    .line 4914
    .local v2, "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4915
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4916
    goto/16 :goto_1719

    .line 4897
    .end local v1    # "_arg0":Landroid/window/TransitionInfo$Change;
    .end local v2    # "_result":Landroid/graphics/Rect;
    :pswitch_354
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4899
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4901
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 4902
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4903
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->getEmbeddedChildrenSnapshot(IZZ)Landroid/window/TaskSnapshot;

    move-result-object v4

    .line 4904
    .local v4, "_result":Landroid/window/TaskSnapshot;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4905
    invoke-virtual {v9, v4, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4906
    goto/16 :goto_1719

    .line 4887
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Z
    .end local v4    # "_result":Landroid/window/TaskSnapshot;
    :pswitch_36f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4888
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4889
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getEmbeddedChildren(I)Ljava/util/List;

    move-result-object v2

    .line 4890
    .local v2, "_result":Ljava/util/List;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4891
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeList(Ljava/util/List;)V

    .line 4892
    goto/16 :goto_1719

    .line 4875
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;
    :pswitch_382
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4877
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4878
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4879
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startActivityFromRecentsForFlexible(ILandroid/os/Bundle;)I

    move-result v3

    .line 4880
    .local v3, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4881
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 4882
    goto/16 :goto_1719

    .line 4863
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":I
    :pswitch_39d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4865
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4866
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4867
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setFlexibleTaskEnabled(IZ)Z

    move-result v3

    .line 4868
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4869
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4870
    goto/16 :goto_1719

    .line 4853
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Z
    :pswitch_3b4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4854
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4855
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isFlexibleTaskEnabled(I)Z

    move-result v2

    .line 4856
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4857
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4858
    goto/16 :goto_1719

    .line 4840
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_3c7
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4842
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4844
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 4845
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4846
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->moveTaskToDisplay(IIZ)V

    .line 4847
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4848
    goto/16 :goto_1719

    .line 4831
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Z
    :pswitch_3de
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4832
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4833
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->releaseVirtualDisplayDevice(I)V

    .line 4834
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4835
    goto/16 :goto_1719

    .line 4821
    .end local v1    # "_arg0":I
    :pswitch_3ed
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 4822
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4823
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->createVirtualDisplayDevice(Landroid/os/Bundle;)I

    move-result v2

    .line 4824
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4825
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 4826
    goto/16 :goto_1719

    .line 4803
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":I
    :pswitch_404
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    .line 4805
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v2

    .line 4807
    .local v2, "_arg1":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v3

    .line 4809
    .local v3, "_arg2":[I
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 4811
    .local v4, "_arg3":Landroid/os/Bundle;
    sget-object v5, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/Bundle;

    .line 4812
    .restart local v5    # "_arg4":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4813
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->shouldSkipStartPocketStudio(Ljava/util/List;[I[ILandroid/os/Bundle;Landroid/os/Bundle;)Z

    move-result v6

    .line 4814
    .restart local v6    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4815
    invoke-virtual {v9, v6}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4816
    goto/16 :goto_1719

    .line 4784
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .end local v2    # "_arg1":[I
    .end local v3    # "_arg2":[I
    .end local v4    # "_arg3":Landroid/os/Bundle;
    .end local v5    # "_arg4":Landroid/os/Bundle;
    .end local v6    # "_result":Z
    :pswitch_432
    sget-object v0, Landroid/window/WindowContainerToken;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/window/WindowContainerToken;

    .line 4786
    .local v1, "_arg0":Landroid/window/WindowContainerToken;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4788
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 4790
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 4792
    .local v4, "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v5

    .line 4794
    .local v5, "_arg4":Z
    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Landroid/os/Bundle;

    .line 4795
    .local v6, "_arg5":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4796
    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/app/IOplusActivityTaskManager$Stub;->updateTaskVisibility(Landroid/window/WindowContainerToken;IZZZLandroid/os/Bundle;)V

    .line 4797
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4798
    goto/16 :goto_1719

    .line 4770
    .end local v1    # "_arg0":Landroid/window/WindowContainerToken;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    .end local v5    # "_arg4":Z
    .end local v6    # "_arg5":Landroid/os/Bundle;
    :pswitch_460
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/app/IAssistDataReceiver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IAssistDataReceiver;

    move-result-object v1

    .line 4772
    .local v1, "_arg0":Landroid/app/IAssistDataReceiver;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4774
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    .line 4776
    .local v3, "_arg2":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 4777
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4778
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->requestViewExtractData(Landroid/app/IAssistDataReceiver;Landroid/os/Bundle;Landroid/os/IBinder;I)V

    .line 4779
    goto/16 :goto_1719

    .line 4762
    .end local v1    # "_arg0":Landroid/app/IAssistDataReceiver;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Landroid/os/IBinder;
    .end local v4    # "_arg3":I
    :pswitch_480
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 4763
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4764
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->reportViewExtractResult(Landroid/os/Bundle;)V

    .line 4765
    goto/16 :goto_1719

    .line 4750
    .end local v1    # "_arg0":Landroid/os/Bundle;
    :pswitch_490
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 4752
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4754
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 4755
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4756
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->updateRecordSurfaceViewState(Landroid/os/IBinder;ZZ)V

    .line 4757
    goto/16 :goto_1719

    .line 4733
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Z
    :pswitch_4a4
    sget-object v1, Landroid/view/WindowManager$LayoutParams;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager$LayoutParams;

    .line 4735
    .local v1, "_arg0":Landroid/view/WindowManager$LayoutParams;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4737
    .local v2, "_arg1":I
    sget-object v3, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Rect;

    .line 4739
    .local v3, "_arg2":Landroid/graphics/Rect;
    sget-object v4, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Rect;

    .line 4740
    .local v4, "_arg3":Landroid/graphics/Rect;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4741
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->adjustWindowFrame(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 4742
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4743
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4744
    invoke-virtual {v9, v4, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4745
    goto/16 :goto_1719

    .line 4721
    .end local v1    # "_arg0":Landroid/view/WindowManager$LayoutParams;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/graphics/Rect;
    .end local v4    # "_arg3":Landroid/graphics/Rect;
    :pswitch_4d1
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 4723
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 4724
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4725
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->getActivityConfigs(Landroid/os/IBinder;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v3

    .line 4726
    .local v3, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4727
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4728
    goto/16 :goto_1719

    .line 4713
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Landroid/os/Bundle;
    :pswitch_4e8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4714
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4715
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->resetNoReparentTask(I)V

    .line 4716
    goto/16 :goto_1719

    .line 4703
    .end local v1    # "_arg0":I
    :pswitch_4f4
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;

    move-result-object v1

    .line 4705
    .local v1, "_arg0":Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4706
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4707
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V

    .line 4708
    goto/16 :goto_1719

    .line 4693
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .end local v2    # "_arg1":I
    :pswitch_508
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;

    move-result-object v1

    .line 4695
    .restart local v1    # "_arg0":Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4696
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4697
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerEmbeddedWindowContainerCallback(Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;I)V

    .line 4698
    goto/16 :goto_1719

    .line 4681
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IEmbeddedWindowContainerCallback;
    .end local v2    # "_arg1":I
    :pswitch_51c
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 4683
    .local v1, "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4685
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4686
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4687
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyFlexibleSplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;I)V

    .line 4688
    goto/16 :goto_1719

    .line 4671
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":I
    :pswitch_534
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 4673
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4674
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4675
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyEmbeddedTasksChangeFocus(ZI)V

    .line 4676
    goto/16 :goto_1719

    .line 4661
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":I
    :pswitch_544
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4662
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4663
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isInAppInnerSplitScreen(I)Z

    move-result v2

    .line 4664
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4665
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4666
    goto/16 :goto_1719

    .line 4644
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_557
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4646
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4648
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4650
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 4652
    .local v4, "_arg3":Ljava/lang/String;
    sget-object v5, Landroid/view/SurfaceControl;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/SurfaceControl;

    .line 4653
    .local v5, "_arg4":Landroid/view/SurfaceControl;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4654
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyFlexibleBlurAttachEvent(Landroid/content/Intent;IILjava/lang/String;Landroid/view/SurfaceControl;)V

    .line 4655
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4656
    goto/16 :goto_1719

    .line 4629
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Landroid/view/SurfaceControl;
    :pswitch_57f
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4631
    .restart local v1    # "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4633
    .restart local v2    # "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 4635
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v4

    invoke-static {v4}, Landroid/view/ITargetTaskCallBack$Stub;->asInterface(Landroid/os/IBinder;)Landroid/view/ITargetTaskCallBack;

    move-result-object v4

    .line 4636
    .local v4, "_arg3":Landroid/view/ITargetTaskCallBack;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4637
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->findTargetTaskByIntent(Landroid/content/Intent;ILandroid/os/Bundle;Landroid/view/ITargetTaskCallBack;)V

    .line 4638
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4639
    goto/16 :goto_1719

    .line 4618
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    .end local v4    # "_arg3":Landroid/view/ITargetTaskCallBack;
    :pswitch_5a6
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 4620
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;

    move-result-object v2

    .line 4621
    .local v2, "_arg1":Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4622
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startDragFullscreenAnimation(Landroid/os/Bundle;Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;)V

    .line 4623
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4624
    goto/16 :goto_1719

    .line 4604
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":Lcom/oplus/flexiblewindow/IFullscreenDragAnimationFinishedCallback;
    :pswitch_5c1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4606
    .local v1, "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4608
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    invoke-static {v3}, Lcom/oplus/flexiblewindow/IMinimizedCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IMinimizedCallback;

    move-result-object v3

    .line 4609
    .local v3, "_arg2":Lcom/oplus/flexiblewindow/IMinimizedCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4610
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyMinimizedReady(ILandroid/os/Bundle;Lcom/oplus/flexiblewindow/IMinimizedCallback;)Z

    move-result v4

    .line 4611
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4612
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4613
    goto/16 :goto_1719

    .line 4594
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Lcom/oplus/flexiblewindow/IMinimizedCallback;
    .end local v4    # "_result":Z
    :pswitch_5e4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4595
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4596
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getCurrentZoomToSplitState(I)I

    move-result v2

    .line 4597
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4598
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 4599
    goto/16 :goto_1719

    .line 4576
    .end local v1    # "_arg0":I
    .end local v2    # "_result":I
    :pswitch_5f7
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    .line 4578
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4580
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4582
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 4584
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v5

    .line 4585
    .local v5, "_arg4":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4586
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->calculateReplaceCanvasLayoutRect(Ljava/util/List;IIIZ)Ljava/util/List;

    move-result-object v6

    .line 4587
    .local v6, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Rect;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4588
    invoke-virtual {v9, v6, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 4589
    goto/16 :goto_1719

    .line 4560
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":Z
    .end local v6    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Rect;>;"
    :pswitch_61d
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    .line 4562
    .restart local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4564
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4566
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 4567
    .local v4, "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4568
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->calculateCanvasLayoutRect(Ljava/util/List;IIZ)Ljava/util/List;

    move-result-object v5

    .line 4569
    .local v5, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Rect;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4570
    invoke-virtual {v9, v5, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 4571
    goto/16 :goto_1719

    .line 4546
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Z
    .end local v5    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Rect;>;"
    :pswitch_63e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4548
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4550
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4551
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4552
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->isClickAtPocketStudioArea(III)Z

    move-result v4

    .line 4553
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4554
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4555
    goto/16 :goto_1719

    .line 4534
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_659
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4536
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/Rect;

    .line 4537
    .local v2, "_arg1":Landroid/graphics/Rect;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4538
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startFlexibleWindowForRecentTasks(ILandroid/graphics/Rect;)Z

    move-result v3

    .line 4539
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4540
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4541
    goto/16 :goto_1719

    .line 4522
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/graphics/Rect;
    .end local v3    # "_result":Z
    :pswitch_674
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4524
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4525
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4526
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startAnyActivity(Landroid/content/Intent;Landroid/os/Bundle;)I

    move-result v3

    .line 4527
    .local v3, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4528
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 4529
    goto/16 :goto_1719

    .line 4507
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":I
    :pswitch_693
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4509
    .restart local v1    # "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4511
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4513
    .local v3, "_arg2":I
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 4514
    .local v4, "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4515
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->setTaskInsensibleParams(Landroid/content/Intent;IILandroid/os/Bundle;)V

    .line 4516
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4517
    goto/16 :goto_1719

    .line 4496
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Landroid/os/Bundle;
    :pswitch_6b6
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4498
    .restart local v1    # "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4499
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4500
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startActivityInTask(Landroid/content/Intent;I)V

    .line 4501
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4502
    goto/16 :goto_1719

    .line 4486
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    :pswitch_6cd
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4487
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4488
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getRecentEmbeddedTasksForContainer(I)Ljava/util/List;

    move-result-object v2

    .line 4489
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4490
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 4491
    goto/16 :goto_1719

    .line 4475
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    :pswitch_6e0
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    .line 4477
    .local v1, "_arg0":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4478
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4479
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->clearEmbeddedContainerTask([II)V

    .line 4480
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4481
    goto/16 :goto_1719

    .line 4460
    .end local v1    # "_arg0":[I
    .end local v2    # "_arg1":I
    :pswitch_6f3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4462
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4464
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 4466
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 4467
    .local v4, "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4468
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->resetFlexibleTask(IZZZ)V

    .line 4469
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4470
    goto/16 :goto_1719

    .line 4449
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Z
    :pswitch_70e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4451
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4452
    .restart local v2    # "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4453
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setFlexibleTaskEmbedding(IZ)V

    .line 4454
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4455
    goto/16 :goto_1719

    .line 4440
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    :pswitch_721
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4441
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4442
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->exitFlexibleEmbeddedTask(I)V

    .line 4443
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4444
    goto/16 :goto_1719

    .line 4429
    .end local v1    # "_arg0":I
    :pswitch_730
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4431
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4432
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4433
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->removeEmbeddedContainerTask(II)V

    .line 4434
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4435
    goto/16 :goto_1719

    .line 4414
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    :pswitch_743
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4416
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/Intent;

    .line 4418
    .local v2, "_arg1":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4420
    .local v3, "_arg2":I
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 4421
    .local v4, "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4422
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->replaceSplitTask(ILandroid/content/Intent;ILandroid/os/Bundle;)V

    .line 4423
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4424
    goto/16 :goto_1719

    .line 4403
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/content/Intent;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Landroid/os/Bundle;
    :pswitch_766
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4405
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4406
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4407
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->exitSplitTask(ILandroid/os/Bundle;)V

    .line 4408
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4409
    goto/16 :goto_1719

    .line 4392
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    :pswitch_77d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4394
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4395
    .restart local v2    # "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4396
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->closeSplitTask(ILandroid/os/Bundle;)V

    .line 4397
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4398
    goto/16 :goto_1719

    .line 4383
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    :pswitch_794
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4384
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4385
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setFocusAppForEmbeddedTask(I)V

    .line 4386
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4387
    goto/16 :goto_1719

    .line 4372
    .end local v1    # "_arg0":I
    :pswitch_7a3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4374
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4375
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4376
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setEmbeddedContainerTask(II)V

    .line 4377
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4378
    goto/16 :goto_1719

    .line 4363
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    :pswitch_7b6
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 4364
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4365
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setIsInFocusAnimating(Z)V

    .line 4366
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4367
    goto/16 :goto_1719

    .line 4353
    .end local v1    # "_arg0":Z
    :pswitch_7c5
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4355
    .local v1, "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 4356
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4357
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setFlexibleFrame(ILandroid/os/Bundle;)V

    .line 4358
    goto/16 :goto_1719

    .line 4343
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    :pswitch_7d9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4344
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4345
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isMinimizedPocketStudio(I)Z

    move-result v2

    .line 4346
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4347
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4348
    goto/16 :goto_1719

    .line 4332
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_7ec
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 4334
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4335
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4336
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setMinimizedPocketStudio(ZI)V

    .line 4337
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4338
    goto/16 :goto_1719

    .line 4322
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":I
    :pswitch_7ff
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4323
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4324
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getPocketStudioTaskRegion(I)Ljava/util/Map;

    move-result-object v2

    .line 4325
    .local v2, "_result":Ljava/util/Map;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4326
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeMap(Ljava/util/Map;)V

    .line 4327
    goto/16 :goto_1719

    .line 4312
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/Map;
    :pswitch_812
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4313
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4314
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isInPocketStudioForStandard(I)Z

    move-result v2

    .line 4315
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4316
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4317
    goto/16 :goto_1719

    .line 4302
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_825
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4303
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4304
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isInPocketStudio(I)Z

    move-result v2

    .line 4305
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4306
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4307
    goto/16 :goto_1719

    .line 4289
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_838
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4291
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4293
    .local v2, "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 4294
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4295
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->startTaskToSplit(Landroid/content/Intent;ILandroid/os/Bundle;)V

    .line 4296
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4297
    goto/16 :goto_1719

    .line 4277
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    :pswitch_857
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4279
    .restart local v1    # "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4280
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4281
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->isAppSupportPocketStudio(Landroid/content/Intent;I)Z

    move-result v3

    .line 4282
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4283
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4284
    goto/16 :goto_1719

    .line 4263
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_872
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    .line 4265
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4267
    .restart local v2    # "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 4268
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4269
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->calculateFlexibleWindowBoundList(Ljava/util/List;ILandroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v4

    .line 4270
    .local v4, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4271
    invoke-virtual {v9, v4, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4272
    goto/16 :goto_1719

    .line 4249
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    .end local v4    # "_result":Landroid/os/Bundle;
    :pswitch_893
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 4251
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4253
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4254
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4255
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->calculateFlexibleWindowBounds(Landroid/content/Intent;II)Landroid/os/Bundle;

    move-result-object v4

    .line 4256
    .restart local v4    # "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4257
    invoke-virtual {v9, v4, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4258
    goto/16 :goto_1719

    .line 4239
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Landroid/os/Bundle;
    :pswitch_8b2
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IFlexibleWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;

    move-result-object v1

    .line 4240
    .local v1, "_arg0":Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4241
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;)Z

    move-result v2

    .line 4242
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4243
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4244
    goto/16 :goto_1719

    .line 4227
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_8c9
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/flexiblewindow/IFlexibleWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;

    move-result-object v1

    .line 4229
    .restart local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4230
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4231
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerFlexibleWindowObserver(Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;I)Z

    move-result v3

    .line 4232
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4233
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4234
    goto/16 :goto_1719

    .line 4209
    .end local v1    # "_arg0":Lcom/oplus/flexiblewindow/IFlexibleWindowObserver;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_8e4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4211
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 4213
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4215
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 4217
    .local v4, "_arg3":Ljava/lang/String;
    sget-object v5, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/Bundle;

    .line 4218
    .local v5, "_arg4":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4219
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->isSupportPuttMode(ILjava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result v6

    .line 4220
    .local v6, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4221
    invoke-virtual {v9, v6}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4222
    goto/16 :goto_1719

    .line 4195
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Landroid/os/Bundle;
    .end local v6    # "_result":Z
    :pswitch_90c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4197
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 4199
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 4200
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4201
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->removePuttTask(ILjava/lang/String;I)Z

    move-result v4

    .line 4202
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4203
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4204
    goto/16 :goto_1719

    .line 4187
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_927
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getEnterPuttAppInfos()Ljava/util/List;

    move-result-object v1

    .line 4188
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/putt/OplusPuttEnterInfo;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4189
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 4190
    goto/16 :goto_1719

    .line 4178
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/putt/OplusPuttEnterInfo;>;"
    :pswitch_933
    sget-object v1, Lcom/oplus/putt/PuttParams;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/putt/PuttParams;

    .line 4179
    .local v1, "_arg0":Lcom/oplus/putt/PuttParams;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4180
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->startPutt(Lcom/oplus/putt/PuttParams;)Z

    move-result v2

    .line 4181
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4182
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4183
    goto/16 :goto_1719

    .line 4164
    .end local v1    # "_arg0":Lcom/oplus/putt/PuttParams;
    .end local v2    # "_result":Z
    :pswitch_94a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 4166
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4168
    .local v2, "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 4169
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4170
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->stopPutt(Ljava/lang/String;ILandroid/os/Bundle;)Z

    move-result v4

    .line 4171
    .restart local v4    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4172
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4173
    goto/16 :goto_1719

    .line 4154
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    .end local v4    # "_result":Z
    :pswitch_969
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/putt/IPuttEventObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/putt/IPuttEventObserver;

    move-result-object v1

    .line 4155
    .local v1, "_arg0":Lcom/oplus/putt/IPuttEventObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4156
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z

    move-result v2

    .line 4157
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4158
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4159
    goto/16 :goto_1719

    .line 4144
    .end local v1    # "_arg0":Lcom/oplus/putt/IPuttEventObserver;
    .end local v2    # "_result":Z
    :pswitch_980
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/putt/IPuttEventObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/putt/IPuttEventObserver;

    move-result-object v1

    .line 4145
    .restart local v1    # "_arg0":Lcom/oplus/putt/IPuttEventObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4146
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerPuttEventObserver(Lcom/oplus/putt/IPuttEventObserver;)Z

    move-result v2

    .line 4147
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4148
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4149
    goto/16 :goto_1719

    .line 4134
    .end local v1    # "_arg0":Lcom/oplus/putt/IPuttEventObserver;
    .end local v2    # "_result":Z
    :pswitch_997
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/putt/IPuttObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/putt/IPuttObserver;

    move-result-object v1

    .line 4135
    .local v1, "_arg0":Lcom/oplus/putt/IPuttObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4136
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z

    move-result v2

    .line 4137
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4138
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4139
    goto/16 :goto_1719

    .line 4124
    .end local v1    # "_arg0":Lcom/oplus/putt/IPuttObserver;
    .end local v2    # "_result":Z
    :pswitch_9ae
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/putt/IPuttObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/putt/IPuttObserver;

    move-result-object v1

    .line 4125
    .restart local v1    # "_arg0":Lcom/oplus/putt/IPuttObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4126
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerPuttObserver(Lcom/oplus/putt/IPuttObserver;)Z

    move-result v2

    .line 4127
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4128
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4129
    goto/16 :goto_1719

    .line 4116
    .end local v1    # "_arg0":Lcom/oplus/putt/IPuttObserver;
    .end local v2    # "_result":Z
    :pswitch_9c5
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getPauseInRecentsAnimPkgList()Ljava/util/List;

    move-result-object v1

    .line 4117
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4118
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 4119
    goto/16 :goto_1719

    .line 4109
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_9d1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4110
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4111
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->pauseInRecentsAnim(I)V

    .line 4112
    goto/16 :goto_1719

    .line 4099
    .end local v1    # "_arg0":I
    :pswitch_9dd
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 4101
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4102
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4103
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyUiSwitched(Ljava/lang/String;I)V

    .line 4104
    goto/16 :goto_1719

    .line 4087
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_9ed
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 4089
    .restart local v1    # "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/ComponentName;

    .line 4090
    .local v2, "_arg1":Landroid/content/ComponentName;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4091
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z

    move-result v3

    .line 4092
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4093
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4094
    goto/16 :goto_1719

    .line 4070
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/content/ComponentName;
    .end local v3    # "_result":Z
    :pswitch_a08
    sget-object v1, Landroid/view/WindowManager$LayoutParams;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager$LayoutParams;

    .line 4072
    .local v1, "_arg0":Landroid/view/WindowManager$LayoutParams;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 4074
    .local v2, "_arg1":I
    sget-object v3, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Rect;

    .line 4076
    .local v3, "_arg2":Landroid/graphics/Rect;
    sget-object v4, Landroid/graphics/Rect;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Rect;

    .line 4077
    .local v4, "_arg3":Landroid/graphics/Rect;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4078
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 4079
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4080
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4081
    invoke-virtual {v9, v4, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4082
    goto/16 :goto_1719

    .line 4062
    .end local v1    # "_arg0":Landroid/view/WindowManager$LayoutParams;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/graphics/Rect;
    .end local v4    # "_arg3":Landroid/graphics/Rect;
    :pswitch_a35
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 4063
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4064
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setInputConsumerEnabled(Z)V

    .line 4065
    goto/16 :goto_1719

    .line 4052
    .end local v1    # "_arg0":Z
    :pswitch_a41
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 4053
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4054
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getRenderThreadTid(I)I

    move-result v2

    .line 4055
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4056
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 4057
    goto/16 :goto_1719

    .line 4044
    .end local v1    # "_arg0":I
    .end local v2    # "_result":I
    :pswitch_a54
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getZoomTaskController()Lcom/oplus/zoomwindow/IOplusZoomTaskController;

    move-result-object v1

    .line 4045
    .local v1, "_result":Lcom/oplus/zoomwindow/IOplusZoomTaskController;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4046
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V

    .line 4047
    goto/16 :goto_1719

    .line 4033
    .end local v1    # "_result":Lcom/oplus/zoomwindow/IOplusZoomTaskController;
    :pswitch_a60
    sget-object v1, Landroid/window/WindowContainerToken;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/window/WindowContainerToken;

    .line 4035
    .local v1, "_arg0":Landroid/window/WindowContainerToken;
    sget-object v2, Landroid/view/SurfaceControl;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/SurfaceControl;

    .line 4036
    .local v2, "_arg1":Landroid/view/SurfaceControl;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4037
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->takeScreenshot(Landroid/window/WindowContainerToken;Landroid/view/SurfaceControl;)Landroid/view/SurfaceControl;

    move-result-object v3

    .line 4038
    .local v3, "_result":Landroid/view/SurfaceControl;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4039
    invoke-virtual {v9, v3, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 4040
    goto/16 :goto_1719

    .line 4025
    .end local v1    # "_arg0":Landroid/window/WindowContainerToken;
    .end local v2    # "_arg1":Landroid/view/SurfaceControl;
    .end local v3    # "_result":Landroid/view/SurfaceControl;
    :pswitch_a7f
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getMultiSearchSession()Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;

    move-result-object v1

    .line 4026
    .local v1, "_result":Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4027
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V

    .line 4028
    goto/16 :goto_1719

    .line 4014
    .end local v1    # "_result":Lcom/oplus/multisearch/IOplusMultiSearchManagerSession;
    :pswitch_a8b
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 4016
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 4017
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4018
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->shouldInterceptBackKeyForMultiSearch(Landroid/os/IBinder;Z)Z

    move-result v3

    .line 4019
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4020
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4021
    goto/16 :goto_1719

    .line 4002
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Z
    :pswitch_aa2
    sget-object v1, Landroid/app/PendingIntent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/PendingIntent;

    .line 4004
    .local v1, "_arg0":Landroid/app/PendingIntent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 4005
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 4006
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->sendMessage(Landroid/app/PendingIntent;Ljava/lang/String;)Z

    move-result v3

    .line 4007
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 4008
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 4009
    goto/16 :goto_1719

    .line 3995
    .end local v1    # "_arg0":Landroid/app/PendingIntent;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_abd
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->unbindQuickReplyService()V

    .line 3996
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3997
    goto/16 :goto_1719

    .line 3987
    :pswitch_ac5
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/quickreply/IQuickReplyCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/quickreply/IQuickReplyCallback;

    move-result-object v1

    .line 3988
    .local v1, "_arg0":Lcom/oplus/quickreply/IQuickReplyCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3989
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->bindQuickReplyService(Lcom/oplus/quickreply/IQuickReplyCallback;)V

    .line 3990
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3991
    goto/16 :goto_1719

    .line 3977
    .end local v1    # "_arg0":Lcom/oplus/quickreply/IQuickReplyCallback;
    :pswitch_ad8
    sget-object v1, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/ComponentName;

    .line 3978
    .local v1, "_arg0":Landroid/content/ComponentName;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3979
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->isNeedDisableWindowLayoutInfo(Landroid/content/ComponentName;)Z

    move-result v2

    .line 3980
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3981
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3982
    goto/16 :goto_1719

    .line 3967
    .end local v1    # "_arg0":Landroid/content/ComponentName;
    .end local v2    # "_result":Z
    :pswitch_aef
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/bracket/IOplusBracketModeChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/bracket/IOplusBracketModeChangedListener;

    move-result-object v1

    .line 3968
    .local v1, "_arg0":Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3969
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->removeBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v2

    .line 3970
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3971
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3972
    goto/16 :goto_1719

    .line 3957
    .end local v1    # "_arg0":Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .end local v2    # "_result":Z
    :pswitch_b06
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/bracket/IOplusBracketModeChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/bracket/IOplusBracketModeChangedListener;

    move-result-object v1

    .line 3958
    .restart local v1    # "_arg0":Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3959
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->addBracketWindowConfigChangedListener(Lcom/oplus/bracket/IOplusBracketModeChangedListener;)Z

    move-result v2

    .line 3960
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3961
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3962
    goto/16 :goto_1719

    .line 3941
    .end local v1    # "_arg0":Lcom/oplus/bracket/IOplusBracketModeChangedListener;
    .end local v2    # "_result":Z
    :pswitch_b1d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3943
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3945
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 3947
    .local v3, "_arg2":Ljava/lang/String;
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 3948
    .local v4, "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3949
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->invokeSync(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v5

    .line 3950
    .local v5, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3951
    invoke-virtual {v9, v5, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3952
    goto/16 :goto_1719

    .line 3921
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_arg3":Landroid/os/Bundle;
    .end local v5    # "_result":Landroid/os/Bundle;
    :pswitch_b40
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3923
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3925
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 3927
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 3929
    .local v4, "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 3931
    .local v5, "_arg4":Ljava/lang/String;
    sget-object v6, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v6}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/os/Bundle;

    .line 3932
    .local v6, "_arg5":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3933
    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/app/IOplusActivityTaskManager$Stub;->callMethod(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v7

    .line 3934
    .local v7, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3935
    invoke-virtual {v9, v7, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3936
    goto/16 :goto_1719

    .line 3913
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Z
    .end local v5    # "_arg4":Ljava/lang/String;
    .end local v6    # "_arg5":Landroid/os/Bundle;
    .end local v7    # "_result":Landroid/os/Bundle;
    :pswitch_b6c
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getRealSize()Landroid/graphics/Point;

    move-result-object v1

    .line 3914
    .local v1, "_result":Landroid/graphics/Point;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3915
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3916
    goto/16 :goto_1719

    .line 3904
    .end local v1    # "_result":Landroid/graphics/Point;
    :pswitch_b78
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 3905
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3906
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getFocusComponent(Z)Landroid/content/ComponentName;

    move-result-object v2

    .line 3907
    .local v2, "_result":Landroid/content/ComponentName;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3908
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3909
    goto/16 :goto_1719

    .line 3894
    .end local v1    # "_arg0":Z
    .end local v2    # "_result":Landroid/content/ComponentName;
    :pswitch_b8b
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 3895
    .restart local v1    # "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3896
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getFocusBounds(Z)Landroid/graphics/Rect;

    move-result-object v2

    .line 3897
    .local v2, "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3898
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3899
    goto/16 :goto_1719

    .line 3886
    .end local v1    # "_arg0":Z
    .end local v2    # "_result":Landroid/graphics/Rect;
    :pswitch_b9e
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getFocusMode()I

    move-result v1

    .line 3887
    .local v1, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3888
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 3889
    goto/16 :goto_1719

    .line 3877
    .end local v1    # "_result":I
    :pswitch_baa
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3878
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3879
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->onProtocolUpdated(Ljava/lang/String;)Z

    move-result v2

    .line 3880
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3881
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3882
    goto/16 :goto_1719

    .line 3869
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_bbd
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getPWAppInfo()Ljava/util/Map;

    move-result-object v1

    .line 3870
    .local v1, "_result":Ljava/util/Map;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3871
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeMap(Ljava/util/Map;)V

    .line 3872
    goto/16 :goto_1719

    .line 3860
    .end local v1    # "_result":Ljava/util/Map;
    :pswitch_bc9
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/compactwindow/IOplusCompactWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/compactwindow/IOplusCompactWindowObserver;

    move-result-object v1

    .line 3861
    .local v1, "_arg0":Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3862
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v2

    .line 3863
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3864
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3865
    goto/16 :goto_1719

    .line 3850
    .end local v1    # "_arg0":Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_be0
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/compactwindow/IOplusCompactWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/compactwindow/IOplusCompactWindowObserver;

    move-result-object v1

    .line 3851
    .restart local v1    # "_arg0":Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3852
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerCompactWindowObserver(Lcom/oplus/compactwindow/IOplusCompactWindowObserver;)Z

    move-result v2

    .line 3853
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3854
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3855
    goto/16 :goto_1719

    .line 3842
    .end local v1    # "_arg0":Lcom/oplus/compactwindow/IOplusCompactWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_bf7
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->moveCompactWindowToRight()I

    move-result v1

    .line 3843
    .local v1, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3844
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 3845
    goto/16 :goto_1719

    .line 3835
    .end local v1    # "_result":I
    :pswitch_c03
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->moveCompactWindowToLeft()I

    move-result v1

    .line 3836
    .restart local v1    # "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3837
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 3838
    goto/16 :goto_1719

    .line 3828
    .end local v1    # "_result":I
    :pswitch_c0f
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isCurrentAppSupportCompactMode()Z

    move-result v1

    .line 3829
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3830
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3831
    goto/16 :goto_1719

    .line 3821
    .end local v1    # "_result":Z
    :pswitch_c1b
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->exitCompactWindow()I

    move-result v1

    .line 3822
    .local v1, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3823
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 3824
    goto/16 :goto_1719

    .line 3814
    .end local v1    # "_result":I
    :pswitch_c27
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->startCompactWindow()I

    move-result v1

    .line 3815
    .restart local v1    # "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3816
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 3817
    goto/16 :goto_1719

    .line 3803
    .end local v1    # "_result":I
    :pswitch_c33
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3805
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 3806
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3807
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->lockRotationInGame(I[Ljava/lang/String;)Z

    move-result v3

    .line 3808
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3809
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3810
    goto/16 :goto_1719

    .line 3791
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":[Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_c4a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3793
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3794
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3795
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->getAppThemeVersion(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    .line 3796
    .local v3, "_result":Ljava/lang/String;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3797
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 3798
    goto/16 :goto_1719

    .line 3781
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Ljava/lang/String;
    :pswitch_c61
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3783
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3784
    .restart local v2    # "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3785
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateUntrustedTouchConfig(Ljava/lang/String;Z)V

    .line 3786
    goto/16 :goto_1719

    .line 3770
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Z
    :pswitch_c71
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 3772
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3773
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3774
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->clientTransactionComplete(Landroid/os/IBinder;I)V

    .line 3775
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3776
    goto/16 :goto_1719

    .line 3760
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    :pswitch_c84
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/os/IOplusTouchNodeCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/os/IOplusTouchNodeCallback;

    move-result-object v1

    .line 3761
    .local v1, "_arg0":Lcom/oplus/os/IOplusTouchNodeCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3762
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z

    move-result v2

    .line 3763
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3764
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3765
    goto/16 :goto_1719

    .line 3750
    .end local v1    # "_arg0":Lcom/oplus/os/IOplusTouchNodeCallback;
    .end local v2    # "_result":Z
    :pswitch_c9b
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/os/IOplusTouchNodeCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/os/IOplusTouchNodeCallback;

    move-result-object v1

    .line 3751
    .restart local v1    # "_arg0":Lcom/oplus/os/IOplusTouchNodeCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3752
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerEventCallback(Lcom/oplus/os/IOplusTouchNodeCallback;)Z

    move-result v2

    .line 3753
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3754
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3755
    goto/16 :goto_1719

    .line 3730
    .end local v1    # "_arg0":Lcom/oplus/os/IOplusTouchNodeCallback;
    .end local v2    # "_result":Z
    :pswitch_cb2
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3732
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    .line 3734
    .local v2, "_arg1":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 3736
    .local v4, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 3738
    .local v5, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v6

    .line 3740
    .local v6, "_arg4":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    .line 3741
    .local v7, "_arg5":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3742
    move-object v0, p0

    invoke-virtual/range {v0 .. v7}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyTouchNodeChange(IJIIILjava/lang/String;)Z

    move-result v12

    .line 3743
    .local v12, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3744
    invoke-virtual {v9, v12}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3745
    goto/16 :goto_1719

    .line 3717
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":J
    .end local v4    # "_arg2":I
    .end local v5    # "_arg3":I
    .end local v6    # "_arg4":I
    .end local v7    # "_arg5":Ljava/lang/String;
    .end local v12    # "_result":Z
    :pswitch_cda
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3719
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3721
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 3722
    .local v3, "_arg2":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3723
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->writeNodeFileOneWay(IILjava/lang/String;)V

    .line 3724
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3725
    goto/16 :goto_1719

    .line 3703
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/lang/String;
    :pswitch_cf1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3705
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3707
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 3708
    .restart local v3    # "_arg2":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3709
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->writeNodeFileFromBt(IILjava/lang/String;)Z

    move-result v4

    .line 3710
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3711
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3712
    goto/16 :goto_1719

    .line 3691
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_result":Z
    :pswitch_d0c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3693
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3694
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3695
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->isTouchNodeSupport(II)Z

    move-result v3

    .line 3696
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3697
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3698
    goto/16 :goto_1719

    .line 3677
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_d23
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3679
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3681
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 3682
    .local v3, "_arg2":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3683
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->writeNodeFileByDevice(IILjava/lang/String;)Z

    move-result v4

    .line 3684
    .restart local v4    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3685
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3686
    goto/16 :goto_1719

    .line 3665
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_result":Z
    :pswitch_d3e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3667
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3668
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3669
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->writeNodeFile(ILjava/lang/String;)Z

    move-result v3

    .line 3670
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3671
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3672
    goto/16 :goto_1719

    .line 3653
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_d55
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3655
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3656
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3657
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->readNodeFileByDevice(II)Ljava/lang/String;

    move-result-object v3

    .line 3658
    .local v3, "_result":Ljava/lang/String;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3659
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 3660
    goto/16 :goto_1719

    .line 3643
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Ljava/lang/String;
    :pswitch_d6c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3644
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3645
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->readNodeFile(I)Ljava/lang/String;

    move-result-object v2

    .line 3646
    .local v2, "_result":Ljava/lang/String;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3647
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 3648
    goto/16 :goto_1719

    .line 3633
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/lang/String;
    :pswitch_d7f
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/confinemode/IOplusConfineModeObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/confinemode/IOplusConfineModeObserver;

    move-result-object v1

    .line 3634
    .local v1, "_arg0":Lcom/oplus/confinemode/IOplusConfineModeObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3635
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v2

    .line 3636
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3637
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3638
    goto/16 :goto_1719

    .line 3623
    .end local v1    # "_arg0":Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .end local v2    # "_result":Z
    :pswitch_d96
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/confinemode/IOplusConfineModeObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/confinemode/IOplusConfineModeObserver;

    move-result-object v1

    .line 3624
    .restart local v1    # "_arg0":Lcom/oplus/confinemode/IOplusConfineModeObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3625
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerConfineModeObserver(Lcom/oplus/confinemode/IOplusConfineModeObserver;)Z

    move-result v2

    .line 3626
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3627
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3628
    goto/16 :goto_1719

    .line 3611
    .end local v1    # "_arg0":Lcom/oplus/confinemode/IOplusConfineModeObserver;
    .end local v2    # "_result":Z
    :pswitch_dad
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3613
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3614
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3615
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->rebindDisplayIfNeeded(II)Z

    move-result v3

    .line 3616
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3617
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3618
    goto/16 :goto_1719

    .line 3601
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_dc4
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3602
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3603
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->updateCarModeMultiLaunchWhiteList(Ljava/lang/String;)Z

    move-result v2

    .line 3604
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3605
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3606
    goto/16 :goto_1719

    .line 3588
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_dd7
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3590
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3592
    .local v2, "_arg1":I
    sget-object v3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/Bundle;

    .line 3593
    .local v3, "_arg2":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3594
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->feedbackUserSelection(IILandroid/os/Bundle;)V

    .line 3595
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3596
    goto/16 :goto_1719

    .line 3578
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/Bundle;
    :pswitch_df2
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3579
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3580
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getGetDisplayIdForPackageName(Ljava/lang/String;)I

    move-result v2

    .line 3581
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3582
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 3583
    goto/16 :goto_1719

    .line 3568
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":I
    :pswitch_e05
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/miragewindow/IOplusMirageSessionCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/miragewindow/IOplusMirageSessionCallback;

    move-result-object v1

    .line 3569
    .local v1, "_arg0":Lcom/oplus/miragewindow/IOplusMirageSessionCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3570
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->createMirageWindowSession(Lcom/oplus/miragewindow/IOplusMirageSessionCallback;)Lcom/oplus/miragewindow/IOplusMirageWindowSession;

    move-result-object v2

    .line 3571
    .local v2, "_result":Lcom/oplus/miragewindow/IOplusMirageWindowSession;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3572
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V

    .line 3573
    goto/16 :goto_1719

    .line 3552
    .end local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageSessionCallback;
    .end local v2    # "_result":Lcom/oplus/miragewindow/IOplusMirageWindowSession;
    :pswitch_e1c
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3554
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3556
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 3558
    .local v3, "_arg2":Z
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 3559
    .local v4, "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3560
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->updatePrivacyProtectionListWithBundle(Ljava/util/List;ZZLandroid/os/Bundle;)Z

    move-result v5

    .line 3561
    .local v5, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3562
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3563
    goto/16 :goto_1719

    .line 3540
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Z
    .end local v4    # "_arg3":Landroid/os/Bundle;
    .end local v5    # "_result":Z
    :pswitch_e3f
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3542
    .restart local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3543
    .restart local v2    # "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3544
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updatePrivacyProtectionList(Ljava/util/List;Z)Z

    move-result v3

    .line 3545
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3546
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3547
    goto/16 :goto_1719

    .line 3528
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Z
    :pswitch_e56
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3530
    .local v1, "_arg0":I
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 3531
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3532
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateMirageWindowCastFlag(ILandroid/os/Bundle;)Z

    move-result v3

    .line 3533
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3534
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3535
    goto/16 :goto_1719

    .line 3520
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":Z
    :pswitch_e71
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getMirageWindowInfo()Lcom/oplus/miragewindow/OplusMirageWindowInfo;

    move-result-object v1

    .line 3521
    .local v1, "_result":Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3522
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3523
    goto/16 :goto_1719

    .line 3513
    .end local v1    # "_result":Lcom/oplus/miragewindow/OplusMirageWindowInfo;
    :pswitch_e7d
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isSupportMirageWindowMode()Z

    move-result v1

    .line 3514
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3515
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3516
    goto/16 :goto_1719

    .line 3505
    .end local v1    # "_result":Z
    :pswitch_e89
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3506
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3507
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setMirageWindowSilent(Ljava/lang/String;)V

    .line 3508
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3509
    goto/16 :goto_1719

    .line 3498
    .end local v1    # "_arg0":Ljava/lang/String;
    :pswitch_e98
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->expandToFullScreen()V

    .line 3499
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3500
    goto/16 :goto_1719

    .line 3489
    :pswitch_ea0
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3490
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3491
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getMirageDisplayCastMode(I)I

    move-result v2

    .line 3492
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3493
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 3494
    goto/16 :goto_1719

    .line 3478
    .end local v1    # "_arg0":I
    .end local v2    # "_result":I
    :pswitch_eb3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3480
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/view/Surface;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/Surface;

    .line 3481
    .local v2, "_arg1":Landroid/view/Surface;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3482
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setMirageDisplaySurfaceByMode(ILandroid/view/Surface;)V

    .line 3483
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3484
    goto/16 :goto_1719

    .line 3467
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/view/Surface;
    :pswitch_eca
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3469
    .restart local v1    # "_arg0":I
    sget-object v2, Landroid/view/Surface;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/Surface;

    .line 3470
    .restart local v2    # "_arg1":Landroid/view/Surface;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3471
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setMirageDisplaySurfaceById(ILandroid/view/Surface;)V

    .line 3472
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3473
    goto/16 :goto_1719

    .line 3458
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Landroid/view/Surface;
    :pswitch_ee1
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 3459
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3460
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->stopMirageWindowMode(Landroid/os/Bundle;)V

    .line 3461
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3462
    goto/16 :goto_1719

    .line 3451
    .end local v1    # "_arg0":Landroid/os/Bundle;
    :pswitch_ef4
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->stopMirageWindowModeOld()V

    .line 3452
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3453
    goto/16 :goto_1719

    .line 3444
    :pswitch_efc
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isMirageWindowShow()Z

    move-result v1

    .line 3445
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3446
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3447
    goto/16 :goto_1719

    .line 3433
    .end local v1    # "_result":Z
    :pswitch_f08
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 3435
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 3436
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3437
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startMirageWindowMode(Landroid/content/Intent;Landroid/os/Bundle;)I

    move-result v3

    .line 3438
    .local v3, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3439
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 3440
    goto/16 :goto_1719

    .line 3418
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":I
    :pswitch_f27
    sget-object v1, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/ComponentName;

    .line 3420
    .local v1, "_arg0":Landroid/content/ComponentName;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3422
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 3424
    .local v3, "_arg2":I
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 3425
    .restart local v4    # "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3426
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->startMirageWindowModeWithName(Landroid/content/ComponentName;IILandroid/os/Bundle;)V

    .line 3427
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3428
    goto/16 :goto_1719

    .line 3408
    .end local v1    # "_arg0":Landroid/content/ComponentName;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Landroid/os/Bundle;
    :pswitch_f4a
    sget-object v1, Landroid/content/ComponentName;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/ComponentName;

    .line 3409
    .restart local v1    # "_arg0":Landroid/content/ComponentName;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3410
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getTaskInfo(Landroid/content/ComponentName;)Landroid/os/Bundle;

    move-result-object v2

    .line 3411
    .local v2, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3412
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3413
    goto/16 :goto_1719

    .line 3398
    .end local v1    # "_arg0":Landroid/content/ComponentName;
    .end local v2    # "_result":Landroid/os/Bundle;
    :pswitch_f61
    sget-object v1, Landroid/view/Surface;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/Surface;

    .line 3399
    .local v1, "_arg0":Landroid/view/Surface;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3400
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->createMirageDisplay(Landroid/view/Surface;)I

    move-result v2

    .line 3401
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3402
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 3403
    goto/16 :goto_1719

    .line 3388
    .end local v1    # "_arg0":Landroid/view/Surface;
    .end local v2    # "_result":I
    :pswitch_f78
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/miragewindow/IOplusMirageDisplayObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;

    move-result-object v1

    .line 3389
    .local v1, "_arg0":Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3390
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v2

    .line 3391
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3392
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3393
    goto/16 :goto_1719

    .line 3378
    .end local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .end local v2    # "_result":Z
    :pswitch_f8f
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/miragewindow/IOplusMirageDisplayObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;

    move-result-object v1

    .line 3379
    .restart local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3380
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerMirageDisplayObserver(Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;)Z

    move-result v2

    .line 3381
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3382
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3383
    goto/16 :goto_1719

    .line 3368
    .end local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageDisplayObserver;
    .end local v2    # "_result":Z
    :pswitch_fa6
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/miragewindow/IOplusMirageWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/miragewindow/IOplusMirageWindowObserver;

    move-result-object v1

    .line 3369
    .local v1, "_arg0":Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3370
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v2

    .line 3371
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3372
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3373
    goto/16 :goto_1719

    .line 3358
    .end local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_fbd
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/miragewindow/IOplusMirageWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/miragewindow/IOplusMirageWindowObserver;

    move-result-object v1

    .line 3359
    .restart local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3360
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerMirageWindowObserver(Lcom/oplus/miragewindow/IOplusMirageWindowObserver;)Z

    move-result v2

    .line 3361
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3362
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3363
    goto/16 :goto_1719

    .line 3349
    .end local v1    # "_arg0":Lcom/oplus/miragewindow/IOplusMirageWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_fd4
    sget-object v1, Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;

    .line 3350
    .local v1, "_arg0":Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3351
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setGlobalDragAndDropConfig(Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;)V

    .line 3352
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3353
    goto/16 :goto_1719

    .line 3341
    .end local v1    # "_arg0":Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    :pswitch_fe7
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getGlobalDragAndDropConfig()Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;

    move-result-object v1

    .line 3342
    .local v1, "_result":Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3343
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3344
    goto/16 :goto_1719

    .line 3332
    .end local v1    # "_result":Lcom/oplus/globaldrag/OplusGlobalDragAndDropRUSConfig;
    :pswitch_ff3
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3333
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3334
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterKeyEventInterceptor(Ljava/lang/String;)Z

    move-result v2

    .line 3335
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3336
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3337
    goto/16 :goto_1719

    .line 3317
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_1006
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3319
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Landroid/os/IOplusKeyEventObserver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/IOplusKeyEventObserver;

    move-result-object v2

    .line 3321
    .local v2, "_arg1":Landroid/os/IOplusKeyEventObserver;
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v3

    .line 3322
    .local v3, "cl":Ljava/lang/ClassLoader;
    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readHashMap(Ljava/lang/ClassLoader;)Ljava/util/HashMap;

    move-result-object v4

    .line 3323
    .local v4, "_arg2":Ljava/util/Map;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3324
    invoke-virtual {p0, v1, v2, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->registerKeyEventInterceptor(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;Ljava/util/Map;)Z

    move-result v5

    .line 3325
    .restart local v5    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3326
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3327
    goto/16 :goto_1719

    .line 3309
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/IOplusKeyEventObserver;
    .end local v3    # "cl":Ljava/lang/ClassLoader;
    .end local v4    # "_arg2":Ljava/util/Map;
    .end local v5    # "_result":Z
    :pswitch_102d
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->hasColorSplitFeature()Z

    move-result v1

    .line 3310
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3311
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3312
    goto/16 :goto_1719

    .line 3302
    .end local v1    # "_result":Z
    :pswitch_1039
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getLeftRightBoundsForIme()Landroid/os/Bundle;

    move-result-object v1

    .line 3303
    .local v1, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3304
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3305
    goto/16 :goto_1719

    .line 3291
    .end local v1    # "_result":Landroid/os/Bundle;
    :pswitch_1045
    sget-object v1, Landroid/app/PendingIntent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/PendingIntent;

    .line 3293
    .local v1, "_arg0":Landroid/app/PendingIntent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3294
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3295
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->splitScreenForApplication(Landroid/app/PendingIntent;I)Z

    move-result v3

    .line 3296
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3297
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3298
    goto/16 :goto_1719

    .line 3283
    .end local v1    # "_arg0":Landroid/app/PendingIntent;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_1060
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getSplitScreenSession()Lcom/oplus/splitscreen/IOplusSplitScreenSession;

    move-result-object v1

    .line 3284
    .local v1, "_result":Lcom/oplus/splitscreen/IOplusSplitScreenSession;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3285
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V

    .line 3286
    goto/16 :goto_1719

    .line 3274
    .end local v1    # "_result":Lcom/oplus/splitscreen/IOplusSplitScreenSession;
    :pswitch_106c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3275
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3276
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getMinimizedBounds(I)Landroid/graphics/Rect;

    move-result-object v2

    .line 3277
    .local v2, "_result":Landroid/graphics/Rect;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3278
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3279
    goto/16 :goto_1719

    .line 3266
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Landroid/graphics/Rect;
    :pswitch_107f
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isFolderInnerScreen()Z

    move-result v1

    .line 3267
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3268
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3269
    goto/16 :goto_1719

    .line 3259
    .end local v1    # "_result":Z
    :pswitch_108b
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->hasLargeScreenFeature()Z

    move-result v1

    .line 3260
    .restart local v1    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3261
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3262
    goto/16 :goto_1719

    .line 3246
    .end local v1    # "_result":Z
    :pswitch_1097
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 3248
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3250
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 3251
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3252
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->splitScreenForEdgePanelExt(Landroid/content/Intent;ZI)Z

    move-result v4

    .line 3253
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3254
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3255
    goto/16 :goto_1719

    .line 3236
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_10b6
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3237
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3238
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setTaskWindowingModeSplitScreen(I)I

    move-result v2

    .line 3239
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3240
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 3241
    goto/16 :goto_1719

    .line 3226
    .end local v1    # "_arg0":I
    .end local v2    # "_result":I
    :pswitch_10c9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3227
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3228
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->splitScreenForRecentTasks(I)Z

    move-result v2

    .line 3229
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3230
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3231
    goto/16 :goto_1719

    .line 3216
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_10dc
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3217
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3218
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->splitScreenForTopApp(I)Z

    move-result v2

    .line 3219
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3220
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3221
    goto/16 :goto_1719

    .line 3206
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_10ef
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3207
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3208
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getSplitScreenStatus(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    .line 3209
    .local v2, "_result":Landroid/os/Bundle;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3210
    invoke-virtual {v9, v2, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3211
    goto/16 :goto_1719

    .line 3194
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Landroid/os/Bundle;
    :pswitch_1102
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3196
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/app/IOplusSplitScreenObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusSplitScreenObserver;

    move-result-object v2

    .line 3197
    .local v2, "_arg1":Lcom/oplus/app/IOplusSplitScreenObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3198
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v3

    .line 3199
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3200
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3201
    goto/16 :goto_1719

    .line 3182
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Lcom/oplus/app/IOplusSplitScreenObserver;
    .end local v3    # "_result":Z
    :pswitch_111d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3184
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/app/IOplusSplitScreenObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusSplitScreenObserver;

    move-result-object v2

    .line 3185
    .restart local v2    # "_arg1":Lcom/oplus/app/IOplusSplitScreenObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3186
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerSplitScreenObserver(ILcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v3

    .line 3187
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3188
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3189
    goto/16 :goto_1719

    .line 3172
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Lcom/oplus/app/IOplusSplitScreenObserver;
    .end local v3    # "_result":Z
    :pswitch_1138
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3173
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3174
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->dismissSplitScreenMode(I)Z

    move-result v2

    .line 3175
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3176
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3177
    goto/16 :goto_1719

    .line 3164
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_114b
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isInSplitScreenMode()Z

    move-result v1

    .line 3165
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3166
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3167
    goto/16 :goto_1719

    .line 3155
    .end local v1    # "_result":Z
    :pswitch_1157
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusSplitScreenObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusSplitScreenObserver;

    move-result-object v1

    .line 3156
    .local v1, "_arg0":Lcom/oplus/app/IOplusSplitScreenObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3157
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setSplitScreenObserver(Lcom/oplus/app/IOplusSplitScreenObserver;)Z

    move-result v2

    .line 3158
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3159
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3160
    goto/16 :goto_1719

    .line 3142
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusSplitScreenObserver;
    .end local v2    # "_result":Z
    :pswitch_116e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3144
    .local v1, "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 3146
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 3147
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3148
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->notifySplitScreenStateChanged(Ljava/lang/String;Landroid/os/Bundle;Z)V

    .line 3149
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3150
    goto/16 :goto_1719

    .line 3132
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Z
    :pswitch_1189
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/lockscreen/IOplusLockScreenCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/lockscreen/IOplusLockScreenCallback;

    move-result-object v1

    .line 3133
    .local v1, "_arg0":Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3134
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v2

    .line 3135
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3136
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3137
    goto/16 :goto_1719

    .line 3122
    .end local v1    # "_arg0":Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .end local v2    # "_result":Z
    :pswitch_11a0
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/lockscreen/IOplusLockScreenCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/lockscreen/IOplusLockScreenCallback;

    move-result-object v1

    .line 3123
    .restart local v1    # "_arg0":Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3124
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerLockScreenCallback(Lcom/oplus/lockscreen/IOplusLockScreenCallback;)Z

    move-result v2

    .line 3125
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3126
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3127
    goto/16 :goto_1719

    .line 3114
    .end local v1    # "_arg0":Lcom/oplus/lockscreen/IOplusLockScreenCallback;
    .end local v2    # "_result":Z
    :pswitch_11b7
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getPackagesState()Ljava/util/Map;

    move-result-object v1

    .line 3115
    .local v1, "_result":Ljava/util/Map;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3116
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeMap(Ljava/util/Map;)V

    .line 3117
    goto/16 :goto_1719

    .line 3105
    .end local v1    # "_result":Ljava/util/Map;
    :pswitch_11c3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    .line 3106
    .local v1, "cl":Ljava/lang/ClassLoader;
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readHashMap(Ljava/lang/ClassLoader;)Ljava/util/HashMap;

    move-result-object v2

    .line 3107
    .local v2, "_arg0":Ljava/util/Map;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3108
    invoke-virtual {p0, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setPackagesState(Ljava/util/Map;)V

    .line 3109
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3110
    goto/16 :goto_1719

    .line 3096
    .end local v1    # "cl":Ljava/lang/ClassLoader;
    .end local v2    # "_arg0":Ljava/util/Map;
    :pswitch_11da
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3097
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3098
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setGimbalLaunchPkg(Ljava/lang/String;)V

    .line 3099
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3100
    goto/16 :goto_1719

    .line 3084
    .end local v1    # "_arg0":Ljava/lang/String;
    :pswitch_11e9
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3086
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/datasync/ISysStateChangeCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/datasync/ISysStateChangeCallback;

    move-result-object v2

    .line 3087
    .local v2, "_arg1":Lcom/oplus/datasync/ISysStateChangeCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3088
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v3

    .line 3089
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3090
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3091
    goto/16 :goto_1719

    .line 3072
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/datasync/ISysStateChangeCallback;
    .end local v3    # "_result":Z
    :pswitch_1204
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3074
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/datasync/ISysStateChangeCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/datasync/ISysStateChangeCallback;

    move-result-object v2

    .line 3075
    .restart local v2    # "_arg1":Lcom/oplus/datasync/ISysStateChangeCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3076
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerSysStateChangeObserver(Ljava/lang/String;Lcom/oplus/datasync/ISysStateChangeCallback;)Z

    move-result v3

    .line 3077
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3078
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3079
    goto/16 :goto_1719

    .line 3060
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/datasync/ISysStateChangeCallback;
    .end local v3    # "_result":Z
    :pswitch_121f
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3062
    .restart local v1    # "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 3063
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3064
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateAppData(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v3

    .line 3065
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3066
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3067
    goto/16 :goto_1719

    .line 3048
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":Z
    :pswitch_123a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3050
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 3051
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3052
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unRegisterRegionScreenshot(Ljava/lang/String;Z)Z

    move-result v3

    .line 3053
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3054
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3055
    goto/16 :goto_1719

    .line 3036
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Z
    :pswitch_1251
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3038
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Landroid/os/ILongPressScreenshotCallback$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/ILongPressScreenshotCallback;

    move-result-object v2

    .line 3039
    .local v2, "_arg1":Landroid/os/ILongPressScreenshotCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3040
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerRegionScreenshot(Ljava/lang/String;Landroid/os/ILongPressScreenshotCallback;)Z

    move-result v3

    .line 3041
    .restart local v3    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3042
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3043
    goto/16 :goto_1719

    .line 3028
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/ILongPressScreenshotCallback;
    .end local v3    # "_result":Z
    :pswitch_126c
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getLastEvent()Ljava/util/List;

    move-result-object v1

    .line 3029
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Point;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3030
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 3031
    goto/16 :goto_1719

    .line 3021
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/graphics/Point;>;"
    :pswitch_1278
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->releaseScreenshotRegion()Z

    move-result v1

    .line 3022
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3023
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3024
    goto/16 :goto_1719

    .line 3013
    .end local v1    # "_result":Z
    :pswitch_1284
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 3014
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3015
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setRegionScreenshot(Z)V

    .line 3016
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3017
    goto/16 :goto_1719

    .line 3005
    .end local v1    # "_arg0":Z
    :pswitch_1293
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isPowerKeyPressed()Z

    move-result v1

    .line 3006
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3007
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3008
    goto/16 :goto_1719

    .line 2996
    .end local v1    # "_result":Z
    :pswitch_129f
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2997
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2998
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterKeyEventObserver(Ljava/lang/String;)Z

    move-result v2

    .line 2999
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 3000
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3001
    goto/16 :goto_1719

    .line 2982
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_12b2
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2984
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Landroid/os/IOplusKeyEventObserver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/IOplusKeyEventObserver;

    move-result-object v2

    .line 2986
    .local v2, "_arg1":Landroid/os/IOplusKeyEventObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2987
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2988
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->registerKeyEventObserver(Ljava/lang/String;Landroid/os/IOplusKeyEventObserver;I)Z

    move-result v4

    .line 2989
    .restart local v4    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2990
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2991
    goto/16 :goto_1719

    .line 2967
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/IOplusKeyEventObserver;
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_12d1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2969
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2971
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v3

    .line 2973
    .local v3, "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 2974
    .local v4, "_arg3":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2975
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->setPermitList(IILjava/util/List;Z)V

    .line 2976
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2977
    goto/16 :goto_1719

    .line 2959
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v4    # "_arg3":Z
    :pswitch_12ec
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getConfineMode()I

    move-result v1

    .line 2960
    .local v1, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2961
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 2962
    goto/16 :goto_1719

    .line 2947
    .end local v1    # "_result":I
    :pswitch_12f8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2949
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2951
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    .line 2952
    .local v3, "_arg2":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2953
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->setConfineMode(IZLandroid/os/IBinder;)V

    .line 2954
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2955
    goto/16 :goto_1719

    .line 2935
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Landroid/os/IBinder;
    :pswitch_130f
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 2937
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2938
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2939
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->splitScreenForEdgePanel(Landroid/content/Intent;I)I

    move-result v3

    .line 2940
    .local v3, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2941
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 2942
    goto/16 :goto_1719

    .line 2915
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":I
    :pswitch_132a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2918
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2919
    .local v2, "N":I
    if-gez v2, :cond_1336

    const/4 v3, 0x0

    goto :goto_133b

    :cond_1336
    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    .line 2920
    .local v3, "_arg1":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    :goto_133b
    const/4 v4, 0x0

    invoke-static {v4, v2}, Ljava/util/stream/IntStream;->range(II)Ljava/util/stream/IntStream;

    move-result-object v4

    new-instance v5, Landroid/app/IOplusActivityTaskManager$Stub$$ExternalSyntheticLambda0;

    invoke-direct {v5, p2, v3}, Landroid/app/IOplusActivityTaskManager$Stub$$ExternalSyntheticLambda0;-><init>(Landroid/os/Parcel;Ljava/util/Map;)V

    invoke-interface {v4, v5}, Ljava/util/stream/IntStream;->forEach(Ljava/util/function/IntConsumer;)V

    .line 2927
    .end local v2    # "N":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2928
    invoke-virtual {p0, v1, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->setEdgeTouchCallRules(Ljava/lang/String;Ljava/util/Map;)V

    .line 2929
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2930
    goto/16 :goto_1719

    .line 2907
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v3    # "_arg1":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    :pswitch_1353
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isSupportEdgeTouchPrevent()Z

    move-result v1

    .line 2908
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2909
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2910
    goto/16 :goto_1719

    .line 2898
    .end local v1    # "_result":Z
    :pswitch_135f
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2899
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2900
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->resetDefaultEdgeTouchPreventParam(Ljava/lang/String;)Z

    move-result v2

    .line 2901
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2902
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2903
    goto/16 :goto_1719

    .line 2887
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_1372
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2889
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v2

    .line 2890
    .local v2, "_arg1":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2891
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->setDefaultEdgeTouchPreventParam(Ljava/lang/String;Ljava/util/List;)V

    .line 2892
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2893
    goto/16 :goto_1719

    .line 2873
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_1385
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2875
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2877
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v3

    .line 2878
    .local v3, "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2879
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->writeEdgeTouchPreventParam(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Z

    move-result v4

    .line 2880
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2881
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2882
    goto/16 :goto_1719

    .line 2865
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v4    # "_result":Z
    :pswitch_13a0
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isZoomSimpleModeEnable()Z

    move-result v1

    .line 2866
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2867
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2868
    goto/16 :goto_1719

    .line 2857
    .end local v1    # "_result":Z
    :pswitch_13ac
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v1

    .line 2858
    .local v1, "_arg0":[Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2859
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->replaceLockTaskPackages([Ljava/lang/String;)V

    .line 2860
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2861
    goto/16 :goto_1719

    .line 2844
    .end local v1    # "_arg0":[Ljava/lang/String;
    :pswitch_13bb
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2846
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 2848
    .local v2, "_arg1":[Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2849
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2850
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->startLockDeviceModeWithFlag(Ljava/lang/String;[Ljava/lang/String;I)V

    .line 2851
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2852
    goto/16 :goto_1719

    .line 2836
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":[Ljava/lang/String;
    .end local v3    # "_arg2":I
    :pswitch_13d2
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isLockDeviceMode()Z

    move-result v1

    .line 2837
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2838
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2839
    goto/16 :goto_1719

    .line 2830
    .end local v1    # "_result":Z
    :pswitch_13de
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->stopLockDeviceMode()V

    .line 2831
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2832
    goto/16 :goto_1719

    .line 2820
    :pswitch_13e6
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2822
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v2

    .line 2823
    .restart local v2    # "_arg1":[Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2824
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->startLockDeviceMode(Ljava/lang/String;[Ljava/lang/String;)V

    .line 2825
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2826
    goto/16 :goto_1719

    .line 2810
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":[Ljava/lang/String;
    :pswitch_13f9
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusZoomWindowConfigChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;

    move-result-object v1

    .line 2811
    .local v1, "_arg0":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2812
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v2

    .line 2813
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2814
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2815
    goto/16 :goto_1719

    .line 2800
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .end local v2    # "_result":Z
    :pswitch_1410
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusZoomWindowConfigChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;

    move-result-object v1

    .line 2801
    .restart local v1    # "_arg0":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2802
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v2

    .line 2803
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2804
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2805
    goto/16 :goto_1719

    .line 2791
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .end local v2    # "_result":Z
    :pswitch_1427
    sget-object v1, Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    .line 2792
    .local v1, "_arg0":Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2793
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V

    .line 2794
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2795
    goto/16 :goto_1719

    .line 2783
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    :pswitch_143a
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    move-result-object v1

    .line 2784
    .local v1, "_result":Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2785
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2786
    goto/16 :goto_1719

    .line 2776
    .end local v1    # "_result":Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    :pswitch_1446
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isSupportZoomWindowMode()Z

    move-result v1

    .line 2777
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2778
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2779
    goto/16 :goto_1719

    .line 2768
    .end local v1    # "_result":Z
    :pswitch_1452
    sget-object v1, Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;

    .line 2769
    .local v1, "_arg0":Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2770
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V

    .line 2771
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2772
    goto/16 :goto_1719

    .line 2758
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;
    :pswitch_1465
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 2760
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2761
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2762
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->updateDeferStartingWindowApps(Ljava/util/List;Z)V

    .line 2763
    goto/16 :goto_1719

    .line 2750
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_arg1":Z
    :pswitch_1475
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getSecurityFlagCurrentPage()Z

    move-result v1

    .line 2751
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2752
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2753
    goto/16 :goto_1719

    .line 2741
    .end local v1    # "_result":Z
    :pswitch_1481
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/ISecurityPageController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/ISecurityPageController;

    move-result-object v1

    .line 2742
    .local v1, "_arg0":Lcom/oplus/app/ISecurityPageController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2743
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v2

    .line 2744
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2745
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2746
    goto/16 :goto_1719

    .line 2731
    .end local v1    # "_arg0":Lcom/oplus/app/ISecurityPageController;
    .end local v2    # "_result":Z
    :pswitch_1498
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/ISecurityPageController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/ISecurityPageController;

    move-result-object v1

    .line 2732
    .restart local v1    # "_arg0":Lcom/oplus/app/ISecurityPageController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2733
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerSecurityPageCallback(Lcom/oplus/app/ISecurityPageController;)Z

    move-result v2

    .line 2734
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2735
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2736
    goto/16 :goto_1719

    .line 2721
    .end local v1    # "_arg0":Lcom/oplus/app/ISecurityPageController;
    .end local v2    # "_result":Z
    :pswitch_14af
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomAppObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomAppObserver;

    move-result-object v1

    .line 2722
    .local v1, "_arg0":Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2723
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v2

    .line 2724
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2725
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2726
    goto/16 :goto_1719

    .line 2711
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .end local v2    # "_result":Z
    :pswitch_14c6
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomAppObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomAppObserver;

    move-result-object v1

    .line 2712
    .restart local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2713
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v2

    .line 2714
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2715
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2716
    goto/16 :goto_1719

    .line 2702
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomAppObserver;
    .end local v2    # "_result":Z
    :pswitch_14dd
    sget-object v1, Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;

    .line 2703
    .local v1, "_arg0":Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2704
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V

    .line 2705
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2706
    goto/16 :goto_1719

    .line 2693
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;
    :pswitch_14f0
    sget-object v1, Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;

    .line 2694
    .local v1, "_arg0":Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2695
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V

    .line 2696
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2697
    goto/16 :goto_1719

    .line 2682
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;
    :pswitch_1503
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2684
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2685
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2686
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->notifyZoomStateChange(Ljava/lang/String;I)V

    .line 2687
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2688
    goto/16 :goto_1719

    .line 2673
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_1516
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2674
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2675
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->startMiniZoomFromZoom(I)V

    .line 2676
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2677
    goto/16 :goto_1719

    .line 2655
    .end local v1    # "_arg0":I
    :pswitch_1525
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2657
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2659
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 2661
    .local v3, "_arg2":Ljava/lang/String;
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 2663
    .local v4, "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 2664
    .local v5, "_arg4":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2665
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityTaskManager$Stub;->handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z

    move-result v6

    .line 2666
    .local v6, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2667
    invoke-virtual {v9, v6}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2668
    goto/16 :goto_1719

    .line 2639
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_arg3":Landroid/os/Bundle;
    .end local v5    # "_arg4":I
    .end local v6    # "_result":Z
    :pswitch_154d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2641
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2643
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 2645
    .restart local v3    # "_arg2":Ljava/lang/String;
    sget-object v4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v4}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    .line 2646
    .restart local v4    # "_arg3":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2647
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result v5

    .line 2648
    .local v5, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2649
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2650
    goto/16 :goto_1719

    .line 2629
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Ljava/lang/String;
    .end local v4    # "_arg3":Landroid/os/Bundle;
    .end local v5    # "_result":Z
    :pswitch_1570
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2630
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2631
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getZoomAppConfigList(I)Ljava/util/List;

    move-result-object v2

    .line 2632
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2633
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2634
    goto/16 :goto_1719

    .line 2620
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_1583
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2621
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2622
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->hideZoomWindow(I)V

    .line 2623
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2624
    goto/16 :goto_1719

    .line 2612
    .end local v1    # "_arg0":I
    :pswitch_1592
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;

    move-result-object v1

    .line 2613
    .local v1, "_result":Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2614
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2615
    goto/16 :goto_1719

    .line 2603
    .end local v1    # "_result":Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    :pswitch_159e
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;

    move-result-object v1

    .line 2604
    .local v1, "_arg0":Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2605
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v2

    .line 2606
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2607
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2608
    goto/16 :goto_1719

    .line 2593
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_15b5
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/zoomwindow/IOplusZoomWindowObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;

    move-result-object v1

    .line 2594
    .restart local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2595
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v2

    .line 2596
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2597
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2598
    goto/16 :goto_1719

    .line 2577
    .end local v1    # "_arg0":Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;
    .end local v2    # "_result":Z
    :pswitch_15cc
    sget-object v1, Landroid/app/PendingIntent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/PendingIntent;

    .line 2579
    .local v1, "_arg0":Landroid/app/PendingIntent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 2581
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2583
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 2584
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2585
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v5

    .line 2586
    .local v5, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2587
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeInt(I)V

    .line 2588
    goto/16 :goto_1719

    .line 2561
    .end local v1    # "_arg0":Landroid/app/PendingIntent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_result":I
    :pswitch_15f3
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 2563
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 2565
    .restart local v2    # "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2567
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 2568
    .restart local v4    # "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2569
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityTaskManager$Stub;->startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v5

    .line 2570
    .restart local v5    # "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2571
    invoke-virtual {v9, v5}, Landroid/os/Parcel;->writeInt(I)V

    .line 2572
    goto/16 :goto_1719

    .line 2550
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_result":I
    :pswitch_161a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2552
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/globaldrag/IDragAndDropListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/globaldrag/IDragAndDropListener;

    move-result-object v2

    .line 2553
    .local v2, "_arg1":Lcom/oplus/globaldrag/IDragAndDropListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2554
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V

    .line 2555
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2556
    goto/16 :goto_1719

    .line 2539
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/globaldrag/IDragAndDropListener;
    :pswitch_1631
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2541
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/globaldrag/IDragAndDropListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/globaldrag/IDragAndDropListener;

    move-result-object v2

    .line 2542
    .restart local v2    # "_arg1":Lcom/oplus/globaldrag/IDragAndDropListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2543
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->registerDragAndDropListener(Ljava/lang/String;Lcom/oplus/globaldrag/IDragAndDropListener;)V

    .line 2544
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2545
    goto/16 :goto_1719

    .line 2527
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/globaldrag/IDragAndDropListener;
    :pswitch_1648
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2529
    .restart local v1    # "_arg0":Ljava/lang/String;
    sget-object v2, Lcom/oplus/app/OplusAppSwitchConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/oplus/app/OplusAppSwitchConfig;

    .line 2530
    .local v2, "_arg1":Lcom/oplus/app/OplusAppSwitchConfig;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2531
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityTaskManager$Stub;->unregisterAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v3

    .line 2532
    .local v3, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2533
    invoke-virtual {v9, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2534
    goto/16 :goto_1719

    .line 2513
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/app/OplusAppSwitchConfig;
    .end local v3    # "_result":Z
    :pswitch_1663
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2515
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/app/IOplusAppSwitchObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusAppSwitchObserver;

    move-result-object v2

    .line 2517
    .local v2, "_arg1":Lcom/oplus/app/IOplusAppSwitchObserver;
    sget-object v3, Lcom/oplus/app/OplusAppSwitchConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/oplus/app/OplusAppSwitchConfig;

    .line 2518
    .local v3, "_arg2":Lcom/oplus/app/OplusAppSwitchConfig;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2519
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityTaskManager$Stub;->registerAppSwitchObserver(Ljava/lang/String;Lcom/oplus/app/IOplusAppSwitchObserver;Lcom/oplus/app/OplusAppSwitchConfig;)Z

    move-result v4

    .line 2520
    .local v4, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2521
    invoke-virtual {v9, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2522
    goto/16 :goto_1719

    .line 2503
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/app/IOplusAppSwitchObserver;
    .end local v3    # "_arg2":Lcom/oplus/app/OplusAppSwitchConfig;
    .end local v4    # "_result":Z
    :pswitch_1686
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusFreeformConfigChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    move-result-object v1

    .line 2504
    .local v1, "_arg0":Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2505
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->removeFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z

    move-result v2

    .line 2506
    .local v2, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2507
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2508
    goto/16 :goto_1719

    .line 2493
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    .end local v2    # "_result":Z
    :pswitch_169d
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusFreeformConfigChangedListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusFreeformConfigChangedListener;

    move-result-object v1

    .line 2494
    .restart local v1    # "_arg0":Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2495
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->addFreeformConfigChangedListener(Lcom/oplus/app/IOplusFreeformConfigChangedListener;)Z

    move-result v2

    .line 2496
    .restart local v2    # "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2497
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2498
    goto :goto_1719

    .line 2485
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusFreeformConfigChangedListener;
    .end local v2    # "_result":Z
    :pswitch_16b3
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->isFreeformEnabled()Z

    move-result v1

    .line 2486
    .local v1, "_result":Z
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2487
    invoke-virtual {v9, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2488
    goto :goto_1719

    .line 2476
    .end local v1    # "_result":Z
    :pswitch_16be
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2477
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2478
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getFreeformConfigList(I)Ljava/util/List;

    move-result-object v2

    .line 2479
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2480
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2481
    goto :goto_1719

    .line 2468
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_16d0
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getAllTopAppInfos()Ljava/util/List;

    move-result-object v1

    .line 2469
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/app/OplusAppInfo;>;"
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2470
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2471
    goto :goto_1719

    .line 2459
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/app/OplusAppInfo;>;"
    :pswitch_16db
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 2460
    .local v1, "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2461
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->getSplitScreenState(Landroid/content/Intent;)I

    move-result v2

    .line 2462
    .local v2, "_result":I
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2463
    invoke-virtual {v9, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 2464
    goto :goto_1719

    .line 2451
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_result":I
    :pswitch_16f1
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getTopApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    .line 2452
    .local v1, "_result":Landroid/content/pm/ApplicationInfo;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2453
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2454
    goto :goto_1719

    .line 2444
    .end local v1    # "_result":Landroid/content/pm/ApplicationInfo;
    :pswitch_16fc
    invoke-virtual {p0}, Landroid/app/IOplusActivityTaskManager$Stub;->getTopActivityComponentName()Landroid/content/ComponentName;

    move-result-object v1

    .line 2445
    .local v1, "_result":Landroid/content/ComponentName;
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2446
    invoke-virtual {v9, v1, v11}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2447
    goto :goto_1719

    .line 2436
    .end local v1    # "_result":Landroid/content/ComponentName;
    :pswitch_1707
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/app/IActivityController$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IActivityController;

    move-result-object v1

    .line 2437
    .local v1, "_arg0":Landroid/app/IActivityController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2438
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityTaskManager$Stub;->setSecureController(Landroid/app/IActivityController;)V

    .line 2439
    invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V

    .line 2440
    nop

    .line 5300
    .end local v1    # "_arg0":Landroid/app/IActivityController;
    :goto_1719
    return v11

    :pswitch_data_171a
    .packed-switch 0x1
        :pswitch_1707
        :pswitch_16fc
        :pswitch_16f1
        :pswitch_16db
        :pswitch_16d0
        :pswitch_16be
        :pswitch_16b3
        :pswitch_169d
        :pswitch_1686
        :pswitch_1663
        :pswitch_1648
        :pswitch_1631
        :pswitch_161a
        :pswitch_15f3
        :pswitch_15cc
        :pswitch_15b5
        :pswitch_159e
        :pswitch_1592
        :pswitch_1583
        :pswitch_1570
        :pswitch_154d
        :pswitch_1525
        :pswitch_1516
        :pswitch_1503
        :pswitch_14f0
        :pswitch_14dd
        :pswitch_14c6
        :pswitch_14af
        :pswitch_1498
        :pswitch_1481
        :pswitch_1475
        :pswitch_1465
        :pswitch_1452
        :pswitch_1446
        :pswitch_143a
        :pswitch_1427
        :pswitch_1410
        :pswitch_13f9
        :pswitch_13e6
        :pswitch_13de
        :pswitch_13d2
        :pswitch_13bb
        :pswitch_13ac
        :pswitch_13a0
        :pswitch_1385
        :pswitch_1372
        :pswitch_135f
        :pswitch_1353
        :pswitch_132a
        :pswitch_130f
        :pswitch_12f8
        :pswitch_12ec
        :pswitch_12d1
        :pswitch_12b2
        :pswitch_129f
        :pswitch_1293
        :pswitch_1284
        :pswitch_1278
        :pswitch_126c
        :pswitch_1251
        :pswitch_123a
        :pswitch_121f
        :pswitch_1204
        :pswitch_11e9
        :pswitch_11da
        :pswitch_11c3
        :pswitch_11b7
        :pswitch_11a0
        :pswitch_1189
        :pswitch_116e
        :pswitch_1157
        :pswitch_114b
        :pswitch_1138
        :pswitch_111d
        :pswitch_1102
        :pswitch_10ef
        :pswitch_10dc
        :pswitch_10c9
        :pswitch_10b6
        :pswitch_1097
        :pswitch_108b
        :pswitch_107f
        :pswitch_106c
        :pswitch_1060
        :pswitch_1045
        :pswitch_1039
        :pswitch_102d
        :pswitch_1006
        :pswitch_ff3
        :pswitch_fe7
        :pswitch_fd4
        :pswitch_fbd
        :pswitch_fa6
        :pswitch_f8f
        :pswitch_f78
        :pswitch_f61
        :pswitch_f4a
        :pswitch_f27
        :pswitch_f08
        :pswitch_efc
        :pswitch_ef4
        :pswitch_ee1
        :pswitch_eca
        :pswitch_eb3
        :pswitch_ea0
        :pswitch_e98
        :pswitch_e89
        :pswitch_e7d
        :pswitch_e71
        :pswitch_e56
        :pswitch_e3f
        :pswitch_e1c
        :pswitch_e05
        :pswitch_df2
        :pswitch_dd7
        :pswitch_dc4
        :pswitch_dad
        :pswitch_d96
        :pswitch_d7f
        :pswitch_d6c
        :pswitch_d55
        :pswitch_d3e
        :pswitch_d23
        :pswitch_d0c
        :pswitch_cf1
        :pswitch_cda
        :pswitch_cb2
        :pswitch_c9b
        :pswitch_c84
        :pswitch_c71
        :pswitch_c61
        :pswitch_c4a
        :pswitch_c33
        :pswitch_c27
        :pswitch_c1b
        :pswitch_c0f
        :pswitch_c03
        :pswitch_bf7
        :pswitch_be0
        :pswitch_bc9
        :pswitch_bbd
        :pswitch_baa
        :pswitch_b9e
        :pswitch_b8b
        :pswitch_b78
        :pswitch_b6c
        :pswitch_b40
        :pswitch_b1d
        :pswitch_b06
        :pswitch_aef
        :pswitch_ad8
        :pswitch_ac5
        :pswitch_abd
        :pswitch_aa2
        :pswitch_a8b
        :pswitch_a7f
        :pswitch_a60
        :pswitch_a54
        :pswitch_a41
        :pswitch_a35
        :pswitch_a08
        :pswitch_9ed
        :pswitch_9dd
        :pswitch_9d1
        :pswitch_9c5
        :pswitch_9ae
        :pswitch_997
        :pswitch_980
        :pswitch_969
        :pswitch_94a
        :pswitch_933
        :pswitch_927
        :pswitch_90c
        :pswitch_8e4
        :pswitch_8c9
        :pswitch_8b2
        :pswitch_893
        :pswitch_872
        :pswitch_857
        :pswitch_838
        :pswitch_825
        :pswitch_812
        :pswitch_7ff
        :pswitch_7ec
        :pswitch_7d9
        :pswitch_7c5
        :pswitch_7b6
        :pswitch_7a3
        :pswitch_794
        :pswitch_77d
        :pswitch_766
        :pswitch_743
        :pswitch_730
        :pswitch_721
        :pswitch_70e
        :pswitch_6f3
        :pswitch_6e0
        :pswitch_6cd
        :pswitch_6b6
        :pswitch_693
        :pswitch_674
        :pswitch_659
        :pswitch_63e
        :pswitch_61d
        :pswitch_5f7
        :pswitch_5e4
        :pswitch_5c1
        :pswitch_5a6
        :pswitch_57f
        :pswitch_557
        :pswitch_544
        :pswitch_534
        :pswitch_51c
        :pswitch_508
        :pswitch_4f4
        :pswitch_4e8
        :pswitch_4d1
        :pswitch_4a4
        :pswitch_490
        :pswitch_480
        :pswitch_460
        :pswitch_432
        :pswitch_404
        :pswitch_3ed
        :pswitch_3de
        :pswitch_3c7
        :pswitch_3b4
        :pswitch_39d
        :pswitch_382
        :pswitch_36f
        :pswitch_354
        :pswitch_33d
        :pswitch_331
        :pswitch_325
        :pswitch_30a
        :pswitch_2f3
        :pswitch_2dc
        :pswitch_2c9
        :pswitch_2aa
        :pswitch_293
        :pswitch_274
        :pswitch_25d
        :pswitch_231
        :pswitch_21e
        :pswitch_1ff
        :pswitch_1e8
        :pswitch_1d1
        :pswitch_1b6
        :pswitch_19f
        :pswitch_188
        :pswitch_171
        :pswitch_15e
        :pswitch_14b
        :pswitch_11b
        :pswitch_108
        :pswitch_f5
        :pswitch_e2
        :pswitch_cf
        :pswitch_bc
        :pswitch_a9
        :pswitch_92
        :pswitch_6b
        :pswitch_58
        :pswitch_45
        :pswitch_21
    .end packed-switch
.end method
