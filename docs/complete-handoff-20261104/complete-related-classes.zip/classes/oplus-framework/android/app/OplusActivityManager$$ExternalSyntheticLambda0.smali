.class public final synthetic Landroid/app/OplusActivityManager$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic blacklist f$0:Landroid/app/OplusActivityManager;


# direct methods
.method public synthetic constructor blacklist <init>(Landroid/app/OplusActivityManager;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/app/OplusActivityManager$$ExternalSyntheticLambda0;->f$0:Landroid/app/OplusActivityManager;

    return-void
.end method


# virtual methods
.method public final whitelist test-api apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Landroid/app/OplusActivityManager$$ExternalSyntheticLambda0;->f$0:Landroid/app/OplusActivityManager;

    check-cast p1, Lcom/oplus/wrapper/app/IProcessObserver;

    invoke-static {v0, p1}, Landroid/app/OplusActivityManager;->$r8$lambda$FhW38koaD_m3YwPTV2FklwgKERw(Landroid/app/OplusActivityManager;Lcom/oplus/wrapper/app/IProcessObserver;)Landroid/app/IProcessObserver;

    move-result-object p1

    return-object p1
.end method
