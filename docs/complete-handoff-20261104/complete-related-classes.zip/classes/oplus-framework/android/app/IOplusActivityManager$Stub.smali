.class public abstract Landroid/app/IOplusActivityManager$Stub;
.super Landroid/os/Binder;
.source "IOplusActivityManager.java"

# interfaces
.implements Landroid/app/IOplusActivityManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/IOplusActivityManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/app/IOplusActivityManager$Stub$Proxy;
    }
.end annotation


# static fields
.field static final blacklist TRANSACTION_activeGc:I = 0x3f

.field static final blacklist TRANSACTION_addBackgroundRestrictedInfo:I = 0x27

.field static final blacklist TRANSACTION_addFastAppThirdLogin:I = 0x25

.field static final blacklist TRANSACTION_addFastAppWCPay:I = 0x21

.field static final blacklist TRANSACTION_addMiniProgramShare:I = 0x1d

.field static final blacklist TRANSACTION_addOplusLoopLoadTime:I = 0x7e

.field static final blacklist TRANSACTION_addOrRemoveOplusVerifyCodeListener:I = 0x69

.field static final blacklist TRANSACTION_addPreventIndulgeList:I = 0x29

.field static final blacklist TRANSACTION_addStageProtectInfo:I = 0x16

.field static final blacklist TRANSACTION_anrViaTheiaEvent:I = 0x5e

.field static final blacklist TRANSACTION_asyncReportDalvikMem:I = 0x79

.field static final blacklist TRANSACTION_asyncReportFrames:I = 0x6d

.field static final blacklist TRANSACTION_autoLayoutCall:I = 0x7f

.field static final blacklist TRANSACTION_cleanPackageResources:I = 0x6a

.field static final blacklist TRANSACTION_clearApplicationUserData:I = 0x88

.field static final blacklist TRANSACTION_clearFastStartConfig:I = 0x94

.field static final blacklist TRANSACTION_compactProcess:I = 0x62

.field static final blacklist TRANSACTION_dumpProcPerfData:I = 0x33

.field static final blacklist TRANSACTION_enterFastFreezer:I = 0x51

.field static final blacklist TRANSACTION_enterFastStart:I = 0x95

.field static final blacklist TRANSACTION_executeResPreload:I = 0x4b

.field static final blacklist TRANSACTION_exitFastFreezer:I = 0x52

.field static final blacklist TRANSACTION_exitFastStart:I = 0x97

.field static final blacklist TRANSACTION_favoriteQueryRule:I = 0x9

.field static final blacklist TRANSACTION_finishFlexibleActivityOnTouchOutside:I = 0x82

.field static final blacklist TRANSACTION_finishNotOrderReceiver:I = 0x40

.field static final blacklist TRANSACTION_forceStopPackageAndSaveActivity:I = 0x6b

.field static final blacklist TRANSACTION_forceTrimAppMemory:I = 0x2e

.field static final blacklist TRANSACTION_gameBgPureModeSwitch:I = 0x98

.field static final blacklist TRANSACTION_getAccidentallyTouchData:I = 0xa

.field static final blacklist TRANSACTION_getAllDarkModeData:I = 0x31

.field static final blacklist TRANSACTION_getAllVisibleTasksInfo:I = 0x5d

.field static final blacklist TRANSACTION_getCompatModeSession:I = 0x71

.field static final blacklist TRANSACTION_getConfigInfo:I = 0x2b

.field static final blacklist TRANSACTION_getCpuLimitLatestLogs:I = 0x3d

.field static final blacklist TRANSACTION_getCpuWorkingStats:I = 0x2d

.field static final blacklist TRANSACTION_getCurrentUser:I = 0x89

.field static final blacklist TRANSACTION_getDarkModeData:I = 0x30

.field static final blacklist TRANSACTION_getDisplayCompatData:I = 0x1c

.field static final blacklist TRANSACTION_getDisplayOptimizationData:I = 0x18

.field static final blacklist TRANSACTION_getDownloadingList:I = 0x64

.field static final blacklist TRANSACTION_getFastAppReplacePkg:I = 0x7c

.field static final blacklist TRANSACTION_getFontVariationAdaptionData:I = 0x46

.field static final blacklist TRANSACTION_getGlobalPkgWhiteList:I = 0x14

.field static final blacklist TRANSACTION_getGlobalProcessWhiteList:I = 0x15

.field static final blacklist TRANSACTION_getLoopCpuLoad:I = 0x7d

.field static final blacklist TRANSACTION_getNavbarSettingsConfigs:I = 0xa2

.field static final blacklist TRANSACTION_getPackageFreezeDataInfos:I = 0x67

.field static final blacklist TRANSACTION_getPayJoyFlag:I = 0x85

.field static final blacklist TRANSACTION_getPkgPreloadFiles:I = 0x50

.field static final blacklist TRANSACTION_getPreloadIOSize:I = 0x4d

.field static final blacklist TRANSACTION_getPreloadPkgList:I = 0x4f

.field static final blacklist TRANSACTION_getPreloadStatus:I = 0x4e

.field static final blacklist TRANSACTION_getProcCmdline:I = 0x3e

.field static final blacklist TRANSACTION_getProcCommonInfoList:I = 0x34

.field static final blacklist TRANSACTION_getProcDependency:I = 0x35

.field static final blacklist TRANSACTION_getProcDependencyByUserId:I = 0x36

.field static final blacklist TRANSACTION_getProcessMemoryInfo:I = 0x8b

.field static final blacklist TRANSACTION_getReflectData:I = 0x20

.field static final blacklist TRANSACTION_getResPreloadInfo:I = 0x4c

.field static final blacklist TRANSACTION_getResolveData:I = 0x1f

.field static final blacklist TRANSACTION_getRunningAppProcessInfos:I = 0x66

.field static final blacklist TRANSACTION_getRunningAppProcesses:I = 0x8c

.field static final blacklist TRANSACTION_getRunningPidsByUid:I = 0x6c

.field static final blacklist TRANSACTION_getRunningProcesses:I = 0x23

.field static final blacklist TRANSACTION_getRunningServices:I = 0x8e

.field static final blacklist TRANSACTION_getRunningTasks:I = 0x87

.field static final blacklist TRANSACTION_getSecureKeyboardData:I = 0xb

.field static final blacklist TRANSACTION_getStageProtectList:I = 0x5f

.field static final blacklist TRANSACTION_getStageProtectListAsUser:I = 0x60

.field static final blacklist TRANSACTION_getStageProtectListFromPkg:I = 0x19

.field static final blacklist TRANSACTION_getStageProtectListFromPkgAsUser:I = 0x1a

.field static final blacklist TRANSACTION_getStartPermission:I = 0x9d

.field static final blacklist TRANSACTION_getTaskPkgList:I = 0x37

.field static final blacklist TRANSACTION_getTerminateObservers:I = 0x74

.field static final blacklist TRANSACTION_getTopLoadPidsInfos:I = 0x3c

.field static final blacklist TRANSACTION_getTotalCpuLoadPercent:I = 0x3b

.field static final blacklist TRANSACTION_getTrafficBytesList:I = 0x54

.field static final blacklist TRANSACTION_getTrafficPacketList:I = 0x55

.field static final blacklist TRANSACTION_getTsaInfo:I = 0x9c

.field static final blacklist TRANSACTION_getUXIconData:I = 0x61

.field static final blacklist TRANSACTION_getUidCpuWorkingStats:I = 0x3a

.field static final blacklist TRANSACTION_grantOplusPermissionByGroup:I = 0xf

.field static final blacklist TRANSACTION_grantUriPermissionToUser:I = 0x80

.field static final blacklist TRANSACTION_handleAppForNotification:I = 0x12

.field static final blacklist TRANSACTION_handleAppFromControlCenter:I = 0x1b

.field static final blacklist TRANSACTION_hookAfterBindApplicationFinished:I = 0x8

.field static final blacklist TRANSACTION_inDownloading:I = 0x63

.field static final blacklist TRANSACTION_isFrozenByHans:I = 0x53

.field static final blacklist TRANSACTION_isNightMode:I = 0x32

.field static final blacklist TRANSACTION_isPermissionInterceptEnabled:I = 0xe

.field static final blacklist TRANSACTION_isPkgProcessRunning:I = 0xa0

.field static final blacklist TRANSACTION_isUidProcessRunning:I = 0x9f

.field static final blacklist TRANSACTION_killPidForce:I = 0x11

.field static final blacklist TRANSACTION_notifyAppKillReason:I = 0x45

.field static final blacklist TRANSACTION_notifyAthenaOnekeyClearRunning:I = 0x4a

.field static final blacklist TRANSACTION_notifyGameStatus:I = 0x83

.field static final blacklist TRANSACTION_notifyProcessTerminate:I = 0x75

.field static final blacklist TRANSACTION_notifyProcessTerminateFinish:I = 0x76

.field static final blacklist TRANSACTION_notifyUiSwitched:I = 0x68

.field static final blacklist TRANSACTION_onBackPressedOnTheiaMonitor:I = 0x5

.field static final blacklist TRANSACTION_putConfigInfo:I = 0x2a

.field static final blacklist TRANSACTION_putFastStartConfig:I = 0x93

.field static final blacklist TRANSACTION_queryProcessNameFromPid:I = 0x44

.field static final blacklist TRANSACTION_queryUsageStats:I = 0x65

.field static final blacklist TRANSACTION_registerAbConfigCallback:I = 0x59

.field static final blacklist TRANSACTION_registerComplexSceneObserver:I = 0x7a

.field static final blacklist TRANSACTION_registerEapDataCallback:I = 0x56

.field static final blacklist TRANSACTION_registerErrorInfoCallback:I = 0x5b

.field static final blacklist TRANSACTION_registerHansListener:I = 0x47

.field static final blacklist TRANSACTION_registerProcessObserver:I = 0x9e

.field static final blacklist TRANSACTION_registerTerminateObserver:I = 0x72

.field static final blacklist TRANSACTION_registerTerminateStateObserver:I = 0x77

.field static final blacklist TRANSACTION_removeFastAppThirdLogin:I = 0x26

.field static final blacklist TRANSACTION_removeFastAppWCPay:I = 0x22

.field static final blacklist TRANSACTION_removeMiniProgramShare:I = 0x1e

.field static final blacklist TRANSACTION_removeStageProtectInfo:I = 0x17

.field static final blacklist TRANSACTION_removeTask:I = 0x86

.field static final blacklist TRANSACTION_reportBindApplicationFinished:I = 0x7

.field static final blacklist TRANSACTION_reportSkippedFrames:I = 0x41

.field static final blacklist TRANSACTION_reportSkippedFramesActivityName:I = 0x43

.field static final blacklist TRANSACTION_reportSkippedFramesProcName:I = 0x42

.field static final blacklist TRANSACTION_requestDeviceFolded:I = 0x6e

.field static final blacklist TRANSACTION_revokeOplusPermissionByGroup:I = 0x10

.field static final blacklist TRANSACTION_sendFlingTransit:I = 0x6f

.field static final blacklist TRANSACTION_sendTheiaEvent:I = 0x6

.field static final blacklist TRANSACTION_setAppFreeze:I = 0x49

.field static final blacklist TRANSACTION_setAppStartMonitorController:I = 0x24

.field static final blacklist TRANSACTION_setDynamicBlackList:I = 0x96

.field static final blacklist TRANSACTION_setGameBgPureGameScene:I = 0x9a

.field static final blacklist TRANSACTION_setGameBgPureModeBlackList:I = 0x99

.field static final blacklist TRANSACTION_setGameSpaceController:I = 0x13

.field static final blacklist TRANSACTION_setGlThreads:I = 0x4

.field static final blacklist TRANSACTION_setHwuiTaskThreads:I = 0x3

.field static final blacklist TRANSACTION_setPayJoyFlag:I = 0x84

.field static final blacklist TRANSACTION_setPermissionInterceptEnable:I = 0xd

.field static final blacklist TRANSACTION_setPermissionRecordController:I = 0x2f

.field static final blacklist TRANSACTION_setPreventIndulgeController:I = 0x28

.field static final blacklist TRANSACTION_setSceneActionTransit:I = 0x70

.field static final blacklist TRANSACTION_startActivity:I = 0x90

.field static final blacklist TRANSACTION_startActivityAsUser:I = 0x91

.field static final blacklist TRANSACTION_startProcess:I = 0x92

.field static final blacklist TRANSACTION_startProcessWithFreeze:I = 0xa1

.field static final blacklist TRANSACTION_startUserInBackground:I = 0x8f

.field static final blacklist TRANSACTION_switchUser:I = 0x8d

.field static final blacklist TRANSACTION_syncPermissionRecord:I = 0x38

.field static final blacklist TRANSACTION_trimSystemMemory:I = 0x81

.field static final blacklist TRANSACTION_unfreezeForKernel:I = 0x1

.field static final blacklist TRANSACTION_unfreezeForKernelTargetPid:I = 0x2

.field static final blacklist TRANSACTION_unregisterAbConfigCallback:I = 0x5a

.field static final blacklist TRANSACTION_unregisterComplexSceneObserver:I = 0x7b

.field static final blacklist TRANSACTION_unregisterEapDataCallback:I = 0x57

.field static final blacklist TRANSACTION_unregisterErrorInfoCallback:I = 0x5c

.field static final blacklist TRANSACTION_unregisterHansListener:I = 0x48

.field static final blacklist TRANSACTION_unregisterTerminateObserver:I = 0x73

.field static final blacklist TRANSACTION_unregisterTerminateStateObserver:I = 0x78

.field static final blacklist TRANSACTION_updateANRDumpState:I = 0x58

.field static final blacklist TRANSACTION_updateConfiguration:I = 0x8a

.field static final blacklist TRANSACTION_updateCpuTracker:I = 0x2c

.field static final blacklist TRANSACTION_updatePermissionChoice:I = 0xc

.field static final blacklist TRANSACTION_updateTsaMap:I = 0x9b

.field static final blacklist TRANSACTION_updateUidCpuTracker:I = 0x39


# direct methods
.method public constructor blacklist <init>()V
    .registers 2

    .line 755
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 756
    const-string v0, "android.app.IOplusActivityManager"

    invoke-virtual {p0, p0, v0}, Landroid/app/IOplusActivityManager$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 757
    return-void
.end method

.method public static blacklist asInterface(Landroid/os/IBinder;)Landroid/app/IOplusActivityManager;
    .registers 3
    .param p0, "obj"    # Landroid/os/IBinder;

    .line 764
    if-nez p0, :cond_4

    .line 765
    const/4 v0, 0x0

    return-object v0

    .line 767
    :cond_4
    const-string v0, "android.app.IOplusActivityManager"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 768
    .local v0, "iin":Landroid/os/IInterface;
    if-eqz v0, :cond_14

    instance-of v1, v0, Landroid/app/IOplusActivityManager;

    if-eqz v1, :cond_14

    .line 769
    move-object v1, v0

    check-cast v1, Landroid/app/IOplusActivityManager;

    return-object v1

    .line 771
    :cond_14
    new-instance v1, Landroid/app/IOplusActivityManager$Stub$Proxy;

    invoke-direct {v1, p0}, Landroid/app/IOplusActivityManager$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v1
.end method

.method public static blacklist getDefaultTransactionName(I)Ljava/lang/String;
    .registers 2
    .param p0, "transactionCode"    # I

    .line 780
    packed-switch p0, :pswitch_data_232

    .line 1432
    const/4 v0, 0x0

    return-object v0

    .line 1428
    :pswitch_5
    const-string v0, "getNavbarSettingsConfigs"

    return-object v0

    .line 1424
    :pswitch_8
    const-string/jumbo v0, "startProcessWithFreeze"

    return-object v0

    .line 1420
    :pswitch_c
    const-string v0, "isPkgProcessRunning"

    return-object v0

    .line 1416
    :pswitch_f
    const-string/jumbo v0, "isUidProcessRunning"

    return-object v0

    .line 1412
    :pswitch_13
    const-string/jumbo v0, "registerProcessObserver"

    return-object v0

    .line 1408
    :pswitch_17
    const-string v0, "getStartPermission"

    return-object v0

    .line 1404
    :pswitch_1a
    const-string v0, "getTsaInfo"

    return-object v0

    .line 1400
    :pswitch_1d
    const-string/jumbo v0, "updateTsaMap"

    return-object v0

    .line 1396
    :pswitch_21
    const-string/jumbo v0, "setGameBgPureGameScene"

    return-object v0

    .line 1392
    :pswitch_25
    const-string/jumbo v0, "setGameBgPureModeBlackList"

    return-object v0

    .line 1388
    :pswitch_29
    const-string v0, "gameBgPureModeSwitch"

    return-object v0

    .line 1384
    :pswitch_2c
    const-string v0, "exitFastStart"

    return-object v0

    .line 1380
    :pswitch_2f
    const-string/jumbo v0, "setDynamicBlackList"

    return-object v0

    .line 1376
    :pswitch_33
    const-string v0, "enterFastStart"

    return-object v0

    .line 1372
    :pswitch_36
    const-string v0, "clearFastStartConfig"

    return-object v0

    .line 1368
    :pswitch_39
    const-string/jumbo v0, "putFastStartConfig"

    return-object v0

    .line 1364
    :pswitch_3d
    const-string/jumbo v0, "startProcess"

    return-object v0

    .line 1360
    :pswitch_41
    const-string/jumbo v0, "startActivityAsUser"

    return-object v0

    .line 1356
    :pswitch_45
    const-string/jumbo v0, "startActivity"

    return-object v0

    .line 1352
    :pswitch_49
    const-string/jumbo v0, "startUserInBackground"

    return-object v0

    .line 1348
    :pswitch_4d
    const-string v0, "getRunningServices"

    return-object v0

    .line 1344
    :pswitch_50
    const-string/jumbo v0, "switchUser"

    return-object v0

    .line 1340
    :pswitch_54
    const-string v0, "getRunningAppProcesses"

    return-object v0

    .line 1336
    :pswitch_57
    const-string v0, "getProcessMemoryInfo"

    return-object v0

    .line 1332
    :pswitch_5a
    const-string/jumbo v0, "updateConfiguration"

    return-object v0

    .line 1328
    :pswitch_5e
    const-string v0, "getCurrentUser"

    return-object v0

    .line 1324
    :pswitch_61
    const-string v0, "clearApplicationUserData"

    return-object v0

    .line 1320
    :pswitch_64
    const-string v0, "getRunningTasks"

    return-object v0

    .line 1316
    :pswitch_67
    const-string/jumbo v0, "removeTask"

    return-object v0

    .line 1312
    :pswitch_6b
    const-string v0, "getPayJoyFlag"

    return-object v0

    .line 1308
    :pswitch_6e
    const-string/jumbo v0, "setPayJoyFlag"

    return-object v0

    .line 1304
    :pswitch_72
    const-string/jumbo v0, "notifyGameStatus"

    return-object v0

    .line 1300
    :pswitch_76
    const-string v0, "finishFlexibleActivityOnTouchOutside"

    return-object v0

    .line 1296
    :pswitch_79
    const-string/jumbo v0, "trimSystemMemory"

    return-object v0

    .line 1292
    :pswitch_7d
    const-string v0, "grantUriPermissionToUser"

    return-object v0

    .line 1288
    :pswitch_80
    const-string v0, "autoLayoutCall"

    return-object v0

    .line 1284
    :pswitch_83
    const-string v0, "addOplusLoopLoadTime"

    return-object v0

    .line 1280
    :pswitch_86
    const-string v0, "getLoopCpuLoad"

    return-object v0

    .line 1276
    :pswitch_89
    const-string v0, "getFastAppReplacePkg"

    return-object v0

    .line 1272
    :pswitch_8c
    const-string/jumbo v0, "unregisterComplexSceneObserver"

    return-object v0

    .line 1268
    :pswitch_90
    const-string/jumbo v0, "registerComplexSceneObserver"

    return-object v0

    .line 1264
    :pswitch_94
    const-string v0, "asyncReportDalvikMem"

    return-object v0

    .line 1260
    :pswitch_97
    const-string/jumbo v0, "unregisterTerminateStateObserver"

    return-object v0

    .line 1256
    :pswitch_9b
    const-string/jumbo v0, "registerTerminateStateObserver"

    return-object v0

    .line 1252
    :pswitch_9f
    const-string/jumbo v0, "notifyProcessTerminateFinish"

    return-object v0

    .line 1248
    :pswitch_a3
    const-string/jumbo v0, "notifyProcessTerminate"

    return-object v0

    .line 1244
    :pswitch_a7
    const-string v0, "getTerminateObservers"

    return-object v0

    .line 1240
    :pswitch_aa
    const-string/jumbo v0, "unregisterTerminateObserver"

    return-object v0

    .line 1236
    :pswitch_ae
    const-string/jumbo v0, "registerTerminateObserver"

    return-object v0

    .line 1232
    :pswitch_b2
    const-string v0, "getCompatModeSession"

    return-object v0

    .line 1228
    :pswitch_b5
    const-string/jumbo v0, "setSceneActionTransit"

    return-object v0

    .line 1224
    :pswitch_b9
    const-string/jumbo v0, "sendFlingTransit"

    return-object v0

    .line 1220
    :pswitch_bd
    const-string/jumbo v0, "requestDeviceFolded"

    return-object v0

    .line 1216
    :pswitch_c1
    const-string v0, "asyncReportFrames"

    return-object v0

    .line 1212
    :pswitch_c4
    const-string v0, "getRunningPidsByUid"

    return-object v0

    .line 1208
    :pswitch_c7
    const-string v0, "forceStopPackageAndSaveActivity"

    return-object v0

    .line 1204
    :pswitch_ca
    const-string v0, "cleanPackageResources"

    return-object v0

    .line 1200
    :pswitch_cd
    const-string v0, "addOrRemoveOplusVerifyCodeListener"

    return-object v0

    .line 1196
    :pswitch_d0
    const-string/jumbo v0, "notifyUiSwitched"

    return-object v0

    .line 1192
    :pswitch_d4
    const-string v0, "getPackageFreezeDataInfos"

    return-object v0

    .line 1188
    :pswitch_d7
    const-string v0, "getRunningAppProcessInfos"

    return-object v0

    .line 1184
    :pswitch_da
    const-string/jumbo v0, "queryUsageStats"

    return-object v0

    .line 1180
    :pswitch_de
    const-string v0, "getDownloadingList"

    return-object v0

    .line 1176
    :pswitch_e1
    const-string v0, "inDownloading"

    return-object v0

    .line 1172
    :pswitch_e4
    const-string v0, "compactProcess"

    return-object v0

    .line 1168
    :pswitch_e7
    const-string v0, "getUXIconData"

    return-object v0

    .line 1164
    :pswitch_ea
    const-string v0, "getStageProtectListAsUser"

    return-object v0

    .line 1160
    :pswitch_ed
    const-string v0, "getStageProtectList"

    return-object v0

    .line 1156
    :pswitch_f0
    const-string v0, "anrViaTheiaEvent"

    return-object v0

    .line 1152
    :pswitch_f3
    const-string v0, "getAllVisibleTasksInfo"

    return-object v0

    .line 1148
    :pswitch_f6
    const-string/jumbo v0, "unregisterErrorInfoCallback"

    return-object v0

    .line 1144
    :pswitch_fa
    const-string/jumbo v0, "registerErrorInfoCallback"

    return-object v0

    .line 1140
    :pswitch_fe
    const-string/jumbo v0, "unregisterAbConfigCallback"

    return-object v0

    .line 1136
    :pswitch_102
    const-string/jumbo v0, "registerAbConfigCallback"

    return-object v0

    .line 1132
    :pswitch_106
    const-string/jumbo v0, "updateANRDumpState"

    return-object v0

    .line 1128
    :pswitch_10a
    const-string/jumbo v0, "unregisterEapDataCallback"

    return-object v0

    .line 1124
    :pswitch_10e
    const-string/jumbo v0, "registerEapDataCallback"

    return-object v0

    .line 1120
    :pswitch_112
    const-string v0, "getTrafficPacketList"

    return-object v0

    .line 1116
    :pswitch_115
    const-string v0, "getTrafficBytesList"

    return-object v0

    .line 1112
    :pswitch_118
    const-string v0, "isFrozenByHans"

    return-object v0

    .line 1108
    :pswitch_11b
    const-string v0, "exitFastFreezer"

    return-object v0

    .line 1104
    :pswitch_11e
    const-string v0, "enterFastFreezer"

    return-object v0

    .line 1100
    :pswitch_121
    const-string v0, "getPkgPreloadFiles"

    return-object v0

    .line 1096
    :pswitch_124
    const-string v0, "getPreloadPkgList"

    return-object v0

    .line 1092
    :pswitch_127
    const-string v0, "getPreloadStatus"

    return-object v0

    .line 1088
    :pswitch_12a
    const-string v0, "getPreloadIOSize"

    return-object v0

    .line 1084
    :pswitch_12d
    const-string v0, "getResPreloadInfo"

    return-object v0

    .line 1080
    :pswitch_130
    const-string v0, "executeResPreload"

    return-object v0

    .line 1076
    :pswitch_133
    const-string/jumbo v0, "notifyAthenaOnekeyClearRunning"

    return-object v0

    .line 1072
    :pswitch_137
    const-string/jumbo v0, "setAppFreeze"

    return-object v0

    .line 1068
    :pswitch_13b
    const-string/jumbo v0, "unregisterHansListener"

    return-object v0

    .line 1064
    :pswitch_13f
    const-string/jumbo v0, "registerHansListener"

    return-object v0

    .line 1060
    :pswitch_143
    const-string v0, "getFontVariationAdaptionData"

    return-object v0

    .line 1056
    :pswitch_146
    const-string/jumbo v0, "notifyAppKillReason"

    return-object v0

    .line 1052
    :pswitch_14a
    const-string/jumbo v0, "queryProcessNameFromPid"

    return-object v0

    .line 1048
    :pswitch_14e
    const-string/jumbo v0, "reportSkippedFramesActivityName"

    return-object v0

    .line 1044
    :pswitch_152
    const-string/jumbo v0, "reportSkippedFramesProcName"

    return-object v0

    .line 1040
    :pswitch_156
    const-string/jumbo v0, "reportSkippedFrames"

    return-object v0

    .line 1036
    :pswitch_15a
    const-string v0, "finishNotOrderReceiver"

    return-object v0

    .line 1032
    :pswitch_15d
    const-string v0, "activeGc"

    return-object v0

    .line 1028
    :pswitch_160
    const-string v0, "getProcCmdline"

    return-object v0

    .line 1024
    :pswitch_163
    const-string v0, "getCpuLimitLatestLogs"

    return-object v0

    .line 1020
    :pswitch_166
    const-string v0, "getTopLoadPidsInfos"

    return-object v0

    .line 1016
    :pswitch_169
    const-string v0, "getTotalCpuLoadPercent"

    return-object v0

    .line 1012
    :pswitch_16c
    const-string v0, "getUidCpuWorkingStats"

    return-object v0

    .line 1008
    :pswitch_16f
    const-string/jumbo v0, "updateUidCpuTracker"

    return-object v0

    .line 1004
    :pswitch_173
    const-string/jumbo v0, "syncPermissionRecord"

    return-object v0

    .line 1000
    :pswitch_177
    const-string v0, "getTaskPkgList"

    return-object v0

    .line 996
    :pswitch_17a
    const-string v0, "getProcDependencyByUserId"

    return-object v0

    .line 992
    :pswitch_17d
    const-string v0, "getProcDependency"

    return-object v0

    .line 988
    :pswitch_180
    const-string v0, "getProcCommonInfoList"

    return-object v0

    .line 984
    :pswitch_183
    const-string v0, "dumpProcPerfData"

    return-object v0

    .line 980
    :pswitch_186
    const-string v0, "isNightMode"

    return-object v0

    .line 976
    :pswitch_189
    const-string v0, "getAllDarkModeData"

    return-object v0

    .line 972
    :pswitch_18c
    const-string v0, "getDarkModeData"

    return-object v0

    .line 968
    :pswitch_18f
    const-string/jumbo v0, "setPermissionRecordController"

    return-object v0

    .line 964
    :pswitch_193
    const-string v0, "forceTrimAppMemory"

    return-object v0

    .line 960
    :pswitch_196
    const-string v0, "getCpuWorkingStats"

    return-object v0

    .line 956
    :pswitch_199
    const-string/jumbo v0, "updateCpuTracker"

    return-object v0

    .line 952
    :pswitch_19d
    const-string v0, "getConfigInfo"

    return-object v0

    .line 948
    :pswitch_1a0
    const-string/jumbo v0, "putConfigInfo"

    return-object v0

    .line 944
    :pswitch_1a4
    const-string v0, "addPreventIndulgeList"

    return-object v0

    .line 940
    :pswitch_1a7
    const-string/jumbo v0, "setPreventIndulgeController"

    return-object v0

    .line 936
    :pswitch_1ab
    const-string v0, "addBackgroundRestrictedInfo"

    return-object v0

    .line 932
    :pswitch_1ae
    const-string/jumbo v0, "removeFastAppThirdLogin"

    return-object v0

    .line 928
    :pswitch_1b2
    const-string v0, "addFastAppThirdLogin"

    return-object v0

    .line 924
    :pswitch_1b5
    const-string/jumbo v0, "setAppStartMonitorController"

    return-object v0

    .line 920
    :pswitch_1b9
    const-string v0, "getRunningProcesses"

    return-object v0

    .line 916
    :pswitch_1bc
    const-string/jumbo v0, "removeFastAppWCPay"

    return-object v0

    .line 912
    :pswitch_1c0
    const-string v0, "addFastAppWCPay"

    return-object v0

    .line 908
    :pswitch_1c3
    const-string v0, "getReflectData"

    return-object v0

    .line 904
    :pswitch_1c6
    const-string v0, "getResolveData"

    return-object v0

    .line 900
    :pswitch_1c9
    const-string/jumbo v0, "removeMiniProgramShare"

    return-object v0

    .line 896
    :pswitch_1cd
    const-string v0, "addMiniProgramShare"

    return-object v0

    .line 892
    :pswitch_1d0
    const-string v0, "getDisplayCompatData"

    return-object v0

    .line 888
    :pswitch_1d3
    const-string v0, "handleAppFromControlCenter"

    return-object v0

    .line 884
    :pswitch_1d6
    const-string v0, "getStageProtectListFromPkgAsUser"

    return-object v0

    .line 880
    :pswitch_1d9
    const-string v0, "getStageProtectListFromPkg"

    return-object v0

    .line 876
    :pswitch_1dc
    const-string v0, "getDisplayOptimizationData"

    return-object v0

    .line 872
    :pswitch_1df
    const-string/jumbo v0, "removeStageProtectInfo"

    return-object v0

    .line 868
    :pswitch_1e3
    const-string v0, "addStageProtectInfo"

    return-object v0

    .line 864
    :pswitch_1e6
    const-string v0, "getGlobalProcessWhiteList"

    return-object v0

    .line 860
    :pswitch_1e9
    const-string v0, "getGlobalPkgWhiteList"

    return-object v0

    .line 856
    :pswitch_1ec
    const-string/jumbo v0, "setGameSpaceController"

    return-object v0

    .line 852
    :pswitch_1f0
    const-string v0, "handleAppForNotification"

    return-object v0

    .line 848
    :pswitch_1f3
    const-string/jumbo v0, "killPidForce"

    return-object v0

    .line 844
    :pswitch_1f7
    const-string/jumbo v0, "revokeOplusPermissionByGroup"

    return-object v0

    .line 840
    :pswitch_1fb
    const-string v0, "grantOplusPermissionByGroup"

    return-object v0

    .line 836
    :pswitch_1fe
    const-string v0, "isPermissionInterceptEnabled"

    return-object v0

    .line 832
    :pswitch_201
    const-string/jumbo v0, "setPermissionInterceptEnable"

    return-object v0

    .line 828
    :pswitch_205
    const-string/jumbo v0, "updatePermissionChoice"

    return-object v0

    .line 824
    :pswitch_209
    const-string v0, "getSecureKeyboardData"

    return-object v0

    .line 820
    :pswitch_20c
    const-string v0, "getAccidentallyTouchData"

    return-object v0

    .line 816
    :pswitch_20f
    const-string v0, "favoriteQueryRule"

    return-object v0

    .line 812
    :pswitch_212
    const-string v0, "hookAfterBindApplicationFinished"

    return-object v0

    .line 808
    :pswitch_215
    const-string/jumbo v0, "reportBindApplicationFinished"

    return-object v0

    .line 804
    :pswitch_219
    const-string/jumbo v0, "sendTheiaEvent"

    return-object v0

    .line 800
    :pswitch_21d
    const-string/jumbo v0, "onBackPressedOnTheiaMonitor"

    return-object v0

    .line 796
    :pswitch_221
    const-string/jumbo v0, "setGlThreads"

    return-object v0

    .line 792
    :pswitch_225
    const-string/jumbo v0, "setHwuiTaskThreads"

    return-object v0

    .line 788
    :pswitch_229
    const-string/jumbo v0, "unfreezeForKernelTargetPid"

    return-object v0

    .line 784
    :pswitch_22d
    const-string/jumbo v0, "unfreezeForKernel"

    return-object v0

    nop

    :pswitch_data_232
    .packed-switch 0x1
        :pswitch_22d
        :pswitch_229
        :pswitch_225
        :pswitch_221
        :pswitch_21d
        :pswitch_219
        :pswitch_215
        :pswitch_212
        :pswitch_20f
        :pswitch_20c
        :pswitch_209
        :pswitch_205
        :pswitch_201
        :pswitch_1fe
        :pswitch_1fb
        :pswitch_1f7
        :pswitch_1f3
        :pswitch_1f0
        :pswitch_1ec
        :pswitch_1e9
        :pswitch_1e6
        :pswitch_1e3
        :pswitch_1df
        :pswitch_1dc
        :pswitch_1d9
        :pswitch_1d6
        :pswitch_1d3
        :pswitch_1d0
        :pswitch_1cd
        :pswitch_1c9
        :pswitch_1c6
        :pswitch_1c3
        :pswitch_1c0
        :pswitch_1bc
        :pswitch_1b9
        :pswitch_1b5
        :pswitch_1b2
        :pswitch_1ae
        :pswitch_1ab
        :pswitch_1a7
        :pswitch_1a4
        :pswitch_1a0
        :pswitch_19d
        :pswitch_199
        :pswitch_196
        :pswitch_193
        :pswitch_18f
        :pswitch_18c
        :pswitch_189
        :pswitch_186
        :pswitch_183
        :pswitch_180
        :pswitch_17d
        :pswitch_17a
        :pswitch_177
        :pswitch_173
        :pswitch_16f
        :pswitch_16c
        :pswitch_169
        :pswitch_166
        :pswitch_163
        :pswitch_160
        :pswitch_15d
        :pswitch_15a
        :pswitch_156
        :pswitch_152
        :pswitch_14e
        :pswitch_14a
        :pswitch_146
        :pswitch_143
        :pswitch_13f
        :pswitch_13b
        :pswitch_137
        :pswitch_133
        :pswitch_130
        :pswitch_12d
        :pswitch_12a
        :pswitch_127
        :pswitch_124
        :pswitch_121
        :pswitch_11e
        :pswitch_11b
        :pswitch_118
        :pswitch_115
        :pswitch_112
        :pswitch_10e
        :pswitch_10a
        :pswitch_106
        :pswitch_102
        :pswitch_fe
        :pswitch_fa
        :pswitch_f6
        :pswitch_f3
        :pswitch_f0
        :pswitch_ed
        :pswitch_ea
        :pswitch_e7
        :pswitch_e4
        :pswitch_e1
        :pswitch_de
        :pswitch_da
        :pswitch_d7
        :pswitch_d4
        :pswitch_d0
        :pswitch_cd
        :pswitch_ca
        :pswitch_c7
        :pswitch_c4
        :pswitch_c1
        :pswitch_bd
        :pswitch_b9
        :pswitch_b5
        :pswitch_b2
        :pswitch_ae
        :pswitch_aa
        :pswitch_a7
        :pswitch_a3
        :pswitch_9f
        :pswitch_9b
        :pswitch_97
        :pswitch_94
        :pswitch_90
        :pswitch_8c
        :pswitch_89
        :pswitch_86
        :pswitch_83
        :pswitch_80
        :pswitch_7d
        :pswitch_79
        :pswitch_76
        :pswitch_72
        :pswitch_6e
        :pswitch_6b
        :pswitch_67
        :pswitch_64
        :pswitch_61
        :pswitch_5e
        :pswitch_5a
        :pswitch_57
        :pswitch_54
        :pswitch_50
        :pswitch_4d
        :pswitch_49
        :pswitch_45
        :pswitch_41
        :pswitch_3d
        :pswitch_39
        :pswitch_36
        :pswitch_33
        :pswitch_2f
        :pswitch_2c
        :pswitch_29
        :pswitch_25
        :pswitch_21
        :pswitch_1d
        :pswitch_1a
        :pswitch_17
        :pswitch_13
        :pswitch_f
        :pswitch_c
        :pswitch_8
        :pswitch_5
    .end packed-switch
.end method


# virtual methods
.method public whitelist asBinder()Landroid/os/IBinder;
    .registers 1

    .line 775
    return-object p0
.end method

.method public blacklist getMaxTransactionId()I
    .registers 2

    .line 6292
    const/16 v0, 0xa1

    return v0
.end method

.method public blacklist getTransactionName(I)Ljava/lang/String;
    .registers 3
    .param p1, "transactionCode"    # I

    .line 1439
    invoke-static {p1}, Landroid/app/IOplusActivityManager$Stub;->getDefaultTransactionName(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public whitelist onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 18
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1443
    move-object v9, p2

    move-object/from16 v10, p3

    const-string v11, "android.app.IOplusActivityManager"

    .line 1444
    .local v11, "descriptor":Ljava/lang/String;
    const/4 v12, 0x1

    if-lt p1, v12, :cond_10

    const v1, 0xffffff

    if-gt p1, v1, :cond_10

    .line 1445
    invoke-virtual {p2, v11}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 1447
    :cond_10
    const v1, 0x5f4e5446

    if-ne p1, v1, :cond_19

    .line 1448
    invoke-virtual {v10, v11}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 1449
    return v12

    .line 1451
    :cond_19
    packed-switch p1, :pswitch_data_d22

    .line 3187
    invoke-super/range {p0 .. p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    return v0

    .line 3180
    :pswitch_21
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getNavbarSettingsConfigs()Landroid/os/Bundle;

    move-result-object v1

    .line 3181
    .local v1, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3182
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3183
    goto/16 :goto_d20

    .line 3169
    .end local v1    # "_result":Landroid/os/Bundle;
    :pswitch_2d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3171
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3172
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3173
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->startProcessWithFreeze(Ljava/lang/String;I)Z

    move-result v3

    .line 3174
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3175
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3176
    goto/16 :goto_d20

    .line 3155
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_44
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3157
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3159
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 3160
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3161
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->isPkgProcessRunning(Ljava/lang/String;Ljava/lang/String;I)Z

    move-result v4

    .line 3162
    .local v4, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3163
    invoke-virtual {v10, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3164
    goto/16 :goto_d20

    .line 3143
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Z
    :pswitch_5f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 3145
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3146
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3147
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->isUidProcessRunning(ILjava/lang/String;)Z

    move-result v3

    .line 3148
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3149
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3150
    goto/16 :goto_d20

    .line 3132
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_76
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/app/IProcessObserver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IProcessObserver;

    move-result-object v1

    .line 3134
    .local v1, "_arg0":Landroid/app/IProcessObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3135
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3136
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->registerProcessObserver(Landroid/app/IProcessObserver;I)V

    .line 3137
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3138
    goto/16 :goto_d20

    .line 3122
    .end local v1    # "_arg0":Landroid/app/IProcessObserver;
    .end local v2    # "_arg1":I
    :pswitch_8d
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3123
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3124
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getStartPermission(Ljava/util/List;)Landroid/os/Bundle;

    move-result-object v2

    .line 3125
    .local v2, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3126
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3127
    goto/16 :goto_d20

    .line 3106
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_result":Landroid/os/Bundle;
    :pswitch_a0
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3108
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3110
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    .line 3112
    .local v3, "_arg2":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 3113
    .local v5, "_arg3":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3114
    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/app/IOplusActivityManager$Stub;->getTsaInfo(Ljava/lang/String;IJJ)Landroid/os/Bundle;

    move-result-object v7

    .line 3115
    .local v7, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3116
    invoke-virtual {v10, v7, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 3117
    goto/16 :goto_d20

    .line 3094
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":J
    .end local v5    # "_arg3":J
    .end local v7    # "_result":Landroid/os/Bundle;
    :pswitch_c0
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3096
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3098
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 3099
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3100
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->updateTsaMap(Ljava/lang/String;IZ)V

    .line 3101
    goto/16 :goto_d20

    .line 3082
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Z
    :pswitch_d4
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3084
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 3085
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3086
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->setGameBgPureGameScene(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    .line 3087
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3088
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3089
    goto/16 :goto_d20

    .line 3072
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_result":Z
    :pswitch_eb
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3073
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3074
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setGameBgPureModeBlackList(Ljava/util/List;)Z

    move-result v2

    .line 3075
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3076
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3077
    goto/16 :goto_d20

    .line 3062
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_result":Z
    :pswitch_fe
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 3063
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3064
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->gameBgPureModeSwitch(Z)Z

    move-result v2

    .line 3065
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3066
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3067
    goto/16 :goto_d20

    .line 3052
    .end local v1    # "_arg0":Z
    .end local v2    # "_result":Z
    :pswitch_111
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 3053
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3054
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->exitFastStart(Landroid/os/IBinder;)Z

    move-result v2

    .line 3055
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3056
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3057
    goto/16 :goto_d20

    .line 3042
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_result":Z
    :pswitch_124
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3043
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3044
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setDynamicBlackList(Ljava/util/List;)Z

    move-result v2

    .line 3045
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3046
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3047
    goto/16 :goto_d20

    .line 3028
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_result":Z
    :pswitch_137
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3030
    .restart local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3032
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    .line 3033
    .local v3, "_arg2":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3034
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->enterFastStart(Ljava/util/List;ILandroid/os/IBinder;)Z

    move-result v4

    .line 3035
    .restart local v4    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3036
    invoke-virtual {v10, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3037
    goto/16 :goto_d20

    .line 3020
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Landroid/os/IBinder;
    .end local v4    # "_result":Z
    :pswitch_152
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->clearFastStartConfig()Z

    move-result v1

    .line 3021
    .local v1, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3022
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3023
    goto/16 :goto_d20

    .line 3011
    .end local v1    # "_result":Z
    :pswitch_15e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3012
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3013
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->putFastStartConfig(Ljava/lang/String;)Z

    move-result v2

    .line 3014
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3015
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 3016
    goto/16 :goto_d20

    .line 2999
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Z
    :pswitch_171
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 3001
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 3002
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 3003
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->startProcess(Ljava/lang/String;I)I

    move-result v3

    .line 3004
    .local v3, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 3005
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 3006
    goto/16 :goto_d20

    .line 2986
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":I
    :pswitch_188
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 2988
    .local v1, "_arg0":Landroid/content/Intent;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 2990
    .local v2, "_arg1":Landroid/os/Bundle;
    sget-object v3, Landroid/os/UserHandle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/UserHandle;

    .line 2991
    .local v3, "_arg2":Landroid/os/UserHandle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2992
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->startActivityAsUser(Landroid/content/Intent;Landroid/os/Bundle;Landroid/os/UserHandle;)V

    .line 2993
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2994
    goto/16 :goto_d20

    .line 2977
    .end local v1    # "_arg0":Landroid/content/Intent;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":Landroid/os/UserHandle;
    :pswitch_1ab
    sget-object v1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    .line 2978
    .restart local v1    # "_arg0":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2979
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->startActivity(Landroid/content/Intent;)V

    .line 2980
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2981
    goto/16 :goto_d20

    .line 2967
    .end local v1    # "_arg0":Landroid/content/Intent;
    :pswitch_1be
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2968
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2969
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->startUserInBackground(I)Z

    move-result v2

    .line 2970
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2971
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2972
    goto/16 :goto_d20

    .line 2957
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_1d1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2958
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2959
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getRunningServices(I)Ljava/util/List;

    move-result-object v2

    .line 2960
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningServiceInfo;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2961
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2962
    goto/16 :goto_d20

    .line 2947
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningServiceInfo;>;"
    :pswitch_1e4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2948
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2949
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->switchUser(I)Z

    move-result v2

    .line 2950
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2951
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2952
    goto/16 :goto_d20

    .line 2939
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_1f7
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v1

    .line 2940
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2941
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2942
    goto/16 :goto_d20

    .line 2930
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    :pswitch_203
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    .line 2931
    .local v1, "_arg0":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2932
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;

    move-result-object v2

    .line 2933
    .local v2, "_result":[Landroid/os/Debug$MemoryInfo;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2934
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedArray([Landroid/os/Parcelable;I)V

    .line 2935
    goto/16 :goto_d20

    .line 2919
    .end local v1    # "_arg0":[I
    .end local v2    # "_result":[Landroid/os/Debug$MemoryInfo;
    :pswitch_216
    sget-object v1, Landroid/content/res/Configuration;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/res/Configuration;

    .line 2920
    .local v1, "_arg0":Landroid/content/res/Configuration;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2921
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->updateConfiguration(Landroid/content/res/Configuration;)Z

    move-result v2

    .line 2922
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2923
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2924
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2925
    goto/16 :goto_d20

    .line 2911
    .end local v1    # "_arg0":Landroid/content/res/Configuration;
    .end local v2    # "_result":Z
    :pswitch_230
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getCurrentUser()I

    move-result v1

    .line 2912
    .local v1, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2913
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 2914
    goto/16 :goto_d20

    .line 2896
    .end local v1    # "_result":I
    :pswitch_23c
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2898
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2900
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    invoke-static {v3}, Landroid/content/pm/IPackageDataObserver$Stub;->asInterface(Landroid/os/IBinder;)Landroid/content/pm/IPackageDataObserver;

    move-result-object v3

    .line 2902
    .local v3, "_arg2":Landroid/content/pm/IPackageDataObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 2903
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2904
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityManager$Stub;->clearApplicationUserData(Ljava/lang/String;ZLandroid/content/pm/IPackageDataObserver;I)Z

    move-result v5

    .line 2905
    .local v5, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2906
    invoke-virtual {v10, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2907
    goto/16 :goto_d20

    .line 2886
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Z
    .end local v3    # "_arg2":Landroid/content/pm/IPackageDataObserver;
    .end local v4    # "_arg3":I
    .end local v5    # "_result":Z
    :pswitch_25f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2887
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2888
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getRunningTasks(I)Ljava/util/List;

    move-result-object v2

    .line 2889
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2890
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2891
    goto/16 :goto_d20

    .line 2876
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningTaskInfo;>;"
    :pswitch_272
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2877
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2878
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->removeTask(I)Z

    move-result v2

    .line 2879
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2880
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2881
    goto/16 :goto_d20

    .line 2868
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_285
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getPayJoyFlag()I

    move-result v1

    .line 2869
    .local v1, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2870
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 2871
    goto/16 :goto_d20

    .line 2859
    .end local v1    # "_result":I
    :pswitch_291
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2860
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2861
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setPayJoyFlag(I)Z

    move-result v2

    .line 2862
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2863
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2864
    goto/16 :goto_d20

    .line 2849
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Z
    :pswitch_2a4
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2850
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2851
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->notifyGameStatus(Landroid/os/Bundle;)I

    move-result v2

    .line 2852
    .local v2, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2853
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 2854
    goto/16 :goto_d20

    .line 2839
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":I
    :pswitch_2bb
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 2840
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2841
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->finishFlexibleActivityOnTouchOutside(Landroid/os/IBinder;)Z

    move-result v2

    .line 2842
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2843
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2844
    goto/16 :goto_d20

    .line 2829
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_result":Z
    :pswitch_2ce
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2831
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2832
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2833
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->trimSystemMemory(IZ)V

    .line 2834
    goto/16 :goto_d20

    .line 2812
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    :pswitch_2de
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Landroid/app/IApplicationThread$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IApplicationThread;

    move-result-object v1

    .line 2814
    .local v1, "_arg0":Landroid/app/IApplicationThread;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2816
    .local v2, "_arg1":Ljava/lang/String;
    sget-object v3, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/net/Uri;

    .line 2818
    .local v3, "_arg2":Landroid/net/Uri;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 2820
    .restart local v4    # "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 2821
    .local v5, "_arg4":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2822
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->grantUriPermissionToUser(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/net/Uri;II)V

    .line 2823
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2824
    goto/16 :goto_d20

    .line 2802
    .end local v1    # "_arg0":Landroid/app/IApplicationThread;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Landroid/net/Uri;
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":I
    :pswitch_306
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2803
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2804
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->autoLayoutCall(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v2

    .line 2805
    .local v2, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2806
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2807
    goto/16 :goto_d20

    .line 2791
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":Landroid/os/Bundle;
    :pswitch_31d
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 2793
    .local v1, "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 2794
    .local v3, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2795
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->addOplusLoopLoadTime(JLjava/lang/String;)V

    .line 2796
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2797
    goto/16 :goto_d20

    .line 2783
    .end local v1    # "_arg0":J
    .end local v3    # "_arg1":Ljava/lang/String;
    :pswitch_330
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getLoopCpuLoad()I

    move-result v1

    .line 2784
    .local v1, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2785
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 2786
    goto/16 :goto_d20

    .line 2774
    .end local v1    # "_result":I
    :pswitch_33c
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2775
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2776
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getFastAppReplacePkg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2777
    .local v2, "_result":Ljava/lang/String;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2778
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2779
    goto/16 :goto_d20

    .line 2762
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Ljava/lang/String;
    :pswitch_34f
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2764
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/osense/complexscene/IComplexSceneObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/osense/complexscene/IComplexSceneObserver;

    move-result-object v2

    .line 2765
    .local v2, "_arg1":Lcom/oplus/osense/complexscene/IComplexSceneObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2766
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->unregisterComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z

    move-result v3

    .line 2767
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2768
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2769
    goto/16 :goto_d20

    .line 2750
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":Lcom/oplus/osense/complexscene/IComplexSceneObserver;
    .end local v3    # "_result":Z
    :pswitch_36e
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2752
    .restart local v1    # "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/osense/complexscene/IComplexSceneObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/osense/complexscene/IComplexSceneObserver;

    move-result-object v2

    .line 2753
    .restart local v2    # "_arg1":Lcom/oplus/osense/complexscene/IComplexSceneObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2754
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->registerComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z

    move-result v3

    .line 2755
    .restart local v3    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2756
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2757
    goto/16 :goto_d20

    .line 2734
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":Lcom/oplus/osense/complexscene/IComplexSceneObserver;
    .end local v3    # "_result":Z
    :pswitch_38d
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2736
    .restart local v1    # "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2738
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    .line 2740
    .local v3, "_arg2":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 2742
    .local v5, "_arg3":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v7

    .line 2743
    .local v7, "_arg4":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2744
    move-object v0, p0

    invoke-virtual/range {v0 .. v8}, Landroid/app/IOplusActivityManager$Stub;->asyncReportDalvikMem(Landroid/os/Bundle;IJJJ)V

    .line 2745
    goto/16 :goto_d20

    .line 2724
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":J
    .end local v5    # "_arg3":J
    .end local v7    # "_arg4":J
    :pswitch_3ae
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/ITerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/ITerminateObserver;

    move-result-object v1

    .line 2725
    .local v1, "_arg0":Lcom/oplus/app/ITerminateObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2726
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->unregisterTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v2

    .line 2727
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2728
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2729
    goto/16 :goto_d20

    .line 2714
    .end local v1    # "_arg0":Lcom/oplus/app/ITerminateObserver;
    .end local v2    # "_result":Z
    :pswitch_3c5
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/ITerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/ITerminateObserver;

    move-result-object v1

    .line 2715
    .restart local v1    # "_arg0":Lcom/oplus/app/ITerminateObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2716
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->registerTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v2

    .line 2717
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2718
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2719
    goto/16 :goto_d20

    .line 2705
    .end local v1    # "_arg0":Lcom/oplus/app/ITerminateObserver;
    .end local v2    # "_result":Z
    :pswitch_3dc
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v1

    .line 2706
    .local v1, "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2707
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->notifyProcessTerminateFinish(Lcom/oplus/app/IProcessTerminateObserver;)V

    .line 2708
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2709
    goto/16 :goto_d20

    .line 2694
    .end local v1    # "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    :pswitch_3ef
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    .line 2696
    .local v1, "_arg0":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2697
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2698
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->notifyProcessTerminate([ILjava/lang/String;)V

    .line 2699
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2700
    goto/16 :goto_d20

    .line 2686
    .end local v1    # "_arg0":[I
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_402
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getTerminateObservers()[I

    move-result-object v1

    .line 2687
    .local v1, "_result":[I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2688
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeIntArray([I)V

    .line 2689
    goto/16 :goto_d20

    .line 2677
    .end local v1    # "_result":[I
    :pswitch_40e
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v1

    .line 2678
    .local v1, "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2679
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v2

    .line 2680
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2681
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2682
    goto/16 :goto_d20

    .line 2667
    .end local v1    # "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    .end local v2    # "_result":Z
    :pswitch_425
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IProcessTerminateObserver$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IProcessTerminateObserver;

    move-result-object v1

    .line 2668
    .restart local v1    # "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2669
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v2

    .line 2670
    .restart local v2    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2671
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2672
    goto/16 :goto_d20

    .line 2659
    .end local v1    # "_arg0":Lcom/oplus/app/IProcessTerminateObserver;
    .end local v2    # "_result":Z
    :pswitch_43c
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getCompatModeSession()Lcom/oplus/compatmode/IOplusCompatModeSession;

    move-result-object v1

    .line 2660
    .local v1, "_result":Lcom/oplus/compatmode/IOplusCompatModeSession;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2661
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V

    .line 2662
    goto/16 :goto_d20

    .line 2648
    .end local v1    # "_result":Lcom/oplus/compatmode/IOplusCompatModeSession;
    :pswitch_448
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2650
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2652
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2653
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2654
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->setSceneActionTransit(Ljava/lang/String;Ljava/lang/String;I)V

    .line 2655
    goto/16 :goto_d20

    .line 2638
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    :pswitch_45c
    sget-object v1, Landroid/view/MotionEvent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/MotionEvent;

    .line 2640
    .local v1, "_arg0":Landroid/view/MotionEvent;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2641
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2642
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->sendFlingTransit(Landroid/view/MotionEvent;I)V

    .line 2643
    goto/16 :goto_d20

    .line 2626
    .end local v1    # "_arg0":Landroid/view/MotionEvent;
    .end local v2    # "_arg1":I
    :pswitch_470
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2628
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2629
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2630
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->requestDeviceFolded(IZ)Z

    move-result v3

    .line 2631
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2632
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2633
    goto/16 :goto_d20

    .line 2616
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Z
    :pswitch_487
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2618
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2619
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2620
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->asyncReportFrames(Ljava/lang/String;I)V

    .line 2621
    goto/16 :goto_d20

    .line 2606
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_497
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2607
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2608
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getRunningPidsByUid(I)[I

    move-result-object v2

    .line 2609
    .local v2, "_result":[I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2610
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeIntArray([I)V

    .line 2611
    goto/16 :goto_d20

    .line 2595
    .end local v1    # "_arg0":I
    .end local v2    # "_result":[I
    :pswitch_4aa
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2597
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2598
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2599
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->forceStopPackageAndSaveActivity(Ljava/lang/String;I)V

    .line 2600
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2601
    goto/16 :goto_d20

    .line 2584
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_4bd
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2586
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2587
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2588
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->cleanPackageResources(Ljava/lang/String;I)V

    .line 2589
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2590
    goto/16 :goto_d20

    .line 2572
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_4d0
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 2574
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/verifycode/IOplusVerifyCodeListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/verifycode/IOplusVerifyCodeListener;

    move-result-object v2

    .line 2575
    .local v2, "_arg1":Lcom/oplus/verifycode/IOplusVerifyCodeListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2576
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->addOrRemoveOplusVerifyCodeListener(ZLcom/oplus/verifycode/IOplusVerifyCodeListener;)Z

    move-result v3

    .line 2577
    .restart local v3    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2578
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2579
    goto/16 :goto_d20

    .line 2562
    .end local v1    # "_arg0":Z
    .end local v2    # "_arg1":Lcom/oplus/verifycode/IOplusVerifyCodeListener;
    .end local v3    # "_result":Z
    :pswitch_4eb
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2564
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2565
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2566
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->notifyUiSwitched(Ljava/lang/String;I)V

    .line 2567
    goto/16 :goto_d20

    .line 2552
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_4fb
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2553
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2554
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getPackageFreezeDataInfos(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object v2

    .line 2555
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2556
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2557
    goto/16 :goto_d20

    .line 2542
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    :pswitch_512
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2543
    .restart local v1    # "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2544
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getRunningAppProcessInfos(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object v2

    .line 2545
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2546
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2547
    goto/16 :goto_d20

    .line 2528
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    :pswitch_529
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2530
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    .line 2532
    .local v2, "_arg1":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v4

    .line 2533
    .local v4, "_arg2":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2534
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->queryUsageStats(IJJ)Ljava/util/List;

    move-result-object v6

    .line 2535
    .local v6, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/usage/UsageStats;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2536
    invoke-virtual {v10, v6, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2537
    goto/16 :goto_d20

    .line 2516
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":J
    .end local v4    # "_arg2":J
    .end local v6    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/usage/UsageStats;>;"
    :pswitch_545
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2518
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v2

    .line 2519
    .local v2, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2520
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getDownloadingList(IZ)Ljava/util/List;

    move-result-object v3

    .line 2521
    .local v3, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2522
    invoke-virtual {v10, v3, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2523
    goto/16 :goto_d20

    .line 2502
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Z
    .end local v3    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    :pswitch_55c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2504
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2506
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 2507
    .local v3, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2508
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->inDownloading(IIZ)Z

    move-result v4

    .line 2509
    .local v4, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2510
    invoke-virtual {v10, v4}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2511
    goto/16 :goto_d20

    .line 2489
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":Z
    .end local v4    # "_result":Z
    :pswitch_577
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2491
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2493
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2494
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2495
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->compactProcess(Landroid/os/Bundle;II)V

    .line 2496
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2497
    goto/16 :goto_d20

    .line 2481
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    :pswitch_592
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getUXIconData()Lcom/oplus/util/OplusUXIconData;

    move-result-object v1

    .line 2482
    .local v1, "_result":Lcom/oplus/util/OplusUXIconData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2483
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2484
    goto/16 :goto_d20

    .line 2470
    .end local v1    # "_result":Lcom/oplus/util/OplusUXIconData;
    :pswitch_59e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2472
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2473
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2474
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getStageProtectListAsUser(II)Ljava/util/List;

    move-result-object v3

    .line 2475
    .local v3, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2476
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2477
    goto/16 :goto_d20

    .line 2460
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_5b5
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2461
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2462
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getStageProtectList(I)Ljava/util/List;

    move-result-object v2

    .line 2463
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2464
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2465
    goto/16 :goto_d20

    .line 2449
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_5c8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2451
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2452
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2453
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->anrViaTheiaEvent(ILjava/lang/String;)V

    .line 2454
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2455
    goto/16 :goto_d20

    .line 2439
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_5db
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2440
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2441
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getAllVisibleTasksInfo(I)Ljava/util/List;

    move-result-object v2

    .line 2442
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2443
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2444
    goto/16 :goto_d20

    .line 2430
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    :pswitch_5ee
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eventhub/sdk/aidl/IEventCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    move-result-object v1

    .line 2431
    .local v1, "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2432
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->unregisterErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 2433
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2434
    goto/16 :goto_d20

    .line 2421
    .end local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    :pswitch_601
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eventhub/sdk/aidl/IEventCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    move-result-object v1

    .line 2422
    .restart local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2423
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->registerErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 2424
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2425
    goto/16 :goto_d20

    .line 2412
    .end local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    :pswitch_614
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eventhub/sdk/aidl/IEventCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    move-result-object v1

    .line 2413
    .restart local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2414
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->unregisterAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 2415
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2416
    goto/16 :goto_d20

    .line 2401
    .end local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    :pswitch_627
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eventhub/sdk/aidl/IEventCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    move-result-object v1

    .line 2403
    .restart local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2404
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2405
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->registerAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;Ljava/lang/String;)V

    .line 2406
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2407
    goto/16 :goto_d20

    .line 2392
    .end local v1    # "_arg0":Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_63e
    sget-object v1, Landroid/os/SharedMemory;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/SharedMemory;

    .line 2393
    .local v1, "_arg0":Landroid/os/SharedMemory;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2394
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->updateANRDumpState(Landroid/os/SharedMemory;)V

    .line 2395
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2396
    goto/16 :goto_d20

    .line 2383
    .end local v1    # "_arg0":Landroid/os/SharedMemory;
    :pswitch_651
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eap/IOplusEapDataCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eap/IOplusEapDataCallback;

    move-result-object v1

    .line 2384
    .local v1, "_arg0":Lcom/oplus/eap/IOplusEapDataCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2385
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->unregisterEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    .line 2386
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2387
    goto/16 :goto_d20

    .line 2374
    .end local v1    # "_arg0":Lcom/oplus/eap/IOplusEapDataCallback;
    :pswitch_664
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/eap/IOplusEapDataCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/eap/IOplusEapDataCallback;

    move-result-object v1

    .line 2375
    .restart local v1    # "_arg0":Lcom/oplus/eap/IOplusEapDataCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2376
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->registerEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    .line 2377
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2378
    goto/16 :goto_d20

    .line 2361
    .end local v1    # "_arg0":Lcom/oplus/eap/IOplusEapDataCallback;
    :pswitch_677
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2363
    .local v1, "_arg0":Landroid/os/Bundle;
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 2364
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2365
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getTrafficPacketList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v3

    .line 2366
    .local v3, "_result":Ljava/lang/String;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2367
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2368
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2369
    goto/16 :goto_d20

    .line 2348
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":Ljava/lang/String;
    :pswitch_696
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 2350
    .restart local v1    # "_arg0":Landroid/os/Bundle;
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 2351
    .restart local v2    # "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2352
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getTrafficBytesList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v3

    .line 2353
    .restart local v3    # "_result":Ljava/lang/String;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2354
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2355
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2356
    goto/16 :goto_d20

    .line 2336
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":Ljava/lang/String;
    :pswitch_6b5
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2338
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2339
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2340
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->isFrozenByHans(Ljava/lang/String;I)Z

    move-result v3

    .line 2341
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2342
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2343
    goto/16 :goto_d20

    .line 2325
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_6cc
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2327
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 2328
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2329
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->exitFastFreezer(Ljava/lang/String;Ljava/lang/String;)V

    .line 2330
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2331
    goto/16 :goto_d20

    .line 2310
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_6df
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2312
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v2

    .line 2314
    .local v2, "_arg1":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    .line 2316
    .local v3, "_arg2":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 2317
    .local v5, "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2318
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->enterFastFreezer(Ljava/lang/String;[IJLjava/lang/String;)V

    .line 2319
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2320
    goto/16 :goto_d20

    .line 2300
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":[I
    .end local v3    # "_arg2":J
    .end local v5    # "_arg3":Ljava/lang/String;
    :pswitch_6fb
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2301
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2302
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    .line 2303
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2304
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2305
    goto/16 :goto_d20

    .line 2292
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_70e
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getPreloadPkgList()Landroid/os/Bundle;

    move-result-object v1

    .line 2293
    .local v1, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2294
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2295
    goto/16 :goto_d20

    .line 2281
    .end local v1    # "_result":Landroid/os/Bundle;
    :pswitch_71a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2283
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2284
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2285
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getPreloadStatus(Ljava/lang/String;I)Z

    move-result v3

    .line 2286
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2287
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2288
    goto/16 :goto_d20

    .line 2273
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Z
    :pswitch_731
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getPreloadIOSize()J

    move-result-wide v1

    .line 2274
    .local v1, "_result":J
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2275
    invoke-virtual {v10, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 2276
    goto/16 :goto_d20

    .line 2262
    .end local v1    # "_result":J
    :pswitch_73d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2264
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2265
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2266
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getResPreloadInfo(II)Landroid/os/Bundle;

    move-result-object v3

    .line 2267
    .local v3, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2268
    invoke-virtual {v10, v3, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2269
    goto/16 :goto_d20

    .line 2248
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Landroid/os/Bundle;
    :pswitch_754
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2250
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2252
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2254
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 2255
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2256
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityManager$Stub;->executeResPreload(Ljava/lang/String;IILjava/lang/String;)V

    .line 2257
    goto/16 :goto_d20

    .line 2240
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    :pswitch_76c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2241
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2242
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->notifyAthenaOnekeyClearRunning(I)V

    .line 2243
    goto/16 :goto_d20

    .line 2228
    .end local v1    # "_arg0":I
    :pswitch_778
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2230
    .local v1, "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 2231
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2232
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->setAppFreeze(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v3

    .line 2233
    .local v3, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2234
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2235
    goto/16 :goto_d20

    .line 2216
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_result":Z
    :pswitch_793
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2218
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/app/IOplusHansListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusHansListener;

    move-result-object v2

    .line 2219
    .local v2, "_arg1":Lcom/oplus/app/IOplusHansListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2220
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->unregisterHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v3

    .line 2221
    .restart local v3    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2222
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2223
    goto/16 :goto_d20

    .line 2204
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/app/IOplusHansListener;
    .end local v3    # "_result":Z
    :pswitch_7ae
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2206
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/app/IOplusHansListener$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusHansListener;

    move-result-object v2

    .line 2207
    .restart local v2    # "_arg1":Lcom/oplus/app/IOplusHansListener;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2208
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->registerHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v3

    .line 2209
    .restart local v3    # "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2210
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 2211
    goto/16 :goto_d20

    .line 2194
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/app/IOplusHansListener;
    .end local v3    # "_result":Z
    :pswitch_7c9
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2195
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2196
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getFontVariationAdaptionData(Ljava/lang/String;)I

    move-result v2

    .line 2197
    .local v2, "_result":I
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2198
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 2199
    goto/16 :goto_d20

    .line 2178
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":I
    :pswitch_7dc
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2180
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2182
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2184
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 2186
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 2187
    .local v5, "_arg4":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2188
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->notifyAppKillReason(IIIILjava/lang/String;)V

    .line 2189
    goto/16 :goto_d20

    .line 2168
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":Ljava/lang/String;
    :pswitch_7f9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2169
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2170
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->queryProcessNameFromPid(I)Ljava/lang/String;

    move-result-object v2

    .line 2171
    .local v2, "_result":Ljava/lang/String;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2172
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2173
    goto/16 :goto_d20

    .line 2149
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/lang/String;
    :pswitch_80c
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 2151
    .local v1, "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 2153
    .local v3, "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 2155
    .local v4, "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 2157
    .local v5, "_arg3":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    .line 2159
    .local v7, "_arg4":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v8

    .line 2160
    .local v8, "_arg5":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2161
    move-object v0, p0

    invoke-virtual/range {v0 .. v8}, Landroid/app/IOplusActivityManager$Stub;->reportSkippedFramesActivityName(JZZJLjava/lang/String;Ljava/lang/String;)V

    .line 2162
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2163
    goto/16 :goto_d20

    .line 2132
    .end local v1    # "_arg0":J
    .end local v3    # "_arg1":Z
    .end local v4    # "_arg2":Z
    .end local v5    # "_arg3":J
    .end local v7    # "_arg4":Ljava/lang/String;
    .end local v8    # "_arg5":Ljava/lang/String;
    :pswitch_830
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 2134
    .restart local v1    # "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 2136
    .restart local v3    # "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 2138
    .restart local v4    # "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 2140
    .restart local v5    # "_arg3":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    .line 2141
    .restart local v7    # "_arg4":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2142
    move-object v0, p0

    invoke-virtual/range {v0 .. v7}, Landroid/app/IOplusActivityManager$Stub;->reportSkippedFramesProcName(JZZJLjava/lang/String;)V

    .line 2143
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2144
    goto/16 :goto_d20

    .line 2117
    .end local v1    # "_arg0":J
    .end local v3    # "_arg1":Z
    .end local v4    # "_arg2":Z
    .end local v5    # "_arg3":J
    .end local v7    # "_arg4":Ljava/lang/String;
    :pswitch_850
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 2119
    .restart local v1    # "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v3

    .line 2121
    .restart local v3    # "_arg1":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v4

    .line 2123
    .restart local v4    # "_arg2":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 2124
    .restart local v5    # "_arg3":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2125
    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/app/IOplusActivityManager$Stub;->reportSkippedFrames(JZZJ)V

    .line 2126
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2127
    goto/16 :goto_d20

    .line 2098
    .end local v1    # "_arg0":J
    .end local v3    # "_arg1":Z
    .end local v4    # "_arg2":Z
    .end local v5    # "_arg3":J
    :pswitch_86c
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    .line 2100
    .local v1, "_arg0":Landroid/os/IBinder;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2102
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 2104
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 2106
    .local v4, "_arg3":Ljava/lang/String;
    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Landroid/os/Bundle;

    .line 2108
    .local v5, "_arg4":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v6

    .line 2109
    .local v6, "_arg5":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2110
    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/app/IOplusActivityManager$Stub;->finishNotOrderReceiver(Landroid/os/IBinder;IILjava/lang/String;Landroid/os/Bundle;Z)V

    .line 2111
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2112
    goto/16 :goto_d20

    .line 2090
    .end local v1    # "_arg0":Landroid/os/IBinder;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":Landroid/os/Bundle;
    .end local v6    # "_arg5":Z
    :pswitch_895
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    .line 2091
    .local v1, "_arg0":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2092
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->activeGc([I)V

    .line 2093
    goto/16 :goto_d20

    .line 2080
    .end local v1    # "_arg0":[I
    :pswitch_8a1
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    .line 2081
    .restart local v1    # "_arg0":[I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2082
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getProcCmdline([I)Ljava/util/List;

    move-result-object v2

    .line 2083
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2084
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2085
    goto/16 :goto_d20

    .line 2070
    .end local v1    # "_arg0":[I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_8b4
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2071
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2072
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getCpuLimitLatestLogs(Ljava/lang/String;)Landroid/os/SharedMemory;

    move-result-object v2

    .line 2073
    .local v2, "_result":Landroid/os/SharedMemory;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2074
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 2075
    goto/16 :goto_d20

    .line 2060
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Landroid/os/SharedMemory;
    :pswitch_8c7
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2061
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2062
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getTopLoadPidsInfos(I)Ljava/util/List;

    move-result-object v2

    .line 2063
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2064
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2065
    goto/16 :goto_d20

    .line 2052
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_8da
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getTotalCpuLoadPercent()J

    move-result-wide v1

    .line 2053
    .local v1, "_result":J
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2054
    invoke-virtual {v10, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 2055
    goto/16 :goto_d20

    .line 2045
    .end local v1    # "_result":J
    :pswitch_8e6
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getUidCpuWorkingStats()Ljava/util/List;

    move-result-object v1

    .line 2046
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2047
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2048
    goto/16 :goto_d20

    .line 2039
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_8f2
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->updateUidCpuTracker()V

    .line 2040
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2041
    goto/16 :goto_d20

    .line 2033
    :pswitch_8fa
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->syncPermissionRecord()V

    .line 2034
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2035
    goto/16 :goto_d20

    .line 2024
    :pswitch_902
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2025
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2026
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getTaskPkgList(I)Ljava/util/List;

    move-result-object v2

    .line 2027
    .restart local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2028
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 2029
    goto/16 :goto_d20

    .line 2012
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_915
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 2014
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 2015
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2016
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getProcDependencyByUserId(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v3

    .line 2017
    .local v3, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusProcDependData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2018
    invoke-virtual {v10, v3, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2019
    goto/16 :goto_d20

    .line 2002
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusProcDependData;>;"
    :pswitch_92c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 2003
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 2004
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getProcDependency(I)Ljava/util/List;

    move-result-object v2

    .line 2005
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusProcDependData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 2006
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 2007
    goto/16 :goto_d20

    .line 1992
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusProcDependData;>;"
    :pswitch_93f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1993
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1994
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getProcCommonInfoList(I)Ljava/util/List;

    move-result-object v2

    .line 1995
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1996
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1997
    goto/16 :goto_d20

    .line 1982
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_952
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    .line 1983
    .local v1, "_arg0":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1984
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->dumpProcPerfData(Landroid/os/Bundle;)Z

    move-result v2

    .line 1985
    .local v2, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1986
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 1987
    goto/16 :goto_d20

    .line 1974
    .end local v1    # "_arg0":Landroid/os/Bundle;
    .end local v2    # "_result":Z
    :pswitch_969
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->isNightMode()Z

    move-result v1

    .line 1975
    .local v1, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1976
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 1977
    goto/16 :goto_d20

    .line 1967
    .end local v1    # "_result":Z
    :pswitch_975
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getAllDarkModeData()Ljava/util/List;

    move-result-object v1

    .line 1968
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/darkmode/OplusDarkModeData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1969
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 1970
    goto/16 :goto_d20

    .line 1958
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/darkmode/OplusDarkModeData;>;"
    :pswitch_981
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1959
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1960
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getDarkModeData(Ljava/lang/String;)Lcom/oplus/darkmode/OplusDarkModeData;

    move-result-object v2

    .line 1961
    .local v2, "_result":Lcom/oplus/darkmode/OplusDarkModeData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1962
    invoke-virtual {v10, v2, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1963
    goto/16 :goto_d20

    .line 1949
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_result":Lcom/oplus/darkmode/OplusDarkModeData;
    :pswitch_994
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusPermissionRecordController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusPermissionRecordController;

    move-result-object v1

    .line 1950
    .local v1, "_arg0":Lcom/oplus/app/IOplusPermissionRecordController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1951
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setPermissionRecordController(Lcom/oplus/app/IOplusPermissionRecordController;)V

    .line 1952
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1953
    goto/16 :goto_d20

    .line 1940
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusPermissionRecordController;
    :pswitch_9a7
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1941
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1942
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->forceTrimAppMemory(I)V

    .line 1943
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1944
    goto/16 :goto_d20

    .line 1932
    .end local v1    # "_arg0":I
    :pswitch_9b6
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getCpuWorkingStats()Ljava/util/List;

    move-result-object v1

    .line 1933
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1934
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1935
    goto/16 :goto_d20

    .line 1923
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_9c2
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 1924
    .local v1, "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1925
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->updateCpuTracker(J)F

    move-result v3

    .line 1926
    .local v3, "_result":F
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1927
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeFloat(F)V

    .line 1928
    goto/16 :goto_d20

    .line 1909
    .end local v1    # "_arg0":J
    .end local v3    # "_result":F
    :pswitch_9d5
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1911
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1913
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1914
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1915
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->getConfigInfo(Ljava/lang/String;II)Landroid/os/Bundle;

    move-result-object v4

    .line 1916
    .local v4, "_result":Landroid/os/Bundle;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1917
    invoke-virtual {v10, v4, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1918
    goto/16 :goto_d20

    .line 1893
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Landroid/os/Bundle;
    :pswitch_9f0
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1895
    .restart local v1    # "_arg0":Ljava/lang/String;
    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v2}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/Bundle;

    .line 1897
    .local v2, "_arg1":Landroid/os/Bundle;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1899
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1900
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1901
    invoke-virtual {p0, v1, v2, v3, v4}, Landroid/app/IOplusActivityManager$Stub;->putConfigInfo(Ljava/lang/String;Landroid/os/Bundle;II)Z

    move-result v5

    .line 1902
    .local v5, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1903
    invoke-virtual {v10, v5}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 1904
    goto/16 :goto_d20

    .line 1884
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Landroid/os/Bundle;
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_result":Z
    :pswitch_a13
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    .line 1885
    .local v1, "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1886
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->addPreventIndulgeList(Ljava/util/List;)V

    .line 1887
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1888
    goto/16 :goto_d20

    .line 1875
    .end local v1    # "_arg0":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_a22
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusAppStartController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusAppStartController;

    move-result-object v1

    .line 1876
    .local v1, "_arg0":Lcom/oplus/app/IOplusAppStartController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1877
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setPreventIndulgeController(Lcom/oplus/app/IOplusAppStartController;)V

    .line 1878
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1879
    goto/16 :goto_d20

    .line 1864
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusAppStartController;
    :pswitch_a35
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1866
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v2

    .line 1867
    .local v2, "_arg1":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1868
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->addBackgroundRestrictedInfo(Ljava/lang/String;Ljava/util/List;)V

    .line 1869
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1870
    goto/16 :goto_d20

    .line 1853
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_a48
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1855
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1856
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1857
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->removeFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    .line 1858
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1859
    goto/16 :goto_d20

    .line 1842
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_a5b
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1844
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1845
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1846
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->addFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    .line 1847
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1848
    goto/16 :goto_d20

    .line 1833
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_a6e
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusAppStartController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusAppStartController;

    move-result-object v1

    .line 1834
    .local v1, "_arg0":Lcom/oplus/app/IOplusAppStartController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1835
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setAppStartMonitorController(Lcom/oplus/app/IOplusAppStartController;)V

    .line 1836
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1837
    goto/16 :goto_d20

    .line 1825
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusAppStartController;
    :pswitch_a81
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getRunningProcesses()Ljava/util/List;

    move-result-object v1

    .line 1826
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1827
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;I)V

    .line 1828
    goto/16 :goto_d20

    .line 1815
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    :pswitch_a8d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1817
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1818
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1819
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->removeFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    .line 1820
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1821
    goto/16 :goto_d20

    .line 1804
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_aa0
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1806
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1807
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1808
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->addFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    .line 1809
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1810
    goto/16 :goto_d20

    .line 1796
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_ab3
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getReflectData()Lcom/oplus/util/OplusReflectData;

    move-result-object v1

    .line 1797
    .local v1, "_result":Lcom/oplus/util/OplusReflectData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1798
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1799
    goto/16 :goto_d20

    .line 1789
    .end local v1    # "_result":Lcom/oplus/util/OplusReflectData;
    :pswitch_abf
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getResolveData()Lcom/oplus/util/OplusResolveData;

    move-result-object v1

    .line 1790
    .local v1, "_result":Lcom/oplus/util/OplusResolveData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1791
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1792
    goto/16 :goto_d20

    .line 1777
    .end local v1    # "_result":Lcom/oplus/util/OplusResolveData;
    :pswitch_acb
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1779
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1781
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 1782
    .local v3, "_arg2":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1783
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->removeMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1784
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1785
    goto/16 :goto_d20

    .line 1764
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Ljava/lang/String;
    :pswitch_ae2
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1766
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1768
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    .line 1769
    .restart local v3    # "_arg2":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1770
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1771
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1772
    goto/16 :goto_d20

    .line 1756
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Ljava/lang/String;
    :pswitch_af9
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getDisplayCompatData()Lcom/oplus/util/OplusDisplayCompatData;

    move-result-object v1

    .line 1757
    .local v1, "_result":Lcom/oplus/util/OplusDisplayCompatData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1758
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1759
    goto/16 :goto_d20

    .line 1746
    .end local v1    # "_result":Lcom/oplus/util/OplusDisplayCompatData;
    :pswitch_b05
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1748
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1749
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1750
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->handleAppFromControlCenter(Ljava/lang/String;I)V

    .line 1751
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1752
    goto/16 :goto_d20

    .line 1732
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    :pswitch_b18
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1734
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1736
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1737
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1738
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->getStageProtectListFromPkgAsUser(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v4

    .line 1739
    .local v4, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1740
    invoke-virtual {v10, v4}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1741
    goto/16 :goto_d20

    .line 1720
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_b33
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1722
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1723
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1724
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v3

    .line 1725
    .local v3, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1726
    invoke-virtual {v10, v3}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1727
    goto/16 :goto_d20

    .line 1712
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_b4a
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getDisplayOptimizationData()Lcom/oplus/util/OplusDisplayOptimizationData;

    move-result-object v1

    .line 1713
    .local v1, "_result":Lcom/oplus/util/OplusDisplayOptimizationData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1714
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1715
    goto/16 :goto_d20

    .line 1702
    .end local v1    # "_result":Lcom/oplus/util/OplusDisplayOptimizationData;
    :pswitch_b56
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1704
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1705
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1706
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->removeStageProtectInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 1707
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1708
    goto/16 :goto_d20

    .line 1683
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_b69
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1685
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1687
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v3

    .line 1689
    .local v3, "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 1691
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    .line 1693
    .local v5, "_arg4":J
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v7

    invoke-static {v7}, Lcom/oplus/app/IOplusProtectConnection$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusProtectConnection;

    move-result-object v7

    .line 1694
    .local v7, "_arg5":Lcom/oplus/app/IOplusProtectConnection;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1695
    move-object v0, p0

    invoke-virtual/range {v0 .. v7}, Landroid/app/IOplusActivityManager$Stub;->addStageProtectInfo(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;JLcom/oplus/app/IOplusProtectConnection;)V

    .line 1696
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1697
    goto/16 :goto_d20

    .line 1675
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":J
    .end local v7    # "_arg5":Lcom/oplus/app/IOplusProtectConnection;
    :pswitch_b91
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getGlobalProcessWhiteList()Ljava/util/List;

    move-result-object v1

    .line 1676
    .local v1, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1677
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1678
    goto/16 :goto_d20

    .line 1666
    .end local v1    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_b9d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1667
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1668
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->getGlobalPkgWhiteList(I)Ljava/util/List;

    move-result-object v2

    .line 1669
    .local v2, "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1670
    invoke-virtual {v10, v2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    .line 1671
    goto/16 :goto_d20

    .line 1657
    .end local v1    # "_arg0":I
    .end local v2    # "_result":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_bb0
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/app/IOplusGameSpaceController$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/app/IOplusGameSpaceController;

    move-result-object v1

    .line 1658
    .local v1, "_arg0":Lcom/oplus/app/IOplusGameSpaceController;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1659
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setGameSpaceController(Lcom/oplus/app/IOplusGameSpaceController;)V

    .line 1660
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1661
    goto/16 :goto_d20

    .line 1644
    .end local v1    # "_arg0":Lcom/oplus/app/IOplusGameSpaceController;
    :pswitch_bc3
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1646
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1648
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1649
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1650
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->handleAppForNotification(Ljava/lang/String;II)V

    .line 1651
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1652
    goto/16 :goto_d20

    .line 1635
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    :pswitch_bda
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1636
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1637
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->killPidForce(I)V

    .line 1638
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1639
    goto/16 :goto_d20

    .line 1624
    .end local v1    # "_arg0":I
    :pswitch_be9
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1626
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1627
    .local v2, "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1628
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->revokeOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V

    .line 1629
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1630
    goto/16 :goto_d20

    .line 1613
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_bfc
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1615
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1616
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1617
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->grantOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V

    .line 1618
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1619
    goto/16 :goto_d20

    .line 1605
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    :pswitch_c0f
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->isPermissionInterceptEnabled()Z

    move-result v1

    .line 1606
    .local v1, "_result":Z
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1607
    invoke-virtual {v10, v1}, Landroid/os/Parcel;->writeBoolean(Z)V

    .line 1608
    goto/16 :goto_d20

    .line 1597
    .end local v1    # "_result":Z
    :pswitch_c1b
    invoke-virtual {p2}, Landroid/os/Parcel;->readBoolean()Z

    move-result v1

    .line 1598
    .local v1, "_arg0":Z
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1599
    invoke-virtual {p0, v1}, Landroid/app/IOplusActivityManager$Stub;->setPermissionInterceptEnable(Z)V

    .line 1600
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1601
    goto/16 :goto_d20

    .line 1584
    .end local v1    # "_arg0":Z
    :pswitch_c2a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1586
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    .line 1588
    .restart local v2    # "_arg1":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1589
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1590
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->updatePermissionChoice(Ljava/lang/String;Ljava/lang/String;I)V

    .line 1591
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1592
    goto/16 :goto_d20

    .line 1576
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Ljava/lang/String;
    .end local v3    # "_arg2":I
    :pswitch_c41
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getSecureKeyboardData()Lcom/oplus/util/OplusSecureKeyboardData;

    move-result-object v1

    .line 1577
    .local v1, "_result":Lcom/oplus/util/OplusSecureKeyboardData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1578
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1579
    goto/16 :goto_d20

    .line 1569
    .end local v1    # "_result":Lcom/oplus/util/OplusSecureKeyboardData;
    :pswitch_c4d
    invoke-virtual {p0}, Landroid/app/IOplusActivityManager$Stub;->getAccidentallyTouchData()Lcom/oplus/util/OplusAccidentallyTouchData;

    move-result-object v1

    .line 1570
    .local v1, "_result":Lcom/oplus/util/OplusAccidentallyTouchData;
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1571
    invoke-virtual {v10, v1, v12}, Landroid/os/Parcel;->writeTypedObject(Landroid/os/Parcelable;I)V

    .line 1572
    goto/16 :goto_d20

    .line 1560
    .end local v1    # "_result":Lcom/oplus/util/OplusAccidentallyTouchData;
    :pswitch_c59
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1562
    .local v1, "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/favorite/IOplusFavoriteQueryCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/favorite/IOplusFavoriteQueryCallback;

    move-result-object v2

    .line 1563
    .local v2, "_arg1":Lcom/oplus/favorite/IOplusFavoriteQueryCallback;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1564
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->favoriteQueryRule(Ljava/lang/String;Lcom/oplus/favorite/IOplusFavoriteQueryCallback;)V

    .line 1565
    goto/16 :goto_d20

    .line 1544
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":Lcom/oplus/favorite/IOplusFavoriteQueryCallback;
    :pswitch_c6d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1546
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1548
    .local v2, "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1550
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1552
    .local v4, "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    .line 1553
    .local v5, "_arg4":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1554
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->hookAfterBindApplicationFinished(Ljava/lang/String;IIILjava/lang/String;)V

    .line 1555
    goto/16 :goto_d20

    .line 1532
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":Ljava/lang/String;
    :pswitch_c8a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    .line 1534
    .restart local v1    # "_arg0":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1536
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1537
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1538
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->reportBindApplicationFinished(Ljava/lang/String;II)V

    .line 1539
    goto/16 :goto_d20

    .line 1522
    .end local v1    # "_arg0":Ljava/lang/String;
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    :pswitch_c9e
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 1524
    .local v1, "_arg0":J
    sget-object v3, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, v3}, Landroid/os/Parcel;->readTypedObject(Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/Intent;

    .line 1525
    .local v3, "_arg1":Landroid/content/Intent;
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1526
    invoke-virtual {p0, v1, v2, v3}, Landroid/app/IOplusActivityManager$Stub;->sendTheiaEvent(JLandroid/content/Intent;)V

    .line 1527
    goto :goto_d20

    .line 1514
    .end local v1    # "_arg0":J
    .end local v3    # "_arg1":Landroid/content/Intent;
    :pswitch_cb1
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    .line 1515
    .restart local v1    # "_arg0":J
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1516
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->onBackPressedOnTheiaMonitor(J)V

    .line 1517
    goto :goto_d20

    .line 1504
    .end local v1    # "_arg0":J
    :pswitch_cbc
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1506
    .local v1, "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1507
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1508
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->setGlThreads(II)V

    .line 1509
    goto :goto_d20

    .line 1494
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    :pswitch_ccb
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1496
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1497
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1498
    invoke-virtual {p0, v1, v2}, Landroid/app/IOplusActivityManager$Stub;->setHwuiTaskThreads(II)V

    .line 1499
    goto :goto_d20

    .line 1473
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    :pswitch_cda
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1475
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1477
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1479
    .local v3, "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1481
    .restart local v4    # "_arg3":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 1483
    .local v5, "_arg4":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v6

    .line 1485
    .local v6, "_arg5":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v7

    .line 1486
    .local v7, "_arg6":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1487
    move-object v0, p0

    invoke-virtual/range {v0 .. v7}, Landroid/app/IOplusActivityManager$Stub;->unfreezeForKernelTargetPid(IIIIILjava/lang/String;I)V

    .line 1488
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1489
    goto :goto_d20

    .line 1456
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":I
    .end local v5    # "_arg4":I
    .end local v6    # "_arg5":Ljava/lang/String;
    .end local v7    # "_arg6":I
    :pswitch_d01
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 1458
    .restart local v1    # "_arg0":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    .line 1460
    .restart local v2    # "_arg1":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    .line 1462
    .restart local v3    # "_arg2":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    .line 1464
    .local v4, "_arg3":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    .line 1465
    .restart local v5    # "_arg4":I
    invoke-virtual {p2}, Landroid/os/Parcel;->enforceNoDataAvail()V

    .line 1466
    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/app/IOplusActivityManager$Stub;->unfreezeForKernel(IIILjava/lang/String;I)V

    .line 1467
    invoke-virtual {v10}, Landroid/os/Parcel;->writeNoException()V

    .line 1468
    nop

    .line 3190
    .end local v1    # "_arg0":I
    .end local v2    # "_arg1":I
    .end local v3    # "_arg2":I
    .end local v4    # "_arg3":Ljava/lang/String;
    .end local v5    # "_arg4":I
    :goto_d20
    return v12

    nop

    :pswitch_data_d22
    .packed-switch 0x1
        :pswitch_d01
        :pswitch_cda
        :pswitch_ccb
        :pswitch_cbc
        :pswitch_cb1
        :pswitch_c9e
        :pswitch_c8a
        :pswitch_c6d
        :pswitch_c59
        :pswitch_c4d
        :pswitch_c41
        :pswitch_c2a
        :pswitch_c1b
        :pswitch_c0f
        :pswitch_bfc
        :pswitch_be9
        :pswitch_bda
        :pswitch_bc3
        :pswitch_bb0
        :pswitch_b9d
        :pswitch_b91
        :pswitch_b69
        :pswitch_b56
        :pswitch_b4a
        :pswitch_b33
        :pswitch_b18
        :pswitch_b05
        :pswitch_af9
        :pswitch_ae2
        :pswitch_acb
        :pswitch_abf
        :pswitch_ab3
        :pswitch_aa0
        :pswitch_a8d
        :pswitch_a81
        :pswitch_a6e
        :pswitch_a5b
        :pswitch_a48
        :pswitch_a35
        :pswitch_a22
        :pswitch_a13
        :pswitch_9f0
        :pswitch_9d5
        :pswitch_9c2
        :pswitch_9b6
        :pswitch_9a7
        :pswitch_994
        :pswitch_981
        :pswitch_975
        :pswitch_969
        :pswitch_952
        :pswitch_93f
        :pswitch_92c
        :pswitch_915
        :pswitch_902
        :pswitch_8fa
        :pswitch_8f2
        :pswitch_8e6
        :pswitch_8da
        :pswitch_8c7
        :pswitch_8b4
        :pswitch_8a1
        :pswitch_895
        :pswitch_86c
        :pswitch_850
        :pswitch_830
        :pswitch_80c
        :pswitch_7f9
        :pswitch_7dc
        :pswitch_7c9
        :pswitch_7ae
        :pswitch_793
        :pswitch_778
        :pswitch_76c
        :pswitch_754
        :pswitch_73d
        :pswitch_731
        :pswitch_71a
        :pswitch_70e
        :pswitch_6fb
        :pswitch_6df
        :pswitch_6cc
        :pswitch_6b5
        :pswitch_696
        :pswitch_677
        :pswitch_664
        :pswitch_651
        :pswitch_63e
        :pswitch_627
        :pswitch_614
        :pswitch_601
        :pswitch_5ee
        :pswitch_5db
        :pswitch_5c8
        :pswitch_5b5
        :pswitch_59e
        :pswitch_592
        :pswitch_577
        :pswitch_55c
        :pswitch_545
        :pswitch_529
        :pswitch_512
        :pswitch_4fb
        :pswitch_4eb
        :pswitch_4d0
        :pswitch_4bd
        :pswitch_4aa
        :pswitch_497
        :pswitch_487
        :pswitch_470
        :pswitch_45c
        :pswitch_448
        :pswitch_43c
        :pswitch_425
        :pswitch_40e
        :pswitch_402
        :pswitch_3ef
        :pswitch_3dc
        :pswitch_3c5
        :pswitch_3ae
        :pswitch_38d
        :pswitch_36e
        :pswitch_34f
        :pswitch_33c
        :pswitch_330
        :pswitch_31d
        :pswitch_306
        :pswitch_2de
        :pswitch_2ce
        :pswitch_2bb
        :pswitch_2a4
        :pswitch_291
        :pswitch_285
        :pswitch_272
        :pswitch_25f
        :pswitch_23c
        :pswitch_230
        :pswitch_216
        :pswitch_203
        :pswitch_1f7
        :pswitch_1e4
        :pswitch_1d1
        :pswitch_1be
        :pswitch_1ab
        :pswitch_188
        :pswitch_171
        :pswitch_15e
        :pswitch_152
        :pswitch_137
        :pswitch_124
        :pswitch_111
        :pswitch_fe
        :pswitch_eb
        :pswitch_d4
        :pswitch_c0
        :pswitch_a0
        :pswitch_8d
        :pswitch_76
        :pswitch_5f
        :pswitch_44
        :pswitch_2d
        :pswitch_21
    .end packed-switch
.end method
