.class public Landroid/app/OplusActivityManager$TaskSnapshotWrapper;
.super Ljava/lang/Object;
.source "OplusActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/OplusActivityManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "TaskSnapshotWrapper"
.end annotation


# instance fields
.field blacklist mTaskSnapshot:Landroid/window/TaskSnapshot;


# direct methods
.method public constructor blacklist <init>(Landroid/window/TaskSnapshot;)V
    .registers 2
    .param p1, "taskSnapshot"    # Landroid/window/TaskSnapshot;

    .line 1061
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1062
    iput-object p1, p0, Landroid/app/OplusActivityManager$TaskSnapshotWrapper;->mTaskSnapshot:Landroid/window/TaskSnapshot;

    .line 1063
    return-void
.end method


# virtual methods
.method public whitelist destroy()V
    .registers 2

    .line 1070
    :try_start_0
    iget-object v0, p0, Landroid/app/OplusActivityManager$TaskSnapshotWrapper;->mTaskSnapshot:Landroid/window/TaskSnapshot;

    if-eqz v0, :cond_f

    .line 1071
    iget-object v0, p0, Landroid/app/OplusActivityManager$TaskSnapshotWrapper;->mTaskSnapshot:Landroid/window/TaskSnapshot;

    invoke-virtual {v0}, Landroid/window/TaskSnapshot;->getSnapshot()Landroid/graphics/GraphicBuffer;

    move-result-object v0

    .line 1072
    .local v0, "snapshotInfo":Landroid/graphics/GraphicBuffer;
    if-eqz v0, :cond_f

    .line 1073
    invoke-virtual {v0}, Landroid/graphics/GraphicBuffer;->destroy()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_f} :catch_10

    .line 1078
    .end local v0    # "snapshotInfo":Landroid/graphics/GraphicBuffer;
    :cond_f
    goto :goto_14

    .line 1076
    :catch_10
    move-exception v0

    .line 1077
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 1079
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_14
    return-void
.end method

.method public whitelist getSnapshotBitmap()Landroid/graphics/Bitmap;
    .registers 2

    .line 1085
    const/4 v0, 0x0

    return-object v0
.end method
