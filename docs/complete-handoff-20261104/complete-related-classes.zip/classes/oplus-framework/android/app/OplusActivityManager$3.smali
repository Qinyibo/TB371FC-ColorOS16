.class Landroid/app/OplusActivityManager$3;
.super Landroid/app/IProcessObserver$Stub;
.source "OplusActivityManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/app/OplusActivityManager;->registerProcessObserver(Lcom/oplus/wrapper/app/IProcessObserver;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic blacklist val$observer:Lcom/oplus/wrapper/app/IProcessObserver;


# direct methods
.method constructor blacklist <init>(Landroid/app/OplusActivityManager;Lcom/oplus/wrapper/app/IProcessObserver;)V
    .registers 3
    .param p1, "this$0"    # Landroid/app/OplusActivityManager;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 4300
    iput-object p2, p0, Landroid/app/OplusActivityManager$3;->val$observer:Lcom/oplus/wrapper/app/IProcessObserver;

    invoke-direct {p0}, Landroid/app/IProcessObserver$Stub;-><init>()V

    return-void
.end method


# virtual methods
.method public blacklist onForegroundActivitiesChanged(IIZ)V
    .registers 5
    .param p1, "pid"    # I
    .param p2, "uid"    # I
    .param p3, "foregroundActivities"    # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4308
    iget-object v0, p0, Landroid/app/OplusActivityManager$3;->val$observer:Lcom/oplus/wrapper/app/IProcessObserver;

    invoke-interface {v0, p1, p2, p3}, Lcom/oplus/wrapper/app/IProcessObserver;->onForegroundActivitiesChanged(IIZ)V

    .line 4309
    return-void
.end method

.method public blacklist onForegroundServicesChanged(III)V
    .registers 5
    .param p1, "pid"    # I
    .param p2, "uid"    # I
    .param p3, "serviceTypes"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4313
    iget-object v0, p0, Landroid/app/OplusActivityManager$3;->val$observer:Lcom/oplus/wrapper/app/IProcessObserver;

    invoke-interface {v0, p1, p2, p3}, Lcom/oplus/wrapper/app/IProcessObserver;->onForegroundServicesChanged(III)V

    .line 4314
    return-void
.end method

.method public blacklist onProcessDied(II)V
    .registers 4
    .param p1, "pid"    # I
    .param p2, "uid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4318
    iget-object v0, p0, Landroid/app/OplusActivityManager$3;->val$observer:Lcom/oplus/wrapper/app/IProcessObserver;

    invoke-interface {v0, p1, p2}, Lcom/oplus/wrapper/app/IProcessObserver;->onProcessDied(II)V

    .line 4319
    return-void
.end method

.method public blacklist onProcessStarted(IIILjava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "pid"    # I
    .param p2, "processUid"    # I
    .param p3, "packageUid"    # I
    .param p4, "packageName"    # Ljava/lang/String;
    .param p5, "processName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 4304
    return-void
.end method
