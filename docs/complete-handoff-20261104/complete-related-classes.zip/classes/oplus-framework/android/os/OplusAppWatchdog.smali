.class public Landroid/os/OplusAppWatchdog;
.super Ljava/lang/Object;
.source "OplusAppWatchdog.java"


# static fields
.field private static final blacklist APP_ID:I = 0x4e72

.field private static final blacklist EVENT_ID:Ljava/lang/String; = "render_thread_block_timeout"

.field private static final blacklist TAG:Ljava/lang/String; = "OplusAppWatchdog"

.field private static final blacklist WATCHDOG_MONITOR_INTERVAL_MS:I = 0x3e8

.field private static final blacklist WATCHDOG_MONITOR_TIMEOUT_MS:I = 0xbb8

.field private static volatile blacklist sInstance:Landroid/os/OplusAppWatchdog;


# instance fields
.field private blacklist mNeedMonitor:Z

.field private volatile blacklist mScreenOff:Z

.field private blacklist mThreadRenders:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Landroid/graphics/HardwareRenderer;",
            ">;"
        }
    .end annotation
.end field

.field private final blacklist mWatchdogLock:Ljava/lang/Object;

.field private blacklist mWatchdogThread:Ljava/lang/Thread;


# direct methods
.method public static synthetic blacklist $r8$lambda$-bKg0ebxAuXjowcdN2VvHgW9u3A(Landroid/os/OplusAppWatchdog;)V
    .registers 1

    invoke-direct {p0}, Landroid/os/OplusAppWatchdog;->run()V

    return-void
.end method

.method private constructor blacklist <init>()V
    .registers 4

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    .line 23
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mNeedMonitor:Z

    .line 24
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mScreenOff:Z

    .line 39
    const-string/jumbo v1, "persist.sys.assert.panic"

    invoke-static {v1, v0}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_3b

    .line 40
    const-string/jumbo v1, "persist.sys.agingtest"

    const-string v2, "0"

    invoke-static {v1, v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "1"

    invoke-virtual {v2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3b

    .line 41
    const-string/jumbo v1, "ro.build.version.ota"

    const-string v2, ""

    invoke-static {v1, v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "PRE"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_45

    .line 42
    :cond_3b
    iput-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mNeedMonitor:Z

    .line 43
    const-string v0, "OplusAppWatchdog"

    const-string/jumbo v1, "monitor disabled"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 45
    :cond_45
    return-void
.end method

.method public static blacklist getInstance()Landroid/os/OplusAppWatchdog;
    .registers 2

    .line 27
    sget-object v0, Landroid/os/OplusAppWatchdog;->sInstance:Landroid/os/OplusAppWatchdog;

    if-nez v0, :cond_17

    .line 28
    const-class v0, Landroid/os/OplusAppWatchdog;

    monitor-enter v0

    .line 29
    :try_start_7
    sget-object v1, Landroid/os/OplusAppWatchdog;->sInstance:Landroid/os/OplusAppWatchdog;

    if-nez v1, :cond_12

    .line 30
    new-instance v1, Landroid/os/OplusAppWatchdog;

    invoke-direct {v1}, Landroid/os/OplusAppWatchdog;-><init>()V

    sput-object v1, Landroid/os/OplusAppWatchdog;->sInstance:Landroid/os/OplusAppWatchdog;

    .line 32
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 34
    :cond_17
    :goto_17
    sget-object v0, Landroid/os/OplusAppWatchdog;->sInstance:Landroid/os/OplusAppWatchdog;

    return-object v0
.end method

.method static synthetic blacklist lambda$addRenderThreadMonitor$0(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 4
    .param p0, "t"    # Ljava/lang/Thread;
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 58
    const-string v0, "OplusAppWatchdog"

    const-string/jumbo v1, "unexpected error"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method

.method private blacklist reportEventAndExit(JJJ)V
    .registers 21
    .param p1, "latestDrawStartTime"    # J
    .param p3, "latestDestroyStartTime"    # J
    .param p5, "monitorTime"    # J

    .line 128
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v12

    .line 129
    .local v12, "faultReportTime":J
    nop

    .line 131
    const/16 v0, 0x4e72

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    .line 133
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    .line 129
    const v0, 0x18bbf

    const/16 v1, 0x4e72

    const-string/jumbo v3, "render_thread_block_timeout"

    move-wide v6, p1

    move-wide/from16 v8, p3

    move-wide/from16 v10, p5

    invoke-static/range {v0 .. v13}, Lcom/oplus/android/internal/util/OplusFrameworkStatsLog;->write(IILjava/lang/String;Ljava/lang/String;JJJJJ)V

    .line 138
    const-string/jumbo v0, "persist.sys.oplus.render.block.time"

    const/16 v1, 0x1f4

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 139
    .local v1, "sleepTimeMills":I
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "render thread is blocked over 3000, latestDrawStartTime: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", latestDestroyStartTime: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", monitorTime: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", faultReportTime: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12, v13}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", sleepTimeMills: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", eventId: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const v2, 0x18bbf

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "OplusAppWatchdog"

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    if-lez v1, :cond_98

    .line 149
    int-to-long v3, v1

    :try_start_79
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7c
    .catch Ljava/lang/InterruptedException; {:try_start_79 .. :try_end_7c} :catch_7d

    .line 152
    goto :goto_98

    .line 150
    :catch_7d
    move-exception v0

    .line 151
    .local v0, "e":Ljava/lang/InterruptedException;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "error happened"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/InterruptedException;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 154
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :cond_98
    :goto_98
    const/16 v0, 0xa

    invoke-static {v0}, Ljava/lang/System;->exit(I)V

    .line 155
    return-void
.end method

.method private blacklist run()V
    .registers 21

    .line 89
    move-object/from16 v1, p0

    const-string v0, "OplusAppWatchdog"

    const-string/jumbo v2, "thread started"

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 90
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/16 v2, 0xa

    invoke-virtual {v0, v2}, Ljava/lang/Thread;->setPriority(I)V

    .line 92
    :goto_13
    const/4 v2, 0x0

    .line 93
    .local v2, "isRenderThreadBlocked":Z
    const-wide/16 v3, 0x0

    .line 94
    .local v3, "latestDrawStartTime":J
    const-wide/16 v5, 0x0

    .line 95
    .local v5, "latestDestroyStartTime":J
    const-wide/16 v7, 0x0

    .line 96
    .local v7, "monitorTime":J
    iget-object v9, v1, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    monitor-enter v9

    .line 97
    :try_start_1d
    iget-object v0, v1, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    invoke-static {v0}, Lcom/android/internal/util/CollectionUtils;->isEmpty(Ljava/util/Collection;)Z

    move-result v0

    if-nez v0, :cond_6d

    .line 98
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    move-wide v7, v10

    .line 99
    iget-object v0, v1, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_30
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_65

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/graphics/HardwareRenderer;

    .line 100
    .local v10, "threadedRenderer":Landroid/graphics/HardwareRenderer;
    invoke-virtual {v10}, Landroid/graphics/HardwareRenderer;->getLatestDrawStartTime()J

    move-result-wide v11

    move-wide v3, v11

    .line 101
    invoke-virtual {v10}, Landroid/graphics/HardwareRenderer;->getLatestDestroyStartTime()J

    move-result-wide v11
    :try_end_45
    .catchall {:try_start_1d .. :try_end_45} :catchall_b9

    move-wide v5, v11

    .line 102
    const-wide/16 v11, 0x0

    cmp-long v13, v3, v11

    const-wide/16 v14, 0xbb8

    if-lez v13, :cond_54

    sub-long v16, v7, v3

    cmp-long v13, v16, v14

    if-gtz v13, :cond_5e

    :cond_54
    cmp-long v11, v5, v11

    if-lez v11, :cond_64

    sub-long v11, v7, v5

    cmp-long v11, v11, v14

    if-lez v11, :cond_64

    .line 104
    :cond_5e
    const/4 v0, 0x1

    .line 105
    .end local v2    # "isRenderThreadBlocked":Z
    .local v0, "isRenderThreadBlocked":Z
    move-wide v2, v3

    move-wide v4, v5

    move-wide v6, v7

    move v8, v0

    goto :goto_74

    .line 107
    .end local v0    # "isRenderThreadBlocked":Z
    .end local v10    # "threadedRenderer":Landroid/graphics/HardwareRenderer;
    .restart local v2    # "isRenderThreadBlocked":Z
    :cond_64
    goto :goto_30

    .line 99
    :cond_65
    move-wide/from16 v18, v7

    move v8, v2

    move-wide v2, v3

    move-wide v4, v5

    move-wide/from16 v6, v18

    goto :goto_74

    .line 97
    :cond_6d
    move-wide/from16 v18, v7

    move v8, v2

    move-wide v2, v3

    move-wide v4, v5

    move-wide/from16 v6, v18

    .line 109
    .end local v3    # "latestDrawStartTime":J
    .end local v5    # "latestDestroyStartTime":J
    .end local v7    # "monitorTime":J
    .local v2, "latestDrawStartTime":J
    .local v4, "latestDestroyStartTime":J
    .local v6, "monitorTime":J
    .local v8, "isRenderThreadBlocked":Z
    :goto_74
    :try_start_74
    monitor-exit v9
    :try_end_75
    .catchall {:try_start_74 .. :try_end_75} :catchall_b0

    .line 110
    if-eqz v8, :cond_7a

    .line 111
    invoke-direct/range {v1 .. v7}, Landroid/os/OplusAppWatchdog;->reportEventAndExit(JJJ)V

    .line 114
    :cond_7a
    :try_start_7a
    iget-boolean v0, v1, Landroid/os/OplusAppWatchdog;->mScreenOff:Z

    if-eqz v0, :cond_8b

    .line 115
    iget-object v9, v1, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    monitor-enter v9
    :try_end_81
    .catch Ljava/lang/InterruptedException; {:try_start_7a .. :try_end_81} :catch_91

    .line 116
    :try_start_81
    iget-object v0, v1, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->wait()V

    .line 117
    monitor-exit v9

    goto :goto_90

    :catchall_88
    move-exception v0

    monitor-exit v9
    :try_end_8a
    .catchall {:try_start_81 .. :try_end_8a} :catchall_88

    .end local v2    # "latestDrawStartTime":J
    .end local v4    # "latestDestroyStartTime":J
    .end local v6    # "monitorTime":J
    .end local v8    # "isRenderThreadBlocked":Z
    .end local p0    # "this":Landroid/os/OplusAppWatchdog;
    :try_start_8a
    throw v0

    .line 119
    .restart local v2    # "latestDrawStartTime":J
    .restart local v4    # "latestDestroyStartTime":J
    .restart local v6    # "monitorTime":J
    .restart local v8    # "isRenderThreadBlocked":Z
    .restart local p0    # "this":Landroid/os/OplusAppWatchdog;
    :cond_8b
    const-wide/16 v9, 0x3e8

    invoke-static {v9, v10}, Ljava/lang/Thread;->sleep(J)V
    :try_end_90
    .catch Ljava/lang/InterruptedException; {:try_start_8a .. :try_end_90} :catch_91

    .line 123
    :goto_90
    goto :goto_ae

    .line 121
    :catch_91
    move-exception v0

    .line 122
    .local v0, "e":Ljava/lang/InterruptedException;
    const-string v9, "OplusAppWatchdog"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "error happened"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v0}, Ljava/lang/InterruptedException;->getMessage()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 124
    .end local v0    # "e":Ljava/lang/InterruptedException;
    .end local v2    # "latestDrawStartTime":J
    .end local v4    # "latestDestroyStartTime":J
    .end local v6    # "monitorTime":J
    .end local v8    # "isRenderThreadBlocked":Z
    :goto_ae
    goto/16 :goto_13

    .line 109
    .restart local v2    # "latestDrawStartTime":J
    .restart local v4    # "latestDestroyStartTime":J
    .restart local v6    # "monitorTime":J
    .restart local v8    # "isRenderThreadBlocked":Z
    :catchall_b0
    move-exception v0

    move-wide/from16 v18, v2

    move v2, v8

    move-wide v7, v6

    move-wide v5, v4

    move-wide/from16 v3, v18

    goto :goto_ba

    .end local v4    # "latestDestroyStartTime":J
    .end local v6    # "monitorTime":J
    .end local v8    # "isRenderThreadBlocked":Z
    .local v2, "isRenderThreadBlocked":Z
    .restart local v3    # "latestDrawStartTime":J
    .restart local v5    # "latestDestroyStartTime":J
    .restart local v7    # "monitorTime":J
    :catchall_b9
    move-exception v0

    :goto_ba
    :try_start_ba
    monitor-exit v9
    :try_end_bb
    .catchall {:try_start_ba .. :try_end_bb} :catchall_b9

    throw v0
.end method


# virtual methods
.method blacklist addRenderThreadMonitor(Landroid/graphics/HardwareRenderer;)V
    .registers 6
    .param p1, "threadedRenderer"    # Landroid/graphics/HardwareRenderer;

    .line 48
    iget-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mNeedMonitor:Z

    if-eqz v0, :cond_41

    if-nez p1, :cond_7

    goto :goto_41

    .line 51
    :cond_7
    iget-object v0, p0, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    monitor-enter v0

    .line 52
    :try_start_a
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    if-nez v1, :cond_16

    .line 53
    new-instance v1, Ljava/util/HashSet;

    const/4 v2, 0x2

    invoke-direct {v1, v2}, Ljava/util/HashSet;-><init>(I)V

    iput-object v1, p0, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    .line 55
    :cond_16
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 56
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mWatchdogThread:Ljava/lang/Thread;

    if-nez v1, :cond_3c

    .line 57
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda0;-><init>(Landroid/os/OplusAppWatchdog;)V

    const-string v3, "OplusAppWatchdog"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    iput-object v1, p0, Landroid/os/OplusAppWatchdog;->mWatchdogThread:Ljava/lang/Thread;

    .line 58
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mWatchdogThread:Ljava/lang/Thread;

    new-instance v2, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda1;

    invoke-direct {v2}, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda1;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    .line 59
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mWatchdogThread:Ljava/lang/Thread;

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 61
    :cond_3c
    monitor-exit v0

    .line 62
    return-void

    .line 61
    :catchall_3e
    move-exception v1

    monitor-exit v0
    :try_end_40
    .catchall {:try_start_a .. :try_end_40} :catchall_3e

    throw v1

    .line 49
    :cond_41
    :goto_41
    return-void
.end method

.method public blacklist notifyScreenStateChanged(Z)V
    .registers 5
    .param p1, "off"    # Z

    .line 76
    const-string v0, "OplusAppWatchdog"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "notifyScreenStateChanged, screenOff: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    iget-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mNeedMonitor:Z

    if-nez v0, :cond_1e

    .line 78
    return-void

    .line 80
    :cond_1e
    iput-boolean p1, p0, Landroid/os/OplusAppWatchdog;->mScreenOff:Z

    .line 81
    iget-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mScreenOff:Z

    if-nez v0, :cond_31

    .line 82
    iget-object v0, p0, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    monitor-enter v0

    .line 83
    :try_start_27
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->notify()V

    .line 84
    monitor-exit v0

    goto :goto_31

    :catchall_2e
    move-exception v1

    monitor-exit v0
    :try_end_30
    .catchall {:try_start_27 .. :try_end_30} :catchall_2e

    throw v1

    .line 86
    :cond_31
    :goto_31
    return-void
.end method

.method blacklist removeRenderThreadMonitor(Landroid/graphics/HardwareRenderer;)V
    .registers 4
    .param p1, "threadedRenderer"    # Landroid/graphics/HardwareRenderer;

    .line 65
    iget-boolean v0, p0, Landroid/os/OplusAppWatchdog;->mNeedMonitor:Z

    if-eqz v0, :cond_1c

    if-nez p1, :cond_7

    goto :goto_1c

    .line 68
    :cond_7
    iget-object v0, p0, Landroid/os/OplusAppWatchdog;->mWatchdogLock:Ljava/lang/Object;

    monitor-enter v0

    .line 69
    :try_start_a
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    invoke-static {v1}, Lcom/android/internal/util/CollectionUtils;->isEmpty(Ljava/util/Collection;)Z

    move-result v1

    if-nez v1, :cond_17

    .line 70
    iget-object v1, p0, Landroid/os/OplusAppWatchdog;->mThreadRenders:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 72
    :cond_17
    monitor-exit v0

    .line 73
    return-void

    .line 72
    :catchall_19
    move-exception v1

    monitor-exit v0
    :try_end_1b
    .catchall {:try_start_a .. :try_end_1b} :catchall_19

    throw v1

    .line 66
    :cond_1c
    :goto_1c
    return-void
.end method
