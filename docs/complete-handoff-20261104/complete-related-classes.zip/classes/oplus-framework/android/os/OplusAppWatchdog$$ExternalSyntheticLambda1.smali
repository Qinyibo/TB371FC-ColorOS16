.class public final synthetic Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# direct methods
.method public synthetic constructor blacklist <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final whitelist test-api uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 3

    .line 0
    invoke-static {p1, p2}, Landroid/os/OplusAppWatchdog;->lambda$addRenderThreadMonitor$0(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    return-void
.end method
