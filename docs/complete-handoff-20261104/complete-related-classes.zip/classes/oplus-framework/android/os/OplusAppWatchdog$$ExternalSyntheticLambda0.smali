.class public final synthetic Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic blacklist f$0:Landroid/os/OplusAppWatchdog;


# direct methods
.method public synthetic constructor blacklist <init>(Landroid/os/OplusAppWatchdog;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda0;->f$0:Landroid/os/OplusAppWatchdog;

    return-void
.end method


# virtual methods
.method public final whitelist test-api run()V
    .registers 2

    .line 0
    iget-object v0, p0, Landroid/os/OplusAppWatchdog$$ExternalSyntheticLambda0;->f$0:Landroid/os/OplusAppWatchdog;

    invoke-static {v0}, Landroid/os/OplusAppWatchdog;->$r8$lambda$-bKg0ebxAuXjowcdN2VvHgW9u3A(Landroid/os/OplusAppWatchdog;)V

    return-void
.end method
