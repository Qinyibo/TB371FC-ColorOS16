.class public Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt;
.super Ljava/lang/Object;
.source "SplitManagerExt.java"

# interfaces
.implements Lcom/oplus/oms/split/core/ISplitManagerExt;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt$Holder;
    }
.end annotation


# static fields
.field private static final blacklist TAG:Ljava/lang/String; = "SplitManagerExt"


# direct methods
.method private constructor blacklist <init>()V
    .registers 1

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    return-void
.end method

.method synthetic constructor blacklist <init>(Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt;-><init>()V

    return-void
.end method

.method public static blacklist get()Lcom/oplus/oms/split/core/ISplitManagerExt;
    .registers 1

    .line 44
    sget-object v0, Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt$Holder;->sInstance:Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt;

    return-object v0
.end method


# virtual methods
.method public blacklist getSplitClassLoader(Ljava/lang/String;)Ljava/lang/ClassLoader;
    .registers 3
    .param p1, "splitName"    # Ljava/lang/String;

    .line 152
    invoke-static {}, Lcom/oplus/oms/split/splitload/SplitApplicationLoaders;->getInstance()Lcom/oplus/oms/split/splitload/SplitApplicationLoaders;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/oplus/oms/split/splitload/SplitApplicationLoaders;->getClassLoader(Ljava/lang/String;)Lcom/oplus/oms/split/splitload/SplitDexClassLoader;

    move-result-object v0

    return-object v0
.end method

.method public blacklist getSplitVersionCode(Landroid/content/Context;Ljava/lang/String;)I
    .registers 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "splitName"    # Ljava/lang/String;

    .line 54
    invoke-static {p1, p2}, Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;->getSplitInstallVersion(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public blacklist loadNow(Landroid/app/Application;Ljava/util/Set;)V
    .registers 12
    .param p1, "app"    # Landroid/app/Application;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Application;",
            "Ljava/util/Set<",
            "Lcom/oplus/oms/split/common/SplitInfoData;",
            ">;)V"
        }
    .end annotation

    .line 115
    .local p2, "splitInfoDataSet":Ljava/util/Set;, "Ljava/util/Set<Lcom/oplus/oms/split/common/SplitInfoData;>;"
    invoke-static {}, Lcom/oplus/oms/split/splitload/SplitLoadManagerImpl;->hasInstance()Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "SplitManagerExt"

    if-nez v0, :cond_11

    .line 116
    const-string v0, "SplitLoadManagerImpl has not initialization"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v0, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 117
    return-void

    .line 119
    :cond_11
    invoke-static {}, Lcom/oplus/oms/split/splitload/SplitLoadManagerImpl;->getInstance()Lcom/oplus/oms/split/splitload/SplitLoadManager;

    move-result-object v0

    .line 120
    .local v0, "splitLoadManager":Lcom/oplus/oms/split/splitload/SplitLoadManager;
    if-nez v0, :cond_20

    .line 121
    const-string/jumbo v3, "splitLoadManager null"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v3, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 122
    return-void

    .line 124
    :cond_20
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 125
    .local v3, "splitFileIntents":Ljava/util/List;, "Ljava/util/List<Landroid/content/Intent;>;"
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_29
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_60

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/oplus/oms/split/common/SplitInfoData;

    .line 126
    .local v5, "splitInfoData":Lcom/oplus/oms/split/common/SplitInfoData;
    invoke-virtual {v5}, Lcom/oplus/oms/split/common/SplitInfoData;->getSplitName()Ljava/lang/String;

    move-result-object v6

    invoke-static {p1, v6}, Lcom/oplus/oms/split/splitload/SplitLoadManagerImpl;->getInstalledSplitIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v6

    .line 127
    .local v6, "intent":Landroid/content/Intent;
    if-nez v6, :cond_40

    .line 128
    goto :goto_29

    .line 130
    :cond_40
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5}, Lcom/oplus/oms/split/common/SplitInfoData;->getSplitName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " need to loadNow"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    new-array v8, v1, [Ljava/lang/Object;

    invoke-static {v2, v7, v8}, Lcom/oplus/oms/split/common/SplitLog;->i(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 131
    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 132
    .end local v5    # "splitInfoData":Lcom/oplus/oms/split/common/SplitInfoData;
    .end local v6    # "intent":Landroid/content/Intent;
    goto :goto_29

    .line 133
    :cond_60
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_6e

    .line 134
    const-string v4, "all splits has loaded"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v4, v1}, Lcom/oplus/oms/split/common/SplitLog;->i(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 135
    return-void

    .line 137
    :cond_6e
    new-instance v1, Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt$1;

    invoke-direct {v1, p0}, Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt$1;-><init>(Lcom/oplus/oms/split/core/splitmanager/SplitManagerExt;)V

    invoke-virtual {v0, v3, v1}, Lcom/oplus/oms/split/splitload/SplitLoadManager;->loadNow(Ljava/util/List;Lcom/oplus/oms/split/splitload/listener/OnSplitLoadListener;)V

    .line 148
    return-void
.end method

.method public blacklist scheduledDownload(Landroid/content/Context;Ljava/util/List;)Z
    .registers 9
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 59
    .local p2, "splitNames":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const-string v0, "SplitManagerExt"

    const/4 v1, 0x0

    if-eqz p1, :cond_40

    if-eqz p2, :cond_40

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v2

    if-nez v2, :cond_e

    goto :goto_40

    .line 63
    :cond_e
    invoke-static {p1, p2}, Lcom/oplus/oms/split/splitdownload/DownloadUtil;->buildDownloadRequests(Landroid/content/Context;Ljava/util/Collection;)Ljava/util/List;

    move-result-object v2

    .line 64
    .local v2, "downloadRequests":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/splitdownload/DownloadRequest;>;"
    if-eqz v2, :cond_38

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    if-nez v3, :cond_1b

    goto :goto_38

    .line 68
    :cond_1b
    invoke-static {}, Lcom/oplus/oms/split/core/splitmanager/OMSInitializer;->get()Lcom/oplus/oms/split/core/IOMSInitializer;

    move-result-object v3

    invoke-interface {v3}, Lcom/oplus/oms/split/core/IOMSInitializer;->getSplitConfiguration()Lcom/oplus/oms/split/core/SplitConfiguration;

    move-result-object v3

    invoke-virtual {v3}, Lcom/oplus/oms/split/core/SplitConfiguration;->getUpdateManager()Lcom/oplus/oms/split/splitdownload/ISplitUpdateManager;

    move-result-object v3

    .line 69
    .local v3, "updateManager":Lcom/oplus/oms/split/splitdownload/ISplitUpdateManager;
    if-eqz v3, :cond_2f

    .line 70
    const/4 v0, 0x1

    invoke-interface {v3, p1, v2, v0}, Lcom/oplus/oms/split/splitdownload/ISplitUpdateManager;->queryVersionFromCloud(Landroid/content/Context;Ljava/util/List;Z)Z

    move-result v0

    return v0

    .line 72
    :cond_2f
    const-string/jumbo v4, "the downloader is null. it can not execute scheduledDownload"

    new-array v5, v1, [Ljava/lang/Object;

    invoke-static {v0, v4, v5}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 73
    return v1

    .line 65
    .end local v3    # "updateManager":Lcom/oplus/oms/split/splitdownload/ISplitUpdateManager;
    :cond_38
    :goto_38
    const-string v3, "There are no plugins that need to be downloaded from the cloud"

    new-array v4, v1, [Ljava/lang/Object;

    invoke-static {v0, v3, v4}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 66
    return v1

    .line 60
    .end local v2    # "downloadRequests":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/splitdownload/DownloadRequest;>;"
    :cond_40
    :goto_40
    const-string/jumbo v2, "scheduledDownload context is null or splitNames is null"

    new-array v3, v1, [Ljava/lang/Object;

    invoke-static {v0, v2, v3}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 61
    return v1
.end method

.method public blacklist setNetworkStrategy(I)V
    .registers 2
    .param p1, "netWorkingType"    # I

    .line 49
    invoke-static {p1}, Lcom/oplus/oms/split/common/NetworkUtil;->setNetWorkStrategy(I)V

    .line 50
    return-void
.end method

.method public blacklist unloadSplit(Landroid/content/Context;Ljava/lang/String;)V
    .registers 9
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "splitName"    # Ljava/lang/String;

    .line 79
    const-string v0, "SplitManagerExt"

    if-eqz p1, :cond_82

    if-nez p2, :cond_8

    goto/16 :goto_82

    .line 83
    :cond_8
    invoke-static {p2}, Lcom/oplus/oms/split/common/SplitProcessUtils;->getSubProcessInfoData(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    .line 84
    .local v1, "subProcess":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/common/ProcessInfoData;>;"
    if-eqz v1, :cond_38

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_38

    .line 85
    new-instance v2, Landroid/util/ArraySet;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    invoke-direct {v2, v3}, Landroid/util/ArraySet;-><init>(I)V

    .line 86
    .local v2, "processNames":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_21
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_35

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/oplus/oms/split/common/ProcessInfoData;

    .line 87
    .local v4, "pi":Lcom/oplus/oms/split/common/ProcessInfoData;
    invoke-virtual {v4}, Lcom/oplus/oms/split/common/ProcessInfoData;->getProcessName()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 88
    .end local v4    # "pi":Lcom/oplus/oms/split/common/ProcessInfoData;
    goto :goto_21

    .line 89
    :cond_35
    invoke-static {p1, v2}, Lcom/oplus/oms/split/common/ProcessUtil;->killProcess(Landroid/content/Context;Ljava/util/Set;)V

    .line 92
    .end local v2    # "processNames":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    :cond_38
    invoke-static {p2}, Lcom/oplus/oms/split/common/SplitProcessUtils;->getMainProcessInfoData(Ljava/lang/String;)Lcom/oplus/oms/split/common/ProcessInfoData;

    move-result-object v2

    .line 93
    .local v2, "mainProcess":Lcom/oplus/oms/split/common/ProcessInfoData;
    const/4 v3, 0x0

    .line 94
    .local v3, "action":Ljava/lang/String;
    if-nez v2, :cond_43

    .line 95
    const-string/jumbo v3, "main_process"

    goto :goto_51

    .line 96
    :cond_43
    invoke-virtual {v2}, Lcom/oplus/oms/split/common/ProcessInfoData;->getProcessName()Ljava/lang/String;

    move-result-object v4

    invoke-static {p1, v4}, Lcom/oplus/oms/split/common/ProcessUtil;->isProcessAlive(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_51

    .line 97
    invoke-virtual {v2}, Lcom/oplus/oms/split/common/ProcessInfoData;->getActionName()Ljava/lang/String;

    move-result-object v3

    .line 100
    :cond_51
    :goto_51
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_62

    .line 101
    const-string/jumbo v4, "unloadSplit action is null, split: %s"

    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v4, v5}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 102
    return-void

    .line 105
    :cond_62
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 106
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {v0, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 107
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 108
    const-string/jumbo v4, "split_name"

    invoke-virtual {v0, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 109
    const-string/jumbo v4, "load_type"

    const/4 v5, 0x1

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 110
    invoke-static {p1, v0}, Lcom/oplus/oms/split/splitload/SplitBroadcastReceiver;->broadcast(Landroid/content/Context;Landroid/content/Intent;)V

    .line 111
    return-void

    .line 80
    .end local v0    # "intent":Landroid/content/Intent;
    .end local v1    # "subProcess":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/common/ProcessInfoData;>;"
    .end local v2    # "mainProcess":Lcom/oplus/oms/split/common/ProcessInfoData;
    .end local v3    # "action":Ljava/lang/String;
    :cond_82
    :goto_82
    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const-string/jumbo v2, "unloadSplit context is null or splitNames is null"

    invoke-static {v0, v2, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 81
    return-void
.end method
