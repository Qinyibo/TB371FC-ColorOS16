.class public Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;
.super Ljava/lang/Object;
.source "SplitInstallUtil.java"


# static fields
.field private static final blacklist TAG:Ljava/lang/String; = "SplitInstallUtils"


# direct methods
.method private constructor blacklist <init>()V
    .registers 1

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    return-void
.end method

.method public static blacklist getSplitInstallVersion(Landroid/content/Context;Ljava/lang/String;)I
    .registers 6
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;

    .line 86
    const/4 v0, -0x1

    if-eqz p0, :cond_30

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_30

    .line 90
    :cond_a
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "_INSTALL_VERSION"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 91
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 90
    invoke-virtual {v1, v2, v0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->get(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 87
    :cond_30
    :goto_30
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getSplitInstallStatus fail, SplitName = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const-string v3, "SplitInstallUtils"

    invoke-static {v3, v1, v2}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 88
    return v0
.end method

.method public static blacklist getSplitLoadFailMD5(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;
    .registers 6
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;
    .param p2, "version"    # I

    .line 50
    if-eqz p0, :cond_2d

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_2d

    .line 55
    :cond_9
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_LOADED_FAIL_MD5_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->get(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 57
    .local v0, "md5":Ljava/lang/String;
    return-object v0

    .line 51
    .end local v0    # "md5":Ljava/lang/String;
    :cond_2d
    :goto_2d
    nop

    .line 52
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {p1, v0}, [Ljava/lang/Object;

    move-result-object v0

    .line 51
    const-string v1, "SplitInstallUtils"

    const-string/jumbo v2, "markSplitLoadedFailMD5 fail, SplitName:%s , version:%d"

    invoke-static {v1, v2, v0}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 53
    const/4 v0, 0x0

    return-object v0
.end method

.method public static blacklist getSplitLoadSuccessVersion(Landroid/content/Context;Ljava/lang/String;)I
    .registers 6
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;

    .line 103
    const/4 v0, -0x1

    if-eqz p0, :cond_30

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_30

    .line 107
    :cond_a
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "_LOADED_SUCCESS"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 108
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 107
    invoke-virtual {v1, v2, v0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->get(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 104
    :cond_30
    :goto_30
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getSplitLoadSuccessVersion fail, SplitName = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const-string v3, "SplitInstallUtils"

    invoke-static {v3, v1, v2}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 105
    return v0
.end method

.method private static blacklist getSplitNativeLibAbi(Lcom/oplus/oms/split/splitrequest/SplitInfo;Landroid/content/Context;)Ljava/lang/String;
    .registers 10
    .param p0, "splitInfo"    # Lcom/oplus/oms/split/splitrequest/SplitInfo;
    .param p1, "context"    # Landroid/content/Context;

    .line 164
    const/4 v0, 0x0

    const/4 v1, 0x0

    const-string v2, "SplitInstallUtils"

    if-eqz p0, :cond_40

    if-nez p1, :cond_9

    goto :goto_40

    .line 168
    :cond_9
    invoke-virtual {p0}, Lcom/oplus/oms/split/splitrequest/SplitInfo;->getSplitName()Ljava/lang/String;

    move-result-object v3

    .line 169
    .local v3, "splitName":Ljava/lang/String;
    const/4 v4, 0x0

    .line 171
    .local v4, "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    :try_start_e
    invoke-virtual {p0, p1}, Lcom/oplus/oms/split/splitrequest/SplitInfo;->getPrimaryLibData(Landroid/content/Context;)Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;

    move-result-object v5
    :try_end_12
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_12} :catch_22

    .line 175
    .end local v4    # "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    .local v5, "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    nop

    .line 176
    if-nez v5, :cond_1d

    .line 177
    const-string v4, "getSplitNativeLibAbi libData is null"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v4, v1}, Lcom/oplus/oms/split/common/SplitLog;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 178
    return-object v0

    .line 180
    :cond_1d
    invoke-virtual {v5}, Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;->getAbi()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 172
    .end local v5    # "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    .restart local v4    # "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    :catch_22
    move-exception v5

    .line 173
    .local v5, "e":Ljava/io/IOException;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "getSplitNativeLibAbi error "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v6, v1}, Lcom/oplus/oms/split/common/SplitLog;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 174
    return-object v0

    .line 165
    .end local v3    # "splitName":Ljava/lang/String;
    .end local v4    # "libData":Lcom/oplus/oms/split/splitrequest/SplitInfo$LibData;
    .end local v5    # "e":Ljava/io/IOException;
    :cond_40
    :goto_40
    const-string v3, "getSplitNativeLibAbi fail"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v2, v3, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 166
    return-object v0
.end method

.method private static blacklist putFileSplitVersion(Ljava/lang/String;I)V
    .registers 9
    .param p0, "splitName"    # Ljava/lang/String;
    .param p1, "version"    # I

    .line 72
    const-string v0, "SplitInstallUtils"

    invoke-static {}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->require()Lcom/oplus/oms/split/splitrequest/SplitPathManager;

    move-result-object v1

    invoke-virtual {v1, p0}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->getSplitDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    .line 73
    .local v1, "splitDir":Ljava/io/File;
    new-instance v2, Ljava/io/File;

    const-string v3, "SplitCopier.lock"

    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 74
    .local v2, "versionCodeFile":Ljava/io/File;
    :try_start_11
    new-instance v3, Ljava/io/BufferedWriter;

    new-instance v4, Ljava/io/OutputStreamWriter;

    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v4, v5, v6}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_22
    .catch Ljava/io/FileNotFoundException; {:try_start_11 .. :try_end_22} :catch_3d
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_22} :catch_36

    .line 76
    .local v3, "fileWriter":Ljava/io/BufferedWriter;
    :try_start_22
    invoke-virtual {v3, p1}, Ljava/io/BufferedWriter;->write(I)V

    .line 77
    invoke-virtual {v3}, Ljava/io/BufferedWriter;->flush()V
    :try_end_28
    .catchall {:try_start_22 .. :try_end_28} :catchall_2c

    .line 78
    :try_start_28
    invoke-virtual {v3}, Ljava/io/BufferedWriter;->close()V
    :try_end_2b
    .catch Ljava/io/FileNotFoundException; {:try_start_28 .. :try_end_2b} :catch_3d
    .catch Ljava/io/IOException; {:try_start_28 .. :try_end_2b} :catch_36

    goto :goto_43

    .line 74
    :catchall_2c
    move-exception v4

    :try_start_2d
    invoke-virtual {v3}, Ljava/io/BufferedWriter;->close()V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_35

    :catchall_31
    move-exception v5

    :try_start_32
    invoke-virtual {v4, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v1    # "splitDir":Ljava/io/File;
    .end local v2    # "versionCodeFile":Ljava/io/File;
    .end local p0    # "splitName":Ljava/lang/String;
    .end local p1    # "version":I
    :goto_35
    throw v4
    :try_end_36
    .catch Ljava/io/FileNotFoundException; {:try_start_32 .. :try_end_36} :catch_3d
    .catch Ljava/io/IOException; {:try_start_32 .. :try_end_36} :catch_36

    .line 80
    .end local v3    # "fileWriter":Ljava/io/BufferedWriter;
    .restart local v1    # "splitDir":Ljava/io/File;
    .restart local v2    # "versionCodeFile":Ljava/io/File;
    .restart local p0    # "splitName":Ljava/lang/String;
    .restart local p1    # "version":I
    :catch_36
    move-exception v3

    .line 81
    .local v3, "e":Ljava/io/IOException;
    const-string v4, "clean up split version code error"

    invoke-static {v0, v4, v3}, Lcom/oplus/oms/split/common/SplitLog;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_44

    .line 78
    .end local v3    # "e":Ljava/io/IOException;
    :catch_3d
    move-exception v3

    .line 79
    .local v3, "e":Ljava/io/FileNotFoundException;
    const-string v4, "SplitCopier.lock no found"

    invoke-static {v0, v4, v3}, Lcom/oplus/oms/split/common/SplitLog;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 82
    .end local v3    # "e":Ljava/io/FileNotFoundException;
    :goto_43
    nop

    .line 83
    :goto_44
    return-void
.end method

.method private static blacklist putNativeLibDirAccessStatus(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 6
    .param p0, "splitName"    # Ljava/lang/String;
    .param p1, "abi"    # Ljava/lang/String;
    .param p2, "installedVersion"    # I

    .line 185
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_26

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_26

    const/4 v0, -0x1

    if-ne p2, v0, :cond_10

    goto :goto_26

    .line 190
    :cond_10
    invoke-static {}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->require()Lcom/oplus/oms/split/splitrequest/SplitPathManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1, p2}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->getSplitLibDir(Ljava/lang/String;Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    .line 192
    .local v0, "splitLibDir":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_25

    .line 193
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/io/File;->setWritable(Z)Z

    .line 194
    invoke-virtual {v0, v1}, Ljava/io/File;->setExecutable(Z)Z

    .line 197
    :cond_25
    return-void

    .line 187
    .end local v0    # "splitLibDir":Ljava/io/File;
    :cond_26
    :goto_26
    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "SplitInstallUtils"

    const-string/jumbo v2, "setNativeLibDirAccessStatus failed"

    invoke-static {v1, v2, v0}, Lcom/oplus/oms/split/common/SplitLog;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 188
    return-void
.end method

.method public static blacklist putSplitInstallVersion(Landroid/content/Context;Ljava/lang/String;I)V
    .registers 6
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;
    .param p2, "version"    # I

    .line 62
    if-eqz p0, :cond_2b

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_2b

    .line 67
    :cond_9
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_INSTALL_VERSION"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->put(Ljava/lang/String;Ljava/lang/Object;)V

    .line 68
    invoke-static {p1, p2}, Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;->putFileSplitVersion(Ljava/lang/String;I)V

    .line 69
    return-void

    .line 63
    :cond_2b
    :goto_2b
    nop

    .line 64
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {p1, v0}, [Ljava/lang/Object;

    move-result-object v0

    .line 63
    const-string v1, "SplitInstallUtils"

    const-string/jumbo v2, "setSplitInstallStatus fail, SplitName:%s , version:%d"

    invoke-static {v1, v2, v0}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 65
    return-void
.end method

.method public static blacklist putSplitLoadSuccessVersion(Landroid/content/Context;Ljava/lang/String;I)V
    .registers 6
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;
    .param p2, "version"    # I

    .line 95
    if-eqz p0, :cond_28

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_28

    .line 99
    :cond_9
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_LOADED_SUCCESS"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->put(Ljava/lang/String;Ljava/lang/Object;)V

    .line 100
    return-void

    .line 96
    :cond_28
    :goto_28
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "putSplitLoadSuccessVersion fail, SplitName = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "SplitInstallUtils"

    invoke-static {v2, v0, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 97
    return-void
.end method

.method public static blacklist putSplitLoadedFailMD5(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V
    .registers 7
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "splitName"    # Ljava/lang/String;
    .param p2, "version"    # I
    .param p3, "md5"    # Ljava/lang/String;

    .line 40
    if-eqz p0, :cond_28

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_28

    .line 45
    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "_LOADED_FAIL_MD5_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 46
    .local v0, "Key":Ljava/lang/String;
    invoke-static {p0}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->getInstance(Landroid/content/Context;)Lcom/oplus/oms/split/common/SharedPreferencesUtil;

    move-result-object v1

    invoke-virtual {v1, v0, p3}, Lcom/oplus/oms/split/common/SharedPreferencesUtil;->put(Ljava/lang/String;Ljava/lang/Object;)V

    .line 47
    return-void

    .line 41
    .end local v0    # "Key":Ljava/lang/String;
    :cond_28
    :goto_28
    nop

    .line 42
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {p1, v0}, [Ljava/lang/Object;

    move-result-object v0

    .line 41
    const-string v1, "SplitInstallUtils"

    const-string/jumbo v2, "markSplitLoadedFailMD5 fail, SplitName:%s , version:%d"

    invoke-static {v1, v2, v0}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    return-void
.end method

.method public static blacklist removeInstallOtherFile(Lcom/oplus/oms/split/splitrequest/SplitInfo;ILandroid/content/Context;)V
    .registers 12
    .param p0, "splitInfo"    # Lcom/oplus/oms/split/splitrequest/SplitInfo;
    .param p1, "installedVersion"    # I
    .param p2, "context"    # Landroid/content/Context;

    .line 113
    const/4 v0, 0x0

    if-eqz p0, :cond_55

    if-eqz p2, :cond_55

    const/4 v1, -0x1

    if-ne p1, v1, :cond_9

    goto :goto_55

    .line 117
    :cond_9
    invoke-virtual {p0}, Lcom/oplus/oms/split/splitrequest/SplitInfo;->getSplitName()Ljava/lang/String;

    move-result-object v1

    .line 118
    .local v1, "splitName":Ljava/lang/String;
    invoke-static {}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->require()Lcom/oplus/oms/split/splitrequest/SplitPathManager;

    move-result-object v2

    invoke-virtual {v2, v1, p1, v0}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->getSplitApkDir(Ljava/lang/String;IZ)Ljava/io/File;

    move-result-object v0

    .line 120
    .local v0, "splitApkDir":Ljava/io/File;
    const/4 v2, 0x0

    .line 121
    .local v2, "abi":Ljava/lang/String;
    nop

    .line 122
    invoke-static {p0, p2}, Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;->getSplitNativeLibAbi(Lcom/oplus/oms/split/splitrequest/SplitInfo;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    .line 124
    invoke-static {v0, v2}, Lcom/oplus/oms/split/common/FileUtil;->deleteOthersDirs(Ljava/io/File;Ljava/lang/String;)Z

    .line 125
    invoke-static {v1}, Lcom/oplus/oms/split/common/SplitProcessUtils;->getSubProcessInfoData(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    .line 126
    .local v3, "subInfoList":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/common/ProcessInfoData;>;"
    new-instance v4, Ljava/util/HashSet;

    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    .line 127
    .local v4, "subProcessSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_4b

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/oplus/oms/split/common/ProcessInfoData;

    .line 128
    .local v6, "sub":Lcom/oplus/oms/split/common/ProcessInfoData;
    invoke-virtual {v6}, Lcom/oplus/oms/split/common/ProcessInfoData;->getProcessName()Ljava/lang/String;

    move-result-object v7

    .line 129
    .local v7, "processName":Ljava/lang/String;
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_4a

    invoke-interface {v4, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4a

    .line 130
    invoke-interface {v4, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 132
    .end local v6    # "sub":Lcom/oplus/oms/split/common/ProcessInfoData;
    .end local v7    # "processName":Ljava/lang/String;
    :cond_4a
    goto :goto_2b

    .line 133
    :cond_4b
    invoke-interface {v4}, Ljava/util/Set;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_54

    .line 134
    invoke-static {p2, v4}, Lcom/oplus/oms/split/common/ProcessUtil;->killProcess(Landroid/content/Context;Ljava/util/Set;)V

    .line 136
    :cond_54
    return-void

    .line 114
    .end local v0    # "splitApkDir":Ljava/io/File;
    .end local v1    # "splitName":Ljava/lang/String;
    .end local v2    # "abi":Ljava/lang/String;
    .end local v3    # "subInfoList":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/oms/split/common/ProcessInfoData;>;"
    .end local v4    # "subProcessSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    :cond_55
    :goto_55
    const-string/jumbo v1, "removeInstallOtherFile failed"

    new-array v0, v0, [Ljava/lang/Object;

    const-string v2, "SplitInstallUtils"

    invoke-static {v2, v1, v0}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 115
    return-void
.end method

.method public static blacklist removeSplitInstalledFile(Lcom/oplus/oms/split/splitrequest/SplitInfo;ILandroid/content/Context;)V
    .registers 8
    .param p0, "splitInfo"    # Lcom/oplus/oms/split/splitrequest/SplitInfo;
    .param p1, "installedVersion"    # I
    .param p2, "context"    # Landroid/content/Context;

    .line 140
    const-string v0, "SplitInstallUtils"

    const/4 v1, 0x0

    if-eqz p0, :cond_4a

    if-eqz p2, :cond_4a

    const/4 v2, -0x1

    if-ne p1, v2, :cond_b

    goto :goto_4a

    .line 144
    :cond_b
    invoke-virtual {p0}, Lcom/oplus/oms/split/splitrequest/SplitInfo;->getSplitName()Ljava/lang/String;

    move-result-object v2

    .line 145
    .local v2, "splitName":Ljava/lang/String;
    invoke-static {}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->require()Lcom/oplus/oms/split/splitrequest/SplitPathManager;

    move-result-object v3

    invoke-virtual {v3, v2, p1, v1}, Lcom/oplus/oms/split/splitrequest/SplitPathManager;->getSplitApkDir(Ljava/lang/String;IZ)Ljava/io/File;

    move-result-object v3

    .line 147
    .local v3, "installedFile":Ljava/io/File;
    if-eqz v3, :cond_41

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_20

    goto :goto_41

    .line 151
    :cond_20
    nop

    .line 152
    invoke-static {p0, p2}, Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;->getSplitNativeLibAbi(Lcom/oplus/oms/split/splitrequest/SplitInfo;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    .line 153
    .local v4, "abi":Ljava/lang/String;
    invoke-static {v2, v4, p1}, Lcom/oplus/oms/split/splitrequest/SplitInstallUtil;->putNativeLibDirAccessStatus(Ljava/lang/String;Ljava/lang/String;I)V

    .line 155
    .end local v4    # "abi":Ljava/lang/String;
    invoke-static {v3}, Lcom/oplus/oms/split/common/FileUtil;->deleteDir(Ljava/io/File;)Z

    .line 156
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_39

    .line 157
    const-string v4, "Failed to delete corrupted split files"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v4, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_40

    .line 159
    :cond_39
    const-string v4, "delete success"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v4, v1}, Lcom/oplus/oms/split/common/SplitLog;->d(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 161
    :goto_40
    return-void

    .line 148
    :cond_41
    :goto_41
    const-string/jumbo v4, "removeSplitInstalledFile installed file is not existed"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v4, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 149
    return-void

    .line 141
    .end local v2    # "splitName":Ljava/lang/String;
    .end local v3    # "installedFile":Ljava/io/File;
    :cond_4a
    :goto_4a
    const-string/jumbo v2, "removeSplitInstalledFile failed"

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v2, v1}, Lcom/oplus/oms/split/common/SplitLog;->w(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 142
    return-void
.end method
