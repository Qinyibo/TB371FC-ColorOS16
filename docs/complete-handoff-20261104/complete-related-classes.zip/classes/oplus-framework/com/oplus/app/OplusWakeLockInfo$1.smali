.class Lcom/oplus/app/OplusWakeLockInfo$1;
.super Ljava/lang/Object;
.source "OplusWakeLockInfo.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/app/OplusWakeLockInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/oplus/app/OplusWakeLockInfo;",
        ">;"
    }
.end annotation


# direct methods
.method constructor blacklist <init>()V
    .registers 1

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public blacklist createFromParcel(Landroid/os/Parcel;)Lcom/oplus/app/OplusWakeLockInfo;
    .registers 3
    .param p1, "in"    # Landroid/os/Parcel;

    .line 34
    new-instance v0, Lcom/oplus/app/OplusWakeLockInfo;

    invoke-direct {v0, p1}, Lcom/oplus/app/OplusWakeLockInfo;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

.method public bridge synthetic whitelist createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 31
    invoke-virtual {p0, p1}, Lcom/oplus/app/OplusWakeLockInfo$1;->createFromParcel(Landroid/os/Parcel;)Lcom/oplus/app/OplusWakeLockInfo;

    move-result-object p1

    return-object p1
.end method

.method public blacklist newArray(I)[Lcom/oplus/app/OplusWakeLockInfo;
    .registers 3
    .param p1, "size"    # I

    .line 39
    new-array v0, p1, [Lcom/oplus/app/OplusWakeLockInfo;

    return-object v0
.end method

.method public bridge synthetic whitelist newArray(I)[Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            null
        }
    .end annotation

    .line 31
    invoke-virtual {p0, p1}, Lcom/oplus/app/OplusWakeLockInfo$1;->newArray(I)[Lcom/oplus/app/OplusWakeLockInfo;

    move-result-object p1

    return-object p1
.end method
