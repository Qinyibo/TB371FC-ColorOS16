.class public Lcom/oplus/app/KernelWakeLockInfo;
.super Ljava/lang/Object;
.source "KernelWakeLockInfo.java"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final whitelist CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/oplus/app/KernelWakeLockInfo;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public whitelist activeCount:J

.field public whitelist activeTime:J

.field public whitelist eventCount:J

.field public whitelist expireCount:J

.field public whitelist isActive:Z

.field public whitelist isKernelWakelock:Z

.field public whitelist lastChange:J

.field public whitelist maxTime:J

.field public whitelist name:Ljava/lang/String;

.field public whitelist pid:I

.field public whitelist preventSuspendTime:J

.field public whitelist totalTime:J

.field public whitelist wakeupCount:J


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 1

    .line 26
    new-instance v0, Lcom/oplus/app/KernelWakeLockInfo$1;

    invoke-direct {v0}, Lcom/oplus/app/KernelWakeLockInfo$1;-><init>()V

    sput-object v0, Lcom/oplus/app/KernelWakeLockInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor whitelist <init>()V
    .registers 4

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeCount:J

    .line 56
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->lastChange:J

    .line 62
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->maxTime:J

    .line 68
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->totalTime:J

    .line 74
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->isActive:Z

    .line 80
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeTime:J

    .line 86
    iput-boolean v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->isKernelWakelock:Z

    .line 93
    iput v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->pid:I

    .line 100
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->eventCount:J

    .line 107
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->expireCount:J

    .line 114
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->preventSuspendTime:J

    .line 121
    iput-wide v0, p0, Lcom/oplus/app/KernelWakeLockInfo;->wakeupCount:J

    return-void
.end method


# virtual methods
.method public whitelist describeContents()I
    .registers 2

    .line 215
    const/4 v0, 0x0

    .line 216
    .local v0, "mask":I
    return v0
.end method

.method public final blacklist readFromParcel(Landroid/os/Parcel;)V
    .registers 9
    .param p1, "aidlParcel"    # Landroid/os/Parcel;

    .line 153
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    .line 154
    .local v0, "aidlStartPos":I
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 156
    .local v1, "aidlParcelableSize":I
    if-ltz v1, :cond_116

    :try_start_a
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_13

    goto/16 :goto_116

    .line 159
    :cond_13
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->name:Ljava/lang/String;

    .line 160
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_1d
    .catchall {:try_start_a .. :try_end_1d} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_26

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 161
    return-void

    .line 163
    :cond_26
    :try_start_26
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeCount:J

    .line 164
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_30
    .catchall {:try_start_26 .. :try_end_30} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_39

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 165
    return-void

    .line 167
    :cond_39
    :try_start_39
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->lastChange:J

    .line 168
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_43
    .catchall {:try_start_39 .. :try_end_43} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_4c

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 169
    return-void

    .line 171
    :cond_4c
    :try_start_4c
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->maxTime:J

    .line 172
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_56
    .catchall {:try_start_4c .. :try_end_56} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_5f

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 173
    return-void

    .line 175
    :cond_5f
    :try_start_5f
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->totalTime:J

    .line 176
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_69
    .catchall {:try_start_5f .. :try_end_69} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_72

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 177
    return-void

    .line 179
    :cond_72
    :try_start_72
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_7c

    move v2, v3

    goto :goto_7d

    :cond_7c
    move v2, v4

    :goto_7d
    iput-boolean v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->isActive:Z

    .line 180
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_83
    .catchall {:try_start_72 .. :try_end_83} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_8c

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 181
    return-void

    .line 183
    :cond_8c
    :try_start_8c
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    iput-wide v5, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeTime:J

    .line 184
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_96
    .catchall {:try_start_8c .. :try_end_96} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_9f

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 185
    return-void

    .line 187
    :cond_9f
    :try_start_9f
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    if-eqz v2, :cond_a6

    goto :goto_a7

    :cond_a6
    move v3, v4

    :goto_a7
    iput-boolean v3, p0, Lcom/oplus/app/KernelWakeLockInfo;->isKernelWakelock:Z

    .line 188
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_ad
    .catchall {:try_start_9f .. :try_end_ad} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_b6

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 189
    return-void

    .line 191
    :cond_b6
    :try_start_b6
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    iput v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->pid:I

    .line 192
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_c0
    .catchall {:try_start_b6 .. :try_end_c0} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_c9

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 193
    return-void

    .line 195
    :cond_c9
    :try_start_c9
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->eventCount:J

    .line 196
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_d3
    .catchall {:try_start_c9 .. :try_end_d3} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_dc

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 197
    return-void

    .line 199
    :cond_dc
    :try_start_dc
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->expireCount:J

    .line 200
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_e6
    .catchall {:try_start_dc .. :try_end_e6} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_ef

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 201
    return-void

    .line 203
    :cond_ef
    :try_start_ef
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->preventSuspendTime:J

    .line 204
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2
    :try_end_f9
    .catchall {:try_start_ef .. :try_end_f9} :catchall_10f

    sub-int/2addr v2, v0

    if-lt v2, v1, :cond_102

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 205
    return-void

    .line 207
    :cond_102
    :try_start_102
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/oplus/app/KernelWakeLockInfo;->wakeupCount:J
    :try_end_108
    .catchall {:try_start_102 .. :try_end_108} :catchall_10f

    .line 209
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 210
    nop

    .line 211
    return-void

    .line 209
    :catchall_10f
    move-exception v2

    add-int v3, v0, v1

    invoke-virtual {p1, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 210
    throw v2

    .line 209
    :cond_116
    :goto_116
    add-int v2, v0, v1

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 157
    return-void
.end method

.method public final whitelist writeToParcel(Landroid/os/Parcel;I)V
    .registers 6
    .param p1, "aidlParcel"    # Landroid/os/Parcel;
    .param p2, "aidlFlag"    # I

    .line 125
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    .line 126
    .local v0, "aidlStartPos":I
    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 127
    iget-object v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->name:Ljava/lang/String;

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 128
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeCount:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 129
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->lastChange:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 130
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->maxTime:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 131
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->totalTime:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 132
    iget-boolean v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->isActive:Z

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 133
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->activeTime:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 134
    iget-boolean v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->isKernelWakelock:Z

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 135
    iget v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->pid:I

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 136
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->eventCount:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 137
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->expireCount:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 138
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->preventSuspendTime:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 139
    iget-wide v1, p0, Lcom/oplus/app/KernelWakeLockInfo;->wakeupCount:J

    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 140
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    .line 141
    .local v1, "aidlEndPos":I
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 142
    sub-int v2, v1, v0

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 143
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 144
    return-void
.end method
