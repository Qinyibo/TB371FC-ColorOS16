.class public Lcom/oplus/util/InstallFont;
.super Ljava/lang/Object;
.source "InstallFont.java"


# static fields
.field private static final blacklist DEBUG:Z

.field private static final blacklist TAG:Ljava/lang/String; = "InstallFont"

.field private static blacklist mAppWhiteList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static blacklist mInputMethodList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 2

    .line 24
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/oplus/util/InstallFont;->DEBUG:Z

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    .line 27
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/oplus/util/InstallFont;->mInputMethodList:Ljava/util/ArrayList;

    .line 35
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.mediatek.mtklogger"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.recents"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 37
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.recents"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.alarmclock"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.alarmclock"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 40
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.captiveportallogin"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.systemui"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.keyguard"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 43
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.settings"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 44
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.bootreg"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 45
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.launcher"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.weather"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 48
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.weather"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 49
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.music"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.gallery3d"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 51
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.nearme.themespace"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.color.safecenter"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.safecenter"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 55
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.filemanager"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 56
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.nearme.gamecenter"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 57
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.contacts"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string/jumbo v1, "oppo.multimedia.soundrecorder"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 59
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.soundrecorder"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.providers.downloads"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.backuprestore"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 62
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.backuprestore"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 63
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.reader"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 64
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.mms"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.usercenter"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oppo.community"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.nearme.note"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.email"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 70
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.packageinstaller"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 71
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.phone"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 72
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string/jumbo v1, "org.codeaurora.bluetooth"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.bluetooth"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 74
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.nfc"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.incallui"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 78
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.google.android.dialer"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 80
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.tencent.mm"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 81
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.tencent.mobileqq"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 82
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.tencent.wework"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 84
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.coloros.screenrecorder"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 85
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.nearme.themestore"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 86
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.heytap.themestore"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 87
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.themestore"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 88
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.google.android.marvin.talkback"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.wallpaper.livepicker"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 93
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.heytap.appplatform"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 94
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.appplatform"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 95
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.android.launcher"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 96
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.heytap.vip"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 97
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.heytap.usercenter"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 98
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oneplus.retailmode"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.heytap.music"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.synergy"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 102
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.ota"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.screenrecorder"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    sget-object v0, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    const-string v1, "com.oplus.ocar"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 107
    return-void
.end method

.method public constructor blacklist <init>()V
    .registers 3

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    invoke-static {}, Lcom/oplus/util/InstallFont;->findInputMethods()Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, Lcom/oplus/util/InstallFont;->mInputMethodList:Ljava/util/ArrayList;

    .line 31
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "init InstallFont , inputMethodList size = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v1, Lcom/oplus/util/InstallFont;->mInputMethodList:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/oplus/util/InstallFont;->logd(Ljava/lang/String;)V

    .line 32
    return-void
.end method

.method public static blacklist findInputMethods()Ljava/util/ArrayList;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 172
    invoke-static {}, Landroid/app/ActivityThread;->currentActivityThread()Landroid/app/ActivityThread;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/ActivityThread;->getSystemUiContext()Landroid/content/Context;

    move-result-object v0

    .line 174
    .local v0, "context":Landroid/content/Context;
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 175
    .local v1, "names":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    .line 176
    .local v2, "packageManager":Landroid/content/pm/PackageManager;
    if-nez v2, :cond_14

    .line 177
    return-object v1

    .line 179
    :cond_14
    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.view.InputMethod"

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x80

    invoke-virtual {v2, v3, v4}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v3

    .line 181
    .local v3, "list":Ljava/util/List;, "Ljava/util/List<Landroid/content/pm/ResolveInfo;>;"
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v4

    .line 182
    .local v4, "listSize":I
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_26
    if-ge v5, v4, :cond_3c

    .line 183
    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/pm/ResolveInfo;

    .line 184
    .local v6, "resolveInfo":Landroid/content/pm/ResolveInfo;
    invoke-virtual {v6}, Landroid/content/pm/ResolveInfo;->getComponentInfo()Landroid/content/pm/ComponentInfo;

    move-result-object v7

    iget-object v7, v7, Landroid/content/pm/ComponentInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v7, v7, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    .line 185
    .local v7, "packageName":Ljava/lang/String;
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 182
    .end local v6    # "resolveInfo":Landroid/content/pm/ResolveInfo;
    .end local v7    # "packageName":Ljava/lang/String;
    add-int/lit8 v5, v5, 0x1

    goto :goto_26

    .line 187
    .end local v5    # "i":I
    :cond_3c
    return-object v1
.end method

.method public static blacklist getCurrentPackageProcesses(Ljava/util/List;Ljava/lang/String;I)Ljava/util/List;
    .registers 7
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "currentUid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningAppProcessInfo;",
            ">;",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 157
    .local p0, "processList":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 158
    .local v0, "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    if-eqz p0, :cond_2d

    .line 159
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/ActivityManager$RunningAppProcessInfo;

    .line 160
    .local v2, "process":Landroid/app/ActivityManager$RunningAppProcessInfo;
    iget-object v3, v2, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2c

    iget v3, v2, Landroid/app/ActivityManager$RunningAppProcessInfo;->uid:I

    if-ne v3, p2, :cond_2c

    .line 161
    iget v3, v2, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 163
    .end local v2    # "process":Landroid/app/ActivityManager$RunningAppProcessInfo;
    :cond_2c
    goto :goto_b

    .line 165
    :cond_2d
    return-object v0
.end method

.method private static blacklist logd(Ljava/lang/String;)V
    .registers 2
    .param p0, "content"    # Ljava/lang/String;

    .line 191
    sget-boolean v0, Lcom/oplus/util/InstallFont;->DEBUG:Z

    if-eqz v0, :cond_9

    .line 192
    const-string v0, "InstallFont"

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 194
    :cond_9
    return-void
.end method

.method private static blacklist loge(Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 4
    .param p0, "content"    # Ljava/lang/String;
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 197
    sget-boolean v0, Lcom/oplus/util/InstallFont;->DEBUG:Z

    if-eqz v0, :cond_24

    .line 198
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "InstallFont"

    invoke-static {v1, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 200
    :cond_24
    return-void
.end method


# virtual methods
.method public blacklist killRunningProcess()V
    .registers 13

    .line 110
    const-string/jumbo v0, "killRunningProcess"

    invoke-static {}, Landroid/app/ActivityManager;->getService()Landroid/app/IActivityManager;

    move-result-object v1

    .line 111
    .local v1, "activityManager":Landroid/app/IActivityManager;
    invoke-static {}, Landroid/os/Process;->myUserHandle()Landroid/os/UserHandle;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/UserHandle;->hashCode()I

    move-result v2

    .line 112
    .local v2, "userIdProcess":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 114
    .local v3, "recentlist":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RecentTaskInfo;>;"
    const/16 v4, 0x64

    const/4 v5, 0x1

    :try_start_17
    invoke-interface {v1, v4, v5, v2}, Landroid/app/IActivityManager;->getRecentTasks(III)Landroid/content/pm/ParceledListSlice;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/pm/ParceledListSlice;->getList()Ljava/util/List;

    move-result-object v4
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_1f} :catch_21

    move-object v3, v4

    .line 117
    goto :goto_25

    .line 115
    :catch_21
    move-exception v4

    .line 116
    .local v4, "e":Ljava/lang/Exception;
    invoke-static {v0, v4}, Lcom/oplus/util/InstallFont;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 119
    .end local v4    # "e":Ljava/lang/Exception;
    :goto_25
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2c

    .line 120
    return-void

    .line 123
    :cond_2c
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 125
    .local v4, "processes":Ljava/util/List;, "Ljava/util/List<Landroid/app/ActivityManager$RunningAppProcessInfo;>;"
    :try_start_31
    invoke-interface {v1}, Landroid/app/IActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v0
    :try_end_35
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_35} :catch_37

    move-object v4, v0

    .line 128
    goto :goto_3b

    .line 126
    :catch_37
    move-exception v5

    .line 127
    .local v5, "e":Ljava/lang/Exception;
    invoke-static {v0, v5}, Lcom/oplus/util/InstallFont;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 131
    .end local v5    # "e":Ljava/lang/Exception;
    :goto_3b
    const-string v0, "InstallFont"

    const-string/jumbo v5, "killRunningProcess: maybe kill processes not in whitelist"

    invoke-static {v0, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 132
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_44
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-ge v0, v5, :cond_f7

    .line 133
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/ActivityManager$RecentTaskInfo;

    .line 134
    .local v5, "info":Landroid/app/ActivityManager$RecentTaskInfo;
    iget-object v6, v5, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    invoke-virtual {v6}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v6

    if-nez v6, :cond_5a

    .line 135
    goto/16 :goto_f3

    .line 137
    :cond_5a
    iget-object v6, v5, Landroid/app/ActivityManager$RecentTaskInfo;->baseIntent:Landroid/content/Intent;

    invoke-virtual {v6}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v6

    .line 138
    .local v6, "pkg":Ljava/lang/String;
    iget v7, v5, Landroid/app/ActivityManager$RecentTaskInfo;->uid:I

    .line 139
    .local v7, "uid":I
    sget-object v8, Lcom/oplus/util/InstallFont;->mAppWhiteList:Ljava/util/ArrayList;

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_f3

    sget-object v8, Lcom/oplus/util/InstallFont;->mInputMethodList:Ljava/util/ArrayList;

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_f3

    .line 140
    const-string v8, "com.oplus.autotest"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_f3

    const-string v8, "com.oppo.autotest"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_f3

    .line 141
    const-string v8, "com.oplus.qe"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_f3

    const-string v8, "com.oppo.qe"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_f3

    .line 142
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "killRunningProcess = "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " , uid = "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/oplus/util/InstallFont;->logd(Ljava/lang/String;)V

    .line 144
    :try_start_b7
    invoke-static {v4, v6, v7}, Lcom/oplus/util/InstallFont;->getCurrentPackageProcesses(Ljava/util/List;Ljava/lang/String;I)Ljava/util/List;

    move-result-object v8

    .line 145
    .local v8, "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_bf
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_d3

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Integer;

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    .line 146
    .local v11, "pid":I
    invoke-static {v11}, Landroid/os/Process;->killProcess(I)V
    :try_end_d2
    .catch Ljava/lang/Exception; {:try_start_b7 .. :try_end_d2} :catch_d4

    .line 147
    .end local v11    # "pid":I
    goto :goto_bf

    .line 150
    .end local v8    # "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    :cond_d3
    goto :goto_f3

    .line 148
    :catch_d4
    move-exception v8

    .line 149
    .local v8, "e":Ljava/lang/Exception;
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Failed killRunningProcess = "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v8}, Lcom/oplus/util/InstallFont;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 132
    .end local v5    # "info":Landroid/app/ActivityManager$RecentTaskInfo;
    .end local v6    # "pkg":Ljava/lang/String;
    .end local v7    # "uid":I
    .end local v8    # "e":Ljava/lang/Exception;
    :cond_f3
    :goto_f3
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_44

    .line 153
    .end local v0    # "i":I
    :cond_f7
    return-void
.end method
