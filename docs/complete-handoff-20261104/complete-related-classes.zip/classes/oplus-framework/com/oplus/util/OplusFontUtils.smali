.class public Lcom/oplus/util/OplusFontUtils;
.super Lcom/oplus/util/OplusBaseFontUtils;
.source "OplusFontUtils.java"


# static fields
.field public static final blacklist CUSTOM_FONT_FAMILY_NAME:Ljava/lang/String; = "individual-font"

.field public static final blacklist CUSTOM_FONT_POSTSCRIPTNAME:Ljava/lang/String; = "Customized-Regular"

.field private static final blacklist SOLID_DIGITS:Ljava/lang/String; = "osans-solid-digits"

.field static blacklist sIndividualTypeface:Landroid/graphics/Typeface;

.field private static blacklist sOplusStyle:Z

.field private static final blacklist sWitheList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 12

    .line 74
    const/4 v0, 0x0

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->sOplusStyle:Z

    .line 75
    const-string v10, "com.android.wallpaper.livepicker"

    const-string v11, "com.android.intentresolver"

    const-string v1, "com.android.systemui"

    const-string v2, "com.android.launcher"

    const-string v3, "com.android.settings"

    const-string v4, "com.android.mms"

    const-string v5, "com.android.incallui"

    const-string v6, "com.android.contacts"

    const-string v7, "com.android.phone"

    const-string v8, "com.android.htmlviewer"

    const-string v9, "com.android.email"

    filled-new-array/range {v1 .. v11}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sWitheList:Ljava/util/List;

    .line 939
    const/4 v0, 0x0

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sIndividualTypeface:Landroid/graphics/Typeface;

    return-void
.end method

.method public constructor blacklist <init>()V
    .registers 1

    .line 71
    invoke-direct {p0}, Lcom/oplus/util/OplusBaseFontUtils;-><init>()V

    return-void
.end method

.method public static blacklist apendIndividualFontFamily(Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/text/FontConfig$NamedFamilyList;",
            ">;)V"
        }
    .end annotation

    .line 867
    .local p0, "xmlFamilies":Ljava/util/List;, "Ljava/util/List<Landroid/text/FontConfig$NamedFamilyList;>;"
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-eqz v0, :cond_d

    if-eqz p0, :cond_d

    .line 868
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->createCustomizeFontFamily()Landroid/text/FontConfig$NamedFamilyList;

    move-result-object v0

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 870
    :cond_d
    return-void
.end method

.method private static blacklist canUseSystemFont(IIIZ)Z
    .registers 5
    .param p0, "wghtFromFontVariation"    # I
    .param p1, "weight"    # I
    .param p2, "exceptedWeight"    # I
    .param p3, "isItalic"    # Z

    .line 1018
    if-ne p0, p2, :cond_8

    if-ne p1, p2, :cond_8

    if-nez p3, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    return v0
.end method

.method private static blacklist checkAndCorrectFlipFontLink(Z)V
    .registers 4
    .param p0, "userChange"    # Z

    .line 273
    new-instance v0, Ljava/io/File;

    const/4 v1, 0x0

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 276
    .local v0, "flipedFontFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_1c

    .line 277
    const/4 v1, 0x2

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->relinkDataFontToTarget(ILjava/io/File;)Z

    move-result v1

    sput-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    .line 278
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    sput-boolean v1, Loplus/content/res/OplusFontUtils;->isFlipFontUsed:Z

    goto :goto_27

    .line 281
    :cond_1c
    const-string v2, "checkAndCorrectFlipFontLink flipedFontFile NOT exists"

    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 282
    sput-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    .line 283
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    sput-boolean v1, Loplus/content/res/OplusFontUtils;->isFlipFontUsed:Z

    .line 287
    :goto_27
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-nez v1, :cond_2f

    .line 288
    const/4 v1, 0x1

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->relinkDataFontToTarget(ILjava/io/File;)Z

    .line 291
    :cond_2f
    return-void
.end method

.method public static blacklist convertIntToString(I)Ljava/lang/String;
    .registers 3
    .param p0, "value"    # I

    .line 609
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\'wght\' "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static blacklist convertIntsToString(II)Ljava/lang/String;
    .registers 5
    .param p0, "wghtValue"    # I
    .param p1, "opszValue"    # I

    .line 613
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\'wght\' "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 614
    .local v0, "result":Ljava/lang/String;
    if-lez p1, :cond_32

    .line 615
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ","

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\'opsz\' "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 617
    :cond_32
    return-object v0
.end method

.method public static blacklist convertStringToInt(Ljava/lang/String;)I
    .registers 8
    .param p0, "fontVariationSettings"    # Ljava/lang/String;

    .line 621
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    .line 622
    return v1

    .line 625
    :cond_8
    const-string/jumbo v0, "wght"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3c

    .line 626
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 627
    .local v0, "wghtIndex":I
    const-string v2, ","

    invoke-virtual {p0, v2, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v2

    .line 628
    .local v2, "nextCommaIndex":I
    const/4 v3, -0x1

    if-ne v2, v3, :cond_22

    .line 629
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    .line 631
    :cond_22
    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    .line 632
    .local v3, "wghtParamStr":Ljava/lang/String;
    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 633
    .local v4, "radius":[Ljava/lang/String;
    array-length v5, v4

    const/4 v6, 0x2

    if-ne v5, v6, :cond_3c

    .line 634
    const/4 v1, 0x1

    aget-object v1, v4, v1

    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    return v1

    .line 638
    .end local v0    # "wghtIndex":I
    .end local v2    # "nextCommaIndex":I
    .end local v3    # "wghtParamStr":Ljava/lang/String;
    .end local v4    # "radius":[Ljava/lang/String;
    :cond_3c
    return v1
.end method

.method private static blacklist convertStringToOpszInt(Ljava/lang/String;)I
    .registers 8
    .param p0, "fontVariationSettings"    # Ljava/lang/String;

    .line 657
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    .line 658
    return v1

    .line 661
    :cond_8
    const-string/jumbo v0, "opsz"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3c

    .line 662
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 663
    .local v0, "wghtIndex":I
    const-string v2, ","

    invoke-virtual {p0, v2, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v2

    .line 664
    .local v2, "nextCommaIndex":I
    const/4 v3, -0x1

    if-ne v2, v3, :cond_22

    .line 665
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    .line 667
    :cond_22
    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    .line 668
    .local v3, "wghtParamStr":Ljava/lang/String;
    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 669
    .local v4, "radius":[Ljava/lang/String;
    array-length v5, v4

    const/4 v6, 0x2

    if-ne v5, v6, :cond_3c

    .line 670
    const/4 v1, 0x1

    aget-object v1, v4, v1

    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    return v1

    .line 674
    .end local v0    # "wghtIndex":I
    .end local v2    # "nextCommaIndex":I
    .end local v3    # "wghtParamStr":Ljava/lang/String;
    .end local v4    # "radius":[Ljava/lang/String;
    :cond_3c
    return v1
.end method

.method public static blacklist create(Landroid/graphics/Typeface;Ljava/lang/String;I)Landroid/graphics/Typeface;
    .registers 4
    .param p0, "typeface"    # Landroid/graphics/Typeface;
    .param p1, "familyName"    # Ljava/lang/String;
    .param p2, "style"    # I

    .line 261
    invoke-static {p0, p2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v0

    return-object v0
.end method

.method public static blacklist createCustomizeFontFamily()Landroid/text/FontConfig$NamedFamilyList;
    .registers 12

    .line 873
    new-instance v0, Landroid/text/FontConfig$FontFamily;

    const/4 v1, 0x1

    new-array v1, v1, [Landroid/text/FontConfig$Font;

    new-instance v2, Landroid/text/FontConfig$Font;

    new-instance v3, Ljava/io/File;

    .line 875
    const/4 v11, 0x0

    invoke-static {v11}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v6, Landroid/graphics/fonts/FontStyle;

    const/16 v4, 0x190

    invoke-direct {v6, v4, v11}, Landroid/graphics/fonts/FontStyle;-><init>(II)V

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v4, 0x0

    const-string v5, "Customized-Regular"

    const/4 v7, 0x0

    const-string v8, ""

    invoke-direct/range {v2 .. v10}, Landroid/text/FontConfig$Font;-><init>(Ljava/io/File;Ljava/io/File;Ljava/lang/String;Landroid/graphics/fonts/FontStyle;ILjava/lang/String;Ljava/lang/String;I)V

    aput-object v2, v1, v11

    .line 874
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 878
    invoke-static {}, Landroid/os/LocaleList;->getEmptyLocaleList()Landroid/os/LocaleList;

    move-result-object v2

    invoke-direct {v0, v1, v2, v11}, Landroid/text/FontConfig$FontFamily;-><init>(Ljava/util/List;Landroid/os/LocaleList;I)V

    .line 879
    .local v0, "family":Landroid/text/FontConfig$FontFamily;
    new-instance v1, Landroid/text/FontConfig$NamedFamilyList;

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const-string v3, "individual-font"

    invoke-direct {v1, v2, v3}, Landroid/text/FontConfig$NamedFamilyList;-><init>(Ljava/util/List;Ljava/lang/String;)V

    return-object v1
.end method

.method public static blacklist createIndividualTypefae()V
    .registers 5

    .line 942
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v0

    const/4 v1, 0x1

    const-string v2, "individual-font"

    if-eqz v0, :cond_15

    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    .line 943
    sput-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    .line 945
    :cond_15
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-eqz v0, :cond_5b

    .line 946
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    if-nez v0, :cond_22

    .line 947
    const/4 v0, 0x4

    new-array v0, v0, [Landroid/graphics/Typeface;

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    .line 949
    :cond_22
    const/4 v0, 0x0

    invoke-static {v2, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v3

    sput-object v3, Lcom/oplus/util/OplusFontUtils;->sIndividualTypeface:Landroid/graphics/Typeface;

    .line 950
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sIndividualTypeface:Landroid/graphics/Typeface;

    if-eqz v3, :cond_62

    .line 951
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    sget-object v4, Lcom/oplus/util/OplusFontUtils;->sIndividualTypeface:Landroid/graphics/Typeface;

    aput-object v4, v3, v0

    .line 952
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v3

    aput-object v3, v0, v1

    .line 953
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    const/4 v1, 0x2

    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v3

    aput-object v3, v0, v1

    .line 954
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    const/4 v1, 0x3

    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    aput-object v2, v0, v1

    .line 955
    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefacesArray:Ljava/util/List;

    goto :goto_62

    .line 958
    :cond_5b
    const/4 v0, 0x0

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sIndividualTypeface:Landroid/graphics/Typeface;

    .line 959
    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefacesArray:Ljava/util/List;

    .line 960
    sput-object v0, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    .line 962
    :cond_62
    :goto_62
    return-void
.end method

.method public static blacklist createTypefaceForCustom(Ljava/util/Map;Ljava/util/Map$Entry;)Z
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/graphics/Typeface;",
            ">;",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/String;",
            "[",
            "Landroid/graphics/fonts/FontFamily;",
            ">;)Z"
        }
    .end annotation

    .line 976
    .local p0, "outSystemFontMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Landroid/graphics/Typeface;>;"
    .local p1, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;[Landroid/graphics/fonts/FontFamily;>;"
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_34

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const-string v2, "individual-font"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34

    .line 977
    new-instance v0, Ljava/io/File;

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 978
    .local v0, "flipedFontFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_34

    .line 979
    const/4 v3, 0x0

    .line 981
    .local v3, "tf":Landroid/graphics/Typeface;
    :try_start_21
    invoke-static {v0}, Landroid/graphics/Typeface;->createFromFile(Ljava/io/File;)Landroid/graphics/Typeface;

    move-result-object v4
    :try_end_25
    .catch Ljava/lang/RuntimeException; {:try_start_21 .. :try_end_25} :catch_27

    move-object v3, v4

    .line 984
    goto :goto_2d

    .line 982
    :catch_27
    move-exception v4

    .line 983
    .local v4, "e":Ljava/lang/RuntimeException;
    const-string v5, "RuntimeException createTypefaceForCustom fail"

    invoke-static {v5, v4}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 985
    .end local v4    # "e":Ljava/lang/RuntimeException;
    :goto_2d
    if-eqz v3, :cond_34

    .line 986
    invoke-interface {p0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 987
    const/4 v1, 0x1

    return v1

    .line 991
    .end local v0    # "flipedFontFile":Ljava/io/File;
    .end local v3    # "tf":Landroid/graphics/Typeface;
    :cond_34
    return v1
.end method

.method public static blacklist createTypefaceKey(Ljava/lang/String;III)Ljava/lang/String;
    .registers 7
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "fv"    # I
    .param p2, "style"    # I
    .param p3, "weight"    # I

    .line 801
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 802
    .local v0, "builder":Ljava/lang/StringBuilder;
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 803
    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 804
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 805
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 806
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 807
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 808
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 809
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private static blacklist createTypefaceKeyWithOpsz(Ljava/lang/String;IIII)Ljava/lang/String;
    .registers 7
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "fv"    # I
    .param p2, "opsz"    # I
    .param p3, "style"    # I
    .param p4, "weight"    # I

    .line 797
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p1, p3, p4}, Lcom/oplus/util/OplusFontUtils;->createTypefaceKey(Ljava/lang/String;III)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static blacklist createTypefaceWithVariation(Landroid/graphics/Typeface;Ljava/lang/String;)Landroid/graphics/Typeface;
    .registers 9
    .param p0, "typeface"    # Landroid/graphics/Typeface;
    .param p1, "fontVariationSettings"    # Ljava/lang/String;

    .line 489
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->getReplaceTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {p0}, Landroid/graphics/Typeface;->getWeight()I

    move-result v1

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v2

    invoke-static {v0, v1, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p0

    .line 490
    invoke-static {p1}, Landroid/graphics/fonts/FontVariationAxis;->fromFontVariationSettings(Ljava/lang/String;)[Landroid/graphics/fonts/FontVariationAxis;

    move-result-object v0

    .line 491
    .local v0, "axesf":[Landroid/graphics/fonts/FontVariationAxis;
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 492
    .local v1, "filteredAxes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/graphics/fonts/FontVariationAxis;>;"
    const/4 v2, 0x0

    if-eqz v0, :cond_1e

    move-object v3, v0

    goto :goto_20

    :cond_1e
    new-array v3, v2, [Landroid/graphics/fonts/FontVariationAxis;

    :goto_20
    array-length v4, v3

    :goto_21
    if-ge v2, v4, :cond_35

    aget-object v5, v3, v2

    .line 493
    .local v5, "axis":Landroid/graphics/fonts/FontVariationAxis;
    invoke-virtual {v5}, Landroid/graphics/fonts/FontVariationAxis;->getOpenTypeTagValue()I

    move-result v6

    invoke-virtual {p0, v6}, Landroid/graphics/Typeface;->isSupportedAxes(I)Z

    move-result v6

    if-eqz v6, :cond_32

    .line 494
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 492
    .end local v5    # "axis":Landroid/graphics/fonts/FontVariationAxis;
    :cond_32
    add-int/lit8 v2, v2, 0x1

    goto :goto_21

    .line 497
    :cond_35
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4a

    .line 498
    invoke-static {p0, v1}, Landroid/graphics/Typeface;->createFromTypefaceWithVariation(Landroid/graphics/Typeface;Ljava/util/List;)Landroid/graphics/Typeface;

    move-result-object p0

    .line 499
    iget-object v2, p0, Landroid/graphics/Typeface;->mTypefaceExt:Landroid/graphics/ITypefaceExt;

    if-eqz v2, :cond_49

    .line 500
    iget-object v2, p0, Landroid/graphics/Typeface;->mTypefaceExt:Landroid/graphics/ITypefaceExt;

    const/4 v3, 0x1

    invoke-interface {v2, v3}, Landroid/graphics/ITypefaceExt;->setSystemTypeface(Z)V

    .line 502
    :cond_49
    return-object p0

    .line 504
    :cond_4a
    return-object p0
.end method

.method public static blacklist defaultFromStyle(I)Landroid/graphics/Typeface;
    .registers 3
    .param p0, "style"    # I

    .line 265
    invoke-static {}, Landroid/graphics/OplusTypefaceInjector;->getSystemDefaultTypefaces()[Landroid/graphics/Typeface;

    move-result-object v0

    .line 266
    .local v0, "systemDefaults":[Landroid/graphics/Typeface;
    if-eqz v0, :cond_f

    array-length v1, v0

    if-ge p0, v1, :cond_f

    const/4 v1, -0x1

    if-le p0, v1, :cond_f

    .line 267
    aget-object v1, v0, p0

    return-object v1

    .line 269
    :cond_f
    const/4 v1, 0x0

    return-object v1
.end method

.method private static blacklist doUpdateTypeface(Landroid/content/res/Configuration;)V
    .registers 9
    .param p0, "configuration"    # Landroid/content/res/Configuration;

    .line 888
    const/4 v0, 0x0

    .line 891
    .local v0, "tf":Landroid/graphics/Typeface;
    new-instance v1, Ljava/io/File;

    const/4 v2, 0x0

    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 892
    .local v1, "flipedFontFile":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_15

    .line 893
    sput-boolean v4, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    goto :goto_17

    .line 895
    :cond_15
    sput-boolean v2, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    .line 897
    :goto_17
    sget-boolean v3, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    sput-boolean v3, Loplus/content/res/OplusFontUtils;->isFlipFontUsed:Z

    .line 899
    :try_start_1b
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->FONTINFOARRAY_ROM6D0:[Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;

    aget-object v3, v3, v2

    iget-object v3, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-static {v3}, Landroid/system/Os;->readlink(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 900
    .local v3, "path":Ljava/lang/String;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_5e

    .line 901
    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 902
    .local v5, "typefaceFile":Ljava/io/File;
    invoke-static {v5}, Lcom/oplus/util/OplusFontUtils;->getFileMd5(Ljava/io/File;)Ljava/lang/String;

    move-result-object v6

    .line 903
    .local v6, "md5":Ljava/lang/String;
    sget-object v7, Lcom/oplus/util/OplusFontUtils;->sThemeStoreTypefaceCache:Landroid/util/LruCache;

    invoke-virtual {v7, v6}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_46

    .line 904
    sget-object v7, Lcom/oplus/util/OplusFontUtils;->sThemeStoreTypefaceCache:Landroid/util/LruCache;

    invoke-virtual {v7, v6}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/Typeface;

    move-object v0, v7

    goto :goto_5e

    .line 906
    :cond_46
    invoke-static {v5}, Landroid/graphics/Typeface;->createFromFile(Ljava/io/File;)Landroid/graphics/Typeface;

    move-result-object v7

    move-object v0, v7

    .line 907
    sget-object v7, Lcom/oplus/util/OplusFontUtils;->sThemeStoreTypefaceCache:Landroid/util/LruCache;

    invoke-virtual {v7, v6, v0}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_50
    .catch Ljava/lang/RuntimeException; {:try_start_1b .. :try_end_50} :catch_58
    .catch Landroid/system/ErrnoException; {:try_start_1b .. :try_end_50} :catch_51

    goto :goto_5e

    .line 912
    .end local v3    # "path":Ljava/lang/String;
    .end local v5    # "typefaceFile":Ljava/io/File;
    .end local v6    # "md5":Ljava/lang/String;
    :catch_51
    move-exception v3

    .line 913
    .local v3, "e":Landroid/system/ErrnoException;
    const-string v5, "Could not update selinux policy initFont createFromFile "

    invoke-static {v5, v3}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_5f

    .line 910
    .end local v3    # "e":Landroid/system/ErrnoException;
    :catch_58
    move-exception v3

    .line 911
    .local v3, "e":Ljava/lang/RuntimeException;
    const-string v5, "RuntimeException initFont() createFromFile fail"

    invoke-static {v5, v3}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 914
    .end local v3    # "e":Ljava/lang/RuntimeException;
    :cond_5e
    :goto_5e
    nop

    .line 917
    :goto_5f
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    if-nez v3, :cond_68

    .line 918
    const/4 v3, 0x4

    new-array v3, v3, [Landroid/graphics/Typeface;

    sput-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    .line 921
    :cond_68
    sget-boolean v3, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-eqz v3, :cond_9e

    .line 922
    if-eqz v0, :cond_a3

    .line 923
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    invoke-static {v0, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    aput-object v5, v3, v2

    .line 924
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    invoke-static {v0, v4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    aput-object v5, v3, v4

    .line 925
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    const/4 v4, 0x2

    invoke-static {v0, v4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    aput-object v5, v3, v4

    .line 926
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    const/4 v4, 0x3

    invoke-static {v0, v4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    aput-object v5, v3, v4

    .line 927
    new-instance v3, Ljava/util/ArrayList;

    sget-object v4, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sput-object v3, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefacesArray:Ljava/util/List;

    goto :goto_a3

    .line 930
    :cond_9e
    const-string v3, "Not using flip font"

    invoke-static {v3}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 933
    :cond_a3
    :goto_a3
    invoke-static {}, Landroid/graphics/Canvas;->freeCaches()V

    .line 934
    invoke-static {}, Landroid/graphics/Canvas;->freeTextLayoutCaches()V

    .line 935
    const/16 v3, 0x14

    invoke-static {v3}, Landroid/graphics/HardwareRenderer;->trimMemory(I)V

    .line 936
    invoke-static {v2}, Landroid/graphics/HardwareRenderer;->trimCaches(I)V

    .line 937
    return-void
.end method

.method private static blacklist extractWghtParamStr(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p0, "fontVariationSettings"    # Ljava/lang/String;

    .line 642
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 643
    return-object p0

    .line 645
    :cond_7
    const-string/jumbo v0, "wght"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_28

    .line 646
    const-string v0, "\'wght\'"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 647
    .local v0, "wghtIndex":I
    const-string v1, ","

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v1

    .line 648
    .local v1, "nextCommaIndex":I
    const/4 v2, -0x1

    if-ne v1, v2, :cond_23

    .line 649
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    .line 651
    :cond_23
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 653
    .end local v0    # "wghtIndex":I
    .end local v1    # "nextCommaIndex":I
    :cond_28
    return-object p0
.end method

.method public static blacklist flipTypeface(Landroid/graphics/ITypefaceExt;)Landroid/graphics/Typeface;
    .registers 4
    .param p0, "typefaceExt"    # Landroid/graphics/ITypefaceExt;

    .line 216
    const/4 v0, 0x0

    .line 217
    .local v0, "typeface":Landroid/graphics/Typeface;
    if-eqz p0, :cond_7

    .line 218
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    .line 220
    :cond_7
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-eqz v1, :cond_30

    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->sReplaceFont:Z

    if-eqz v1, :cond_30

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    if-eqz v1, :cond_30

    if-eqz v0, :cond_23

    if-eqz p0, :cond_1d

    .line 224
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->isSystemTypeface()Z

    move-result v1

    if-nez v1, :cond_23

    .line 225
    :cond_1d
    invoke-static {v0}, Landroid/graphics/OplusTypefaceInjector;->isSystemTypeface(Landroid/graphics/Typeface;)Z

    move-result v1

    if-eqz v1, :cond_30

    .line 226
    :cond_23
    if-nez v0, :cond_27

    const/4 v1, 0x0

    goto :goto_2b

    :cond_27
    invoke-virtual {v0}, Landroid/graphics/Typeface;->getStyle()I

    move-result v1

    .line 227
    .local v1, "style":I
    :goto_2b
    sget-object v2, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefaces:[Landroid/graphics/Typeface;

    aget-object v2, v2, v1

    return-object v2

    .line 228
    .end local v1    # "style":I
    :cond_30
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-nez v1, :cond_4b

    if-eqz v0, :cond_4b

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefacesArray:Ljava/util/List;

    if-eqz v1, :cond_4b

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sCurrentTypefacesArray:Ljava/util/List;

    .line 231
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4b

    .line 232
    invoke-virtual {v0}, Landroid/graphics/Typeface;->getStyle()I

    move-result v1

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->defaultFromStyle(I)Landroid/graphics/Typeface;

    move-result-object v1

    return-object v1

    .line 233
    :cond_4b
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportMediumFont:Z

    if-nez v1, :cond_64

    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-nez v1, :cond_64

    if-eqz v0, :cond_64

    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    if-eqz v1, :cond_64

    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    .line 236
    invoke-virtual {v0, v1}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_64

    .line 237
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    return-object v1

    .line 239
    :cond_64
    return-object v0
.end method

.method public static blacklist flipTypeface(Landroid/graphics/ITypefaceExt;Landroid/graphics/Paint;)Landroid/graphics/Typeface;
    .registers 4
    .param p0, "typefaceExt"    # Landroid/graphics/ITypefaceExt;
    .param p1, "paint"    # Landroid/graphics/Paint;

    .line 207
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->flipTypeface(Landroid/graphics/ITypefaceExt;)Landroid/graphics/Typeface;

    move-result-object v0

    .line 209
    .local v0, "tf":Landroid/graphics/Typeface;
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->shouldReplaceToOSans(Landroid/graphics/ITypefaceExt;)Z

    move-result v1

    if-eqz v1, :cond_1b

    .line 210
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v1

    if-nez v1, :cond_13

    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    goto :goto_17

    :cond_13
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v1

    :goto_17
    invoke-static {v1, p1}, Lcom/oplus/util/OplusFontUtils;->replaceTypefaceWithVariation(Landroid/graphics/Typeface;Landroid/graphics/Paint;)Landroid/graphics/Typeface;

    move-result-object v0

    .line 212
    :cond_1b
    return-object v0
.end method

.method private static blacklist freeCaches()V
    .registers 0

    .line 440
    invoke-static {}, Landroid/graphics/Canvas;->freeCaches()V

    .line 441
    invoke-static {}, Landroid/graphics/Canvas;->freeTextLayoutCaches()V

    .line 442
    return-void
.end method

.method public static blacklist getAdaptionValue(Ljava/lang/String;)I
    .registers 4
    .param p0, "name"    # Ljava/lang/String;

    .line 966
    :try_start_0
    new-instance v0, Landroid/app/OplusActivityManager;

    invoke-direct {v0}, Landroid/app/OplusActivityManager;-><init>()V

    .line 967
    .local v0, "mOppoActivityManager":Landroid/app/OplusActivityManager;
    invoke-virtual {v0, p0}, Landroid/app/OplusActivityManager;->getFontVariationAdaption(Ljava/lang/String;)I

    move-result v1
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_9} :catch_a

    .line 968
    .local v1, "data":I
    return v1

    .line 969
    .end local v0    # "mOppoActivityManager":Landroid/app/OplusActivityManager;
    .end local v1    # "data":I
    :catch_a
    move-exception v0

    .line 970
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "init data Exception , "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "FontUtils"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 971
    const/4 v1, 0x0

    return v1
.end method

.method private static blacklist getCustomizedFontFile(Z)Ljava/lang/String;
    .registers 5
    .param p0, "oldFile"    # Z

    .line 445
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget v1, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 446
    .local v0, "userIdStr":Ljava/lang/String;
    sget v1, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    if-nez v1, :cond_1b

    .line 447
    const-string v0, ""

    .line 450
    :cond_1b
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lcom/oplus/util/OplusFontUtils;->DATA_FONT_DIRECTORY:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-eqz p0, :cond_2f

    const-string v2, "ColorOS-Regular.ttf"

    goto :goto_31

    :cond_2f
    const-string v2, "Customized-Regular.ttf"

    :goto_31
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 451
    .local v1, "result":Ljava/lang/String;
    if-eqz p0, :cond_53

    .line 452
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "getCustomizedFontFile with name "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "FontUtils"

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 454
    :cond_53
    return-object v1
.end method

.method public static blacklist getNeedReplaceAllTypefaceApp()Z
    .registers 1

    .line 202
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->sNeedReplaceAllTypefaceApp:Z

    return v0
.end method

.method private static blacklist getReplaceTypeface()Landroid/graphics/Typeface;
    .registers 2

    .line 784
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1e

    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_b

    goto :goto_1e

    .line 787
    :cond_b
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_13

    .line 788
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sOneplusVf:Landroid/graphics/Typeface;

    return-object v0

    .line 790
    :cond_13
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_1b

    .line 791
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->sOplusSerifVf:Landroid/graphics/Typeface;

    return-object v0

    .line 793
    :cond_1b
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    return-object v0

    .line 785
    :cond_1e
    :goto_1e
    sget-object v0, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_VF:Landroid/graphics/Typeface;

    return-object v0
.end method

.method private static blacklist getReplaceTypefaceName()Ljava/lang/String;
    .registers 2

    .line 771
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_20

    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_b

    goto :goto_20

    .line 774
    :cond_b
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_14

    .line 775
    const-string/jumbo v0, "op-sans-en"

    return-object v0

    .line 777
    :cond_14
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_1d

    .line 778
    const-string/jumbo v0, "sys-serif"

    return-object v0

    .line 780
    :cond_1d
    const-string v0, "DEFAULT"

    return-object v0

    .line 772
    :cond_20
    :goto_20
    const-string/jumbo v0, "sys-sans-en"

    return-object v0
.end method

.method private static blacklist getSystemFontLink(ILjava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p0, "index"    # I
    .param p1, "robotoTargetFont"    # Ljava/lang/String;

    .line 368
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    packed-switch v0, :pswitch_data_18

    .line 379
    :pswitch_5
    move-object v0, p1

    .local v0, "targetFont":Ljava/lang/String;
    goto :goto_16

    .line 376
    .end local v0    # "targetFont":Ljava/lang/String;
    :pswitch_7
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FONT_LINK_SERIF:[Ljava/lang/String;

    aget-object v0, v0, p0

    .line 377
    .restart local v0    # "targetFont":Ljava/lang/String;
    goto :goto_16

    .line 373
    .end local v0    # "targetFont":Ljava/lang/String;
    :pswitch_c
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FONT_LINK_ONEPLUS_SANS:[Ljava/lang/String;

    aget-object v0, v0, p0

    .line 374
    .restart local v0    # "targetFont":Ljava/lang/String;
    goto :goto_16

    .line 370
    .end local v0    # "targetFont":Ljava/lang/String;
    :pswitch_11
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FONT_LINK_OPPO_SANS:[Ljava/lang/String;

    aget-object v0, v0, p0

    .line 371
    .restart local v0    # "targetFont":Ljava/lang/String;
    nop

    .line 382
    :goto_16
    return-object v0

    nop

    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_11
        :pswitch_5
        :pswitch_c
        :pswitch_5
        :pswitch_7
    .end packed-switch
.end method

.method private static blacklist getSystemZHFontLink(ILjava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p0, "index"    # I
    .param p1, "defaultTargetFont"    # Ljava/lang/String;

    .line 387
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    packed-switch v0, :pswitch_data_e

    .line 392
    move-object v0, p1

    .local v0, "targetFont":Ljava/lang/String;
    goto :goto_c

    .line 389
    .end local v0    # "targetFont":Ljava/lang/String;
    :pswitch_7
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FONT_LINK_SERIF:[Ljava/lang/String;

    aget-object v0, v0, p0

    .line 390
    .restart local v0    # "targetFont":Ljava/lang/String;
    nop

    .line 395
    :goto_c
    return-object v0

    nop

    :pswitch_data_e
    .packed-switch 0x5
        :pswitch_7
    .end packed-switch
.end method

.method private static blacklist getVariationFontFromCache(Landroid/graphics/Typeface;Ljava/lang/String;)Landroid/graphics/Typeface;
    .registers 12
    .param p0, "typeface"    # Landroid/graphics/Typeface;
    .param p1, "fontVariationSettings"    # Ljava/lang/String;

    .line 715
    invoke-static {p1}, Lcom/oplus/util/OplusFontUtils;->convertStringToInt(Ljava/lang/String;)I

    move-result v0

    .line 717
    .local v0, "wghtFromFontVariation":I
    div-int/lit8 v1, v0, 0xa

    mul-int/lit8 v1, v1, 0xa

    .line 719
    .end local v0    # "wghtFromFontVariation":I
    .local v1, "wghtFromFontVariation":I
    invoke-virtual {p0}, Landroid/graphics/Typeface;->getWeight()I

    move-result v0

    .line 721
    .local v0, "weight":I
    sget-object v2, Lcom/oplus/util/OplusFontUtils;->FONT_WEIGHT_CAST_WGHT:Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 723
    .local v2, "wghtFromWeight":Ljava/lang/Integer;
    if-nez v2, :cond_1d

    add-int/lit16 v3, v0, -0x226

    goto :goto_23

    :cond_1d
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    add-int/lit16 v3, v3, -0x226

    :goto_23
    add-int/2addr v1, v3

    .line 725
    sget v3, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v4, 0x3

    if-ne v3, v4, :cond_2f

    const/16 v3, 0xb2

    if-ge v1, v3, :cond_2f

    .line 727
    const/16 v1, 0xb2

    .line 729
    :cond_2f
    const/16 v3, 0x3e8

    .line 730
    .local v3, "maxVariation":I
    const/16 v4, 0x64

    .line 731
    .local v4, "minVariation":I
    sget-object v5, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    if-eqz v5, :cond_43

    sget-object v5, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    const-string v6, "com.baidu.BaiduMap"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_43

    .line 732
    const/16 v4, 0xfa

    .line 734
    :cond_43
    if-lt v1, v3, :cond_46

    .line 735
    move v1, v3

    .line 737
    :cond_46
    if-gt v1, v4, :cond_49

    .line 738
    move v1, v4

    .line 741
    :cond_49
    const/4 v5, 0x0

    .line 742
    .local v5, "newTypeface":Landroid/graphics/Typeface;
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->getReplaceTypefaceName()Ljava/lang/String;

    move-result-object v6

    .line 743
    .local v6, "typeFaceName":Ljava/lang/String;
    const-string/jumbo v7, "sys-sans-en"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_e0

    .line 744
    const/16 v7, 0x64

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v8

    invoke-static {v1, v0, v7, v8}, Lcom/oplus/util/OplusFontUtils;->canUseSystemFont(IIIZ)Z

    move-result v7

    if-eqz v7, :cond_72

    .line 745
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v7

    const-string/jumbo v8, "sans-en-thin"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    move-object v5, v7

    check-cast v5, Landroid/graphics/Typeface;

    goto :goto_dd

    .line 746
    :cond_72
    const/16 v7, 0x12c

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v8

    invoke-static {v1, v0, v7, v8}, Lcom/oplus/util/OplusFontUtils;->canUseSystemFont(IIIZ)Z

    move-result v7

    if-eqz v7, :cond_8d

    .line 747
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v7

    const-string/jumbo v8, "sans-en-light"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    move-object v5, v7

    check-cast v5, Landroid/graphics/Typeface;

    goto :goto_dd

    .line 748
    :cond_8d
    const/16 v7, 0x190

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v8

    invoke-static {v1, v0, v7, v8}, Lcom/oplus/util/OplusFontUtils;->canUseSystemFont(IIIZ)Z

    move-result v7

    if-eqz v7, :cond_a8

    .line 749
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v7

    const-string/jumbo v8, "sans-en-nomal"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    move-object v5, v7

    check-cast v5, Landroid/graphics/Typeface;

    goto :goto_dd

    .line 750
    :cond_a8
    const/16 v7, 0x1f4

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v8

    invoke-static {v1, v0, v7, v8}, Lcom/oplus/util/OplusFontUtils;->canUseSystemFont(IIIZ)Z

    move-result v7

    if-eqz v7, :cond_c3

    .line 751
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v7

    const-string/jumbo v8, "sans-en-medium"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    move-object v5, v7

    check-cast v5, Landroid/graphics/Typeface;

    goto :goto_dd

    .line 752
    :cond_c3
    const/16 v7, 0x258

    invoke-virtual {p0}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v8

    invoke-static {v1, v0, v7, v8}, Lcom/oplus/util/OplusFontUtils;->canUseSystemFont(IIIZ)Z

    move-result v7

    if-eqz v7, :cond_dd

    .line 753
    invoke-static {}, Landroid/graphics/Typeface;->getSystemFontMap()Ljava/util/Map;

    move-result-object v7

    const-string/jumbo v8, "sans-en-semibold"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    move-object v5, v7

    check-cast v5, Landroid/graphics/Typeface;

    .line 755
    :cond_dd
    :goto_dd
    if-eqz v5, :cond_e0

    .line 756
    return-object v5

    .line 760
    :cond_e0
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->getReplaceTypefaceName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0}, Landroid/graphics/Typeface;->getStyle()I

    move-result v8

    invoke-virtual {p0}, Landroid/graphics/Typeface;->getWeight()I

    move-result v9

    invoke-static {v7, v1, v8, v9}, Lcom/oplus/util/OplusFontUtils;->createTypefaceKey(Ljava/lang/String;III)Ljava/lang/String;

    move-result-object v7

    .line 761
    .local v7, "key":Ljava/lang/String;
    sget-object v8, Lcom/oplus/util/OplusFontUtils;->sOplusVariationCacheMap:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v8, v7}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    move-object v5, v8

    check-cast v5, Landroid/graphics/Typeface;

    .line 762
    if-nez v5, :cond_108

    .line 763
    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->convertIntToString(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {p0, v8}, Lcom/oplus/util/OplusFontUtils;->createTypefaceWithVariation(Landroid/graphics/Typeface;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v5

    .line 764
    sget-object v8, Lcom/oplus/util/OplusFontUtils;->sOplusVariationCacheMap:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v8, v7, v5}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 767
    :cond_108
    return-object v5
.end method

.method public static blacklist handleFactoryReset()V
    .registers 2

    .line 399
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->sIsROM6d0FlipFont:Z

    if-eqz v0, :cond_1e

    .line 401
    :try_start_4
    new-instance v0, Ljava/io/File;

    const/4 v1, 0x0

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 402
    .local v0, "flipFontFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_17

    .line 403
    invoke-virtual {v0}, Ljava/io/File;->delete()Z
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_17} :catch_18

    .line 407
    .end local v0    # "flipFontFile":Ljava/io/File;
    :cond_17
    goto :goto_1e

    .line 405
    :catch_18
    move-exception v0

    .line 406
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "Failed handleFactoryReset"

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 409
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_1e
    :goto_1e
    return-void
.end method

.method public static blacklist initFontUtil()V
    .registers 7

    .line 847
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->renameFontFileName()V

    .line 848
    new-instance v0, Ljava/io/File;

    const/4 v1, 0x0

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 849
    .local v0, "fontFile":Ljava/io/File;
    const/4 v2, -0x1

    sput v2, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    .line 850
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_33

    .line 851
    new-instance v2, Ljava/util/Random;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-direct {v2, v3, v4}, Ljava/util/Random;-><init>(J)V

    .line 852
    .local v2, "randomizer":Ljava/util/Random;
    const/4 v3, 0x0

    .line 853
    .local v3, "min":I
    const/16 v4, 0x2710

    .line 854
    .local v4, "max":I
    sub-int v5, v4, v3

    const/4 v6, 0x1

    add-int/2addr v5, v6

    invoke-virtual {v2, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v5

    add-int/2addr v5, v3

    sput v5, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    .line 855
    sput-boolean v6, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    .line 856
    sget-boolean v5, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    sput-boolean v5, Loplus/content/res/OplusFontUtils;->isFlipFontUsed:Z

    .line 859
    .end local v2    # "randomizer":Ljava/util/Random;
    .end local v3    # "min":I
    .end local v4    # "max":I
    :cond_33
    invoke-static {}, Landroid/os/Process;->myUserHandle()Landroid/os/UserHandle;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/UserHandle;->hashCode()I

    move-result v2

    sput v2, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    .line 860
    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->checkAndCorrectFlipFontLink(Z)V

    .line 861
    return-void
.end method

.method public static blacklist initVariationFontVariable(Landroid/content/Context;)V
    .registers 2
    .param p0, "context"    # Landroid/content/Context;

    .line 542
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    .line 543
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->isOplusApp(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_17

    invoke-static {p0}, Lcom/oplus/util/OplusContextUtil;->isOplusOSStyle(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_17

    :cond_15
    const/4 v0, 0x0

    goto :goto_18

    :cond_17
    :goto_17
    const/4 v0, 0x1

    :goto_18
    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->sOplusStyle:Z

    .line 544
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->updateFontVariationRes()V

    .line 545
    return-void
.end method

.method public static blacklist isCurrentLanguageSupportMediumFont()Z
    .registers 3

    .line 412
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    .line 413
    .local v0, "currentLcale":Ljava/util/Locale;
    if-eqz v0, :cond_14

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->SUPPORT_MEDIUM_FONT_LANGUAGE_LIST:Ljava/util/List;

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    .line 414
    const/4 v1, 0x1

    return v1

    .line 416
    :cond_14
    const/4 v1, 0x0

    return v1
.end method

.method public static blacklist isCurrentLanguageSupportVariationFont()Z
    .registers 3

    .line 420
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    .line 421
    .local v0, "currentLocale":Ljava/util/Locale;
    if-eqz v0, :cond_14

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->SUPPORT_FONT_VARIATION_LIST:Ljava/util/List;

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    .line 422
    const/4 v1, 0x1

    return v1

    .line 424
    :cond_14
    const/4 v1, 0x0

    return v1
.end method

.method public static blacklist isLanguageNotSupportCertainFont(I)Z
    .registers 5
    .param p0, "fontVariationStatus"    # I

    .line 428
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    .line 429
    .local v0, "currentLocale":Ljava/util/Locale;
    const/4 v1, 0x0

    if-nez v0, :cond_8

    .line 430
    return v1

    .line 432
    :cond_8
    sget-object v2, Lcom/oplus/util/OplusFontUtils;->NOT_SUPPORT_FONT_VARIATION_LANGUAGE:Ljava/util/Map;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    .line 433
    .local v2, "langList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz v2, :cond_22

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_22

    .line 434
    const/4 v1, 0x1

    return v1

    .line 436
    :cond_22
    return v1
.end method

.method private static blacklist isOSansChanged(Loplus/content/res/OplusExtraConfiguration;I)Z
    .registers 9
    .param p0, "extraCfg"    # Loplus/content/res/OplusExtraConfiguration;
    .param p1, "changes"    # I

    .line 508
    const/4 v0, 0x0

    if-nez p0, :cond_4

    .line 509
    return v0

    .line 511
    :cond_4
    const/high16 v1, 0x1000000

    and-int/2addr v1, p1

    const/4 v2, 0x1

    if-eqz v1, :cond_c

    move v1, v2

    goto :goto_d

    :cond_c
    move v1, v0

    .line 512
    .local v1, "checkType":Z
    :goto_d
    sget-wide v3, Lcom/oplus/util/OplusFontUtils;->sPreOSansSettings:J

    iget v5, p0, Loplus/content/res/OplusExtraConfiguration;->mFontVariationSettings:I

    int-to-long v5, v5

    cmp-long v3, v3, v5

    if-eqz v3, :cond_18

    move v3, v2

    goto :goto_19

    :cond_18
    move v3, v0

    .line 513
    .local v3, "settingsChanged":Z
    :goto_19
    if-eqz v1, :cond_1e

    if-eqz v3, :cond_1e

    move v0, v2

    :cond_1e
    return v0
.end method

.method private static blacklist isOplusApp(Ljava/lang/String;)Z
    .registers 3
    .param p0, "packageName"    # Ljava/lang/String;

    .line 548
    const/4 v0, 0x0

    if-nez p0, :cond_4

    .line 549
    return v0

    .line 551
    :cond_4
    const-string v1, "com.heytap"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_36

    const-string v1, "com.oplus"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_36

    const-string v1, "com.coloros"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_36

    .line 552
    const-string v1, "com.oppo"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_36

    const-string v1, "com.nearme"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_36

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sWitheList:Ljava/util/List;

    invoke-interface {v1, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_35

    goto :goto_36

    .line 555
    :cond_35
    return v0

    .line 553
    :cond_36
    :goto_36
    const/4 v0, 0x1

    return v0
.end method

.method public static blacklist isOplusSansEnabled()Z
    .registers 3

    .line 1006
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_c

    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_b

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :cond_c
    :goto_c
    return v1
.end method

.method public static blacklist isOplusStyle()Z
    .registers 1

    .line 1012
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->sOplusStyle:Z

    return v0
.end method

.method private static blacklist killRunningProcess()V
    .registers 2

    .line 462
    :try_start_0
    new-instance v0, Lcom/oplus/util/OplusFontUtils$1;

    invoke-direct {v0}, Lcom/oplus/util/OplusFontUtils$1;-><init>()V

    .line 468
    invoke-virtual {v0}, Lcom/oplus/util/OplusFontUtils$1;->start()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_8} :catch_9

    .line 471
    goto :goto_f

    .line 469
    :catch_9
    move-exception v0

    .line 470
    .local v0, "e":Ljava/lang/Throwable;
    const-string v1, "<killRunningProcess>:"

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 472
    .end local v0    # "e":Ljava/lang/Throwable;
    :goto_f
    return-void
.end method

.method private static blacklist relinkDataFontToTarget(ILjava/io/File;)Z
    .registers 12
    .param p0, "target"    # I
    .param p1, "customFontFile"    # Ljava/io/File;

    .line 294
    const-string v0, " , "

    const-string v1, "FontUtils"

    const/4 v2, 0x0

    .local v2, "i":I
    :goto_5
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sFontLinkInfos:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x1

    if-ge v2, v3, :cond_128

    .line 295
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->sFontLinkInfos:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;

    .line 296
    .local v3, "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    new-instance v5, Ljava/io/File;

    iget-object v6, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-direct {v5, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 298
    .local v5, "dataFontLinkFile":Ljava/io/File;
    const/4 v6, 0x0

    :try_start_1e
    const-string v7, ""

    .line 299
    .local v7, "targetFont":Ljava/lang/String;
    if-ne p0, v4, :cond_2e

    .line 300
    iget-object v4, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mSystemFontName:Ljava/lang/String;

    invoke-static {v2, v4}, Lcom/oplus/util/OplusFontUtils;->getSystemFontLink(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v7, v4

    .line 301
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->relinkZhFont()Z

    goto/16 :goto_b6

    .line 302
    :cond_2e
    const/4 v4, 0x2

    if-ne p0, v4, :cond_b6

    .line 303
    invoke-static {v6}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v4

    move-object v7, v4

    .line 304
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v4
    :try_end_3a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1e .. :try_end_3a} :catch_121
    .catch Landroid/system/ErrnoException; {:try_start_1e .. :try_end_3a} :catch_107

    if-eqz v4, :cond_b6

    .line 306
    :try_start_3c
    new-instance v4, Landroid/graphics/fonts/Font$Builder;

    invoke-direct {v4, p1}, Landroid/graphics/fonts/Font$Builder;-><init>(Ljava/io/File;)V

    invoke-virtual {v4}, Landroid/graphics/fonts/Font$Builder;->build()Landroid/graphics/fonts/Font;

    move-result-object v4

    .line 307
    .local v4, "customFont":Landroid/graphics/fonts/Font;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "invalidate font file check  pass ! "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v1, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_5f
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_5f} :catch_8b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3c .. :try_end_5f} :catch_60
    .catch Landroid/system/ErrnoException; {:try_start_3c .. :try_end_5f} :catch_107

    .line 314
    .end local v4    # "customFont":Landroid/graphics/fonts/Font;
    goto :goto_b6

    .line 311
    :catch_60
    move-exception v4

    .line 312
    .local v4, "illegalArgumentException":Ljava/lang/IllegalArgumentException;
    :try_start_61
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "invalidate font file check  failed illegalArgumentException "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v4}, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v1, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 313
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    goto :goto_b6

    .line 308
    .end local v4    # "illegalArgumentException":Ljava/lang/IllegalArgumentException;
    :catch_8b
    move-exception v4

    .line 309
    .local v4, "ioException":Ljava/io/IOException;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "invalidate font file check  failed ioException "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v4}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v1, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 310
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 314
    nop

    .line 318
    .end local v4    # "ioException":Ljava/io/IOException;
    :cond_b6
    :goto_b6
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_e8

    .line 319
    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    .line 320
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "relink font targetFont = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v8, ", "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v8, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 322
    iget-object v4, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/system/Os;->symlink(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_102

    .line 323
    :cond_e8
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_102

    iget-object v4, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    .line 324
    invoke-static {v4}, Landroid/system/Os;->readlink(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_102

    .line 325
    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    .line 326
    iget-object v4, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-static {v7, v4}, Landroid/system/Os;->symlink(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_102
    .catch Ljava/lang/IllegalArgumentException; {:try_start_61 .. :try_end_102} :catch_121
    .catch Landroid/system/ErrnoException; {:try_start_61 .. :try_end_102} :catch_107

    .line 334
    .end local v7    # "targetFont":Ljava/lang/String;
    :cond_102
    :goto_102
    nop

    .line 294
    .end local v3    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .end local v5    # "dataFontLinkFile":Ljava/io/File;
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_5

    .line 331
    .restart local v3    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .restart local v5    # "dataFontLinkFile":Ljava/io/File;
    :catch_107
    move-exception v0

    .line 332
    .local v0, "e":Landroid/system/ErrnoException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Could not update selinux policy check and correct flipfont: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, v3, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 333
    return v6

    .line 328
    .end local v0    # "e":Landroid/system/ErrnoException;
    :catch_121
    move-exception v0

    .line 329
    .local v0, "e":Ljava/lang/IllegalArgumentException;
    const-string v1, "SELinux policy update check and correct flipfont"

    invoke-static {v1, v0}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 330
    return v6

    .line 336
    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    .end local v2    # "i":I
    .end local v3    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .end local v5    # "dataFontLinkFile":Ljava/io/File;
    :cond_128
    return v4
.end method

.method private static blacklist relinkZhFont()Z
    .registers 7

    .line 340
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1
    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sFontLinkInfosZH:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_92

    .line 341
    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sFontLinkInfosZH:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;

    .line 342
    .local v1, "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    new-instance v2, Ljava/io/File;

    iget-object v3, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 344
    .local v2, "dataFontLinkFile":Ljava/io/File;
    const/4 v3, 0x0

    :try_start_19
    iget-object v4, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mSystemFontName:Ljava/lang/String;

    invoke-static {v0, v4}, Lcom/oplus/util/OplusFontUtils;->getSystemZHFontLink(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 345
    .local v4, "targetFont":Ljava/lang/String;
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_51

    .line 346
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 347
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "relink zh_font targetFont = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 349
    iget-object v5, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-static {v4, v5}, Landroid/system/Os;->symlink(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6b

    .line 350
    :cond_51
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_6b

    iget-object v5, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    .line 351
    invoke-static {v5}, Landroid/system/Os;->readlink(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6b

    .line 352
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 353
    iget-object v5, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-static {v4, v5}, Landroid/system/Os;->symlink(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_6b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_19 .. :try_end_6b} :catch_8a
    .catch Landroid/system/ErrnoException; {:try_start_19 .. :try_end_6b} :catch_6f

    .line 361
    .end local v4    # "targetFont":Ljava/lang/String;
    :cond_6b
    :goto_6b
    nop

    .line 340
    .end local v1    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .end local v2    # "dataFontLinkFile":Ljava/io/File;
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 358
    .restart local v1    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .restart local v2    # "dataFontLinkFile":Ljava/io/File;
    :catch_6f
    move-exception v4

    .line 359
    .local v4, "e":Landroid/system/ErrnoException;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "relinkZhFont Could not update selinux policy check and correct flipfont: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, v1, Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;->mDataFontName:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v4}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 360
    return v3

    .line 355
    .end local v4    # "e":Landroid/system/ErrnoException;
    :catch_8a
    move-exception v4

    .line 356
    .local v4, "e":Ljava/lang/IllegalArgumentException;
    const-string/jumbo v5, "relinkZhFont SELinux policy update check and correct flipfont"

    invoke-static {v5, v4}, Lcom/oplus/util/OplusFontUtils;->loge(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 357
    return v3

    .line 363
    .end local v0    # "i":I
    .end local v1    # "fontLinkInfo":Lcom/oplus/util/OplusBaseFontUtils$FontLinkInfo;
    .end local v2    # "dataFontLinkFile":Ljava/io/File;
    .end local v4    # "e":Ljava/lang/IllegalArgumentException;
    :cond_92
    const/4 v0, 0x1

    return v0
.end method

.method private static blacklist renameFontFileName()V
    .registers 4

    .line 107
    const/4 v0, 0x1

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v0

    .line 108
    .local v0, "fontFilePath":Ljava/lang/String;
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 109
    .local v1, "oldFile":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_27

    .line 110
    new-instance v2, Ljava/io/File;

    const/4 v3, 0x0

    invoke-static {v3}, Lcom/oplus/util/OplusFontUtils;->getCustomizedFontFile(Z)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v2

    if-nez v2, :cond_27

    .line 111
    const-string v2, "FontUtils"

    const-string v3, "Failed to rename to new font file!"

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 114
    :cond_27
    return-void
.end method

.method public static blacklist replaceFakeBoldToColorMedium(Landroid/widget/TextView;Landroid/graphics/ITypefaceExt;I)V
    .registers 6
    .param p0, "textView"    # Landroid/widget/TextView;
    .param p1, "typefaceExt"    # Landroid/graphics/ITypefaceExt;
    .param p2, "style"    # I

    .line 243
    if-nez p0, :cond_3

    .line 244
    return-void

    .line 246
    :cond_3
    const/4 v0, 0x0

    .line 247
    .local v0, "typeface":Landroid/graphics/Typeface;
    if-eqz p1, :cond_a

    .line 248
    invoke-interface {p1}, Landroid/graphics/ITypefaceExt;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    .line 250
    :cond_a
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->sIsCheckCTS:Z

    if-nez v1, :cond_45

    sget v1, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    if-eqz v1, :cond_45

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq p2, v1, :cond_18

    if-ne p2, v2, :cond_45

    :cond_18
    if-eqz v0, :cond_36

    if-eqz p1, :cond_22

    .line 252
    invoke-interface {p1}, Landroid/graphics/ITypefaceExt;->isSystemTypeface()Z

    move-result v1

    if-nez v1, :cond_36

    :cond_22
    sget-object v1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    invoke-virtual {v1, v0}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_36

    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    if-eqz v1, :cond_45

    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    :cond_36
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportMediumFont:Z

    if-eqz v1, :cond_45

    .line 254
    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    if-ne p2, v2, :cond_40

    const/4 v2, 0x2

    goto :goto_41

    :cond_40
    const/4 v2, 0x0

    :goto_41
    invoke-virtual {p0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_48

    .line 256
    :cond_45
    invoke-virtual {p0, v0, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 258
    :goto_48
    return-void
.end method

.method public static blacklist replaceSysSans(Landroid/graphics/Typeface;Ljava/lang/String;)Landroid/graphics/Typeface;
    .registers 3
    .param p0, "typeface"    # Landroid/graphics/Typeface;
    .param p1, "familyName"    # Ljava/lang/String;

    .line 995
    const-string/jumbo v0, "sys-sans-en"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    .line 996
    const-string/jumbo v0, "op-sans-en"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    .line 997
    const-string/jumbo v0, "sys-serif"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_24

    .line 998
    :cond_1b
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportVariationFont()Z

    move-result v0

    if-nez v0, :cond_24

    .line 999
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    return-object v0

    .line 1001
    :cond_24
    return-object p0
.end method

.method public static blacklist replaceTypefaceWithVariation(Landroid/graphics/Typeface;Landroid/graphics/Paint;)Landroid/graphics/Typeface;
    .registers 6
    .param p0, "typeface"    # Landroid/graphics/Typeface;
    .param p1, "paint"    # Landroid/graphics/Paint;

    .line 475
    invoke-virtual {p1}, Landroid/graphics/Paint;->getFontVariationSettings()Ljava/lang/String;

    move-result-object v0

    .line 476
    .local v0, "fv":Ljava/lang/String;
    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->extractWghtParamStr(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 478
    .local v1, "extractWghtStrInFv":Ljava/lang/String;
    if-eqz v0, :cond_12

    sget-object v2, Lcom/oplus/util/OplusFontUtils;->sLastFontVariationSettings:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1d

    .line 479
    :cond_12
    invoke-virtual {p1}, Landroid/graphics/Paint;->getWrapper()Landroid/graphics/IPaintWrapper;

    move-result-object v2

    .line 480
    .local v2, "wrapper":Landroid/graphics/IPaintWrapper;
    sget-object v3, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    invoke-interface {v2, v3}, Landroid/graphics/IPaintWrapper;->setFontVariationSettings(Ljava/lang/String;)V

    .line 481
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    .line 484
    .end local v2    # "wrapper":Landroid/graphics/IPaintWrapper;
    :cond_1d
    invoke-static {p0, v0}, Lcom/oplus/util/OplusFontUtils;->getVariationFontFromCache(Landroid/graphics/Typeface;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    return-object v2
.end method

.method public static blacklist setAppTypeFace(Ljava/lang/String;)V
    .registers 2
    .param p0, "sAppName"    # Ljava/lang/String;

    .line 183
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FLITER_CTS_APP_PKG_LIST:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 184
    const/4 v0, 0x1

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->sIsCheckCTS:Z

    .line 186
    :cond_b
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->FLITER_NOT_REPLACEFONT_APP_PKG_LIST:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_16

    .line 187
    const/4 v0, 0x0

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->sReplaceFont:Z

    .line 189
    :cond_16
    return-void
.end method

.method public static blacklist setFlipFont(Landroid/content/res/Configuration;)V
    .registers 4
    .param p0, "configuration"    # Landroid/content/res/Configuration;

    .line 94
    const-class v0, Landroid/content/res/OplusBaseConfiguration;

    invoke-static {v0, p0}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/res/OplusBaseConfiguration;

    .line 95
    .local v0, "baseConfiguration":Landroid/content/res/OplusBaseConfiguration;
    if-eqz v0, :cond_55

    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    if-eqz v1, :cond_55

    sget v1, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    iget-object v2, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v2, v2, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    if-eq v1, v2, :cond_55

    .line 96
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "SetFlipFont -- sFlipFont="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", sIsROM6d0FlipFont= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-boolean v2, Lcom/oplus/util/OplusFontUtils;->sIsROM6d0FlipFont:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " --> mFlipFont="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v2, v2, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 97
    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v1, v1, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    sput v1, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    .line 98
    const/4 v1, 0x0

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->checkAndCorrectFlipFontLink(Z)V

    .line 102
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->doUpdateTypeface(Landroid/content/res/Configuration;)V

    .line 104
    :cond_55
    return-void
.end method

.method public static blacklist setFlipFontWhenUserChange(Landroid/content/res/Configuration;)V
    .registers 5
    .param p0, "configuration"    # Landroid/content/res/Configuration;

    .line 120
    const-class v0, Landroid/content/res/OplusBaseConfiguration;

    invoke-static {v0, p0}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/res/OplusBaseConfiguration;

    .line 121
    .local v0, "baseConfiguration":Landroid/content/res/OplusBaseConfiguration;
    if-eqz v0, :cond_46

    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v1, v1, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    if-ltz v1, :cond_46

    .line 122
    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v1, v1, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    .line 123
    .local v1, "currentUserId":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "setFlipFontWhenUserChange -- mUserId in mExtraConfiguration = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", sUserId = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget v3, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 125
    iget-object v2, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v2, v2, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    sput v2, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    .line 126
    sput v1, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    .line 127
    const/4 v2, 0x1

    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->checkAndCorrectFlipFontLink(Z)V

    .line 131
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->doUpdateTypeface(Landroid/content/res/Configuration;)V

    .line 133
    .end local v1    # "currentUserId":I
    :cond_46
    return-void
.end method

.method public static blacklist setIMEFlag(Z)V
    .registers 3
    .param p0, "isIme"    # Z

    .line 835
    const-string v0, "com.google.android.marvin.talkback"

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    .line 836
    const-string v1, "com.oplus.securitykeyboard"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_18

    .line 839
    :cond_15
    sput-boolean p0, Lcom/oplus/util/OplusFontUtils;->sIsIme:Z

    goto :goto_1b

    .line 837
    :cond_18
    :goto_18
    const/4 v0, 0x0

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->sIsIme:Z

    .line 841
    :goto_1b
    return-void
.end method

.method public static blacklist setNeedReplaceAllTypefaceApp(Z)V
    .registers 1
    .param p0, "flag"    # Z

    .line 195
    sput-boolean p0, Lcom/oplus/util/OplusFontUtils;->sNeedReplaceAllTypefaceApp:Z

    .line 196
    return-void
.end method

.method public static blacklist shouldReplaceToOSans(Landroid/graphics/ITypefaceExt;)Z
    .registers 6
    .param p0, "typefaceExt"    # Landroid/graphics/ITypefaceExt;

    .line 679
    sget-object v0, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_VF:Landroid/graphics/Typeface;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    .line 680
    return v1

    .line 683
    :cond_6
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    if-nez v0, :cond_b

    .line 684
    return v1

    .line 687
    :cond_b
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportVariationFont:Z

    if-nez v0, :cond_10

    .line 688
    return v1

    .line 691
    :cond_10
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->isLanguageNotSupportCertainFont(I)Z

    move-result v0

    if-eqz v0, :cond_19

    .line 692
    return v1

    .line 695
    :cond_19
    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    if-eqz v0, :cond_1e

    .line 696
    return v1

    .line 699
    :cond_1e
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->isSystemTypeface()Z

    move-result v0

    if-nez v0, :cond_25

    .line 700
    return v1

    .line 702
    :cond_25
    invoke-interface {p0}, Landroid/graphics/ITypefaceExt;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    .line 703
    .local v0, "tf":Landroid/graphics/Typeface;
    if-eqz v0, :cond_39

    const-string/jumbo v2, "osans-solid-digits"

    invoke-virtual {v0}, Landroid/graphics/Typeface;->getSystemFontFamilyName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_39

    .line 704
    return v1

    .line 706
    :cond_39
    sget-boolean v2, Lcom/oplus/util/OplusFontUtils;->sIsCheckCTS:Z

    sget-boolean v3, Lcom/oplus/util/OplusFontUtils;->sReplaceFont:Z

    const/4 v4, 0x1

    xor-int/2addr v3, v4

    or-int/2addr v2, v3

    if-eqz v2, :cond_43

    .line 707
    return v1

    .line 710
    :cond_43
    return v4
.end method

.method public static blacklist updateConfigurationInUIMode(Landroid/content/Context;Landroid/content/res/Configuration;I)V
    .registers 14
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "config"    # Landroid/content/res/Configuration;
    .param p2, "userId"    # I

    .line 813
    iget v0, p1, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 v0, v0, 0x20

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_a

    move v0, v1

    goto :goto_b

    :cond_a
    move v0, v2

    .line 814
    .local v0, "isNightMode":Z
    :goto_b
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "font_variation_settings"

    const/16 v5, 0x1226

    invoke-static {v3, v4, v5, p2}, Landroid/provider/Settings$System;->getIntForUser(Landroid/content/ContentResolver;Ljava/lang/String;II)I

    move-result v3

    .line 815
    .local v3, "fontVariationSettings":I
    const/high16 v4, -0x10000

    and-int/2addr v4, v3

    .line 816
    .local v4, "vectorDrawableConfig":I
    and-int/lit16 v5, v3, 0xfff

    .line 817
    .local v5, "variation":I
    const v6, 0xf000

    and-int v7, v3, v6

    shr-int/lit8 v7, v7, 0xc

    .line 818
    .local v7, "status":I
    const/4 v8, 0x2

    if-ne v7, v8, :cond_2e

    .line 819
    if-eqz v0, :cond_2b

    const/16 v8, 0x1f4

    goto :goto_2d

    :cond_2b
    const/16 v8, 0x226

    :goto_2d
    move v5, v8

    .line 821
    :cond_2e
    sget v8, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    if-eq v7, v8, :cond_33

    goto :goto_34

    :cond_33
    move v1, v2

    .line 822
    .local v1, "isStatusChanged":Z
    :goto_34
    sput v7, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    .line 823
    shl-int/lit8 v8, v7, 0xc

    and-int/2addr v6, v8

    .line 824
    .end local v7    # "status":I
    .local v6, "status":I
    const-class v7, Landroid/content/res/OplusBaseConfiguration;

    invoke-static {v7, p1}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/content/res/OplusBaseConfiguration;

    .line 825
    .local v7, "baseConfiguration":Landroid/content/res/OplusBaseConfiguration;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "updateConfigurationInUIMode:  isNightMode="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " status="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " variation="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 826
    or-int v8, v5, v6

    .line 827
    .local v8, "fontConfig":I
    iget-object v9, v7, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    or-int v10, v4, v8

    iput v10, v9, Loplus/content/res/OplusExtraConfiguration;->mFontVariationSettings:I

    .line 828
    if-eqz v1, :cond_7c

    .line 829
    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->checkAndCorrectFlipFontLink(Z)V

    .line 830
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->killRunningProcess()V

    .line 832
    :cond_7c
    return-void
.end method

.method private static blacklist updateFontVariationRes()V
    .registers 3

    .line 562
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    packed-switch v0, :pswitch_data_d8

    .line 583
    :pswitch_5
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    .local v0, "newFv":Ljava/lang/String;
    goto :goto_3f

    .line 572
    .end local v0    # "newFv":Ljava/lang/String;
    :pswitch_8
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationAdaption:I

    if-nez v0, :cond_1f

    sget-boolean v0, Lcom/oplus/util/OplusFontUtils;->isSearched:Z

    if-nez v0, :cond_1f

    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    if-eqz v0, :cond_1f

    .line 573
    sget-object v0, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->getAdaptionValue(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationAdaption:I

    .line 574
    const/4 v0, 0x1

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->isSearched:Z

    .line 576
    :cond_1f
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationAdaption:I

    if-eqz v0, :cond_2a

    .line 577
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationAdaption:I

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->convertIntToString(I)Ljava/lang/String;

    move-result-object v0

    .restart local v0    # "newFv":Ljava/lang/String;
    goto :goto_3f

    .line 579
    .end local v0    # "newFv":Ljava/lang/String;
    :cond_2a
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariation:I

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->convertIntToString(I)Ljava/lang/String;

    move-result-object v0

    .line 581
    .restart local v0    # "newFv":Ljava/lang/String;
    goto :goto_3f

    .line 569
    .end local v0    # "newFv":Ljava/lang/String;
    :pswitch_31
    sget v0, Lcom/oplus/util/OplusFontUtils;->mFontVariation:I

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->convertIntToString(I)Ljava/lang/String;

    move-result-object v0

    .line 570
    .restart local v0    # "newFv":Ljava/lang/String;
    goto :goto_3f

    .line 564
    .end local v0    # "newFv":Ljava/lang/String;
    :pswitch_38
    const/16 v0, 0x226

    invoke-static {v0}, Lcom/oplus/util/OplusFontUtils;->convertIntToString(I)Ljava/lang/String;

    move-result-object v0

    .line 565
    .restart local v0    # "newFv":Ljava/lang/String;
    nop

    .line 587
    :goto_3f
    sget-object v1, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4d

    .line 588
    sget-object v1, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    sput-object v1, Lcom/oplus/util/OplusFontUtils;->sLastFontVariationSettings:Ljava/lang/String;

    .line 589
    sput-object v0, Lcom/oplus/util/OplusFontUtils;->mFontVariationSettings:Ljava/lang/String;

    .line 593
    :cond_4d
    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_VF:Landroid/graphics/Typeface;

    if-eqz v1, :cond_5d

    sget-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    if-eqz v1, :cond_5d

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sOneplusVf:Landroid/graphics/Typeface;

    if-eqz v1, :cond_5d

    sget-object v1, Lcom/oplus/util/OplusFontUtils;->sOplusSerifVf:Landroid/graphics/Typeface;

    if-nez v1, :cond_99

    .line 595
    :cond_5d
    invoke-static {}, Landroid/graphics/OplusTypefaceInjector;->getSystemFontMap()Ljava/util/Map;

    move-result-object v1

    const-string/jumbo v2, "sys-sans-en"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Typeface;

    sput-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_VF:Landroid/graphics/Typeface;

    .line 596
    invoke-static {}, Landroid/graphics/OplusTypefaceInjector;->getSystemFontMap()Ljava/util/Map;

    move-result-object v1

    const-string/jumbo v2, "sans-serif-medium"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Typeface;

    sput-object v1, Landroid/graphics/OplusTypefaceInjector;->OPLUSUI_MEDIUM:Landroid/graphics/Typeface;

    .line 597
    invoke-static {}, Landroid/graphics/OplusTypefaceInjector;->getSystemFontMap()Ljava/util/Map;

    move-result-object v1

    const-string/jumbo v2, "op-sans-en"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Typeface;

    sput-object v1, Lcom/oplus/util/OplusFontUtils;->sOneplusVf:Landroid/graphics/Typeface;

    .line 598
    invoke-static {}, Landroid/graphics/OplusTypefaceInjector;->getSystemFontMap()Ljava/util/Map;

    move-result-object v1

    const-string/jumbo v2, "sys-serif"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Typeface;

    sput-object v1, Lcom/oplus/util/OplusFontUtils;->sOplusSerifVf:Landroid/graphics/Typeface;

    .line 601
    :cond_99
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "updateFontVariationConfiguration: mFontVariation = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/oplus/util/OplusFontUtils;->mFontVariation:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " mFontVariationStatus = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " mPackageName = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " mFontVariationAdaption = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v2, Lcom/oplus/util/OplusFontUtils;->mFontVariationAdaption:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 606
    return-void

    nop

    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_38
        :pswitch_31
        :pswitch_8
        :pswitch_31
        :pswitch_5
        :pswitch_31
    .end packed-switch
.end method

.method public static blacklist updateLanguageLocale(Landroid/content/res/Configuration;)V
    .registers 2
    .param p0, "config"    # Landroid/content/res/Configuration;

    .line 537
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportVariationFont()Z

    move-result v0

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportVariationFont:Z

    .line 538
    const/4 v0, 0x1

    sput-boolean v0, Lcom/oplus/util/OplusFontUtils;->isCurrentLanguageSupportMediumFont:Z

    .line 539
    return-void
.end method

.method public static blacklist updateOSansConfig(Landroid/content/res/Configuration;I)Z
    .registers 9
    .param p0, "config"    # Landroid/content/res/Configuration;
    .param p1, "changes"    # I

    .line 517
    and-int/lit8 v0, p1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_8

    move v0, v1

    goto :goto_9

    :cond_8
    move v0, v2

    .line 518
    .local v0, "localeChanged":Z
    :goto_9
    if-eqz v0, :cond_e

    .line 519
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->updateLanguageLocale(Landroid/content/res/Configuration;)V

    .line 521
    :cond_e
    const-class v3, Landroid/content/res/OplusBaseConfiguration;

    invoke-static {v3, p0}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/res/OplusBaseConfiguration;

    .line 522
    .local v3, "baseCfg":Landroid/content/res/OplusBaseConfiguration;
    if-nez v3, :cond_19

    .line 523
    return v2

    .line 525
    :cond_19
    iget-object v4, v3, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    .line 526
    .local v4, "extraCfg":Loplus/content/res/OplusExtraConfiguration;
    invoke-static {v4, p1}, Lcom/oplus/util/OplusFontUtils;->isOSansChanged(Loplus/content/res/OplusExtraConfiguration;I)Z

    move-result v5

    if-eqz v5, :cond_3a

    .line 527
    iget v2, v4, Loplus/content/res/OplusExtraConfiguration;->mFontVariationSettings:I

    and-int/lit16 v2, v2, 0xfff

    sput v2, Lcom/oplus/util/OplusFontUtils;->mFontVariation:I

    .line 528
    iget v2, v4, Loplus/content/res/OplusExtraConfiguration;->mFontVariationSettings:I

    const v5, 0xf000

    and-int/2addr v2, v5

    shr-int/lit8 v2, v2, 0xc

    sput v2, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    .line 529
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->updateFontVariationRes()V

    .line 530
    iget v2, v4, Loplus/content/res/OplusExtraConfiguration;->mFontVariationSettings:I

    int-to-long v5, v2

    sput-wide v5, Lcom/oplus/util/OplusFontUtils;->sPreOSansSettings:J

    .line 531
    return v1

    .line 533
    :cond_3a
    return v2
.end method

.method private static blacklist updateThemeStoreFontConfig(Landroid/content/res/Configuration;I)Z
    .registers 6
    .param p0, "configuration"    # Landroid/content/res/Configuration;
    .param p1, "changes"    # I

    .line 157
    const-class v0, Landroid/content/res/OplusBaseConfiguration;

    invoke-static {v0, p0}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/res/OplusBaseConfiguration;

    .line 158
    .local v0, "baseConfiguration":Landroid/content/res/OplusBaseConfiguration;
    const/4 v1, 0x0

    if-nez v0, :cond_c

    .line 159
    return v1

    .line 161
    :cond_c
    iget-object v2, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v2, v2, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    const/4 v3, -0x1

    if-ne v2, v3, :cond_19

    .line 162
    const-string v2, "invalid mFontUserId in extraConfiguration -1, abandon"

    invoke-static {v2}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 163
    return v1

    .line 167
    :cond_19
    sget v2, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    iget-object v3, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v3, v3, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    if-ne v2, v3, :cond_2a

    sget v2, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    iget-object v3, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v3, v3, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    if-ne v2, v3, :cond_2a

    .line 169
    return v1

    .line 172
    :cond_2a
    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v1, v1, Loplus/content/res/OplusExtraConfiguration;->mFlipFont:I

    sput v1, Lcom/oplus/util/OplusFontUtils;->sFlipFont:I

    .line 173
    iget-object v1, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v1, v1, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    sput v1, Lcom/oplus/util/OplusFontUtils;->sUserId:I

    .line 174
    invoke-static {p0}, Lcom/oplus/util/OplusFontUtils;->doUpdateTypeface(Landroid/content/res/Configuration;)V

    .line 175
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "<updateTypefaceInCurrProcess> myTid = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " , fliped = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-boolean v2, Lcom/oplus/util/OplusFontUtils;->isFlipFontUsed:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", myUid = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 176
    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", myPid = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", mFontUserId = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v0, Landroid/content/res/OplusBaseConfiguration;->mOplusExtraConfiguration:Loplus/content/res/OplusExtraConfiguration;

    iget v2, v2, Loplus/content/res/OplusExtraConfiguration;->mFontUserId:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 175
    invoke-static {v1}, Lcom/oplus/util/OplusFontUtils;->logd(Ljava/lang/String;)V

    .line 178
    const/4 v1, 0x1

    return v1
.end method

.method public static blacklist updateTypefaceInCurrProcess(Landroid/content/res/Configuration;I)V
    .registers 5
    .param p0, "configuration"    # Landroid/content/res/Configuration;
    .param p1, "changes"    # I

    .line 140
    const/4 v0, 0x0

    .line 142
    .local v0, "changed":Z
    invoke-static {p0, p1}, Lcom/oplus/util/OplusFontUtils;->updateThemeStoreFontConfig(Landroid/content/res/Configuration;I)Z

    move-result v0

    .line 144
    invoke-static {p0, p1}, Lcom/oplus/util/OplusFontUtils;->updateOSansConfig(Landroid/content/res/Configuration;I)Z

    move-result v1

    or-int/2addr v0, v1

    .line 146
    if-eqz v0, :cond_51

    .line 147
    invoke-static {}, Lcom/oplus/util/OplusFontUtils;->freeCaches()V

    .line 148
    sget-boolean v1, Lcom/oplus/util/OplusFontUtils;->sIsIme:Z

    if-eqz v1, :cond_51

    sget v1, Lcom/oplus/util/OplusFontUtils;->mFontVariationStatus:I

    const/4 v2, 0x2

    if-eq v1, v2, :cond_51

    .line 149
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "kill:IME "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lcom/oplus/util/OplusFontUtils;->mPackageName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    new-instance v2, Ljava/lang/Throwable;

    invoke-direct {v2}, Ljava/lang/Throwable;-><init>()V

    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "FontUtils"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 150
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 153
    :cond_51
    return-void
.end method
