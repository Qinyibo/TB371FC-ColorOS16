.class public Lcom/oplus/zoomwindow/OplusZoomWindowManager$ZoomConstant;
.super Ljava/lang/Object;
.source "OplusZoomWindowManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/zoomwindow/OplusZoomWindowManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZoomConstant"
.end annotation


# static fields
.field public static final whitelist CHANG_ZOOM_TASK_TO_BACK:I = 0x6

.field public static final whitelist CHANG_ZOOM_TASK_TO_DEFAULT:I = 0x3

.field public static final whitelist CHANG_ZOOM_TASK_TO_FLOAT:I = 0x5

.field public static final whitelist CHANG_ZOOM_TASK_TO_FULL:I = 0x4

.field public static final whitelist CHANG_ZOOM_TASK_TO_MINI:I = 0x1

.field public static final whitelist CHANG_ZOOM_TASK_TO_SPLIT:I = 0x7

.field public static final whitelist CHANG_ZOOM_TASK_TO_ZOOM:I = 0x2

.field public static final whitelist EVENT_RECENT_HOME_CLICK:I = 0x1

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_AFTER:I = 0x3

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_BEFORE:I = 0x1

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_FULL_TO_ZOOM:I = 0x2

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_MINI_TO_SUPER_MINI:I = 0x6

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_SHARE:I = 0x4

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_SUPER_MINI_TO_MINI:I = 0x5

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_ZOOM_TO_SUPER_MINI_LEFT:I = 0x8

.field public static final whitelist ZOOM_EVENT_GLOBAL_DRAG_ZOOM_TO_SUPER_MINI_RIGHT:I = 0x7

.field public static final whitelist ZOOM_FLOAT_STATE:I = 0x3

.field public static final whitelist ZOOM_IDLE_STATE:I = 0x0

.field public static final whitelist ZOOM_MINI_STATE:I = 0x2

.field public static final whitelist ZOOM_SCALE_STATE:I = 0x4

.field public static final whitelist ZOOM_STATE:I = 0x1

.field public static final whitelist ZOOM_SUPER_MINI_STATE:I = 0x5


# direct methods
.method public constructor whitelist <init>()V
    .registers 1

    .line 601
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
