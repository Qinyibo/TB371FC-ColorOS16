.class Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;
.super Lcom/oplus/app/IOplusZoomWindowConfigChangedListener$Stub;
.source "OplusZoomWindowManager.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/zoomwindow/OplusZoomWindowManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "OnConfigChangeListenerDelegate"
.end annotation


# static fields
.field private static final blacklist MSG_CONFIG_SWITCH_CHANGED:I = 0x2

.field private static final blacklist MSG_CONFIG_TYPE_CHANGED:I = 0x1


# instance fields
.field private final blacklist mHandler:Landroid/os/Handler;

.field private final blacklist mListener:Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;


# direct methods
.method public constructor blacklist <init>(Lcom/oplus/zoomwindow/OplusZoomWindowManager;Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;Landroid/os/Looper;)V
    .registers 4
    .param p2, "listener"    # Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;
    .param p3, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 1112
    invoke-direct {p0}, Lcom/oplus/app/IOplusZoomWindowConfigChangedListener$Stub;-><init>()V

    .line 1113
    iput-object p2, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mListener:Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;

    .line 1114
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1, p3, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    iput-object p1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mHandler:Landroid/os/Handler;

    .line 1115
    return-void
.end method


# virtual methods
.method public whitelist handleMessage(Landroid/os/Message;)Z
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;

    .line 1129
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    packed-switch v0, :pswitch_data_1c

    .line 1141
    return v1

    .line 1136
    :pswitch_8
    iget v0, p1, Landroid/os/Message;->arg1:I

    if-eqz v0, :cond_d

    move v1, v2

    .line 1137
    .local v1, "enable":Z
    :cond_d
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mListener:Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;

    invoke-interface {v0, v1}, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;->onConfigSwitchChanged(Z)V

    .line 1138
    return v2

    .line 1131
    .end local v1    # "enable":Z
    :pswitch_13
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 1132
    .local v0, "type":I
    iget-object v1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mListener:Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;

    invoke-interface {v1, v0}, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;->onConfigTypeChanged(I)V

    .line 1133
    return v2

    nop

    :pswitch_data_1c
    .packed-switch 0x1
        :pswitch_13
        :pswitch_8
    .end packed-switch
.end method

.method public blacklist onConfigSwitchChanged(Z)V
    .registers 5
    .param p1, "enable"    # Z

    .line 1124
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mHandler:Landroid/os/Handler;

    .line 1125
    nop

    .line 1124
    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    .line 1125
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1126
    return-void
.end method

.method public blacklist onConfigTypeChanged(I)V
    .registers 5
    .param p1, "type"    # I

    .line 1119
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1120
    return-void
.end method
