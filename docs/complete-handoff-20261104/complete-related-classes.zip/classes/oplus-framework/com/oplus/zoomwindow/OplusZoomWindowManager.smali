.class public Lcom/oplus/zoomwindow/OplusZoomWindowManager;
.super Ljava/lang/Object;
.source "OplusZoomWindowManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;,
        Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;,
        Lcom/oplus/zoomwindow/OplusZoomWindowManager$ZoomConstant;
    }
.end annotation


# static fields
.field public static final whitelist ACTION_DEFAULT_HANDLE:I = 0x1

.field public static final whitelist ACTION_DELETE_HANDLE:I = 0x10

.field public static final whitelist ACTION_INVISIBLE_HANDLE:I = 0x4

.field public static final whitelist ACTION_MASK_FOR_FLOAT_HANDLE:I = 0x1c

.field public static final whitelist ACTION_MASK_ON_SHOWING_OF_MINI_ZOOM_MODE:I = -0x2001

.field public static final whitelist ACTION_MASK_ON_SHOWING_OF_ZOOM_MODE:I = -0x2

.field public static final whitelist ACTION_NEW_HANDLE:I = 0x8

.field public static final whitelist ACTION_RELAUNCH_HANDLE:I = 0x20

.field public static final whitelist ACTION_VISIBLE_HANDLE:I = 0x2

.field public static final blacklist DEFAULT_TOP_OFFSET_OF_ZOOM_PORTRAIT:I = 0x10d

.field public static final blacklist DISMISS_SPLIT_SCREEN_FROM_ZOOM_MODE:I = 0x9

.field public static final blacklist EXTRA_HANDWRITING_PEN_ARRAY:Ljava/lang/String; = "extra_Handwriting_pen_array"

.field public static final whitelist EXTRA_WINDOW_MODE:Ljava/lang/String; = "extra_window_mode"

.field public static final whitelist FLAG_BUBBLE_ZOOM_WINDOW:I = 0x2

.field public static final whitelist FLAG_CLICKED_FULL_SCREEN_BUTTON:I = 0x5

.field public static final whitelist FLAG_CLICK_OUTSIDE_ZOOM:I = 0x3

.field public static final whitelist FLAG_DELETE_MINI_ZOOM_WINDOW:I = 0x8

.field public static final whitelist FLAG_DELETE_ON_ACTION_SIMPLE_MODE_BUTTON:I = 0x10

.field public static final whitelist FLAG_DELETE_ON_ACTION_USER_SWITCHED:I = 0xf

.field public static final whitelist FLAG_DELETE_ON_BLOCKING_PACKAGE:I = 0x11

.field public static final whitelist FLAG_DELETE_ON_CLICKED_CLOSED_ZOOM:I = 0xe

.field public static final whitelist FLAG_DELETE_ON_ENTER_DRAG_WINDOW:I = 0xa

.field public static final whitelist FLAG_DELETE_ON_ENTER_SPEC_MODE:I = 0xd

.field public static final whitelist FLAG_DELETE_ZOOM_BY_RECENTS:I = 0xc

.field public static final whitelist FLAG_DELETE_ZOOM_BY_SCREEN_OFF:I = 0xb

.field public static final whitelist FLAG_DELETE_ZOOM_WINDOW:I = 0x1

.field public static final whitelist FLAG_DELETE_ZOOM_WINDOW_BY_GLOBAL_DRAG:I = 0x9

.field public static final whitelist FLAG_EXIT_ZOOM_BY_OTHERS:I = 0x6

.field public static final whitelist FLAG_HIDE_ZOOM_WINDOW:I = 0x2

.field public static final whitelist FLAG_MOVE_TO_HOT_EDGE:I = 0x7

.field public static final whitelist FLAG_ON_DEFAULT_ACTION:I = 0x0

.field public static final whitelist FLAG_ON_DEFAULT_EVENT:I = 0x0

.field public static final whitelist FLAG_ON_DELETE_CONTROL_VIEW:I = 0x2

.field public static final whitelist FLAG_ON_DELETE_HANDLE:I = 0x8

.field public static final whitelist FLAG_ON_DELETE_MINI_ZOOM_BUTTON_RESTORE:I = 0x10000

.field public static final whitelist FLAG_ON_DELETE_MINI_ZOOM_BUTTON_SELECTED:I = 0x8000

.field public static final whitelist FLAG_ON_DELETE_MINI_ZOOM_CONTROL_VIEW:I = 0x4000

.field public static final whitelist FLAG_ON_DELETE_ZOOM_BUTTON_RESTORE:I = 0x800

.field public static final whitelist FLAG_ON_DELETE_ZOOM_BUTTON_SELECTED:I = 0x100

.field public static final whitelist FLAG_ON_DISABLE_CONTROL_VIEW:I = 0x40

.field public static final blacklist FLAG_ON_DOUBLE_TAP_TO_CLOSED_ZOOM:I = 0x800

.field public static final blacklist FLAG_ON_DRAG_TO_SCALE_LEFT_BOTTOM:I = 0x20

.field public static final blacklist FLAG_ON_DRAG_TO_SCALE_LEFT_SIDE:I = 0x80

.field public static final blacklist FLAG_ON_DRAG_TO_SCALE_RIGHT_BOTTOM:I = 0x40

.field public static final blacklist FLAG_ON_DRAG_TO_SCALE_RIGHT_SIDE:I = 0x100

.field public static final blacklist FLAG_ON_DRAG_TO_SCALE_UP:I = 0x200

.field public static final whitelist FLAG_ON_FLING:I = 0x2

.field public static final blacklist FLAG_ON_FULL_SCREEN:I = 0x400

.field public static final whitelist FLAG_ON_FULL_SCREEN_BUTTON_RESTORE:I = 0x400

.field public static final whitelist FLAG_ON_FULL_SCREEN_BUTTON_SELECTED:I = 0x80

.field public static final whitelist FLAG_ON_HIDE_HANDLE:I = 0x10

.field public static final whitelist FLAG_ON_HIDE_TIPS_VIEW:I = 0x100000

.field public static final whitelist FLAG_ON_LONG_PRESS:I = 0x1

.field public static final whitelist FLAG_ON_MINI_ZOOM_BUTTON_RESTORE:I = 0x1000

.field public static final whitelist FLAG_ON_MINI_ZOOM_BUTTON_SELECTED:I = 0x200

.field public static final whitelist FLAG_ON_MINI_ZOOM_SHOW_TIPS_VIEW:I = 0x40000

.field public static final whitelist FLAG_ON_SHOW_CONTROL_VIEW:I = 0x1

.field public static final whitelist FLAG_ON_SHOW_GUIDE:I = 0x200000

.field public static final whitelist FLAG_ON_SHOW_HANDLE:I = 0x4

.field public static final whitelist FLAG_ON_SHOW_MINI_ZOOM_CONTROL_VIEW:I = 0x2000

.field public static final whitelist FLAG_ON_SINGLE_TAP_TO_CLOSED_ZOOM:I = 0x10

.field public static final whitelist FLAG_ON_SINGLE_TAP_TO_SHOW_TIP:I = 0x8

.field public static final whitelist FLAG_ON_SING_TAP_MINI_ZOOM:I = 0x80000

.field public static final whitelist FLAG_ON_SING_TAP_SHOW_TIPS_VIEW:I = 0x20000

.field public static final whitelist FLAG_ON_START_BY_LAUNCHER_GESTURE_FROM_FULL_SCREEN:I = 0x1

.field public static final whitelist FLAG_ON_START_BY_LAUNCHER_SWIPE_UP_FROM_ZOOM:I = 0x3

.field public static final whitelist FLAG_ON_START_BY_MINI_ZOOM_BUTTON_FROM_ZOOM:I = 0x2

.field public static final whitelist FLAG_ON_START_DEFAULT_ZOOM_AT_LEFT_SIDE:I = 0xd

.field public static final whitelist FLAG_ON_START_DEFAULT_ZOOM_AT_RIGHT_SIDE:I = 0xe

.field public static final whitelist FLAG_ON_START_DEFAULT_ZOOM_FROM_APP:I = 0x12

.field public static final blacklist FLAG_ON_START_FLOATWINDOW_FROM_GAMES_CENTER:I = 0x16

.field public static final blacklist FLAG_ON_START_FLOATWINDOW_FROM_GAME_REDIRECT:I = 0x18

.field public static final blacklist FLAG_ON_START_FLOATWINDOW_FROM_MINI_WINDOW:I = 0x19

.field public static final blacklist FLAG_ON_START_FLOATWINDOW_FROM_SHARE:I = 0x17

.field public static final whitelist FLAG_ON_START_FULL_SCREEN_FROM_RECENTS:I = 0x3

.field public static final whitelist FLAG_ON_START_MINI_BY_CHANGE_SCALE:I = 0x5

.field public static final whitelist FLAG_ON_START_MINI_BY_FLOAT_HANDLE:I = 0x6

.field public static final whitelist FLAG_ON_START_MINI_BY_THIRD_PARTY_APP:I = 0x7

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_BY_LAUNCHER_CARD:I = 0x4

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_CHANGE:I = 0x13

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_FULL_SCREEN:I = 0x1

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_RECENTS:I = 0x2

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_RECENTS_GESTURE:I = 0x9

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_THIRD_PARTY_APP:I = 0x7

.field public static final whitelist FLAG_ON_START_MINI_ZOOM_FROM_ZOOM:I = 0x2

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_FLOAT_HANDLE:I = 0x4

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_HANDWRITING_PEN_GESTURE:I = 0xb

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_NOTIFICATION:I = 0x5

.field public static final blacklist FLAG_ON_START_ZOOM_FROM_NOTIFICATION_CENTER:I = 0x14

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_NOTIFICATION_NEW_TASK:I = 0x6

.field public static final blacklist FLAG_ON_START_ZOOM_FROM_NOTIFICATION_REPLY:I = 0x15

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_PINCH_GESTURE:I = 0xa

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_POCKET_STUDIO:I = 0xc

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_RECENTS:I = 0x1

.field public static final whitelist FLAG_ON_START_ZOOM_FROM_SPLIT_DRAG:I = 0x11

.field public static final whitelist FLAG_ON_START_ZOOM_TO_FULL:I = 0x8

.field public static final whitelist FLAG_ON_UP:I = 0x4

.field public static final whitelist FLAG_SHOW_ZOOM_WINDOW:I = 0x1

.field public static final whitelist FLAG_START_ZOOM_AT_GAME_ENTER_BACKGROUND:I = 0x10

.field public static final whitelist FLAG_TOUCH_OUTSIDE_CONTROL_VIEW:I = 0x400000

.field public static final whitelist FLAG_UNSUPPORT_ZOOM:I = 0x4

.field public static final whitelist FLAG_ZOOM_TO_FULL_BY_RECENT_SLIDING:I = 0xf

.field public static final whitelist FLOAT_HANDLE_ON_LEFT:I = 0x0

.field public static final whitelist FLOAT_HANDLE_ON_RIGHT:I = 0x1

.field public static final blacklist FOLDSCREEN_LARGE_ZOOM_RATIO:F = 1.7777778f

.field public static final blacklist FOLDSCREEN_LARGE_ZOOM_SCALE_FOR_LANDSCAPE_APP_DEFAULT:F = 0.7f

.field public static final blacklist FOLDSCREEN_LARGE_ZOOM_SCALE_FOR_PORTRAIT_DEFAULT:F = 0.7f

.field public static final blacklist FOLDSCREEN_SMALL_MINI_ZOOM_SCALE_FOR_DEFAULT:F = 0.3f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_LANDSCAPE_RATIO:F = 1.4444444f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_PORTRAIT_RATIO:F = 1.6666666f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_SCALE_FOR_LANDSCAPE_APP_DEFAULT:F = 0.667f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_SCALE_FOR_LANDSCAPE_DEFAULT:F = 0.6f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_SCALE_FOR_PORTRAIT_DEFAULT:F = 0.667f

.field public static final blacklist FOLDSCREEN_SMALL_ZOOM_SCALE_FOR_PORTRAIT_LANDSCAPE_APP_DEFAULT:F = 0.52f

.field public static final blacklist FOLDSCREEN_ZOOM_BOTTOM_LIMIT_EDGE:I = 0x90

.field public static final blacklist FOLDSCREEN_ZOOM_LEFT_LIMIT_EDGE:I = 0x28

.field public static final blacklist FOLDSCREEN_ZOOM_RIGHT_LIMIT_EDGE:I = 0x10

.field public static final blacklist FOLDSCREEN_ZOOM_SCALE_FOR_POCKET_STUDIO_DEFAULT:F = 0.85f

.field public static final blacklist FOLDSCREEN_ZOOM_TOP_LIMIT_EDGE:I = 0x28

.field public static final blacklist FOLD_TOP_BOTTOM_LIMIT_EDGE_OF_MOVE_MINI_ZOOM_LANDSCAPE:I = 0x28

.field public static final whitelist KEY_OF_DELETE_MINI_ZOOM_BUTTON:Ljava/lang/String; = "delete_mini_zoom_button"

.field public static final whitelist KEY_OF_DELETE_ZOOM_BUTTON:Ljava/lang/String; = "delete_zoom_button"

.field public static final whitelist KEY_OF_FLOAT_HANDLE_INFO:Ljava/lang/String; = "float_handle_info"

.field public static final whitelist KEY_OF_FULL_SCREEN_BUTTON:Ljava/lang/String; = "full_screen_button"

.field public static final whitelist KEY_OF_LAUNCH_FROM_POCKET_STUDIO:Ljava/lang/String; = "launch_from_pocket_studio_zoom"

.field public static final whitelist KEY_OF_MINI_ZOOM_BUTTON:Ljava/lang/String; = "mini_zoom_button"

.field public static final whitelist KEY_OF_START_ZOOM_AT_OTHER_SIDE:Ljava/lang/String; = "start_zoom_at_other_side"

.field public static final whitelist KEY_ZOOM_TASK_ID_FROM_RECENTS:Ljava/lang/String; = "zoom_task_id"

.field public static final whitelist KEY_ZOOM_TYPE_FROM_RECENTS:Ljava/lang/String; = "android:activity.mZoomLaunchFlags"

.field public static final blacklist LEFT_RIGHT_LIMIT_EDGE_OF_MOVE_MINI_ZOOM:I = 0x10

.field public static final blacklist MINI_ZOOM_SCALE_FOR_LANDSCAPE_DEFAULT:F = 0.3f

.field public static final blacklist MINI_ZOOM_SCALE_FOR_PORTRAIT_DEFAULT:F = 0.3f

.field public static final whitelist MINI_ZOOM_TYPE:I = 0x2

.field public static final blacklist PAD_LEFT_RIGHT_LIMIT_EDGE_OF_MOVE_MINI_ZOOM:I = 0x18

.field public static final blacklist PAD_MINI_ZOOM_SCALE_FOR_DEFAULT:F = 0.45f

.field public static final blacklist PAD_TOP_BOTTOM_LIMIT_EDGE_OF_MOVE_MINI_ZOOM_LANDSCAPE:I = 0x30

.field public static final blacklist PAD_TOP_BOTTOM_LIMIT_EDGE_OF_MOVE_MINI_ZOOM_PORTRAIT:I = 0x30

.field public static final blacklist PAD_ZOOM_RATIO:F = 1.7777778f

.field public static final blacklist PAD_ZOOM_SCALE_FOR_DEFAULT:F = 0.85f

.field public static final blacklist STAGE_APP_REQUEST_FINISH:I = 0x4

.field public static final blacklist STAGE_INIT:I = 0x0

.field public static final blacklist STAGE_RESULT:I = 0x6

.field public static final blacklist STAGE_SET_NEW_TASK:I = 0x2

.field public static final whitelist STATE_CHANGE_TO_BACK_BY_PACKAGE:I = 0x4

.field public static final whitelist STATE_CHANGE_TO_FULL:I = 0x3

.field public static final whitelist STATE_CHANGE_TO_MINI:I = 0x1

.field public static final whitelist STATE_CHANG_TO_ZOOM:I = 0x2

.field private static final blacklist TAG:Ljava/lang/String; = "OplusZoomWindowManager"

.field public static final blacklist TOP_BOTTOM_LIMIT_EDGE_OF_MOVE_MINI_ZOOM_LANDSCAPE:I = 0x10

.field public static final blacklist TOP_BOTTOM_LIMIT_EDGE_OF_MOVE_MINI_ZOOM_PORTRAIT:I = 0x28

.field public static final whitelist TOP_ZOOM_CLOSE:I = 0x1

.field public static final whitelist TOP_ZOOM_TO_FULL:I = 0x0

.field public static final whitelist TYPE_FORCED_RELAUNCH_ZOOM_CPN_LIST:I = 0x9

.field public static final whitelist TYPE_FORCES_SHOW_TOAST_LIST:I = 0x4

.field public static final whitelist TYPE_NOT_SHOW_TOAST_LIST:I = 0x5

.field public static final whitelist TYPE_SHOW_COMPATIBILITY_TOAST:I = 0x1

.field public static final whitelist TYPE_SHOW_UNSUPPORT_TOAST:I = 0x2

.field public static final whitelist TYPE_UNRELAUNCH_ZOOM_CPN_LIST:I = 0x8

.field public static final whitelist TYPE_UNREUSED_ZOOM_CPN_LIST:I = 0x7

.field public static final whitelist TYPE_UNSUPPORT_ZOOM_CPN_LIST:I = 0x6

.field public static final whitelist TYPE_ZOOM_APP_BLACK_LIST:I = 0x2

.field public static final whitelist TYPE_ZOOM_APP_REPLY_LIST:I = 0x3

.field public static final whitelist TYPE_ZOOM_APP_SUPPORT_LIST:I = 0x1

.field public static final whitelist WINDOWING_MODE_FULLSCREEN:I = 0x1

.field public static final whitelist WINDOWING_MODE_ZOOM:I = 0x64

.field public static final blacklist WINDOWING_MODE_ZOOM_LEGACY:I = 0x6

.field public static final whitelist WINDOWING_MODE_ZOOM_TO_FULLSCREEN:I = 0x65

.field public static final whitelist WINDOW_TYPE_MINIZOOM:I = 0x2

.field public static final whitelist WINDOW_TYPE_UNDEFINE:I = 0x0

.field public static final whitelist WINDOW_TYPE_ZOOM:I = 0x1

.field public static final blacklist ZOOM_CORNER_RADIUS_PORTRAIT:I = 0x16

.field public static final blacklist ZOOM_LANDSCAPE_APP_RATIO:F = 1.6666666f

.field public static final blacklist ZOOM_LANDSCAPE_RATIO:F = 1.45f

.field public static final blacklist ZOOM_PORTRAIT_APP_FOLDSCREEN:F = 0.6f

.field public static final blacklist ZOOM_RATIO:F = 1.6666666f

.field public static final blacklist ZOOM_SCALE_FOR_LANDSCAPE_APP_DEFAULT:F = 0.556f

.field public static final blacklist ZOOM_SCALE_FOR_LANDSCAPE_DEFAULT:F = 0.6f

.field public static final blacklist ZOOM_SCALE_FOR_PORTRAIT_DEFAULT:F = 0.667f

.field public static final whitelist ZOOM_TYPE:I = 0x1

.field private static volatile blacklist sInstance:Lcom/oplus/zoomwindow/OplusZoomWindowManager;


# instance fields
.field private final blacklist mConfigListeners:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;",
            "Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;",
            ">;"
        }
    .end annotation
.end field

.field private blacklist mOAms:Landroid/app/OplusActivityManager;


# direct methods
.method private constructor blacklist <init>()V
    .registers 2

    .line 791
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 773
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iput-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    .line 792
    new-instance v0, Landroid/app/OplusActivityManager;

    invoke-direct {v0}, Landroid/app/OplusActivityManager;-><init>()V

    iput-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    .line 793
    return-void
.end method

.method public static whitelist getInstance()Lcom/oplus/zoomwindow/OplusZoomWindowManager;
    .registers 2

    .line 781
    sget-object v0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->sInstance:Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    if-nez v0, :cond_17

    .line 782
    const-class v0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    monitor-enter v0

    .line 783
    :try_start_7
    sget-object v1, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->sInstance:Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    if-nez v1, :cond_12

    .line 784
    new-instance v1, Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    invoke-direct {v1}, Lcom/oplus/zoomwindow/OplusZoomWindowManager;-><init>()V

    sput-object v1, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->sInstance:Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    .line 786
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 788
    :cond_17
    :goto_17
    sget-object v0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->sInstance:Lcom/oplus/zoomwindow/OplusZoomWindowManager;

    return-object v0
.end method


# virtual methods
.method public whitelist addOnConfigChangedListener(Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;)Z
    .registers 8
    .param p1, "listener"    # Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;

    .line 1049
    const-string v0, "OplusZoomWindowManager"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "addOnConfigChangedListener listener = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1050
    const/4 v0, 0x0

    if-nez p1, :cond_1c

    .line 1051
    return v0

    .line 1053
    :cond_1c
    iget-object v1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    monitor-enter v1

    .line 1054
    :try_start_1f
    iget-object v2, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_30

    .line 1055
    const-string v2, "OplusZoomWindowManager"

    const-string v3, "addOnConfigChangedListener already added before"

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1056
    monitor-exit v1

    return v0

    .line 1058
    :cond_30
    new-instance v2, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;

    .line 1059
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, p0, p1, v3}, Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;-><init>(Lcom/oplus/zoomwindow/OplusZoomWindowManager;Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;Landroid/os/Looper;)V
    :try_end_39
    .catchall {:try_start_1f .. :try_end_39} :catchall_58

    .line 1061
    .local v2, "delegate":Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;
    :try_start_39
    iget-object v3, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    if-eqz v3, :cond_4a

    .line 1062
    iget-object v3, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    invoke-interface {v3, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1063
    iget-object v3, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v3, v2}, Landroid/app/OplusActivityManager;->addZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v0
    :try_end_48
    .catch Landroid/os/RemoteException; {:try_start_39 .. :try_end_48} :catch_4b
    .catchall {:try_start_39 .. :try_end_48} :catchall_58

    :try_start_48
    monitor-exit v1

    return v0

    .line 1068
    :cond_4a
    goto :goto_56

    .line 1065
    :catch_4b
    move-exception v3

    .line 1066
    .local v3, "e":Landroid/os/RemoteException;
    const-string v4, "OplusZoomWindowManager"

    const-string v5, "addOnConfigChangedListener remoteException "

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1067
    invoke-virtual {v3}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1069
    .end local v2    # "delegate":Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangeListenerDelegate;
    .end local v3    # "e":Landroid/os/RemoteException;
    :goto_56
    monitor-exit v1

    .line 1070
    return v0

    .line 1069
    :catchall_58
    move-exception v0

    monitor-exit v1
    :try_end_5a
    .catchall {:try_start_48 .. :try_end_5a} :catchall_58

    throw v0
.end method

.method public blacklist adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    .registers 8
    .param p1, "attrs"    # Landroid/view/WindowManager$LayoutParams;
    .param p2, "windowingMode"    # I
    .param p3, "outDisplayFrame"    # Landroid/graphics/Rect;
    .param p4, "outParentFrame"    # Landroid/graphics/Rect;

    .line 1212
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityManager;->adjustWindowFrameForZoom(Landroid/view/WindowManager$LayoutParams;ILandroid/graphics/Rect;Landroid/graphics/Rect;)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 1215
    goto :goto_e

    .line 1213
    :catch_6
    move-exception v0

    .line 1214
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "adjustWindowFrameForZoom remoteException"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1216
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_e
    return-void
.end method

.method public whitelist getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;
    .registers 4

    .line 942
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityManager;->getCurrentZoomWindowState()Lcom/oplus/zoomwindow/OplusZoomWindowInfo;

    move-result-object v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_6} :catch_7

    return-object v0

    .line 943
    :catch_7
    move-exception v0

    .line 944
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "getCurrentZoomWindowState Exception "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 946
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method

.method public whitelist getZoomAppConfigList(I)Ljava/util/List;
    .registers 5
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 976
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->getZoomAppConfigList(I)Ljava/util/List;

    move-result-object v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return-object v0

    .line 977
    :catch_7
    move-exception v0

    .line 978
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "hideZoomWindow remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 979
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 981
    .end local v0    # "e":Landroid/os/RemoteException;
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    return-object v0
.end method

.method public whitelist getZoomBounds(ZI)Landroid/graphics/Rect;
    .registers 6
    .param p1, "landApp"    # Z
    .param p2, "type"    # I

    .line 1284
    const/4 v0, 0x1

    if-eq p2, v0, :cond_c

    const/4 v0, 0x2

    if-eq p2, v0, :cond_c

    .line 1285
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    return-object v0

    .line 1288
    :cond_c
    :try_start_c
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityManager;->getZoomBounds(ZI)Landroid/graphics/Rect;

    move-result-object v0
    :try_end_12
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_12} :catch_13

    return-object v0

    .line 1289
    :catch_13
    move-exception v0

    .line 1290
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "getDefaultZoomScale remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1292
    .end local v0    # "e":Landroid/os/RemoteException;
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    return-object v0
.end method

.method public whitelist getZoomBoundsByTaskId(II)Landroid/graphics/Rect;
    .registers 6
    .param p1, "taskId"    # I
    .param p2, "type"    # I

    .line 1305
    const/4 v0, 0x1

    if-eq p2, v0, :cond_c

    const/4 v0, 0x2

    if-eq p2, v0, :cond_c

    .line 1306
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    return-object v0

    .line 1309
    :cond_c
    :try_start_c
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityManager;->getZoomBoundsByTaskId(II)Landroid/graphics/Rect;

    move-result-object v0
    :try_end_12
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_12} :catch_13

    return-object v0

    .line 1310
    :catch_13
    move-exception v0

    .line 1311
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "getDefaultZoomScale remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1313
    .end local v0    # "e":Landroid/os/RemoteException;
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    return-object v0
.end method

.method public whitelist getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;
    .registers 4

    .line 1003
    const-string v0, "getZoomWindowConfig start"

    const-string v1, "OplusZoomWindowManager"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1006
    :try_start_7
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityManager;->getZoomWindowConfig()Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    move-result-object v0
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_d} :catch_e

    return-object v0

    .line 1007
    :catch_e
    move-exception v0

    .line 1008
    .local v0, "e":Landroid/os/RemoteException;
    const-string v2, "getZoomWindowConfig remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1009
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1011
    .end local v0    # "e":Landroid/os/RemoteException;
    new-instance v0, Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    invoke-direct {v0}, Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;-><init>()V

    return-object v0
.end method

.method public whitelist handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z
    .registers 12
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;
    .param p5, "type"    # I

    .line 916
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_2} :catch_f

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    .end local p1    # "target":Ljava/lang/String;
    .end local p2    # "userId":I
    .end local p3    # "callPkg":Ljava/lang/String;
    .end local p4    # "extension":Landroid/os/Bundle;
    .end local p5    # "type":I
    .local v1, "target":Ljava/lang/String;
    .local v2, "userId":I
    .local v3, "callPkg":Ljava/lang/String;
    .local v4, "extension":Landroid/os/Bundle;
    .local v5, "type":I
    :try_start_7
    invoke-virtual/range {v0 .. v5}, Landroid/app/OplusActivityManager;->handleShowCompatibilityToast(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;I)Z

    move-result p1
    :try_end_b
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_b} :catch_c

    return p1

    .line 917
    :catch_c
    move-exception v0

    move-object p1, v0

    goto :goto_16

    .end local v1    # "target":Ljava/lang/String;
    .end local v2    # "userId":I
    .end local v3    # "callPkg":Ljava/lang/String;
    .end local v4    # "extension":Landroid/os/Bundle;
    .end local v5    # "type":I
    .restart local p1    # "target":Ljava/lang/String;
    .restart local p2    # "userId":I
    .restart local p3    # "callPkg":Ljava/lang/String;
    .restart local p4    # "extension":Landroid/os/Bundle;
    .restart local p5    # "type":I
    :catch_f
    move-exception v0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    move-object p1, v0

    .line 918
    .end local p2    # "userId":I
    .end local p3    # "callPkg":Ljava/lang/String;
    .end local p4    # "extension":Landroid/os/Bundle;
    .end local p5    # "type":I
    .restart local v1    # "target":Ljava/lang/String;
    .restart local v2    # "userId":I
    .restart local v3    # "callPkg":Ljava/lang/String;
    .restart local v4    # "extension":Landroid/os/Bundle;
    .restart local v5    # "type":I
    .local p1, "e":Landroid/os/RemoteException;
    :goto_16
    const-string p2, "OplusZoomWindowManager"

    const-string p3, "handleShowCompatibilityToast remoteException "

    invoke-static {p2, p3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 919
    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    .line 921
    .end local p1    # "e":Landroid/os/RemoteException;
    const/4 p1, 0x0

    return p1
.end method

.method public whitelist hideZoomWindow(I)V
    .registers 5
    .param p1, "flag"    # I

    .line 951
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->hideZoomWindow(I)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 955
    goto :goto_11

    .line 952
    :catch_6
    move-exception v0

    .line 953
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "hideZoomWindow remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 954
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 956
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_11
    return-void
.end method

.method public whitelist isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z
    .registers 8
    .param p1, "target"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "callPkg"    # Ljava/lang/String;
    .param p4, "extension"    # Landroid/os/Bundle;

    .line 896
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/app/OplusActivityManager;->isSupportZoomMode(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 897
    :catch_7
    move-exception v0

    .line 898
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "isSupportZoomMode remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 899
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 901
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist isSupportZoomWindowMode()Z
    .registers 4

    .line 878
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityManager;->isSupportZoomWindowMode()Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 879
    :catch_7
    move-exception v0

    .line 880
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "isSupportZoomWindowMode remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 881
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 883
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x1

    return v0
.end method

.method public whitelist isZoomSimpleModeEnable()Z
    .registers 4

    .line 1197
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0}, Landroid/app/OplusActivityManager;->isZoomSimpleModeEnable()Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 1198
    :catch_7
    move-exception v0

    .line 1199
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "isZoomSimpleModeEnable remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1200
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1202
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "componentName"    # Landroid/content/ComponentName;

    .line 1224
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityManager;->isZoomSupportMultiWindow(Ljava/lang/String;Landroid/content/ComponentName;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 1225
    :catch_7
    move-exception v0

    .line 1226
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "isZoomSupportMultiWindow remoteException"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1228
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist notifyZoomStateChange(Ljava/lang/String;I)V
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "action"    # I

    .line 1241
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1, p2}, Landroid/app/OplusActivityManager;->notifyZoomStateChange(Ljava/lang/String;I)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 1244
    goto :goto_e

    .line 1242
    :catch_6
    move-exception v0

    .line 1243
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "notifyZoomStateChange remoteException"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1245
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_e
    return-void
.end method

.method public whitelist onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V
    .registers 5
    .param p1, "cvInfo"    # Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;

    .line 1165
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->onControlViewChanged(Lcom/oplus/zoomwindow/OplusZoomControlViewInfo;)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 1169
    goto :goto_11

    .line 1166
    :catch_6
    move-exception v0

    .line 1167
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "onControlViewChanged remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1168
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1170
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_11
    return-void
.end method

.method public whitelist onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V
    .registers 5
    .param p1, "floatHandleInfo"    # Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;

    .line 1184
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->onFloatHandleViewChanged(Lcom/oplus/zoomwindow/OplusZoomFloatHandleViewInfo;)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 1188
    goto :goto_11

    .line 1185
    :catch_6
    move-exception v0

    .line 1186
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "onFloatHandleViewChanged remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1187
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1189
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_11
    return-void
.end method

.method public whitelist onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V
    .registers 5
    .param p1, "inputEventInfo"    # Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;

    .line 1151
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->onInputEvent(Lcom/oplus/zoomwindow/OplusZoomInputEventInfo;)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 1155
    goto :goto_11

    .line 1152
    :catch_6
    move-exception v0

    .line 1153
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "onInputEvent remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1154
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1156
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_11
    return-void
.end method

.method public whitelist registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;

    .line 850
    const-string v0, "registerZoomAppObserver start"

    const-string v1, "OplusZoomWindowManager"

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 852
    :try_start_7
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->registerZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_d} :catch_e

    return v0

    .line 853
    :catch_e
    move-exception v0

    .line 854
    .local v0, "e":Landroid/os/RemoteException;
    const-string v2, "registerZoomAppObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 855
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 857
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;

    .line 1254
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->registerZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 1255
    :catch_7
    move-exception v0

    .line 1256
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "registerZoomWindowObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1258
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;

    .line 831
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->registerZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 832
    :catch_7
    move-exception v0

    .line 833
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "registerZoomWindowObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 834
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 836
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist removeOnConfigChangedListener(Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;)Z
    .registers 7
    .param p1, "listener"    # Lcom/oplus/zoomwindow/OplusZoomWindowManager$OnConfigChangedListener;

    .line 1079
    const-string v0, "OplusZoomWindowManager"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "removeOnConfigChangedListener listener = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1080
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    monitor-enter v0

    .line 1081
    :try_start_1b
    iget-object v1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    :try_end_23
    .catchall {:try_start_1b .. :try_end_23} :catchall_45

    .line 1082
    .local v1, "delegate":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    if-eqz v1, :cond_42

    .line 1084
    :try_start_25
    iget-object v2, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    if-eqz v2, :cond_36

    .line 1085
    iget-object v2, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mConfigListeners:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1086
    iget-object v2, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v2, v1}, Landroid/app/OplusActivityManager;->removeZoomWindowConfigChangedListener(Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;)Z

    move-result v2
    :try_end_34
    .catch Landroid/os/RemoteException; {:try_start_25 .. :try_end_34} :catch_37
    .catchall {:try_start_25 .. :try_end_34} :catchall_45

    :try_start_34
    monitor-exit v0

    return v2

    .line 1091
    :cond_36
    goto :goto_42

    .line 1088
    :catch_37
    move-exception v2

    .line 1089
    .local v2, "e":Landroid/os/RemoteException;
    const-string v3, "OplusZoomWindowManager"

    const-string v4, "removeOnConfigChangedListener remoteException "

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1090
    invoke-virtual {v2}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1093
    .end local v1    # "delegate":Lcom/oplus/app/IOplusZoomWindowConfigChangedListener;
    .end local v2    # "e":Landroid/os/RemoteException;
    :cond_42
    :goto_42
    monitor-exit v0

    .line 1094
    const/4 v0, 0x0

    return v0

    .line 1093
    :catchall_45
    move-exception v1

    monitor-exit v0
    :try_end_47
    .catchall {:try_start_34 .. :try_end_47} :catchall_45

    throw v1
.end method

.method public whitelist setBubbleMode(Z)V
    .registers 2
    .param p1, "inBubbleMode"    # Z

    .line 1175
    return-void
.end method

.method public whitelist setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V
    .registers 5
    .param p1, "config"    # Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;

    .line 1030
    const-string v0, "setZoomWindowConfig start"

    const-string v1, "OplusZoomWindowManager"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1033
    :try_start_7
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->setZoomWindowConfig(Lcom/oplus/zoomwindow/OplusZoomWindowRUSConfig;)V
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_c} :catch_d

    .line 1037
    goto :goto_16

    .line 1034
    :catch_d
    move-exception v0

    .line 1035
    .local v0, "e":Landroid/os/RemoteException;
    const-string v2, "setZoomWindowConfig remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1036
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 1038
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_16
    return-void
.end method

.method public whitelist startMiniZoomFromZoom(I)V
    .registers 5
    .param p1, "startWay"    # I

    .line 930
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->startMiniZoomFromZoom(I)V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_5} :catch_6

    .line 934
    goto :goto_11

    .line 931
    :catch_6
    move-exception v0

    .line 932
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "startMiniZoomFromZoom remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 933
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 935
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_11
    return-void
.end method

.method public whitelist startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 8
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;

    .line 800
    const-string v0, "OplusZoomWindowManager"

    :try_start_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "startZoomWindow: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " callPkg: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 801
    iget-object v1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v1, p1, p2, p3, p4}, Landroid/app/OplusActivityManager;->startZoomWindow(Landroid/content/Intent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0
    :try_end_28
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_28} :catch_29

    return v0

    .line 802
    :catch_29
    move-exception v1

    .line 803
    .local v1, "e":Landroid/os/RemoteException;
    const-string v2, "startZoomWindow remoteException "

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 804
    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    .line 806
    .end local v1    # "e":Landroid/os/RemoteException;
    const/4 v0, -0x1

    return v0
.end method

.method public whitelist startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I
    .registers 8
    .param p1, "pendingIntent"    # Landroid/app/PendingIntent;
    .param p2, "bOptions"    # Landroid/os/Bundle;
    .param p3, "userId"    # I
    .param p4, "callPkg"    # Ljava/lang/String;

    .line 821
    const-string v0, "OplusZoomWindowManager"

    :try_start_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "startZoomWindowByPendingIntent: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " callPkg: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 822
    iget-object v1, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v1, p1, p2, p3, p4}, Landroid/app/OplusActivityManager;->startZoomWindowByPendingIntent(Landroid/app/PendingIntent;Landroid/os/Bundle;ILjava/lang/String;)I

    move-result v0
    :try_end_28
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_28} :catch_29

    return v0

    .line 823
    :catch_29
    move-exception v1

    .line 824
    .local v1, "e":Landroid/os/RemoteException;
    const-string v2, "startZoomWindow remoteException "

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 826
    .end local v1    # "e":Landroid/os/RemoteException;
    const/4 v0, -0x1

    return v0
.end method

.method public whitelist unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomAppObserver;

    .line 861
    const-string v0, "unregisterZoomAppObserver start"

    const-string v1, "OplusZoomWindowManager"

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 863
    :try_start_7
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->unregisterZoomAppObserver(Lcom/oplus/zoomwindow/IOplusZoomAppObserver;)Z

    move-result v0
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_d} :catch_e

    return v0

    .line 864
    :catch_e
    move-exception v0

    .line 865
    .local v0, "e":Landroid/os/RemoteException;
    const-string v2, "unregisterZoomAppObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 866
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 868
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public blacklist unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z
    .registers 5
    .param p1, "listener"    # Lcom/oplus/zoomwindow/IOplusZoomStateListener;

    .line 1266
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->unregisterZoomStateListener(Lcom/oplus/zoomwindow/IOplusZoomStateListener;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 1267
    :catch_7
    move-exception v0

    .line 1268
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "registerZoomWindowObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1270
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method

.method public whitelist unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;

    .line 841
    :try_start_0
    iget-object v0, p0, Lcom/oplus/zoomwindow/OplusZoomWindowManager;->mOAms:Landroid/app/OplusActivityManager;

    invoke-virtual {v0, p1}, Landroid/app/OplusActivityManager;->unregisterZoomWindowObserver(Lcom/oplus/zoomwindow/IOplusZoomWindowObserver;)Z

    move-result v0
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_7

    return v0

    .line 842
    :catch_7
    move-exception v0

    .line 843
    .local v0, "e":Landroid/os/RemoteException;
    const-string v1, "OplusZoomWindowManager"

    const-string v2, "unregisterZoomWindowObserver remoteException "

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 844
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 846
    .end local v0    # "e":Landroid/os/RemoteException;
    const/4 v0, 0x0

    return v0
.end method
