.class public Lcom/oplus/wrapper/view/InputMonitor;
.super Ljava/lang/Object;
.source "InputMonitor.java"


# instance fields
.field private final blacklist mInputMonitor:Landroid/view/InputMonitor;


# direct methods
.method public constructor blacklist <init>(Landroid/view/InputMonitor;)V
    .registers 2
    .param p1, "inputMonitor"    # Landroid/view/InputMonitor;

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    iput-object p1, p0, Lcom/oplus/wrapper/view/InputMonitor;->mInputMonitor:Landroid/view/InputMonitor;

    .line 29
    return-void
.end method


# virtual methods
.method public whitelist dispose()V
    .registers 2

    .line 42
    iget-object v0, p0, Lcom/oplus/wrapper/view/InputMonitor;->mInputMonitor:Landroid/view/InputMonitor;

    invoke-virtual {v0}, Landroid/view/InputMonitor;->dispose()V

    .line 43
    return-void
.end method

.method public whitelist getInputChannel()Lcom/oplus/wrapper/view/InputChannel;
    .registers 3

    .line 51
    new-instance v0, Lcom/oplus/wrapper/view/InputChannel;

    iget-object v1, p0, Lcom/oplus/wrapper/view/InputMonitor;->mInputMonitor:Landroid/view/InputMonitor;

    invoke-virtual {v1}, Landroid/view/InputMonitor;->getInputChannel()Landroid/view/InputChannel;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/oplus/wrapper/view/InputChannel;-><init>(Landroid/view/InputChannel;)V

    return-object v0
.end method
