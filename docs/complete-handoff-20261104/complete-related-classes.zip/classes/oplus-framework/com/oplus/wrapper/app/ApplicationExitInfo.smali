.class public Lcom/oplus/wrapper/app/ApplicationExitInfo;
.super Ljava/lang/Object;
.source "ApplicationExitInfo.java"


# static fields
.field public static final whitelist SUBREASON_EXCESSIVE_CPU:I


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 1

    .line 29
    invoke-static {}, Lcom/oplus/wrapper/app/ApplicationExitInfo;->getSubreasonExcessiveCpu()I

    move-result v0

    sput v0, Lcom/oplus/wrapper/app/ApplicationExitInfo;->SUBREASON_EXCESSIVE_CPU:I

    return-void
.end method

.method private constructor blacklist <init>()V
    .registers 1

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    return-void
.end method

.method private static blacklist getSubreasonExcessiveCpu()I
    .registers 1

    .line 36
    const/4 v0, 0x7

    return v0
.end method
