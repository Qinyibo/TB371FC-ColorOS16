.class public Lcom/oplus/wrapper/app/KeyguardManager;
.super Ljava/lang/Object;
.source "KeyguardManager.java"


# static fields
.field public static final whitelist ACTION_CONFIRM_DEVICE_CREDENTIAL:Ljava/lang/String;


# instance fields
.field private final blacklist mKeyguardManager:Landroid/app/KeyguardManager;


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 1

    .line 31
    invoke-static {}, Lcom/oplus/wrapper/app/KeyguardManager;->getActionConfirmDeviceCredential()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/oplus/wrapper/app/KeyguardManager;->ACTION_CONFIRM_DEVICE_CREDENTIAL:Ljava/lang/String;

    return-void
.end method

.method public constructor whitelist <init>(Landroid/app/KeyguardManager;)V
    .registers 2
    .param p1, "keyguardManager"    # Landroid/app/KeyguardManager;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    iput-object p1, p0, Lcom/oplus/wrapper/app/KeyguardManager;->mKeyguardManager:Landroid/app/KeyguardManager;

    .line 46
    return-void
.end method

.method private static blacklist getActionConfirmDeviceCredential()Ljava/lang/String;
    .registers 1

    .line 49
    const-string v0, "android.app.action.CONFIRM_DEVICE_CREDENTIAL"

    return-object v0
.end method

.method public static whitelist isDeviceLocked(Landroid/app/KeyguardManager;I)Z
    .registers 3
    .param p0, "target"    # Landroid/app/KeyguardManager;
    .param p1, "userId"    # I

    .line 64
    invoke-virtual {p0, p1}, Landroid/app/KeyguardManager;->isDeviceLocked(I)Z

    move-result v0

    return v0
.end method


# virtual methods
.method public whitelist isDeviceLocked(I)Z
    .registers 3
    .param p1, "userId"    # I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 81
    iget-object v0, p0, Lcom/oplus/wrapper/app/KeyguardManager;->mKeyguardManager:Landroid/app/KeyguardManager;

    invoke-virtual {v0, p1}, Landroid/app/KeyguardManager;->isDeviceLocked(I)Z

    move-result v0

    return v0
.end method
