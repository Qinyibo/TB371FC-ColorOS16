.class public interface abstract Lcom/oplus/wrapper/app/IApplicationThread;
.super Ljava/lang/Object;
.source "IApplicationThread.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/wrapper/app/IApplicationThread$Stub;
    }
.end annotation
