.class public abstract Lcom/oplus/wrapper/app/IApplicationThread$Stub;
.super Ljava/lang/Object;
.source "IApplicationThread.java"

# interfaces
.implements Landroid/os/IInterface;
.implements Lcom/oplus/wrapper/app/IApplicationThread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/wrapper/app/IApplicationThread;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/wrapper/app/IApplicationThread$Stub$Proxy;
    }
.end annotation


# instance fields
.field private final blacklist mTarget:Landroid/app/IApplicationThread;


# direct methods
.method public constructor whitelist <init>()V
    .registers 2

    .line 85
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 86
    new-instance v0, Lcom/oplus/wrapper/app/IApplicationThread$Stub$1;

    invoke-direct {v0, p0}, Lcom/oplus/wrapper/app/IApplicationThread$Stub$1;-><init>(Lcom/oplus/wrapper/app/IApplicationThread$Stub;)V

    iput-object v0, p0, Lcom/oplus/wrapper/app/IApplicationThread$Stub;->mTarget:Landroid/app/IApplicationThread;

    .line 461
    return-void
.end method

.method public static whitelist asInterface(Landroid/os/IBinder;)Lcom/oplus/wrapper/app/IApplicationThread;
    .registers 3
    .param p0, "obj"    # Landroid/os/IBinder;

    .line 469
    new-instance v0, Lcom/oplus/wrapper/app/IApplicationThread$Stub$Proxy;

    invoke-static {p0}, Landroid/app/IApplicationThread$Stub;->asInterface(Landroid/os/IBinder;)Landroid/app/IApplicationThread;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/oplus/wrapper/app/IApplicationThread$Stub$Proxy;-><init>(Landroid/app/IApplicationThread;)V

    return-object v0
.end method


# virtual methods
.method public whitelist asBinder()Landroid/os/IBinder;
    .registers 2

    .line 479
    iget-object v0, p0, Lcom/oplus/wrapper/app/IApplicationThread$Stub;->mTarget:Landroid/app/IApplicationThread;

    invoke-interface {v0}, Landroid/app/IApplicationThread;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method
