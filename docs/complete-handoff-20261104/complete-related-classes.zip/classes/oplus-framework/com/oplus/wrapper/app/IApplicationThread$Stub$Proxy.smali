.class Lcom/oplus/wrapper/app/IApplicationThread$Stub$Proxy;
.super Ljava/lang/Object;
.source "IApplicationThread.java"

# interfaces
.implements Lcom/oplus/wrapper/app/IApplicationThread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/oplus/wrapper/app/IApplicationThread$Stub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Proxy"
.end annotation


# instance fields
.field private final blacklist mTarget:Landroid/app/IApplicationThread;


# direct methods
.method constructor blacklist <init>(Landroid/app/IApplicationThread;)V
    .registers 2
    .param p1, "target"    # Landroid/app/IApplicationThread;

    .line 497
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 498
    iput-object p1, p0, Lcom/oplus/wrapper/app/IApplicationThread$Stub$Proxy;->mTarget:Landroid/app/IApplicationThread;

    .line 499
    return-void
.end method
