.class public Lcom/oplus/obpf/OBpfConnection;
.super Ljava/lang/Object;
.source "OBpfConnection.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;,
        Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;,
        Lcom/oplus/obpf/OBpfConnection$OBpfData;
    }
.end annotation


# static fields
.field private static final blacklist BFP_DATA_BYTES_TYPE:S = 0x1s

.field private static final blacklist BFP_DATA_KSTACK_TYPE:S = 0x3s

.field private static final blacklist BFP_DATA_STRING_TYPE:S = 0x2s

.field private static final blacklist BFP_DATA_USTACK_TYPE:S = 0x4s

.field private static final blacklist BPF_BIN_DATA_MAGIC_NUM:I = 0x40b

.field private static final blacklist BPF_COMMAND_HEADER_LEN:I = 0xc

.field private static final blacklist BPF_DATA_HEADER_LEN:I = 0xc

.field private static final blacklist BPF_DATA_MAX_BUFFER_SIZE:I = 0x1000

.field private static final blacklist BPF_DO_DUMP:Ljava/lang/String; = "doDump -a"

.field private static final blacklist BPF_MANAGER_MAGIC_NUM:Ljava/lang/String; = "obpf"

.field private static final blacklist BTF_SUPPORT_FLAG:I = 0x2

.field private static final blacklist CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final whitelist CUSTOMIZE_THREAD_FD_TYPE:I = 0x2

.field private static final blacklist DEBUG:Z

.field private static final blacklist DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final whitelist DEFAULT_THREAD_FD_TYPE:I = 0x1

.field private static final blacklist DEFAULT_THREAD_LOCK:Ljava/lang/Object;

.field private static final blacklist DEFAULT_THREAD_NAME:Ljava/lang/String; = "bpf:default"

.field private static final blacklist DELAY_CHECK_TIME:I = 0x3e8

.field public static final whitelist DUMP_BPF_CONNECT_NAME:I = 0x2

.field public static final whitelist DUMP_BPF_MANAGER:I = 0x1

.field public static final whitelist MANAGER_DUMP_COMMAND:S = 0x2s

.field public static final whitelist MANAGER_LOAD_BPF_COMMAND:S = 0x1s

.field public static final whitelist MANAGER_UNKNOWN_COMMAND:S = 0x0s

.field public static final whitelist MANAGER_USER_DATA_COMMAND:S = 0x3s

.field private static final blacklist MAX_COMMAND_LEN:I = 0x400

.field public static final whitelist NO_THREAD_FD_TYPE:I = 0x0

.field public static final whitelist OBPF_CONNECT_ERROR:I = -0x1

.field public static final whitelist OBPF_CONNECT_TRY_AGAIN:I = -0xb

.field private static final blacklist OBPF_MANAGER_DEFAULT_MAX_START_COUNT:I = 0x5

.field private static final blacklist OPLUS_BPF_ENABLE_PROP:Ljava/lang/String; = "sys.oplus.cvt.enable"

.field private static final blacklist OPLUS_BPF_MANAGER_SOCKET:Ljava/lang/String; = "/dev/socket/opluscvtmanager"

.field private static final blacklist OPLUS_BPF_MIN_INITIAL_SDK:I = 0x21

.field private static final blacklist OPLUS_BPF_MIN_SDK:I = 0x22

.field private static final blacklist SERVICE_NAME:Ljava/lang/String; = "opluscvt"

.field private static final blacklist SOCKET_NAME:Ljava/lang/String; = "opluscvtmanager"

.field private static final blacklist TAG:Ljava/lang/String; = "OCvtConnection"

.field private static volatile blacklist sBpfService:Lcom/oplus/obpf/IOplusBpfService;

.field private static blacklist sBpfThread:Landroid/os/HandlerThread;


# instance fields
.field private final blacklist mBpfConnectName:Ljava/lang/String;

.field private blacklist mBpfInputStream:Ljava/io/InputStream;

.field private blacklist mBpfOutputStream:Ljava/io/OutputStream;

.field private blacklist mBpfSocket:Landroid/net/LocalSocket;

.field private blacklist mBpfSocketFD:I

.field private final blacklist mBpfSocketLock:Ljava/lang/Object;

.field private final blacklist mInputBuf:Ljava/nio/ByteBuffer;

.field private final blacklist mInputData:Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;

.field private blacklist mIsDefaultQueue:Z

.field private final blacklist mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

.field private blacklist mLooper:Landroid/os/Looper;

.field private blacklist mMsgQueue:Landroid/os/MessageQueue;

.field private final blacklist mQuitLock:Ljava/lang/Object;

.field private blacklist mQuitting:Z

.field private final blacklist mReplyBufLock:Ljava/lang/Object;


# direct methods
.method public static synthetic blacklist $r8$lambda$7_ILs1j4TErFrtodb75ye5D0244(Lcom/oplus/obpf/OBpfConnection;Ljava/io/FileDescriptor;I)I
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/oplus/obpf/OBpfConnection;->lambda$connect$0(Ljava/io/FileDescriptor;I)I

    move-result p0

    return p0
.end method

.method static constructor blacklist <clinit>()V
    .registers 2

    .line 212
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    sput-object v0, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    .line 213
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    sput-object v0, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    .line 215
    const-string v0, "OCvtConnection"

    const/4 v1, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    sput-boolean v0, Lcom/oplus/obpf/OBpfConnection;->DEBUG:Z

    .line 216
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_LOCK:Ljava/lang/Object;

    .line 218
    const/4 v0, 0x0

    sput-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfService:Lcom/oplus/obpf/IOplusBpfService;

    return-void
.end method

.method public constructor whitelist <init>(Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;Landroid/os/Looper;Ljava/lang/String;)V
    .registers 7
    .param p1, "listener"    # Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;
    .param p2, "looper"    # Landroid/os/Looper;
    .param p3, "name"    # Ljava/lang/String;

    .line 269
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 225
    nop

    .line 226
    const/16 v0, 0x1000

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mInputBuf:Ljava/nio/ByteBuffer;

    .line 230
    new-instance v0, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    iget-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mInputBuf:Ljava/nio/ByteBuffer;

    .line 231
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v0, v1}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;-><init>(Ljava/io/InputStream;)V

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mInputData:Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;

    .line 235
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    .line 239
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mReplyBufLock:Ljava/lang/Object;

    .line 240
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitLock:Ljava/lang/Object;

    .line 247
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    .line 248
    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    .line 249
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    .line 250
    const/4 v2, -0x1

    iput v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    .line 252
    iput-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitting:Z

    .line 253
    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    .line 255
    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfOutputStream:Ljava/io/OutputStream;

    .line 257
    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfInputStream:Ljava/io/InputStream;

    .line 270
    iput-object p2, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    .line 271
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    if-eqz v0, :cond_54

    .line 272
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    invoke-virtual {v0}, Landroid/os/Looper;->getQueue()Landroid/os/MessageQueue;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    .line 274
    :cond_54
    iput-object p1, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    .line 275
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "bpf:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfConnectName:Ljava/lang/String;

    .line 276
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    if-nez v0, :cond_72

    .line 277
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    .line 279
    :cond_72
    return-void
.end method

.method private blacklist dumpBpfConnectName(I)I
    .registers 10
    .param p1, "socketFD"    # I

    .line 530
    const/4 v0, 0x0

    .line 531
    .local v0, "fdType":I
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_LOCK:Ljava/lang/Object;

    monitor-enter v1

    .line 532
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_5
    :try_start_5
    sget-object v3, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_44

    .line 533
    sget-object v3, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 534
    .local v3, "bpfConnectName":Ljava/lang/String;
    sget-object v4, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v4

    .line 535
    .local v4, "bpfSocketFD":I
    if-ne v4, p1, :cond_1e

    .line 536
    const/4 v0, 0x1

    .line 538
    :cond_1e
    const-string v5, "OCvtConnection"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "default thread ConnectName = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ", fd = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 532
    nop

    .end local v3    # "bpfConnectName":Ljava/lang/String;
    .end local v4    # "bpfSocketFD":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    .line 542
    .end local v2    # "i":I
    :cond_44
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_45
    sget-object v3, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_84

    .line 543
    sget-object v3, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 544
    .restart local v3    # "bpfConnectName":Ljava/lang/String;
    sget-object v4, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v4

    .line 545
    .restart local v4    # "bpfSocketFD":I
    if-ne v4, p1, :cond_5e

    .line 546
    const/4 v0, 0x2

    .line 548
    :cond_5e
    const-string v5, "OCvtConnection"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "customize thread ConnectName = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ", fd = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 542
    nop

    .end local v3    # "bpfConnectName":Ljava/lang/String;
    .end local v4    # "bpfSocketFD":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_45

    .line 551
    .end local v2    # "i":I
    :cond_84
    monitor-exit v1

    .line 552
    return v0

    .line 551
    :catchall_86
    move-exception v2

    monitor-exit v1
    :try_end_88
    .catchall {:try_start_5 .. :try_end_88} :catchall_86

    throw v2
.end method

.method private blacklist dumpBpfManager()I
    .registers 6

    .line 504
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfService:Lcom/oplus/obpf/IOplusBpfService;

    if-nez v0, :cond_11

    .line 505
    const-string/jumbo v0, "opluscvt"

    invoke-static {v0}, Landroid/os/ServiceManager;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    .line 506
    .local v0, "b":Landroid/os/IBinder;
    invoke-static {v0}, Lcom/oplus/obpf/IOplusBpfService$Stub;->asInterface(Landroid/os/IBinder;)Lcom/oplus/obpf/IOplusBpfService;

    move-result-object v1

    sput-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfService:Lcom/oplus/obpf/IOplusBpfService;

    .line 509
    .end local v0    # "b":Landroid/os/IBinder;
    :cond_11
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfService:Lcom/oplus/obpf/IOplusBpfService;

    const/4 v1, -0x1

    const-string v2, "OCvtConnection"

    if-nez v0, :cond_1e

    .line 510
    const-string v0, "doDump Service == null"

    invoke-static {v2, v0}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 511
    return v1

    .line 515
    :cond_1e
    :try_start_1e
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfService:Lcom/oplus/obpf/IOplusBpfService;

    const-string v3, "-a"

    invoke-virtual {v3}, Ljava/lang/String;->toCharArray()[C

    move-result-object v3

    invoke-interface {v0, v3}, Lcom/oplus/obpf/IOplusBpfService;->doDump([C)V
    :try_end_29
    .catch Landroid/os/RemoteException; {:try_start_1e .. :try_end_29} :catch_2c

    .line 519
    nop

    .line 520
    const/4 v0, 0x0

    return v0

    .line 516
    :catch_2c
    move-exception v0

    .line 517
    .local v0, "e":Landroid/os/RemoteException;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "doDump RemoteException e = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 518
    return v1
.end method

.method private blacklist execBpfCommand(Ljava/io/OutputStream;Ljava/lang/String;SI)Z
    .registers 12
    .param p1, "ostream"    # Ljava/io/OutputStream;
    .param p2, "message"    # Ljava/lang/String;
    .param p3, "command"    # S
    .param p4, "commandFlags"    # I

    .line 569
    const-string v0, ", command = "

    const-string v1, "OCvtConnection"

    const/4 v2, 0x0

    :try_start_5
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v3

    .line 570
    .local v3, "len":I
    const/16 v4, 0x400

    if-le v3, v4, :cond_e

    .line 571
    return v2

    .line 573
    :cond_e
    add-int/lit8 v4, v3, 0xc

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v4

    .line 574
    .local v4, "buf":Ljava/nio/ByteBuffer;
    sget-object v5, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 576
    const-string/jumbo v5, "obpf"

    invoke-virtual {v5}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 577
    invoke-virtual {v4, p3}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 578
    invoke-virtual {v4, p4}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 579
    int-to-short v5, v3

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 580
    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 581
    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v5

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->position()I

    move-result v6

    invoke-virtual {p1, v5, v2, v6}, Ljava/io/OutputStream;->write([BII)V

    .line 582
    sget-boolean v5, Lcom/oplus/obpf/OBpfConnection;->DEBUG:Z

    if-eqz v5, :cond_88

    .line 583
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "command position = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->position()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", buf.array().length = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 584
    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    array-length v6, v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", len = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", message = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 583
    invoke-static {v1, v5}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_88
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_88} :catch_8b

    .line 592
    .end local v3    # "len":I
    .end local v4    # "buf":Ljava/nio/ByteBuffer;
    :cond_88
    nop

    .line 593
    const/4 v0, 0x1

    return v0

    .line 588
    :catch_8b
    move-exception v3

    .line 589
    .local v3, "ex":Ljava/io/IOException;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "command IOException message = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, ", ex = "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 591
    return v2
.end method

.method private blacklist fileDescriptorEventHandler(Ljava/io/FileDescriptor;I)I
    .registers 5
    .param p1, "fd"    # Ljava/io/FileDescriptor;
    .param p2, "events"    # I

    .line 701
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    .line 702
    return v1

    .line 704
    :cond_6
    and-int/lit8 v0, p2, 0x1

    if-eqz v0, :cond_d

    .line 705
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->processIncomingData()V

    .line 707
    :cond_d
    and-int/lit8 v0, p2, 0x4

    if-eqz v0, :cond_15

    .line 708
    invoke-virtual {p0}, Lcom/oplus/obpf/OBpfConnection;->disconnect()V

    .line 709
    return v1

    .line 711
    :cond_15
    const/4 v0, 0x5

    return v0
.end method

.method private blacklist handleBpfData(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;I)Lcom/oplus/obpf/OBpfConnection$OBpfData;
    .registers 12
    .param p1, "inputData"    # Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;
    .param p2, "receivedLen"    # I

    .line 647
    const/16 v0, 0xc

    const/4 v1, 0x0

    const-string v2, "OCvtConnection"

    if-lt p2, v0, :cond_8f

    .line 649
    :try_start_7
    new-instance v0, Lcom/oplus/obpf/OBpfConnection$OBpfData;

    invoke-direct {v0, v1}, Lcom/oplus/obpf/OBpfConnection$OBpfData;-><init>(Lcom/oplus/obpf/OBpfConnection-IA;)V

    .line 650
    .local v0, "oBpfData":Lcom/oplus/obpf/OBpfConnection$OBpfData;
    sget-object v3, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {p1, v3}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->-$$Nest$mreadInt(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;Ljava/nio/ByteOrder;)I

    move-result v3

    .line 652
    .local v3, "magicNum":I
    const/16 v4, 0x40b

    if-eq v3, v4, :cond_2d

    .line 653
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "handleData mismatch magicNum = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 654
    return-object v1

    .line 657
    :cond_2d
    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {p1, v4}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->-$$Nest$mreadInt(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;Ljava/nio/ByteOrder;)I

    move-result v4

    .line 658
    .local v4, "dispatchFlag":I
    sget-object v5, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {p1, v5}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->-$$Nest$mreadShort(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;Ljava/nio/ByteOrder;)S

    move-result v5

    .line 659
    .local v5, "dataType":S
    sget-object v6, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {p1, v6}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->-$$Nest$mreadShort(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;Ljava/nio/ByteOrder;)S

    move-result v6

    const v7, 0xffff

    and-int/2addr v6, v7

    .line 661
    .local v6, "msgLen":I
    invoke-static {v0, v4}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fputmDispatchFlag(Lcom/oplus/obpf/OBpfConnection$OBpfData;I)V

    .line 662
    invoke-static {v0, v5}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fputmDataType(Lcom/oplus/obpf/OBpfConnection$OBpfData;S)V

    .line 663
    add-int/lit8 v7, p2, -0xc

    if-eq v6, v7, :cond_6d

    .line 664
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "handleData illegal msgLen = "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ", receivedLen = "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v2, v7}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 667
    :cond_6d
    add-int/lit8 v6, p2, -0xc

    .line 668
    new-array v7, v6, [B

    .line 669
    .local v7, "bytes":[B
    invoke-virtual {p1, v7}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->readFully([B)V

    .line 670
    invoke-static {v0, v7}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fputmData(Lcom/oplus/obpf/OBpfConnection$OBpfData;[B)V
    :try_end_77
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_77} :catch_78

    .line 671
    return-object v0

    .line 672
    .end local v0    # "oBpfData":Lcom/oplus/obpf/OBpfConnection$OBpfData;
    .end local v3    # "magicNum":I
    .end local v4    # "dispatchFlag":I
    .end local v5    # "dataType":S
    .end local v6    # "msgLen":I
    .end local v7    # "bytes":[B
    :catch_78
    move-exception v0

    .line 673
    .local v0, "e":Ljava/io/IOException;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "handleData IOException e = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 676
    .end local v0    # "e":Ljava/io/IOException;
    :cond_8f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "handleData fail receivedLen = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 677
    return-object v1
.end method

.method private blacklist ignoreConnect()Z
    .registers 5

    .line 715
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    const/4 v1, 0x1

    if-eqz v0, :cond_d

    .line 716
    const-string v0, "OCvtConnection"

    const-string v2, "is already connect"

    invoke-static {v0, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 717
    return v1

    .line 720
    :cond_d
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    if-nez v0, :cond_19

    .line 721
    const-string v0, "OCvtConnection"

    const-string v2, "do not have ConnectionListener"

    invoke-static {v0, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 722
    return v1

    .line 725
    :cond_19
    const/4 v0, 0x0

    .line 726
    .local v0, "quitting":Z
    iget-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitLock:Ljava/lang/Object;

    monitor-enter v2

    .line 727
    :try_start_1d
    iget-boolean v3, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitting:Z

    move v0, v3

    .line 728
    monitor-exit v2
    :try_end_21
    .catchall {:try_start_1d .. :try_end_21} :catchall_2d

    .line 730
    if-eqz v0, :cond_2b

    .line 731
    const-string v2, "OCvtConnection"

    const-string v3, "can not use this, now mQuitting = true"

    invoke-static {v2, v3}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 732
    return v1

    .line 734
    :cond_2b
    const/4 v1, 0x0

    return v1

    .line 728
    :catchall_2d
    move-exception v1

    :try_start_2e
    monitor-exit v2
    :try_end_2f
    .catchall {:try_start_2e .. :try_end_2f} :catchall_2d

    throw v1
.end method

.method private blacklist initMsgQueue()Z
    .registers 5

    .line 622
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 623
    :try_start_3
    iget-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    if-eqz v1, :cond_2b

    .line 624
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    if-nez v1, :cond_1b

    .line 625
    new-instance v1, Landroid/os/HandlerThread;

    const-string v2, "bpf:default"

    const/16 v3, 0xa

    invoke-direct {v1, v2, v3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    .line 627
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->start()V

    .line 629
    :cond_1b
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    iput-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    .line 630
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mLooper:Landroid/os/Looper;

    invoke-virtual {v1}, Landroid/os/Looper;->getQueue()Landroid/os/MessageQueue;

    move-result-object v1

    iput-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    .line 632
    :cond_2b
    iget-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    if-eqz v1, :cond_39

    .line 633
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    iget v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    iget-object v3, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfConnectName:Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_42

    .line 635
    :cond_39
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    iget v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    iget-object v3, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfConnectName:Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 637
    :goto_42
    monitor-exit v0
    :try_end_43
    .catchall {:try_start_3 .. :try_end_43} :catchall_52

    .line 639
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    if-nez v0, :cond_50

    .line 640
    const-string v0, "OCvtConnection"

    const-string v1, "init fail mMsgQueue = null"

    invoke-static {v0, v1}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 641
    const/4 v0, 0x0

    return v0

    .line 643
    :cond_50
    const/4 v0, 0x1

    return v0

    .line 637
    :catchall_52
    move-exception v1

    :try_start_53
    monitor-exit v0
    :try_end_54
    .catchall {:try_start_53 .. :try_end_54} :catchall_52

    throw v1
.end method

.method private static blacklist isBpfSocketExist()Z
    .registers 2

    .line 556
    new-instance v0, Ljava/io/File;

    const-string v1, "/dev/socket/opluscvtmanager"

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 557
    .local v0, "socketFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    return v1
.end method

.method public static whitelist isBtfSupport()Z
    .registers 2

    .line 307
    const-string/jumbo v0, "sys.oplus.cvt.enable"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getInt(Ljava/lang/String;I)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_d

    const/4 v1, 0x1

    :cond_d
    return v1
.end method

.method public static whitelist isEnable()Z
    .registers 2

    .line 289
    invoke-static {}, Lcom/oplus/obpf/OBpfConnection;->isLegalSdkAndBpfEnable()Z

    move-result v0

    if-nez v0, :cond_8

    .line 290
    const/4 v0, 0x0

    return v0

    .line 293
    :cond_8
    invoke-static {}, Lcom/oplus/obpf/OBpfConnection;->isBpfSocketExist()Z

    move-result v0

    if-nez v0, :cond_15

    .line 294
    const-string v0, "OCvtConnection"

    const-string v1, "do not exist"

    invoke-static {v0, v1}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 296
    :cond_15
    const/4 v0, 0x1

    return v0
.end method

.method private static blacklist isLegalSdkAndBpfEnable()Z
    .registers 3

    .line 561
    sget v0, Landroid/os/Build$VERSION;->DEVICE_INITIAL_SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x0

    if-lt v0, v1, :cond_12

    .line 563
    const-string/jumbo v0, "sys.oplus.cvt.enable"

    invoke-static {v0, v2}, Landroid/os/SystemProperties;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-lez v0, :cond_12

    const/4 v2, 0x1

    goto :goto_13

    :cond_12
    nop

    .line 561
    :goto_13
    return v2
.end method

.method public static whitelist isStringType(S)Z
    .registers 2
    .param p0, "dataType"    # S

    .line 319
    const/4 v0, 0x2

    if-eq p0, v0, :cond_c

    const/4 v0, 0x3

    if-eq p0, v0, :cond_c

    const/4 v0, 0x4

    if-ne p0, v0, :cond_a

    goto :goto_c

    :cond_a
    const/4 v0, 0x0

    goto :goto_d

    :cond_c
    :goto_c
    const/4 v0, 0x1

    :goto_d
    return v0
.end method

.method private synthetic blacklist lambda$connect$0(Ljava/io/FileDescriptor;I)I
    .registers 4
    .param p1, "fd"    # Ljava/io/FileDescriptor;
    .param p2, "events"    # I

    .line 384
    invoke-direct {p0, p1, p2}, Lcom/oplus/obpf/OBpfConnection;->fileDescriptorEventHandler(Ljava/io/FileDescriptor;I)I

    move-result v0

    return v0
.end method

.method private blacklist openSocket()Landroid/net/LocalSocket;
    .registers 5

    .line 599
    :try_start_0
    new-instance v0, Landroid/net/LocalSocket;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/net/LocalSocket;-><init>(I)V

    .line 600
    .local v0, "socket":Landroid/net/LocalSocket;
    new-instance v1, Landroid/net/LocalSocketAddress;

    const-string/jumbo v2, "opluscvtmanager"

    sget-object v3, Landroid/net/LocalSocketAddress$Namespace;->RESERVED:Landroid/net/LocalSocketAddress$Namespace;

    invoke-direct {v1, v2, v3}, Landroid/net/LocalSocketAddress;-><init>(Ljava/lang/String;Landroid/net/LocalSocketAddress$Namespace;)V

    invoke-virtual {v0, v1}, Landroid/net/LocalSocket;->connect(Landroid/net/LocalSocketAddress;)V
    :try_end_13
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_13} :catch_15

    .line 606
    nop

    .line 607
    return-object v0

    .line 603
    .end local v0    # "socket":Landroid/net/LocalSocket;
    :catch_15
    move-exception v0

    .line 604
    .local v0, "ex":Ljava/io/IOException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Connection failed: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OCvtConnection"

    invoke-static {v2, v1}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 605
    const/4 v1, 0x0

    return-object v1
.end method

.method private blacklist processIncomingData()V
    .registers 8

    .line 681
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mInputBuf:Ljava/nio/ByteBuffer;

    invoke-direct {p0, v0}, Lcom/oplus/obpf/OBpfConnection;->read(Ljava/nio/ByteBuffer;)I

    move-result v0

    .line 682
    .local v0, "len":I
    if-lez v0, :cond_53

    .line 685
    :try_start_8
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mInputData:Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;

    invoke-virtual {v1}, Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;->reset()V

    .line 686
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mReplyBufLock:Ljava/lang/Object;

    monitor-enter v1
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_10} :catch_3a

    .line 687
    :try_start_10
    iget-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mInputData:Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;

    invoke-direct {p0, v2, v0}, Lcom/oplus/obpf/OBpfConnection;->handleBpfData(Lcom/oplus/obpf/OBpfConnection$ByteBufferInputStream;I)Lcom/oplus/obpf/OBpfConnection$OBpfData;

    move-result-object v2

    .line 688
    .local v2, "oBpfData":Lcom/oplus/obpf/OBpfConnection$OBpfData;
    if-eqz v2, :cond_35

    invoke-static {v2}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fgetmDispatchFlag(Lcom/oplus/obpf/OBpfConnection$OBpfData;)I

    move-result v3

    if-lez v3, :cond_35

    invoke-static {v2}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fgetmData(Lcom/oplus/obpf/OBpfConnection$OBpfData;)[B

    move-result-object v3

    if-eqz v3, :cond_35

    .line 690
    iget-object v3, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    invoke-static {v2}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fgetmDispatchFlag(Lcom/oplus/obpf/OBpfConnection$OBpfData;)I

    move-result v4

    invoke-static {v2}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fgetmDataType(Lcom/oplus/obpf/OBpfConnection$OBpfData;)S

    move-result v5

    invoke-static {v2}, Lcom/oplus/obpf/OBpfConnection$OBpfData;->-$$Nest$fgetmData(Lcom/oplus/obpf/OBpfConnection$OBpfData;)[B

    move-result-object v6

    invoke-interface {v3, v4, v5, v6}, Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;->onBpfDataArrived(IS[B)V

    .line 693
    .end local v2    # "oBpfData":Lcom/oplus/obpf/OBpfConnection$OBpfData;
    :cond_35
    monitor-exit v1

    .line 696
    goto :goto_53

    .line 693
    :catchall_37
    move-exception v2

    monitor-exit v1
    :try_end_39
    .catchall {:try_start_10 .. :try_end_39} :catchall_37

    .end local v0    # "len":I
    .end local p0    # "this":Lcom/oplus/obpf/OBpfConnection;
    :try_start_39
    throw v2
    :try_end_3a
    .catch Ljava/io/IOException; {:try_start_39 .. :try_end_3a} :catch_3a

    .line 694
    .restart local v0    # "len":I
    .restart local p0    # "this":Lcom/oplus/obpf/OBpfConnection;
    :catch_3a
    move-exception v1

    .line 695
    .local v1, "e":Ljava/io/IOException;
    const-string v2, "OCvtConnection"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Failed to parse bpf data buffer. Size = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 698
    .end local v1    # "e":Ljava/io/IOException;
    :cond_53
    :goto_53
    return-void
.end method

.method private blacklist quitDefaultThread()V
    .registers 3

    .line 451
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    if-eqz v0, :cond_16

    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-gtz v0, :cond_16

    .line 452
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    .line 453
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 454
    sput-object v0, Lcom/oplus/obpf/OBpfConnection;->sBpfThread:Landroid/os/HandlerThread;

    .line 456
    :cond_16
    return-void
.end method

.method private blacklist read(Ljava/nio/ByteBuffer;)I
    .registers 7
    .param p1, "buf"    # Ljava/nio/ByteBuffer;

    .line 611
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    monitor-enter v0

    .line 613
    :try_start_3
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfInputStream:Ljava/io/InputStream;

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    array-length v3, v3

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v4, v3}, Ljava/io/InputStream;->read([BII)I

    move-result v1
    :try_end_13
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_13} :catch_17
    .catchall {:try_start_3 .. :try_end_13} :catchall_15

    :try_start_13
    monitor-exit v0

    return v1

    .line 618
    :catchall_15
    move-exception v1

    goto :goto_35

    .line 614
    :catch_17
    move-exception v1

    .line 615
    .local v1, "ex":Ljava/io/IOException;
    const-string v2, "OCvtConnection"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "read IOException ex = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 617
    nop

    .end local v1    # "ex":Ljava/io/IOException;
    monitor-exit v0

    const/4 v0, -0x1

    return v0

    .line 618
    :goto_35
    monitor-exit v0
    :try_end_36
    .catchall {:try_start_13 .. :try_end_36} :catchall_15

    throw v1
.end method


# virtual methods
.method public whitelist connect(Ljava/lang/String;SI)I
    .registers 12
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "command"    # S
    .param p3, "commandFlags"    # I

    .line 334
    invoke-static {}, Lcom/oplus/obpf/OBpfConnection;->isLegalSdkAndBpfEnable()Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_8

    .line 335
    return v1

    .line 338
    :cond_8
    invoke-static {}, Lcom/oplus/obpf/OBpfConnection;->isBpfSocketExist()Z

    move-result v0

    if-nez v0, :cond_11

    .line 339
    const/16 v0, -0xb

    return v0

    .line 342
    :cond_11
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    monitor-enter v0

    .line 343
    :try_start_14
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->ignoreConnect()Z

    move-result v2

    if-eqz v2, :cond_1c

    .line 344
    monitor-exit v0

    return v1

    .line 348
    :cond_1c
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->openSocket()Landroid/net/LocalSocket;

    move-result-object v2

    .line 350
    .local v2, "socket":Landroid/net/LocalSocket;
    if-nez v2, :cond_2b

    .line 351
    const-string v3, "OCvtConnection"

    const-string v4, "connect socket == null"

    invoke-static {v3, v4}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 352
    monitor-exit v0
    :try_end_2a
    .catchall {:try_start_14 .. :try_end_2a} :catchall_97

    return v1

    .line 358
    :cond_2b
    :try_start_2b
    invoke-virtual {v2}, Landroid/net/LocalSocket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    .line 359
    .local v3, "ostream":Ljava/io/OutputStream;
    invoke-virtual {v2}, Landroid/net/LocalSocket;->getInputStream()Ljava/io/InputStream;

    move-result-object v4
    :try_end_33
    .catch Ljava/io/IOException; {:try_start_2b .. :try_end_33} :catch_79
    .catchall {:try_start_2b .. :try_end_33} :catchall_97

    .line 364
    .local v4, "istream":Ljava/io/InputStream;
    nop

    .line 366
    :try_start_34
    invoke-direct {p0, v3, p1, p2, p3}, Lcom/oplus/obpf/OBpfConnection;->execBpfCommand(Ljava/io/OutputStream;Ljava/lang/String;SI)Z

    move-result v5

    if-nez v5, :cond_3f

    .line 367
    invoke-static {v2}, Llibcore/io/IoUtils;->closeQuietly(Ljava/lang/AutoCloseable;)V

    .line 368
    monitor-exit v0

    return v1

    .line 372
    :cond_3f
    iput-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    .line 373
    iput-object v3, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfOutputStream:Ljava/io/OutputStream;

    .line 374
    iput-object v4, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfInputStream:Ljava/io/InputStream;

    .line 376
    iget-object v5, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    invoke-virtual {v5}, Landroid/net/LocalSocket;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/FileDescriptor;->getInt$()I

    move-result v5

    iput v5, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    .line 377
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->initMsgQueue()Z

    move-result v5

    if-nez v5, :cond_5f

    .line 378
    invoke-static {v2}, Llibcore/io/IoUtils;->closeQuietly(Ljava/lang/AutoCloseable;)V

    .line 379
    const/4 v5, 0x0

    iput-object v5, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    .line 380
    monitor-exit v0

    return v1

    .line 382
    :cond_5f
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    iget-object v5, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    invoke-virtual {v5}, Landroid/net/LocalSocket;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v5

    new-instance v6, Lcom/oplus/obpf/OBpfConnection$$ExternalSyntheticLambda0;

    invoke-direct {v6, p0}, Lcom/oplus/obpf/OBpfConnection$$ExternalSyntheticLambda0;-><init>(Lcom/oplus/obpf/OBpfConnection;)V

    const/4 v7, 0x5

    invoke-virtual {v1, v5, v7, v6}, Landroid/os/MessageQueue;->addOnFileDescriptorEventListener(Ljava/io/FileDescriptor;ILandroid/os/MessageQueue$OnFileDescriptorEventListener;)V

    .line 386
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    .line 387
    .end local v2    # "socket":Landroid/net/LocalSocket;
    .end local v3    # "ostream":Ljava/io/OutputStream;
    .end local v4    # "istream":Ljava/io/InputStream;
    monitor-exit v0
    :try_end_76
    .catchall {:try_start_34 .. :try_end_76} :catchall_97

    .line 388
    iget v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    return v0

    .line 360
    .restart local v2    # "socket":Landroid/net/LocalSocket;
    :catch_79
    move-exception v3

    .line 361
    .local v3, "ex":Ljava/io/IOException;
    :try_start_7a
    invoke-static {v2}, Llibcore/io/IoUtils;->closeQuietly(Ljava/lang/AutoCloseable;)V

    .line 362
    const-string v4, "OCvtConnection"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "connect IOException ex = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 363
    monitor-exit v0

    return v1

    .line 387
    .end local v2    # "socket":Landroid/net/LocalSocket;
    .end local v3    # "ex":Ljava/io/IOException;
    :catchall_97
    move-exception v1

    monitor-exit v0
    :try_end_99
    .catchall {:try_start_7a .. :try_end_99} :catchall_97

    throw v1
.end method

.method public whitelist disconnect()V
    .registers 4

    .line 399
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    monitor-enter v0

    .line 400
    :try_start_3
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    if-eqz v1, :cond_27

    .line 402
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    if-eqz v1, :cond_16

    .line 403
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mMsgQueue:Landroid/os/MessageQueue;

    iget-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    .line 404
    invoke-virtual {v2}, Landroid/net/LocalSocket;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v2

    .line 403
    invoke-virtual {v1, v2}, Landroid/os/MessageQueue;->removeOnFileDescriptorEventListener(Ljava/io/FileDescriptor;)V

    .line 406
    :cond_16
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    invoke-static {v1}, Llibcore/io/IoUtils;->closeQuietly(Ljava/lang/AutoCloseable;)V

    .line 407
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    .line 410
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    if-eqz v1, :cond_27

    .line 411
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mListener:Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;

    invoke-interface {v1}, Lcom/oplus/obpf/OBpfConnection$BpfConnectionListener;->onDisconnect()V

    .line 414
    :cond_27
    monitor-exit v0
    :try_end_28
    .catchall {:try_start_3 .. :try_end_28} :catchall_4a

    .line 416
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_LOCK:Ljava/lang/Object;

    monitor-enter v1

    .line 417
    :try_start_2b
    iget v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    if-ltz v0, :cond_45

    .line 418
    iget-boolean v0, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    if-eqz v0, :cond_3b

    .line 419
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_FD_MAP:Landroid/util/SparseArray;

    iget v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->remove(I)V

    goto :goto_42

    .line 421
    :cond_3b
    sget-object v0, Lcom/oplus/obpf/OBpfConnection;->CUSTOMIZE_THREAD_FD_MAP:Landroid/util/SparseArray;

    iget v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->remove(I)V

    .line 423
    :goto_42
    const/4 v0, -0x1

    iput v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketFD:I

    .line 425
    :cond_45
    monitor-exit v1

    .line 426
    return-void

    .line 425
    :catchall_47
    move-exception v0

    monitor-exit v1
    :try_end_49
    .catchall {:try_start_2b .. :try_end_49} :catchall_47

    throw v0

    .line 414
    :catchall_4a
    move-exception v1

    :try_start_4b
    monitor-exit v0
    :try_end_4c
    .catchall {:try_start_4b .. :try_end_4c} :catchall_4a

    throw v1
.end method

.method public whitelist doDump(II)I
    .registers 4
    .param p1, "dumpType"    # I
    .param p2, "dumpArg"    # I

    .line 468
    packed-switch p1, :pswitch_data_10

    .line 477
    const/4 v0, -0x1

    return v0

    .line 472
    :pswitch_5
    invoke-direct {p0, p2}, Lcom/oplus/obpf/OBpfConnection;->dumpBpfConnectName(I)I

    move-result v0

    return v0

    .line 470
    :pswitch_a
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->dumpBpfManager()I

    move-result v0

    return v0

    nop

    :pswitch_data_10
    .packed-switch 0x1
        :pswitch_a
        :pswitch_5
    .end packed-switch
.end method

.method public whitelist exit()V
    .registers 3

    .line 436
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitLock:Ljava/lang/Object;

    monitor-enter v0

    .line 437
    :try_start_3
    iget-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitting:Z

    if-eqz v1, :cond_9

    .line 438
    monitor-exit v0

    return-void

    .line 440
    :cond_9
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/oplus/obpf/OBpfConnection;->mQuitting:Z

    .line 441
    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_1f

    .line 442
    invoke-virtual {p0}, Lcom/oplus/obpf/OBpfConnection;->disconnect()V

    .line 443
    sget-object v1, Lcom/oplus/obpf/OBpfConnection;->DEFAULT_THREAD_LOCK:Ljava/lang/Object;

    monitor-enter v1

    .line 444
    :try_start_13
    iget-boolean v0, p0, Lcom/oplus/obpf/OBpfConnection;->mIsDefaultQueue:Z

    if-eqz v0, :cond_1a

    .line 445
    invoke-direct {p0}, Lcom/oplus/obpf/OBpfConnection;->quitDefaultThread()V

    .line 447
    :cond_1a
    monitor-exit v1

    .line 448
    return-void

    .line 447
    :catchall_1c
    move-exception v0

    monitor-exit v1
    :try_end_1e
    .catchall {:try_start_13 .. :try_end_1e} :catchall_1c

    throw v0

    .line 441
    :catchall_1f
    move-exception v1

    :try_start_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_20 .. :try_end_21} :catchall_1f

    throw v1
.end method

.method protected whitelist test-api finalize()V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .line 740
    :try_start_0
    sget-boolean v0, Lcom/oplus/obpf/OBpfConnection;->DEBUG:Z

    if-eqz v0, :cond_1e

    .line 741
    const-string v0, "OCvtConnection"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "finalize ConnectName = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfConnectName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 743
    :cond_1e
    invoke-virtual {p0}, Lcom/oplus/obpf/OBpfConnection;->exit()V
    :try_end_21
    .catchall {:try_start_0 .. :try_end_21} :catchall_26

    .line 745
    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    .line 746
    nop

    .line 747
    return-void

    .line 745
    :catchall_26
    move-exception v0

    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    .line 746
    throw v0
.end method

.method public whitelist sendUserData(Ljava/lang/String;I)V
    .registers 6
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "commandFlags"    # I

    .line 489
    iget-object v0, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocketLock:Ljava/lang/Object;

    monitor-enter v0

    .line 490
    :try_start_3
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfSocket:Landroid/net/LocalSocket;

    if-eqz v1, :cond_11

    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfOutputStream:Ljava/io/OutputStream;

    if-eqz v1, :cond_11

    .line 491
    iget-object v1, p0, Lcom/oplus/obpf/OBpfConnection;->mBpfOutputStream:Ljava/io/OutputStream;

    const/4 v2, 0x3

    invoke-direct {p0, v1, p1, v2, p2}, Lcom/oplus/obpf/OBpfConnection;->execBpfCommand(Ljava/io/OutputStream;Ljava/lang/String;SI)Z

    .line 493
    :cond_11
    monitor-exit v0

    .line 494
    return-void

    .line 493
    :catchall_13
    move-exception v1

    monitor-exit v0
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_13

    throw v1
.end method
