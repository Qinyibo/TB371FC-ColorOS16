.class public Lcom/android/internal/os/RuntimeInitExtImpl;
.super Ljava/lang/Object;
.source "RuntimeInitExtImpl.java"

# interfaces
.implements Lcom/android/internal/os/IRuntimeInitExt;


# static fields
.field private static final blacklist HPROF_COUNT:I = 0x4

.field private static final blacklist OOM_EXCEPTION:Ljava/lang/String; = "java.lang.OutOfMemoryError"

.field private static final blacklist PRELOAD_CLASSES:[Ljava/lang/String;

.field static final blacklist TAG:Ljava/lang/String; = "AndroidRuntime"


# direct methods
.method static constructor blacklist <clinit>()V
    .registers 3

    .line 52
    const-string/jumbo v0, "system.ext.registry.BaseCommonCoreRegistry"

    const-string/jumbo v1, "system.ext.registry.SocCommonCoreRegistry"

    const-string/jumbo v2, "system.ext.registry.PreloadRegistry"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/os/RuntimeInitExtImpl;->PRELOAD_CLASSES:[Ljava/lang/String;

    return-void
.end method

.method public constructor blacklist <init>()V
    .registers 1

    .line 50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private blacklist checkTooManyMessages(Ljava/lang/Throwable;)V
    .registers 5
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 95
    new-instance v0, Landroid/app/ApplicationErrorReport$CrashInfo;

    invoke-direct {v0, p1}, Landroid/app/ApplicationErrorReport$CrashInfo;-><init>(Ljava/lang/Throwable;)V

    .line 96
    .local v0, "crashInfo":Landroid/app/ApplicationErrorReport$CrashInfo;
    const-string/jumbo v1, "java.lang.OutOfMemoryError"

    iget-object v2, v0, Landroid/app/ApplicationErrorReport$CrashInfo;->exceptionClassName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13

    .line 97
    invoke-static {}, Landroid/os/OplusTooManyMessagesTrack;->dumpIfTooManyMessages()V

    .line 99
    :cond_13
    return-void
.end method

.method public static blacklist preload(Ljava/lang/ClassLoader;)V
    .registers 9
    .param p0, "preloadClassLoader"    # Ljava/lang/ClassLoader;

    .line 145
    const-string v0, "AndroidRuntime"

    if-nez p0, :cond_a

    .line 146
    const-class v1, Lcom/android/internal/os/RuntimeInitExtImpl;

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    .line 149
    :cond_a
    sget-object v1, Lcom/android/internal/os/RuntimeInitExtImpl;->PRELOAD_CLASSES:[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_e
    if-ge v3, v2, :cond_76

    aget-object v4, v1, v3

    .line 151
    .local v4, "preloadClass":Ljava/lang/String;
    const/4 v5, 0x1

    :try_start_13
    invoke-static {v4, v5, p0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_16
    .catch Ljava/lang/ClassNotFoundException; {:try_start_13 .. :try_end_16} :catch_6c
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_13 .. :try_end_16} :catch_4a
    .catchall {:try_start_13 .. :try_end_16} :catchall_17

    .line 165
    :goto_16
    goto :goto_73

    .line 156
    :catchall_17
    move-exception v1

    .line 157
    .local v1, "t":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Error preloading "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 158
    instance-of v0, v1, Ljava/lang/Error;

    if-nez v0, :cond_46

    .line 160
    instance-of v0, v1, Ljava/lang/RuntimeException;

    if-eqz v0, :cond_40

    .line 161
    move-object v0, v1

    check-cast v0, Ljava/lang/RuntimeException;

    throw v0

    .line 163
    :cond_40
    new-instance v0, Ljava/lang/RuntimeException;

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v0

    .line 159
    :cond_46
    move-object v0, v1

    check-cast v0, Ljava/lang/Error;

    throw v0

    .line 154
    .end local v1    # "t":Ljava/lang/Throwable;
    :catch_4a
    move-exception v5

    .line 155
    .local v5, "e":Ljava/lang/UnsatisfiedLinkError;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Problem preloading "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ": "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v0, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .end local v5    # "e":Ljava/lang/UnsatisfiedLinkError;
    goto :goto_16

    .line 152
    :catch_6c
    move-exception v5

    .line 153
    .local v5, "e":Ljava/lang/ClassNotFoundException;
    const-string v6, "Class not found for extloader"

    invoke-static {v0, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .end local v5    # "e":Ljava/lang/ClassNotFoundException;
    goto :goto_16

    .line 149
    .end local v4    # "preloadClass":Ljava/lang/String;
    :goto_73
    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    .line 167
    :cond_76
    return-void
.end method


# virtual methods
.method public blacklist collectHeapdump(Ljava/lang/Throwable;)V
    .registers 13
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 110
    const-string v0, "AndroidRuntime"

    const-string v1, "/data/persist_log/hprofdump/"

    invoke-direct {p0, p1}, Lcom/android/internal/os/RuntimeInitExtImpl;->checkTooManyMessages(Ljava/lang/Throwable;)V

    .line 113
    const-string/jumbo v2, "persist.sys.assert.panic"

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    .line 114
    .local v2, "isLogkitOpen":Z
    const-string/jumbo v4, "persist.sys.alwayson.enable"

    invoke-static {v4, v3}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 115
    .local v3, "isLogAlwaysOn":Z
    sget-boolean v4, Landroid/os/Build;->IS_DEBUGGABLE:Z

    if-nez v4, :cond_1f

    if-nez v2, :cond_1f

    if-nez v3, :cond_1f

    .line 116
    return-void

    .line 119
    :cond_1f
    new-instance v4, Landroid/app/ApplicationErrorReport$CrashInfo;

    invoke-direct {v4, p1}, Landroid/app/ApplicationErrorReport$CrashInfo;-><init>(Ljava/lang/Throwable;)V

    .line 121
    .local v4, "crashInfo":Landroid/app/ApplicationErrorReport$CrashInfo;
    const-string/jumbo v5, "java.lang.OutOfMemoryError"

    iget-object v6, v4, Landroid/app/ApplicationErrorReport$CrashInfo;->exceptionClassName:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_80

    .line 123
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/system/Os;->getpid()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".hprof"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 124
    .local v5, "fileName":Ljava/lang/String;
    const-string v6, "/data/persist_log/hprofdump/"

    .line 126
    .local v6, "directory":Ljava/lang/String;
    const/4 v7, 0x4

    :try_start_49
    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 127
    .local v8, "dumpDir":Ljava/io/File;
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v9

    if-nez v9, :cond_57

    .line 128
    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    .line 130
    :cond_57
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 131
    .local v1, "logpath":Ljava/lang/String;
    invoke-static {v1}, Landroid/os/Debug;->dumpHprofData(Ljava/lang/String;)V

    .line 134
    const-wide/16 v9, 0x0

    invoke-static {v8, v7, v9, v10}, Landroid/os/FileUtils;->deleteOlderFiles(Ljava/io/File;IJ)Z
    :try_end_70
    .catch Ljava/io/IOException; {:try_start_49 .. :try_end_70} :catch_72

    .line 138
    nop

    .end local v1    # "logpath":Ljava/lang/String;
    .end local v8    # "dumpDir":Ljava/io/File;
    goto :goto_7a

    .line 136
    :catch_72
    move-exception v1

    .line 137
    .local v1, "err":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v8

    invoke-static {v0, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 139
    .end local v1    # "err":Ljava/io/IOException;
    :goto_7a
    const/4 v1, 0x6

    const-string v8, "OutOfMemoryError IN SYSTEM PROCESS: Already dump hprof!"

    invoke-static {v7, v1, v0, v8, p1}, Landroid/util/Log;->printlns(IILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 141
    .end local v5    # "fileName":Ljava/lang/String;
    .end local v6    # "directory":Ljava/lang/String;
    :cond_80
    return-void
.end method

.method public blacklist uncaughtExceptionExt(Ljava/lang/Thread;Ljava/lang/Throwable;Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .registers 9
    .param p1, "t"    # Ljava/lang/Thread;
    .param p2, "e"    # Ljava/lang/Throwable;
    .param p3, "eh"    # Ljava/lang/Thread$UncaughtExceptionHandler;

    .line 70
    const-string/jumbo v0, "main"

    invoke-virtual {p1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_37

    invoke-static {}, Landroid/app/ActivityThread;->currentActivityThread()Landroid/app/ActivityThread;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/ActivityThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    if-ne p1, v0, :cond_37

    .line 72
    :try_start_1b
    invoke-virtual {p1}, Ljava/lang/Thread;->getUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    :try_end_22
    .catchall {:try_start_1b .. :try_end_22} :catchall_23

    .line 83
    goto :goto_34

    .line 73
    :catchall_23
    move-exception v0

    .line 74
    .local v0, "t2":Ljava/lang/Throwable;
    instance-of v1, v0, Landroid/os/DeadObjectException;

    if-eqz v1, :cond_29

    goto :goto_34

    .line 78
    :cond_29
    :try_start_29
    const-string v1, "AndroidRuntime"

    const-string v2, "Error reporting crash"

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v3, v4, v1, v2, v0}, Landroid/util/Log;->printlns(IILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_32
    .catchall {:try_start_29 .. :try_end_32} :catchall_33

    .line 81
    goto :goto_34

    .line 79
    :catchall_33
    move-exception v1

    .line 84
    .end local v0    # "t2":Ljava/lang/Throwable;
    :goto_34
    invoke-virtual {p1, p3}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    .line 88
    :cond_37
    const/4 v0, 0x1

    sput-boolean v0, Lcom/android/internal/os/OplusExceptionHelper;->sTriggered:Z

    .line 90
    return-void
.end method
