.class Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"

# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "CoverModeExcutor"
.end annotation


# instance fields
.field private final mHander:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/os/Handler;)V
    .registers 3
    .param p1, "handler"    # Landroid/os/Handler;

    .line 170
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 171
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Handler;

    iput-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;->mHander:Landroid/os/Handler;

    .line 172
    return-void
.end method


# virtual methods
.method public execute(Ljava/lang/Runnable;)V
    .registers 3
    .param p1, "runnable"    # Ljava/lang/Runnable;

    .line 176
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;->mHander:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 177
    return-void
.end method
