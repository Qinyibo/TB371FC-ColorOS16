.class public Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;
.super Lcom/android/server/hans/oguard/analyzer/AppAnalyzer;
.source "AppWakelockAnalyzer.java"


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private mAudioPlayingDuraton:J

.field private mAudioRecordingDuraton:J

.field private volatile mHighThreshold:J

.field private volatile mSeriousThreshold:J

.field private volatile mSpecThreshold:J

.field private volatile mValue:F


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 16
    const-class v0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 25
    invoke-direct {p0}, Lcom/android/server/hans/oguard/analyzer/AppAnalyzer;-><init>()V

    .line 17
    const-wide/32 v0, 0x493e0

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHighThreshold:J

    .line 18
    const-wide/32 v0, 0x927c0

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSeriousThreshold:J

    .line 19
    const-wide/32 v0, 0x124f80

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecThreshold:J

    .line 20
    const v0, 0x3ecccccd    # 0.4f

    iput v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mValue:F

    .line 21
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioPlayingDuraton:J

    .line 22
    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioRecordingDuraton:J

    .line 26
    return-void
.end method

.method private aggAudioWakelockTime(Lcom/android/server/hans/oguard/AppPowerRecord;)V
    .registers 8
    .param p1, "record"    # Lcom/android/server/hans/oguard/AppPowerRecord;

    .line 42
    iget v0, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mImportance:I

    and-int/lit16 v0, v0, 0x100

    if-nez v0, :cond_7

    .line 43
    return-void

    .line 46
    :cond_7
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_8
    iget-object v1, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockTagList:Landroid/util/ArrayMap;

    invoke-virtual {v1}, Landroid/util/ArrayMap;->size()I

    move-result v1

    if-ge v0, v1, :cond_46

    .line 47
    iget-object v1, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockTagList:Landroid/util/ArrayMap;

    invoke-virtual {v1, v0}, Landroid/util/ArrayMap;->keyAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 48
    .local v1, "wlTag":Ljava/lang/String;
    iget-object v2, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockTagList:Landroid/util/ArrayMap;

    invoke-virtual {v2, v0}, Landroid/util/ArrayMap;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    .line 49
    .local v2, "wlDuration":J
    invoke-static {}, Lcom/android/server/hans/oguard/OGuardDBConfig;->getInstance()Lcom/android/server/hans/oguard/OGuardDBConfig;

    move-result-object v4

    invoke-virtual {v4, v1}, Lcom/android/server/hans/oguard/OGuardDBConfig;->isAudioPlayingTag(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_34

    .line 50
    iget-wide v4, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioPlayingWLTime:J

    add-long/2addr v4, v2

    iput-wide v4, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioPlayingWLTime:J

    goto :goto_43

    .line 51
    :cond_34
    invoke-static {}, Lcom/android/server/hans/oguard/OGuardDBConfig;->getInstance()Lcom/android/server/hans/oguard/OGuardDBConfig;

    move-result-object v4

    invoke-virtual {v4, v1}, Lcom/android/server/hans/oguard/OGuardDBConfig;->isAudioRecordTag(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_43

    .line 52
    iget-wide v4, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioRecordingWLTime:J

    add-long/2addr v4, v2

    iput-wide v4, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioRecordingWLTime:J

    .line 46
    .end local v1    # "wlTag":Ljava/lang/String;
    .end local v2    # "wlDuration":J
    :cond_43
    :goto_43
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 55
    .end local v0    # "i":I
    :cond_46
    return-void
.end method

.method private getAbnormalLevel()I
    .registers 5

    .line 119
    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSeriousThreshold:J

    cmp-long v0, v0, v2

    if-ltz v0, :cond_a

    .line 120
    const/4 v0, 0x2

    return v0

    .line 122
    :cond_a
    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHighThreshold:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_39

    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecHoldDuration:J

    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecThreshold:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_39

    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mStatsDuration:J

    const-wide/32 v2, 0x1b7740

    cmp-long v0, v0, v2

    if-ltz v0, :cond_37

    const-wide/16 v0, 0x64

    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecHoldDuration:J

    mul-long/2addr v2, v0

    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mStatsDuration:J

    div-long/2addr v2, v0

    iget v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mValue:F

    const/high16 v1, 0x42c80000    # 100.0f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    int-to-long v0, v0

    cmp-long v0, v2, v0

    if-ltz v0, :cond_37

    goto :goto_39

    .line 127
    :cond_37
    const/4 v0, 0x0

    return v0

    .line 125
    :cond_39
    :goto_39
    const/4 v0, 0x1

    return v0
.end method

.method private protectAppType()Z
    .registers 3

    .line 167
    const/4 v0, 0x7

    iget v1, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAppType:I

    if-eq v0, v1, :cond_e

    const/16 v0, 0xb

    iget v1, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAppType:I

    if-ne v0, v1, :cond_c

    goto :goto_e

    .line 171
    :cond_c
    const/4 v0, 0x0

    return v0

    .line 169
    :cond_e
    :goto_e
    const/4 v0, 0x1

    return v0
.end method


# virtual methods
.method protected getKillsPolicy(I)I
    .registers 9
    .param p1, "level"    # I

    .line 145
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mScrOn:Z

    const-wide/32 v1, 0x36ee80

    const/4 v3, 0x1

    if-nez v0, :cond_3a

    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isScreenOff()Z

    move-result v0

    if-eqz v0, :cond_3a

    .line 146
    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v0

    iget v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    iget-object v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    const-string v6, "INPUT"

    invoke-virtual {v0, v4, v5, v6}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isDefaultApp(ILjava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_29

    .line 147
    iget-wide v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    cmp-long v0, v4, v1

    if-ltz v0, :cond_29

    .line 148
    return v3

    .line 151
    :cond_29
    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v0

    iget v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    iget-object v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    const-string v6, "SMS"

    invoke-virtual {v0, v4, v5, v6}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isDefaultApp(ILjava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3a

    .line 152
    return v3

    .line 155
    :cond_3a
    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v0

    iget v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    iget-object v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    iget v6, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAppType:I

    invoke-virtual {v0, v4, v5, v6}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isClockApp(ILjava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_87

    .line 156
    iget-wide v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    cmp-long v0, v4, v1

    if-ltz v0, :cond_87

    .line 157
    invoke-static {}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->getInstance()Lcom/android/server/hans/oguard/logger/OGuardLogger;

    move-result-object v0

    sget-object v1, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "clock-app  "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " / "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ", hold wakelock "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    return v3

    .line 161
    :cond_87
    const/4 v0, 0x2

    return v0
.end method

.method protected getRemindPolicy()I
    .registers 5

    .line 132
    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    const-wide/32 v2, 0x36ee80

    cmp-long v0, v0, v2

    if-ltz v0, :cond_19

    const-wide/16 v0, 0x64

    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    mul-long/2addr v2, v0

    iget-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mStatsDuration:J

    div-long/2addr v2, v0

    const-wide/16 v0, 0x19

    cmp-long v0, v2, v0

    if-ltz v0, :cond_19

    .line 133
    const/4 v0, 0x2

    return v0

    .line 135
    :cond_19
    const/4 v0, 0x5

    return v0
.end method

.method protected getRestrictOffset()I
    .registers 2

    .line 140
    const/4 v0, 0x4

    return v0
.end method

.method protected initStatsInfo(Lcom/android/server/hans/oguard/AppPowerRecord;)V
    .registers 6
    .param p1, "record"    # Lcom/android/server/hans/oguard/AppPowerRecord;

    .line 30
    iget-object v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mRecord:Lcom/android/server/hans/oguard/AppPowerRecord;

    if-eqz v0, :cond_1d

    .line 31
    iget-wide v0, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockTime:J

    iget-wide v2, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockFilterTime:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHoldDuration:J

    .line 32
    iget-wide v0, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mSpecWakelockTime:J

    iget-wide v2, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mWakelockFilterTime:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecHoldDuration:J

    .line 34
    invoke-direct {p0, p1}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->aggAudioWakelockTime(Lcom/android/server/hans/oguard/AppPowerRecord;)V

    .line 35
    iget-wide v0, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioPlayingWLTime:J

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioPlayingDuraton:J

    .line 36
    iget-wide v0, p1, Lcom/android/server/hans/oguard/AppPowerRecord;->mAudioRecordingWLTime:J

    iput-wide v0, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioRecordingDuraton:J

    .line 38
    :cond_1d
    return-void
.end method

.method public startAppAnalyzer()I
    .registers 14

    .line 60
    invoke-virtual {p0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->isCtrlScope()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_148

    const-string/jumbo v0, "wakelock"

    invoke-virtual {p0, v0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->analyzerEnable(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_12

    goto/16 :goto_148

    .line 63
    :cond_12
    iget-wide v2, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mStatsDuration:J

    invoke-virtual {p0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getMinStatsDuration()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-gez v2, :cond_1d

    .line 64
    return v1

    .line 66
    :cond_1d
    invoke-virtual {p0, v0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getResourceThreshold(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v2

    .line 67
    .local v2, "threshold":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;"
    invoke-virtual {p0, v0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getResourceSpecThreshold(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    .line 68
    .local v0, "specThreshold":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/Float;>;"
    const-wide/16 v3, 0x3e8

    if-eqz v2, :cond_41

    .line 69
    iget-object v5, v2, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    int-to-long v5, v5

    mul-long/2addr v5, v3

    iput-wide v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mHighThreshold:J

    .line 70
    iget-object v5, v2, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    int-to-long v5, v5

    mul-long/2addr v5, v3

    iput-wide v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSeriousThreshold:J

    .line 72
    :cond_41
    if-eqz v0, :cond_59

    .line 73
    iget-object v5, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    int-to-long v5, v5

    mul-long/2addr v5, v3

    iput-wide v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mSpecThreshold:J

    .line 74
    iget-object v3, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Float;

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    iput v3, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mValue:F

    .line 77
    :cond_59
    iget v3, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mImportance:I

    const/16 v4, 0x100

    if-lt v3, v4, :cond_98

    .line 78
    iget v3, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mImportance:I

    and-int/2addr v3, v4

    if-eqz v3, :cond_98

    .line 79
    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v5

    iget v6, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    iget-object v7, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    iget v8, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAppType:I

    iget-wide v9, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioPlayingDuraton:J

    iget-wide v11, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mAudioRecordingDuraton:J

    invoke-virtual/range {v5 .. v12}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isValidAudio(ILjava/lang/String;IJJ)Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;

    move-result-object v3

    .line 80
    .local v3, "audioResult":Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;
    sget-object v5, Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;->ABNORMAL_AUDIO_OUT_BEHAVIOR:Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;

    const/4 v6, 0x1

    if-ne v3, v5, :cond_83

    .line 81
    iget-object v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mRecord:Lcom/android/server/hans/oguard/AppPowerRecord;

    invoke-virtual {v4, v1, v6}, Lcom/android/server/hans/oguard/AppPowerRecord;->clearImpCaseData(ZZ)V

    .line 82
    const/16 v1, 0xc

    return v1

    .line 83
    :cond_83
    sget-object v5, Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;->ABNORMAL_AUDIO_IN_BEHAVIOR:Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;

    if-ne v3, v5, :cond_8f

    .line 84
    iget-object v4, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mRecord:Lcom/android/server/hans/oguard/AppPowerRecord;

    invoke-virtual {v4, v1, v6}, Lcom/android/server/hans/oguard/AppPowerRecord;->clearImpCaseData(ZZ)V

    .line 85
    const/16 v1, 0xd

    return v1

    .line 86
    :cond_8f
    sget-object v5, Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;->NORMAL_BEHAVIOR:Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;

    if-ne v3, v5, :cond_98

    .line 87
    iget-object v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mRecord:Lcom/android/server/hans/oguard/AppPowerRecord;

    invoke-virtual {v5, v1, v6}, Lcom/android/server/hans/oguard/AppPowerRecord;->clearImpCaseData(ZZ)V

    .line 92
    .end local v3    # "audioResult":Lcom/android/server/hans/oguard/policy/AppPowerImportance$ValidAudioResult;
    :cond_98
    invoke-direct {p0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getAbnormalLevel()I

    move-result v3

    .line 93
    .local v3, "abnormalLevel":I
    invoke-virtual {p0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getRestrictLevel()I

    move-result v5

    if-gt v3, v5, :cond_a3

    .line 94
    return v1

    .line 96
    :cond_a3
    iget v1, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mImportance:I

    if-lt v1, v4, :cond_c9

    .line 97
    invoke-static {}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->getInstance()Lcom/android/server/hans/oguard/logger/OGuardLogger;

    move-result-object v1

    sget-object v4, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "importanceActive, feedBack: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v4, v5}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->fullLog(Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    const/16 v1, 0xa

    return v1

    .line 100
    :cond_c9
    const/16 v1, 0x8

    invoke-virtual {p0, v1}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->inWhiteList(I)Z

    move-result v4

    const/16 v5, 0x16

    if-eqz v4, :cond_d4

    .line 101
    return v5

    .line 104
    :cond_d4
    invoke-direct {p0}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->protectAppType()Z

    move-result v4

    const-string v6, " / "

    if-eqz v4, :cond_106

    .line 105
    invoke-static {}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->getInstance()Lcom/android/server/hans/oguard/logger/OGuardLogger;

    move-result-object v1

    sget-object v4, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->TAG:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "skip protect app "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v4, v6}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 106
    return v5

    .line 109
    :cond_106
    invoke-static {}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->getInstance()Lcom/android/server/hans/oguard/policy/AppPowerImportance;

    move-result-object v4

    iget v5, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    iget-object v7, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    invoke-virtual {v4, v5, v7}, Lcom/android/server/hans/oguard/policy/AppPowerImportance;->isImportanceOsApp(ILjava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_140

    .line 110
    invoke-static {}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->getInstance()Lcom/android/server/hans/oguard/logger/OGuardLogger;

    move-result-object v1

    sget-object v4, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "skip important os app "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v7, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mUid:I

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->mPkgName:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v4, v5}, Lcom/android/server/hans/oguard/logger/OGuardLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    const/16 v1, 0x18

    return v1

    .line 114
    :cond_140
    invoke-virtual {p0, v3}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->setRestrictLevel(I)V

    .line 115
    invoke-virtual {p0, v3, v1}, Lcom/android/server/hans/oguard/analyzer/AppWakelockAnalyzer;->getGradingPolicy(II)I

    move-result v1

    return v1

    .line 61
    .end local v0    # "specThreshold":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/Float;>;"
    .end local v2    # "threshold":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;"
    .end local v3    # "abnormalLevel":I
    :cond_148
    :goto_148
    return v1
.end method
