.class Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "PocketProxToken"
.end annotation


# instance fields
.field public mToken:Landroid/os/IBinder;

.field final synthetic this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;


# direct methods
.method public constructor <init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Landroid/os/IBinder;)V
    .registers 3
    .param p2, "token"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 591
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 592
    iput-object p2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    .line 593
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->linkToDeath()V

    .line 594
    return-void
.end method

.method private linkToDeath()V
    .registers 4

    .line 623
    :try_start_0
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    const/4 v1, 0x0

    invoke-interface {v0, p0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_6} :catch_8

    .line 626
    nop

    .line 627
    return-void

    .line 624
    :catch_8
    move-exception v0

    .line 625
    .local v0, "e":Landroid/os/RemoteException;
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "PocketProxToken.mToken is already dead."

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public binderDied()V
    .registers 3

    .line 598
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "binder die token = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusProximitySensorScreenOnOff"

    invoke-static {v1, v0}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 599
    invoke-virtual {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->unlinkToDeath()V

    .line 600
    return-void
.end method

.method public unlinkToDeath()V
    .registers 6

    .line 603
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPocketEnableLock(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 604
    :try_start_7
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z

    move-result v1

    .line 605
    .local v1, "oldenable":Z
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fputmPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V

    .line 606
    if-eqz v1, :cond_31

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmCurrentProximityEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z

    move-result v2

    if-eqz v2, :cond_31

    .line 607
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmCurrentProximity(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I

    move-result v2

    const/4 v4, 0x1

    if-ne v2, v4, :cond_2c

    .line 608
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2, v4}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fputmPendingPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V

    goto :goto_31

    .line 610
    :cond_2c
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$mchangeSensor(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    .line 613
    :cond_31
    :goto_31
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    invoke-static {v2, v4}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$mfindIndexPocketToken(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Landroid/os/IBinder;)I

    move-result v2

    .line 614
    .local v2, "index":I
    if-ltz v2, :cond_44

    .line 615
    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v4}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPocketProxEnableTokens(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 617
    .end local v1    # "oldenable":Z
    .end local v2    # "index":I
    :cond_44
    monitor-exit v0
    :try_end_45
    .catchall {:try_start_7 .. :try_end_45} :catchall_4b

    .line 618
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    invoke-interface {v0, p0, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    .line 619
    return-void

    .line 617
    :catchall_4b
    move-exception v1

    :try_start_4c
    monitor-exit v0
    :try_end_4d
    .catchall {:try_start_4c .. :try_end_4d} :catchall_4b

    throw v1
.end method
