.class Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;
.super Ljava/lang/Thread;
.source "OplusHansWatchDog.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/OplusHansWatchDog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "HansWatchdogThread"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/hans/OplusHansWatchDog;


# direct methods
.method constructor <init>(Lcom/android/server/hans/OplusHansWatchDog;)V
    .registers 2
    .param p1, "this$0"    # Lcom/android/server/hans/OplusHansWatchDog;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 232
    iput-object p1, p0, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 235
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    invoke-static {v0}, Lcom/android/server/hans/OplusHansWatchDog;->-$$Nest$mrunCheck(Lcom/android/server/hans/OplusHansWatchDog;)V

    .line 236
    return-void
.end method
