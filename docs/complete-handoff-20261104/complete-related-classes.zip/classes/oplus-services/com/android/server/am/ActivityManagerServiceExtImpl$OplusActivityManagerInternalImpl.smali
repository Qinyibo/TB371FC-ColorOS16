.class Lcom/android/server/am/ActivityManagerServiceExtImpl$OplusActivityManagerInternalImpl;
.super Landroid/app/OplusActivityManagerInternal;
.source "ActivityManagerServiceExtImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/am/ActivityManagerServiceExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "OplusActivityManagerInternalImpl"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/am/ActivityManagerServiceExtImpl;


# direct methods
.method private constructor <init>(Lcom/android/server/am/ActivityManagerServiceExtImpl;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 738
    iput-object p1, p0, Lcom/android/server/am/ActivityManagerServiceExtImpl$OplusActivityManagerInternalImpl;->this$0:Lcom/android/server/am/ActivityManagerServiceExtImpl;

    invoke-direct {p0}, Landroid/app/OplusActivityManagerInternal;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/server/am/ActivityManagerServiceExtImpl;Lcom/android/server/am/ActivityManagerServiceExtImpl-IA;)V
    .registers 3

    invoke-direct {p0, p1}, Lcom/android/server/am/ActivityManagerServiceExtImpl$OplusActivityManagerInternalImpl;-><init>(Lcom/android/server/am/ActivityManagerServiceExtImpl;)V

    return-void
.end method


# virtual methods
.method public startActivityAsUserEmpty(Landroid/os/Bundle;)I
    .registers 3
    .param p1, "options"    # Landroid/os/Bundle;

    .line 744
    iget-object v0, p0, Lcom/android/server/am/ActivityManagerServiceExtImpl$OplusActivityManagerInternalImpl;->this$0:Lcom/android/server/am/ActivityManagerServiceExtImpl;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerServiceExtImpl;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ActivityManagerService;->startActivityAsUserEmpty(Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method
