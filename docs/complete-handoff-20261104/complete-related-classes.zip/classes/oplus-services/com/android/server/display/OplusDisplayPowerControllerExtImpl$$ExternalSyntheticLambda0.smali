.class public final synthetic Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method public synthetic constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$$ExternalSyntheticLambda0;->f$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$$ExternalSyntheticLambda0;->f$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->$r8$lambda$FTfMT7MOD-gY3tYEnoLa_b6xl8E(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V

    return-void
.end method
