.class public Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
.super Landroid/app/IRfcommOemManager$Stub;
.source "RfcommOemManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$NamedThreadFactory;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private final mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

.field private final mContext:Landroid/content/Context;

.field private final mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

.field private final mServerMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/util/Pair<",
            "Ljava/util/UUID;",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;",
            ">;"
        }
    .end annotation
.end field

.field private final mSessionMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;",
            ">;"
        }
    .end annotation
.end field

.field private final mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;


# direct methods
.method static bridge synthetic -$$Nest$fgetmServerMap(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mmanageBluetoothDisconnected(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->manageBluetoothDisconnected()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmanageBluetoothReconnected(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->manageBluetoothReconnected()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveRfcommServerData(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->removeRfcommServerData(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetTAG()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 1

    .line 61
    const-class v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 12
    .param p1, "context"    # Landroid/content/Context;

    .line 72
    invoke-direct {p0}, Landroid/app/IRfcommOemManager$Stub;-><init>()V

    .line 73
    iput-object p1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    .line 74
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    .line 75
    const-string v1, "bluetooth"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/BluetoothManager;

    .line 76
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    .line 77
    new-instance v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    invoke-direct {v0, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    .line 79
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    .line 80
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    .line 81
    new-instance v1, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v7, Ljava/util/concurrent/SynchronousQueue;

    invoke-direct {v7}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    new-instance v8, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$NamedThreadFactory;

    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    invoke-direct {v8, v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$NamedThreadFactory;-><init>(Ljava/lang/String;)V

    new-instance v9, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;

    invoke-direct {v9}, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-wide/16 v4, 0xa

    invoke-direct/range {v1 .. v9}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    iput-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 84
    invoke-direct {p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->retrieveRfCommServersData()V

    .line 86
    invoke-direct {p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->registerReceiverInner()V

    .line 87
    return-void
.end method

.method private addRfcommServerData(Ljava/lang/Integer;Ljava/lang/String;)V
    .registers 6
    .param p1, "appUID"    # Ljava/lang/Integer;
    .param p2, "uuidString"    # Ljava/lang/String;

    .line 448
    :try_start_0
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    invoke-virtual {v0, p2, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;->saveUUID(Ljava/lang/String;Ljava/lang/Integer;)V
    :try_end_5
    .catchall {:try_start_0 .. :try_end_5} :catchall_6

    .line 451
    goto :goto_e

    .line 449
    :catchall_6
    move-exception v0

    .line 450
    .local v0, "ex":Ljava/lang/Throwable;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransfer: Couldn\'t save Rfcomm Server to shared preferences"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 452
    .end local v0    # "ex":Ljava/lang/Throwable;
    :goto_e
    return-void
.end method

.method private isValidAppUid(I)Z
    .registers 3
    .param p1, "appUid"    # I

    .line 480
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageManager;->getNameForUid(I)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method private declared-synchronized manageBluetoothDisconnected()V
    .registers 7

    monitor-enter p0

    .line 393
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_33

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 394
    .local v1, "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :try_end_1d
    .catchall {:try_start_1 .. :try_end_1d} :catchall_67

    .line 396
    .local v2, "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    if-eqz v2, :cond_2c

    .line 397
    :try_start_1f
    invoke-virtual {v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit()V
    :try_end_22
    .catch Ljava/io/IOException; {:try_start_1f .. :try_end_22} :catch_23
    .catchall {:try_start_1f .. :try_end_22} :catchall_67

    goto :goto_2c

    .line 399
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_23
    move-exception v3

    .line 400
    .local v3, "e":Ljava/io/IOException;
    :try_start_24
    sget-object v4, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v5, "BluetoothTransfer: Socket is already closed"

    invoke-static {v4, v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_2d

    .line 401
    .end local v3    # "e":Ljava/io/IOException;
    :cond_2c
    :goto_2c
    nop

    .line 402
    :goto_2d
    const/4 v3, 0x0

    invoke-interface {v1, v3}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    nop

    .end local v1    # "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    .end local v2    # "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    goto :goto_b

    .line 406
    :cond_33
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 407
    .local v0, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;>;"
    :goto_3d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_65

    .line 408
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;
    :try_end_49
    .catchall {:try_start_24 .. :try_end_49} :catchall_67

    .line 410
    .local v1, "session":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;"
    :try_start_49
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_58

    .line 411
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    invoke-virtual {v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit()V
    :try_end_58
    .catch Ljava/io/IOException; {:try_start_49 .. :try_end_58} :catch_59
    .catchall {:try_start_49 .. :try_end_58} :catchall_67

    .line 415
    :cond_58
    goto :goto_61

    .line 413
    :catch_59
    move-exception v2

    .line 414
    .local v2, "e":Ljava/io/IOException;
    :try_start_5a
    sget-object v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v4, "BluetoothTransfer: Socket is already closed"

    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 417
    .end local v2    # "e":Ljava/io/IOException;
    :goto_61
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V
    :try_end_64
    .catchall {:try_start_5a .. :try_end_64} :catchall_67

    .line 418
    .end local v1    # "session":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;"
    goto :goto_3d

    .line 419
    :cond_65
    monitor-exit p0

    return-void

    .line 392
    .end local v0    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;>;"
    :catchall_67
    move-exception v0

    :try_start_68
    monitor-exit p0
    :try_end_69
    .catchall {:try_start_68 .. :try_end_69} :catchall_67

    throw v0
.end method

.method private declared-synchronized manageBluetoothReconnected()V
    .registers 10

    monitor-enter p0

    .line 423
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_96

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 424
    .local v1, "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_70

    .line 425
    new-instance v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;

    .line 427
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/util/Pair;

    iget-object v2, v2, Landroid/util/Pair;->first:Ljava/lang/Object;

    move-object v4, v2

    check-cast v4, Ljava/util/UUID;

    .line 428
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/util/Pair;

    iget-object v2, v2, Landroid/util/Pair;->second:Ljava/lang/Object;

    move-object v5, v2

    check-cast v5, Ljava/lang/Integer;

    sget-object v6, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    iget-object v7, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;
    :try_end_39
    .catchall {:try_start_1 .. :try_end_39} :catchall_99

    move-object v8, p0

    :try_start_3a
    invoke-direct/range {v3 .. v8}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;-><init>(Ljava/util/UUID;Ljava/lang/Integer;Ljava/lang/String;Landroid/bluetooth/BluetoothAdapter;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V

    .line 432
    .local v3, "serverRunnable":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    invoke-virtual {v3}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->startListen()Z

    move-result v2

    if-nez v2, :cond_67

    .line 433
    sget-object v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "rfcomm start listen failed, server = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 434
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/util/Pair;

    invoke-virtual {v5}, Landroid/util/Pair;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 433
    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 435
    goto :goto_b

    .line 437
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :cond_67
    invoke-interface {v1, v3}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    .line 438
    iget-object v2, v8, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 439
    .end local v3    # "serverRunnable":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    goto :goto_94

    .line 440
    :cond_70
    move-object v8, p0

    sget-object v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "manageBluetoothReconnected server.value is not null "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 441
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/util/Pair;

    invoke-virtual {v4}, Landroid/util/Pair;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 440
    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_94
    .catchall {:try_start_3a .. :try_end_94} :catchall_9d

    .line 443
    .end local v1    # "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    :goto_94
    goto/16 :goto_b

    .line 444
    :cond_96
    move-object v8, p0

    monitor-exit p0

    return-void

    .line 422
    :catchall_99
    move-exception v0

    move-object v8, p0

    :goto_9b
    :try_start_9b
    monitor-exit p0
    :try_end_9c
    .catchall {:try_start_9b .. :try_end_9c} :catchall_9d

    throw v0

    :catchall_9d
    move-exception v0

    goto :goto_9b
.end method

.method private registerReceiverInner()V
    .registers 6

    .line 91
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.bluetooth.adapter.action.STATE_CHANGED"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 93
    .local v0, "bluetoothStateChangeFilter":Landroid/content/IntentFilter;
    new-instance v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$1;

    invoke-direct {v1, p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$1;-><init>(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V

    .line 114
    .local v1, "bluetoothStateChangedReceiver":Landroid/content/BroadcastReceiver;
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    invoke-virtual {v2, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 117
    new-instance v2, Landroid/content/IntentFilter;

    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    .line 118
    .local v2, "packageStateChangeFilter":Landroid/content/IntentFilter;
    const-string/jumbo v3, "package"

    invoke-virtual {v2, v3}, Landroid/content/IntentFilter;->addDataScheme(Ljava/lang/String;)V

    .line 119
    const-string v3, "android.intent.action.PACKAGE_FULLY_REMOVED"

    invoke-virtual {v2, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 121
    new-instance v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;

    invoke-direct {v3, p0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;-><init>(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V

    .line 153
    .local v3, "packageStateChangedReceiver":Landroid/content/BroadcastReceiver;
    iget-object v4, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    invoke-virtual {v4, v3, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 154
    return-void
.end method

.method private removeRfcommServerData(Ljava/lang/String;)V
    .registers 5
    .param p1, "uuidString"    # Ljava/lang/String;

    .line 456
    :try_start_0
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    invoke-virtual {v0, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;->removeUUID(Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_0 .. :try_end_5} :catchall_6

    .line 459
    goto :goto_e

    .line 457
    :catchall_6
    move-exception v0

    .line 458
    .local v0, "ex":Ljava/lang/Throwable;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransfer: Couldn\'t remove Rfcomm Server from shared preferences"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 460
    .end local v0    # "ex":Ljava/lang/Throwable;
    :goto_e
    return-void
.end method

.method private retrieveRfCommServersData()V
    .registers 8

    .line 464
    :try_start_0
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;->getAll()Ljava/util/Map;

    move-result-object v0

    .line 465
    .local v0, "savedServersData":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;*>;"
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_49

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 466
    .local v2, "uuid":Ljava/lang/String;
    iget-object v3, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mRfcommPersistDataHelper:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;

    const/4 v4, -0x1

    invoke-virtual {v3, v2, v4}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommPersistDataHelper;->getAppUidByUUID(Ljava/lang/String;I)I

    move-result v3

    .line 467
    .local v3, "appUID":I
    if-eq v3, v4, :cond_2d

    invoke-direct {p0, v3}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->isValidAppUid(I)Z

    move-result v4

    if-eqz v4, :cond_2d

    .line 468
    invoke-virtual {p0, v3, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->enableRfComm(ILjava/lang/String;)Z

    goto :goto_48

    .line 470
    :cond_2d
    sget-object v4, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Not a valid retrieve RfCommServer: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 471
    invoke-direct {p0, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->removeRfcommServerData(Ljava/lang/String;)V
    :try_end_48
    .catchall {:try_start_0 .. :try_end_48} :catchall_4a

    .line 473
    .end local v2    # "uuid":Ljava/lang/String;
    .end local v3    # "appUID":I
    :goto_48
    goto :goto_e

    .line 476
    .end local v0    # "savedServersData":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;*>;"
    :cond_49
    goto :goto_52

    .line 474
    :catchall_4a
    move-exception v0

    .line 475
    .local v0, "ex":Ljava/lang/Throwable;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransfer: Couldn\'t load Rfcomm Servers from shared preferences"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 477
    .end local v0    # "ex":Ljava/lang/Throwable;
    :goto_52
    return-void
.end method

.method private sendRfcommBroadcast(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V
    .registers 11
    .param p1, "macAddress"    # Ljava/lang/String;
    .param p2, "remoteDeviceName"    # Ljava/lang/String;
    .param p3, "appUID"    # Ljava/lang/Integer;
    .param p4, "broadcastAction"    # Ljava/lang/String;

    .line 370
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v0

    .line 372
    .local v0, "packages":[Ljava/lang/String;
    if-eqz v0, :cond_62

    array-length v1, v0

    if-lez v1, :cond_62

    .line 373
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 374
    .local v1, "intent":Landroid/content/Intent;
    const/16 v2, 0x20

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 375
    const/high16 v2, 0x1000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 377
    const-string v2, "deviceintegration:rfcomm.extra.MACADDRESS"

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 378
    const-string v2, "deviceintegration:rfcomm.extra.NAME"

    invoke-virtual {v1, v2, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 380
    invoke-virtual {v1, p4}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 381
    const/4 v2, 0x0

    aget-object v3, v0, v2

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 383
    sget-object v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "BluetoothTransfer: send \""

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    aget-object v2, v0, v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "\" - "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 385
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    sget-object v3, Landroid/os/UserHandle;->ALL:Landroid/os/UserHandle;

    const-string v4, "deviceintegration.permission.BLUETOOTH_TRANSPORT_EVENT"

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Context;->sendBroadcastAsUser(Landroid/content/Intent;Landroid/os/UserHandle;Ljava/lang/String;)V

    .line 389
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_62
    return-void
.end method


# virtual methods
.method public declared-synchronized closeAllConnections(I)Z
    .registers 6
    .param p1, "appUID"    # I

    monitor-enter p0

    .line 283
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 284
    .local v0, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;>;"
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    .line 285
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 286
    .local v1, "session":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_42

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    invoke-virtual {v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->getAppUID()Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_2f
    .catchall {:try_start_1 .. :try_end_2f} :catchall_46

    if-eqz v2, :cond_42

    .line 288
    :try_start_31
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    invoke-virtual {v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit()V

    .line 289
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V
    :try_end_3d
    .catch Ljava/io/IOException; {:try_start_31 .. :try_end_3d} :catch_3e
    .catchall {:try_start_31 .. :try_end_3d} :catchall_46

    .line 292
    goto :goto_42

    .line 290
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_3e
    move-exception v2

    .line 291
    .local v2, "e":Ljava/io/IOException;
    monitor-exit p0

    const/4 v3, 0x0

    return v3

    .line 294
    .end local v1    # "session":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;"
    .end local v2    # "e":Ljava/io/IOException;
    :cond_42
    :goto_42
    goto :goto_b

    .line 295
    :cond_43
    monitor-exit p0

    const/4 v1, 0x1

    return v1

    .line 282
    .end local v0    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Ljava/lang/String;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;>;>;"
    .end local p1    # "appUID":I
    :catchall_46
    move-exception p1

    :try_start_47
    monitor-exit p0
    :try_end_48
    .catchall {:try_start_47 .. :try_end_48} :catchall_46

    throw p1
.end method

.method public declared-synchronized closeClientConnections(ILjava/lang/String;)Z
    .registers 7
    .param p1, "appUID"    # I
    .param p2, "macAddress"    # Ljava/lang/String;

    monitor-enter p0

    .line 300
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_34

    const/4 v1, 0x0

    if-nez v0, :cond_c

    .line 301
    monitor-exit p0

    return v1

    .line 303
    :cond_c
    :try_start_c
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    .line 304
    .local v0, "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    if-eqz v0, :cond_32

    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->getAppUID()Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_22
    .catchall {:try_start_c .. :try_end_22} :catchall_34

    if-eqz v2, :cond_32

    .line 306
    :try_start_24
    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit()V

    .line 307
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v2, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2c
    .catch Ljava/io/IOException; {:try_start_24 .. :try_end_2c} :catch_2f
    .catchall {:try_start_24 .. :try_end_2c} :catchall_34

    .line 308
    monitor-exit p0

    const/4 v1, 0x1

    return v1

    .line 309
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_2f
    move-exception v2

    .line 310
    .local v2, "e":Ljava/io/IOException;
    monitor-exit p0

    return v1

    .line 313
    .end local v2    # "e":Ljava/io/IOException;
    :cond_32
    monitor-exit p0

    return v1

    .line 299
    .end local v0    # "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    .end local p1    # "appUID":I
    .end local p2    # "macAddress":Ljava/lang/String;
    :catchall_34
    move-exception p1

    :try_start_35
    monitor-exit p0
    :try_end_36
    .catchall {:try_start_35 .. :try_end_36} :catchall_34

    throw p1
.end method

.method public declared-synchronized disableRfComm(ILjava/lang/String;)Z
    .registers 8
    .param p1, "appUID"    # I
    .param p2, "uuidString"    # Ljava/lang/String;

    monitor-enter p0

    .line 234
    :try_start_1
    new-instance v0, Landroid/util/Pair;

    invoke-static {p2}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 235
    .local v0, "keyPair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_37

    .line 236
    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :try_end_1e
    .catchall {:try_start_1 .. :try_end_1e} :catchall_3a

    .line 237
    .local v1, "server":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    if-eqz v1, :cond_2c

    .line 239
    :try_start_20
    invoke-virtual {v1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit()V
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_20 .. :try_end_23} :catch_24
    .catchall {:try_start_20 .. :try_end_23} :catchall_3a

    .line 242
    goto :goto_2c

    .line 240
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_24
    move-exception v2

    .line 241
    .local v2, "e":Ljava/io/IOException;
    :try_start_25
    sget-object v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v4, "BluetoothTransfer: Socket is already closed, nothing to do"

    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 244
    .end local v2    # "e":Ljava/io/IOException;
    :cond_2c
    :goto_2c
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v2, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 245
    invoke-direct {p0, p2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->removeRfcommServerData(Ljava/lang/String;)V
    :try_end_34
    .catchall {:try_start_25 .. :try_end_34} :catchall_3a

    .line 246
    monitor-exit p0

    const/4 v2, 0x1

    return v2

    .line 248
    .end local v1    # "server":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :cond_37
    monitor-exit p0

    const/4 v1, 0x0

    return v1

    .line 233
    .end local v0    # "keyPair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;"
    .end local p1    # "appUID":I
    .end local p2    # "uuidString":Ljava/lang/String;
    :catchall_3a
    move-exception p1

    :try_start_3b
    monitor-exit p0
    :try_end_3c
    .catchall {:try_start_3b .. :try_end_3c} :catchall_3a

    throw p1
.end method

.method public declared-synchronized enableRfComm(ILjava/lang/String;)Z
    .registers 19
    .param p1, "appUID"    # I
    .param p2, "uuidString"    # Ljava/lang/String;

    move-object/from16 v5, p0

    move-object/from16 v6, p2

    monitor-enter p0

    .line 158
    const/4 v7, 0x0

    if-eqz v6, :cond_10f

    :try_start_8
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    if-nez v0, :cond_e

    goto/16 :goto_10f

    .line 161
    :cond_e
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mContext:Landroid/content/Context;

    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_21

    .line 163
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v1, "caller does not have BLUETOOTH_CONNECT permission"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1f
    .catchall {:try_start_8 .. :try_end_1f} :catchall_10c

    .line 164
    monitor-exit p0

    return v7

    .line 167
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :cond_21
    :try_start_21
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0
    :try_end_25
    .catchall {:try_start_21 .. :try_end_25} :catchall_10c

    move-wide v8, v0

    .line 169
    .local v8, "identity":J
    :try_start_26
    new-instance v0, Landroid/util/Pair;

    invoke-static {v6}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v1

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v10, v0

    .line 171
    .local v10, "keyPair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;"
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    const/4 v1, 0x0

    invoke-interface {v0, v10, v1}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x1

    if-nez v0, :cond_101

    .line 175
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v12, v0

    .line 176
    .local v12, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;>;"
    :goto_49
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_b8

    .line 177
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    move-object v2, v0

    .line 178
    .local v2, "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/util/UUID;

    move-object v3, v0

    .line 179
    .local v3, "existingUUID":Ljava/util/UUID;
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    move-object v4, v0

    .line 181
    .local v4, "existingAppUid":Ljava/lang/Integer;
    invoke-static {v6}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b7

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b7

    .line 183
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-direct {v5, v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->isValidAppUid(I)Z

    move-result v0

    if-nez v0, :cond_aa

    .line 184
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :try_end_90
    .catchall {:try_start_26 .. :try_end_90} :catchall_107

    move-object v13, v0

    .line 185
    .local v13, "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    if-eqz v13, :cond_9f

    .line 187
    :try_start_93
    invoke-virtual {v13}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit()V
    :try_end_96
    .catch Ljava/io/IOException; {:try_start_93 .. :try_end_96} :catch_97
    .catchall {:try_start_93 .. :try_end_96} :catchall_107

    .line 190
    goto :goto_9f

    .line 188
    :catch_97
    move-exception v0

    .line 189
    .local v0, "e":Ljava/io/IOException;
    :try_start_98
    sget-object v14, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v15, "BluetoothTransfer: Socket is already closed, nothing to do"

    invoke-static {v14, v15, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 192
    .end local v0    # "e":Ljava/io/IOException;
    :cond_9f
    :goto_9f
    invoke-interface {v12}, Ljava/util/Iterator;->remove()V

    .line 193
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->removeRfcommServerData(Ljava/lang/String;)V

    .line 194
    .end local v13    # "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    goto :goto_b7

    .line 195
    :cond_aa
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v1, "BluetoothTransfer: Found an existing UUID for another app id"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_b1
    .catchall {:try_start_98 .. :try_end_b1} :catchall_107

    .line 196
    nop

    .line 228
    :try_start_b2
    invoke-static {v8, v9}, Landroid/os/Binder;->restoreCallingIdentity(J)V
    :try_end_b5
    .catchall {:try_start_b2 .. :try_end_b5} :catchall_10c

    .line 196
    monitor-exit p0

    return v7

    .line 199
    .end local v2    # "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    .end local v3    # "existingUUID":Ljava/util/UUID;
    .end local v4    # "existingAppUid":Ljava/lang/Integer;
    :cond_b7
    :goto_b7
    goto :goto_49

    .line 201
    :cond_b8
    :try_start_b8
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_ef

    .line 203
    new-instance v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;

    .line 205
    invoke-static {v6}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v1

    .line 206
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    sget-object v3, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    iget-object v4, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    .restart local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    invoke-direct/range {v0 .. v5}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;-><init>(Ljava/util/UUID;Ljava/lang/Integer;Ljava/lang/String;Landroid/bluetooth/BluetoothAdapter;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V

    .line 210
    .local v0, "serverRunnable":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->startListen()Z

    move-result v1
    :try_end_d5
    .catchall {:try_start_b8 .. :try_end_d5} :catchall_107

    if-nez v1, :cond_dd

    .line 211
    nop

    .line 228
    :try_start_d8
    invoke-static {v8, v9}, Landroid/os/Binder;->restoreCallingIdentity(J)V
    :try_end_db
    .catchall {:try_start_d8 .. :try_end_db} :catchall_10c

    .line 211
    monitor-exit p0

    return v7

    .line 213
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :cond_dd
    :try_start_dd
    iget-object v1, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v1, v10, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 214
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v5, v1, v6}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->addRfcommServerData(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 215
    iget-object v1, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 216
    .end local v0    # "serverRunnable":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    goto :goto_fb

    .line 219
    :cond_ef
    iget-object v0, v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mServerMap:Ljava/util/Map;

    invoke-interface {v0, v10, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v5, v0, v6}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->addRfcommServerData(Ljava/lang/Integer;Ljava/lang/String;)V
    :try_end_fb
    .catchall {:try_start_dd .. :try_end_fb} :catchall_107

    .line 222
    :goto_fb
    nop

    .line 228
    :try_start_fc
    invoke-static {v8, v9}, Landroid/os/Binder;->restoreCallingIdentity(J)V
    :try_end_ff
    .catchall {:try_start_fc .. :try_end_ff} :catchall_10c

    .line 222
    monitor-exit p0

    return v11

    .line 225
    .end local v12    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;>;"
    :cond_101
    nop

    .line 228
    :try_start_102
    invoke-static {v8, v9}, Landroid/os/Binder;->restoreCallingIdentity(J)V
    :try_end_105
    .catchall {:try_start_102 .. :try_end_105} :catchall_10c

    .line 225
    monitor-exit p0

    return v11

    .line 228
    .end local v10    # "keyPair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;"
    :catchall_107
    move-exception v0

    :try_start_108
    invoke-static {v8, v9}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 229
    throw v0

    .line 157
    .end local v8    # "identity":J
    .end local p1    # "appUID":I
    .end local p2    # "uuidString":Ljava/lang/String;
    :catchall_10c
    move-exception v0

    monitor-exit p0
    :try_end_10e
    .catchall {:try_start_108 .. :try_end_10e} :catchall_10c

    throw v0

    .line 159
    .restart local p1    # "appUID":I
    .restart local p2    # "uuidString":Ljava/lang/String;
    :cond_10f
    :goto_10f
    monitor-exit p0

    return v7
.end method

.method public declared-synchronized getInputParcelFileDescriptor(ILjava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 7
    .param p1, "appUID"    # I
    .param p2, "macAddress"    # Ljava/lang/String;

    monitor-enter p0

    .line 253
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2d

    .line 254
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    .line 255
    .local v0, "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    if-eqz v0, :cond_2d

    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->getAppUID()Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_2f

    if-eqz v2, :cond_2d

    .line 257
    :try_start_22
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->pipeInputStream(Ljava/util/concurrent/ThreadPoolExecutor;)Landroid/os/ParcelFileDescriptor;

    move-result-object v1
    :try_end_28
    .catch Ljava/io/IOException; {:try_start_22 .. :try_end_28} :catch_2a
    .catchall {:try_start_22 .. :try_end_28} :catchall_2f

    monitor-exit p0

    return-object v1

    .line 258
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_2a
    move-exception v2

    .line 259
    .local v2, "e":Ljava/io/IOException;
    monitor-exit p0

    return-object v1

    .line 263
    .end local v0    # "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    .end local v2    # "e":Ljava/io/IOException;
    :cond_2d
    monitor-exit p0

    return-object v1

    .line 252
    .end local p1    # "appUID":I
    .end local p2    # "macAddress":Ljava/lang/String;
    :catchall_2f
    move-exception p1

    :try_start_30
    monitor-exit p0
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_2f

    throw p1
.end method

.method public declared-synchronized getOutputParcelFileDescriptor(ILjava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 7
    .param p1, "appUID"    # I
    .param p2, "macAddress"    # Ljava/lang/String;

    monitor-enter p0

    .line 268
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2d

    .line 269
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    .line 270
    .local v0, "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    if-eqz v0, :cond_2d

    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->getAppUID()Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_2f

    if-eqz v2, :cond_2d

    .line 272
    :try_start_22
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mThreadPoolExecutor:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->pipeOutputStream(Ljava/util/concurrent/ThreadPoolExecutor;)Landroid/os/ParcelFileDescriptor;

    move-result-object v1
    :try_end_28
    .catch Ljava/io/IOException; {:try_start_22 .. :try_end_28} :catch_2a
    .catchall {:try_start_22 .. :try_end_28} :catchall_2f

    monitor-exit p0

    return-object v1

    .line 273
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_2a
    move-exception v2

    .line 274
    .local v2, "e":Ljava/io/IOException;
    monitor-exit p0

    return-object v1

    .line 278
    .end local v0    # "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    .end local v2    # "e":Ljava/io/IOException;
    :cond_2d
    monitor-exit p0

    return-object v1

    .line 267
    .end local p1    # "appUID":I
    .end local p2    # "macAddress":Ljava/lang/String;
    :catchall_2f
    move-exception p1

    :try_start_30
    monitor-exit p0
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_2f

    throw p1
.end method

.method public declared-synchronized manageAcceptedSocket(Landroid/bluetooth/BluetoothSocket;Ljava/lang/Integer;)V
    .registers 7
    .param p1, "socket"    # Landroid/bluetooth/BluetoothSocket;
    .param p2, "appUID"    # Ljava/lang/Integer;

    monitor-enter p0

    .line 317
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    .line 320
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    .line 321
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    .line 322
    .local v0, "existingSession":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    if-eqz v0, :cond_5c

    .line 323
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "BluetoothTransfer: invalid session: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v3

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_43
    .catchall {:try_start_1 .. :try_end_43} :catchall_8c

    .line 325
    :try_start_43
    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit()V
    :try_end_46
    .catch Ljava/io/IOException; {:try_start_43 .. :try_end_46} :catch_47
    .catchall {:try_start_43 .. :try_end_46} :catchall_8c

    .line 328
    goto :goto_4f

    .line 326
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_47
    move-exception v1

    .line 327
    .local v1, "e":Ljava/io/IOException;
    :try_start_48
    sget-object v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v3, "BluetoothTransfer: try to close session fail"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 329
    .end local v1    # "e":Ljava/io/IOException;
    :goto_4f
    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 333
    .end local v0    # "existingSession":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    :cond_5c
    new-instance v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    invoke-direct {v0, p1, p0, p2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;-><init>(Landroid/bluetooth/BluetoothSocket;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;Ljava/lang/Integer;)V

    .line 334
    .local v0, "rfcommConnectedSession":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->isValidSession()Z

    move-result v1

    if-eqz v1, :cond_8a

    .line 335
    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 336
    nop

    .line 337
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    .line 338
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "deviceintegration.rfcomm.ACTION_BT_SOCKET_CONNECTED"

    .line 336
    invoke-direct {p0, v1, v2, p2, v3}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->sendRfcommBroadcast(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V
    :try_end_8a
    .catchall {:try_start_48 .. :try_end_8a} :catchall_8c

    .line 342
    :cond_8a
    monitor-exit p0

    return-void

    .line 316
    .end local v0    # "rfcommConnectedSession":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    .end local p1    # "socket":Landroid/bluetooth/BluetoothSocket;
    .end local p2    # "appUID":Ljava/lang/Integer;
    :catchall_8c
    move-exception p1

    :try_start_8d
    monitor-exit p0
    :try_end_8e
    .catchall {:try_start_8d .. :try_end_8e} :catchall_8c

    throw p1
.end method

.method public declared-synchronized manageSocketConnectionLost(Landroid/bluetooth/BluetoothSocket;Ljava/lang/Integer;)V
    .registers 7
    .param p1, "socket"    # Landroid/bluetooth/BluetoothSocket;
    .param p2, "appUID"    # Ljava/lang/Integer;

    monitor-enter p0

    .line 345
    :try_start_1
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_52

    .line 346
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    .line 347
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_54

    .line 348
    .local v0, "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    if-eqz v0, :cond_2f

    .line 350
    :try_start_23
    invoke-virtual {v0}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit()V
    :try_end_26
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_26} :catch_27
    .catchall {:try_start_23 .. :try_end_26} :catchall_54

    .line 353
    goto :goto_2f

    .line 351
    .end local p0    # "this":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    :catch_27
    move-exception v1

    .line 352
    .local v1, "e":Ljava/io/IOException;
    :try_start_28
    sget-object v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->TAG:Ljava/lang/String;

    const-string v3, "BluetoothTransfer: Socket is already closed"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 355
    .end local v1    # "e":Ljava/io/IOException;
    :cond_2f
    :goto_2f
    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->mSessionMap:Ljava/util/Map;

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 357
    nop

    .line 358
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v1

    .line 359
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "deviceintegration.rfcomm.ACTION_BT_SOCKET_DISCONNECTED"

    .line 357
    invoke-direct {p0, v1, v2, p2, v3}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->sendRfcommBroadcast(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V
    :try_end_52
    .catchall {:try_start_28 .. :try_end_52} :catchall_54

    .line 363
    .end local v0    # "session":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
    :cond_52
    monitor-exit p0

    return-void

    .line 344
    .end local p1    # "socket":Landroid/bluetooth/BluetoothSocket;
    .end local p2    # "appUID":Ljava/lang/Integer;
    :catchall_54
    move-exception p1

    :try_start_55
    monitor-exit p0
    :try_end_56
    .catchall {:try_start_55 .. :try_end_56} :catchall_54

    throw p1
.end method
