.class final Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
.super Ljava/lang/Object;
.source "OplusHansWatchDog.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/OplusHansWatchDog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "HandlerChecker"
.end annotation


# instance fields
.field private mCompleted:Z

.field private final mHandler:Landroid/os/Handler;

.field private final mName:Ljava/lang/String;

.field private mStartTime:J

.field private mWaitMax:J

.field final synthetic this$0:Lcom/android/server/hans/OplusHansWatchDog;


# direct methods
.method static bridge synthetic -$$Nest$msetWaitMax(Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;J)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->setWaitMax(J)V

    return-void
.end method

.method constructor <init>(Lcom/android/server/hans/OplusHansWatchDog;Landroid/os/Handler;Ljava/lang/String;J)V
    .registers 8
    .param p2, "handler"    # Landroid/os/Handler;
    .param p3, "name"    # Ljava/lang/String;
    .param p4, "waitMaxMillis"    # J
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null
        }
    .end annotation

    .line 117
    iput-object p1, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 113
    invoke-static {}, Lcom/android/server/hans/OplusHansWatchDog;->-$$Nest$sfgetsDefaultTimeout()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    .line 118
    iput-object p2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mHandler:Landroid/os/Handler;

    .line 119
    iput-object p3, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    .line 120
    iput-wide p4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    .line 121
    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    .line 122
    return-void
.end method

.method private setWaitMax(J)V
    .registers 3
    .param p1, "waitMax"    # J

    .line 198
    iput-wide p1, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    .line 199
    return-void
.end method


# virtual methods
.method describeBlockedStateLocked()Ljava/lang/String;
    .registers 3

    .line 202
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Blocked in handler on "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCompletionStateLocked()I
    .registers 7

    .line 158
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    if-eqz v0, :cond_6

    .line 159
    const/4 v0, 0x0

    return v0

    .line 161
    :cond_6
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    sub-long/2addr v0, v2

    .line 162
    .local v0, "latency":J
    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    const-wide/16 v4, 0x2

    div-long/2addr v2, v4

    cmp-long v2, v0, v2

    if-gez v2, :cond_18

    .line 163
    const/4 v2, 0x1

    return v2

    .line 164
    :cond_18
    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    cmp-long v2, v0, v2

    if-gez v2, :cond_3e

    .line 165
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " blocked: WAITED_HALF, latency: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansWatchDog;->logD(Ljava/lang/String;)V

    .line 166
    const/4 v2, 0x2

    return v2

    .line 169
    :cond_3e
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " blocked: OVERDUE, latency: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansWatchDog;->logD(Ljava/lang/String;)V

    .line 170
    const/4 v2, 0x3

    return v2
.end method

.method public getLooper()Landroid/os/Looper;
    .registers 2

    .line 174
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 186
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    return-object v0
.end method

.method public getQueue()Landroid/os/MessageQueue;
    .registers 2

    .line 182
    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getQueue()Landroid/os/MessageQueue;

    move-result-object v0

    return-object v0
.end method

.method public getStartTime()J
    .registers 3

    .line 194
    iget-wide v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    return-wide v0
.end method

.method public getThread()Ljava/lang/Thread;
    .registers 2

    .line 178
    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    return-object v0
.end method

.method public getWaitMax()J
    .registers 3

    .line 190
    iget-wide v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    return-wide v0
.end method

.method isHalfOverdueLocked()Z
    .registers 7

    .line 152
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    if-nez v0, :cond_16

    .line 153
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    sub-long/2addr v0, v2

    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    const-wide/16 v4, 0x2

    div-long/2addr v2, v4

    cmp-long v0, v0, v2

    if-ltz v0, :cond_16

    const/4 v0, 0x1

    goto :goto_17

    :cond_16
    const/4 v0, 0x0

    .line 152
    :goto_17
    return v0
.end method

.method isOverdueLocked()Z
    .registers 5

    .line 147
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    if-nez v0, :cond_13

    .line 148
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    sub-long/2addr v0, v2

    iget-wide v2, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    cmp-long v0, v0, v2

    if-ltz v0, :cond_13

    const/4 v0, 0x1

    goto :goto_14

    :cond_13
    const/4 v0, 0x0

    .line 147
    :goto_14
    return v0
.end method

.method public run()V
    .registers 3

    .line 207
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->this$0:Lcom/android/server/hans/OplusHansWatchDog;

    invoke-static {v0}, Lcom/android/server/hans/OplusHansWatchDog;->-$$Nest$fgetmLock(Lcom/android/server/hans/OplusHansWatchDog;)Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 208
    const/4 v1, 0x1

    :try_start_8
    iput-boolean v1, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    .line 209
    monitor-exit v0

    .line 210
    return-void

    .line 209
    :catchall_c
    move-exception v1

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_8 .. :try_end_e} :catchall_c

    throw v1
.end method

.method public scheduleCheckLocked()V
    .registers 3

    .line 125
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getQueue()Landroid/os/MessageQueue;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/MessageQueue;->isPolling()Z

    move-result v0

    if-eqz v0, :cond_14

    .line 133
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    .line 134
    return-void

    .line 136
    :cond_14
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    if-nez v0, :cond_19

    .line 138
    return-void

    .line 141
    :cond_19
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    .line 142
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    .line 143
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    .line 144
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 214
    const-string v0, ""

    invoke-virtual {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public toString(Ljava/lang/String;)Ljava/lang/String;
    .registers 12
    .param p1, "Tag"    # Ljava/lang/String;

    .line 218
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x100

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 219
    .local v0, "sb":Ljava/lang/StringBuilder;
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_10

    const-string v1, ""

    goto :goto_23

    :cond_10
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 220
    .local v1, "prefix":Ljava/lang/String;
    :goto_23
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " mHandler   :"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mHandler:Landroid/os/Handler;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 221
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " mName      :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mName:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 222
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " mWaitMax   :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 223
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " mCompleted :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mCompleted:Z

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 224
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " mStartTime :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 225
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " upTime     :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 226
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " halfTime   :"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    iget-wide v6, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    const-wide/16 v8, 0x2

    div-long/2addr v6, v8

    add-long/2addr v4, v6

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " blocked:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->isHalfOverdueLocked()Z

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 227
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " overDueTime:"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v5, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mStartTime:J

    iget-wide v7, p0, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->mWaitMax:J

    add-long/2addr v5, v7

    invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->isOverdueLocked()Z

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 228
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method
