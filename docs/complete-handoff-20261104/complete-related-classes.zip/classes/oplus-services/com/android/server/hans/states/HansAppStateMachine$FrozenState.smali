.class Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;
.super Lcom/android/server/hans/states/State;
.source "HansAppStateMachine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/states/HansAppStateMachine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "FrozenState"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/hans/states/HansAppStateMachine;


# direct methods
.method public static synthetic $r8$lambda$rTqoNt8b800uKTITcZT0I7dvTJg(Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->lambda$exit$0()V

    return-void
.end method

.method public constructor <init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p1, "this$0"    # Lcom/android/server/hans/states/HansAppStateMachine;
    .param p2, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 709
    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-direct {p0}, Lcom/android/server/hans/states/State;-><init>()V

    .line 710
    new-instance v0, Lcom/android/server/hans/states/action/FrozenAction;

    invoke-direct {v0, p2}, Lcom/android/server/hans/states/action/FrozenAction;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->mAction:Lcom/android/server/hans/states/action/Action;

    .line 711
    return-void
.end method

.method private synthetic lambda$exit$0()V
    .registers 4

    .line 753
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/OplusHansManager;->tryUnProxyWakeLock(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 754
    return-void
.end method

.method private transToMiddle()V
    .registers 10

    .line 846
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmMiddleState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 848
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 849
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v6

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v8

    .line 848
    invoke-virtual/range {v2 .. v8}, Lcom/android/server/hans/OplusHansDBConfig;->getMtoFCheckTime(ILjava/lang/String;IJLjava/lang/String;)J

    move-result-wide v1

    const/16 v3, 0x8

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 850
    return-void
.end method

.method private transToRunning()V
    .registers 9

    .line 839
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRunningState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 841
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 842
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v6

    .line 841
    invoke-virtual/range {v2 .. v7}, Lcom/android/server/hans/OplusHansDBConfig;->getRtoMCheckTime(ILjava/lang/String;IJ)J

    move-result-wide v1

    const/4 v3, 0x4

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 843
    return-void
.end method


# virtual methods
.method public enter()V
    .registers 6

    .line 715
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " F enter(), M stay="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 716
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 717
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v1, 0x72

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 720
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    .line 722
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->freezeDirectlyForSceneCombo(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    move-result-object v0

    .line 723
    .local v0, "freezeState":Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    if-eq v0, v2, :cond_de

    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    if-eq v0, v2, :cond_de

    .line 724
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", pkg="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " HansSceneManager.freeze() failed, go back to R"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 725
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 726
    :try_start_c1
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getSuperFRZMode()Z

    move-result v3

    if-eqz v3, :cond_d6

    .line 727
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansPackage;->setSuperFRZMode(Z)V

    .line 729
    :cond_d6
    monitor-exit v2
    :try_end_d7
    .catchall {:try_start_c1 .. :try_end_d7} :catchall_db

    .line 731
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToRunning()V

    goto :goto_e3

    .line 729
    :catchall_db
    move-exception v1

    :try_start_dc
    monitor-exit v2
    :try_end_dd
    .catchall {:try_start_dc .. :try_end_dd} :catchall_db

    throw v1

    .line 733
    :cond_de
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->mAction:Lcom/android/server/hans/states/action/Action;

    invoke-virtual {v1}, Lcom/android/server/hans/states/action/Action;->executeAction()V

    .line 735
    :goto_e3
    return-void
.end method

.method public exit()V
    .registers 7

    .line 739
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, ", pkg="

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " F exit(), F stay="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", reason="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", FrozenActionKeepProxy="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    .line 740
    invoke-virtual {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->shouldFrozenActionKeepProxy()Z

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 739
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 741
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    invoke-virtual {v0, v1, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDirectly(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v0

    .line 742
    .local v0, "unfreezeState":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    if-eq v0, v1, :cond_c6

    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    if-eq v0, v1, :cond_c6

    .line 743
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "cgroupUnFreeze failed"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_d3

    .line 747
    :cond_c6
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/am/OplusHansManager;->removeTrimMemHansPkgFromList(Lcom/android/server/hans/OplusHansPackage;)V

    .line 751
    :goto_d3
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->mAction:Lcom/android/server/hans/states/action/Action;

    invoke-virtual {v1}, Lcom/android/server/hans/states/action/Action;->clearAction()V

    .line 752
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneManager;->getMainHandler()Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 755
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 835
    const-string v0, "Frozen"

    return-object v0
.end method

.method public processMessage(Landroid/os/Message;)Z
    .registers 10
    .param p1, "msg"    # Landroid/os/Message;

    .line 760
    iget v0, p1, Landroid/os/Message;->what:I

    const-string v1, ", reason="

    const-string v2, ", transition from F to "

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v5, ", pkg="

    const-string/jumbo v6, "uid="

    sparse-switch v0, :sswitch_data_31e

    goto/16 :goto_31c

    .line 814
    :sswitch_12
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v7, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    invoke-static {v0, v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 815
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 816
    .local v0, "destState":I
    if-ne v0, v3, :cond_23

    .line 817
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToMiddle()V

    goto :goto_36

    .line 818
    :cond_23
    if-ne v0, v4, :cond_29

    .line 819
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToRunning()V

    goto :goto_36

    .line 820
    :cond_29
    if-nez v0, :cond_36

    .line 821
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v7

    invoke-virtual {v3, v7}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 823
    :cond_36
    :goto_36
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_31c

    .line 824
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v6}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 825
    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getStateName(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 824
    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    goto/16 :goto_31c

    .line 806
    .end local v0    # "destState":I
    :sswitch_93
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->removeAllMessages()V

    .line 807
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 808
    .local v0, "reason":Ljava/lang/String;
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_31b

    .line 809
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " SM all messages removed, reason: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto/16 :goto_31b

    .line 781
    .end local v0    # "reason":Ljava/lang/String;
    :sswitch_e9
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 782
    .local v0, "curResumedUid":I
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    if-ne v1, v0, :cond_146

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v1

    if-eqz v1, :cond_146

    .line 783
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " F Deepsleep OFF, is top app, transition to Default"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 784
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_31b

    .line 785
    :cond_146
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansImportance(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansImportance;

    const/16 v2, 0xe1d

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->isInImportanceList(I)Z

    move-result v1

    if-eqz v1, :cond_31b

    .line 786
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " F Deepsleep OFF, transition to Running"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 787
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToRunning()V

    goto/16 :goto_31b

    .line 791
    .end local v0    # "curResumedUid":I
    :sswitch_196
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v7, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    invoke-static {v0, v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 792
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 793
    .local v0, "destState":I
    if-ne v0, v3, :cond_1a7

    .line 794
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToMiddle()V

    goto :goto_1ba

    .line 795
    :cond_1a7
    if-ne v0, v4, :cond_1ad

    .line 796
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToRunning()V

    goto :goto_1ba

    .line 797
    :cond_1ad
    if-nez v0, :cond_1ba

    .line 798
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v7

    invoke-virtual {v3, v7}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 800
    :cond_1ba
    :goto_1ba
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_31b

    .line 801
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v7}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v6}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 802
    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getStateName(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 801
    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    goto/16 :goto_31b

    .line 762
    .end local v0    # "destState":I
    :sswitch_217
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mremoveAllMessagesExceptEnterSM(Lcom/android/server/hans/states/HansAppStateMachine;)V

    .line 763
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " F exit SM"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 764
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 765
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 766
    goto/16 :goto_31b

    .line 768
    :sswitch_26e
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v1, 0x67

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 769
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 770
    .local v0, "curResumedUid":I
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const-string v2, "LcdOn"

    invoke-static {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 771
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    if-ne v1, v0, :cond_2ce

    .line 772
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " F LCD ON, is top app, transition to Default"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 774
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto :goto_31b

    .line 775
    :cond_2ce
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mgetLcdOffSkipImportance(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->isInImportanceList(I)Z

    move-result v1

    if-eqz v1, :cond_31b

    .line 776
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " F LCD ON, transition to Running"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 777
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;->transToRunning()V

    .line 830
    .end local v0    # "curResumedUid":I
    :cond_31b
    :goto_31b
    return v4

    .line 828
    :cond_31c
    :goto_31c
    return v4

    nop

    :sswitch_data_31e
    .sparse-switch
        0x65 -> :sswitch_26e
        0x69 -> :sswitch_217
        0x6b -> :sswitch_196
        0x6d -> :sswitch_e9
        0x6f -> :sswitch_93
        0x70 -> :sswitch_12
    .end sparse-switch
.end method
