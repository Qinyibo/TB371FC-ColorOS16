.class public Lcom/android/server/display/WakelockControllerExtImpl;
.super Ljava/lang/Object;
.source "WakelockControllerExtImpl.java"

# interfaces
.implements Lcom/android/server/display/IWakelockControllerExt;


# static fields
.field private static final DEBUG_PANIC:Z

.field private static final SUSPEND_BLOCKER_NEGATIVE:Ljava/lang/String; = "[0]custom prox negative"

.field private static final SUSPEND_BLOCKER_POSITIVE:Ljava/lang/String; = "[0]custom prox positive"

.field private static final TAG:Ljava/lang/String; = "WakelockControllerExtImpl"

.field private static final WAKELOCK_CUSTOM_NEGATIVE:I = 0x65

.field private static final WAKELOCK_CUSTOM_POSITIVE:I = 0x64


# instance fields
.field private mIsHoldNegativeWakelock:Z

.field private mIsHoldPostiveWakelock:Z

.field private mWakelockController:Lcom/android/server/display/WakelockController;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 30
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/display/WakelockControllerExtImpl;->DEBUG_PANIC:Z

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 3
    .param p1, "base"    # Ljava/lang/Object;

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    .line 32
    iput-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    .line 36
    move-object v0, p1

    check-cast v0, Lcom/android/server/display/WakelockController;

    iput-object v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mWakelockController:Lcom/android/server/display/WakelockController;

    .line 37
    return-void
.end method


# virtual methods
.method public acquireWakelockCustom(ILandroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;)Z
    .registers 5
    .param p1, "wakelockType"    # I
    .param p2, "displayPowerCallbacks"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;

    .line 41
    sget-boolean v0, Lcom/android/server/display/WakelockControllerExtImpl;->DEBUG_PANIC:Z

    if-eqz v0, :cond_34

    .line 42
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "acquireWakelockCustom "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", mIsHoldNegativeWakelock "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", mIsHoldPostiveWakelock "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "WakelockControllerExtImpl"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 46
    :cond_34
    const/16 v0, 0x65

    const/4 v1, 0x1

    if-ne p1, v0, :cond_45

    .line 47
    iget-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    if-nez v0, :cond_44

    .line 48
    const-string v0, "[0]custom prox negative"

    invoke-interface {p2, v0}, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;->acquireSuspendBlocker(Ljava/lang/String;)V

    .line 49
    iput-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    .line 51
    :cond_44
    return v1

    .line 52
    :cond_45
    const/16 v0, 0x64

    if-ne p1, v0, :cond_55

    .line 53
    iget-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    if-nez v0, :cond_54

    .line 54
    const-string v0, "[0]custom prox positive"

    invoke-interface {p2, v0}, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;->acquireSuspendBlocker(Ljava/lang/String;)V

    .line 55
    iput-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    .line 57
    :cond_54
    return v1

    .line 59
    :cond_55
    const/4 v0, 0x0

    return v0
.end method

.method public releaseWakelockCustom(ILandroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;)Z
    .registers 6
    .param p1, "wakelockType"    # I
    .param p2, "displayPowerCallbacks"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;

    .line 64
    sget-boolean v0, Lcom/android/server/display/WakelockControllerExtImpl;->DEBUG_PANIC:Z

    if-eqz v0, :cond_34

    .line 65
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "acquireWakelockCustom "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", mIsHoldNegativeWakelock "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", mIsHoldPostiveWakelock "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "WakelockControllerExtImpl"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    :cond_34
    const/16 v0, 0x65

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne p1, v0, :cond_46

    .line 70
    iget-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    if-eqz v0, :cond_45

    .line 71
    const-string v0, "[0]custom prox negative"

    invoke-interface {p2, v0}, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;->releaseSuspendBlocker(Ljava/lang/String;)V

    .line 72
    iput-boolean v2, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldNegativeWakelock:Z

    .line 74
    :cond_45
    return v1

    .line 75
    :cond_46
    const/16 v0, 0x64

    if-ne p1, v0, :cond_56

    .line 76
    iget-boolean v0, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    if-eqz v0, :cond_55

    .line 77
    const-string v0, "[0]custom prox positive"

    invoke-interface {p2, v0}, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerCallbacks;->releaseSuspendBlocker(Ljava/lang/String;)V

    .line 78
    iput-boolean v2, p0, Lcom/android/server/display/WakelockControllerExtImpl;->mIsHoldPostiveWakelock:Z

    .line 80
    :cond_55
    return v1

    .line 82
    :cond_56
    return v2
.end method
