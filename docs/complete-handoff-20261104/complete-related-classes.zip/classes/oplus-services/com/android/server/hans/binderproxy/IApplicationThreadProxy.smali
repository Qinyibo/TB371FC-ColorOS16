.class public Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;
.super Lcom/android/server/hans/binderproxy/OplusBinderTransactProxy;
.source "IApplicationThreadProxy.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/hans/binderproxy/IApplicationThreadProxy$ProxyTransaction;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "android.app.IApplicationThread"

.field private static TRANSACTION_setProcessState:I


# direct methods
.method static bridge synthetic -$$Nest$sfgetTRANSACTION_setProcessState()I
    .registers 1

    sget v0, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;->TRANSACTION_setProcessState:I

    return v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 19
    const-string v0, "android.app.IApplicationThread"

    const/4 v1, -0x1

    sput v1, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;->TRANSACTION_setProcessState:I

    .line 23
    :try_start_5
    const-class v1, Landroid/app/IApplicationThread$Stub;

    const-string v2, "TRANSACTION_setProcessState"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 24
    .local v1, "f":Ljava/lang/reflect/Field;
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 25
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v3

    sput v3, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;->TRANSACTION_setProcessState:I

    .line 26
    invoke-static {}, Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;->getInstance()Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;

    move-result-object v3

    invoke-virtual {v3, v0, v2}, Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;->setProxyBinderReady(Ljava/lang/String;Z)V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_1f} :catch_20

    .line 30
    .end local v1    # "f":Ljava/lang/reflect/Field;
    goto :goto_45

    .line 27
    :catch_20
    move-exception v1

    .line 28
    .local v1, "e":Ljava/lang/Exception;
    invoke-static {}, Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;->getInstance()Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, Lcom/android/server/hans/binderproxy/OplusBinderProxyManager;->setProxyBinderReady(Ljava/lang/String;Z)V

    .line 29
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "IApplicationThreadProxy init TRANSACTION_setProcessState fail:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "OplusBinderProxy"

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_45
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Landroid/os/IBinder;II)V
    .registers 5
    .param p1, "descriptor"    # Ljava/lang/String;
    .param p2, "bpBinder"    # Landroid/os/IBinder;
    .param p3, "uid"    # I
    .param p4, "pid"    # I

    .line 34
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/server/hans/binderproxy/OplusBinderTransactProxy;-><init>(Ljava/lang/String;Landroid/os/IBinder;II)V

    .line 35
    return-void
.end method


# virtual methods
.method public onCreateTransaction(ILandroid/os/Parcel;)Lcom/android/server/hans/binderproxy/Transaction;
    .registers 4
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;

    .line 38
    new-instance v0, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy$ProxyTransaction;

    invoke-direct {v0, p0, p1, p2}, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy$ProxyTransaction;-><init>(Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;ILandroid/os/Parcel;)V

    return-object v0
.end method
