.class public Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;
.super Ljava/lang/Object;
.source "OGuardDBConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/oguard/OGuardDBConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "AudioWakelockDetectionPolicy"
.end annotation


# instance fields
.field aggAudioDirectOut:Z

.field aggAudioIn:Z

.field aggAudioMix:Z

.field aggOnScrOn:Z

.field bgKeepLiveTime:J

.field pkg:Ljava/lang/String;

.field threshold:J


# direct methods
.method public constructor <init>(Lcom/android/server/hans/oguard/OGuardDBConfig;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 14
    .param p1, "this$0"    # Lcom/android/server/hans/oguard/OGuardDBConfig;
    .param p2, "pkg"    # Ljava/lang/String;
    .param p3, "aggOnScrOn"    # Ljava/lang/String;
    .param p4, "aggAudioIn"    # Ljava/lang/String;
    .param p5, "aggAudioMix"    # Ljava/lang/String;
    .param p6, "aggAudioDirectOut"    # Ljava/lang/String;
    .param p7, "threshold"    # Ljava/lang/String;
    .param p8, "keepAliveTime"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        }
    .end annotation

    .line 1682
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1674
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggOnScrOn:Z

    .line 1675
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioIn:Z

    .line 1676
    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioMix:Z

    .line 1677
    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioDirectOut:Z

    .line 1678
    sget-wide v0, Lcom/android/server/hans/oguard/obrain/ObrainConstants;->ONE_DAY:J

    iput-wide v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->threshold:J

    .line 1679
    sget-wide v0, Lcom/android/server/hans/oguard/obrain/ObrainConstants;->ONE_DAY:J

    iput-wide v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->bgKeepLiveTime:J

    .line 1683
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1d

    .line 1684
    iput-object p2, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->pkg:Ljava/lang/String;

    .line 1686
    :cond_1d
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_29

    .line 1687
    invoke-static {p3}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggOnScrOn:Z

    .line 1689
    :cond_29
    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_35

    .line 1690
    invoke-static {p4}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioIn:Z

    .line 1692
    :cond_35
    invoke-static {p5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_41

    .line 1693
    invoke-static {p5}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioMix:Z

    .line 1695
    :cond_41
    invoke-static {p6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4d

    .line 1696
    invoke-static {p6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioDirectOut:Z

    .line 1698
    :cond_4d
    invoke-static {p7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const-wide/16 v1, 0x3e8

    if-nez v0, :cond_5c

    .line 1699
    invoke-static {p7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    mul-long/2addr v3, v1

    iput-wide v3, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->threshold:J

    .line 1701
    :cond_5c
    invoke-static {p8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_69

    .line 1702
    invoke-static {p8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    mul-long/2addr v3, v1

    iput-wide v3, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->bgKeepLiveTime:J

    .line 1704
    :cond_69
    return-void
.end method


# virtual methods
.method public getAudioWakelockDetectionThreshold()J
    .registers 3

    .line 1723
    iget-wide v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->threshold:J

    return-wide v0
.end method

.method public getBgKeepLiveTime()J
    .registers 3

    .line 1727
    iget-wide v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->bgKeepLiveTime:J

    return-wide v0
.end method

.method public isAggAudioDirectOut()Z
    .registers 2

    .line 1719
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioDirectOut:Z

    return v0
.end method

.method public isAggAudioIn()Z
    .registers 2

    .line 1711
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioIn:Z

    return v0
.end method

.method public isAggAudioMix()Z
    .registers 2

    .line 1715
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioMix:Z

    return v0
.end method

.method public isAggOnScrOn()Z
    .registers 2

    .line 1707
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggOnScrOn:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    .line 1732
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "AudioWakelockDetectionPolicy{ pkg: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->pkg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " aggOnScrOn: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggOnScrOn:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " aggAudioIn: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioIn:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " aggAudioMix: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioMix:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " aggAudioDirectOut: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->aggAudioDirectOut:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " threshold: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->threshold:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " bgKeepLiveTime: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$AudioWakelockDetectionPolicy;->bgKeepLiveTime:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
