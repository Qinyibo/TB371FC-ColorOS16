.class Lcom/android/server/am/OplusActivityManagerServiceEnhance$CpuFilter;
.super Ljava/lang/Object;
.source "OplusActivityManagerServiceEnhance.java"

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/am/OplusActivityManagerServiceEnhance;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "CpuFilter"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 963
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .registers 4
    .param p1, "pathname"    # Ljava/io/File;

    .line 967
    const-string v0, "cpu[0-9]"

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 968
    const/4 v0, 0x1

    return v0

    .line 970
    :cond_e
    const/4 v0, 0x0

    return v0
.end method
