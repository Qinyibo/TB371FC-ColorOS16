.class public Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.super Ljava/lang/Object;
.source "OplusDisplayPowerControllerExtImpl.java"

# interfaces
.implements Lcom/android/server/display/IOplusDisplayPowerControllerExt;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;,
        Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;,
        Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;,
        Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;,
        Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;
    }
.end annotation


# static fields
.field private static final ADFR_ENABLED:Z

.field private static final BRIGHTNESS_LEVEL_DIFF:I = 0x5

.field private static DEBUG:Z = false

.field private static final DELAY_TIME:I = 0x3e8

.field private static final EVENT_ANIMATION_END:I = 0x2

.field private static final FACE_SCREEN_BRIGHTNESS:Ljava/lang/String; = "face_fill_screen_brightness"

.field private static final FEATURE_REMAP_DISPLAY_DISABLED:Ljava/lang/String; = "oplus.software.fold_remap_display_disabled"

.field private static final INVALID_INT:I = -0x1

.field private static final MSG_EXIT_STATE_DELAYED:I = 0x7e5

.field private static final MSG_FIRST_INDEX:I = 0x3e8

.field private static final MSG_INIT_RUS_OBJECT:I = 0x7e4

.field private static final MSG_REGISTER_DISPLAY_LISTENER:I = 0x3eb

.field private static final MSG_SCREEN_ON_UNBLOCKED_BY_BIOMETRICS:I = 0x3e9

.field private static final MSG_SET_MAX_BRIGHTNESS_RECOVER:I = 0x7e6

.field private static final MSG_SET_SPEC_BTN_UPDATE:I = 0x898

.field private static final MSG_SET_TEMPORARY_BRIGHTNESS_EXT:I = 0x5

.field private static final MSG_SPEC_FORCE_BTN_UPDATE:I = 0x899

.field private static final OPLUS_BIOMETRICS_INTERNAL_NAME:Ljava/lang/String; = "com.android.server.biometrics.sensors.wakeup.OplusBiometricWakeupManager"

.field private static final OPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE:Ljava/lang/String; = "oplus_customize_recovery_settings_state"

.field private static final OPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI:Landroid/net/Uri;

.field private static final OPLUS_DC_MODE:Ljava/lang/String; = "display_dc_settings_switch"

.field private static final OSENSE_ID_SCREEN_STATE_TURN_ON:I = 0x3f5

.field private static final REAL_SCREEN_BRIGHTNESS:Ljava/lang/String; = "real_screen_brightness"

.field private static final RECOVERY_STATE_DEFAULT:I = 0x0

.field private static final REGISTER_DISPLAY_LISTENER_DELAY_TIME:I = 0x7d0

.field private static final SCREEN_BRIGHTNESS_MODE_AUTOMATIC:I = 0x1

.field private static final SCREEN_DIM_MINIMUM_REDUCTION:I = 0xa

.field private static final SCREEN_ON_BLOCKED_BY_BIOMETRICS_TRACE_NAME:Ljava/lang/String; = "Screen on blocked by biometrics"

.field private static final SECOND_SCREEN_AUTO_BRIGHTNESS_ADJ:Ljava/lang/String; = "second_screen_auto_brightness_adj"

.field private static final SECOND_SCREEN_BRIGHTNESS_ON_TO_DOZE:Ljava/lang/String; = "second_screen_brightness_on_to_doze"

.field private static final SECOND_SCREEN_BRIGHTNESS_POLICY_BRIGHT:Ljava/lang/String; = "second_screen_brightness_policy_bright"

.field private static final TAG_BIOMETRICS:Ljava/lang/String; = "Biometrics_DEBUG"

.field private static final VRR_ENABLED:Z


# instance fields
.field private INVALID_NIT_VALUE:J

.field private INVALID_PHYSICAL_DISPLAY_ID:J

.field private TAG:Ljava/lang/String;

.field private mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

.field private mAutoAdjChanged:Z

.field private final mBlockReasonList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mBootCompleted:Z

.field private mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

.field private mBroadcastReceiver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

.field private mByUser:Z

.field private mContext:Landroid/content/Context;

.field private mCurPowerReq:Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

.field private mCurrentBrightness:F

.field private mCurrentNit:F

.field private mCurrentPowerModeState:I

.field private mCurrentSdrBrightness:F

.field private mDPCExtWorkHandler:Landroid/os/Handler;

.field private mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mDefaultNormalMaxBrightness:F

.field private mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

.field private mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

.field private mDisplayId:I

.field private final mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

.field private mDisplaySpecialPkgList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public mDpc:Lcom/android/server/display/DisplayPowerController;

.field private mGlobalDCMode:Z

.field private mGlobalHbmSellMode:I

.field private mGlobalHbmSupported:Z

.field private mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

.field private mIgnoreReadyState:Z

.field private mIsAutoBrightness:Z

.field private mIsOplusTest:Z

.field private mIsSetUxWhenWindowUnblock:Z

.field private mIsUserSwitching:Z

.field private mNeedResetTemporaryStrategy:Z

.field private mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

.field private mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

.field private mOnToDozeBrightness:I

.field private mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

.field private mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

.field private mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

.field private mPendingDisplayReadyBlocker:Z

.field private mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

.field private mPhysicalDisplayId:J

.field private mPolicyBrightBrightness:I

.field private mPolicyBrightProvider:Z

.field private mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

.field private mPowerManager:Landroid/os/PowerManager;

.field private mPowerManagerInternal:Landroid/os/PowerManagerInternal;

.field private mPowerOnUxPid:I

.field private mPowerOnUxTid:I

.field private mPowerState:Lcom/android/server/display/DisplayPowerState;

.field private mRate:I

.field private mRateType:I

.field private mRemapDisable:Z

.field private mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/android/server/display/RampAnimator$DualRampAnimator<",
            "Lcom/android/server/display/DisplayPowerState;",
            ">;"
        }
    .end annotation
.end field

.field private mScreenOnBlockedByFace:Z

.field private mScreenState:I

.field private mSecondAdjChanged:Z

.field private mSetPowerOnUx:Z

.field private mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

.field private mUniqueDisplayId:Ljava/lang/String;

.field private mWinOverride:Z


# direct methods
.method public static synthetic $r8$lambda$FTfMT7MOD-gY3tYEnoLa_b6xl8E(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->lambda$setupPostProcessLocked$0()V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmContext(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmDisplayListener(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/hardware/display/DisplayManager$DisplayListener;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmDisplaySpecialPkgList(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/util/List;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplaySpecialPkgList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHandler(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsOplusTest:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusAutomaticBrightnessController(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusAutomaticBrightnessController;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmPendingScreenOnUnblockerFromBiometrics(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerState:Lcom/android/server/display/DisplayPowerState;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsOplusTest:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetOPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI()Landroid/net/Uri;
    .registers 1

    sget-object v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->OPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI:Landroid/net/Uri;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 212
    invoke-static {}, Lcom/oplus/vrr/OPlusRefreshRateManager;->hasADFRFeature()Z

    move-result v0

    sput-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->ADFR_ENABLED:Z

    .line 213
    invoke-static {}, Lcom/oplus/vrr/OPlusRefreshRateManager;->hasVRRFeature()Z

    move-result v0

    sput-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->VRR_ENABLED:Z

    .line 214
    const-string/jumbo v0, "oplus_customize_recovery_settings_state"

    invoke-static {v0}, Landroid/provider/Settings$Global;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->OPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI:Landroid/net/Uri;

    .line 216
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 7
    .param p1, "base"    # Ljava/lang/Object;

    .line 303
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 174
    const-string v0, "DpcExtImpl"

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    .line 217
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAutoAdjChanged:Z

    .line 218
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSecondAdjChanged:Z

    .line 219
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mWinOverride:Z

    .line 220
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsOplusTest:Z

    .line 221
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBootCompleted:Z

    .line 222
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    .line 223
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightProvider:Z

    .line 224
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    .line 225
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalDCMode:Z

    .line 226
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    .line 227
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenOnBlockedByFace:Z

    .line 228
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    .line 229
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNeedResetTemporaryStrategy:Z

    .line 230
    invoke-static {}, Lcom/oplus/content/OplusFeatureConfigManager;->getInstacne()Lcom/oplus/content/OplusFeatureConfigManager;

    move-result-object v1

    .line 231
    const-string/jumbo v2, "oplus.software.display.screen_gloablehbm_support"

    invoke-virtual {v1, v2}, Lcom/oplus/content/OplusFeatureConfigManager;->hasFeature(Ljava/lang/String;)Z

    move-result v1

    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalHbmSupported:Z

    .line 232
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 233
    const/4 v1, 0x0

    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    .line 234
    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentNit:F

    .line 235
    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentSdrBrightness:F

    .line 236
    const/high16 v1, 0x437f0000    # 255.0f

    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDefaultNormalMaxBrightness:F

    .line 237
    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, -0x1

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 238
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOnToDozeBrightness:I

    .line 239
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightBrightness:I

    .line 240
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRate:I

    .line 241
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRateType:I

    .line 242
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentPowerModeState:I

    .line 246
    const-wide/16 v3, 0x0

    iput-wide v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_PHYSICAL_DISPLAY_ID:J

    .line 247
    const-wide/16 v3, -0x1

    iput-wide v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_NIT_VALUE:J

    .line 248
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenState:I

    .line 249
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalHbmSellMode:I

    .line 250
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    .line 252
    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 257
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurPowerReq:Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 258
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 259
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    .line 263
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    .line 272
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    .line 273
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    .line 276
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    .line 277
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    .line 278
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDPCExtWorkHandler:Landroid/os/Handler;

    .line 279
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    .line 280
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    .line 281
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBroadcastReceiver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    .line 283
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    .line 284
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSetPowerOnUx:Z

    .line 285
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsSetUxWhenWindowUnblock:Z

    .line 286
    iput v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxPid:I

    .line 287
    iput v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxTid:I

    .line 291
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIgnoreReadyState:Z

    .line 294
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    .line 300
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    .line 301
    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplaySpecialPkgList:Ljava/util/List;

    .line 1675
    new-instance v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;

    invoke-direct {v0, p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayListener:Landroid/hardware/display/DisplayManager$DisplayListener;

    .line 304
    move-object v0, p1

    check-cast v0, Lcom/android/server/display/DisplayPowerController;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    .line 305
    return-void
.end method

.method private clampAbsoluteBrightness(F)F
    .registers 5
    .param p1, "value"    # F

    .line 1404
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMinBrightness()F

    move-result v0

    .line 1405
    .local v0, "minLimit":F
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getTotalBrightness()F

    move-result v1

    .line 1406
    .local v1, "maxLimit":F
    invoke-static {p1, v0, v1}, Landroid/util/MathUtils;->constrain(FFF)F

    move-result v2

    return v2
.end method

.method private getAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;)F
    .registers 6
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;

    .line 552
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, -0x2

    invoke-static {v0, p2, v1, v2}, Landroid/provider/Settings$System;->getFloatForUser(Landroid/content/ContentResolver;Ljava/lang/String;FI)F

    move-result v0

    return v0
.end method

.method private getBrightnessFromDataBase()F
    .registers 4

    .line 601
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getDefaultDisplayBrightness()F

    move-result v0

    .line 602
    .local v0, "brightness":F
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_14

    .line 603
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    int-to-float v0, v1

    .line 606
    :cond_14
    invoke-virtual {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getBrightnessForRemapDisable(F)F

    move-result v0

    .line 608
    return v0
.end method

.method private getBrightnessRampRate(Z)I
    .registers 3
    .param p1, "slowChange"    # Z

    .line 996
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-eqz p1, :cond_9

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getBrightnessRampRateSlow()I

    move-result v0

    goto :goto_d

    :cond_9
    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getBrightnessRampRateFast()I

    move-result v0

    :goto_d
    return v0
.end method

.method private getScreenStateInternal(Lcom/android/server/display/DisplayPowerState;)I
    .registers 7
    .param p1, "powerState"    # Lcom/android/server/display/DisplayPowerState;

    .line 954
    const/4 v0, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p1}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v1

    goto :goto_9

    :cond_8
    move v1, v0

    .line 955
    .local v1, "state":I
    :goto_9
    sget-boolean v2, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_50

    .line 956
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "ScreenState = "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ", fingerPrint block = "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    if-eqz v4, :cond_29

    move v4, v3

    goto :goto_2a

    :cond_29
    move v4, v0

    :goto_2a
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ", keyguard block = "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    .line 957
    invoke-virtual {v4}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v4

    invoke-interface {v4}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->isScreenOnUnblockerExist()Z

    move-result v4

    if-ne v4, v3, :cond_42

    move v4, v3

    goto :goto_43

    :cond_42
    move v4, v0

    :goto_43
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 956
    const-string v4, "Biometrics_DEBUG"

    invoke-static {v4, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 959
    :cond_50
    const/4 v2, 0x2

    if-ne v1, v2, :cond_65

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    if-nez v2, :cond_65

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v2}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v2

    invoke-interface {v2}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->isScreenOnUnblockerExist()Z

    move-result v2

    if-ne v2, v3, :cond_64

    goto :goto_65

    .line 962
    :cond_64
    return v3

    .line 960
    :cond_65
    :goto_65
    return v0
.end method

.method private hbmOverridesManulMode(I)Z
    .registers 5
    .param p1, "brightness"    # I

    .line 1756
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getMaxDisplayBrightness()F

    move-result v0

    float-to-int v0, v0

    .line 1758
    .local v0, "normalMaxBrightness":I
    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    int-to-float v2, v0

    cmpl-float v1, v1, v2

    if-ltz v1, :cond_10

    if-lt p1, v0, :cond_10

    const/4 v1, 0x1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    return v1
.end method

.method private isDozeState(I)Z
    .registers 3
    .param p1, "screenState"    # I

    .line 1019
    const/4 v0, 0x3

    if-eq p1, v0, :cond_9

    const/4 v0, 0x4

    if-ne p1, v0, :cond_7

    goto :goto_9

    :cond_7
    const/4 v0, 0x0

    goto :goto_a

    :cond_9
    :goto_9
    const/4 v0, 0x1

    :goto_a
    return v0
.end method

.method private isDsiSwitchForbiddenState(I)Z
    .registers 3
    .param p1, "state"    # I

    .line 1746
    const/4 v0, 0x3

    if-eq p1, v0, :cond_c

    const/4 v0, 0x6

    if-eq p1, v0, :cond_c

    const/4 v0, 0x4

    if-ne p1, v0, :cond_a

    goto :goto_c

    .line 1751
    :cond_a
    const/4 v0, 0x0

    return v0

    .line 1749
    :cond_c
    :goto_c
    const/4 v0, 0x1

    return v0
.end method

.method private isRealBrightnessNoAnimation(Z)Z
    .registers 14
    .param p1, "brightnessNoAnimation"    # Z

    .line 1488
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getLogicalDisplayMapper()Lcom/android/server/display/LogicalDisplayMapper;

    move-result-object v0

    .line 1489
    .local v0, "mapper":Lcom/android/server/display/LogicalDisplayMapper;
    if-eqz v0, :cond_43

    .line 1490
    invoke-virtual {v0}, Lcom/android/server/display/LogicalDisplayMapper;->getLogicalDisplays()Landroid/util/SparseArray;

    move-result-object v1

    .line 1491
    .local v1, "logicalDisplays":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/display/LogicalDisplay;>;"
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v2

    .line 1492
    .local v2, "count":I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_15
    if-ge v3, v2, :cond_43

    .line 1493
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/display/LogicalDisplay;

    .line 1494
    .local v4, "display":Lcom/android/server/display/LogicalDisplay;
    if-eqz v4, :cond_24

    invoke-virtual {v4}, Lcom/android/server/display/LogicalDisplay;->getPrimaryDisplayDeviceLocked()Lcom/android/server/display/DisplayDevice;

    move-result-object v5

    goto :goto_25

    :cond_24
    const/4 v5, 0x0

    .line 1495
    .local v5, "device":Lcom/android/server/display/DisplayDevice;
    :goto_25
    if-eqz v5, :cond_40

    .line 1496
    invoke-virtual {v5}, Lcom/android/server/display/DisplayDevice;->getDisplayDeviceInfoLocked()Lcom/android/server/display/DisplayDeviceInfo;

    move-result-object v6

    .line 1497
    .local v6, "info":Lcom/android/server/display/DisplayDeviceInfo;
    iget v7, v6, Lcom/android/server/display/DisplayDeviceInfo;->type:I

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ne v7, v9, :cond_33

    move v7, v9

    goto :goto_34

    :cond_33
    move v7, v8

    .line 1498
    .local v7, "isInternal":Z
    :goto_34
    iget v10, v6, Lcom/android/server/display/DisplayDeviceInfo;->state:I

    const/4 v11, 0x2

    if-ne v10, v11, :cond_3a

    move v8, v9

    .line 1499
    .local v8, "deviceIsON":Z
    :cond_3a
    if-eqz v7, :cond_40

    if-eqz v8, :cond_40

    .line 1500
    const/4 p1, 0x0

    .line 1501
    goto :goto_43

    .line 1492
    .end local v4    # "display":Lcom/android/server/display/LogicalDisplay;
    .end local v5    # "device":Lcom/android/server/display/DisplayDevice;
    .end local v6    # "info":Lcom/android/server/display/DisplayDeviceInfo;
    .end local v7    # "isInternal":Z
    .end local v8    # "deviceIsON":Z
    :cond_40
    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    .line 1506
    .end local v1    # "logicalDisplays":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/display/LogicalDisplay;>;"
    .end local v2    # "count":I
    .end local v3    # "i":I
    :cond_43
    :goto_43
    return p1
.end method

.method private synthetic lambda$setupPostProcessLocked$0()V
    .registers 2

    .line 446
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    return-void
.end method

.method public static notifyScreenStateToBiometrics(Z)V
    .registers 8
    .param p0, "isOff"    # Z

    .line 982
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "[notifyScreenStateToBiometrics] isOff = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Biometrics_DEBUG"

    invoke-static {v1, v0}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 984
    :try_start_18
    const-string v0, "com.android.server.biometrics.sensors.wakeup.OplusBiometricWakeupManager"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 985
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string/jumbo v1, "getOplusBiometricWakeupManager"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 986
    .local v1, "method":Ljava/lang/reflect/Method;
    new-array v3, v2, [Ljava/lang/Object;

    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 987
    .local v3, "obj":Ljava/lang/Object;
    const-string/jumbo v4, "notifyScreenStateToBiometrics"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v6, v5, v2

    invoke-virtual {v0, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    .line 988
    .end local v1    # "method":Ljava/lang/reflect/Method;
    .local v2, "method":Ljava/lang/reflect/Method;
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v2, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_47} :catch_49

    .line 991
    nop

    .end local v0    # "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v2    # "method":Ljava/lang/reflect/Method;
    .end local v3    # "obj":Ljava/lang/Object;
    goto :goto_4d

    .line 989
    :catch_49
    move-exception v0

    .line 990
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 992
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_4d
    return-void
.end method

.method private onGoToSleepFinish()V
    .registers 7

    .line 969
    const-string v0, "Biometrics_DEBUG"

    const-string v1, "[onGoToSleepFinish]"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 971
    :try_start_7
    const-string v0, "com.android.server.biometrics.sensors.wakeup.OplusBiometricWakeupManager"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 972
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string/jumbo v1, "getOplusBiometricWakeupManager"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 973
    .local v1, "method":Ljava/lang/reflect/Method;
    new-array v3, v2, [Ljava/lang/Object;

    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 974
    .local v3, "obj":Ljava/lang/Object;
    const-string/jumbo v4, "onGoToSleepFinish"

    new-array v5, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    .line 975
    .end local v1    # "method":Ljava/lang/reflect/Method;
    .local v4, "method":Ljava/lang/reflect/Method;
    new-array v1, v2, [Ljava/lang/Object;

    invoke-virtual {v4, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_2b} :catch_2d

    .line 978
    nop

    .end local v0    # "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v3    # "obj":Ljava/lang/Object;
    .end local v4    # "method":Ljava/lang/reflect/Method;
    goto :goto_31

    .line 976
    :catch_2d
    move-exception v0

    .line 977
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 979
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_31
    return-void
.end method

.method private onRateChange(I)V
    .registers 4
    .param p1, "rate"    # I

    .line 1129
    int-to-float v0, p1

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getBrightnessRampRateFast()I

    move-result v1

    int-to-float v1, v1

    invoke-static {v0, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v0

    if-nez v0, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    .line 1130
    .local v0, "isFastAnimating":Z
    :goto_11
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->onRateChange(Z)V

    .line 1131
    return-void
.end method

.method private onScreenEvent(IZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V
    .registers 6
    .param p1, "displayId"    # I
    .param p2, "isOn"    # Z
    .param p3, "powerRequest"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1168
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_9

    .line 1169
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/display/OplusAutomaticBrightnessController;->onScreenEvent(IZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V

    .line 1172
    :cond_9
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_12

    .line 1173
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p2, p3}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->onScreenEvent(ZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V

    .line 1176
    :cond_12
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    if-eqz v0, :cond_27

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    if-eqz v0, :cond_27

    .line 1177
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    invoke-interface {v0, p2}, Lcom/android/server/display/IDisplayDeviceConfigExt;->onScreenEvent(Z)V

    .line 1180
    :cond_27
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0, p2}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->onScreenEvent(Z)V

    .line 1181
    invoke-static {}, Lcom/android/server/display/feature/antidizzy/OplusFeatureAntiDizzy;->getInstance()Lcom/android/server/display/feature/antidizzy/OplusFeatureAntiDizzy;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/display/feature/antidizzy/OplusFeatureAntiDizzy;->onScreenEvent(IZ)V

    .line 1183
    if-nez p2, :cond_46

    invoke-static {p2, p3}, Lcom/android/server/display/util/OplusBrightnessUtils;->isFolding(ZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)Z

    move-result v0

    if-nez v0, :cond_46

    .line 1185
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1186
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateManualAutomaticModeStatus(F)V

    goto :goto_4f

    .line 1187
    :cond_46
    if-eqz p2, :cond_4f

    .line 1188
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getScreenBrightnessSetting()F

    move-result v0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateManualAutomaticModeStatus(F)V

    .line 1190
    :cond_4f
    :goto_4f
    invoke-static {}, Lcom/android/server/display/feature/stat/TrackManager;->getInstance()Lcom/android/server/display/feature/stat/TrackManager;

    move-result-object v0

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-virtual {v0, v1, p2}, Lcom/android/server/display/feature/stat/TrackManager;->onScreenEvent(IZ)V

    .line 1191
    return-void
.end method

.method private putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V
    .registers 6
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "adj"    # F

    .line 548
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, -0x2

    invoke-static {v0, p2, p3, v1}, Landroid/provider/Settings$System;->putFloatForUser(Landroid/content/ContentResolver;Ljava/lang/String;FI)Z

    .line 549
    return-void
.end method

.method private putStringForUser(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/String;

    .line 540
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_f

    .line 541
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, -0x2

    invoke-static {v0, p1, p2, v1}, Landroid/provider/Settings$System;->putStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;I)Z

    goto :goto_17

    .line 543
    :cond_f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "putStringForUser fail, mContext is null"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 545
    :goto_17
    return-void
.end method

.method private registerOplusDpcExtBroadcast(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;)V
    .registers 4
    .param p1, "receiver"    # Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    .line 1762
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1763
    .local v0, "actionList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    const-string v1, "android.intent.action.PACKAGE_ADDED"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1764
    const-string v1, "android.intent.action.PACKAGE_REMOVED"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1765
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->getInstance()Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;

    move-result-object v1

    invoke-virtual {v1, v0, p1}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->addListener(Ljava/util/List;Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver$Listener;)V

    .line 1766
    return-void
.end method

.method private setAutomaticScreenBrightness(II)V
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "brightness"    # I

    .line 1000
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    if-nez v0, :cond_13

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_13

    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    if-nez v0, :cond_e

    if-nez p1, :cond_13

    .line 1001
    :cond_e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p2}, Lcom/android/server/display/OplusAutomaticBrightnessController;->setAutomaticScreenBrightness(I)V

    .line 1003
    :cond_13
    return-void
.end method

.method private setBrightnessNoAnimation(Z)V
    .registers 5
    .param p1, "noAnimation"    # Z

    .line 1741
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setBrightnessNoAnimation, noAnimation = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1742
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 1743
    return-void
.end method

.method private shouldUseCurrentBrightness(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 1023
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_1c

    .line 1024
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->hasRemapDisable()Z

    move-result v0

    if-eqz v0, :cond_10

    if-nez p1, :cond_1c

    .line 1026
    :cond_10
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isFullScreenAodSupport()Z

    move-result v0

    if-eqz v0, :cond_1c

    const/4 v0, 0x1

    goto :goto_1d

    :cond_1c
    const/4 v0, 0x0

    .line 1023
    :goto_1d
    return v0
.end method

.method private statForBrightness(IFFIII)V
    .registers 14
    .param p1, "state"    # I
    .param p2, "from"    # F
    .param p3, "to"    # F
    .param p4, "reason"    # I
    .param p5, "targetRateType"    # I
    .param p6, "displayId"    # I

    .line 1148
    invoke-static {}, Lcom/android/server/display/feature/stat/TrackManager;->getInstance()Lcom/android/server/display/feature/stat/TrackManager;

    move-result-object v0

    iget-boolean v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    move v1, p1

    move v2, p2

    move v3, p3

    move v5, p4

    move v6, p6

    .end local p1    # "state":I
    .end local p2    # "from":F
    .end local p3    # "to":F
    .end local p4    # "reason":I
    .end local p6    # "displayId":I
    .local v1, "state":I
    .local v2, "from":F
    .local v3, "to":F
    .local v5, "reason":I
    .local v6, "displayId":I
    invoke-virtual/range {v0 .. v6}, Lcom/android/server/display/feature/stat/TrackManager;->setCurrTarget(IFFZII)V

    .line 1149
    const/4 p1, 0x3

    if-eq p5, p1, :cond_1c

    const/16 p1, 0x15

    if-eq p5, p1, :cond_1c

    const/16 p1, 0x16

    if-ne p5, p1, :cond_1a

    goto :goto_1c

    :cond_1a
    const/4 p1, 0x0

    goto :goto_1d

    :cond_1c
    :goto_1c
    const/4 p1, 0x1

    .line 1152
    .local p1, "isWindowType":Z
    :goto_1d
    invoke-static {}, Lcom/android/server/display/feature/stat/TrackManager;->getInstance()Lcom/android/server/display/feature/stat/TrackManager;

    move-result-object p2

    invoke-virtual {p2, v2, v3, p1}, Lcom/android/server/display/feature/stat/TrackManager;->onWinBrightnessChanged(FFZ)V

    .line 1153
    return-void
.end method

.method private unregisterOplusDpcExtBroadcast(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;)V
    .registers 3
    .param p1, "receiver"    # Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    .line 1769
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->getInstance()Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->removeListener(Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver$Listener;)V

    .line 1770
    return-void
.end method

.method private updateAnimationInfo(Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;)Z
    .registers 5
    .param p1, "state"    # Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;

    .line 1156
    const/4 v0, 0x0

    .line 1157
    .local v0, "importantChange":Z
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    if-eqz v1, :cond_15

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    .line 1158
    invoke-virtual {v1}, Lcom/android/server/display/animation/AnimationInfo;->getBarScale()F

    move-result v1

    invoke-virtual {p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getBrightnessBarScale()F

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_16

    .line 1159
    :cond_15
    const/4 v0, 0x1

    .line 1161
    :cond_16
    new-instance v1, Lcom/android/server/display/animation/AnimationInfo;

    invoke-direct {v1, p1}, Lcom/android/server/display/animation/AnimationInfo;-><init>(Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;)V

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    .line 1162
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    invoke-virtual {v1, v2}, Lcom/android/server/display/animation/AnimationInfo;->setUseAutoBrightness(Z)V

    .line 1163
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBootCompleted:Z

    invoke-virtual {v1, v2}, Lcom/android/server/display/animation/AnimationInfo;->setBootCompleted(Z)V

    .line 1164
    return v0
.end method

.method private declared-synchronized updateManualAutomaticModeStatus(F)V
    .registers 6
    .param p1, "brightness"    # F

    monitor-enter p0

    .line 1135
    :try_start_1
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalHbmSupported:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_30

    .line 1136
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getMaxDisplayBrightness()F

    move-result v0

    invoke-static {p1, v0}, Ljava/lang/Float;->compare(FF)I

    move-result v0

    const/4 v2, 0x1

    if-ltz v0, :cond_13

    move v0, v2

    goto :goto_14

    :cond_13
    move v0, v1

    .line 1137
    .local v0, "keepRegist":Z
    :goto_14
    iget-boolean v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    if-nez v3, :cond_28

    if-eqz v0, :cond_28

    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isFactoryVersion()Z

    move-result v3

    if-nez v3, :cond_28

    .line 1138
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v1

    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->setManualAutomaticMode(Z)V

    goto :goto_2f

    .line 1140
    .end local p0    # "this":Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
    :cond_28
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->setManualAutomaticMode(Z)V

    .line 1142
    .end local v0    # "keepRegist":Z
    :goto_2f
    goto :goto_37

    .line 1143
    :cond_30
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->setManualAutomaticMode(Z)V
    :try_end_37
    .catchall {:try_start_1 .. :try_end_37} :catchall_39

    .line 1145
    :goto_37
    monitor-exit p0

    return-void

    .line 1134
    .end local p1    # "brightness":F
    :catchall_39
    move-exception p1

    :try_start_3a
    monitor-exit p0
    :try_end_3b
    .catchall {:try_start_3a .. :try_end_3b} :catchall_39

    throw p1
.end method

.method private updateProvider(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;Lcom/android/server/display/DisplayPowerState;F)V
    .registers 12
    .param p1, "request"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .param p2, "powerState"    # Lcom/android/server/display/DisplayPowerState;
    .param p3, "target"    # F

    .line 634
    invoke-virtual {p2}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v0

    .line 635
    .local v0, "state":I
    float-to-int v1, p3

    .line 636
    .local v1, "temp":I
    iget v2, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->policy:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_a0

    .line 637
    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOnToDozeBrightness:I

    if-eq v2, v1, :cond_58

    .line 638
    invoke-virtual {p0, p3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getNitByBrightness(F)F

    move-result v2

    .line 639
    .local v2, "nit":F
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    float-to-double v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    filled-new-array {v5, v6}, [Ljava/lang/Object;

    move-result-object v5

    const-string v6, "[%f,%f]"

    invoke-static {v4, v6, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 640
    .local v4, "info":Ljava/lang/String;
    const-string/jumbo v5, "second_screen_brightness_on_to_doze"

    invoke-direct {p0, v5, v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putStringForUser(Ljava/lang/String;Ljava/lang/String;)V

    .line 641
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "updateProvider:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOnToDozeBrightness:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "->"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, p3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 642
    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOnToDozeBrightness:I

    .line 645
    .end local v2    # "nit":F
    .end local v4    # "info":Ljava/lang/String;
    :cond_58
    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightProvider:Z

    if-nez v2, :cond_aa

    .line 646
    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightBrightness:I

    int-to-float v2, v2

    invoke-virtual {p0, v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getNitByBrightness(F)F

    move-result v2

    .line 647
    .restart local v2    # "nit":F
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    float-to-double v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    iget v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightBrightness:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    filled-new-array {v5, v6}, [Ljava/lang/Object;

    move-result-object v5

    const-string v6, "[%f,%d]"

    invoke-static {v4, v6, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 648
    .restart local v4    # "info":Ljava/lang/String;
    const-string/jumbo v5, "second_screen_brightness_policy_bright"

    invoke-direct {p0, v5, v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putStringForUser(Ljava/lang/String;Ljava/lang/String;)V

    .line 649
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "updateProvider policy_bright:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 650
    iput-boolean v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightProvider:Z

    .line 651
    .end local v2    # "nit":F
    .end local v4    # "info":Ljava/lang/String;
    goto :goto_aa

    .line 652
    :cond_a0
    iget v2, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->policy:I

    const/4 v3, 0x3

    if-ne v2, v3, :cond_aa

    .line 653
    iput v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightBrightness:I

    .line 654
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPolicyBrightProvider:Z

    .line 656
    :cond_aa
    :goto_aa
    return-void
.end method


# virtual methods
.method public animateLongTakeStateChange(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;II)V
    .registers 5
    .param p1, "request"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .param p2, "oldState"    # I
    .param p3, "state"    # I

    .line 1031
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_9

    .line 1032
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->animateLongTakeStateChange(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;II)V

    .line 1034
    :cond_9
    return-void
.end method

.method public animateScreenBrightness(Lcom/android/server/display/RampAnimator$DualRampAnimator;FFFLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;Lcom/android/server/display/DisplayPowerState;)V
    .registers 15
    .param p2, "target"    # F
    .param p3, "sdrTarget"    # F
    .param p4, "rate"    # F
    .param p5, "request"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .param p6, "powerState"    # Lcom/android/server/display/DisplayPowerState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/display/RampAnimator$DualRampAnimator<",
            "Lcom/android/server/display/DisplayPowerState;",
            ">;FFF",
            "Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;",
            "Lcom/android/server/display/DisplayPowerState;",
            ")V"
        }
    .end annotation

    .line 661
    .local p1, "rampAnimator":Lcom/android/server/display/RampAnimator$DualRampAnimator;, "Lcom/android/server/display/RampAnimator$DualRampAnimator<Lcom/android/server/display/DisplayPowerState;>;"
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "animateScreenBrightness "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 662
    iget-boolean v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    iget-object v7, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAnimationInfo:Lcom/android/server/display/animation/AnimationInfo;

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    .end local p1    # "rampAnimator":Lcom/android/server/display/RampAnimator$DualRampAnimator;, "Lcom/android/server/display/RampAnimator$DualRampAnimator<Lcom/android/server/display/DisplayPowerState;>;"
    .end local p2    # "target":F
    .end local p3    # "sdrTarget":F
    .end local p4    # "rate":F
    .local v2, "rampAnimator":Lcom/android/server/display/RampAnimator$DualRampAnimator;, "Lcom/android/server/display/RampAnimator$DualRampAnimator<Lcom/android/server/display/DisplayPowerState;>;"
    .local v3, "target":F
    .local v4, "sdrTarget":F
    .local v5, "rate":F
    invoke-virtual/range {v2 .. v7}, Lcom/android/server/display/RampAnimator$DualRampAnimator;->animateToByUser(FFFZLcom/android/server/display/IAnimationInfo;)Z

    .line 663
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->hasRemapDisable()Z

    move-result p1

    if-eqz p1, :cond_3a

    .line 664
    invoke-virtual {p6}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result p1

    .line 665
    .local p1, "state":I
    iget p2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    const/4 p3, 0x1

    if-ne p2, p3, :cond_3a

    const/4 p2, 0x2

    if-ne p1, p2, :cond_3a

    .line 666
    invoke-direct {p0, p5, p6, v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateProvider(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;Lcom/android/server/display/DisplayPowerState;F)V

    .line 669
    .end local p1    # "state":I
    :cond_3a
    return-void
.end method

.method public applyOplusProximitySensorLocked(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;IZZZI)Z
    .registers 14
    .param p1, "powerRequest"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .param p2, "proximity"    # I
    .param p3, "proximitySensorEnabled"    # Z
    .param p4, "waitingForNegativeProximity"    # Z
    .param p5, "screenOffBecauseOfProximity"    # Z
    .param p6, "state"    # I

    .line 1303
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    .end local p1    # "powerRequest":Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .end local p2    # "proximity":I
    .end local p3    # "proximitySensorEnabled":Z
    .end local p4    # "waitingForNegativeProximity":Z
    .end local p5    # "screenOffBecauseOfProximity":Z
    .end local p6    # "state":I
    .local v1, "powerRequest":Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .local v2, "proximity":I
    .local v3, "proximitySensorEnabled":Z
    .local v4, "waitingForNegativeProximity":Z
    .local v5, "screenOffBecauseOfProximity":Z
    .local v6, "state":I
    invoke-virtual/range {v0 .. v6}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->applyOplusProximitySensorLocked(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;IZZZI)Z

    move-result p1

    return p1
.end method

.method public applydimmingbrightness(I)I
    .registers 3
    .param p1, "brightness"    # I

    .line 1285
    add-int/lit8 v0, p1, -0xa

    if-lez v0, :cond_7

    .line 1286
    add-int/lit8 p1, p1, -0xa

    goto :goto_9

    .line 1288
    :cond_7
    div-int/lit8 p1, p1, 0x2

    .line 1290
    :goto_9
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getMinDisplayBrightness()F

    move-result v0

    float-to-int v0, v0

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    return v0
.end method

.method public blockScreenOnByBiometrics(Ljava/lang/String;)V
    .registers 6
    .param p1, "reason"    # Ljava/lang/String;

    .line 833
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_1e

    .line 834
    const-string v0, "Biometrics_DEBUG"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "blockScreenOnByBiometrics, mPendingScreenOnUnblockerFromBiometrics = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 836
    :cond_1e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    if-nez v0, :cond_33

    .line 837
    const-string v0, "Screen on blocked by biometrics"

    const/4 v1, 0x0

    const-wide/32 v2, 0x20000

    invoke-static {v2, v3, v0, v1}, Landroid/os/Trace;->asyncTraceBegin(JLjava/lang/String;I)V

    .line 838
    new-instance v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Lcom/android/server/display/OplusDisplayPowerControllerExtImpl-IA;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    .line 840
    :cond_33
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    .line 843
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    monitor-enter v0

    .line 844
    :try_start_39
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "execuce mBlockReasonList.add reason: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 845
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 846
    invoke-static {}, Lcom/android/server/power/OplusScreenTimeEvent;->getInstance()Lcom/android/server/power/OplusScreenTimeEvent;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/power/OplusScreenTimeEvent;->reportBiometricBlockAdd()V

    .line 847
    monitor-exit v0

    .line 849
    return-void

    .line 847
    :catchall_60
    move-exception v1

    monitor-exit v0
    :try_end_62
    .catchall {:try_start_39 .. :try_end_62} :catchall_60

    throw v1
.end method

.method public caculateautoBrightnessAdjustment(F)F
    .registers 3
    .param p1, "autoBrightnessAdjustment"    # F

    .line 1274
    const/high16 v0, 0x3f800000    # 1.0f

    return v0
.end method

.method public cancelPwkBecauseProximity()V
    .registers 2

    .line 1484
    const-string v0, "CANCELED_beacuseProximity"

    invoke-static {v0}, Lcom/android/server/theia/TheiaUtil;->notePowerkeyProcessStagePoint(Ljava/lang/String;)V

    .line 1485
    return-void
.end method

.method public clampBrightness(F)F
    .registers 3
    .param p1, "brightness"    # F

    .line 1411
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsOplusTest:Z

    if-eqz v0, :cond_5

    .line 1412
    return p1

    .line 1415
    :cond_5
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-eqz v0, :cond_10

    .line 1416
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0, p1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->clampBrightness(F)F

    move-result v0

    return v0

    .line 1418
    :cond_10
    return p1
.end method

.method public clearPowerOnUX()V
    .registers 5

    .line 1926
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSetPowerOnUx:Z

    if-eqz v0, :cond_28

    .line 1927
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsSetUxWhenWindowUnblock:Z

    .line 1928
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSetPowerOnUx:Z

    .line 1929
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->isUafKeyThreadEnabled()Z

    move-result v1

    if-eqz v1, :cond_1d

    .line 1930
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    const/16 v1, 0x3f5

    invoke-virtual {v0, v1}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->releaseSysResource(I)Z

    goto :goto_28

    .line 1932
    :cond_1d
    invoke-static {}, Lcom/oplus/uifirst/OplusUIFirstManager;->getInstance()Lcom/oplus/uifirst/OplusUIFirstManager;

    move-result-object v1

    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxPid:I

    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxTid:I

    invoke-virtual {v1, v2, v3, v0}, Lcom/oplus/uifirst/OplusUIFirstManager;->setUxThreadValueByFile(III)V

    .line 1936
    :cond_28
    :goto_28
    return-void
.end method

.method public configure(ZFZZII)V
    .registers 14
    .param p1, "enable"    # Z
    .param p2, "adjustment"    # F
    .param p3, "dozing"    # Z
    .param p4, "userInitiatedChange"    # Z
    .param p5, "displayId"    # I
    .param p6, "state"    # I

    .line 690
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_f

    .line 691
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p6

    .end local p1    # "enable":Z
    .end local p2    # "adjustment":F
    .end local p3    # "dozing":Z
    .end local p4    # "userInitiatedChange":Z
    .end local p6    # "state":I
    .local v2, "enable":Z
    .local v3, "adjustment":F
    .local v4, "dozing":Z
    .local v5, "userInitiatedChange":Z
    .local v6, "state":I
    invoke-virtual/range {v1 .. v6}, Lcom/android/server/display/OplusAutomaticBrightnessController;->configure(ZFZZI)V

    goto :goto_14

    .line 690
    .end local v2    # "enable":Z
    .end local v3    # "adjustment":F
    .end local v4    # "dozing":Z
    .end local v5    # "userInitiatedChange":Z
    .end local v6    # "state":I
    .restart local p1    # "enable":Z
    .restart local p2    # "adjustment":F
    .restart local p3    # "dozing":Z
    .restart local p4    # "userInitiatedChange":Z
    .restart local p6    # "state":I
    :cond_f
    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p6

    .line 693
    .end local p1    # "enable":Z
    .end local p2    # "adjustment":F
    .end local p3    # "dozing":Z
    .end local p4    # "userInitiatedChange":Z
    .end local p6    # "state":I
    .restart local v2    # "enable":Z
    .restart local v3    # "adjustment":F
    .restart local v4    # "dozing":Z
    .restart local v5    # "userInitiatedChange":Z
    .restart local v6    # "state":I
    :goto_14
    iput v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenState:I

    .line 694
    return-void
.end method

.method public dismissEglContext(Lcom/android/server/display/ColorFade;I)V
    .registers 4
    .param p1, "colorFade"    # Lcom/android/server/display/ColorFade;
    .param p2, "displayId"    # I

    .line 1354
    if-eqz p2, :cond_d

    if-eqz p1, :cond_d

    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    if-eqz v0, :cond_9

    goto :goto_d

    .line 1358
    :cond_9
    invoke-virtual {p1}, Lcom/android/server/display/ColorFade;->dismissEglContext()V

    .line 1359
    return-void

    .line 1355
    :cond_d
    :goto_d
    return-void
.end method

.method public dump(Ljava/io/PrintWriter;)V
    .registers 4
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 923
    invoke-virtual {p1}, Ljava/io/PrintWriter;->println()V

    .line 924
    const-string v0, "OplusDisplayPowerControllerExtImpl:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 925
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mDisplayId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 926
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mPendingScreenOnUnblockerFromBiometrics="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 927
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mScreenOnBlockedByFace="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenOnBlockedByFace:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 928
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mPendingDisplayReadyBlocker="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 929
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-eqz v0, :cond_71

    .line 930
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0, p1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->dump(Ljava/io/PrintWriter;)V

    .line 932
    :cond_71
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    if-eqz v0, :cond_95

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    if-eqz v0, :cond_95

    .line 933
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayDeviceConfigExt;->getOplusDisplayDeviceConfig()Ljava/lang/Object;

    move-result-object v0

    .line 934
    .local v0, "obj":Ljava/lang/Object;
    if-eqz v0, :cond_95

    instance-of v1, v0, Lcom/android/server/display/config/device/OplusDisplayDeviceConfig;

    if-eqz v1, :cond_95

    .line 935
    move-object v1, v0

    check-cast v1, Lcom/android/server/display/config/device/OplusDisplayDeviceConfig;

    .line 936
    .local v1, "oplusDisplayDeviceConfig":Lcom/android/server/display/config/device/OplusDisplayDeviceConfig;
    if-eqz v1, :cond_95

    .line 937
    invoke-virtual {v1, p1}, Lcom/android/server/display/config/device/OplusDisplayDeviceConfig;->dump(Ljava/io/PrintWriter;)V

    .line 941
    .end local v0    # "obj":Ljava/lang/Object;
    .end local v1    # "oplusDisplayDeviceConfig":Lcom/android/server/display/config/device/OplusDisplayDeviceConfig;
    :cond_95
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_9e

    .line 942
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->dump(Ljava/io/PrintWriter;)V

    .line 945
    :cond_9e
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->getInstance()Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver;->dump(Ljava/io/PrintWriter;)V

    .line 946
    return-void
.end method

.method public getAdjustmentSetting(Landroid/content/Context;F)F
    .registers 10
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "pendingAdj"    # F

    .line 613
    move v0, p2

    .line 614
    .local v0, "adj":F
    const-string/jumbo v1, "second_screen_auto_brightness_adj"

    invoke-direct {p0, p1, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;)F

    move-result v2

    .line 615
    .local v2, "secondAdj":F
    iget-boolean v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAutoAdjChanged:Z

    const-string v4, " state="

    const/4 v5, 0x0

    if-eqz v3, :cond_3f

    .line 616
    cmpl-float v3, v0, v2

    if-eqz v3, :cond_16

    .line 617
    invoke-direct {p0, p1, v1, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V

    .line 619
    :cond_16
    iput-boolean v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAutoAdjChanged:Z

    .line 620
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "getAdjustmentSetting pengdingAdj="

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenState:I

    invoke-static {v6}, Landroid/view/Display;->stateToString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 622
    :cond_3f
    iget-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSecondAdjChanged:Z

    if-eqz v1, :cond_77

    .line 623
    cmpl-float v1, v0, v2

    if-eqz v1, :cond_4e

    .line 624
    move v0, v2

    .line 625
    const-string/jumbo v1, "screen_auto_brightness_adj"

    invoke-direct {p0, p1, v1, v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V

    .line 627
    :cond_4e
    iput-boolean v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSecondAdjChanged:Z

    .line 628
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "getAdjustmentSetting adj="

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenState:I

    invoke-static {v4}, Landroid/view/Display;->stateToString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 630
    :cond_77
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v1

    if-eqz v1, :cond_7f

    const/4 v1, 0x0

    goto :goto_80

    :cond_7f
    move v1, v0

    :goto_80
    return v1
.end method

.method public getAutomaticScreenBrightness()F
    .registers 3

    .line 698
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-nez v0, :cond_f

    .line 699
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "mOplusAutomaticBrightnessController invalid "

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 700
    const/high16 v0, -0x40800000    # -1.0f

    return v0

    .line 702
    :cond_f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0}, Lcom/android/server/display/OplusAutomaticBrightnessController;->getAutomaticScreenBrightness()F

    move-result v0

    return v0
.end method

.method public getBrightnessByNit(F)F
    .registers 4
    .param p1, "nit"    # F

    .line 1449
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-nez v0, :cond_e

    .line 1450
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string v1, "can not find mBrightnessModel!!!"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1451
    const/high16 v0, -0x40800000    # -1.0f

    return v0

    .line 1453
    :cond_e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    const-string/jumbo v1, "nits"

    invoke-interface {v0, v1, p1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getValueByCurve(Ljava/lang/String;F)F

    move-result v0

    return v0
.end method

.method public getBrightnessForRemapDisable(F)F
    .registers 4
    .param p1, "currScreenBrightnessSetting"    # F

    .line 489
    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-static {v0, p1, v1}, Lcom/android/server/display/util/OplusBrightnessUtils;->getBrightnessForRemapDisable(IFLcom/android/server/display/IDisplayBrightnessModelExt;)F

    move-result v0

    return v0
.end method

.method public getCurrentBrightness()F
    .registers 3

    .line 707
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-nez v0, :cond_f

    .line 708
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "mOplusAutomaticBrightnessController invalid "

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 709
    const/high16 v0, -0x40800000    # -1.0f

    return v0

    .line 711
    :cond_f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0}, Lcom/android/server/display/OplusAutomaticBrightnessController;->getCurrentBrightness()F

    move-result v0

    return v0
.end method

.method public getDCModeStatus()Z
    .registers 6

    .line 1466
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, -0x2

    const-string v2, "display_dc_settings_switch"

    const/4 v3, 0x0

    invoke-static {v0, v2, v3, v1}, Landroid/provider/Settings$Secure;->getIntForUser(Landroid/content/ContentResolver;Ljava/lang/String;II)I

    move-result v0

    .line 1468
    .local v0, "mode":I
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "OPLUS_DC_MODE  mode = "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1469
    if-lez v0, :cond_29

    const/4 v3, 0x1

    :cond_29
    return v3
.end method

.method public getDefaultDisplayBrightness()F
    .registers 2

    .line 1575
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getDefaultBrightness()F

    move-result v0

    return v0
.end method

.method public getDynamicBarUpdateBrightness(F)F
    .registers 4
    .param p1, "brightness"    # F

    .line 1397
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    if-eqz v0, :cond_14

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-nez v0, :cond_9

    goto :goto_14

    .line 1400
    :cond_9
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->clampAbsoluteBrightness(F)F

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;->getUpdateBrightnessState(F)F

    move-result v0

    return v0

    .line 1398
    :cond_14
    :goto_14
    return p1
.end method

.method public getDynamicMaxBrightness(F)F
    .registers 3
    .param p1, "defMax"    # F

    .line 1838
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    if-nez v0, :cond_5

    .line 1839
    return p1

    .line 1841
    :cond_5
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;->getUpdateBrightnessState(F)F

    move-result v0

    return v0
.end method

.method public getEdrType()I
    .registers 2

    .line 1195
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_b

    .line 1196
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->getEdrType()I

    move-result v0

    return v0

    .line 1198
    :cond_b
    const/4 v0, 0x0

    return v0
.end method

.method public getGlobalHbmSellMode()I
    .registers 2

    .line 1373
    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalHbmSellMode:I

    return v0
.end method

.method public getIgnoreReadyState()Z
    .registers 2

    .line 1968
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIgnoreReadyState:Z

    return v0
.end method

.method public getMaxDisplayBrightness()F
    .registers 2

    .line 1570
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v0

    return v0
.end method

.method public getMaximumScreenBrightnessSetting()I
    .registers 2

    .line 1237
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getMaxDisplayBrightness()F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method public getMinDisplayBrightness()F
    .registers 2

    .line 1580
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMinBrightness()F

    move-result v0

    return v0
.end method

.method public getNitByBrightness(F)F
    .registers 4
    .param p1, "brightness"    # F

    .line 1458
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-nez v0, :cond_e

    .line 1459
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string v1, "can not find mBrightnessModel!!!"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1460
    const/high16 v0, -0x40800000    # -1.0f

    return v0

    .line 1462
    :cond_e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    const-string v1, "backlights"

    invoke-interface {v0, v1, p1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getValueByCurve(Ljava/lang/String;F)F

    move-result v0

    return v0
.end method

.method public getPhysicalDisplayToken(J)Landroid/os/IBinder;
    .registers 4
    .param p1, "physicalDisplayId"    # J

    .line 1614
    invoke-static {p1, p2}, Lcom/android/server/display/DisplayControl;->getPhysicalDisplayToken(J)Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public getResetTemporaryStrategyStatus()Z
    .registers 2

    .line 1654
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNeedResetTemporaryStrategy:Z

    return v0
.end method

.method public getScreenBrightnessSetting()F
    .registers 3

    .line 590
    invoke-direct {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getBrightnessFromDataBase()F

    move-result v0

    .line 593
    .local v0, "brightness":F
    iget-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    if-nez v1, :cond_c

    .line 594
    invoke-virtual {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getDynamicBarUpdateBrightness(F)F

    move-result v0

    .line 597
    :cond_c
    return v0
.end method

.method public getScreenNormalMaxBrightness()F
    .registers 2

    .line 484
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v0

    return v0
.end method

.method public getScreenState()I
    .registers 2

    .line 950
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerState:Lcom/android/server/display/DisplayPowerState;

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getScreenStateInternal(Lcom/android/server/display/DisplayPowerState;)I

    move-result v0

    return v0
.end method

.method public getTotalDisplayBrightness()F
    .registers 2

    .line 1585
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getTotalBrightness()F

    move-result v0

    return v0
.end method

.method public getUseProximityForceSuspendState(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 1320
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->getUseProximityForceSuspendState(I)Z

    move-result v0

    return v0
.end method

.method public handleBrightnessModeChange(I)V
    .registers 3
    .param p1, "screenBrightnessModeSetting"    # I

    .line 1851
    const/4 v0, 0x1

    if-ne p1, v0, :cond_4

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    .line 1852
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_10

    .line 1853
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->handleBrightnessModeChange(I)V

    .line 1856
    :cond_10
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_19

    .line 1857
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p1}, Lcom/android/server/display/OplusAutomaticBrightnessController;->handleBrightnessModeChange(I)V

    .line 1859
    :cond_19
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getScreenBrightnessSetting()F

    move-result v0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateManualAutomaticModeStatus(F)V

    .line 1860
    const/16 v0, 0xf5

    invoke-static {v0, p1}, Lcom/android/server/display/util/OplusDisplayPanelFeatureHelper;->setDisplayPanelFeatureValue(II)V

    .line 1861
    return-void
.end method

.method public handleDisplayChanged(ZZFIILcom/android/server/display/brightness/BrightnessReason;)V
    .registers 29
    .param p1, "slowChange"    # Z
    .param p2, "enabled"    # Z
    .param p3, "brightnessFloat"    # F
    .param p4, "state"    # I
    .param p5, "displayId"    # I
    .param p6, "reason"    # Lcom/android/server/display/brightness/BrightnessReason;

    .line 1049
    move-object/from16 v0, p0

    move/from16 v7, p3

    move/from16 v6, p5

    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v1, :cond_1c

    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    move/from16 v9, p4

    invoke-virtual {v1, v9}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->isBlockedScreenOnForPanoramic(I)Z

    move-result v1

    if-eqz v1, :cond_1e

    .line 1050
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string v2, "OplusFeaturePanoramicBrightness handleDisplayChanged In PowerBlock state"

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1051
    return-void

    .line 1049
    :cond_1c
    move/from16 v9, p4

    .line 1054
    :cond_1e
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-nez v1, :cond_2b

    .line 1055
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "mOplusAutomaticBrightnessController == null invalid !!!"

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1056
    return-void

    .line 1059
    :cond_2b
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-nez v1, :cond_38

    .line 1060
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "mBrightnessModel == null invalid !!!"

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1061
    return-void

    .line 1063
    :cond_38
    float-to-int v14, v7

    .line 1064
    .local v14, "brightness":I
    invoke-direct {v0, v6, v14}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setAutomaticScreenBrightness(II)V

    .line 1066
    invoke-direct {v0, v14}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->hbmOverridesManulMode(I)Z

    move-result v15

    .line 1067
    .local v15, "isHbmOverridesManulMode":Z
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getBrightnessRampRateSlow()I

    move-result v1

    .line 1069
    .local v1, "initialRate":I
    if-nez v15, :cond_4e

    .line 1070
    invoke-direct/range {p0 .. p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getBrightnessRampRate(Z)I

    move-result v1

    move v8, v1

    goto :goto_4f

    .line 1069
    :cond_4e
    move v8, v1

    .line 1073
    .end local v1    # "initialRate":I
    .local v8, "initialRate":I
    :goto_4f
    int-to-float v1, v14

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getNitByBrightness(F)F

    move-result v10

    .line 1074
    .local v10, "dpcNit":F
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v1}, Lcom/android/server/display/OplusAutomaticBrightnessController;->getAmbientLuxValid()Z

    move-result v11

    .line 1075
    .local v11, "luxValid":Z
    new-instance v1, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    invoke-direct {v1}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;-><init>()V

    move-object v12, v1

    .line 1076
    .local v12, "builder":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;
    invoke-virtual {v12, v10}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setNit(F)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    .line 1077
    invoke-virtual {v1, v10}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setDpcNit(F)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    .line 1078
    invoke-virtual {v1, v6}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setDisplayId(I)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget-boolean v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    .line 1079
    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setIsAutoBrightness(Z)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    .line 1080
    invoke-virtual {v1, v11}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setAmbientLuxValid(Z)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget-boolean v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    if-nez v2, :cond_85

    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    .line 1081
    invoke-virtual {v2}, Lcom/android/server/display/OplusAutomaticBrightnessController;->isDragging()Z

    move-result v2

    if-eqz v2, :cond_83

    goto :goto_85

    :cond_83
    const/4 v2, 0x0

    goto :goto_86

    :cond_85
    :goto_85
    const/4 v2, 0x1

    :goto_86
    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setDragging(Z)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRateType:I

    .line 1082
    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setLastRateType(I)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurPowerReq:Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1083
    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setPowerReq(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1084
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    iget-object v3, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    invoke-virtual {v1, v2, v3}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setNoAnimation(ZZ)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mUniqueDisplayId:Ljava/lang/String;

    .line 1085
    invoke-virtual {v0, v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isPrimaryDisplay(Ljava/lang/String;)Z

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setPrimaryDisplay(Z)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;

    move-result-object v1

    .line 1086
    invoke-virtual/range {p6 .. p6}, Lcom/android/server/display/brightness/BrightnessReason;->getTag()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;->setWindowManagerBrightnessOverrideTag(Ljava/lang/CharSequence;)V

    .line 1087
    iget-object v1, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    invoke-virtual {v1, v12, v8}, Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;->postProcessing(Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;I)Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;

    move-result-object v13

    .line 1089
    .local v13, "newBrightnessState":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;
    invoke-direct {v0, v13}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateAnimationInfo(Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;)Z

    move-result v16

    .line 1091
    .local v16, "animationInfoChanged":Z
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getBrightness()F

    move-result v1

    .line 1092
    .local v1, "targetBrightness":F
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getSdrBrightness()F

    move-result v2

    .line 1093
    .local v2, "targetSdrBrightness":F
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getRateType()I

    move-result v5

    .line 1094
    .local v5, "targetRateType":I
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getRate()I

    move-result v3

    .line 1095
    .local v3, "targetRate":I
    move v4, v3

    .end local v3    # "targetRate":I
    .local v4, "targetRate":I
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getNit()F

    move-result v3

    .line 1096
    .local v3, "targetNit":F
    move/from16 v17, v2

    .end local v2    # "targetSdrBrightness":F
    .local v17, "targetSdrBrightness":F
    iget v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentNit:F

    .line 1097
    move/from16 v18, v4

    .end local v4    # "targetRate":I
    .local v18, "targetRate":I
    invoke-virtual/range {p6 .. p6}, Lcom/android/server/display/brightness/BrightnessReason;->getReason()I

    move-result v4

    .line 1096
    move/from16 v21, v9

    move v9, v1

    move/from16 v1, v21

    move/from16 v21, v17

    move/from16 v17, v14

    move/from16 v14, v21

    move/from16 v21, v18

    move/from16 v18, v15

    move/from16 v15, v21

    .end local v1    # "targetBrightness":F
    .local v9, "targetBrightness":F
    .local v14, "targetSdrBrightness":F
    .local v15, "targetRate":I
    .local v17, "brightness":I
    .local v18, "isHbmOverridesManulMode":Z
    invoke-direct/range {v0 .. v6}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->statForBrightness(IFFIII)V

    .line 1098
    int-to-float v1, v15

    .line 1099
    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->isDragging()Z

    move-result v2

    iget-boolean v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    iget-object v6, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 1098
    invoke-static {v1, v2, v4, v5, v6}, Lcom/android/server/display/util/OplusBrightnessUtils;->isAutoStepper(FZZILcom/android/server/display/IDisplayBrightnessModelExt;)Z

    move-result v1

    .line 1100
    .local v1, "isAutoStepper":Z
    iget v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    invoke-static {v9, v2}, Lcom/android/internal/display/BrightnessSynchronizer;->floatEquals(FF)Z

    move-result v2

    if-eqz v2, :cond_120

    iget v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentSdrBrightness:F

    .line 1101
    invoke-static {v14, v2}, Lcom/android/internal/display/BrightnessSynchronizer;->floatEquals(FF)Z

    move-result v2

    if-eqz v2, :cond_120

    if-eqz v16, :cond_114

    goto :goto_120

    :cond_114
    move/from16 v19, v1

    move/from16 v20, v8

    move v2, v10

    move v1, v11

    move-object v4, v12

    move-object v6, v13

    move v11, v3

    move v3, v9

    goto/16 :goto_209

    .line 1103
    :cond_120
    :goto_120
    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v2}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v2

    invoke-virtual {v13}, Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;->getRate()I

    move-result v4

    int-to-float v4, v4

    invoke-interface {v2, v9, v14, v4}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->animateScreenBrightness(FFF)V

    .line 1104
    iget-object v2, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Animating brightness: hdrBrightness target="

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v6, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, "->"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v19, v1

    .end local v1    # "isAutoStepper":Z
    .local v19, "isAutoStepper":Z
    const-string v1, ",sdrBrightness target="

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentSdrBrightness:F

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ",rate="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRate:I

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1106
    if-eqz v19, :cond_176

    const-string v4, "auto"

    goto :goto_17a

    :cond_176
    invoke-static {v15}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    :goto_17a
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ",rate type = "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRateType:I

    .line 1107
    invoke-static {v4}, Lcom/android/server/display/util/OplusBrightnessUtils;->totalRateTypeToString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1108
    invoke-static {v5}, Lcom/android/server/display/util/OplusBrightnessUtils;->totalRateTypeToString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ",byUser="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mUniqueDisplayId:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " , brightness from dpc = "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1104
    invoke-static {v2, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1110
    move v1, v8

    .end local v8    # "initialRate":I
    .local v1, "initialRate":I
    invoke-static {}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->getInstance()Lcom/android/server/display/feature/viewer/BrightnessViewer;

    move-result-object v8

    move v2, v10

    .end local v10    # "dpcNit":F
    .local v2, "dpcNit":F
    float-to-int v10, v9

    move-object v4, v12

    .end local v12    # "builder":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;
    .local v4, "builder":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState$Builder;
    iget-boolean v12, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    move-object v6, v13

    .end local v13    # "newBrightnessState":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;
    .local v6, "newBrightnessState":Lcom/android/server/display/feature/postprocess/OplusDisplayBrightnessState;
    invoke-virtual/range {p6 .. p6}, Lcom/android/server/display/brightness/BrightnessReason;->getReason()I

    move-result v13

    move/from16 v20, v1

    move v1, v11

    move v11, v3

    move v3, v9

    move/from16 v9, p4

    .end local v9    # "targetBrightness":F
    .local v1, "luxValid":Z
    .local v3, "targetBrightness":F
    .local v11, "targetNit":F
    .local v20, "initialRate":I
    invoke-virtual/range {v8 .. v13}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->setCurrTarget(IIFZI)V

    .line 1111
    invoke-static {}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->getInstance()Lcom/android/server/display/feature/viewer/BrightnessViewer;

    move-result-object v8

    float-to-int v9, v3

    float-to-int v10, v3

    iget-boolean v12, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mWinOverride:Z

    invoke-virtual {v8, v9, v10, v11, v12}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->onWinBrightnessChanged(IIFZ)V

    .line 1112
    invoke-static {}, Lcom/android/server/display/feature/viewer/BrightnessRecorder;->getInstance()Lcom/android/server/display/feature/viewer/BrightnessRecorder;

    move-result-object v8

    float-to-int v9, v3

    float-to-int v10, v3

    iget-boolean v12, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mWinOverride:Z

    invoke-virtual {v8, v9, v10, v12}, Lcom/android/server/display/feature/viewer/BrightnessRecorder;->updateRecorderWin(IIZ)V

    .line 1114
    iget-object v8, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    if-eqz v8, :cond_1fc

    .line 1115
    iget-object v8, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    float-to-int v9, v3

    invoke-interface {v8, v9, v11}, Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;->setTargetBrightness(IF)V

    .line 1118
    :cond_1fc
    invoke-direct {v0, v15}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->onRateChange(I)V

    .line 1120
    iput v3, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    .line 1121
    iput v11, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentNit:F

    .line 1122
    iput v14, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentSdrBrightness:F

    .line 1123
    iput v5, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRateType:I

    .line 1124
    iput v15, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRate:I

    .line 1126
    :goto_209
    return-void
.end method

.method public handlePwkMonitorForTheia(IZ)V
    .registers 6
    .param p1, "state"    # I
    .param p2, "isOff"    # Z

    .line 1474
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LIGHT_setScreenState_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1475
    .local v0, "stagePoint":Ljava/lang/String;
    const/4 v1, 0x2

    if-ne p1, v1, :cond_2a

    .line 1476
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_ON"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_3f

    .line 1477
    :cond_2a
    if-eqz p2, :cond_3f

    .line 1478
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_OFF"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1480
    :cond_3f
    :goto_3f
    invoke-static {v0}, Lcom/android/server/theia/TheiaUtil;->notePowerkeyProcessStagePoint(Ljava/lang/String;)V

    .line 1481
    return-void
.end method

.method public handleSetTemporaryBrightnessMessage(FLjava/lang/String;I)F
    .registers 8
    .param p1, "brightness"    # F
    .param p2, "msg"    # Ljava/lang/String;
    .param p3, "displayId"    # I

    .line 1423
    move v0, p1

    .line 1424
    .local v0, "resultBrightness":F
    invoke-virtual {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isSpecialAdj(F)Z

    move-result v1

    if-nez v1, :cond_3d

    .line 1425
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    invoke-virtual {v1, v0}, Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;->getUpdateBrightnessState(F)F

    move-result v0

    .line 1426
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " to "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " displayId="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1429
    :cond_3d
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-static {p3, v0, v1}, Lcom/android/server/display/util/OplusBrightnessUtils;->getBrightnessForRemapDisable(IFLcom/android/server/display/IDisplayBrightnessModelExt;)F

    move-result v0

    .line 1430
    return v0
.end method

.method public hasBiometricsBlockedReason(Ljava/lang/String;)Z
    .registers 4
    .param p1, "reason"    # Ljava/lang/String;

    .line 882
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    monitor-enter v0

    .line 883
    :try_start_3
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    monitor-exit v0

    return v1

    .line 884
    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public hasRemapDisable()Z
    .registers 2

    .line 494
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->hasRemapDisable()Z

    move-result v0

    return v0
.end method

.method public init(Landroid/content/Context;IZLcom/android/server/display/DisplayDeviceConfig;)V
    .registers 8
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "displayId"    # I
    .param p3, "bootCompleted"    # Z
    .param p4, "config"    # Lcom/android/server/display/DisplayDeviceConfig;

    .line 308
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    .line 309
    iput p2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    .line 310
    iput-object p4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    .line 311
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "[display="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "]"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    .line 312
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->hasRemapDisable()Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    .line 313
    iput-boolean p3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBootCompleted:Z

    .line 314
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayDeviceConfigExt;->getBrightnessModel()Lcom/android/server/display/IDisplayBrightnessModelExt;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 315
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getPhysicalDisplayId()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    .line 316
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    const-string/jumbo v1, "persist.sys.assert.panic"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setDebug(Z)V

    .line 317
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    if-nez v0, :cond_6a

    .line 318
    sget-object v0, Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;->DEFAULT:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    .line 322
    :cond_6a
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->VRR_ENABLED:Z

    if-eqz v0, :cond_7a

    .line 323
    new-instance v0, Lcom/oplus/vrr/OPlusRefreshRateManager;

    invoke-direct {v0}, Lcom/oplus/vrr/OPlusRefreshRateManager;-><init>()V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    .line 324
    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    invoke-virtual {p0, v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setActivePhysicalDisplayId(J)V

    .line 330
    :cond_7a
    const-class v0, Landroid/os/PowerManagerInternal;

    invoke-static {v0}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManagerInternal;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManagerInternal:Landroid/os/PowerManagerInternal;

    .line 331
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "power"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    .line 335
    new-instance v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Lcom/android/server/display/OplusDisplayPowerControllerExtImpl-IA;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBroadcastReceiver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    .line 336
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBroadcastReceiver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->registerOplusDpcExtBroadcast(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;)V

    .line 337
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_b5

    .line 338
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0xc070057

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplaySpecialPkgList:Ljava/util/List;

    .line 340
    :cond_b5
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "mDisplaySpecialPkgList = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplaySpecialPkgList:Ljava/util/List;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 341
    return-void
.end method

.method public initAutomaticBrightnessController(Lcom/android/server/display/AutomaticBrightnessController$Callbacks;Landroid/os/Looper;F)Lcom/android/server/display/IOplusAutomaticBrightnessController;
    .registers 11
    .param p1, "callbacks"    # Lcom/android/server/display/AutomaticBrightnessController$Callbacks;
    .param p2, "looper"    # Landroid/os/Looper;
    .param p3, "dozeScaleFactor"    # F

    .line 1628
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-nez v0, :cond_2c

    .line 1629
    new-instance v1, Lcom/android/server/display/OplusAutomaticBrightnessController;

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    iget-boolean v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBootCompleted:Z

    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    move-object v6, p0

    invoke-direct/range {v1 .. v6}, Lcom/android/server/display/OplusAutomaticBrightnessController;-><init>(Landroid/content/Context;IZLcom/android/server/display/IDisplayBrightnessModelExt;Lcom/android/server/display/IOplusDisplayPowerControllerExt;)V

    iput-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    .line 1631
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/display/OplusAutomaticBrightnessController;->init(Lcom/android/server/display/AutomaticBrightnessController$Callbacks;Landroid/os/Looper;F)V

    .line 1632
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->addListener(Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter$Listener;)V

    .line 1633
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->addAmbientResetListener(Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter$AmbientResetListener;)V

    goto :goto_2d

    .line 1628
    :cond_2c
    move-object v6, p0

    .line 1636
    :goto_2d
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMinBrightness()F

    move-result v1

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setScreenBrightnessRangeMinimum(F)V

    .line 1637
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getTotalBrightness()F

    move-result v1

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setScreenBrightnessRangeMaximum(F)V

    .line 1638
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v1

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setScreenBrightnessNormalMaximum(F)V

    .line 1639
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    iget-object v1, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v1}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getDefaultBrightness()F

    move-result v1

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setScreenBrightnessDefault(F)V

    .line 1640
    iget-boolean v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    if-eqz v0, :cond_7d

    iget v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    if-eqz v0, :cond_7d

    .line 1641
    invoke-static {}, Landroid/hardware/display/OplusDisplayManager;->getInstance()Landroid/hardware/display/OplusDisplayManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/hardware/display/OplusDisplayManager;->getNormalMaxDisplayBrightness(I)F

    move-result v0

    iput v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDefaultNormalMaxBrightness:F

    goto :goto_85

    .line 1643
    :cond_7d
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v0

    iput v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDefaultNormalMaxBrightness:F

    .line 1645
    :goto_85
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "initAutomaticBrightnessController min brightness:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMinBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",max brightness:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 1646
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",hbmMax:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 1647
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getTotalBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",dft:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 1648
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getDefaultBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",dmax:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDefaultNormalMaxBrightness:F

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1645
    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1650
    iget-object v0, v6, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    return-object v0
.end method

.method public initParameters(Landroid/os/Handler;)V
    .registers 6
    .param p1, "handler"    # Landroid/os/Handler;

    .line 363
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    invoke-static {v0, v1, v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->getInstance(Landroid/content/Context;Lcom/android/server/display/DisplayPowerController;Landroid/os/Handler;)Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    .line 364
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    if-eqz v0, :cond_38

    .line 365
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    const/16 v1, 0x3eb

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->removeMessages(I)V

    .line 366
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 367
    .local v0, "registerDisplayListererMsg":Landroid/os/Message;
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    const-wide/16 v2, 0x7d0

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 368
    new-instance v1, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    invoke-direct {v1, p0, v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Handler;)V

    iput-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    .line 369
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;->register(Landroid/content/ContentResolver;)V

    .line 371
    .end local v0    # "registerDisplayListererMsg":Landroid/os/Message;
    :cond_38
    return-void
.end method

.method public interceptProximityEvent()Z
    .registers 2

    .line 1330
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->interceptProximityEvent()Z

    move-result v0

    return v0
.end method

.method public isBlockDisplayByBiometrics()Z
    .registers 2

    .line 762
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    return v0
.end method

.method public isBlockScreenOnByBiometrics()Z
    .registers 2

    .line 756
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public isBlockedBySideFingerprint()Z
    .registers 3

    .line 1596
    const-string/jumbo v0, "persist.vendor.fingerprint.sensor_type"

    const-string/jumbo v1, "unknow"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "side"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    .line 1597
    sget-object v0, Lcom/android/server/power/IOplusPowerManagerServiceFeature;->DEFAULT:Lcom/android/server/power/IOplusPowerManagerServiceFeature;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/power/IOplusPowerManagerServiceFeature;

    invoke-interface {v0}, Lcom/android/server/power/IOplusPowerManagerServiceFeature;->isBlockedByFingerprint()Z

    move-result v0

    return v0

    .line 1599
    :cond_20
    const/4 v0, 0x0

    return v0
.end method

.method public isDCMode()Z
    .registers 2

    .line 1368
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getDCModeStatus()Z

    move-result v0

    return v0
.end method

.method public isFactoryVersion()Z
    .registers 2

    .line 1846
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isFactoryVersion()Z

    move-result v0

    return v0
.end method

.method public isFolding()Z
    .registers 2

    .line 1808
    sget-object v0, Lcom/android/server/wm/IOplusWindowAnimationManager;->DEFAULT:Lcom/android/server/wm/IOplusWindowAnimationManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusWindowAnimationManager;

    invoke-interface {v0}, Lcom/android/server/wm/IOplusWindowAnimationManager;->getDeviceFolding()Z

    move-result v0

    return v0
.end method

.method public isIgnoreProximity()Z
    .registers 3

    .line 1813
    const/4 v0, 0x0

    .line 1814
    .local v0, "isIgnoreProximity":Z
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->isGameModeOn()Z

    move-result v1

    or-int/2addr v0, v1

    .line 1815
    return v0
.end method

.method public isOplusTest()Z
    .registers 2

    .line 2016
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsOplusTest:Z

    return v0
.end method

.method public isPrimaryDisplay(Ljava/lang/String;)Z
    .registers 3
    .param p1, "uniqueId"    # Ljava/lang/String;

    .line 673
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/display/util/OplusDisplayState;->isPrimaryDisplay(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public isRemapDisplayDevice()Z
    .registers 2

    .line 1976
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->isRemapDisabledDisplay()Z

    move-result v0

    return v0
.end method

.method public isSilentRebootFirstGoToSleep(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 1342
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->isSilentRebootFirstGoToSleep(I)Z

    move-result v0

    return v0
.end method

.method public isSpecialAdj(F)Z
    .registers 3
    .param p1, "value"    # F

    .line 1242
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    if-eqz v0, :cond_f

    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    if-eqz v0, :cond_f

    .line 1243
    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDefaultNormalMaxBrightness:F

    invoke-static {p1, v0}, Lcom/android/server/display/util/OplusBrightnessUtils;->isSpecialAdj(FF)Z

    move-result v0

    return v0

    .line 1245
    :cond_f
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getMaxDisplayBrightness()F

    move-result v0

    invoke-static {p1, v0}, Lcom/android/server/display/util/OplusBrightnessUtils;->isSpecialAdj(FF)Z

    move-result v0

    return v0
.end method

.method public isUseProximityForceSuspendStateChanged(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 1325
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->isUseProximityForceSuspendStateChanged(I)Z

    move-result v0

    return v0
.end method

.method public needScreenOffWhenDeviceStateClose()Z
    .registers 2

    .line 1820
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/util/OplusDisplayState;->getNeedScreenOffWhenDeviceStateClose()Z

    move-result v0

    return v0
.end method

.method public notifyBrightnessChange(F)V
    .registers 9
    .param p1, "brightnessState"    # F

    .line 778
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->VRR_ENABLED:Z

    if-eqz v0, :cond_29

    .line 779
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    if-eqz v0, :cond_27

    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    iget-wide v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_PHYSICAL_DISPLAY_ID:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_27

    .line 780
    invoke-virtual {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getNitByBrightness(F)F

    move-result v6

    .line 781
    .local v6, "nit":F
    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_NIT_VALUE:J

    long-to-float v0, v0

    cmpl-float v0, v6, v0

    if-nez v0, :cond_1c

    .line 782
    return-void

    .line 784
    :cond_1c
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    iget-wide v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    move v5, p1

    .end local p1    # "brightnessState":F
    .local v5, "brightnessState":F
    invoke-interface/range {v1 .. v6}, Lcom/oplus/vrr/IOPlusRefreshRateManager;->notifyBrightnessChange(IJFF)V

    goto :goto_2a

    .line 779
    .end local v5    # "brightnessState":F
    .end local v6    # "nit":F
    .restart local p1    # "brightnessState":F
    :cond_27
    move v5, p1

    .end local p1    # "brightnessState":F
    .restart local v5    # "brightnessState":F
    goto :goto_2a

    .line 778
    .end local v5    # "brightnessState":F
    .restart local p1    # "brightnessState":F
    :cond_29
    move v5, p1

    .line 787
    .end local p1    # "brightnessState":F
    .restart local v5    # "brightnessState":F
    :goto_2a
    return-void
.end method

.method public notifyBrightnessSetting(IZZIZ)Z
    .registers 7
    .param p1, "brightness"    # I
    .param p2, "appliedTemporaryBrightness"    # Z
    .param p3, "appliedTemporaryAutoBrightnessAdjustment"    # Z
    .param p4, "currentScreenBrightnessSetting"    # I
    .param p5, "slowChange"    # Z

    .line 1280
    const/4 v0, 0x0

    return v0
.end method

.method public onAnimationChanged(Landroid/animation/Animator;I)V
    .registers 7
    .param p1, "animation"    # Landroid/animation/Animator;
    .param p2, "eventCode"    # I

    .line 741
    const/4 v0, 0x2

    if-ne p2, v0, :cond_26

    .line 744
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    invoke-virtual {v0}, Landroid/os/PowerManager;->isInteractive()Z

    move-result v0

    .line 745
    .local v0, "isInteractive":Z
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "RECORD: Animation finished when screen is off isInteractive: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 746
    if-nez v0, :cond_26

    .line 747
    invoke-direct {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->onGoToSleepFinish()V

    .line 751
    .end local v0    # "isInteractive":Z
    :cond_26
    return-void
.end method

.method public onBootCompleted()V
    .registers 3

    .line 1865
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBootCompleted:Z

    .line 1866
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v1}, Lcom/android/server/display/util/OplusBrightnessUtils;->getScreenBrightness(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 1868
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    if-eqz v0, :cond_23

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    if-eqz v0, :cond_23

    .line 1869
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayDeviceConfigExt;->onBootCompleted()V

    .line 1872
    :cond_23
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_2c

    .line 1873
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0}, Lcom/android/server/display/OplusAutomaticBrightnessController;->onBootCompleted()V

    .line 1877
    :cond_2c
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_36

    .line 1878
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->onBootCompleted()V

    goto :goto_3e

    .line 1880
    :cond_36
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "mDisplayFeatureManager is null"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1883
    :goto_3e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    if-eqz v0, :cond_49

    .line 1884
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/display/RampAnimator$DualRampAnimator;->onBootCompleted(Landroid/os/Handler;)V

    .line 1886
    :cond_49
    return-void
.end method

.method public onChange(Landroid/content/Context;IZLandroid/net/Uri;I)V
    .registers 14
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "displayId"    # I
    .param p3, "selfChange"    # Z
    .param p4, "uri"    # Landroid/net/Uri;
    .param p5, "state"    # I

    .line 557
    const-string/jumbo v0, "screen_auto_brightness_adj_talkback"

    invoke-static {v0}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1, p4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string/jumbo v2, "screen_auto_brightness_adj"

    const/4 v3, 0x1

    if-eqz v1, :cond_61

    .line 558
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    .line 559
    .local v1, "resolver":Landroid/content/ContentResolver;
    invoke-direct {p0, p1, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;)F

    move-result v4

    .line 560
    .local v4, "adjTalkBack":F
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "onChange set talkback brightness "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " state="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-static {p5}, Landroid/view/Display;->stateToString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 561
    float-to-int v5, v4

    const/4 v6, -0x1

    if-eq v5, v6, :cond_60

    .line 562
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v5}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v5

    const/4 v6, 0x0

    invoke-interface {v5, v6}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setAutoBrightnessAdjustment(F)V

    .line 563
    invoke-direct {p0, p1, v2, v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V

    .line 564
    const/high16 v5, -0x40800000    # -1.0f

    invoke-direct {p0, p1, v0, v5}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V

    .line 565
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_61

    .line 566
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, v3}, Lcom/android/server/display/OplusAutomaticBrightnessController;->setTalkBack(Z)V

    goto :goto_61

    .line 569
    :cond_60
    return-void

    .line 573
    .end local v1    # "resolver":Landroid/content/ContentResolver;
    .end local v4    # "adjTalkBack":F
    :cond_61
    :goto_61
    const-string/jumbo v0, "second_screen_auto_brightness_adj"

    invoke-static {v0}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0, p4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_71

    .line 574
    iput-boolean v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSecondAdjChanged:Z

    goto :goto_9d

    .line 575
    :cond_71
    invoke-static {v2}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0, p4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7e

    .line 576
    iput-boolean v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mAutoAdjChanged:Z

    goto :goto_9d

    .line 577
    :cond_7e
    const-string/jumbo v0, "screen_brightness"

    invoke-static {v0}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0, p4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9d

    .line 578
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDataBaseBrightness:Ljava/util/concurrent/atomic/AtomicInteger;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v1}, Lcom/android/server/display/util/OplusBrightnessUtils;->getScreenBrightness(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 579
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getScreenBrightnessSetting()F

    move-result v0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->updateManualAutomaticModeStatus(F)V

    .line 582
    :cond_9d
    :goto_9d
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isSupportNewAnimation()Z

    move-result v0

    if-eqz v0, :cond_b0

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    if-eqz v0, :cond_b0

    .line 584
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    invoke-virtual {v0, p1, p4}, Lcom/android/server/display/RampAnimator$DualRampAnimator;->onChange(Landroid/content/Context;Landroid/net/Uri;)V

    .line 586
    :cond_b0
    return-void
.end method

.method public onDisplayChanged(Lcom/android/server/display/DisplayDeviceConfig;)V
    .registers 5
    .param p1, "config"    # Lcom/android/server/display/DisplayDeviceConfig;

    .line 456
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    .line 457
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayDeviceConfig;->getExtImpl()Lcom/android/server/display/IDisplayDeviceConfigExt;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayDeviceConfigExt;->getBrightnessModel()Lcom/android/server/display/IDisplayBrightnessModelExt;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 458
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_17

    .line 459
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->onDisplayChanged(Lcom/android/server/display/DisplayDeviceConfig;)V

    .line 462
    :cond_17
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    if-eqz v0, :cond_20

    .line 463
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;->onDisplayChanged(Lcom/android/server/display/DisplayDeviceConfig;)V

    .line 466
    :cond_20
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_29

    .line 467
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p1}, Lcom/android/server/display/OplusAutomaticBrightnessController;->onDisplayChanged(Lcom/android/server/display/DisplayDeviceConfig;)V

    .line 470
    :cond_29
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    if-nez v0, :cond_2e

    .line 471
    return-void

    .line 474
    :cond_2e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getPhysicalDisplayId()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    .line 475
    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    invoke-virtual {p0, v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setActivePhysicalDisplayId(J)V

    .line 476
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onDisplayChanged "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", min="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 477
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMinBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", max="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 478
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getMaxBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", hbmMax="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 479
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getTotalBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", dft="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    .line 480
    invoke-interface {v2}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getDefaultBrightness()F

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 476
    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 481
    return-void
.end method

.method public onDisplayControllerHandler(Landroid/os/Message;Landroid/os/Handler;)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "handler"    # Landroid/os/Handler;

    .line 1203
    iget v0, p1, Landroid/os/Message;->what:I

    sparse-switch v0, :sswitch_data_2a

    goto :goto_28

    .line 1213
    :sswitch_6
    goto :goto_28

    .line 1211
    :sswitch_7
    goto :goto_28

    .line 1225
    :sswitch_8
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_28

    .line 1226
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->recoverTemperatureLimitBrightness()V

    goto :goto_28

    .line 1209
    :sswitch_12
    goto :goto_28

    .line 1207
    :sswitch_13
    goto :goto_28

    .line 1217
    :sswitch_14
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_1e

    .line 1218
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setDragFlag(Z)V

    .line 1220
    :cond_1e
    const/16 v0, 0x7e6

    invoke-virtual {p2, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 1221
    .local v0, "sendMsg":Landroid/os/Message;
    invoke-virtual {p2, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 1222
    nop

    .line 1233
    .end local v0    # "sendMsg":Landroid/os/Message;
    :cond_28
    :goto_28
    return-void

    nop

    :sswitch_data_2a
    .sparse-switch
        0x5 -> :sswitch_14
        0x7e4 -> :sswitch_13
        0x7e5 -> :sswitch_12
        0x7e6 -> :sswitch_8
        0x898 -> :sswitch_7
        0x899 -> :sswitch_6
    .end sparse-switch
.end method

.method public onGameLockStateChangeLocked(Z)V
    .registers 3
    .param p1, "isLock"    # Z

    .line 1890
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_9

    .line 1891
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, p1}, Lcom/android/server/display/OplusAutomaticBrightnessController;->onGameLockStateChangeLocked(Z)V

    .line 1893
    :cond_9
    return-void
.end method

.method public onProximityDebounceTimeArrived(II)V
    .registers 4
    .param p1, "displayId"    # I
    .param p2, "proximity"    # I

    .line 1310
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->onProximityDebounceTimeArrived(II)V

    .line 1311
    return-void
.end method

.method public onSwitchUser(IFZ)Z
    .registers 14
    .param p1, "newUserId"    # I
    .param p2, "currentBrightnessSetting"    # F
    .param p3, "isDimming"    # Z

    .line 499
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 500
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v1, :cond_c

    .line 501
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v1, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->onSwitchUser(I)V

    .line 504
    :cond_c
    const/4 v1, 0x0

    :try_start_d
    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRemapDisable:Z

    if-eqz v2, :cond_3b

    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    if-ne v2, v0, :cond_3b

    .line 505
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onSwitchUser newUserId="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 506
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v2}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v2

    invoke-interface {v2}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->handleSettingsChange()V
    :try_end_37
    .catchall {:try_start_d .. :try_end_37} :catchall_ee

    .line 507
    nop

    .line 535
    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 507
    return v0

    .line 509
    :cond_3b
    :try_start_3b
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-nez v2, :cond_4b

    .line 510
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "onSwitchUser mOplusAutomaticBrightnessController invalid"

    invoke-static {v0, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_47
    .catchall {:try_start_3b .. :try_end_47} :catchall_ee

    .line 511
    nop

    .line 535
    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 511
    return v1

    .line 514
    :cond_4b
    :try_start_4b
    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    if-eqz v2, :cond_50

    goto :goto_51

    .line 515
    :cond_50
    move v0, v1

    :goto_51
    nop

    .line 516
    .local v0, "autoMode":I
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v2}, Lcom/android/server/display/OplusAutomaticBrightnessController;->getAutomaticScreenBrightnessAdjustment()F

    move-result v2

    .line 517
    .local v2, "adj":F
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v4, "newUserId=%d,autoMode=%d,dimming=%s,cur=%f,adj=%f"

    .line 518
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v9

    filled-new-array {v5, v6, v7, v8, v9}, [Ljava/lang/Object;

    move-result-object v5

    .line 517
    invoke-static {v3, v4, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 519
    .local v3, "info":Ljava/lang/String;
    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "onSwitchUser "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", sync brightness to "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 520
    const/4 v4, -0x2

    if-nez p3, :cond_de

    .line 521
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string/jumbo v6, "screen_brightness"

    float-to-int v7, p2

    .line 522
    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v7

    .line 521
    invoke-static {v5, v6, v7, v4}, Landroid/provider/Settings$System;->putStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;I)Z

    .line 523
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string/jumbo v6, "face_fill_screen_brightness"

    float-to-int v7, p2

    .line 524
    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v7

    .line 523
    invoke-static {v5, v6, v7, v4}, Landroid/provider/Settings$System;->putStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;I)Z

    .line 525
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string/jumbo v6, "real_screen_brightness"

    float-to-int v7, p2

    .line 526
    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v7

    .line 525
    invoke-static {v5, v6, v7, v4}, Landroid/provider/Settings$System;->putStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;I)Z

    .line 527
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string/jumbo v6, "screen_auto_brightness_adj"

    invoke-static {v5, v6, v2, v4}, Landroid/provider/Settings$System;->putFloatForUser(Landroid/content/ContentResolver;Ljava/lang/String;FI)Z

    .line 530
    :cond_de
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string/jumbo v6, "screen_brightness_mode"

    invoke-static {v5, v6, v0, v4}, Landroid/provider/Settings$System;->putIntForUser(Landroid/content/ContentResolver;Ljava/lang/String;II)Z
    :try_end_ea
    .catchall {:try_start_4b .. :try_end_ea} :catchall_ee

    .line 532
    nop

    .line 535
    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 532
    return v1

    .line 535
    .end local v0    # "autoMode":I
    .end local v2    # "adj":F
    .end local v3    # "info":Ljava/lang/String;
    :catchall_ee
    move-exception v0

    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsUserSwitching:Z

    .line 536
    throw v0
.end method

.method public onUpdatePowerState(III)V
    .registers 8
    .param p1, "state"    # I
    .param p2, "policy"    # I
    .param p3, "brightness"    # I

    .line 770
    const/4 v0, 0x1

    if-eq p1, v0, :cond_b

    const/4 v1, 0x3

    if-eq p1, v1, :cond_b

    const/4 v1, 0x4

    if-ne p1, v1, :cond_a

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    .line 771
    .local v0, "isOff":Z
    :cond_b
    :goto_b
    if-nez v0, :cond_3b

    if-eqz p2, :cond_3b

    .line 772
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "RECORD:onUpdatePowerState policy:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " state:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " brightness:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 774
    :cond_3b
    return-void
.end method

.method public onWakeUp()Z
    .registers 3

    .line 1897
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    if-nez v0, :cond_10

    .line 1898
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    const-class v1, Landroid/os/PowerManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    .line 1900
    :cond_10
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManager:Landroid/os/PowerManager;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/PowerManager;->isInteractive(I)Z

    move-result v0

    if-eqz v0, :cond_1e

    :cond_1d
    const/4 v1, 0x1

    :cond_1e
    return v1
.end method

.method public pokeDynamicVsyncAnimation(ILjava/lang/String;)V
    .registers 5
    .param p1, "durationInMs"    # I
    .param p2, "detail"    # Ljava/lang/String;

    .line 1590
    sget-object v0, Lcom/android/server/dynamicvsync/IOplusDynamicVsyncManagerFeature;->DEFAULT:Lcom/android/server/dynamicvsync/IOplusDynamicVsyncManagerFeature;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/dynamicvsync/IOplusDynamicVsyncManagerFeature;

    .line 1591
    invoke-interface {v0, p1, p2}, Lcom/android/server/dynamicvsync/IOplusDynamicVsyncManagerFeature;->pokeDynamicVsyncAnimation(ILjava/lang/String;)V

    .line 1592
    return-void
.end method

.method public postBrightnessChanged(FF)Z
    .registers 5
    .param p1, "oldBrightnessValue"    # F
    .param p2, "newBrightnessValue"    # F

    .line 1799
    sub-float v0, p2, p1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    float-to-int v0, v0

    .line 1800
    .local v0, "diff":I
    const/4 v1, 0x5

    if-gt v0, v1, :cond_c

    .line 1801
    const/4 v1, 0x0

    return v1

    .line 1803
    :cond_c
    const/4 v1, 0x1

    return v1
.end method

.method public putBrightnessTodatabase(I)I
    .registers 3
    .param p1, "target"    # I

    .line 1295
    const/4 v0, 0x0

    return v0
.end method

.method public recoverySettingsState()V
    .registers 3

    .line 1982
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setAutoBrightnessAdjustment(F)V

    .line 1983
    return-void
.end method

.method public registerPSensor(Landroid/hardware/SensorManager;Landroid/hardware/SensorEventListener;ILandroid/os/Handler;Landroid/hardware/Sensor;)Z
    .registers 12
    .param p1, "sensorManager"    # Landroid/hardware/SensorManager;
    .param p2, "listener"    # Landroid/hardware/SensorEventListener;
    .param p3, "samplingPeriodUs"    # I
    .param p4, "handler"    # Landroid/os/Handler;
    .param p5, "sensor"    # Landroid/hardware/Sensor;

    .line 1336
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    .end local p1    # "sensorManager":Landroid/hardware/SensorManager;
    .end local p2    # "listener":Landroid/hardware/SensorEventListener;
    .end local p3    # "samplingPeriodUs":I
    .end local p4    # "handler":Landroid/os/Handler;
    .end local p5    # "sensor":Landroid/hardware/Sensor;
    .local v1, "sensorManager":Landroid/hardware/SensorManager;
    .local v2, "listener":Landroid/hardware/SensorEventListener;
    .local v3, "samplingPeriodUs":I
    .local v4, "handler":Landroid/os/Handler;
    .local v5, "sensor":Landroid/hardware/Sensor;
    invoke-virtual/range {v0 .. v5}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->registerPSensor(Landroid/hardware/SensorManager;Landroid/hardware/SensorEventListener;ILandroid/os/Handler;Landroid/hardware/Sensor;)Z

    move-result p1

    return p1
.end method

.method public removeFaceBlockReasonFromBlockReasonList()V
    .registers 5

    .line 899
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_c

    .line 900
    const-string v0, "Biometrics_DEBUG"

    const-string/jumbo v1, "removeFaceBlockReasonFromBlockReasonList"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 903
    :cond_c
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    monitor-enter v0

    .line 904
    :try_start_f
    const-string v1, "Biometrics_DEBUG"

    const-string/jumbo v2, "execuce listIterator.remove!"

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 905
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 906
    .local v1, "listIterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_47

    .line 907
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 910
    .local v2, "reason":Ljava/lang/String;
    const-string v3, "android.policy:POWER"

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_43

    const-string/jumbo v3, "oplus.wakeup.gesture:DOUBLE_TAP_SCREEN"

    .line 911
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_43

    const-string/jumbo v3, "oplus.wakeup.gesture:LIFT_HAND"

    .line 912
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_46

    .line 914
    :cond_43
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    .line 916
    .end local v2    # "reason":Ljava/lang/String;
    :cond_46
    goto :goto_1d

    .line 917
    .end local v1    # "listIterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    :cond_47
    monitor-exit v0

    .line 918
    return-void

    .line 917
    :catchall_49
    move-exception v1

    monitor-exit v0
    :try_end_4b
    .catchall {:try_start_f .. :try_end_4b} :catchall_49

    throw v1
.end method

.method public removeMessageWhenScreenOn(Landroid/os/Handler;I)V
    .registers 4
    .param p1, "mHandler"    # Landroid/os/Handler;
    .param p2, "msg"    # I

    .line 826
    if-eqz p1, :cond_b

    invoke-virtual {p1, p2}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 827
    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeMessages(I)V

    .line 829
    :cond_b
    return-void
.end method

.method public reportFinishSetPowerMode()V
    .registers 2

    .line 1940
    invoke-static {}, Lcom/android/server/power/OplusScreenTimeEvent;->getInstance()Lcom/android/server/power/OplusScreenTimeEvent;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/power/OplusScreenTimeEvent;->reportFinishSetPowerMode()V

    .line 1941
    return-void
.end method

.method public reportSetScreenState()V
    .registers 2

    .line 1945
    invoke-static {}, Lcom/android/server/power/OplusScreenTimeEvent;->getInstance()Lcom/android/server/power/OplusScreenTimeEvent;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/power/OplusScreenTimeEvent;->reportSetScreenState()V

    .line 1946
    return-void
.end method

.method public resetNeedScreenOffWhenDeviceStateClose()V
    .registers 3

    .line 1825
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/server/display/util/OplusDisplayState;->setNeedScreenOffWhenDeviceStateClose(Z)V

    .line 1826
    return-void
.end method

.method public screenUpdateExt(IFFFFI)Landroid/util/Pair;
    .registers 12
    .param p1, "screenState"    # I
    .param p2, "oriBrightnessState"    # F
    .param p3, "sdrBrightnessState"    # F
    .param p4, "screenBrightness"    # F
    .param p5, "colorFadeLevel"    # F
    .param p6, "displayId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFFFFI)",
            "Landroid/util/Pair<",
            "Ljava/lang/Float;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 1008
    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isDozeState(I)Z

    move-result v0

    if-eqz v0, :cond_4a

    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isPanoramicAodSupport()Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_4a

    .line 1012
    :cond_11
    invoke-direct {p0, p6}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->shouldUseCurrentBrightness(I)Z

    move-result v0

    const/high16 v1, 0x3f800000    # 1.0f

    if-eqz v0, :cond_1c

    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentBrightness:F

    goto :goto_1d

    :cond_1c
    move v0, v1

    .line 1013
    .local v0, "tmpBrightnessState":F
    :goto_1d
    invoke-direct {p0, p6}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->shouldUseCurrentBrightness(I)Z

    move-result v2

    if-eqz v2, :cond_25

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentSdrBrightness:F

    .line 1014
    .local v1, "tmpSdrBrightnessState":F
    :cond_25
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "add for debug Aod brightness set "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1015
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v2

    return-object v2

    .line 1009
    .end local v0    # "tmpBrightnessState":F
    .end local v1    # "tmpSdrBrightnessState":F
    :cond_4a
    :goto_4a
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    return-object v0
.end method

.method public sendMessageWhenScreenOnUnblocker(Landroid/os/Handler;Landroid/os/Message;)Z
    .registers 5
    .param p1, "mHandler"    # Landroid/os/Handler;
    .param p2, "msg"    # Landroid/os/Message;

    .line 811
    if-eqz p1, :cond_18

    .line 812
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string v1, "ScreenOnUnblocker, onScreenOn"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 813
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenOnBlockedByFace:Z

    if-eqz v0, :cond_13

    .line 814
    const-wide/16 v0, 0x3e8

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_16

    .line 816
    :cond_13
    invoke-virtual {p1, p2}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 818
    :goto_16
    const/4 v0, 0x1

    return v0

    .line 820
    :cond_18
    const/4 v0, 0x0

    return v0
.end method

.method public setActivePhysicalDisplayId(J)V
    .registers 6
    .param p1, "physicalDisplayId"    # J

    .line 1954
    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    if-nez v0, :cond_32

    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_PHYSICAL_DISPLAY_ID:J

    cmp-long v0, p1, v0

    if-nez v0, :cond_b

    goto :goto_32

    .line 1957
    :cond_b
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->VRR_ENABLED:Z

    if-eqz v0, :cond_31

    .line 1958
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    if-eqz v0, :cond_31

    .line 1959
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setActivePhysicalDisplayId: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1960
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    invoke-interface {v0, p1, p2}, Lcom/oplus/vrr/IOPlusRefreshRateManager;->setActivePhysicalDisplayId(J)V

    .line 1963
    :cond_31
    return-void

    .line 1955
    :cond_32
    :goto_32
    return-void
.end method

.method public setAnimating(ZZF)V
    .registers 6
    .param p1, "animating"    # Z
    .param p2, "isPrimaryAnimator"    # Z
    .param p3, "rate"    # F

    .line 1378
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_9

    .line 1379
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setAnimating(ZZ)V

    .line 1382
    :cond_9
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-interface {v0}, Lcom/android/server/display/IDisplayBrightnessModelExt;->getBrightnessRampRateFast()I

    move-result v0

    int-to-float v0, v0

    invoke-static {p3, v0}, Ljava/lang/Float;->compare(FF)I

    move-result v0

    if-nez v0, :cond_18

    const/4 v0, 0x1

    goto :goto_19

    :cond_18
    const/4 v0, 0x0

    .line 1383
    .local v0, "isFastAnimating":Z
    :goto_19
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v1

    invoke-virtual {v1, p1, p2, v0}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->setAnimating(ZZZ)V

    .line 1384
    return-void
.end method

.method public setBrightnessExt(F)V
    .registers 4
    .param p1, "brightnessValue"    # F

    .line 1830
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_10

    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsAutoBrightness:Z

    if-eqz v0, :cond_10

    .line 1831
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "screen_auto_brightness_adj_talkback"

    invoke-direct {p0, v0, v1, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putAutoAdjSetting(Landroid/content/Context;Ljava/lang/String;F)V

    .line 1833
    :cond_10
    float-to-int v0, p1

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "screen_brightness"

    invoke-direct {p0, v1, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->putStringForUser(Ljava/lang/String;Ljava/lang/String;)V

    .line 1834
    return-void
.end method

.method public setByUser(Z)V
    .registers 3
    .param p1, "byUser"    # Z

    .line 716
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mByUser:Z

    .line 717
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    if-eqz v0, :cond_b

    .line 718
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    invoke-interface {v0, p1}, Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;->setDrag(Z)V

    .line 720
    :cond_b
    return-void
.end method

.method public setCameraTemporaryAdjustment(F)Z
    .registers 6
    .param p1, "adjustment"    # F

    .line 1618
    const/4 v0, 0x1

    .line 1619
    .local v0, "refreshBri":Z
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v1, :cond_24

    .line 1620
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v1, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setCameraTemporaryAdjustment(F)Z

    move-result v0

    .line 1621
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "setTemporaryAutoBrightnessAdjustment = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1623
    :cond_24
    return v0
.end method

.method public setDCMode()V
    .registers 2

    .line 1363
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->getDCModeStatus()Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mGlobalDCMode:Z

    .line 1364
    return-void
.end method

.method public setDisplayPowerControlHandler(Landroid/os/Handler;)V
    .registers 4
    .param p1, "handler"    # Landroid/os/Handler;

    .line 428
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "impl setDisplayPowerControlHandler"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 429
    new-instance v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mHandler:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    .line 430
    return-void
.end method

.method public setDisplayPowerModeFinished(I)V
    .registers 4
    .param p1, "state"    # I

    .line 1388
    iput p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentPowerModeState:I

    .line 1389
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_13

    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentPowerModeState:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_13

    .line 1390
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1392
    :cond_13
    return-void
.end method

.method public setIgnoreReadyState(Z)V
    .registers 2
    .param p1, "ignore"    # Z

    .line 1972
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIgnoreReadyState:Z

    .line 1973
    return-void
.end method

.method public setLoggingEnabled(Z)V
    .registers 3
    .param p1, "loggingEnabled"    # Z

    .line 1663
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerState:Lcom/android/server/display/DisplayPowerState;

    if-eqz v0, :cond_d

    .line 1664
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerState:Lcom/android/server/display/DisplayPowerState;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerState;->getWrapper()Lcom/android/server/display/IDisplayPowerStateWrapper;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/android/server/display/IDisplayPowerStateWrapper;->setLoggingEnabled(Z)V

    .line 1667
    :cond_d
    invoke-static {p1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->setAmbienceLogOn(Z)V

    .line 1668
    return-void
.end method

.method public setPowerOnUX(II)V
    .registers 7
    .param p1, "oldState"    # I
    .param p2, "curState"    # I

    .line 1905
    iget-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsSetUxWhenWindowUnblock:Z

    if-nez v0, :cond_e

    invoke-static {}, Lcom/android/server/display/feature/power/OplusPowerDisplayHelper;->getInstance()Lcom/android/server/display/feature/power/OplusPowerDisplayHelper;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/feature/power/OplusPowerDisplayHelper;->getPolicyChange()Z

    move-result v0

    if-eqz v0, :cond_57

    .line 1906
    :cond_e
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->isUafKeyThreadEnabled()Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 1907
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_23

    .line 1908
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string v1, "UAD set UX power on"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1910
    :cond_23
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    const/16 v3, 0x3f5

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->requestSysResource(IILandroid/os/Bundle;)Z

    goto :goto_54

    .line 1912
    :cond_2f
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxPid:I

    .line 1913
    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v0

    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxTid:I

    .line 1914
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_47

    .line 1915
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "set UX power on"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1917
    :cond_47
    invoke-static {}, Lcom/oplus/uifirst/OplusUIFirstManager;->getInstance()Lcom/oplus/uifirst/OplusUIFirstManager;

    move-result-object v0

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxPid:I

    iget v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerOnUxTid:I

    const/16 v3, 0x88

    invoke-virtual {v0, v1, v2, v3}, Lcom/oplus/uifirst/OplusUIFirstManager;->setUxThreadValueByFile(III)V

    .line 1920
    :goto_54
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSetPowerOnUx:Z

    .line 1922
    :cond_57
    return-void
.end method

.method public setPowerRequest(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V
    .registers 2
    .param p1, "request"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1672
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurPowerReq:Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1673
    return-void
.end method

.method public setPowerState(Lcom/android/server/display/DisplayPowerState;)V
    .registers 5
    .param p1, "powerState"    # Lcom/android/server/display/DisplayPowerState;

    .line 1347
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_21

    .line 1348
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setPowerState:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1350
    :cond_21
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerState:Lcom/android/server/display/DisplayPowerState;

    .line 1351
    return-void
.end method

.method public setQuickDarkToBrightStatus(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V
    .registers 2
    .param p1, "powerrequest"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1270
    return-void
.end method

.method public setReason(I)V
    .registers 3
    .param p1, "reason"    # I

    .line 1436
    if-eqz p1, :cond_18

    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    if-nez v0, :cond_18

    .line 1437
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    if-eqz v0, :cond_f

    .line 1438
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;->setReason(I)V

    .line 1441
    :cond_f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    if-eqz v0, :cond_18

    .line 1442
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mORBrightnessMarvelsDataCollector:Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;

    invoke-interface {v0, p1}, Lcom/android/server/display/marvels/module/IORBrightnessMarvelsDataCollector;->setReason(I)V

    .line 1445
    :cond_18
    return-void
.end method

.method public setResetTemporaryStrategyStatus(Z)V
    .registers 2
    .param p1, "enable"    # Z

    .line 1658
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNeedResetTemporaryStrategy:Z

    .line 1659
    return-void
.end method

.method public setScreenBrightnessRampAnimator(Lcom/android/server/display/RampAnimator$DualRampAnimator;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/display/RampAnimator$DualRampAnimator<",
            "Lcom/android/server/display/DisplayPowerState;",
            ">;)V"
        }
    .end annotation

    .line 684
    .local p1, "animator":Lcom/android/server/display/RampAnimator$DualRampAnimator;, "Lcom/android/server/display/RampAnimator$DualRampAnimator<Lcom/android/server/display/DisplayPowerState;>;"
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenBrightnessRampAnimator:Lcom/android/server/display/RampAnimator$DualRampAnimator;

    .line 685
    return-void
.end method

.method public setScreenStateExt(ZILcom/android/server/display/DisplayPowerState;Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V
    .registers 10
    .param p1, "isPrimary"    # Z
    .param p2, "state"    # I
    .param p3, "powerState"    # Lcom/android/server/display/DisplayPowerState;
    .param p4, "powerRequest"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;

    .line 1251
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->VRR_ENABLED:Z

    if-eqz v0, :cond_19

    .line 1252
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    if-eqz v0, :cond_19

    iget-wide v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    iget-wide v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->INVALID_PHYSICAL_DISPLAY_ID:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_19

    .line 1253
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    iget-wide v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPhysicalDisplayId:J

    invoke-interface {v0, v1, v2, v3, p2}, Lcom/oplus/vrr/IOPlusRefreshRateManager;->screenStateChange(IJI)V

    .line 1257
    :cond_19
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/display/util/OplusDisplayState;->setScreenState(ZI)V

    .line 1259
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p2, v2, :cond_27

    move v3, v0

    goto :goto_28

    :cond_27
    move v3, v1

    .line 1260
    .local v3, "isStateOFF":Z
    :goto_28
    if-eqz v3, :cond_36

    invoke-virtual {p3}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v4

    if-ne v4, v2, :cond_36

    .line 1261
    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-direct {p0, v0, v1, p4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->onScreenEvent(IZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V

    goto :goto_3d

    .line 1262
    :cond_36
    if-ne p2, v2, :cond_3d

    .line 1263
    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-direct {p0, v1, v0, p4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->onScreenEvent(IZLandroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;)V

    .line 1265
    :cond_3d
    :goto_3d
    return-void
.end method

.method public setSpecBrightness(ILjava/lang/String;I)V
    .registers 6
    .param p1, "gear"    # I
    .param p2, "reason"    # Ljava/lang/String;
    .param p3, "rate"    # I

    .line 1604
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-nez v0, :cond_d

    .line 1605
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "setSpecBrightness mDisplayFeatureManager  is null"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1606
    return-void

    .line 1609
    :cond_d
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setSpecBrightness(ILjava/lang/String;I)V

    .line 1610
    return-void
.end method

.method public setUniqueDisplayId(ZLjava/lang/String;)V
    .registers 5
    .param p1, "isPrimary"    # Z
    .param p2, "uniqueId"    # Ljava/lang/String;

    .line 678
    iput-object p2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mUniqueDisplayId:Ljava/lang/String;

    .line 679
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-virtual {v0, p1, v1}, Lcom/android/server/display/util/OplusDisplayState;->setLogicalDisplayId(ZI)V

    .line 680
    return-void
.end method

.method public setUseProximityForceSuspend(ZI)V
    .registers 4
    .param p1, "enable"    # Z
    .param p2, "displayId"    # I

    .line 1315
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusProximitySensorScreenOnOff:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->setUseProximityForceSuspend(ZI)V

    .line 1316
    return-void
.end method

.method public setUxWhenWindowUnblock(Z)V
    .registers 2
    .param p1, "flag"    # Z

    .line 1950
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mIsSetUxWhenWindowUnblock:Z

    .line 1951
    return-void
.end method

.method public setWinOverride(Z)V
    .registers 3
    .param p1, "winOverride"    # Z

    .line 724
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mWinOverride:Z

    .line 725
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_b

    .line 726
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setWinOverrideStatus(Z)V

    .line 728
    :cond_b
    return-void
.end method

.method public setWindowManagerPolicy(Z)V
    .registers 4
    .param p1, "screenOn"    # Z

    .line 1038
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_9

    .line 1039
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0, p1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setWindowManagerPolicy(Z)V

    .line 1042
    :cond_9
    if-eqz p1, :cond_1c

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_1c

    iget v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mCurrentPowerModeState:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1c

    .line 1043
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1045
    :cond_1c
    return-void
.end method

.method public setupPostProcessLocked(Landroid/os/Handler;)V
    .registers 7
    .param p1, "handler"    # Landroid/os/Handler;

    .line 434
    new-instance v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;

    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDPCExtWorkHandler:Landroid/os/Handler;

    .line 435
    new-instance v0, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v1}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayDeviceConfig:Lcom/android/server/display/DisplayDeviceConfig;

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDPCExtWorkHandler:Landroid/os/Handler;

    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;-><init>(Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;Lcom/android/server/display/DisplayDeviceConfig;Landroid/os/Handler;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    .line 437
    new-instance v0, Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    iget v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDPCExtWorkHandler:Landroid/os/Handler;

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;-><init>(ILandroid/os/Handler;Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;Lcom/android/server/display/IDisplayBrightnessModelExt;)V

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPostProcessingManager:Lcom/android/server/display/feature/postprocess/OplusBrightnessPostProcessingManager;

    .line 439
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->getBarControllerFeature()Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    .line 440
    invoke-static {}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->getInstance()Lcom/android/server/display/feature/viewer/BrightnessViewer;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/viewer/BrightnessViewer;->init(Landroid/content/Context;)V

    .line 441
    invoke-static {}, Lcom/android/server/display/feature/viewer/BrightnessRecorder;->getInstance()Lcom/android/server/display/feature/viewer/BrightnessRecorder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1, p1}, Lcom/android/server/display/feature/viewer/BrightnessRecorder;->init(Landroid/content/Context;Landroid/os/Handler;)V

    .line 442
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mUniqueDisplayId:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isPrimaryDisplay(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5c

    .line 443
    invoke-static {}, Lcom/android/server/display/feature/marvels/ORBrightnessMarvels;->getInstance()Lcom/android/server/display/feature/marvels/ORBrightnessMarvels;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDPCExtWorkHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBrightnessModel:Lcom/android/server/display/IDisplayBrightnessModelExt;

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/display/feature/marvels/ORBrightnessMarvels;->init(Landroid/os/Handler;Landroid/content/Context;Lcom/android/server/display/IDisplayBrightnessModelExt;)V

    .line 446
    :cond_5c
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    new-instance v1, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->setNoAnimationChangedRunable(Ljava/lang/Runnable;)V

    .line 447
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_72

    .line 448
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusFeatureBrightnessBarController:Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusAutomaticBrightnessController;->setBrightnessBarController(Lcom/android/server/display/feature/postprocess/OplusFeatureBrightnessBarController;)V

    goto :goto_7a

    .line 450
    :cond_72
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v1, "mOplusAutomaticBrightnessController == null"

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 452
    :goto_7a
    return-void
.end method

.method public shouldIgnoreDoze(I)Z
    .registers 8
    .param p1, "state"    # I

    .line 1719
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->isRemapDisabledDisplay()Z

    move-result v0

    if-eqz v0, :cond_94

    .line 1720
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayId()I

    move-result v0

    .line 1721
    .local v0, "displayId":I
    const-string v1, " d state:"

    const/4 v2, 0x1

    if-nez v0, :cond_55

    .line 1722
    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isDsiSwitchForbiddenState(I)Z

    move-result v3

    if-eqz v3, :cond_55

    .line 1723
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getBaseState()I

    move-result v3

    invoke-static {v3}, Landroid/hardware/devicestate/DeviceStateManager;->isFoldedDeviceState(I)Z

    move-result v3

    if-eqz v3, :cond_55

    .line 1725
    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "DsiSwitch: default screen can\'t enter doze if folded, state = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1726
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getBaseState()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1725
    invoke-static {v3, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1727
    return v2

    .line 1728
    :cond_55
    if-ne v0, v2, :cond_94

    .line 1729
    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isDsiSwitchForbiddenState(I)Z

    move-result v3

    if-eqz v3, :cond_94

    .line 1730
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getBaseState()I

    move-result v3

    invoke-static {v3}, Landroid/hardware/devicestate/DeviceStateManager;->isFoldedDeviceState(I)Z

    move-result v3

    if-nez v3, :cond_94

    .line 1732
    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "DsiSwitch: vice screen can\'t enter doze if unfolded, state = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1733
    invoke-static {}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getInstance()Lcom/android/server/display/OplusFoldingDeviceManagerService;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/display/OplusFoldingDeviceManagerService;->getBaseState()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1732
    invoke-static {v3, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1734
    return v2

    .line 1737
    .end local v0    # "displayId":I
    :cond_94
    const/4 v0, 0x0

    return v0
.end method

.method public stop(Z)V
    .registers 4
    .param p1, "isPrimaryDisplay"    # Z

    .line 345
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    if-eqz v0, :cond_16

    .line 346
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->removeListener(Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter$Listener;)V

    .line 347
    invoke-static {}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->getInstance()Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOplusAutomaticBrightnessController:Lcom/android/server/display/OplusAutomaticBrightnessController;

    invoke-virtual {v0, v1}, Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter;->removeAmbientResetListener(Lcom/android/server/display/feature/ambience/OplusBrightnessAmbientAdapter$AmbientResetListener;)V

    .line 350
    :cond_16
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    if-eqz v0, :cond_1f

    .line 351
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayFeatureManager:Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;

    invoke-virtual {v0}, Lcom/android/server/display/feature/postprocess/OplusDisplayFeatureManager;->stop()V

    .line 354
    :cond_1f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    if-eqz v0, :cond_2e

    .line 355
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mSettingsObserver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;->unregister(Landroid/content/ContentResolver;)V

    .line 357
    :cond_2e
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBroadcastReceiver:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;

    invoke-direct {p0, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->unregisterOplusDpcExtBroadcast(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;)V

    .line 358
    invoke-static {}, Lcom/android/server/display/util/OplusDisplayState;->getInstance()Lcom/android/server/display/util/OplusDisplayState;

    move-result-object v0

    const/4 v1, -0x1

    invoke-virtual {v0, p1, v1}, Lcom/android/server/display/util/OplusDisplayState;->setLogicalDisplayId(ZI)V

    .line 359
    return-void
.end method

.method public unblockDisplayReady()V
    .registers 4

    .line 793
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManagerInternal:Landroid/os/PowerManagerInternal;

    if-nez v0, :cond_5

    return-void

    .line 798
    :cond_5
    const-class v0, Landroid/os/IOplusPowerManagerInternalEx;

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPowerManagerInternal:Landroid/os/PowerManagerInternal;

    .line 799
    invoke-static {v0, v1}, Lcom/oplus/util/OplusTypeCastingHelper;->typeCasting(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/IOplusPowerManagerInternalEx;

    .line 800
    .local v0, "internalEx":Landroid/os/IOplusPowerManagerInternalEx;
    if-eqz v0, :cond_1a

    invoke-interface {v0}, Landroid/os/IOplusPowerManagerInternalEx;->isStartGoToSleep()Z

    move-result v1

    if-eqz v1, :cond_1a

    .line 802
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    .line 804
    :cond_1a
    sget-boolean v1, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v1, :cond_39

    .line 805
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "unblockDisplayReady, mPendingDisplayReadyBlocker = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Biometrics_DEBUG"

    invoke-static {v2, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 807
    :cond_39
    return-void
.end method

.method public unblockScreenOnByBiometrics(Ljava/lang/String;)V
    .registers 6
    .param p1, "reason"    # Ljava/lang/String;

    .line 853
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_29

    .line 854
    const-string v0, "Biometrics_DEBUG"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "unblockScreen(reason = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ") , mPendingScreenOnUnblockerFromBiometrics = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 856
    :cond_29
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    const/4 v1, 0x0

    if-eqz v0, :cond_39

    .line 857
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingScreenOnUnblockerFromBiometrics:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    .line 858
    const-wide/32 v2, 0x20000

    const-string v0, "Screen on blocked by biometrics"

    invoke-static {v2, v3, v0, v1}, Landroid/os/Trace;->asyncTraceEnd(JLjava/lang/String;I)V

    .line 861
    :cond_39
    iput-boolean v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mPendingDisplayReadyBlocker:Z

    .line 865
    const-string v0, "UNBLOCK_REASON_GO_TO_SLEEP"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4c

    .line 867
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->sendUpdatePowerState()V

    .line 872
    :cond_4c
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    monitor-enter v0

    .line 873
    :try_start_4f
    const-string v1, "Biometrics_DEBUG"

    const-string/jumbo v2, "execute mBlockReasonList.clear"

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 874
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mBlockReasonList:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 875
    invoke-static {}, Lcom/android/server/power/OplusScreenTimeEvent;->getInstance()Lcom/android/server/power/OplusScreenTimeEvent;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/power/OplusScreenTimeEvent;->reportBiometricBlockClear()V

    .line 876
    monitor-exit v0

    .line 878
    return-void

    .line 876
    :catchall_65
    move-exception v1

    monitor-exit v0
    :try_end_67
    .catchall {:try_start_4f .. :try_end_67} :catchall_65

    throw v1
.end method

.method public updateBrightnessAnimationStatus(Lcom/android/server/display/DisplayPowerState;ILcom/android/server/display/LogicalDisplay;I)V
    .registers 13
    .param p1, "powerState"    # Lcom/android/server/display/DisplayPowerState;
    .param p2, "powerRqstPolicy"    # I
    .param p3, "display"    # Lcom/android/server/display/LogicalDisplay;
    .param p4, "displayId"    # I

    .line 1512
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mNoAnimation:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    .line 1513
    .local v0, "noAnimation":Z
    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ne p2, v4, :cond_2f

    .line 1514
    if-eqz p1, :cond_2b

    .line 1515
    invoke-virtual {p1}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v5

    .line 1516
    .local v5, "currentScreenState":I
    if-eq v5, v3, :cond_1c

    if-eq v5, v4, :cond_1c

    const/4 v6, 0x4

    if-ne v5, v6, :cond_1a

    goto :goto_1c

    :cond_1a
    move v6, v1

    goto :goto_1d

    :cond_1c
    :goto_1c
    move v6, v3

    .line 1519
    .local v6, "brightnessNoAnimation":Z
    :goto_1d
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->hasRemapDisable()Z

    move-result v7

    if-eqz v7, :cond_27

    .line 1520
    invoke-direct {p0, v6}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isRealBrightnessNoAnimation(Z)Z

    move-result v6

    .line 1522
    :cond_27
    invoke-direct {p0, v6}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1523
    .end local v5    # "currentScreenState":I
    .end local v6    # "brightnessNoAnimation":Z
    goto :goto_3e

    .line 1525
    :cond_2b
    invoke-direct {p0, v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    goto :goto_3e

    .line 1527
    :cond_2f
    if-ne p2, v2, :cond_3e

    if-eqz v0, :cond_3e

    .line 1529
    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v6, "updateBrightnessAnimationStatus false"

    invoke-static {v5, v6}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1530
    invoke-direct {p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1534
    :cond_3e
    :goto_3e
    if-ne p2, v3, :cond_66

    .line 1535
    if-eqz p1, :cond_66

    .line 1536
    invoke-virtual {p1}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v5

    .line 1537
    .restart local v5    # "currentScreenState":I
    iget v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mRateType:I

    const/16 v7, 0x17

    if-ne v6, v7, :cond_4f

    if-ne v5, v2, :cond_4f

    move v1, v3

    .line 1539
    .local v1, "brightnessNoAnimation":Z
    :cond_4f
    invoke-virtual {p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->hasRemapDisable()Z

    move-result v6

    if-eqz v6, :cond_59

    .line 1540
    invoke-direct {p0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->isRealBrightnessNoAnimation(Z)Z

    move-result v1

    .line 1542
    :cond_59
    if-eqz v1, :cond_66

    .line 1543
    iget-object v6, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    const-string/jumbo v7, "game scene ON->DOZE updateBrightnessAnimationStatus true"

    invoke-static {v6, v7}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1544
    invoke-direct {p0, v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->setBrightnessNoAnimation(Z)V

    .line 1552
    .end local v1    # "brightnessNoAnimation":Z
    .end local v5    # "currentScreenState":I
    :cond_66
    sget-boolean v1, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->ADFR_ENABLED:Z

    if-eqz v1, :cond_81

    if-eqz p1, :cond_81

    .line 1554
    invoke-virtual {p1}, Lcom/android/server/display/DisplayPowerState;->getScreenState()I

    move-result v1

    if-ne v1, v2, :cond_81

    .line 1556
    const/4 v1, 0x2

    .line 1557
    .local v1, "state":I
    if-eq p2, v4, :cond_76

    .line 1558
    const/4 v1, 0x1

    .line 1560
    :cond_76
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    if-eqz v2, :cond_81

    .line 1561
    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mOPlusRefreshRateManager:Lcom/oplus/vrr/IOPlusRefreshRateManager;

    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDisplayId:I

    invoke-interface {v2, v3, v1}, Lcom/oplus/vrr/IOPlusRefreshRateManager;->screenStateChangeWarning(II)V

    .line 1566
    .end local v1    # "state":I
    :cond_81
    return-void
.end method

.method public updateScreenOnBlockedState(Z)V
    .registers 5
    .param p1, "isBlockedScreenOn"    # Z

    .line 890
    iput-boolean p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mScreenOnBlockedByFace:Z

    .line 891
    sget-boolean v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->DEBUG:Z

    if-eqz v0, :cond_1f

    .line 892
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "updateScreenOnBlockedState, isBlockedScreenOn = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 894
    :cond_1f
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->sendMsgUnblockScreenOn(Z)V

    .line 895
    return-void
.end method

.method public useSoftwareAutoBrightnessConfigInOtherDisplay(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 1712
    sget-object v0, Lcom/android/server/wm/IOplusPuttManager;->DEFAULT:Lcom/android/server/wm/IOplusPuttManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusPuttManager;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusPuttManager;->useSoftwareAutoBrightnessConfigInOtherDisplay(I)Z

    move-result v0

    return v0
.end method
