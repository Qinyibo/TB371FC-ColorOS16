.class Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;


# direct methods
.method constructor <init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V
    .registers 2
    .param p1, "this$0"    # Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 699
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 702
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPMS(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/power/PowerManagerService;

    move-result-object v0

    const-string v1, "OplusProximitySensorScreenOnOff"

    if-eqz v0, :cond_30

    .line 703
    const-string/jumbo v0, "onProximityNegativeForceSuspend"

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 704
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$mproximityNegativeReset(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    .line 705
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmContext(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Landroid/content/Context;

    move-result-object v0

    const-string/jumbo v2, "power"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    .line 706
    .local v0, "pm":Landroid/os/PowerManager;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const/16 v4, 0x61

    const-string v5, "android.service.power:proximity"

    invoke-virtual {v0, v2, v3, v4, v5}, Landroid/os/PowerManager;->wakeUp(JILjava/lang/String;)V

    .line 707
    .end local v0    # "pm":Landroid/os/PowerManager;
    goto :goto_36

    .line 708
    :cond_30
    const-string/jumbo v0, "mOnProximityNegativeSuspendRunnable: PMS is null!"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 710
    :goto_36
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmDisplayPowerController(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/display/DisplayPowerController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    .line 711
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->getWakelockController()Lcom/android/server/display/WakelockController;

    move-result-object v0

    .line 712
    .local v0, "wakelockController":Lcom/android/server/display/WakelockController;
    if-eqz v0, :cond_54

    .line 713
    const/16 v1, 0x65

    invoke-virtual {v0, v1}, Lcom/android/server/display/WakelockController;->releaseWakelock(I)Z

    goto :goto_5a

    .line 715
    :cond_54
    const-string/jumbo v2, "mOnProximityNegativeSuspendRunnable: callbacks is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 717
    :goto_5a
    return-void
.end method
