.class public Lcom/android/server/am/OplusActivityManagerHelper;
.super Ljava/lang/Object;
.source "OplusActivityManagerHelper.java"


# static fields
.field private static final DEBUG_SWITCH:Z

.field private static final EVENT_CODE_PREVENT_START:I = 0x1

.field protected static final INVALID_PID:I = -0x1

.field protected static final INVALID_UID:I = -0x1

.field protected static final PREVENT_REASON_BS_APP_REVIVAL:Ljava/lang/String; = "bs_app_revival"

.field protected static final PREVENT_REASON_BS_ENGINEER:Ljava/lang/String; = "bs_engineer"

.field protected static final PREVENT_REASON_BS_OPSCENE:Ljava/lang/String; = "bs_opscene"

.field protected static final PREVENT_REASON_BS_PRELOAD:Ljava/lang/String; = "bs_preload"

.field protected static final PREVENT_REASON_BS_STARTUP:Ljava/lang/String; = "bs_startup"

.field protected static final PREVENT_REASON_BS_STARTUP_BLK:Ljava/lang/String; = "bs_startup_blk"

.field protected static final PREVENT_REASON_BS_STARTUP_QUOTA:Ljava/lang/String; = "bs_startup_quota"

.field protected static final PREVENT_REASON_PV_OPSCENE:Ljava/lang/String; = "pv_opscene"

.field protected static final PREVENT_REASON_PV_PRELOAD:Ljava/lang/String; = "pv_preload"

.field protected static final PREVENT_REASON_PV_STARTUP:Ljava/lang/String; = "pv_startup"

.field protected static final PREVENT_REASON_PV_STARTUP_QUOTA:Ljava/lang/String; = "pv_startup_quota"

.field protected static final PREVENT_REASON_SS_ENGINEER:Ljava/lang/String; = "ss_engineer"

.field protected static final PREVENT_REASON_SS_OPSCENE:Ljava/lang/String; = "ss_opscene"

.field protected static final PREVENT_REASON_SS_PRELOAD:Ljava/lang/String; = "ss_preload"

.field protected static final PREVENT_REASON_SS_STARTUP:Ljava/lang/String; = "ss_startup"

.field protected static final PREVENT_REASON_SS_STARTUP_BLK:Ljava/lang/String; = "ss_startup_blk"

.field protected static final PREVENT_REASON_SS_STARTUP_QUOTA:Ljava/lang/String; = "ss_startup_quota"

.field protected static final PREVENT_REASON_SV_GUARDELF:Ljava/lang/String; = "sv_guardelf"

.field private static final TAG:Ljava/lang/String; = "OplusActivityManagerHelper"

.field private static volatile sInstance:Lcom/android/server/am/OplusActivityManagerHelper;


# instance fields
.field private mOplusNotificationManagerInternal:Lcom/android/server/notification/OplusNotificationManagerInternal;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 54
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerHelper;->DEBUG_SWITCH:Z

    .line 57
    const/4 v0, 0x0

    sput-object v0, Lcom/android/server/am/OplusActivityManagerHelper;->sInstance:Lcom/android/server/am/OplusActivityManagerHelper;

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 61
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerHelper;->mOplusNotificationManagerInternal:Lcom/android/server/notification/OplusNotificationManagerInternal;

    .line 63
    return-void
.end method

.method public static getInstance()Lcom/android/server/am/OplusActivityManagerHelper;
    .registers 2

    .line 66
    sget-object v0, Lcom/android/server/am/OplusActivityManagerHelper;->sInstance:Lcom/android/server/am/OplusActivityManagerHelper;

    if-nez v0, :cond_17

    .line 67
    const-class v0, Lcom/android/server/am/OplusActivityManagerHelper;

    monitor-enter v0

    .line 68
    :try_start_7
    sget-object v1, Lcom/android/server/am/OplusActivityManagerHelper;->sInstance:Lcom/android/server/am/OplusActivityManagerHelper;

    if-nez v1, :cond_12

    .line 69
    new-instance v1, Lcom/android/server/am/OplusActivityManagerHelper;

    invoke-direct {v1}, Lcom/android/server/am/OplusActivityManagerHelper;-><init>()V

    sput-object v1, Lcom/android/server/am/OplusActivityManagerHelper;->sInstance:Lcom/android/server/am/OplusActivityManagerHelper;

    .line 71
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 73
    :cond_17
    :goto_17
    sget-object v0, Lcom/android/server/am/OplusActivityManagerHelper;->sInstance:Lcom/android/server/am/OplusActivityManagerHelper;

    return-object v0
.end method

.method private getOplusNotificationManagerInternal()Lcom/android/server/notification/OplusNotificationManagerInternal;
    .registers 2

    .line 77
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerHelper;->mOplusNotificationManagerInternal:Lcom/android/server/notification/OplusNotificationManagerInternal;

    if-nez v0, :cond_e

    .line 78
    const-class v0, Lcom/android/server/notification/OplusNotificationManagerInternal;

    invoke-static {v0}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/notification/OplusNotificationManagerInternal;

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerHelper;->mOplusNotificationManagerInternal:Lcom/android/server/notification/OplusNotificationManagerInternal;

    .line 80
    :cond_e
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerHelper;->mOplusNotificationManagerInternal:Lcom/android/server/notification/OplusNotificationManagerInternal;

    return-object v0
.end method

.method private notifyComponentPreventToNMS(IIILjava/lang/String;Ljava/lang/String;)V
    .registers 13
    .param p1, "fromUid"    # I
    .param p2, "uid"    # I
    .param p3, "pid"    # I
    .param p4, "component"    # Ljava/lang/String;
    .param p5, "reason"    # Ljava/lang/String;

    .line 89
    invoke-direct {p0}, Lcom/android/server/am/OplusActivityManagerHelper;->getOplusNotificationManagerInternal()Lcom/android/server/notification/OplusNotificationManagerInternal;

    move-result-object v0

    .line 90
    .local v0, "oplusNotificationManagerInternal":Lcom/android/server/notification/OplusNotificationManagerInternal;
    const-string v1, "OplusActivityManagerHelper"

    if-nez v0, :cond_f

    .line 91
    const-string/jumbo v2, "notifyComponentPreventToNMS: oplusNotificationManagerInternal is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 92
    return-void

    .line 95
    :cond_f
    sget-boolean v2, Lcom/android/server/am/OplusActivityManagerHelper;->DEBUG_SWITCH:Z

    if-eqz v2, :cond_52

    .line 96
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "notifyComponentPreventToNMS fromUid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", component="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", reason="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 99
    :cond_52
    const/4 v1, 0x1

    move v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p5

    .end local p1    # "fromUid":I
    .end local p2    # "uid":I
    .end local p3    # "pid":I
    .end local p4    # "component":Ljava/lang/String;
    .end local p5    # "reason":Ljava/lang/String;
    .local v2, "fromUid":I
    .local v3, "uid":I
    .local v4, "pid":I
    .local v5, "component":Ljava/lang/String;
    .local v6, "reason":Ljava/lang/String;
    invoke-virtual/range {v0 .. v6}, Lcom/android/server/notification/OplusNotificationManagerInternal;->onComponentEvent(IIIILjava/lang/String;Ljava/lang/String;)V

    .line 100
    return-void
.end method


# virtual methods
.method protected notifyComponentPreventToNMS(IILcom/android/server/am/ProcessRecord;Ljava/lang/String;Ljava/lang/String;)V
    .registers 13
    .param p1, "fromUid"    # I
    .param p2, "uid"    # I
    .param p3, "processRecord"    # Lcom/android/server/am/ProcessRecord;
    .param p4, "component"    # Ljava/lang/String;
    .param p5, "reason"    # Ljava/lang/String;

    .line 84
    nop

    .line 85
    if-eqz p3, :cond_8

    invoke-virtual {p3}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v0

    goto :goto_9

    :cond_8
    const/4 v0, -0x1

    :goto_9
    move v4, v0

    .line 84
    move-object v1, p0

    move v2, p1

    move v3, p2

    move-object v5, p4

    move-object v6, p5

    .end local p1    # "fromUid":I
    .end local p2    # "uid":I
    .end local p4    # "component":Ljava/lang/String;
    .end local p5    # "reason":Ljava/lang/String;
    .local v2, "fromUid":I
    .local v3, "uid":I
    .local v5, "component":Ljava/lang/String;
    .local v6, "reason":Ljava/lang/String;
    invoke-direct/range {v1 .. v6}, Lcom/android/server/am/OplusActivityManagerHelper;->notifyComponentPreventToNMS(IIILjava/lang/String;Ljava/lang/String;)V

    .line 86
    return-void
.end method
