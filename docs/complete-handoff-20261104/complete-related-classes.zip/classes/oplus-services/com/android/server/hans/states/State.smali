.class public Lcom/android/server/hans/states/State;
.super Ljava/lang/Object;
.source "State.java"

# interfaces
.implements Lcom/android/server/hans/states/IState;


# instance fields
.field protected mAction:Lcom/android/server/hans/states/action/Action;


# direct methods
.method protected constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    return-void
.end method


# virtual methods
.method public enter()V
    .registers 1

    .line 16
    return-void
.end method

.method public exit()V
    .registers 1

    .line 20
    return-void
.end method

.method public getAction()Lcom/android/server/hans/states/action/Action;
    .registers 2

    .line 35
    iget-object v0, p0, Lcom/android/server/hans/states/State;->mAction:Lcom/android/server/hans/states/action/Action;

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 4

    .line 29
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 30
    .local v0, "name":Ljava/lang/String;
    const/16 v1, 0x24

    invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    .line 31
    .local v1, "lastDollar":I
    add-int/lit8 v2, v1, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public processMessage(Landroid/os/Message;)Z
    .registers 3
    .param p1, "msg"    # Landroid/os/Message;

    .line 24
    const/4 v0, 0x0

    return v0
.end method
