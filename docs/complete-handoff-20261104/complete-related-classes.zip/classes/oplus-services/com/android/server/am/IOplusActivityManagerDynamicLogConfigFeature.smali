.class public interface abstract Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;
.super Ljava/lang/Object;
.source "IOplusActivityManagerDynamicLogConfigFeature.java"

# interfaces
.implements Landroid/common/IOplusCommonFeature;


# static fields
.field public static final DEFAULT:Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;

.field public static final NAME:Ljava/lang/String; = "IOplusActivityManagerDynamicLogConfigFeature"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 35
    new-instance v0, Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature$1;

    invoke-direct {v0}, Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature$1;-><init>()V

    sput-object v0, Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;->DEFAULT:Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;

    return-void
.end method


# virtual methods
.method public doDump(Lcom/android/server/am/ActivityManagerService;Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;I)Z
    .registers 9
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "cmd"    # Ljava/lang/String;
    .param p3, "fd"    # Ljava/io/FileDescriptor;
    .param p4, "pw"    # Ljava/io/PrintWriter;
    .param p5, "args"    # [Ljava/lang/String;
    .param p6, "opti"    # I

    .line 49
    const-string v0, "IOplusActivityManagerDynamicLogConfigFeature"

    const-string v1, "default doDump"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 50
    const/4 v0, 0x0

    return v0
.end method

.method public enableDefaultLogIfNeed()V
    .registers 1

    .line 55
    return-void
.end method

.method public getDefault()Landroid/common/IOplusCommonFeature;
    .registers 2

    .line 42
    sget-object v0, Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;->DEFAULT:Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;

    return-object v0
.end method

.method public index()Landroid/common/OplusFeatureList$OplusIndex;
    .registers 2

    .line 38
    sget-object v0, Landroid/common/OplusFeatureList$OplusIndex;->IOplusActivityManagerDynamicLogConfigFeature:Landroid/common/OplusFeatureList$OplusIndex;

    return-object v0
.end method
