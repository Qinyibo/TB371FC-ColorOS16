.class Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;
.super Lcom/android/server/hans/states/State;
.source "HansAppStateMachine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/states/HansAppStateMachine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "DefaultState"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/hans/states/HansAppStateMachine;


# direct methods
.method constructor <init>(Lcom/android/server/hans/states/HansAppStateMachine;)V
    .registers 2
    .param p1, "this$0"    # Lcom/android/server/hans/states/HansAppStateMachine;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 166
    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-direct {p0}, Lcom/android/server/hans/states/State;-><init>()V

    return-void
.end method

.method private transToFrozen()V
    .registers 12

    .line 217
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    const-string v1, ", pkg="

    const-string/jumbo v2, "uid="

    if-eqz v0, :cond_5a

    .line 218
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " D is already frozen"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 219
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_25e

    .line 220
    :cond_5a
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->isImportantForSM(Z)Z

    move-result v0

    if-eqz v0, :cond_112

    .line 221
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", top app, cannot transition from D to F, importance="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 222
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "D->F(lcdoff)"

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addImportanceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 223
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v1, v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckExistingQuotaTask(Lcom/android/server/hans/states/HansAppStateMachine;ILjava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_25e

    .line 225
    :cond_112
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    .line 226
    .local v5, "curElapsedTime":J
    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeTime()J

    move-result-wide v7

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v9

    invoke-static/range {v4 .. v9}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckDelayFreeze(Lcom/android/server/hans/states/HansAppStateMachine;JJLjava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    .line 227
    .local v0, "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    iget-object v4, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_185

    .line 228
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", top app, can not transition from D to F. reason: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 229
    return-void

    .line 231
    :cond_185
    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v7

    sub-long v7, v5, v7

    .line 232
    .local v7, "deltaTime":J
    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v9

    cmp-long v4, v7, v9

    if-gtz v4, :cond_253

    .line 233
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    iget-object v9, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v9}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v9

    iget-object v10, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v10}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v10

    invoke-virtual {v10}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4, v9, v10}, Lcom/android/server/am/OplusHansManager;->hasTouchedWindow(ILjava/lang/String;)I

    move-result v4

    if-ne v4, v3, :cond_20c

    .line 234
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v9

    sub-long/2addr v9, v7

    const/16 v4, 0x15

    invoke-virtual {v3, v4, v9, v10}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 235
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " can not transition from D to F. reason: inputEvent"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 236
    return-void

    .line 238
    :cond_20c
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_253

    .line 239
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " no input event"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 242
    :cond_253
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 244
    .end local v0    # "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    .end local v5    # "curElapsedTime":J
    .end local v7    # "deltaTime":J
    :goto_25e
    return-void
.end method

.method private transToRunning()V
    .registers 9

    .line 209
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRunningState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 210
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setAlive(Z)V

    .line 212
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 213
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v6

    .line 212
    invoke-virtual/range {v2 .. v7}, Lcom/android/server/hans/OplusHansDBConfig;->getRtoMCheckTime(ILjava/lang/String;IJ)J

    move-result-wide v1

    const/4 v3, 0x4

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 214
    return-void
.end method


# virtual methods
.method public enter()V
    .registers 1

    .line 170
    return-void
.end method

.method public exit()V
    .registers 1

    .line 174
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 205
    const-string v0, "Default"

    return-object v0
.end method

.method public processMessage(Landroid/os/Message;)Z
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;

    .line 178
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    const-string v2, ", pkg="

    const-string/jumbo v3, "uid="

    sparse-switch v0, :sswitch_data_b6

    .line 198
    return v1

    .line 184
    :sswitch_c
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 185
    .local v0, "curResumedUid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v2

    if-nez v2, :cond_b5

    .line 186
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    if-ne v2, v0, :cond_b5

    .line 187
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->transToFrozen()V

    goto/16 :goto_b5

    .line 192
    .end local v0    # "curResumedUid":I
    :sswitch_2f
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_71

    .line 193
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " D CMD_FREEZE"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 195
    :cond_71
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->transToFrozen()V

    .line 196
    goto :goto_b5

    .line 180
    :sswitch_75
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " enter SM"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 181
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;->transToRunning()V

    .line 182
    nop

    .line 200
    :cond_b5
    :goto_b5
    return v1

    :sswitch_data_b6
    .sparse-switch
        0x14 -> :sswitch_75
        0x15 -> :sswitch_2f
        0x67 -> :sswitch_c
    .end sparse-switch
.end method
