.class public Lcom/android/server/hans/scene/HansSceneManager;
.super Ljava/lang/Object;
.source "HansSceneManager.java"

# interfaces
.implements Lcom/android/server/hans/scene/IOplusBgSceneCallback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;,
        Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;,
        Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    }
.end annotation


# static fields
.field private static final AIRPLANE_SCENE_TARGET:I = 0x7

.field public static final APP_TARGET_EX_WHITELIST:I = 0x4

.field public static final APP_TARGET_INVALID:I = 0x0

.field public static final APP_TARGET_MAX:I = 0x8

.field public static final APP_TARGET_THIRD:I = 0x1

.field public static final APP_TARGET_WHITELIST:I = 0x2

.field private static final CHECK_EXECUTING_COMPONENT_DELAY_TIME:J = 0x64L

.field private static final DEEP_SLEEP_SCENE_TARGET:I = 0x7

.field static final DYNAMIC_BACKGROUND:Ljava/lang/String; = "dynamic-background"

.field private static final ENTER_SYS_BLACK_GRAY_DELAY_TIME:J = 0x2710L

.field public static final FASTFREEZER_REASON_COLD_START:Ljava/lang/String; = "cold-start"

.field public static final FASTFREEZER_REASON_FOLD:Ljava/lang/String; = "fold-open"

.field public static final FASTFREEZER_REASON_OSENSE:Ljava/lang/String; = "osense"

.field public static final FASTFREEZER_REASON_SKIP_FRAME:Ljava/lang/String; = "skip-frame"

.field private static final FAST_FREEZER_SCENE_TARGET:I = 0x7

.field private static final HANS_MAIN_HANDLER_THREAD_NAME:Ljava/lang/String; = "HansMainHandler"

.field private static final LCD_ON_OFF_SCENE_TARGET:I = 0x5

.field private static final MINUTES_OF_DAY:I = 0x5a0

.field private static final MIN_MOVE_SLOP:I = 0x28

.field public static final MSG_APP_SWITCH:I = 0x1

.field public static final MSG_BIO_UNLOCK:I = 0x24

.field private static final MSG_CPU_HIGH_LOAD_MODE:I = 0x1b

.field private static final MSG_DEEPSLEEP_OFF:I = 0xc

.field private static final MSG_DEEP_IDLE_SCENE:I = 0x15

.field private static final MSG_DEEP_SLEEP_PREDICT_TIME_CHANGED:I = 0x19

.field private static final MSG_DELAY_UPDATE_HANS_WL_BY_APPUSAGE:I = 0x22

.field private static final MSG_ENTER_FAST_FREEZE:I = 0x11

.field private static final MSG_ENTER_HIGH_LOADING_FREEZE:I = 0x12

.field private static final MSG_EXIT_FAST_FREEZER:I = 0x2

.field private static final MSG_EXIT_HIGH_LOADING_FREEZE:I = 0x13

.field private static final MSG_EXIT_MIN_SYSTEM_BY_LAUNCHER:I = 0x29

.field private static final MSG_FORCE_TRANS_STATE_IN_NIGHT_DIS_NET:I = 0x23

.field public static final MSG_FREEZE_CHECK_EXECUTING_COMPONENT:I = 0x28

.field private static final MSG_HANS_DISABLED:I = 0xa

.field private static final MSG_IDLE_SCENE:I = 0x14

.field public static final MSG_LCD_OFF:I = 0x4

.field private static final MSG_LCD_OFF_UNIFIED_FREEZE:I = 0x16

.field public static final MSG_LCD_ON:I = 0x3

.field private static final MSG_MIN_SYSTEM_MODE:I = 0x25

.field private static final MSG_NIGHT_DEEP_DOZE_MODE:I = 0x17

.field private static final MSG_POST_FREEZE_CHECK:I = 0x5

.field private static final MSG_PRELOAD_FREEZE_AGAIN:I = 0x10

.field public static final MSG_REGISTER_AUDIO_POLICY:I = 0x27

.field private static final MSG_REPEAT_ENTER_HIGH_LOADING_FREEZE:I = 0x1a

.field private static final MSG_RESET_NET_STATE:I = 0x18

.field public static final MSG_SCENE_FLING_END:I = 0x1d

.field public static final MSG_SCENE_FLING_START:I = 0x1c

.field private static final MSG_SECOND_DISPLAY_STATE:I = 0x21

.field private static final MSG_SET_FIREWALL:I = 0x6

.field private static final MSG_STRICT_MODE:I = 0x20

.field private static final MSG_UFZ_UID_TCP:I = 0x1e

.field private static final MSG_UID_ACTIVE:I = 0x8

.field private static final MSG_UID_GONE:I = 0x9

.field private static final MSG_UID_IDLE:I = 0x7

.field private static final MSG_UID_PROC_ADJ_CHANGED:I = 0x26

.field private static final MSG_UNFIREWALL_UID_TCP:I = 0x1f

.field private static final MSG_UPDATE_SYS_BLACK_GRAY:I = 0xd

.field private static final MS_OF_MINUTE:I = 0xea60

.field public static final NIGHT_DEEP_DOZE_MODE:Ljava/lang/String; = "night deep doze mode"

.field private static final PRELOAD_RETRY_DELAY_TIME:J = 0xbb8L

.field public static final SCENE_ID_AIRPLANE:I = 0x8

.field public static final SCENE_ID_CAMERA_MIN_SYSTEM:I = 0x400

.field public static final SCENE_ID_CPU_HIGH_LOAD:I = 0x20

.field public static final SCENE_ID_DEEP_IDLE:I = 0x4

.field public static final SCENE_ID_DEEP_SLEEP:I = 0x1

.field public static final SCENE_ID_DP_UID_DISNET:I = 0x80

.field public static final SCENE_ID_DP_UID_DISNET_WHEN_SWITCH_CLOSE:I = 0x100

.field public static final SCENE_ID_GAME_MIN_SYSTEM:I = 0x200

.field public static final SCENE_ID_IDLE:I = 0x2

.field public static final SCENE_ID_LIVE_STREAM_MIN_SYSTEM:I = 0x800

.field public static final SCENE_ID_NIGHT_DEEP_DOZE:I = 0x10

.field public static final SCENE_ID_STRICT_MODE:I = 0x40

.field public static final SCENE_TAG_CPU_HIGH_LOAD:Ljava/lang/String; = "CpuHighLoad"

.field private static final SM_EVENT_DEEPSLEEP_OFF:I = 0x6

.field private static final SM_EVENT_EXIT_NIGHT_DIS_NET_WHEN_SWITCH_CLOSE:I = 0x9

.field private static final SM_EVENT_FF_EXIT:I = 0x3

.field private static final SM_EVENT_HANS_DISABLED:I = 0x4

.field private static final SM_EVENT_HIGH_LOAD_FREEZE:I = 0x7

.field private static final SM_EVENT_LCD_OFF_UNIFIED_FREEZE:I = 0x2

.field private static final SM_EVENT_LCD_ON:I = 0x1

.field private static final SM_EVENT_NIGHT_DIS_NET:I = 0x8

.field private static final STRICT_MODE:Ljava/lang/String; = "StrictMode-"

.field public static final TARGET_FOR_ALL:I = 0x7

.field public static final TARGET_FOR_RESTRICTION:I = 0x7

.field public static final THERMAL_CAMERA_FOREGROUND_SCENE:I = 0x2

.field public static final THERMAL_GAME_FOCUS_SCENE:I = 0x1

.field public static final THERMAL_IM_FLOAT_WINDOW_SCENE:I = 0x4

.field public static final THERMAL_IM_SPLIT_WINDOW_SCENE:I = 0x8

.field public static final THERMAL_MAX_SCENE:I = 0x7fffffff

.field public static final THERMAL_NORMAL_SCENE:I = 0x0

.field private static final UNKNOWN_ADJ:I = 0x3e9

.field private static volatile sInstance:Lcom/android/server/hans/scene/HansSceneManager;


# instance fields
.field private volatile LastFFCameraApp:Z

.field private mAdjTestSwitch:Z

.field private mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mAlarmManager:Landroid/app/AlarmManager;

.field private mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

.field private mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

.field private mCheckBufferTime:J

.field private mCheckMinTime:J

.field private mContext:Landroid/content/Context;

.field private mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mCurrentCameraMinSysSubSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private final mDSSkipBtSet:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mDeepSleepPredictEndTimeChanged:Z

.field private mDeepSleepPredictEndTimeMs:J

.field private mDeepSleepPredictStartTimeChanged:Z

.field private mDeepSleepPredictStartTimeMs:J

.field private mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private final mEnterNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

.field private mExitCameraMinSystemTime:J

.field private final mExitNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

.field private final mFFTryFrozeByHighload:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private final mFFTryFrozeList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mFastFreezerFrozenPkgs:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private mFastFreezerOn:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

.field private final mHansMapRWLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

.field private final mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

.field private final mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

.field private mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private volatile mInCpuHighLoadMode:Z

.field private volatile mInHighloadFreezing:Z

.field private mInNightDeepDoze:Z

.field private mInvalidHansWhitelist:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private mLastCheckMsgTime:J

.field private mLastEvent:I

.field private mLastFastFreezerEnterTime:Ljava/util/concurrent/atomic/AtomicLong;

.field private mLastLcdOffTime:J

.field private mLastLcdOnTime:J

.field private mLcdOffFastFreezeCheckNum:I

.field private mLcdOffFreezerRunnable:Ljava/lang/Runnable;

.field private mLcdOffScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

.field private mLcdOffTriggerTime:J

.field private mLcdOnScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

.field private mLightDozeTime:J

.field private final mManagedGrayPkgSet:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mManagedMapExWhitelist:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private mManagedMapThird:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private mManagedMapWhitelist:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation
.end field

.field private final mMediaMutePlayerSet:Landroid/util/ArraySet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mNightDeepDozeAlarmEnterTimeMs:J

.field private mNightDeepDozeAlarmExitTimeMs:J

.field private mNightDeepDozeConfigEndTimeMs:J

.field private mNightDeepDozeConfigStartTimeMs:J

.field private mNightDeepDozeEndTimeMs:J

.field private mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mNightDeepDozeStartTimeMs:J

.field private mRemoveForceTransToMiddleStateUidsRunnable:Ljava/lang/Runnable;

.field private final mRunningUidAdjMap:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mRunningUidSet:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

.field private mSetCameraMinSysSubScene:Ljava/lang/String;

.field private mStartX:I

.field private mStartY:I

.field private mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

.field private mStrictModeSceneStr:Ljava/lang/String;

.field private final mTcpRetransmissionRestrictSet:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mThermalIgnoreTrafficSet:Landroid/util/ArraySet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mThermalMode:Z

.field private mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final mThermalProxyPartnerUid:Landroid/util/ArraySet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mThermalSkipImpPkgs:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Lcom/android/server/hans/OplusHansPackage;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final mUidObserver:Landroid/app/IUidObserver;

.field private mUidToPkgNameForDualApps:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$Ch2ksox0jdFPGT8At6UeI8AJ5ug(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->lambda$new$5()V

    return-void
.end method

.method public static synthetic $r8$lambda$F3G2vN7RQrXPa2mlTtR22llldNQ(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeProxyAlarmSetForRestrictionChanged()V

    return-void
.end method

.method public static synthetic $r8$lambda$G_VVOPtAd1w9NCK53qD4x2ZpYro(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->lambda$new$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$SQdVTupYcbvR7wCHvMZQ-gLQVH0(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->lambda$exitDpUidDisNetWhenOptSwitchClose$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$UrG6f9Wm4bPSV2zwnD0u7AmE7JU(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->lambda$removeAllInvalidHansWlUid$9()V

    return-void
.end method

.method public static synthetic $r8$lambda$jxodTB2TF0l_cA5JfK63MNnwqqY(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->lambda$updateHansWLByAppUsage$8()V

    return-void
.end method

.method public static synthetic $r8$lambda$lyUVJZ8Ot13G97klQFbv1MyW1vc(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeProxyDeepDozeChanged()V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetmAdjTestSwitch(Lcom/android/server/hans/scene/HansSceneManager;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAdjTestSwitch:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmLastLcdOffTime(Lcom/android/server/hans/scene/HansSceneManager;)J
    .registers 3

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    return-wide v0
.end method

.method static bridge synthetic -$$Nest$fgetmLcdOffSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneCombo;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmLcdOnSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneCombo;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmNightDeepDozeAlarmExitTimeMs(Lcom/android/server/hans/scene/HansSceneManager;)J
    .registers 3

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    return-wide v0
.end method

.method static bridge synthetic -$$Nest$fgetmRunningUidAdjMap(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/HashMap;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmRunningUidSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputmLastLcdOffTime(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmLastLcdOnTime(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOnTime:J

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmLcdOffTriggerTime(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmNightDeepDozeAlarmEnterTimeMs(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmEnterTimeMs:J

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmNightDeepDozeAlarmExitTimeMs(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;Lcom/android/server/hans/scene/HansSceneCombo;)V
    .registers 2

    iput-object p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    return-void
.end method

.method static bridge synthetic -$$Nest$mcancelFreezeForLcdOff(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelFreezeForLcdOff()V

    return-void
.end method

.method static bridge synthetic -$$Nest$menterFastFreezer(Lcom/android/server/hans/scene/HansSceneManager;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/server/hans/scene/HansSceneManager;->enterFastFreezer(ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mexitFastFreezeByHighload(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitFastFreezeByHighload()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mexitFastFreezer(Lcom/android/server/hans/scene/HansSceneManager;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->exitFastFreezer(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mexitMinSystemScene(Lcom/android/server/hans/scene/HansSceneManager;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->exitMinSystemScene(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mfilterWhitelistUidByAppUsage(Lcom/android/server/hans/scene/HansSceneManager;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->filterWhitelistUidByAppUsage(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mfreezeForPreload(Lcom/android/server/hans/scene/HansSceneManager;Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeForPreload(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mgetDeepSleepPredictTimeRangeString(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/lang/String;
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getDeepSleepPredictTimeRangeString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mgetMainHandlerMsgStr(Lcom/android/server/hans/scene/HansSceneManager;I)Ljava/lang/String;
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getMainHandlerMsgStr(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mhandleHighload(Lcom/android/server/hans/scene/HansSceneManager;Landroid/util/ArrayMap;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->handleHighload(Landroid/util/ArrayMap;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mnotifyDependencyApp(Lcom/android/server/hans/scene/HansSceneManager;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->notifyDependencyApp(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->notifyEventToSM(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mrefreshNightDeepDozeTimeMs(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->refreshNightDeepDozeTimeMs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mresetNetstate(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->resetNetstate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnterNightDeepDozeAlarm(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->setEnterNightDeepDozeAlarm()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetExitNightDeepDozeAlarm(Lcom/android/server/hans/scene/HansSceneManager;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->setExitNightDeepDozeAlarm()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFirstFreezeForLcdOff(Lcom/android/server/hans/scene/HansSceneManager;J)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->setFirstFreezeForLcdOff(J)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    .line 138
    const/4 v0, 0x0

    sput-object v0, Lcom/android/server/hans/scene/HansSceneManager;->sInstance:Lcom/android/server/hans/scene/HansSceneManager;

    return-void
.end method

.method private constructor <init>()V
    .registers 7

    .line 377
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 151
    const-string v0, "StrictMode-"

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    .line 163
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerOn:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 164
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    .line 166
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 168
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentCameraMinSysSubSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 169
    const-string v0, ""

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSetCameraMinSysSubScene:Ljava/lang/String;

    .line 170
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitCameraMinSystemTime:J

    .line 172
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 173
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 174
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 175
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 176
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    .line 177
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    .line 185
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeChanged:Z

    .line 186
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeChanged:Z

    .line 195
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    .line 196
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    .line 199
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    .line 202
    new-instance v0, Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-direct {v0}, Lcom/android/server/hans/scene/HansSceneCombo;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    .line 206
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    .line 207
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    .line 208
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    .line 209
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    .line 216
    new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapRWLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 217
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapRWLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    .line 218
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapRWLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    .line 221
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    .line 224
    new-instance v4, Landroid/util/ArraySet;

    invoke-direct {v4}, Landroid/util/ArraySet;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    .line 228
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    .line 230
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAdjTestSwitch:Z

    .line 233
    new-instance v4, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v4, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastFastFreezerEnterTime:Ljava/util/concurrent/atomic/AtomicLong;

    .line 234
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->LastFFCameraApp:Z

    .line 235
    new-instance v4, Landroid/util/SparseArray;

    invoke-direct {v4}, Landroid/util/SparseArray;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    .line 236
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    .line 237
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeByHighload:Ljava/util/ArrayList;

    .line 238
    new-instance v4, Landroid/util/ArraySet;

    invoke-direct {v4}, Landroid/util/ArraySet;-><init>()V

    iput-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    .line 241
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    .line 242
    iput v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    .line 243
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    .line 244
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOnTime:J

    .line 245
    const-wide/16 v4, 0x1388

    iput-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckMinTime:J

    .line 246
    const-wide/32 v4, 0x493e0

    iput-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLightDozeTime:J

    .line 247
    const-wide/16 v4, 0x2710

    iput-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckBufferTime:J

    .line 248
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastCheckMsgTime:J

    .line 250
    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

    .line 251
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iput-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidToPkgNameForDualApps:Ljava/util/HashMap;

    .line 252
    new-instance v2, Landroid/util/ArraySet;

    invoke-direct {v2}, Landroid/util/ArraySet;-><init>()V

    iput-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    .line 253
    new-instance v2, Landroid/util/ArraySet;

    invoke-direct {v2}, Landroid/util/ArraySet;-><init>()V

    iput-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    .line 270
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInHighloadFreezing:Z

    .line 271
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInCpuHighLoadMode:Z

    .line 273
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInNightDeepDoze:Z

    .line 288
    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    .line 345
    new-instance v0, Lcom/android/server/hans/scene/HansSceneManager$1;

    invoke-direct {v0, p0}, Lcom/android/server/hans/scene/HansSceneManager$1;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidObserver:Landroid/app/IUidObserver;

    .line 1140
    new-instance v0, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda8;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRemoveForceTransToMiddleStateUidsRunnable:Ljava/lang/Runnable;

    .line 1647
    new-instance v0, Lcom/android/server/hans/scene/HansSceneManager$2;

    invoke-direct {v0, p0}, Lcom/android/server/hans/scene/HansSceneManager$2;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mEnterNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    .line 1706
    new-instance v0, Lcom/android/server/hans/scene/HansSceneManager$3;

    invoke-direct {v0, p0}, Lcom/android/server/hans/scene/HansSceneManager$3;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    .line 2229
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartX:I

    .line 2230
    iput v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartY:I

    .line 2231
    iput v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    .line 2498
    new-instance v0, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda9;

    invoke-direct {v0, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda9;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFreezerRunnable:Ljava/lang/Runnable;

    .line 378
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "HansMainHandler"

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    .line 379
    .local v0, "thread":Landroid/os/HandlerThread;
    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 380
    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getThreadId()I

    move-result v3

    invoke-direct {v1, p0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;-><init>(Lcom/android/server/hans/scene/HansSceneManager;Landroid/os/Looper;I)V

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    .line 381
    return-void
.end method

.method private addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V
    .registers 5
    .param p1, "extScene"    # Lcom/android/server/hans/scene/HansScene;

    .line 1356
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 1358
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    .line 1359
    .local v0, "oldTargetFlags":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->addExtension(Lcom/android/server/hans/scene/HansScene;)Z

    .line 1360
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->addExtension(Lcom/android/server/hans/scene/HansScene;)Z

    .line 1361
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v1

    .line 1362
    .local v1, "newTargetFlags":I
    invoke-direct {p0, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateTargetMap(II)V
    :try_end_1e
    .catchall {:try_start_5 .. :try_end_1e} :catchall_25

    .line 1364
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1365
    nop

    .line 1366
    return-void

    .line 1364
    .end local v0    # "oldTargetFlags":I
    .end local v1    # "newTargetFlags":I
    :catchall_25
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1365
    throw v0
.end method

.method private addOrRemoveExtensionProxyFlagForAllHansPkg(ZI)V
    .registers 10
    .param p1, "add"    # Z
    .param p2, "targetFlags"    # I

    .line 795
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isChinaMode()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 796
    return-void

    .line 798
    :cond_b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->proxyCpnExtensionEnable()Z

    move-result v0

    if-nez v0, :cond_16

    .line 799
    return-void

    .line 801
    :cond_16
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isBlackHansPkgEnable()Z

    move-result v0

    .line 802
    .local v0, "blackHansPkgEnable":Z
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 804
    const/4 v1, 0x1

    .local v1, "i":I
    :goto_24
    const/16 v2, 0x8

    if-ge v1, v2, :cond_92

    .line 805
    const/4 v2, 0x0

    .line 807
    .local v2, "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    and-int v3, v1, p2

    const/4 v4, 0x1

    if-ne v3, v4, :cond_34

    .line 808
    :try_start_2e
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v2, v3

    goto :goto_45

    .line 838
    .end local v1    # "i":I
    .end local v2    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_32
    move-exception v1

    goto :goto_8c

    .line 809
    .restart local v1    # "i":I
    .restart local v2    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :cond_34
    and-int v3, v1, p2

    const/4 v4, 0x2

    if-ne v3, v4, :cond_3d

    .line 810
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v2, v3

    goto :goto_45

    .line 811
    :cond_3d
    and-int v3, v1, p2

    const/4 v4, 0x4

    if-ne v3, v4, :cond_45

    .line 812
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v2, v3

    .line 814
    :cond_45
    :goto_45
    if-nez v2, :cond_48

    .line 815
    goto :goto_89

    .line 819
    :cond_48
    const/4 v3, 0x0

    .local v3, "j":I
    :goto_49
    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v4

    if-ge v3, v4, :cond_89

    .line 820
    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 821
    .local v4, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_86

    .line 823
    if-eqz v0, :cond_68

    .line 824
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansDBConfig;->isBlackHansApp(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_68

    .line 825
    goto :goto_86

    .line 829
    :cond_68
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackApp(I)Z

    move-result v5

    if-eqz v5, :cond_77

    .line 830
    goto :goto_86

    .line 833
    :cond_77
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v5

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansDBConfig;->getProxyCpnExtensionMask()I

    move-result v6

    invoke-virtual {v5, p1, v6}, Lcom/android/server/hans/states/HansAppStateMachine;->addOrRemoveActionProxyFlags(ZI)V
    :try_end_86
    .catchall {:try_start_2e .. :try_end_86} :catchall_32

    .line 819
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_86
    :goto_86
    add-int/lit8 v3, v3, 0x1

    goto :goto_49

    .line 804
    .end local v2    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v3    # "j":I
    :cond_89
    :goto_89
    shl-int/lit8 v1, v1, 0x1

    goto :goto_24

    .line 838
    .end local v1    # "i":I
    :goto_8c
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 839
    throw v1

    .line 838
    :cond_92
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 839
    nop

    .line 840
    return-void
.end method

.method private appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V
    .registers 7
    .param p1, "sb"    # Ljava/lang/StringBuilder;
    .param p2, "tag"    # Ljava/lang/String;
    .param p3, "isOn"    # Z

    .line 4000
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    filled-new-array {p2, v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "(%s|%s) "

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4001
    return-void
.end method

.method private cancelEnterNightDeepDozeAlarm()V
    .registers 5

    .line 1631
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmEnterTimeMs:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_9

    .line 1632
    return-void

    .line 1634
    :cond_9
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v0, :cond_19

    .line 1635
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1637
    :cond_19
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_36

    .line 1638
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mEnterNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/AlarmManager$OnAlarmListener;)V

    .line 1639
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmEnterTimeMs:J

    .line 1640
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_36

    .line 1641
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "night deep doze mode cancel enter alarm succeed"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1645
    :cond_36
    return-void
.end method

.method private cancelExitNightDeepDozeAlarm()V
    .registers 5

    .line 1690
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_9

    .line 1691
    return-void

    .line 1693
    :cond_9
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v0, :cond_19

    .line 1694
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1696
    :cond_19
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_36

    .line 1697
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/AlarmManager$OnAlarmListener;)V

    .line 1698
    iput-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    .line 1699
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_36

    .line 1700
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "night deep doze mode cancel exit alarm succeed"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1704
    :cond_36
    return-void
.end method

.method private cancelFreezeForLcdOff()V
    .registers 3

    .line 2478
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFreezerRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 2479
    return-void
.end method

.method private cancelNotificationRestrictionsIfNecessary()V
    .registers 3

    .line 5039
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInCameraVocalScene()Z

    move-result v0

    if-nez v0, :cond_7

    .line 5040
    return-void

    .line 5042
    :cond_7
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    const-string/jumbo v1, "exit min system"

    invoke-virtual {v0, v1}, Lcom/android/server/am/OplusHansManager;->cancelNotificationRestrictions(Ljava/lang/String;)V

    .line 5043
    return-void
.end method

.method private changeNightDeepDoze(Z)V
    .registers 3
    .param p1, "isDozeMode"    # Z

    .line 4606
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isNightDeepDozeEnable()Z

    move-result v0

    if-eqz v0, :cond_13

    .line 4607
    if-eqz p1, :cond_10

    .line 4608
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->enterNightDeepDoze()V

    goto :goto_13

    .line 4610
    :cond_10
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitNightDeepDoze()V

    .line 4613
    :cond_13
    :goto_13
    return-void
.end method

.method private checkIfFastFreezeCurResumedUid(I)V
    .registers 7
    .param p1, "resumedUidWhenFF"    # I

    .line 1968
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v0

    .line 1969
    .local v0, "CurResumedUid":I
    if-ne v0, p1, :cond_b

    .line 1970
    return-void

    .line 1973
    :cond_b
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 1975
    :try_start_10
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;
    :try_end_18
    .catchall {:try_start_10 .. :try_end_18} :catchall_53

    .line 1976
    .local v1, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v1, :cond_20

    .line 1981
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1977
    return-void

    .line 1979
    :cond_20
    :try_start_20
    const-string v2, "TopActivity"

    const-string v3, ""

    invoke-virtual {p0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v2
    :try_end_28
    .catchall {:try_start_20 .. :try_end_28} :catchall_53

    .line 1981
    .end local v1    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .local v2, "state":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1982
    nop

    .line 1983
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "checkIfFastFreezeCurResumedUid: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ",frozen State: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1984
    return-void

    .line 1981
    .end local v2    # "state":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    :catchall_53
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1982
    throw v1
.end method

.method private clearMutePlayerSet()V
    .registers 3

    .line 4946
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 4947
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    invoke-virtual {v1}, Landroid/util/ArraySet;->clear()V

    .line 4948
    monitor-exit v0

    .line 4949
    return-void

    .line 4948
    :catchall_a
    move-exception v1

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_a

    throw v1
.end method

.method private dumpSingleAppInfoLocked(Lcom/android/server/hans/OplusHansPackage;Z)Ljava/lang/String;
    .registers 9
    .param p1, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "importanceList"    # Z

    .line 3953
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 3954
    .local v0, "sb":Ljava/lang/StringBuilder;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "pkg: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%-50s"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3955
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "   uid: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%5d"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3956
    if-eqz p2, :cond_fe

    .line 3959
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "Traffic"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3960
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/4 v2, 0x2

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "Float"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3961
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/4 v2, 0x4

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "Audio"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3962
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "ARec"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3963
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/16 v2, 0x10

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "GPS"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3964
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/16 v2, 0x20

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "BT"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3965
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/16 v2, 0x800

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "SRec"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3966
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/16 v2, 0x2000

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "Widget"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3967
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/high16 v2, 0x10000

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "ActWindow"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3968
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/high16 v2, 0x40000

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "Access"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    .line 3969
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    const/high16 v2, 0x100000

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    const-string v2, "FG"

    invoke-direct {p0, v0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->appendImportance(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    goto/16 :goto_23e

    .line 3971
    :cond_fe
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "   type: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%2d"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3972
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isRuleAllow()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(net|%s) "

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3973
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 3974
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lcom/android/server/am/OplusHansManager;->isAllowBootStart(Ljava/lang/String;I)Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .line 3975
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v3, v4, v5}, Lcom/android/server/am/OplusHansManager;->isAllowAssStart(Ljava/lang/String;I)Z

    move-result v3

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    filled-new-array {v2, v3}, [Ljava/lang/Object;

    move-result-object v2

    .line 3973
    const-string v3, " --(autoStart|%s) (assStart|%s) "

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3976
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(appClass|%s)"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3977
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurState()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "|"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v3

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurStateStayTimeStr(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(%s) "

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3978
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1e5

    .line 3979
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(IR|%s) "

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3981
    :cond_1e5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_202

    .line 3982
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(UR|%s) "

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3985
    :cond_202
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFGService()Z

    move-result v1

    if-eqz v1, :cond_20d

    .line 3986
    const-string v1, " --(FGS=true) "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3988
    :cond_20d
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFreezeSilentAudio()Z

    move-result v1

    if-eqz v1, :cond_218

    .line 3989
    const-string v1, " --(AUDIO_SILENCE=true) "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3991
    :cond_218
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->proxyAction()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, " --(proxyFlags|%s)"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3992
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isGrayPkg(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_23e

    .line 3993
    const-string v1, " --(gray) "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3996
    :cond_23e
    :goto_23e
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private enterFastFreezer(ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;
    .registers 25
    .param p1, "curResumedUid"    # I
    .param p2, "curResumedPkg"    # Ljava/lang/String;
    .param p3, "freezeTimeout"    # I
    .param p4, "reason"    # Ljava/lang/String;

    .line 1809
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move/from16 v3, p3

    const-string v4, "FastFreezer-Disable"

    .line 1810
    .local v4, "ret":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isFastFreezerEnable()Z

    move-result v0

    if-eqz v0, :cond_32e

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneManager;->isFastFreezerOn()Z

    move-result v0

    if-eqz v0, :cond_1e

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    goto/16 :goto_332

    .line 1815
    :cond_1e
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    .line 1816
    .local v5, "ffEnterTime":J
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isFastFreezeHotEnable(Ljava/lang/String;)Z

    move-result v7

    .line 1818
    .local v7, "frontCamera":Z
    if-lez v3, :cond_2e

    .line 1819
    int-to-long v8, v3

    .local v8, "frozenTimeout":J
    goto :goto_a1

    .line 1821
    .end local v8    # "frozenTimeout":J
    :cond_2e
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getFastFreezeInterval()J

    move-result-wide v8

    .line 1822
    .local v8, "ffInterval":J
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mLastFastFreezerEnterTime:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v10

    sub-long v10, v5, v10

    .line 1823
    .local v10, "ffEnterInterval":J
    cmp-long v0, v10, v8

    if-gez v0, :cond_96

    .line 1824
    if-eqz v7, :cond_79

    .line 1825
    iget-boolean v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->LastFFCameraApp:Z

    if-eqz v0, :cond_96

    const-wide/16 v12, 0x2

    div-long v14, v8, v12

    cmp-long v0, v10, v14

    if-gez v0, :cond_96

    .line 1826
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "Fast Freezer interval is less than "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    div-long v12, v8, v12

    invoke-virtual {v14, v12, v13}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " , frontCamera="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1827
    const-string v0, "FastFreezer-Skip-Interval"

    .line 1828
    .end local v4    # "ret":Ljava/lang/String;
    .local v0, "ret":Ljava/lang/String;
    return-object v0

    .line 1831
    .end local v0    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :cond_79
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Fast Freezer interval is less than "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1832
    const-string v0, "FastFreezer-Skip-Interval"

    .line 1833
    .end local v4    # "ret":Ljava/lang/String;
    .restart local v0    # "ret":Ljava/lang/String;
    return-object v0

    .line 1836
    .end local v0    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :cond_96
    iput-boolean v7, v1, Lcom/android/server/hans/scene/HansSceneManager;->LastFFCameraApp:Z

    .line 1837
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansDBConfig;->getFastFreezeTimeout(Ljava/lang/String;)J

    move-result-wide v12

    move-wide v8, v12

    .line 1840
    .end local v10    # "ffEnterInterval":J
    .local v8, "frozenTimeout":J
    :goto_a1
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    move-object v10, v0

    .line 1842
    .local v10, "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v11, v0

    .line 1843
    .local v11, "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    move-object v12, v0

    .line 1844
    .local v12, "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 1847
    :try_start_b8
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v13, v0

    .line 1848
    .local v13, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_bf
    :goto_bf
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0
    :try_end_c3
    .catchall {:try_start_b8 .. :try_end_c3} :catchall_323

    if-eqz v0, :cond_10f

    .line 1849
    :try_start_c5
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    move v14, v0

    .line 1850
    .local v14, "ruid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v0

    if-eq v14, v0, :cond_bf

    .line 1851
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStartingActivityUid()I

    move-result v0

    if-ne v14, v0, :cond_e5

    .line 1852
    goto :goto_bf

    .line 1854
    :cond_e5
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneItem;->getTargetFlags()I

    move-result v0

    invoke-direct {v1, v14, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    move-object v15, v0

    .line 1855
    .local v15, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v15, :cond_f3

    .line 1856
    goto :goto_bf

    .line 1858
    :cond_f3
    invoke-virtual {v15}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v16

    monitor-enter v16
    :try_end_f8
    .catchall {:try_start_c5 .. :try_end_f8} :catchall_108

    .line 1859
    :try_start_f8
    invoke-virtual {v15}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    if-eqz v0, :cond_100

    .line 1860
    monitor-exit v16

    goto :goto_bf

    .line 1862
    :cond_100
    invoke-virtual {v10, v14, v15}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 1863
    monitor-exit v16

    .line 1864
    .end local v14    # "ruid":I
    goto :goto_bf

    .line 1863
    .restart local v14    # "ruid":I
    :catchall_105
    move-exception v0

    monitor-exit v16
    :try_end_107
    .catchall {:try_start_f8 .. :try_end_107} :catchall_105

    .end local v4    # "ret":Ljava/lang/String;
    .end local v5    # "ffEnterTime":J
    .end local v7    # "frontCamera":Z
    .end local v8    # "frozenTimeout":J
    .end local v10    # "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v11    # "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .end local v12    # "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "curResumedUid":I
    .end local p2    # "curResumedPkg":Ljava/lang/String;
    .end local p3    # "freezeTimeout":I
    .end local p4    # "reason":Ljava/lang/String;
    :try_start_107
    throw v0
    :try_end_108
    .catchall {:try_start_107 .. :try_end_108} :catchall_108

    .line 1866
    .end local v13    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    .end local v14    # "ruid":I
    .end local v15    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local v4    # "ret":Ljava/lang/String;
    .restart local v5    # "ffEnterTime":J
    .restart local v7    # "frontCamera":Z
    .restart local v8    # "frozenTimeout":J
    .restart local v10    # "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v11    # "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .restart local v12    # "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "curResumedUid":I
    .restart local p2    # "curResumedPkg":Ljava/lang/String;
    .restart local p3    # "freezeTimeout":I
    .restart local p4    # "reason":Ljava/lang/String;
    :catchall_108
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    goto/16 :goto_328

    :cond_10f
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1867
    nop

    .line 1869
    invoke-virtual {v10}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-nez v0, :cond_127

    .line 1870
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v13, "Fast Freezer has no uids to freeze"

    invoke-virtual {v0, v13}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1871
    const-string v0, "FastFreezer-Skip-NoTargets"

    .line 1872
    .end local v4    # "ret":Ljava/lang/String;
    .restart local v0    # "ret":Ljava/lang/String;
    return-object v0

    .line 1877
    .end local v0    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :cond_127
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    iget-object v13, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v13}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->getThreadId()I

    move-result v13

    const/4 v14, 0x1

    invoke-virtual {v0, v13, v14}, Lcom/android/server/am/OplusHansManager;->setThreadUx(IZ)V

    .line 1880
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mLastFastFreezerEnterTime:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0, v5, v6}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    .line 1881
    invoke-direct {v1, v14}, Lcom/android/server/hans/scene/HansSceneManager;->setFastFreezerOn(Z)V

    .line 1884
    invoke-direct {v1, v10}, Lcom/android/server/hans/scene/HansSceneManager;->fastFreezeAppList(Landroid/util/SparseArray;)Ljava/util/ArrayList;

    move-result-object v13

    .line 1885
    .local v13, "fastFreezeUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v15

    .line 1887
    .local v15, "itPkg":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/hans/OplusHansPackage;>;"
    const/16 v16, 0x0

    .line 1888
    .local v16, "cnt":I
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1889
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneItem;->getImportanceFlags()I

    move-result v0

    .line 1890
    .local v0, "importantFlag":I
    if-eqz v7, :cond_160

    .line 1891
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Lcom/android/server/hans/OplusHansDBConfig;->getSkipFastFreezeImptCheck()I

    move-result v14

    not-int v14, v14

    and-int/2addr v0, v14

    move v14, v0

    goto :goto_161

    .line 1890
    :cond_160
    move v14, v0

    .line 1893
    .end local v0    # "importantFlag":I
    .local v14, "importantFlag":I
    :goto_161
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 1896
    :try_start_166
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V

    .line 1897
    :goto_16b
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v0
    :try_end_16f
    .catchall {:try_start_166 .. :try_end_16f} :catchall_318

    if-eqz v0, :cond_221

    .line 1898
    :try_start_171
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/OplusHansPackage;

    move-object/from16 v17, v0

    .line 1899
    .local v17, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual/range {v17 .. v17}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v19

    monitor-enter v19
    :try_end_17e
    .catchall {:try_start_171 .. :try_end_17e} :catchall_21a

    .line 1900
    :try_start_17e
    invoke-virtual/range {v17 .. v17}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0
    :try_end_182
    .catchall {:try_start_17e .. :try_end_182} :catchall_213

    if-eqz v0, :cond_18b

    .line 1901
    :try_start_184
    monitor-exit v19
    :try_end_185
    .catchall {:try_start_184 .. :try_end_185} :catchall_186

    goto :goto_19a

    .line 1920
    :catchall_186
    move-exception v0

    move-object/from16 v2, v17

    goto/16 :goto_216

    .line 1902
    :cond_18b
    :try_start_18b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual/range {v17 .. v17}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansDBConfig;->inFastFreezeWhiteList(Ljava/lang/String;)Z

    move-result v0
    :try_end_197
    .catchall {:try_start_18b .. :try_end_197} :catchall_213

    if-eqz v0, :cond_19d

    .line 1903
    :try_start_199
    monitor-exit v19
    :try_end_19a
    .catchall {:try_start_199 .. :try_end_19a} :catchall_186

    .line 1897
    .end local v17    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :goto_19a
    move-object/from16 v2, p2

    goto :goto_16b

    .line 1907
    .restart local v17    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_19d
    :try_start_19d
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v0
    :try_end_1a1
    .catchall {:try_start_19d .. :try_end_1a1} :catchall_213

    move-object/from16 v2, v17

    .end local v17    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .local v2, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :try_start_1a3
    invoke-virtual {v0, v2, v14}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v0

    if-eqz v0, :cond_1b5

    .line 1908
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v12, v0, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_208

    .line 1909
    :cond_1b5
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/android/server/am/OplusHansManager;->isTaskAffinityPackage(I)Z

    move-result v0

    if-eqz v0, :cond_1cd

    .line 1910
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    const-string v3, "TaskAffinity"

    invoke-virtual {v12, v0, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_208

    .line 1912
    :cond_1cd
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v0, v3, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 1913
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1914
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1f6
    .catchall {:try_start_1a3 .. :try_end_1f6} :catchall_218

    .line 1915
    add-int/lit8 v3, v16, 0x1

    .line 1916
    .end local v16    # "cnt":I
    .local v3, "cnt":I
    :try_start_1f8
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getFFMaxFzNum()I

    move-result v0

    if-lt v3, v0, :cond_206

    .line 1917
    monitor-exit v19
    :try_end_203
    .catchall {:try_start_1f8 .. :try_end_203} :catchall_20f

    move/from16 v16, v3

    goto :goto_221

    .line 1916
    :cond_206
    move/from16 v16, v3

    .line 1920
    .end local v3    # "cnt":I
    .restart local v16    # "cnt":I
    :goto_208
    :try_start_208
    monitor-exit v19

    move-object/from16 v2, p2

    move/from16 v3, p3

    goto/16 :goto_16b

    .end local v16    # "cnt":I
    .restart local v3    # "cnt":I
    :catchall_20f
    move-exception v0

    move/from16 v16, v3

    goto :goto_216

    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "cnt":I
    .restart local v16    # "cnt":I
    .restart local v17    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_213
    move-exception v0

    move-object/from16 v2, v17

    .end local v17    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :goto_216
    monitor-exit v19
    :try_end_217
    .catchall {:try_start_208 .. :try_end_217} :catchall_218

    .end local v4    # "ret":Ljava/lang/String;
    .end local v5    # "ffEnterTime":J
    .end local v7    # "frontCamera":Z
    .end local v8    # "frozenTimeout":J
    .end local v10    # "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v11    # "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .end local v12    # "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    .end local v13    # "fastFreezeUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v14    # "importantFlag":I
    .end local v15    # "itPkg":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v16    # "cnt":I
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "curResumedUid":I
    .end local p2    # "curResumedPkg":Ljava/lang/String;
    .end local p3    # "freezeTimeout":I
    .end local p4    # "reason":Ljava/lang/String;
    :try_start_217
    throw v0
    :try_end_218
    .catchall {:try_start_217 .. :try_end_218} :catchall_21a

    .restart local v4    # "ret":Ljava/lang/String;
    .restart local v5    # "ffEnterTime":J
    .restart local v7    # "frontCamera":Z
    .restart local v8    # "frozenTimeout":J
    .restart local v10    # "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v11    # "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .restart local v12    # "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    .restart local v13    # "fastFreezeUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v14    # "importantFlag":I
    .restart local v15    # "itPkg":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v16    # "cnt":I
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "curResumedUid":I
    .restart local p2    # "curResumedPkg":Ljava/lang/String;
    .restart local p3    # "freezeTimeout":I
    .restart local p4    # "reason":Ljava/lang/String;
    :catchall_218
    move-exception v0

    goto :goto_216

    .line 1923
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_21a
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    goto/16 :goto_31d

    :cond_221
    :goto_221
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1924
    nop

    .line 1927
    const/4 v0, 0x1

    invoke-direct {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->fastFreezeAllApp(Z)V

    .line 1928
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->getThreadId()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Lcom/android/server/am/OplusHansManager;->setThreadUx(IZ)V

    .line 1930
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 1932
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_23f
    :try_start_23f
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2
    :try_end_245
    .catchall {:try_start_23f .. :try_end_245} :catchall_30d

    if-ge v0, v2, :cond_267

    .line 1933
    :try_start_247
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_251

    .line 1934
    const/4 v3, 0x1

    goto :goto_25d

    .line 1936
    :cond_251
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setFrozen(Z)V
    :try_end_25d
    .catchall {:try_start_247 .. :try_end_25d} :catchall_260

    .line 1932
    :goto_25d
    add-int/lit8 v0, v0, 0x1

    goto :goto_23f

    .line 1942
    .end local v0    # "i":I
    :catchall_260
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    goto/16 :goto_312

    .line 1938
    :cond_267
    :try_start_267
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0
    :try_end_26b
    .catchall {:try_start_267 .. :try_end_26b} :catchall_30d

    if-eqz v0, :cond_28a

    .line 1939
    :try_start_26d
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "enter FF list "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v1, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_28a
    .catchall {:try_start_26d .. :try_end_28a} :catchall_260

    .line 1942
    :cond_28a
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1943
    nop

    .line 1945
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1946
    .local v0, "sb":Ljava/lang/StringBuilder;
    const-string/jumbo v2, "enter FastFreezer, frontApp: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move/from16 v3, p1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1947
    const-string v2, ", frozen uids: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v11}, Ljava/util/ArrayList;->stream()Ljava/util/stream/Stream;

    move-result-object v3

    move-object/from16 v17, v4

    .end local v4    # "ret":Ljava/lang/String;
    .local v17, "ret":Ljava/lang/String;
    new-instance v4, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda7;

    invoke-direct {v4}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda7;-><init>()V

    invoke-interface {v3, v4}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object v3

    invoke-static {}, Ljava/util/stream/Collectors;->toList()Ljava/util/stream/Collector;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1948
    const-string v2, ", important uids: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1949
    const-string v2, ", reason: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-object/from16 v3, p4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1950
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1951
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->addFFInfo(Ljava/lang/String;)V

    .line 1952
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string/jumbo v4, "enterFF"

    invoke-virtual {v2, v11, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyFreezeTrace(Ljava/util/ArrayList;Ljava/lang/String;)V

    .line 1956
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1959
    .end local v17    # "ret":Ljava/lang/String;
    .local v2, "ret":Ljava/lang/String;
    iget-object v4, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-object/from16 v18, v0

    .end local v0    # "sb":Ljava/lang/StringBuilder;
    .local v18, "sb":Ljava/lang/StringBuilder;
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-object/from16 v17, v2

    .end local v2    # "ret":Ljava/lang/String;
    .restart local v17    # "ret":Ljava/lang/String;
    const/4 v2, 0x2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v4, v0, v8, v9}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 1963
    invoke-direct/range {p0 .. p1}, Lcom/android/server/hans/scene/HansSceneManager;->checkIfFastFreezeCurResumedUid(I)V

    .line 1964
    return-object v17

    .line 1942
    .end local v17    # "ret":Ljava/lang/String;
    .end local v18    # "sb":Ljava/lang/StringBuilder;
    .restart local v4    # "ret":Ljava/lang/String;
    :catchall_30d
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    .end local v4    # "ret":Ljava/lang/String;
    .restart local v17    # "ret":Ljava/lang/String;
    :goto_312
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1943
    throw v0

    .line 1923
    .end local v17    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :catchall_318
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    .end local v4    # "ret":Ljava/lang/String;
    .restart local v17    # "ret":Ljava/lang/String;
    :goto_31d
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1924
    throw v0

    .line 1866
    .end local v13    # "fastFreezeUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v14    # "importantFlag":I
    .end local v15    # "itPkg":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v16    # "cnt":I
    .end local v17    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :catchall_323
    move-exception v0

    move-object/from16 v3, p4

    move-object/from16 v17, v4

    .end local v4    # "ret":Ljava/lang/String;
    .restart local v17    # "ret":Ljava/lang/String;
    :goto_328
    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1867
    throw v0

    .line 1810
    .end local v5    # "ffEnterTime":J
    .end local v7    # "frontCamera":Z
    .end local v8    # "frozenTimeout":J
    .end local v10    # "pkgsToFreeze":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v11    # "frozenApps":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .end local v12    # "importantUids":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    .end local v17    # "ret":Ljava/lang/String;
    .restart local v4    # "ret":Ljava/lang/String;
    :cond_32e
    move-object/from16 v3, p4

    move-object/from16 v17, v4

    .line 1811
    .end local v4    # "ret":Ljava/lang/String;
    .restart local v17    # "ret":Ljava/lang/String;
    :goto_332
    return-object v17
.end method

.method private enterMinSystemScene(I)V
    .registers 14
    .param p1, "sceneId"    # I

    .line 4821
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4822
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v0

    if-eqz v0, :cond_2c

    .line 4823
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "already in MinSystem Scene: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4824
    return-void

    .line 4826
    :cond_2c
    const/4 v0, 0x0

    .line 4827
    .local v0, "subSceneId":I
    const-string v1, ""

    .line 4829
    .local v1, "sceneName":Ljava/lang/String;
    const/16 v2, 0x200

    if-ne p1, v2, :cond_4d

    .line 4830
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isMinSystemEnable(I)Z

    move-result v2

    if-nez v2, :cond_47

    .line 4831
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string v3, "Game MinSystem Scene is not enable"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4832
    return-void

    .line 4834
    :cond_47
    const-string/jumbo v1, "gameMinSystem"

    move-object v2, v1

    goto/16 :goto_ec

    .line 4837
    :cond_4d
    const/16 v2, 0x800

    if-ne p1, v2, :cond_6b

    .line 4838
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isMinSystemEnable(I)Z

    move-result v2

    if-nez v2, :cond_65

    .line 4839
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string v3, "LiveStream MinSystem Scene is not enable"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4840
    return-void

    .line 4842
    :cond_65
    const-string/jumbo v1, "livingMinSystem"

    move-object v2, v1

    goto/16 :goto_ec

    .line 4845
    :cond_6b
    const/16 v2, 0x400

    if-ne p1, v2, :cond_eb

    .line 4846
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isMinSystemEnable(I)Z

    move-result v2

    if-nez v2, :cond_83

    .line 4847
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string v3, "camera MinSystem Scene is not enable"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4848
    return-void

    .line 4851
    :cond_83
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->isHighExtremeMode()Z

    move-result v2

    if-eqz v2, :cond_98

    .line 4852
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string/jumbo v3, "in high extremeMode, not enter cameraMinSystem Scene"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4853
    return-void

    .line 4856
    :cond_98
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitCameraMinSystemTime:J

    sub-long/2addr v2, v4

    .line 4857
    .local v2, "exitCameraMinSysDuration":J
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getEnterCameraMinSysIntervalTime()J

    move-result-wide v4

    cmp-long v4, v2, v4

    if-gtz v4, :cond_ce

    .line 4858
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    const-string/jumbo v5, "exit cameraMinSystem Scene less interval time."

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4860
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getEnterCameraMinSysIntervalTime()J

    move-result-wide v4

    sub-long v10, v4, v2

    .line 4861
    .local v10, "nextTryTime":J
    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v4, 0x1

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    const/16 v7, 0x25

    const/16 v8, 0x400

    invoke-static/range {v6 .. v11}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/Object;J)V

    .line 4862
    return-void

    .line 4865
    .end local v10    # "nextTryTime":J
    :cond_ce
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSetCameraMinSysSubScene:Ljava/lang/String;

    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneIdByStr(Ljava/lang/String;)I

    move-result v0

    .line 4866
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "cameraMinSystem-"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSetCameraMinSysSubScene:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-object v2, v1

    goto :goto_ec

    .line 4845
    .end local v2    # "exitCameraMinSysDuration":J
    :cond_eb
    move-object v2, v1

    .line 4870
    .end local v1    # "sceneName":Ljava/lang/String;
    .local v2, "sceneName":Ljava/lang/String;
    :goto_ec
    new-instance v1, Lcom/android/server/hans/scene/HansSceneItem;

    .line 4871
    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getMinSystemImportance(II)I

    move-result v3

    const/16 v5, 0xc

    const/4 v6, 0x7

    const/16 v4, 0x1fe

    invoke-direct/range {v1 .. v6}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 4875
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v1, v3}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v1

    if-nez v1, :cond_16a

    .line 4876
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Enter MinSystem Scene:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneItem;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4877
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "enter minSystem: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneItem;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 4879
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4880
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentCameraMinSysSubSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4881
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 4883
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getMinSystemSkipImportance(II)I

    move-result v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansImportance;->setSkipImportance(I)V

    .line 4885
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayPackage()V

    .line 4887
    const-string/jumbo v1, "enterMinSystemScene"

    invoke-virtual {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeAllApps(Ljava/lang/String;)V

    .line 4889
    :cond_16a
    return-void
.end method

.method private exitDpUidDisNetWhenOptSwitchClose()V
    .registers 3

    .line 1120
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda12;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->post(Ljava/lang/Runnable;)Z

    .line 1123
    return-void
.end method

.method private exitFastFreezeByHighload()V
    .registers 5

    .line 4335
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeByHighload:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    .line 4336
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/freeze/HansCGroup;->FastFreezeExit(I)V

    .line 4337
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_6

    .line 4338
    :cond_1c
    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInHighloadFreezing:Z

    if-eqz v0, :cond_30

    .line 4339
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getCycleEnterHLDelay()I

    move-result v1

    int-to-long v1, v1

    const/16 v3, 0x1a

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessageDelayed(IJ)Z

    .line 4341
    :cond_30
    return-void
.end method

.method private exitFastFreezer(Ljava/lang/String;)V
    .registers 10
    .param p1, "reason"    # Ljava/lang/String;

    .line 1999
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2000
    .local v0, "unfreezeList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 2001
    .local v1, "thawList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 2003
    :try_start_f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    .local v2, "i":I
    :goto_17
    if-ltz v2, :cond_67

    .line 2004
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 2005
    .local v4, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v4, :cond_24

    .line 2006
    goto :goto_61

    .line 2008
    :cond_24
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5
    :try_end_29
    .catchall {:try_start_f .. :try_end_29} :catchall_144

    .line 2009
    :try_start_29
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v6

    if-eqz v6, :cond_43

    .line 2010
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_60

    .line 2012
    :cond_43
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v1, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2013
    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 2014
    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v6, v2}, Landroid/util/SparseArray;->removeAt(I)V

    .line 2017
    :goto_60
    monitor-exit v5

    .line 2003
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :goto_61
    add-int/lit8 v2, v2, -0x1

    goto :goto_17

    .line 2017
    .restart local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_64
    move-exception v3

    monitor-exit v5
    :try_end_66
    .catchall {:try_start_29 .. :try_end_66} :catchall_64

    .end local v0    # "unfreezeList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .end local v1    # "thawList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "reason":Ljava/lang/String;
    :try_start_66
    throw v3
    :try_end_67
    .catchall {:try_start_66 .. :try_end_67} :catchall_144

    .line 2034
    .end local v2    # "i":I
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .restart local v0    # "unfreezeList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/String;>;>;"
    .restart local v1    # "thawList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "reason":Ljava/lang/String;
    :cond_67
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 2035
    nop

    .line 2037
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->getThreadId()I

    move-result v4

    invoke-virtual {v2, v4, v3}, Lcom/android/server/am/OplusHansManager;->setThreadUx(IZ)V

    .line 2038
    const/4 v2, 0x0

    invoke-direct {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->fastFreezeAllApp(Z)V

    .line 2039
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->getThreadId()I

    move-result v5

    invoke-virtual {v4, v5, v2}, Lcom/android/server/am/OplusHansManager;->setThreadUx(IZ)V

    .line 2041
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 2043
    :try_start_90
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    move-result v4

    sub-int/2addr v4, v3

    .local v4, "i":I
    :goto_97
    if-ltz v4, :cond_b5

    .line 2044
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_a2

    .line 2045
    goto :goto_b2

    .line 2047
    :cond_a2
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansPackage;->setFrozen(Z)V

    .line 2048
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->removeAt(I)V

    .line 2043
    :goto_b2
    add-int/lit8 v4, v4, -0x1

    goto :goto_97

    .line 2050
    .end local v4    # "i":I
    :cond_b5
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_d8

    .line 2051
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "exit FF list "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_d8
    .catchall {:try_start_90 .. :try_end_d8} :catchall_13d

    .line 2054
    :cond_d8
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 2055
    nop

    .line 2057
    invoke-direct {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->setFastFreezerOn(Z)V

    .line 2059
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 2060
    .local v2, "sb":Ljava/lang/StringBuilder;
    const-string/jumbo v3, "exit FastFreezer, unfreeze uids: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/util/ArrayList;->stream()Ljava/util/stream/Stream;

    move-result-object v4

    new-instance v5, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda5;

    invoke-direct {v5}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda5;-><init>()V

    invoke-interface {v4, v5}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object v4

    invoke-static {}, Ljava/util/stream/Collectors;->toList()Ljava/util/stream/Collector;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " thaw: "

    .line 2061
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", reason: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2062
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 2063
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->addFFInfo(Ljava/lang/String;)V

    .line 2064
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v0, p1, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyUnFreezeTrace(Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;)V

    .line 2065
    const/4 v3, 0x3

    invoke-direct {p0, v3}, Lcom/android/server/hans/scene/HansSceneManager;->notifyEventToSM(I)V

    .line 2066
    return-void

    .line 2054
    .end local v2    # "sb":Ljava/lang/StringBuilder;
    :catchall_13d
    move-exception v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 2055
    throw v2

    .line 2034
    :catchall_144
    move-exception v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 2035
    throw v2
.end method

.method private exitMinSystemScene(I)V
    .registers 5
    .param p1, "sceneId"    # I

    .line 4892
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4893
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_85

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_85

    .line 4894
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v0

    if-nez v0, :cond_1c

    goto :goto_85

    .line 4899
    :cond_1c
    const/16 v0, 0x400

    if-ne p1, v0, :cond_26

    .line 4900
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitCameraMinSystemTime:J

    .line 4902
    :cond_26
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Exit MinSystem Scene: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneItem;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4903
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "exit minSystem: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneItem;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 4904
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4905
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelNotificationRestrictionsIfNecessary()V

    .line 4906
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentCameraMinSysSubSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4907
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMinSystemScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 4909
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayPackage()V

    .line 4911
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansImportance;->setSkipImportance(I)V

    .line 4912
    return-void

    .line 4895
    :cond_85
    :goto_85
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "Already exit MinSystem Scene"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4896
    return-void
.end method

.method private fastFreezeAllApp(Z)V
    .registers 7
    .param p1, "enter"    # Z

    .line 2069
    if-eqz p1, :cond_81

    .line 2070
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isCgroupV2()Z

    move-result v0

    if-eqz v0, :cond_2a

    .line 2071
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_d
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_29

    .line 2072
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 2073
    .local v1, "uid":I
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v2, v1}, Lcom/android/server/hans/freeze/HansCGroup;->FastFreezeEnter(I)V

    .line 2071
    .end local v1    # "uid":I
    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    .end local v0    # "i":I
    :cond_29
    goto :goto_5d

    .line 2076
    :cond_2a
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2078
    const/4 v0, 0x0

    .restart local v0    # "i":I
    :goto_30
    :try_start_30
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-ge v0, v1, :cond_57

    .line 2079
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    .line 2080
    .local v1, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_54

    .line 2081
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2
    :try_end_47
    .catchall {:try_start_30 .. :try_end_47} :catchall_7a

    .line 2082
    :try_start_47
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    const-string/jumbo v4, "enterFF"

    invoke-virtual {v3, v1, v4}, Lcom/android/server/hans/freeze/HansCGroup;->hansFreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Z

    .line 2083
    monitor-exit v2

    goto :goto_54

    :catchall_51
    move-exception v3

    monitor-exit v2
    :try_end_53
    .catchall {:try_start_47 .. :try_end_53} :catchall_51

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "enter":Z
    :try_start_53
    throw v3
    :try_end_54
    .catchall {:try_start_53 .. :try_end_54} :catchall_7a

    .line 2078
    .end local v1    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "enter":Z
    :cond_54
    :goto_54
    add-int/lit8 v0, v0, 0x1

    goto :goto_30

    .line 2087
    .end local v0    # "i":I
    :cond_57
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2088
    nop

    .line 2090
    :goto_5d
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "FastFreeze enter, freeze uids: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_ec

    .line 2087
    :catchall_7a
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2088
    throw v0

    .line 2092
    :cond_81
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isCgroupV2()Z

    move-result v0

    if-eqz v0, :cond_a9

    .line 2093
    const/4 v0, 0x0

    .restart local v0    # "i":I
    :goto_8c
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_a8

    .line 2094
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 2095
    .local v1, "uid":I
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v2, v1}, Lcom/android/server/hans/freeze/HansCGroup;->FastFreezeExit(I)V

    .line 2093
    .end local v1    # "uid":I
    add-int/lit8 v0, v0, 0x1

    goto :goto_8c

    .end local v0    # "i":I
    :cond_a8
    goto :goto_d0

    .line 2098
    :cond_a9
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2100
    const/4 v0, 0x0

    .restart local v0    # "i":I
    :goto_af
    :try_start_af
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-ge v0, v1, :cond_ca

    .line 2101
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    const-string/jumbo v2, "exitFF"

    const-string v3, ""

    invoke-virtual {p0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDirectly(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    :try_end_c7
    .catchall {:try_start_af .. :try_end_c7} :catchall_ed

    .line 2100
    add-int/lit8 v0, v0, 0x1

    goto :goto_af

    .line 2104
    .end local v0    # "i":I
    :cond_ca
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2105
    nop

    .line 2107
    :goto_d0
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "FastFreeze exit, unfreeze uids: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFFTryFrozeList:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 2109
    :goto_ec
    return-void

    .line 2104
    :catchall_ed
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2105
    throw v0
.end method

.method private fastFreezeAppList(Landroid/util/SparseArray;)Ljava/util/ArrayList;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;)",
            "Ljava/util/ArrayList<",
            "Lcom/android/server/hans/OplusHansPackage;",
            ">;"
        }
    .end annotation

    .line 1987
    .local p1, "freezeAppList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1989
    .local v0, "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_6
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_20

    .line 1990
    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 1991
    .local v2, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v2, :cond_1d

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1d

    .line 1992
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1989
    :cond_1d
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 1995
    .end local v1    # "i":I
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_20
    return-object v0
.end method

.method private filterWhitelistUidByAppUsage(I)V
    .registers 15
    .param p1, "count"    # I

    .line 4428
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isQueryAppUsageEnable()Z

    move-result v0

    if-nez v0, :cond_1b

    .line 4429
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 4430
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "queryAppUsageEnable:false."

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4432
    :cond_1a
    return-void

    .line 4434
    :cond_1b
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_6c

    .line 4435
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x22

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_34

    .line 4436
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4438
    :cond_34
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 4439
    .local v0, "msg":Landroid/os/Message;
    add-int/lit8 v1, p1, 0x1

    iput v1, v0, Landroid/os/Message;->arg1:I

    .line 4440
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getAppUsageMgsDelayTime()J

    move-result-wide v2

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 4441
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_6b

    .line 4442
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "delay update hans whitelist by AppUsage becauseOf screenOn, count: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4444
    :cond_6b
    return-void

    .line 4447
    .end local v0    # "msg":Landroid/os/Message;
    :cond_6c
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    .line 4448
    .local v5, "nowElapsedRealtime":J
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getQueryAppUsageIntervalTime()J

    move-result-wide v7

    .line 4449
    .local v7, "intervalQueryTime":J
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->clone()Landroid/util/SparseArray;

    move-result-object v1

    .line 4450
    .local v1, "cloneWhitelist":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    const/4 v0, 0x0

    move v2, v0

    .local v2, "i":I
    :goto_80
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-ge v2, v0, :cond_145

    .line 4451
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v4

    .line 4452
    .local v4, "uid":I
    invoke-static {}, Lcom/android/server/hans/app/AppUsageManager;->getInstance()Lcom/android/server/hans/app/AppUsageManager;

    move-result-object v0

    invoke-virtual {v0, v4, v7, v8}, Lcom/android/server/hans/app/AppUsageManager;->isAppUsedRecently(IJ)Z

    move-result v0

    if-nez v0, :cond_119

    sget-object v9, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_NOTIFICATION:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 4453
    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lcom/android/server/hans/scene/HansSceneManager;->hasNotificationInPastDays(IJJLcom/android/server/oplus/osense/OsenseConstants$AppStatusType;)Z

    move-result v0

    if-nez v0, :cond_117

    sget-object v9, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_ONGOING_NOTI:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 4454
    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lcom/android/server/hans/scene/HansSceneManager;->hasNotificationInPastDays(IJJLcom/android/server/oplus/osense/OsenseConstants$AppStatusType;)Z

    move-result v0

    if-eqz v0, :cond_a8

    goto/16 :goto_11a

    .line 4459
    :cond_a8
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v9

    .line 4460
    .local v9, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v9, :cond_da

    .line 4461
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_141

    .line 4462
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "uid: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " hansPkg is null."

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto :goto_141

    .line 4467
    :cond_da
    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v10

    monitor-enter v10

    .line 4468
    :try_start_df
    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v0

    .line 4469
    .local v0, "appClass":I
    monitor-exit v10
    :try_end_e4
    .catchall {:try_start_df .. :try_end_e4} :catchall_114

    .line 4470
    const/4 v10, 0x2

    if-ne v0, v10, :cond_ec

    .line 4471
    const/4 v10, 0x1

    invoke-virtual {p0, v10, v4}, Lcom/android/server/hans/scene/HansSceneManager;->removedUidFromWhitelistByUsage(ZI)V

    goto :goto_141

    .line 4473
    :cond_ec
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v10

    if-eqz v10, :cond_141

    .line 4474
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v12, "uid: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, " not belong third white list."

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto :goto_141

    .line 4469
    .end local v0    # "appClass":I
    :catchall_114
    move-exception v0

    :try_start_115
    monitor-exit v10
    :try_end_116
    .catchall {:try_start_115 .. :try_end_116} :catchall_114

    throw v0

    .line 4453
    .end local v9    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_117
    move-object v3, p0

    goto :goto_11a

    .line 4452
    :cond_119
    move-object v3, p0

    .line 4455
    :goto_11a
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_141

    .line 4456
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "uid:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ", has noti or recent use."

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4450
    .end local v4    # "uid":I
    :cond_141
    :goto_141
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_80

    :cond_145
    move-object v3, p0

    .line 4479
    .end local v2    # "i":I
    return-void
.end method

.method private forceTransAppStateToMInNightDisNetScene(Z)V
    .registers 6
    .param p1, "enter"    # Z

    .line 1127
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->forceTransStateInNightDisNetScene()Z

    move-result v0

    if-nez v0, :cond_b

    .line 1128
    return-void

    .line 1130
    :cond_b
    const/16 v0, 0x23

    if-eqz p1, :cond_1c

    .line 1131
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1132
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const-wide/16 v2, 0x2710

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_28

    .line 1134
    :cond_1c
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1135
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRemoveForceTransToMiddleStateUidsRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->post(Ljava/lang/Runnable;)Z

    .line 1137
    :goto_28
    return-void
.end method

.method private freezeForPreload(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 8
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 2777
    if-nez p1, :cond_5

    .line 2778
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    return-object v0

    .line 2781
    :cond_5
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansRestriction()Lcom/android/server/hans/OplusHansRestriction;

    move-result-object v0

    .line 2782
    .local v0, "currentRestriction":Lcom/android/server/hans/OplusHansRestriction;
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2783
    :try_start_12
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-eqz v2, :cond_1c

    .line 2784
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v2

    .line 2791
    :cond_1c
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v2

    const/high16 v3, 0x80000

    invoke-virtual {v2, p1, v3}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v2

    if-eqz v2, :cond_7c

    .line 2792
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_6f

    .line 2793
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", pkg="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 2794
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", , cannot transition to F, importance="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 2795
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " scene: Preload"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 2793
    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 2797
    :cond_6f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v3, 0x10

    const-wide/16 v4, 0xbb8

    invoke-static {v2, v3, p1, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;ILjava/lang/Object;J)V

    .line 2798
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v2

    .line 2800
    :cond_7c
    if-eqz p1, :cond_9b

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansDBConfig;->isInImPkgConfigList(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_9b

    .line 2801
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lcom/android/server/am/OplusHansManager;->setNetCare(ILjava/lang/String;)V

    .line 2804
    :cond_9b
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    const-string v3, "Preload_F"

    invoke-virtual {v2, p1, v3}, Lcom/android/server/hans/freeze/HansCGroup;->hansFreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Z

    move-result v2

    .line 2805
    .local v2, "isSuccessful":Z
    if-eqz v2, :cond_ba

    .line 2807
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v3, p1, v0}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleDeny(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)V

    .line 2809
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeViaSM(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2810
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v3

    invoke-virtual {v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->postFreezeCheck(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2811
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v3

    .line 2813
    :cond_ba
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v3

    .line 2815
    .end local v2    # "isSuccessful":Z
    :catchall_be
    move-exception v2

    monitor-exit v1
    :try_end_c0
    .catchall {:try_start_12 .. :try_end_c0} :catchall_be

    throw v2
.end method

.method private freezeForSceneCombo(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 7
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "currentRestriction"    # Lcom/android/server/hans/OplusHansRestriction;

    .line 2743
    if-nez p1, :cond_5

    .line 2744
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    return-object v0

    .line 2747
    :cond_5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 2748
    :try_start_a
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v1

    if-eqz v1, :cond_14

    .line 2749
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v0

    return-object v1

    .line 2752
    :cond_14
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getImportanceFlags()I

    move-result v2

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v1

    if-eqz v1, :cond_28

    .line 2753
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->IMPORTANT:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v0

    return-object v1

    .line 2756
    :cond_28
    if-eqz p1, :cond_47

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isInImPkgConfigList(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_47

    .line 2757
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lcom/android/server/am/OplusHansManager;->setNetCare(ILjava/lang/String;)V

    .line 2760
    :cond_47
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    const-string v2, ""

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/freeze/HansCGroup;->hansFreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Z

    move-result v1

    .line 2761
    .local v1, "isSuccessful":Z
    if-eqz v1, :cond_63

    .line 2763
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, p1, p2}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleDeny(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)V

    .line 2765
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v2

    invoke-virtual {v2, p1}, Lcom/android/server/hans/scene/HansSceneManager;->postFreezeCheck(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2766
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v0

    return-object v2

    .line 2768
    :cond_63
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v0

    return-object v2

    .line 2770
    .end local v1    # "isSuccessful":Z
    :catchall_67
    move-exception v1

    monitor-exit v0
    :try_end_69
    .catchall {:try_start_a .. :try_end_69} :catchall_67

    throw v1
.end method

.method private getCurrentCameraMinSysSubSceneIdByStr(Ljava/lang/String;)I
    .registers 6
    .param p1, "subScene"    # Ljava/lang/String;

    .line 5009
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v0

    const/16 v1, 0x400

    const/4 v2, 0x0

    if-ne v0, v1, :cond_a

    .line 5010
    return v2

    .line 5012
    :cond_a
    if-nez p1, :cond_16

    .line 5013
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "cameraMinSystem sub scene is null."

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    .line 5014
    return v2

    .line 5017
    :cond_16
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_72

    :cond_1d
    goto :goto_47

    :sswitch_1e
    const-string/jumbo v0, "stage"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v2, 0x2

    goto :goto_48

    :sswitch_29
    const-string v0, "Photo"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v2, 0x1

    goto :goto_48

    :sswitch_33
    const-string v0, "Scan"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    goto :goto_48

    :sswitch_3c
    const-string/jumbo v0, "normal"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v2, 0x3

    goto :goto_48

    :goto_47
    const/4 v2, -0x1

    :goto_48
    packed-switch v2, :pswitch_data_84

    .line 5031
    const/4 v0, 0x0

    .local v0, "sceneId":I
    goto :goto_56

    .line 5028
    .end local v0    # "sceneId":I
    :pswitch_4d
    const/16 v0, 0x8

    .line 5029
    .restart local v0    # "sceneId":I
    goto :goto_56

    .line 5025
    .end local v0    # "sceneId":I
    :pswitch_50
    const/4 v0, 0x4

    .line 5026
    .restart local v0    # "sceneId":I
    goto :goto_56

    .line 5022
    .end local v0    # "sceneId":I
    :pswitch_52
    const/4 v0, 0x2

    .line 5023
    .restart local v0    # "sceneId":I
    goto :goto_56

    .line 5019
    .end local v0    # "sceneId":I
    :pswitch_54
    const/4 v0, 0x1

    .line 5020
    .restart local v0    # "sceneId":I
    nop

    .line 5034
    :goto_56
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "cameraMinSystem sub scene: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 5035
    return v0

    nop

    :sswitch_data_72
    .sparse-switch
        -0x3df94319 -> :sswitch_3c
        0x273a9d -> :sswitch_33
        0x4984e12 -> :sswitch_29
        0x68ac2fe -> :sswitch_1e
    .end sparse-switch

    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_54
        :pswitch_52
        :pswitch_50
        :pswitch_4d
    .end packed-switch
.end method

.method private getDeepSleepPredictTimeRangeString()Ljava/lang/String;
    .registers 5

    .line 1777
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeMs:J

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeMs:J

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->getTimeRangeString(JJ)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;
    .registers 5
    .param p1, "uid"    # I
    .param p2, "targetFlags"    # I

    .line 2354
    const/4 v0, 0x1

    .local v0, "target":I
    :goto_1
    const/16 v1, 0x8

    if-ge v0, v1, :cond_2d

    .line 2355
    and-int v1, p2, v0

    packed-switch v1, :pswitch_data_30

    .line 2366
    :pswitch_a
    const/4 v1, 0x0

    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_27

    .line 2363
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_c
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    .line 2364
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_27

    .line 2360
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_15
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    .line 2361
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_27

    .line 2357
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_1e
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansPackage;

    .line 2358
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    nop

    .line 2369
    :goto_27
    if-eqz v1, :cond_2a

    .line 2370
    return-object v1

    .line 2354
    :cond_2a
    shl-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 2373
    .end local v0    # "target":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_2d
    const/4 v0, 0x0

    return-object v0

    nop

    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_1e
        :pswitch_15
        :pswitch_a
        :pswitch_c
    .end packed-switch
.end method

.method public static getInstance()Lcom/android/server/hans/scene/HansSceneManager;
    .registers 2

    .line 384
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager;->sInstance:Lcom/android/server/hans/scene/HansSceneManager;

    if-nez v0, :cond_17

    .line 385
    const-class v0, Lcom/android/server/hans/scene/HansSceneManager;

    monitor-enter v0

    .line 386
    :try_start_7
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager;->sInstance:Lcom/android/server/hans/scene/HansSceneManager;

    if-nez v1, :cond_12

    .line 387
    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager;

    invoke-direct {v1}, Lcom/android/server/hans/scene/HansSceneManager;-><init>()V

    sput-object v1, Lcom/android/server/hans/scene/HansSceneManager;->sInstance:Lcom/android/server/hans/scene/HansSceneManager;

    .line 389
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 391
    :cond_17
    :goto_17
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager;->sInstance:Lcom/android/server/hans/scene/HansSceneManager;

    return-object v0
.end method

.method private getMainHandlerMsgStr(I)Ljava/lang/String;
    .registers 3
    .param p1, "what"    # I

    .line 3237
    packed-switch p1, :pswitch_data_4a

    .line 3263
    :pswitch_3
    const-string/jumbo v0, "unknown msg"

    return-object v0

    .line 3261
    :pswitch_7
    const-string v0, "MSG_EXIT_MIN_SYSTEM_BY_LAUNCHER"

    return-object v0

    .line 3260
    :pswitch_a
    const-string v0, "MSG_UID_PROC_ADJ_CHANGED"

    return-object v0

    .line 3259
    :pswitch_d
    const-string v0, "MSG_MIN_SYSTEM_MODE"

    return-object v0

    .line 3258
    :pswitch_10
    const-string v0, "MSG_UNFIREWALL_UID_TCP"

    return-object v0

    .line 3257
    :pswitch_13
    const-string v0, "MSG_UFZ_UID_TCP"

    return-object v0

    .line 3255
    :pswitch_16
    const-string v0, "MSG_SCENE_FLING_END"

    return-object v0

    .line 3254
    :pswitch_19
    const-string v0, "MSG_SCENE_FLING_START"

    return-object v0

    .line 3252
    :pswitch_1c
    const-string v0, "MSG_NIGHT_DEEP_DOZE_MODE"

    return-object v0

    .line 3251
    :pswitch_1f
    const-string v0, "MSG_LCD_OFF_UNIFIED_FREEZE"

    return-object v0

    .line 3250
    :pswitch_22
    const-string v0, "MSG_ENTER_HIGH_LOADING_FREEZE"

    return-object v0

    .line 3249
    :pswitch_25
    const-string v0, "ENTER_FAST_FREEZE"

    return-object v0

    .line 3248
    :pswitch_28
    const-string v0, "DEEPSLEEP_OFF"

    return-object v0

    .line 3247
    :pswitch_2b
    const-string v0, "MSG_HANS_DISABLED"

    return-object v0

    .line 3246
    :pswitch_2e
    const-string v0, "MSG_UID_GONE"

    return-object v0

    .line 3245
    :pswitch_31
    const-string v0, "MSG_UID_ACTIVE"

    return-object v0

    .line 3244
    :pswitch_34
    const-string v0, "MSG_UID_IDLE"

    return-object v0

    .line 3243
    :pswitch_37
    const-string v0, "SET_FIREWALL"

    return-object v0

    .line 3242
    :pswitch_3a
    const-string v0, "POST_FREEZE_CHECK"

    return-object v0

    .line 3241
    :pswitch_3d
    const-string v0, "LCD_OFF"

    return-object v0

    .line 3240
    :pswitch_40
    const-string v0, "LCD_ON"

    return-object v0

    .line 3239
    :pswitch_43
    const-string v0, "EXIT_FAST_FREEZER"

    return-object v0

    .line 3238
    :pswitch_46
    const-string v0, "APP_SWITCH"

    return-object v0

    nop

    :pswitch_data_4a
    .packed-switch 0x1
        :pswitch_46
        :pswitch_43
        :pswitch_40
        :pswitch_3d
        :pswitch_3a
        :pswitch_37
        :pswitch_34
        :pswitch_31
        :pswitch_2e
        :pswitch_2b
        :pswitch_3
        :pswitch_28
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_25
        :pswitch_22
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_1f
        :pswitch_1c
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_19
        :pswitch_16
        :pswitch_13
        :pswitch_10
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_d
        :pswitch_a
        :pswitch_3
        :pswitch_3
        :pswitch_7
    .end packed-switch
.end method

.method private getMinSystemImportance(II)I
    .registers 4
    .param p1, "sceneId"    # I
    .param p2, "subSceneId"    # I

    .line 4988
    sparse-switch p1, :sswitch_data_1c

    .line 5002
    const v0, 0x1d6fbfff

    .local v0, "importance":I
    goto :goto_1b

    .line 4994
    .end local v0    # "importance":I
    :sswitch_7
    const/4 v0, 0x4

    if-eq p2, v0, :cond_13

    const/16 v0, 0x8

    if-ne p2, v0, :cond_f

    goto :goto_13

    .line 4998
    :cond_f
    const v0, 0x192b8fee

    .line 5000
    .restart local v0    # "importance":I
    goto :goto_1b

    .line 4996
    .end local v0    # "importance":I
    :cond_13
    :goto_13
    const v0, 0x192b8fee

    .restart local v0    # "importance":I
    goto :goto_1b

    .line 4991
    .end local v0    # "importance":I
    :sswitch_17
    const v0, 0x192b8fee

    .line 4992
    .restart local v0    # "importance":I
    nop

    .line 5005
    :goto_1b
    return v0

    :sswitch_data_1c
    .sparse-switch
        0x200 -> :sswitch_17
        0x400 -> :sswitch_7
        0x800 -> :sswitch_17
    .end sparse-switch
.end method

.method private getMinSystemSkipImportance(II)I
    .registers 4
    .param p1, "sceneId"    # I
    .param p2, "subSceneId"    # I

    .line 4966
    sparse-switch p1, :sswitch_data_1a

    .line 4980
    const/4 v0, 0x0

    .local v0, "skipImportance":I
    goto :goto_19

    .line 4972
    .end local v0    # "skipImportance":I
    :sswitch_5
    const/4 v0, 0x4

    if-eq p2, v0, :cond_11

    const/16 v0, 0x8

    if-ne p2, v0, :cond_d

    goto :goto_11

    .line 4976
    :cond_d
    const v0, 0x4443011

    .line 4978
    .restart local v0    # "skipImportance":I
    goto :goto_19

    .line 4974
    .end local v0    # "skipImportance":I
    :cond_11
    :goto_11
    const v0, 0x4443011

    .restart local v0    # "skipImportance":I
    goto :goto_19

    .line 4969
    .end local v0    # "skipImportance":I
    :sswitch_15
    const v0, 0x4443011

    .line 4970
    .restart local v0    # "skipImportance":I
    nop

    .line 4983
    :goto_19
    return v0

    :sswitch_data_1a
    .sparse-switch
        0x200 -> :sswitch_15
        0x400 -> :sswitch_5
        0x800 -> :sswitch_15
    .end sparse-switch
.end method

.method private getMutePlayerSet()Landroid/util/ArraySet;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 4932
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 4933
    .local v0, "result":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    monitor-enter v1

    .line 4934
    :try_start_8
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    invoke-virtual {v0, v2}, Landroid/util/ArraySet;->addAll(Landroid/util/ArraySet;)V

    .line 4935
    monitor-exit v1

    .line 4936
    return-object v0

    .line 4935
    :catchall_f
    move-exception v2

    monitor-exit v1
    :try_end_11
    .catchall {:try_start_8 .. :try_end_11} :catchall_f

    throw v2
.end method

.method private getNightDeepDozeTimeRangeString()Ljava/lang/String;
    .registers 5

    .line 1773
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->getTimeRangeString(JJ)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private getSceneId(Ljava/lang/String;)I
    .registers 5
    .param p1, "sceneName"    # Ljava/lang/String;

    .line 1280
    const/4 v0, 0x0

    if-nez p1, :cond_4

    .line 1281
    return v0

    .line 1283
    :cond_4
    const-string v1, "LcdOn"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 1284
    const/4 v0, 0x4

    return v0

    .line 1285
    :cond_e
    const-string v1, "LcdOff"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18

    .line 1286
    const/4 v0, 0x2

    return v0

    .line 1287
    :cond_18
    const-string v1, "FastFreezer"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/16 v2, 0x20

    if-eqz v1, :cond_23

    .line 1288
    return v2

    .line 1289
    :cond_23
    const-string v1, "deepSleepUidDisNet"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    .line 1290
    const-string v1, "dsUidDisNetDsSleepSwitchClose"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    .line 1291
    const-string/jumbo v1, "nightDeepDoze"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    .line 1292
    const-string v1, "deepSleep"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    goto :goto_51

    .line 1294
    :cond_45
    const-string v1, "MinSystem"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_50

    .line 1295
    const/16 v0, 0x100

    return v0

    .line 1297
    :cond_50
    return v0

    .line 1293
    :cond_51
    :goto_51
    return v2
.end method

.method private getSceneIdByScene()I
    .registers 7

    .line 1267
    const/4 v0, 0x0

    .line 1268
    .local v0, "sceneId":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneCombo;->getName()Ljava/lang/String;

    move-result-object v1

    .line 1269
    .local v1, "sceneName":Ljava/lang/String;
    const-string v2, "\\|"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 1270
    .local v2, "res":[Ljava/lang/String;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_e
    array-length v4, v2

    if-ge v3, v4, :cond_25

    .line 1271
    aget-object v4, v2, v3

    .line 1272
    .local v4, "scene":Ljava/lang/String;
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_22

    .line 1273
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/android/server/hans/scene/HansSceneManager;->getSceneId(Ljava/lang/String;)I

    move-result v5

    or-int/2addr v0, v5

    .line 1270
    .end local v4    # "scene":Ljava/lang/String;
    :cond_22
    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    .line 1276
    .end local v3    # "i":I
    :cond_25
    return v0
.end method

.method private getSmEventStr(I)Ljava/lang/String;
    .registers 3
    .param p1, "eventId"    # I

    .line 2518
    packed-switch p1, :pswitch_data_20

    .line 2528
    :pswitch_3
    const-string/jumbo v0, "unknown event id"

    return-object v0

    .line 2526
    :pswitch_7
    const-string v0, "SM_EVENT_EXIT_NIGHT_DIS_NET_WHEN_SWITCH_CLOSE"

    return-object v0

    .line 2525
    :pswitch_a
    const-string v0, "SM_EVENT_NIGHT_DIS_NET"

    return-object v0

    .line 2524
    :pswitch_d
    const-string v0, "SM_EVENT_HIGH_LOAD_FREEZE"

    return-object v0

    .line 2523
    :pswitch_10
    const-string v0, "SM_EVENT_DEEPSLEEP_OFF"

    return-object v0

    .line 2522
    :pswitch_13
    const-string v0, "SM_EVENT_HANS_DISABLED"

    return-object v0

    .line 2521
    :pswitch_16
    const-string v0, "FF_EXIT"

    return-object v0

    .line 2520
    :pswitch_19
    const-string v0, "SM_EVENT_LCD_OFF_UNIFIED_FREEZE"

    return-object v0

    .line 2519
    :pswitch_1c
    const-string v0, "LCD_ON"

    return-object v0

    nop

    :pswitch_data_20
    .packed-switch 0x1
        :pswitch_1c
        :pswitch_19
        :pswitch_16
        :pswitch_13
        :pswitch_3
        :pswitch_10
        :pswitch_d
        :pswitch_a
        :pswitch_7
    .end packed-switch
.end method

.method private getTimeRangeString(JJ)Ljava/lang/String;
    .registers 8
    .param p1, "start"    # J
    .param p3, "end"    # J

    .line 1781
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x28

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 1782
    .local v0, "sb":Ljava/lang/StringBuilder;
    invoke-static {p1, p2}, Lcom/android/server/hans/OplusHansHistoryManager;->formatSimpleTime(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " ~ "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p3, p4}, Lcom/android/server/hans/OplusHansHistoryManager;->formatSimpleTime(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1783
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private handleHighload(Landroid/util/ArrayMap;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/ArrayMap<",
            "Ljava/lang/String;",
            "Landroid/util/SparseArray<",
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;>;>;)V"
        }
    .end annotation

    .line 4289
    .local p1, "uidMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4290
    .local v0, "freezingList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    invoke-virtual {p1}, Landroid/util/ArrayMap;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    .local v1, "i":I
    :goto_b
    if-ltz v1, :cond_6f

    .line 4291
    invoke-virtual {p1, v1}, Landroid/util/ArrayMap;->keyAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 4292
    .local v2, "key":Ljava/lang/String;
    const-string/jumbo v3, "non_sys_app_task"

    invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_40

    .line 4293
    invoke-virtual {p1, v1}, Landroid/util/ArrayMap;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/SparseArray;

    .line 4294
    .local v3, "value":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;"
    if-eqz v3, :cond_6c

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v4

    if-ltz v4, :cond_6c

    .line 4295
    const/4 v4, 0x0

    .local v4, "j":I
    :goto_2b
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v4, v5, :cond_3f

    .line 4296
    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v5

    .line 4297
    .local v5, "uid":I
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4295
    add-int/lit8 v4, v4, 0x1

    goto :goto_2b

    .end local v4    # "j":I
    .end local v5    # "uid":I
    :cond_3f
    goto :goto_6c

    .line 4300
    .end local v3    # "value":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;"
    :cond_40
    const-string/jumbo v3, "sys_app_task"

    invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6c

    .line 4301
    invoke-virtual {p1, v1}, Landroid/util/ArrayMap;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/SparseArray;

    .line 4302
    .restart local v3    # "value":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;"
    if-eqz v3, :cond_6c

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v4

    if-ltz v4, :cond_6c

    .line 4303
    const/4 v4, 0x0

    .restart local v4    # "j":I
    :goto_58
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v4, v5, :cond_6c

    .line 4304
    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v5

    .line 4305
    .restart local v5    # "uid":I
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4303
    add-int/lit8 v4, v4, 0x1

    goto :goto_58

    .line 4290
    .end local v3    # "value":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;"
    .end local v4    # "j":I
    .end local v5    # "uid":I
    :cond_6c
    :goto_6c
    add-int/lit8 v1, v1, -0x1

    goto :goto_b

    .line 4311
    .end local v1    # "i":I
    .end local v2    # "key":Ljava/lang/String;
    :cond_6f
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 4312
    .local v1, "uidsOfNotManaged":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 4313
    .local v2, "uidsToNotify":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_7a
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_ca

    .line 4314
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    .line 4315
    .local v4, "uid":I
    const/4 v5, 0x5

    invoke-virtual {p0, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    .line 4316
    .local v5, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v5, :cond_be

    .line 4317
    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v7

    if-eq v6, v7, :cond_be

    .line 4318
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/android/server/hans/OplusHansDBConfig;->isInCpuHighLoadFreezeEnableWhiteList(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_be

    .line 4319
    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    .line 4320
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v7

    .line 4319
    const/4 v8, 0x7

    invoke-direct {p0, v6, v8, v7, v2}, Lcom/android/server/hans/scene/HansSceneManager;->notifySmEventLocked(IIILjava/util/List;)V

    goto :goto_c7

    .line 4322
    :cond_be
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-interface {v1, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4313
    :goto_c7
    add-int/lit8 v3, v3, 0x1

    goto :goto_7a

    .line 4325
    .end local v3    # "i":I
    .end local v4    # "uid":I
    .end local v5    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_ca
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_f5

    .line 4326
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "handleHighload freezingList="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " uidsOfNotManaged="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 4329
    :cond_f5
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_115

    .line 4330
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "SM_EVENT_HIGH_LOAD_FREEZE to uids="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4332
    :cond_115
    return-void
.end method

.method private handleStateMachineUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V
    .registers 5
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;

    .line 3203
    if-nez p1, :cond_3

    .line 3204
    return-void

    .line 3207
    :cond_3
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStateToRList()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 3208
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->unfreezeTo(ILjava/lang/String;)V

    goto :goto_4f

    .line 3209
    :cond_1a
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStateToMList()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x2

    if-eqz v0, :cond_31

    .line 3210
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    invoke-virtual {v0, v1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->unfreezeTo(ILjava/lang/String;)V

    goto :goto_4f

    .line 3211
    :cond_31
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStateToDList()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 3212
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->unfreezeTo(ILjava/lang/String;)V

    goto :goto_4f

    .line 3214
    :cond_48
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    invoke-virtual {v0, v1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->unfreezeTo(ILjava/lang/String;)V

    .line 3216
    :goto_4f
    return-void
.end method

.method private hasNotificationInPastDays(IJJLcom/android/server/oplus/osense/OsenseConstants$AppStatusType;)Z
    .registers 15
    .param p1, "uid"    # I
    .param p2, "nowElapsedRealtime"    # J
    .param p4, "intervalTime"    # J
    .param p6, "type"    # Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 4482
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p6, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->getAppStatusTime(Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;I)Landroid/util/Pair;

    move-result-object v0

    .line 4483
    .local v0, "notificationTimePair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Long;Ljava/lang/Long;>;"
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    .line 4484
    .local v1, "notiStartTime":J
    iget-object v3, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    .line 4486
    .local v3, "notiEndTime":J
    const/4 v5, 0x0

    .line 4487
    .local v5, "hasNotication":Z
    cmp-long v6, v1, v3

    if-lez v6, :cond_23

    .line 4488
    const/4 v5, 0x1

    goto :goto_30

    .line 4490
    :cond_23
    const-wide/16 v6, 0x0

    cmp-long v6, v3, v6

    if-eqz v6, :cond_30

    add-long v6, v3, p4

    cmp-long v6, v6, p2

    if-ltz v6, :cond_30

    .line 4491
    const/4 v5, 0x1

    .line 4494
    :cond_30
    :goto_30
    return v5
.end method

.method private initRunningUidSet()V
    .registers 7

    .line 485
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getRunningUidList()Ljava/util/ArrayList;

    move-result-object v0

    .line 486
    .local v0, "runningUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 488
    :try_start_d
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z
    :try_end_12
    .catchall {:try_start_d .. :try_end_12} :catchall_3b

    .line 490
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 491
    nop

    .line 492
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    monitor-enter v1

    .line 493
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_1c
    :try_start_1c
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_36

    .line 494
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    const/16 v5, 0x3e9

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 493
    add-int/lit8 v2, v2, 0x1

    goto :goto_1c

    .line 496
    .end local v2    # "i":I
    :cond_36
    monitor-exit v1

    .line 497
    return-void

    .line 496
    :catchall_38
    move-exception v2

    monitor-exit v1
    :try_end_3a
    .catchall {:try_start_1c .. :try_end_3a} :catchall_38

    throw v2

    .line 490
    :catchall_3b
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 491
    throw v1
.end method

.method private isInNight()Z
    .registers 13

    .line 1469
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->refreshNightDeepDozeTimeMs()V

    .line 1470
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isNightDeepDozeTimeRangeInvalid()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    .line 1471
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 1472
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v2, "night deep doze mode isInNight: false, time range error."

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1474
    :cond_1a
    return v1

    .line 1476
    :cond_1b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getNightDeepDozeDeltaMinutes()I

    move-result v0

    .line 1477
    .local v0, "minutesOfDelta":I
    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    sub-long/2addr v2, v4

    int-to-long v4, v0

    const-wide/16 v6, 0x3c

    mul-long/2addr v4, v6

    const-wide/16 v8, 0x3e8

    mul-long/2addr v4, v8

    cmp-long v2, v2, v4

    if-gez v2, :cond_44

    .line 1478
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_43

    .line 1479
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string/jumbo v3, "night deep doze mode isInNight: false, too short to enter."

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1481
    :cond_43
    return v1

    .line 1483
    :cond_44
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 1485
    .local v2, "nowTimeMs":J
    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    cmp-long v4, v2, v4

    if-gez v4, :cond_5f

    .line 1486
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v4

    if-eqz v4, :cond_5e

    .line 1487
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    const-string/jumbo v5, "night deep doze mode isInNight: false, out of start."

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1489
    :cond_5e
    return v1

    .line 1490
    :cond_5f
    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    cmp-long v4, v2, v4

    if-lez v4, :cond_76

    .line 1491
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v4

    if-eqz v4, :cond_75

    .line 1492
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    const-string/jumbo v5, "night deep doze mode isInNight: false, out of end."

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1494
    :cond_75
    return v1

    .line 1495
    :cond_76
    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    int-to-long v10, v0

    mul-long/2addr v10, v6

    mul-long/2addr v10, v8

    sub-long/2addr v4, v10

    cmp-long v4, v2, v4

    if-lez v4, :cond_91

    .line 1496
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v4

    if-eqz v4, :cond_90

    .line 1497
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    const-string/jumbo v5, "night deep doze mode isInNight: false, too late to enter."

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1499
    :cond_90
    return v1

    .line 1501
    :cond_91
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    const-string/jumbo v4, "night deep doze mode isInNight: true."

    invoke-virtual {v1, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1502
    const/4 v1, 0x1

    return v1
.end method

.method private isNightDeepDozeTimeRangeInvalid()Z
    .registers 5

    .line 1587
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_19

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_19

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    cmp-long v0, v0, v2

    if-gtz v0, :cond_17

    goto :goto_19

    :cond_17
    const/4 v0, 0x0

    goto :goto_1a

    :cond_19
    :goto_19
    const/4 v0, 0x1

    :goto_1a
    return v0
.end method

.method private isRestrictSysOrGrayApp(Ljava/lang/String;Z)Z
    .registers 11
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "isBlack"    # Z

    .line 1336
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 1338
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->assumeDeviceCharging()Z

    move-result v3

    .line 1339
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v4

    .line 1340
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDeepSleep()Z

    move-result v1

    if-nez v1, :cond_39

    iget-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInNightDeepDoze:Z

    if-nez v1, :cond_39

    .line 1342
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isUidDisNetEnabled()Z

    move-result v1

    if-nez v1, :cond_39

    .line 1343
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDsOrUidDisStatusWhenSwitchClose()Z

    move-result v1

    if-eqz v1, :cond_37

    goto :goto_39

    :cond_37
    const/4 v1, 0x0

    goto :goto_3a

    :cond_39
    :goto_39
    const/4 v1, 0x1

    :goto_3a
    move v5, v1

    .line 1344
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getExtremeFgMode()Z

    move-result v6

    .line 1345
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v7

    .line 1336
    move-object v1, p1

    move v2, p2

    .end local p1    # "pkgName":Ljava/lang/String;
    .end local p2    # "isBlack":Z
    .local v1, "pkgName":Ljava/lang/String;
    .local v2, "isBlack":Z
    invoke-virtual/range {v0 .. v7}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackRestrictedScene(Ljava/lang/String;ZZZZZZ)Z

    move-result p1

    .line 1346
    .local p1, "isRestricted":Z
    return p1
.end method

.method private judugeFlingAction(Landroid/view/MotionEvent;I)I
    .registers 11
    .param p1, "ev"    # Landroid/view/MotionEvent;
    .param p2, "duration"    # I

    .line 2236
    const/4 v0, -0x1

    .line 2238
    .local v0, "msgId":I
    :try_start_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    .line 2239
    .local v1, "actionMasked":I
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v2
    :try_end_9
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_9} :catch_5c

    .line 2242
    .local v2, "pointerIndex":I
    nop

    .line 2244
    const/4 v3, 0x2

    const/4 v4, -0x1

    packed-switch v1, :pswitch_data_5e

    goto :goto_5b

    .line 2254
    :pswitch_10
    iget v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    if-nez v4, :cond_5b

    .line 2255
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getX(I)F

    move-result v4

    float-to-int v4, v4

    iget v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartX:I

    sub-int/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result v4

    .line 2256
    .local v4, "diffX":I
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getY(I)F

    move-result v5

    float-to-int v5, v5

    iget v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartY:I

    sub-int/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    move-result v5

    .line 2257
    .local v5, "diffY":I
    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v6

    const/16 v7, 0x28

    if-le v6, v7, :cond_38

    .line 2258
    const/16 v0, 0x1c

    .line 2259
    iput v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    .line 2261
    .end local v4    # "diffX":I
    .end local v5    # "diffY":I
    :cond_38
    goto :goto_5b

    .line 2264
    :pswitch_39
    iget v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    if-ne v5, v3, :cond_3f

    .line 2265
    const/16 v0, 0x1d

    .line 2267
    :cond_3f
    iput v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartX:I

    .line 2268
    iput v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartY:I

    .line 2269
    iput v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    .line 2270
    goto :goto_5b

    .line 2246
    :pswitch_46
    iget v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    if-ne v3, v4, :cond_5b

    .line 2247
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    float-to-int v3, v3

    iput v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartX:I

    .line 2248
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getY(I)F

    move-result v3

    float-to-int v3, v3

    iput v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStartY:I

    .line 2249
    const/4 v3, 0x0

    iput v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastEvent:I

    .line 2276
    :cond_5b
    :goto_5b
    return v0

    .line 2240
    .end local v1    # "actionMasked":I
    .end local v2    # "pointerIndex":I
    :catch_5c
    move-exception v1

    .line 2241
    .local v1, "e":Ljava/lang/IllegalArgumentException;
    return v0

    :pswitch_data_5e
    .packed-switch 0x0
        :pswitch_46
        :pswitch_39
        :pswitch_10
    .end packed-switch
.end method

.method static synthetic lambda$enterFastFreezer$3(Landroid/util/Pair;)Ljava/lang/Integer;
    .registers 2
    .param p0, "pair"    # Landroid/util/Pair;

    .line 1947
    iget-object v0, p0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    return-object v0
.end method

.method private synthetic lambda$exitDpUidDisNetWhenOptSwitchClose$1()V
    .registers 2

    .line 1121
    const/16 v0, 0x9

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifyEventToSM(I)V

    .line 1122
    return-void
.end method

.method static synthetic lambda$exitFastFreezer$4(Landroid/util/Pair;)Ljava/lang/Integer;
    .registers 2
    .param p0, "pair"    # Landroid/util/Pair;

    .line 2060
    iget-object v0, p0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    return-object v0
.end method

.method private synthetic lambda$new$2()V
    .registers 6

    .line 1142
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 1143
    :try_start_3
    new-instance v1, Landroid/util/ArraySet;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    invoke-direct {v1, v2}, Landroid/util/ArraySet;-><init>(Landroid/util/ArraySet;)V

    .line 1144
    .local v1, "removeSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    invoke-virtual {v2}, Landroid/util/ArraySet;->clear()V

    .line 1145
    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_5d

    .line 1146
    invoke-virtual {v1}, Landroid/util/ArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_14
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_37

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 1147
    .local v2, "uid":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v4

    invoke-direct {p0, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    .line 1148
    .local v3, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v3, :cond_36

    .line 1149
    const-string/jumbo v4, "exit NIGHT_DIS_NET"

    invoke-virtual {p0, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager;->forceBackToRunning(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 1151
    .end local v2    # "uid":Ljava/lang/Integer;
    .end local v3    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_36
    goto :goto_14

    .line 1154
    :cond_37
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->proxySysAppAlarmImDeepSleep(Z)V

    .line 1155
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_5c

    .line 1156
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "exit NIGHT_DIS_NET, trans running state set: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 1158
    :cond_5c
    return-void

    .line 1145
    .end local v1    # "removeSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    :catchall_5d
    move-exception v1

    :try_start_5e
    monitor-exit v0
    :try_end_5f
    .catchall {:try_start_5e .. :try_end_5f} :catchall_5d

    throw v1
.end method

.method private synthetic lambda$new$5()V
    .registers 2

    .line 2499
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 2500
    return-void

    .line 2502
    :cond_b
    const-string/jumbo v0, "lcdoff_handler"

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->lcdOffFreezeAllApp(Ljava/lang/String;)V

    .line 2503
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->setRepeatFreezeForLcdOff()V

    .line 2504
    return-void
.end method

.method private synthetic lambda$removeAllInvalidHansWlUid$9()V
    .registers 4

    .line 4413
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .local v0, "i":I
    :goto_8
    if-ltz v0, :cond_17

    .line 4414
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->removedUidFromWhitelistByUsage(ZI)V

    .line 4413
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    .line 4416
    .end local v0    # "i":I
    :cond_17
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_27

    .line 4417
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "removeAllInvalidHansWlUid."

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4419
    :cond_27
    return-void
.end method

.method static synthetic lambda$setPersistentUidToKernelIfNeeded$0(Lcom/android/server/hans/OplusHansPackage;Z)V
    .registers 6
    .param p0, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p1, "add"    # Z

    .line 788
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getNativeService()Lcom/android/server/hans/freeze/HansNativeService;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    const/4 v2, 0x1

    if-eqz p1, :cond_11

    move v3, v2

    goto :goto_12

    :cond_11
    const/4 v3, 0x2

    :goto_12
    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/freeze/HansNativeService;->talkWithNative(III)I

    .line 789
    return-void
.end method

.method static synthetic lambda$unProxyPartner$10(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p0, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;

    .line 5187
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/OplusHansProxyManager;->unProxyAlarm(ILjava/lang/String;)V

    .line 5188
    return-void
.end method

.method static synthetic lambda$unfreezeProxyAlarmSetForRestrictionChanged$6(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p0, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;

    .line 3800
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/OplusHansProxyManager;->unProxyAlarm(ILjava/lang/String;)V

    .line 3801
    return-void
.end method

.method static synthetic lambda$unfreezeProxyDeepDozeChanged$7(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p0, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;

    .line 3816
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/OplusHansProxyManager;->unProxyAlarm(ILjava/lang/String;)V

    .line 3817
    return-void
.end method

.method private synthetic lambda$updateHansWLByAppUsage$8()V
    .registers 2

    .line 4407
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->filterWhitelistUidByAppUsage(I)V

    return-void
.end method

.method private lcdOffFreezeAllApp(Ljava/lang/String;)V
    .registers 8
    .param p1, "from"    # Ljava/lang/String;

    .line 2507
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 2508
    .local v0, "curRealTime":J
    iget v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckNum()I

    move-result v3

    if-ge v2, v3, :cond_20

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    sub-long v2, v0, v2

    .line 2509
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckTime()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-gez v2, :cond_30

    :cond_20
    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    sub-long v2, v0, v2

    .line 2510
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffCheckTime()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-ltz v2, :cond_3d

    .line 2511
    :cond_30
    const/4 v2, 0x2

    invoke-direct {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->notifyEventToSM(I)V

    .line 2512
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v2, p1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 2513
    iput-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    .line 2515
    :cond_3d
    return-void
.end method

.method private notifyDependencyApp(ILjava/lang/String;)V
    .registers 9
    .param p1, "uid"    # I
    .param p2, "packageName"    # Ljava/lang/String;

    .line 2193
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p2}, Lcom/android/server/hans/OplusHansDBConfig;->isDependencyCheck(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 2194
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/am/OplusHansManager;->getDependencyUids(I)Ljava/util/ArrayList;

    move-result-object v0

    .line 2195
    .local v0, "uidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 2196
    .local v2, "dependencyUid":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const-string/jumbo v4, "fg-dependency"

    const-string v5, ""

    invoke-virtual {p0, v3, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 2197
    .end local v2    # "dependencyUid":Ljava/lang/Integer;
    goto :goto_16

    .line 2199
    .end local v0    # "uidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    :cond_2f
    return-void
.end method

.method private notifyEventToSM(I)V
    .registers 7
    .param p1, "eventId"    # I

    .line 2591
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2592
    .local v0, "uidsToNotify":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2595
    :try_start_a
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    .line 2596
    .local v1, "curResumedUid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getCurLiveWallpaperUid()I

    move-result v2

    .line 2598
    .local v2, "curLiveWallpaperUid":I
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_29

    .line 2599
    invoke-direct {p0, v1, p1, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifySmEventLocked(IIILjava/util/List;)V

    .line 2601
    :cond_29
    if-eq v2, v1, :cond_3a

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3a

    .line 2602
    invoke-direct {p0, v2, p1, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifySmEventLocked(IIILjava/util/List;)V

    .line 2605
    :cond_3a
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .line 2606
    .local v3, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_40
    :goto_40
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_59

    .line 2607
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    .line 2608
    .local v4, "ruid":I
    if-eq v4, v1, :cond_40

    if-ne v4, v2, :cond_55

    .line 2609
    goto :goto_40

    .line 2611
    :cond_55
    invoke-direct {p0, v4, p1, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifySmEventLocked(IIILjava/util/List;)V

    .line 2612
    .end local v4    # "ruid":I
    goto :goto_40

    .line 2614
    :cond_59
    const/16 v4, 0x8

    if-ne p1, v4, :cond_61

    .line 2615
    const/4 v4, 0x1

    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->proxySysAppAlarmImDeepSleep(Z)V
    :try_end_61
    .catchall {:try_start_a .. :try_end_61} :catchall_97

    .line 2620
    .end local v1    # "curResumedUid":I
    .end local v2    # "curLiveWallpaperUid":I
    .end local v3    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_61
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2621
    nop

    .line 2622
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_96

    .line 2623
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "notify state machine event="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getSmEventStr(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " to uids="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 2625
    :cond_96
    return-void

    .line 2620
    :catchall_97
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2621
    throw v1
.end method

.method private notifySmEventLocked(IIILjava/util/List;)V
    .registers 10
    .param p1, "uid"    # I
    .param p2, "eventId"    # I
    .param p3, "curResumedUid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(III",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 2532
    .local p4, "uidsToNotify":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2533
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_c4

    .line 2534
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2535
    packed-switch p2, :pswitch_data_c6

    .line 2583
    :pswitch_14
    :try_start_14
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    goto/16 :goto_ba

    .line 2569
    :pswitch_1a
    const/4 v2, 0x0

    .line 2570
    .local v2, "needUnfreeze":Z
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v3

    const/4 v4, 0x4

    if-eq v3, v4, :cond_29

    .line 2571
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_2a

    .line 2572
    :cond_29
    const/4 v2, 0x1

    .line 2574
    :cond_2a
    if-nez v2, :cond_3b

    .line 2575
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, p1, v4}, Lcom/android/server/am/OplusHansManager;->isOnDeviceIdleWhitelist(ILjava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3b

    .line 2576
    const/4 v2, 0x1

    .line 2578
    :cond_3b
    if-eqz v2, :cond_c0

    .line 2579
    const-string/jumbo v3, "uidDisNetWhenSwitchCloseScene"

    invoke-virtual {p0, v0, v3}, Lcom/android/server/hans/scene/HansSceneManager;->forceBackToRunning(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    goto/16 :goto_c0

    .line 2566
    .end local v2    # "needUnfreeze":Z
    :pswitch_45
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    const-string/jumbo v3, "enter NIGHT_DIS_NET"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->forceTransitionRtoMnoImp(Ljava/lang/String;)V

    .line 2567
    goto/16 :goto_c0

    .line 2560
    :pswitch_51
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-nez v2, :cond_c0

    .line 2561
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyHighLoading(I)V

    .line 2562
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_c0

    .line 2547
    :pswitch_66
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyDeepsleepOff(I)V

    .line 2548
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2549
    goto :goto_c0

    .line 2557
    :pswitch_75
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    const-string v3, "HansDisabled"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V

    .line 2558
    goto :goto_c0

    .line 2551
    :pswitch_7f
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-nez v2, :cond_c0

    .line 2552
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyFastFreezerExit()V

    .line 2553
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_c0

    .line 2541
    :pswitch_94
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-nez v2, :cond_c0

    .line 2542
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyLcdOffAlarm(I)V

    .line 2543
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_c0

    .line 2537
    :pswitch_a9
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyLcdOn(I)V

    .line 2538
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2539
    goto :goto_c0

    .line 2586
    :catchall_b8
    move-exception v2

    goto :goto_c2

    .line 2583
    :goto_ba
    const-string/jumbo v3, "unknown even id to state machine"

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 2586
    :cond_c0
    :goto_c0
    monitor-exit v1

    goto :goto_c4

    :goto_c2
    monitor-exit v1
    :try_end_c3
    .catchall {:try_start_14 .. :try_end_c3} :catchall_b8

    throw v2

    .line 2588
    :cond_c4
    :goto_c4
    return-void

    nop

    :pswitch_data_c6
    .packed-switch 0x1
        :pswitch_a9
        :pswitch_94
        :pswitch_7f
        :pswitch_75
        :pswitch_14
        :pswitch_66
        :pswitch_51
        :pswitch_45
        :pswitch_1a
    .end packed-switch
.end method

.method private proxySysAppAlarmImDeepSleep(Z)V
    .registers 13
    .param p1, "proxy"    # Z

    .line 2629
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getProxySysAppActionMap()Landroid/util/ArrayMap;

    move-result-object v0

    .line 2631
    .local v0, "sysProxyActionsMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Ljava/util/HashSet<Ljava/lang/String;>;>;"
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 2632
    .local v1, "runningUserSet":Ljava/util/HashSet;, "Ljava/util/HashSet<Ljava/lang/Integer;>;"
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 2633
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getCurUserId()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 2635
    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_28
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_c8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    .line 2637
    .local v3, "userId":Ljava/lang/Integer;
    invoke-virtual {v0}, Landroid/util/ArrayMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_3c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_c6

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 2638
    .local v5, "pkgName":Ljava/lang/String;
    invoke-virtual {v0, v5}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/HashSet;

    .line 2639
    .local v6, "actionSet":Ljava/util/HashSet;, "Ljava/util/HashSet<Ljava/lang/String;>;"
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static {v5, v7}, Lcom/android/server/am/OplusHansManager;->getPackageUid(Ljava/lang/String;I)I

    move-result v7

    .line 2641
    .local v7, "uid":I
    const-string v8, "*"

    if-eqz p1, :cond_70

    .line 2642
    invoke-virtual {v6, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_68

    .line 2643
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v8

    invoke-virtual {v8, v7, v5}, Lcom/android/server/hans/OplusHansProxyManager;->proxyAlarmsByPkg(ILjava/lang/String;)V

    goto :goto_85

    .line 2645
    :cond_68
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v8

    invoke-virtual {v8, v7, v5, v6}, Lcom/android/server/hans/OplusHansProxyManager;->proxyAlarmsByPkgActions(ILjava/lang/String;Ljava/util/Set;)V

    goto :goto_85

    .line 2648
    :cond_70
    invoke-virtual {v6, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7e

    .line 2649
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v8

    invoke-virtual {v8, v7, v5}, Lcom/android/server/hans/OplusHansProxyManager;->unproxyAlarmsByPkg(ILjava/lang/String;)V

    goto :goto_85

    .line 2651
    :cond_7e
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v8

    invoke-virtual {v8, v7, v5, v6}, Lcom/android/server/hans/OplusHansProxyManager;->unproxyAlarmsByPkgActions(ILjava/lang/String;Ljava/util/Set;)V

    .line 2655
    :goto_85
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v8

    if-eqz v8, :cond_c4

    .line 2656
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "proxy: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ", sys app uid: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ", pkg: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " alarm in deepsleep, action: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 2658
    .end local v5    # "pkgName":Ljava/lang/String;
    .end local v6    # "actionSet":Ljava/util/HashSet;, "Ljava/util/HashSet<Ljava/lang/String;>;"
    .end local v7    # "uid":I
    :cond_c4
    goto/16 :goto_3c

    .line 2659
    .end local v3    # "userId":Ljava/lang/Integer;
    :cond_c6
    goto/16 :goto_28

    .line 2660
    :cond_c8
    return-void
.end method

.method private refreshNightDeepDozeTimeMs()V
    .registers 26

    .line 1506
    move-object/from16 v0, p0

    const-wide/16 v1, 0x0

    .line 1507
    .local v1, "startTimeMs":J
    const-wide/16 v3, 0x0

    .line 1508
    .local v3, "endTimeMs":J
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    .line 1512
    .local v5, "calendar":Ljava/util/Calendar;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansDBConfig;->isNightDeepDozeTimeRestrictEnable()Z

    move-result v6

    const-string/jumbo v7, "night deep doze mode "

    if-eqz v6, :cond_11d

    .line 1513
    const/16 v6, 0xb

    invoke-virtual {v5, v6}, Ljava/util/Calendar;->get(I)I

    move-result v8

    .line 1514
    .local v8, "hour":I
    const/16 v9, 0xc

    invoke-virtual {v5, v9}, Ljava/util/Calendar;->get(I)I

    move-result v10

    .line 1515
    .local v10, "minute":I
    mul-int/lit8 v11, v8, 0x3c

    add-int/2addr v11, v10

    .line 1517
    .local v11, "minutesOfNow":I
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v12

    invoke-virtual {v12}, Lcom/android/server/hans/OplusHansDBConfig;->getNightDeepDozeStartMinutes()I

    move-result v12

    .line 1518
    .local v12, "minutesOfStart":I
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v13

    invoke-virtual {v13}, Lcom/android/server/hans/OplusHansDBConfig;->getNightDeepDozeEndMinutes()I

    move-result v13

    .line 1519
    .local v13, "minutesOfEnd":I
    const/4 v14, 0x0

    .line 1521
    .local v14, "minutesOfOffset":I
    rem-int/lit16 v12, v12, 0x5a0

    .line 1522
    rem-int/lit16 v13, v13, 0x5a0

    .line 1523
    if-ge v12, v13, :cond_119

    .line 1524
    if-gez v13, :cond_44

    .line 1525
    add-int/lit16 v12, v12, 0x5a0

    .line 1526
    add-int/lit16 v13, v13, 0x5a0

    goto :goto_4a

    .line 1527
    :cond_44
    if-gez v12, :cond_4a

    .line 1528
    neg-int v14, v12

    .line 1529
    add-int/2addr v13, v14

    .line 1530
    add-int/2addr v11, v14

    .line 1531
    const/4 v12, 0x0

    .line 1533
    :cond_4a
    :goto_4a
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v15

    if-eqz v15, :cond_9b

    .line 1534
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v15

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "night deep doze mode date: "

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 1535
    move-wide/from16 v19, v1

    const/4 v9, 0x5

    .end local v1    # "startTimeMs":J
    .local v19, "startTimeMs":J
    invoke-virtual {v5, v9}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", minutesOfNow: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", minutesOfStart: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", minutesOfEnd: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", minutesOfOffset: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1534
    invoke-virtual {v15, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    goto :goto_9d

    .line 1533
    .end local v19    # "startTimeMs":J
    .restart local v1    # "startTimeMs":J
    :cond_9b
    move-wide/from16 v19, v1

    .line 1542
    .end local v1    # "startTimeMs":J
    .restart local v19    # "startTimeMs":J
    :goto_9d
    if-lt v11, v13, :cond_a4

    .line 1543
    const/4 v1, 0x1

    const/4 v9, 0x5

    invoke-virtual {v5, v9, v1}, Ljava/util/Calendar;->add(II)V

    .line 1545
    :cond_a4
    div-int/lit8 v1, v12, 0x3c

    const/16 v2, 0xb

    invoke-virtual {v5, v2, v1}, Ljava/util/Calendar;->set(II)V

    .line 1546
    rem-int/lit8 v1, v12, 0x3c

    const/16 v2, 0xc

    invoke-virtual {v5, v2, v1}, Ljava/util/Calendar;->set(II)V

    .line 1547
    invoke-virtual {v5}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v1

    const-wide/32 v21, 0xea60

    div-long v1, v1, v21

    move-wide/from16 v23, v1

    int-to-long v1, v14

    sub-long v1, v23, v1

    mul-long v1, v1, v21

    iput-wide v1, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigStartTimeMs:J

    .line 1548
    iget-wide v1, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigStartTimeMs:J

    .line 1549
    .end local v19    # "startTimeMs":J
    .restart local v1    # "startTimeMs":J
    div-int/lit8 v6, v13, 0x3c

    const/16 v9, 0xb

    invoke-virtual {v5, v9, v6}, Ljava/util/Calendar;->set(II)V

    .line 1550
    rem-int/lit8 v6, v13, 0x3c

    const/16 v9, 0xc

    invoke-virtual {v5, v9, v6}, Ljava/util/Calendar;->set(II)V

    .line 1551
    invoke-virtual {v5}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v15

    div-long v15, v15, v21

    move-wide/from16 v17, v1

    .end local v1    # "startTimeMs":J
    .local v17, "startTimeMs":J
    int-to-long v1, v14

    sub-long/2addr v15, v1

    mul-long v1, v15, v21

    iput-wide v1, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigEndTimeMs:J

    .line 1552
    iget-wide v3, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigEndTimeMs:J

    .line 1554
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_113

    .line 1555
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    move-wide v15, v3

    .end local v3    # "endTimeMs":J
    .local v15, "endTimeMs":J
    iget-wide v3, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigStartTimeMs:J

    move-object v9, v5

    .end local v5    # "calendar":Ljava/util/Calendar;
    .local v9, "calendar":Ljava/util/Calendar;
    iget-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeConfigEndTimeMs:J

    .line 1557
    invoke-direct {v0, v3, v4, v5, v6}, Lcom/android/server/hans/scene/HansSceneManager;->getTimeRangeString(JJ)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", config"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1555
    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto :goto_115

    .line 1554
    .end local v9    # "calendar":Ljava/util/Calendar;
    .end local v15    # "endTimeMs":J
    .restart local v3    # "endTimeMs":J
    .restart local v5    # "calendar":Ljava/util/Calendar;
    :cond_113
    move-wide v15, v3

    move-object v9, v5

    .line 1564
    .end local v3    # "endTimeMs":J
    .end local v5    # "calendar":Ljava/util/Calendar;
    .end local v8    # "hour":I
    .end local v10    # "minute":I
    .end local v11    # "minutesOfNow":I
    .end local v12    # "minutesOfStart":I
    .end local v13    # "minutesOfEnd":I
    .end local v14    # "minutesOfOffset":I
    .restart local v9    # "calendar":Ljava/util/Calendar;
    .restart local v15    # "endTimeMs":J
    :goto_115
    move-wide v3, v15

    move-wide/from16 v1, v17

    goto :goto_122

    .line 1523
    .end local v9    # "calendar":Ljava/util/Calendar;
    .end local v15    # "endTimeMs":J
    .end local v17    # "startTimeMs":J
    .restart local v1    # "startTimeMs":J
    .restart local v3    # "endTimeMs":J
    .restart local v5    # "calendar":Ljava/util/Calendar;
    .restart local v8    # "hour":I
    .restart local v10    # "minute":I
    .restart local v11    # "minutesOfNow":I
    .restart local v12    # "minutesOfStart":I
    .restart local v13    # "minutesOfEnd":I
    .restart local v14    # "minutesOfOffset":I
    :cond_119
    move-wide/from16 v19, v1

    move-object v9, v5

    .end local v1    # "startTimeMs":J
    .end local v5    # "calendar":Ljava/util/Calendar;
    .restart local v9    # "calendar":Ljava/util/Calendar;
    .restart local v19    # "startTimeMs":J
    goto :goto_120

    .line 1512
    .end local v8    # "hour":I
    .end local v9    # "calendar":Ljava/util/Calendar;
    .end local v10    # "minute":I
    .end local v11    # "minutesOfNow":I
    .end local v12    # "minutesOfStart":I
    .end local v13    # "minutesOfEnd":I
    .end local v14    # "minutesOfOffset":I
    .end local v19    # "startTimeMs":J
    .restart local v1    # "startTimeMs":J
    .restart local v5    # "calendar":Ljava/util/Calendar;
    :cond_11d
    move-wide/from16 v19, v1

    move-object v9, v5

    .line 1564
    .end local v1    # "startTimeMs":J
    .end local v5    # "calendar":Ljava/util/Calendar;
    .restart local v9    # "calendar":Ljava/util/Calendar;
    .restart local v19    # "startTimeMs":J
    :goto_120
    move-wide/from16 v1, v19

    .end local v19    # "startTimeMs":J
    .restart local v1    # "startTimeMs":J
    :goto_122
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v5

    if-eqz v5, :cond_14a

    .line 1565
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 1567
    invoke-direct {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getDeepSleepPredictTimeRangeString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v8, ", AI"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 1565
    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1572
    :cond_14a
    iget-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeMs:J

    invoke-static {v1, v2, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    iput-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    .line 1573
    const-wide/16 v5, 0x0

    cmp-long v5, v3, v5

    if-nez v5, :cond_15b

    iget-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeMs:J

    goto :goto_161

    :cond_15b
    iget-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeMs:J

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    :goto_161
    iput-wide v5, v0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    .line 1574
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v5

    if-eqz v5, :cond_18b

    .line 1575
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 1577
    invoke-direct {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getNightDeepDozeTimeRangeString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ", final"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 1575
    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1580
    :cond_18b
    return-void
.end method

.method private registerUidObserver()V
    .registers 6

    .line 336
    :try_start_0
    invoke-static {}, Landroid/app/ActivityManager;->getService()Landroid/app/IActivityManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidObserver:Landroid/app/IUidObserver;

    const/4 v2, -0x1

    const/4 v3, 0x0

    const/16 v4, 0x4e

    invoke-interface {v0, v1, v4, v2, v3}, Landroid/app/IActivityManager;->registerUidObserver(Landroid/app/IUidObserver;IILjava/lang/String;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_d} :catch_e

    .line 342
    goto :goto_2a

    .line 340
    :catch_e
    move-exception v0

    .line 341
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "registerUidObserver failed "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    .line 343
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2a
    return-void
.end method

.method private removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V
    .registers 6
    .param p1, "extScene"    # Lcom/android/server/hans/scene/HansScene;

    .line 1371
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 1373
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestrictionLevel()I

    move-result v0

    .line 1374
    .local v0, "restrictionLevel":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v1

    .line 1375
    .local v1, "oldTargetFlags":I
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->removeExtension(Lcom/android/server/hans/scene/HansScene;)Z

    .line 1376
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->removeExtension(Lcom/android/server/hans/scene/HansScene;)Z

    .line 1377
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v2

    .line 1378
    .local v2, "newTargetFlags":I
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v3}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestrictionLevel()I

    move-result v3

    if-eq v3, v0, :cond_2b

    const/4 v3, 0x1

    goto :goto_2c

    :cond_2b
    const/4 v3, 0x0

    .line 1379
    .local v3, "restrictionLevelChanged":Z
    :goto_2c
    invoke-direct {p0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->updateTargetMap(II)V
    :try_end_2f
    .catchall {:try_start_5 .. :try_end_2f} :catchall_3b

    .line 1381
    .end local v0    # "restrictionLevel":I
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1382
    nop

    .line 1383
    if-eqz v3, :cond_3a

    .line 1384
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeProxyAlarmSetForRestrictionChanged()V

    .line 1386
    :cond_3a
    return-void

    .line 1381
    .end local v1    # "oldTargetFlags":I
    .end local v2    # "newTargetFlags":I
    .end local v3    # "restrictionLevelChanged":Z
    :catchall_3b
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1382
    throw v0
.end method

.method private resetNetstate()V
    .registers 5

    .line 4204
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4205
    .local v0, "resetUidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 4207
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_b
    :try_start_b
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_24

    .line 4208
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    .line 4209
    .local v2, "uid":I
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_20
    .catchall {:try_start_b .. :try_end_20} :catchall_32

    .line 4207
    nop

    .end local v2    # "uid":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_b

    .line 4212
    .end local v1    # "i":I
    :cond_24
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 4213
    nop

    .line 4214
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/am/OplusHansManager;->resetFirewall(Ljava/util/ArrayList;)V

    .line 4215
    return-void

    .line 4212
    :catchall_32
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 4213
    throw v1
.end method

.method private sendOnceMessageIfStartAndEndChanged()V
    .registers 3

    .line 4234
    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeChanged:Z

    if-eqz v0, :cond_18

    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeChanged:Z

    if-eqz v0, :cond_18

    .line 4235
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeChanged:Z

    .line 4236
    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeChanged:Z

    .line 4237
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x19

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 4239
    :cond_18
    return-void
.end method

.method private setDualAppsExistForAlignment(ILjava/lang/String;Z)V
    .registers 8
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;
    .param p3, "exist"    # Z

    .line 4242
    invoke-static {p1}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v0

    const/16 v1, 0x3e7

    if-ne v0, v1, :cond_9e

    .line 4243
    const-string v0, ", pkgName="

    if-eqz p3, :cond_3e

    .line 4244
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidToPkgNameForDualApps:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4245
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "add uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " to DualApps map"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_7d

    .line 4247
    :cond_3e
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidToPkgNameForDualApps:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object p2, v1

    check-cast p2, Ljava/lang/String;

    .line 4248
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mUidToPkgNameForDualApps:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4249
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "remove uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " from DualApps map"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4251
    :goto_7d
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p2}, Lcom/android/server/hans/OplusHansDBConfig;->isInImPkgConfigList(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9e

    .line 4253
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

    if-nez v0, :cond_95

    .line 4254
    const-class v0, Lcom/android/server/OplusAlarmManagerServiceInternal;

    invoke-static {v0}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/OplusAlarmManagerServiceInternal;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

    .line 4256
    :cond_95
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

    if-eqz v0, :cond_9e

    .line 4257
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManagerServiceInternal:Lcom/android/server/OplusAlarmManagerServiceInternal;

    invoke-virtual {v0, p3}, Lcom/android/server/OplusAlarmManagerServiceInternal;->setDualAppsExist(Z)V

    .line 4261
    :cond_9e
    return-void
.end method

.method private setEnterNightDeepDozeAlarm()V
    .registers 11

    .line 1596
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    cmp-long v0, v0, v2

    if-lez v0, :cond_15

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmEnterTimeMs:J

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    cmp-long v0, v0, v2

    if-nez v0, :cond_13

    goto :goto_15

    :cond_13
    const/4 v0, 0x0

    goto :goto_16

    :cond_15
    :goto_15
    const/4 v0, 0x1

    .line 1598
    .local v0, "fail":Z
    :goto_16
    if-nez v0, :cond_22

    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isNightDeepDozeTimeRangeInvalid()Z

    move-result v1

    if-eqz v1, :cond_22

    .line 1599
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelEnterNightDeepDozeAlarm()V

    .line 1600
    const/4 v0, 0x1

    .line 1602
    :cond_22
    if-eqz v0, :cond_4a

    .line 1603
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_49

    .line 1604
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "night deep doze mode set enter alarm fail, "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 1606
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getNightDeepDozeTimeRangeString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1604
    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1608
    :cond_49
    return-void

    .line 1611
    :cond_4a
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v1, :cond_5a

    .line 1612
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v2, "alarm"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/AlarmManager;

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1614
    :cond_5a
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v1, :cond_99

    .line 1615
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelEnterNightDeepDozeAlarm()V

    .line 1616
    iget-wide v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    iput-wide v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmEnterTimeMs:J

    .line 1617
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    iget-wide v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeStartTimeMs:J

    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager;->mEnterNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    iget-object v9, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v4, 0x1

    const-string/jumbo v7, "hans enter night deep doze mode"

    invoke-virtual/range {v3 .. v9}, Landroid/app/AlarmManager;->setExact(IJLjava/lang/String;Landroid/app/AlarmManager$OnAlarmListener;Landroid/os/Handler;)V

    .line 1622
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_99

    .line 1623
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "night deep doze mode set enter alarm succeed, "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 1625
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getNightDeepDozeTimeRangeString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1623
    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1628
    :cond_99
    return-void
.end method

.method private setExitNightDeepDozeAlarm()V
    .registers 10

    .line 1660
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    cmp-long v0, v0, v2

    if-lez v0, :cond_63

    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    cmp-long v0, v0, v2

    if-nez v0, :cond_13

    goto :goto_63

    .line 1670
    :cond_13
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v0, :cond_23

    .line 1671
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1673
    :cond_23
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_62

    .line 1674
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelExitNightDeepDozeAlarm()V

    .line 1675
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    iput-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeAlarmExitTimeMs:J

    .line 1676
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeEndTimeMs:J

    iget-object v7, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitNightDeepDozeAlarmListener:Landroid/app/AlarmManager$OnAlarmListener;

    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v3, 0x1

    const-string/jumbo v6, "hans exit night deep doze mode"

    invoke-virtual/range {v2 .. v8}, Landroid/app/AlarmManager;->setExact(IJLjava/lang/String;Landroid/app/AlarmManager$OnAlarmListener;Landroid/os/Handler;)V

    .line 1681
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_62

    .line 1682
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "night deep doze mode set exit alarm succeed, "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1684
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getNightDeepDozeTimeRangeString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1682
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1687
    :cond_62
    return-void

    .line 1662
    :cond_63
    :goto_63
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_88

    .line 1663
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "night deep doze mode set exit alarm fail, "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1665
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getNightDeepDozeTimeRangeString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1663
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1667
    :cond_88
    return-void
.end method

.method private setFastFreezerOn(Z)V
    .registers 3
    .param p1, "on"    # Z

    .line 1805
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerOn:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 1806
    return-void
.end method

.method private setFirstFreezeForLcdOff(J)V
    .registers 7
    .param p1, "elapsedRealtime"    # J

    .line 2482
    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffTriggerTime:J

    .line 2483
    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastCheckMsgTime:J

    .line 2485
    const/4 v0, 0x1

    iput v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    .line 2486
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFreezerRunnable:Ljava/lang/Runnable;

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckTime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2487
    return-void
.end method

.method private setRepeatFreezeForLcdOff()V
    .registers 5

    .line 2490
    iget v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckNum()I

    move-result v1

    if-ge v0, v1, :cond_22

    .line 2491
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFreezerRunnable:Ljava/lang/Runnable;

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckTime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2492
    iget v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFastFreezeCheckNum:I

    goto :goto_31

    .line 2494
    :cond_22
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffFreezerRunnable:Ljava/lang/Runnable;

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffCheckTime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2496
    :goto_31
    return-void
.end method

.method private setThermalLevel(I)V
    .registers 4
    .param p1, "thermalLevel"    # I

    .line 4956
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    .line 4957
    .local v0, "oldLevel":I
    if-eq v0, p1, :cond_15

    .line 4958
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4959
    sub-int v1, p1, v0

    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateThermalPriorityLevel(I)V

    .line 4960
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSkippingNotification(I)V

    .line 4962
    :cond_15
    return-void
.end method

.method private setThermalMngLevel(I)V
    .registers 6
    .param p1, "newLevel"    # I

    .line 5148
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalGuardEnable()Z

    move-result v0

    if-nez v0, :cond_b

    .line 5149
    return-void

    .line 5151
    :cond_b
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    .line 5152
    .local v0, "oldLevel":I
    if-ne v0, p1, :cond_14

    .line 5153
    return-void

    .line 5155
    :cond_14
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 5156
    const/4 v1, 0x2

    if-ne p1, v1, :cond_25

    .line 5157
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, Lcom/android/server/am/OplusHansManager;->setStrictModeByThermal(I)V

    goto :goto_38

    .line 5158
    :cond_25
    const/4 v2, 0x1

    if-ne p1, v2, :cond_30

    .line 5159
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/am/OplusHansManager;->setStrictModeByThermal(I)V

    goto :goto_38

    .line 5161
    :cond_30
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lcom/android/server/am/OplusHansManager;->setStrictModeByThermal(I)V

    .line 5163
    :goto_38
    if-ne v0, v1, :cond_3d

    .line 5164
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unProxyPartner()V

    .line 5166
    :cond_3d
    return-void
.end method

.method private unProxyPartner()V
    .registers 8

    .line 5175
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 5176
    .local v0, "thermalProxyPartnerUid":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    monitor-enter v1

    .line 5177
    :try_start_8
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    invoke-virtual {v0, v2}, Landroid/util/ArraySet;->addAll(Landroid/util/ArraySet;)V

    .line 5178
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    invoke-virtual {v2}, Landroid/util/ArraySet;->clear()V

    .line 5179
    monitor-exit v1
    :try_end_13
    .catchall {:try_start_8 .. :try_end_13} :catchall_4e

    .line 5180
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_14
    invoke-virtual {v0}, Landroid/util/ArraySet;->size()I

    move-result v2

    if-ge v1, v2, :cond_4d

    .line 5181
    invoke-virtual {v0, v1}, Landroid/util/ArraySet;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 5182
    .local v2, "uid":I
    invoke-virtual {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    .line 5183
    .local v3, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v3, :cond_4a

    .line 5184
    const-string v4, "Proxy2AlignAlarm"

    const-string v5, ""

    invoke-virtual {p0, v3, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v4

    .line 5185
    .local v4, "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    sget-object v5, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    invoke-virtual {v4, v5}, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4a

    .line 5186
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/am/OplusHansManager;->getBgHandler()Landroid/os/Handler;

    move-result-object v5

    new-instance v6, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda4;

    invoke-direct {v6, v3}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda4;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    invoke-virtual {v5, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 5180
    .end local v2    # "uid":I
    .end local v3    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .end local v4    # "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    :cond_4a
    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    .line 5192
    .end local v1    # "i":I
    :cond_4d
    return-void

    .line 5179
    :catchall_4e
    move-exception v2

    :try_start_4f
    monitor-exit v1
    :try_end_50
    .catchall {:try_start_4f .. :try_end_50} :catchall_4e

    throw v2
.end method

.method private unfreezeProxyAlarmSetForRestrictionChanged()V
    .registers 7

    .line 3795
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansProxyManager;->getProxyToAlignAlarmHansList()Ljava/util/ArrayList;

    move-result-object v0

    .line 3796
    .local v0, "proxyToAlignAlarmHansList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_39

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 3797
    .local v2, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    const-string v3, "Proxy2AlignAlarm"

    const-string v4, "RestrictionChanged"

    invoke-virtual {p0, v2, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v3

    .line 3798
    .local v3, "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    sget-object v4, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    invoke-virtual {v3, v4}, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_38

    .line 3799
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/am/OplusHansManager;->getBgHandler()Landroid/os/Handler;

    move-result-object v4

    new-instance v5, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda11;

    invoke-direct {v5, v2}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda11;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 3803
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    :cond_38
    goto :goto_c

    .line 3804
    :cond_39
    return-void
.end method

.method private unfreezeProxyDeepDozeChanged()V
    .registers 7

    .line 3811
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansProxyManager;->getProxyDeepDozeHansList()Ljava/util/ArrayList;

    move-result-object v0

    .line 3812
    .local v0, "proxyDeepDozeHansList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_49

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 3813
    .local v2, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    const-string/jumbo v3, "exitFreezeDeepDoze"

    const-string/jumbo v4, "exitDeepDoze"

    invoke-virtual {p0, v2, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v3

    .line 3814
    .local v3, "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    sget-object v4, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    invoke-virtual {v3, v4}, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_48

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansDBConfig;->isBusinessCooperationApp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_48

    .line 3815
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/am/OplusHansManager;->getBgHandler()Landroid/os/Handler;

    move-result-object v4

    new-instance v5, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda1;

    invoke-direct {v5, v2}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda1;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 3819
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "result":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    :cond_48
    goto :goto_c

    .line 3820
    :cond_49
    invoke-static {}, Lcom/android/server/hans/OplusHansProxyManager;->getInstance()Lcom/android/server/hans/OplusHansProxyManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansProxyManager;->clearProxyDeepDozeUid()V

    .line 3821
    return-void
.end method

.method private unfreezeThermalImpPkg(I)V
    .registers 9
    .param p1, "nowLevel"    # I

    .line 5257
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 5258
    .local v0, "thermalSkipImpPkgs":Ljava/util/HashMap;, "Ljava/util/HashMap<Lcom/android/server/hans/OplusHansPackage;Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    monitor-enter v1

    .line 5259
    :try_start_8
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 5260
    monitor-exit v1
    :try_end_e
    .catchall {:try_start_8 .. :try_end_e} :catchall_5c

    .line 5261
    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 5262
    .local v2, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    .line 5263
    .local v3, "skipLevel":Ljava/lang/Integer;
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v4

    if-le v4, p1, :cond_5a

    .line 5264
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4

    .line 5265
    :try_start_33
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v5

    if-eqz v5, :cond_52

    .line 5266
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "exitThermal_"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, ""

    invoke-virtual {p0, v2, v5, v6}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 5268
    :cond_52
    monitor-exit v4
    :try_end_53
    .catchall {:try_start_33 .. :try_end_53} :catchall_57

    .line 5269
    invoke-virtual {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->removeThermalSkipImpPkg(Lcom/android/server/hans/OplusHansPackage;)V

    goto :goto_5a

    .line 5268
    :catchall_57
    move-exception v1

    :try_start_58
    monitor-exit v4
    :try_end_59
    .catchall {:try_start_58 .. :try_end_59} :catchall_57

    throw v1

    .line 5271
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "skipLevel":Ljava/lang/Integer;
    :cond_5a
    :goto_5a
    goto :goto_16

    .line 5272
    :cond_5b
    return-void

    .line 5260
    :catchall_5c
    move-exception v2

    :try_start_5d
    monitor-exit v1
    :try_end_5e
    .catchall {:try_start_5d .. :try_end_5e} :catchall_5c

    throw v2
.end method

.method private unfreezeWidgetForStrictMode()V
    .registers 7

    .line 4386
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getStrictModeWidgetList(Z)Landroid/util/SparseArray;

    move-result-object v0

    .line 4387
    .local v0, "list":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/String;>;"
    if-eqz v0, :cond_22

    .line 4388
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v1

    .line 4389
    .local v1, "length":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_10
    if-ge v2, v1, :cond_22

    .line 4390
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    const-string/jumbo v4, "exitStrictMode"

    const-string/jumbo v5, "widget"

    invoke-virtual {p0, v3, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 4389
    add-int/lit8 v2, v2, 0x1

    goto :goto_10

    .line 4393
    .end local v1    # "length":I
    .end local v2    # "i":I
    :cond_22
    return-void
.end method

.method private updateExtensionSceneByStrictMode(Lcom/android/server/hans/scene/HansScene;Z)V
    .registers 3
    .param p1, "extScene"    # Lcom/android/server/hans/scene/HansScene;
    .param p2, "enterScene"    # Z

    .line 1389
    if-eqz p2, :cond_6

    .line 1390
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    goto :goto_9

    .line 1392
    :cond_6
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1394
    :goto_9
    return-void
.end method

.method private updateGrayPackageLocked()V
    .registers 10

    .line 1302
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getGrayPkgListSize()I

    move-result v0

    if-nez v0, :cond_b

    .line 1303
    return-void

    .line 1305
    :cond_b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    const/4 v1, 0x6

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackageMap(I)Landroid/util/SparseArray;

    move-result-object v0

    .line 1308
    .local v0, "whiteMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_15
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_b7

    .line 1309
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 1310
    .local v3, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v3, :cond_b3

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansDBConfig;->isGrayPkg(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_33

    .line 1311
    goto/16 :goto_b3

    .line 1313
    :cond_33
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-direct {p0, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->isRestrictSysOrGrayApp(Ljava/lang/String;Z)Z

    move-result v4

    .line 1314
    .local v4, "isRestricted":Z
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v5

    if-eqz v5, :cond_79

    .line 1315
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "updateGrayPackgae uid: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " pkg: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 1316
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " isRestricted: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 1315
    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 1318
    :cond_79
    const/4 v5, 0x1

    if-eqz v4, :cond_97

    .line 1319
    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    monitor-enter v6

    .line 1320
    :try_start_7f
    iget-object v7, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1321
    monitor-exit v6
    :try_end_89
    .catchall {:try_start_7f .. :try_end_89} :catchall_94

    .line 1322
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-virtual {p0, v6, v1}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 1323
    invoke-virtual {p0, v3, v5}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V

    goto :goto_b3

    .line 1321
    :catchall_94
    move-exception v1

    :try_start_95
    monitor-exit v6
    :try_end_96
    .catchall {:try_start_95 .. :try_end_96} :catchall_94

    throw v1

    .line 1325
    :cond_97
    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    monitor-enter v6

    .line 1326
    :try_start_9a
    iget-object v7, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 1327
    monitor-exit v6
    :try_end_a4
    .catchall {:try_start_9a .. :try_end_a4} :catchall_b0

    .line 1328
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-virtual {p0, v6, v5}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 1329
    const/4 v5, 0x2

    invoke-virtual {p0, v3, v5}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V

    goto :goto_b3

    .line 1327
    :catchall_b0
    move-exception v1

    :try_start_b1
    monitor-exit v6
    :try_end_b2
    .catchall {:try_start_b1 .. :try_end_b2} :catchall_b0

    throw v1

    .line 1308
    .end local v4    # "isRestricted":Z
    :cond_b3
    :goto_b3
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_15

    .line 1332
    .end local v2    # "i":I
    .end local v3    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_b7
    return-void
.end method

.method private updateSkippingNotification(I)V
    .registers 4
    .param p1, "thermalLevel"    # I

    .line 5046
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInCameraVocalScene()Z

    move-result v0

    if-nez v0, :cond_7

    .line 5047
    return-void

    .line 5050
    :cond_7
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneId()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getSkipNotiThermalLevel(I)I

    move-result v0

    if-ge p1, v0, :cond_1f

    .line 5052
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    const-string/jumbo v1, "exit high temperature"

    invoke-virtual {v0, v1}, Lcom/android/server/am/OplusHansManager;->cancelNotificationRestrictions(Ljava/lang/String;)V

    .line 5054
    :cond_1f
    return-void
.end method

.method private updateSysBlackOrGrayIfSceneChanged(Z)V
    .registers 6
    .param p1, "enter"    # Z

    .line 1429
    const/16 v0, 0xd

    if-eqz p1, :cond_11

    .line 1430
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1431
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const-wide/16 v2, 0x2710

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_19

    .line 1433
    :cond_11
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1434
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayPackage()V

    .line 1436
    :goto_19
    return-void
.end method

.method private updateSysBlackPackageLocked()V
    .registers 11

    .line 1234
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackageMap(I)Landroid/util/SparseArray;

    move-result-object v0

    .line 1235
    .local v0, "sysBlackMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-gtz v1, :cond_11

    .line 1236
    return-void

    .line 1242
    :cond_11
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getSceneIdByScene()I

    move-result v1

    .line 1243
    .local v1, "sceneId":I
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v2

    .line 1244
    .local v2, "currentMinSystemScene":I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_1a
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v4

    if-ge v3, v4, :cond_6b

    .line 1245
    invoke-virtual {v0, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 1246
    .local v4, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v4, :cond_29

    .line 1247
    goto :goto_68

    .line 1249
    :cond_29
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    .line 1250
    .local v5, "pkgName":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    invoke-virtual {v6, v5, v1}, Lcom/android/server/hans/OplusHansDBConfig;->updateSysBlackAppEffectRestrictMask(Ljava/lang/String;I)V

    .line 1251
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    const/4 v7, 0x1

    invoke-virtual {p0, v6, v7}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v6

    if-eqz v6, :cond_41

    move v6, v7

    goto :goto_42

    :cond_41
    const/4 v6, 0x0

    .line 1252
    .local v6, "inManagedMap":Z
    :goto_42
    invoke-direct {p0, v5, v7}, Lcom/android/server/hans/scene/HansSceneManager;->isRestrictSysOrGrayApp(Ljava/lang/String;Z)Z

    move-result v8

    .line 1253
    .local v8, "isRestricted":Z
    if-nez v6, :cond_5d

    if-eqz v8, :cond_5d

    .line 1255
    and-int/lit16 v9, v1, 0x100

    if-eqz v9, :cond_59

    .line 1256
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v9

    invoke-virtual {v9, v2, v5}, Lcom/android/server/hans/OplusHansDBConfig;->inMinSystemSysAppWhiteList(ILjava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_59

    .line 1257
    goto :goto_68

    .line 1259
    :cond_59
    invoke-virtual {p0, v4, v7}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V

    goto :goto_68

    .line 1260
    :cond_5d
    if-eqz v6, :cond_68

    if-nez v8, :cond_68

    .line 1261
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v9

    invoke-virtual {p0, v9, v7}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 1244
    .end local v5    # "pkgName":Ljava/lang/String;
    .end local v6    # "inManagedMap":Z
    .end local v8    # "isRestricted":Z
    :cond_68
    :goto_68
    add-int/lit8 v3, v3, 0x1

    goto :goto_1a

    .line 1264
    .end local v3    # "i":I
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_6b
    return-void
.end method

.method private updateTargetMap(II)V
    .registers 13
    .param p1, "oldTargetFlags"    # I
    .param p2, "newTargetFlags"    # I

    .line 671
    not-int v0, p1

    and-int/2addr v0, p2

    .line 672
    .local v0, "addedTargetFlags":I
    not-int v1, p2

    and-int/2addr v1, p1

    .line 674
    .local v1, "removedTargetFlags":I
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "addedTargetFlags="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", removedTargetFlags="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 675
    const/16 v2, 0x8

    if-eqz v0, :cond_91

    .line 676
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 678
    const/4 v3, 0x1

    .local v3, "target":I
    :goto_32
    if-ge v3, v2, :cond_8b

    .line 679
    const/4 v4, 0x0

    .line 680
    .local v4, "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    and-int v5, v0, v3

    packed-switch v5, :pswitch_data_e2

    :pswitch_3a
    goto :goto_49

    .line 688
    :pswitch_3b
    :try_start_3b
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v4, v5

    .line 689
    goto :goto_49

    .line 685
    :pswitch_3f
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v4, v5

    .line 686
    goto :goto_49

    .line 682
    :pswitch_43
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v4, v5

    .line 683
    goto :goto_49

    .line 707
    .end local v3    # "target":I
    .end local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_47
    move-exception v2

    goto :goto_82

    .line 694
    .restart local v3    # "target":I
    .restart local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_49
    if-eqz v4, :cond_88

    .line 695
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_4c
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    move-result v6

    if-ge v5, v6, :cond_88

    .line 696
    invoke-virtual {v4, v5}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v6

    .line 697
    .local v6, "uid":I
    invoke-virtual {v4, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/hans/OplusHansPackage;

    .line 698
    .local v7, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v7, :cond_7f

    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v8, v9}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7f

    .line 699
    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v8

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v9

    if-eq v8, v9, :cond_7f

    .line 700
    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v8

    invoke-virtual {v8}, Lcom/android/server/hans/states/HansAppStateMachine;->enter()V
    :try_end_7f
    .catchall {:try_start_3b .. :try_end_7f} :catchall_47

    .line 695
    .end local v6    # "uid":I
    .end local v7    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_7f
    add-int/lit8 v5, v5, 0x1

    goto :goto_4c

    .line 707
    .end local v3    # "target":I
    .end local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v5    # "i":I
    :goto_82
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 708
    throw v2

    .line 678
    .restart local v3    # "target":I
    :cond_88
    shl-int/lit8 v3, v3, 0x1

    goto :goto_32

    .line 707
    .end local v3    # "target":I
    :cond_8b
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 708
    nop

    .line 711
    :cond_91
    if-eqz v1, :cond_e0

    .line 712
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 714
    const/4 v3, 0x1

    .restart local v3    # "target":I
    :goto_99
    if-ge v3, v2, :cond_da

    .line 715
    const/4 v4, 0x0

    .line 716
    .restart local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    and-int v5, v1, v3

    packed-switch v5, :pswitch_data_ee

    :pswitch_a1
    goto :goto_b0

    .line 724
    :pswitch_a2
    :try_start_a2
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v4, v5

    .line 725
    goto :goto_b0

    .line 721
    :pswitch_a6
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v4, v5

    .line 722
    goto :goto_b0

    .line 718
    :pswitch_aa
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v4, v5

    .line 719
    goto :goto_b0

    .line 741
    .end local v3    # "target":I
    .end local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_ae
    move-exception v2

    goto :goto_d1

    .line 730
    .restart local v3    # "target":I
    .restart local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_b0
    if-eqz v4, :cond_d7

    .line 731
    const/4 v5, 0x0

    .restart local v5    # "i":I
    :goto_b3
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    move-result v6

    if-ge v5, v6, :cond_d7

    .line 732
    invoke-virtual {v4, v5}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v6

    .line 733
    .restart local v6    # "uid":I
    invoke-virtual {v4, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/hans/OplusHansPackage;

    .line 734
    .restart local v7    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v7, :cond_ce

    .line 735
    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v8

    const-string v9, "RemovedFromTargetMap"

    invoke-virtual {v8, v9}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V
    :try_end_ce
    .catchall {:try_start_a2 .. :try_end_ce} :catchall_ae

    .line 731
    .end local v6    # "uid":I
    .end local v7    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_ce
    add-int/lit8 v5, v5, 0x1

    goto :goto_b3

    .line 741
    .end local v3    # "target":I
    .end local v4    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v5    # "i":I
    :goto_d1
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 742
    throw v2

    .line 714
    .restart local v3    # "target":I
    :cond_d7
    shl-int/lit8 v3, v3, 0x1

    goto :goto_99

    .line 741
    .end local v3    # "target":I
    :cond_da
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 742
    nop

    .line 744
    :cond_e0
    return-void

    nop

    :pswitch_data_e2
    .packed-switch 0x1
        :pswitch_43
        :pswitch_3f
        :pswitch_3a
        :pswitch_3b
    .end packed-switch

    :pswitch_data_ee
    .packed-switch 0x1
        :pswitch_aa
        :pswitch_a6
        :pswitch_a1
        :pswitch_a2
    .end packed-switch
.end method

.method private updateThermalLevel(I)Z
    .registers 4
    .param p1, "thermalLevel"    # I

    .line 4543
    const/4 v0, 0x0

    .line 4544
    .local v0, "update":Z
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->isThermalModeEnable()Z

    move-result v1

    if-eqz v1, :cond_32

    .line 4545
    iget-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    if-nez v1, :cond_1f

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalModeEnterLevel()I

    move-result v1

    if-lt p1, v1, :cond_1f

    .line 4546
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalMode(Z)V

    .line 4547
    const/4 v0, 0x1

    goto :goto_32

    .line 4548
    :cond_1f
    iget-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    if-eqz v1, :cond_32

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalModeExitLevel()I

    move-result v1

    if-gt p1, v1, :cond_32

    .line 4549
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalMode(Z)V

    .line 4550
    const/4 v0, 0x1

    .line 4553
    :cond_32
    :goto_32
    return v0
.end method

.method private updateThermalPriorityLevel(I)V
    .registers 11
    .param p1, "thermalDiff"    # I

    .line 5080
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    .line 5081
    .local v0, "thermalLevel":I
    if-nez p1, :cond_c

    const/4 v1, 0x7

    if-ge v0, v1, :cond_c

    .line 5082
    return-void

    .line 5084
    :cond_c
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->inThermalImpScene()Z

    move-result v1

    .line 5085
    .local v1, "impScene":Z
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    .line 5087
    .local v2, "oldPriLevel":I
    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ltz p1, :cond_7b

    .line 5088
    if-eqz v1, :cond_48

    .line 5089
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v4, v5}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_2b

    .line 5090
    const/4 v3, 0x3

    .local v3, "newPriLevel":I
    goto/16 :goto_b0

    .line 5091
    .end local v3    # "newPriLevel":I
    :cond_2b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v5, v5}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_38

    .line 5092
    const/4 v3, 0x2

    .restart local v3    # "newPriLevel":I
    goto/16 :goto_b0

    .line 5093
    .end local v3    # "newPriLevel":I
    :cond_38
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v6, v5}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_45

    .line 5094
    const/4 v3, 0x1

    .restart local v3    # "newPriLevel":I
    goto/16 :goto_b0

    .line 5096
    .end local v3    # "newPriLevel":I
    :cond_45
    const/4 v3, 0x0

    .restart local v3    # "newPriLevel":I
    goto/16 :goto_b0

    .line 5099
    .end local v3    # "newPriLevel":I
    :cond_48
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v7

    const/4 v8, 0x0

    invoke-virtual {v7, v3, v8}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_55

    .line 5100
    const/4 v3, 0x4

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5101
    .end local v3    # "newPriLevel":I
    :cond_55
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v4, v8}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_61

    .line 5102
    const/4 v3, 0x3

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5103
    .end local v3    # "newPriLevel":I
    :cond_61
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v5, v8}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_6d

    .line 5104
    const/4 v3, 0x2

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5105
    .end local v3    # "newPriLevel":I
    :cond_6d
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v6, v8}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-lt v0, v3, :cond_79

    .line 5106
    const/4 v3, 0x1

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5108
    .end local v3    # "newPriLevel":I
    :cond_79
    const/4 v3, 0x0

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5112
    .end local v3    # "newPriLevel":I
    :cond_7b
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v7

    invoke-virtual {v7, v6, v6}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v7

    if-gt v0, v7, :cond_87

    .line 5113
    const/4 v3, 0x0

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5114
    .end local v3    # "newPriLevel":I
    :cond_87
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v7

    invoke-virtual {v7, v5, v6}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v5

    if-gt v0, v5, :cond_93

    .line 5115
    const/4 v3, 0x1

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5116
    .end local v3    # "newPriLevel":I
    :cond_93
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v5, v4, v6}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v4

    if-gt v0, v4, :cond_9f

    .line 5117
    const/4 v3, 0x2

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5118
    .end local v3    # "newPriLevel":I
    :cond_9f
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4, v3, v6}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalPriorityConfig(II)I

    move-result v3

    if-gt v0, v3, :cond_ab

    .line 5119
    const/4 v3, 0x3

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5121
    .end local v3    # "newPriLevel":I
    :cond_ab
    if-eqz v1, :cond_af

    .line 5122
    const/4 v3, 0x3

    .restart local v3    # "newPriLevel":I
    goto :goto_b0

    .line 5124
    .end local v3    # "newPriLevel":I
    :cond_af
    const/4 v3, 0x4

    .line 5128
    .restart local v3    # "newPriLevel":I
    :goto_b0
    if-lez p1, :cond_b4

    if-gt v3, v2, :cond_bc

    :cond_b4
    if-gez p1, :cond_b8

    if-lt v3, v2, :cond_bc

    :cond_b8
    if-nez p1, :cond_11d

    if-eq v3, v2, :cond_11d

    .line 5131
    :cond_bc
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 5132
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "ThermalLevel:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, " ThermalImpScene:"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " ThermalPriLevel:"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 5134
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 5136
    if-ge v3, v2, :cond_11d

    .line 5137
    move v4, v3

    .line 5138
    .local v4, "priLevel":I
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeThermalImpPkg(I)V

    .line 5141
    .end local v4    # "priLevel":I
    :cond_11d
    return-void
.end method


# virtual methods
.method public addDSSkipBtUid(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 5275
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    monitor-enter v0

    .line 5276
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 5277
    monitor-exit v0

    .line 5278
    return-void

    .line 5277
    :catchall_e
    move-exception v1

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v1
.end method

.method public addForceTransToMiddleStateUid(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 1161
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 1162
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->add(Ljava/lang/Object;)Z

    .line 1163
    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_2f

    .line 1164
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 1165
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "enter NIGHT_DIS_NET, force trans middle state uid: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 1167
    :cond_2e
    return-void

    .line 1163
    :catchall_2f
    move-exception v1

    :try_start_30
    monitor-exit v0
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_2f

    throw v1
.end method

.method public addMutePlayerSet(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 4940
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 4941
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->add(Ljava/lang/Object;)Z

    .line 4942
    monitor-exit v0

    .line 4943
    return-void

    .line 4942
    :catchall_e
    move-exception v1

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v1
.end method

.method public addProxyPartner(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 5169
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    monitor-enter v0

    .line 5170
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->add(Ljava/lang/Object;)Z

    .line 5171
    monitor-exit v0

    .line 5172
    return-void

    .line 5171
    :catchall_e
    move-exception v1

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v1
.end method

.method public addThermalIgnoreTraffic(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 4575
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInThermalMode()Z

    move-result v0

    if-eqz v0, :cond_17

    .line 4576
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 4577
    :try_start_9
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->add(Ljava/lang/Object;)Z

    .line 4578
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_9 .. :try_end_16} :catchall_14

    throw v1

    .line 4580
    :cond_17
    :goto_17
    return-void
.end method

.method public addThermalSkipImpPkg(ILcom/android/server/hans/OplusHansPackage;)V
    .registers 7
    .param p1, "level"    # I
    .param p2, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 5221
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    monitor-enter v0

    .line 5222
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v1, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    .line 5223
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ge v1, p1, :cond_a6

    .line 5224
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, p2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5225
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_a6

    .line 5226
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "mThermalSkipImpPkgs update: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 5227
    invoke-virtual {p2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " in level: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 5226
    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto :goto_a6

    .line 5231
    :cond_60
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, p2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5232
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_a6

    .line 5233
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "mThermalSkipImpPkgs add: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 5234
    invoke-virtual {p2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " in level: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 5233
    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 5237
    :cond_a6
    :goto_a6
    monitor-exit v0

    .line 5238
    return-void

    .line 5237
    :catchall_a8
    move-exception v1

    monitor-exit v0
    :try_end_aa
    .catchall {:try_start_3 .. :try_end_aa} :catchall_a8

    throw v1
.end method

.method public addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V
    .registers 8
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "targetId"    # I

    .line 519
    if-nez p1, :cond_21

    .line 520
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " is null"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->w(Ljava/lang/String;)V

    .line 521
    return-void

    .line 523
    :cond_21
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-direct {p0, v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->setDualAppsExistForAlignment(ILjava/lang/String;Z)V

    .line 524
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "addToManagedMap(), uid="

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", targetId="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", mSceneCombo.getTargetFlags()="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 525
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 527
    const-string/jumbo v0, "third map already contains uid="

    packed-switch p2, :pswitch_data_1f8

    :pswitch_70
    goto/16 :goto_18c

    .line 557
    :pswitch_72
    :try_start_72
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_89

    .line 558
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_18c

    .line 560
    :cond_89
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "ex whitelist map already contains uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_a8
    .catchall {:try_start_72 .. :try_end_a8} :catchall_1f1

    .line 577
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 561
    return-void

    .line 537
    :pswitch_ae
    :try_start_ae
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/util/SparseArray;->contains(I)Z

    move-result v1

    if-eqz v1, :cond_112

    .line 538
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "invalid whitelist map already contains uid="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 539
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_f0

    .line 540
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto/16 :goto_18c

    .line 542
    :cond_f0
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_10c
    .catchall {:try_start_ae .. :try_end_10c} :catchall_1f1

    .line 577
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 543
    return-void

    .line 546
    :cond_112
    :try_start_112
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_12f

    .line 547
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 549
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, p1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->uploadThirdWhiteAppStateEvent(Lcom/android/server/hans/OplusHansPackage;I)V

    goto :goto_18c

    .line 551
    :cond_12f
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "whitelist map already contains uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_14e
    .catchall {:try_start_112 .. :try_end_14e} :catchall_1f1

    .line 577
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 552
    return-void

    .line 529
    :pswitch_154
    :try_start_154
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_16a

    .line 530
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_18c

    .line 532
    :cond_16a
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V
    :try_end_186
    .catchall {:try_start_154 .. :try_end_186} :catchall_1f1

    .line 577
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 533
    return-void

    .line 568
    :goto_18c
    :try_start_18c
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    and-int/2addr v0, p2

    if-eqz v0, :cond_1ea

    .line 569
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ea

    .line 570
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    if-eq v0, v1, :cond_1ea

    .line 571
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkgName="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", can enter SM"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 572
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->enter()V
    :try_end_1ea
    .catchall {:try_start_18c .. :try_end_1ea} :catchall_1f1

    .line 577
    :cond_1ea
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 578
    nop

    .line 579
    return-void

    .line 577
    :catchall_1f1
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 578
    throw v0

    :pswitch_data_1f8
    .packed-switch 0x1
        :pswitch_154
        :pswitch_ae
        :pswitch_70
        :pswitch_72
    .end packed-switch
.end method

.method public appSwitch(ILjava/lang/String;ILjava/lang/String;)V
    .registers 11
    .param p1, "curResumedUid"    # I
    .param p2, "curResumedPkg"    # Ljava/lang/String;
    .param p3, "lastResumedUid"    # I
    .param p4, "lastResumedPkg"    # Ljava/lang/String;

    .line 2203
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, 0x1

    move v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    .end local p1    # "curResumedUid":I
    .end local p2    # "curResumedPkg":Ljava/lang/String;
    .end local p3    # "lastResumedUid":I
    .end local p4    # "lastResumedPkg":Ljava/lang/String;
    .local v2, "curResumedUid":I
    .local v3, "curResumedPkg":Ljava/lang/String;
    .local v4, "lastResumedUid":I
    .local v5, "lastResumedPkg":Ljava/lang/String;
    invoke-static/range {v0 .. v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/String;ILjava/lang/String;)V

    .line 2204
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object p1

    invoke-virtual {p1, v3}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->notifyForgroundAppChanged(Ljava/lang/String;)V

    .line 2206
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/server/am/OplusHansManager;->isFirstVersionForOSense()Z

    move-result p1

    if-eqz p1, :cond_21

    .line 2207
    const/4 p1, -0x1

    const-string p2, "cold-start"

    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->enterFastFreeze(ILjava/lang/String;)V

    .line 2209
    :cond_21
    return-void
.end method

.method public asyncReportFling(Landroid/view/MotionEvent;I)V
    .registers 5
    .param p1, "ev"    # Landroid/view/MotionEvent;
    .param p2, "duration"    # I

    .line 2216
    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->judugeFlingAction(Landroid/view/MotionEvent;I)I

    move-result v0

    .line 2217
    .local v0, "msgId":I
    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    .line 2218
    return-void

    .line 2221
    :cond_8
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->setFlingMsgId(I)V

    .line 2222
    return-void
.end method

.method public cancelKillFrozenAppAlarm(Landroid/app/AlarmManager$OnAlarmListener;)V
    .registers 4
    .param p1, "listener"    # Landroid/app/AlarmManager$OnAlarmListener;

    .line 1734
    if-nez p1, :cond_3

    .line 1735
    return-void

    .line 1737
    :cond_3
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v0, :cond_13

    .line 1738
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1740
    :cond_13
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_1c

    .line 1741
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    invoke-virtual {v0, p1}, Landroid/app/AlarmManager;->cancel(Landroid/app/AlarmManager$OnAlarmListener;)V

    .line 1743
    :cond_1c
    return-void
.end method

.method public cancelSetFirewall(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 4181
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeEqualMessages(ILjava/lang/Object;)V

    .line 4182
    return-void
.end method

.method public checkExecutingComponentDelay(I)V
    .registers 6
    .param p1, "uid"    # I

    .line 4137
    const/16 v0, 0x2710

    if-ge p1, v0, :cond_5

    .line 4138
    return-void

    .line 4140
    :cond_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x28

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 4141
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 4142
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const-wide/16 v2, 0x64

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 4143
    return-void
.end method

.method public checkMsgTimeout(Ljava/lang/String;I)V
    .registers 11
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 2438
    const-string v0, "android"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 2439
    return-void

    .line 2441
    :cond_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 2452
    .local v0, "elapsedRealtime":J
    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    sub-long v2, v0, v2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckBufferTime:J

    cmp-long v2, v2, v4

    if-lez v2, :cond_53

    .line 2453
    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    sub-long v2, v0, v2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLightDozeTime:J

    cmp-long v2, v2, v4

    if-gez v2, :cond_2b

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastCheckMsgTime:J

    sub-long v2, v0, v2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckMinTime:J

    cmp-long v2, v2, v4

    if-gtz v2, :cond_45

    :cond_2b
    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    sub-long v2, v0, v2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLightDozeTime:J

    cmp-long v2, v2, v4

    if-ltz v2, :cond_53

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastCheckMsgTime:J

    sub-long v2, v0, v2

    .line 2454
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getImportantRepeatTime()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-lez v2, :cond_53

    .line 2455
    :cond_45
    iput-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastCheckMsgTime:J

    .line 2456
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v3, 0x16

    const/4 v4, -0x1

    invoke-virtual {v2, v3, v4, v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Message;->sendToTarget()V

    .line 2461
    :cond_53
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->isIdleEnable()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_82

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    sub-long v4, v0, v4

    .line 2462
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffIdleTime()J

    move-result-wide v6

    cmp-long v2, v4, v6

    if-lez v2, :cond_82

    .line 2464
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v4, 0x14

    invoke-virtual {v2, v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 2465
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Message;->sendToTarget()V

    .line 2468
    :cond_82
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->isIdleEnable()Z

    move-result v2

    if-eqz v2, :cond_b0

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOffTime:J

    sub-long v4, v0, v4

    .line 2469
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffDeepIdleTime()J

    move-result-wide v6

    cmp-long v2, v4, v6

    if-lez v2, :cond_b0

    .line 2471
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v4, 0x15

    invoke-virtual {v2, v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 2472
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v4, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Message;->sendToTarget()V

    .line 2474
    :cond_b0
    return-void
.end method

.method public checkTransBinder(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 8
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 4146
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 4148
    :try_start_5
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isHighExtremeMode()Z

    move-result v1

    const/4 v2, 0x2

    if-nez v1, :cond_3f

    .line 4149
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansDBConfig;->isBinderCheckAllPkg(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1f

    goto :goto_3f

    .line 4152
    :cond_1f
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getTransBinderThawTimes()I

    move-result v1

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansDBConfig;->getBinderCheckThreshold()I

    move-result v3

    if-lt v1, v3, :cond_3d

    .line 4153
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansDBConfig;->isBinderCheckEnable(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3d

    .line 4154
    move v1, v2

    goto :goto_3e

    :cond_3d
    const/4 v1, 0x0

    .local v1, "type":I
    :goto_3e
    goto :goto_40

    .line 4150
    .end local v1    # "type":I
    :cond_3f
    :goto_3f
    const/4 v1, 0x2

    .line 4158
    .restart local v1    # "type":I
    :goto_40
    if-ne v1, v2, :cond_45

    .line 4159
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->resetTransBinderThawTimes()V

    .line 4161
    :cond_45
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v2

    .line 4162
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {v2, v5, v3, v1, v4}, Landroid/os/Handler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    .line 4164
    .local v2, "checkBinderMsg":Landroid/os/Message;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    .line 4165
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v4, v5}, Lcom/android/server/am/OplusHansManager;->isDependencyByForeground(I)Z

    move-result v4

    .line 4164
    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansDBConfig;->getBindeCheckDelay(Z)J

    move-result-wide v3

    .line 4166
    .local v3, "delay":J
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v5

    invoke-virtual {v5, v2, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 4167
    nop

    .end local v1    # "type":I
    .end local v2    # "checkBinderMsg":Landroid/os/Message;
    .end local v3    # "delay":J
    monitor-exit v0

    .line 4168
    return-void

    .line 4167
    :catchall_80
    move-exception v1

    monitor-exit v0
    :try_end_82
    .catchall {:try_start_5 .. :try_end_82} :catchall_80

    throw v1
.end method

.method public dumpFreUnfreezeInfo()Ljava/lang/String;
    .registers 6

    .line 4004
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x3e8

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 4005
    .local v0, "sb":Ljava/lang/StringBuilder;
    const-string v1, "dumpsys activity hans freunfreeze"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4006
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\n\nHansPackage White Apps size= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4007
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_2f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_64

    .line 4008
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 4009
    .local v2, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\t"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4010
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4011
    :try_start_51
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->freunfreezeQueueTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4012
    monitor-exit v3
    :try_end_59
    .catchall {:try_start_51 .. :try_end_59} :catchall_61

    .line 4013
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4007
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v1, v1, 0x1

    goto :goto_2f

    .line 4012
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_61
    move-exception v4

    :try_start_62
    monitor-exit v3
    :try_end_63
    .catchall {:try_start_62 .. :try_end_63} :catchall_61

    throw v4

    .line 4015
    .end local v1    # "i":I
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_64
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\n\nHansPackage Temp White Apps size= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4016
    const/4 v1, 0x0

    .restart local v1    # "i":I
    :goto_87
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_bc

    .line 4017
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 4018
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\t"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4019
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4020
    :try_start_a9
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->freunfreezeQueueTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4021
    monitor-exit v3
    :try_end_b1
    .catchall {:try_start_a9 .. :try_end_b1} :catchall_b9

    .line 4022
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4016
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v1, v1, 0x1

    goto :goto_87

    .line 4021
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_b9
    move-exception v4

    :try_start_ba
    monitor-exit v3
    :try_end_bb
    .catchall {:try_start_ba .. :try_end_bb} :catchall_b9

    throw v4

    .line 4025
    .end local v1    # "i":I
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_bc
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\n\nHansPackage Third Apps size= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4026
    const/4 v1, 0x0

    .restart local v1    # "i":I
    :goto_df
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_114

    .line 4027
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 4028
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\t"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4029
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4030
    :try_start_101
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->freunfreezeQueueTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4031
    monitor-exit v3
    :try_end_109
    .catchall {:try_start_101 .. :try_end_109} :catchall_111

    .line 4032
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4026
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v1, v1, 0x1

    goto :goto_df

    .line 4031
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_111
    move-exception v4

    :try_start_112
    monitor-exit v3
    :try_end_113
    .catchall {:try_start_112 .. :try_end_113} :catchall_111

    throw v4

    .line 4034
    .end local v1    # "i":I
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_114
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\n\nmInvalidHansWhitelist= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4035
    const/4 v1, 0x0

    .restart local v1    # "i":I
    :goto_137
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_16c

    .line 4036
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansPackage;

    .line 4037
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\t"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4038
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4039
    :try_start_159
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->freunfreezeQueueTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4040
    monitor-exit v3
    :try_end_161
    .catchall {:try_start_159 .. :try_end_161} :catchall_169

    .line 4041
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4035
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v1, v1, 0x1

    goto :goto_137

    .line 4040
    .restart local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_169
    move-exception v4

    :try_start_16a
    monitor-exit v3
    :try_end_16b
    .catchall {:try_start_16a .. :try_end_16b} :catchall_169

    throw v4

    .line 4043
    .end local v1    # "i":I
    .end local v2    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_16c
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public dumpHansSceneInfo(Z)Ljava/lang/String;
    .registers 10
    .param p1, "importanceList"    # Z

    .line 3824
    new-instance v0, Ljava/lang/StringBuffer;

    const/16 v1, 0x32

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(I)V

    .line 3827
    .local v0, "sb":Ljava/lang/StringBuffer;
    :try_start_7
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "dumpsys hans appInfo, curtime: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-static {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->formatDateTime(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3828
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Hans Scene = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getSceneStr()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3829
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getExtremeFgMode()Z

    move-result v1

    if-eqz v1, :cond_6f

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " OldStrictModeLevel:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevelByScene(I)I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_71

    :cond_6f
    const-string v1, ""

    :goto_71
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3830
    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3831
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Target Flags = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " (THIRD=1, WHITELIST=2, EX_WHITELIST=4, TMP_WHITELIST=8, SYS_BLACK=16)\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3832
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Restriction Level = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestrictionLevel()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3833
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Importance Flags = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getImportanceFlags()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3834
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Restriction flags = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestrictionFlags()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3835
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Importance = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v3}, Lcom/android/server/hans/scene/HansSceneCombo;->getImportanceFlags()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansImportance;->getImportantStr(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3836
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  SkipImportanceFlag = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansImportance;->getSkipImportanceFlag()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 3837
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v2

    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansImportance;->getSkipImportanceFlag()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansImportance;->getImportantStr(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 3836
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3838
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansImportance;->getSkipImportantPkgList()Ljava/util/ArrayList;

    move-result-object v1

    .line 3839
    .local v1, "skipImportantPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1c6

    .line 3840
    const-string v2, "  SkipImportantPkgList: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3841
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_189
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1c1

    .line 3842
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 3843
    .local v3, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ", "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3841
    nop

    .end local v3    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v2, v2, 0x1

    goto :goto_189

    .line 3845
    .end local v2    # "i":I
    :cond_1c1
    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3848
    :cond_1c6
    const-string v2, "TcpRetransmissionFrozenSet = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3849
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    monitor-enter v2
    :try_end_1ce
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_1ce} :catch_56a

    .line 3850
    :try_start_1ce
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    .line 3851
    monitor-exit v2
    :try_end_1d4
    .catchall {:try_start_1ce .. :try_end_1d4} :catchall_567

    .line 3852
    :try_start_1d4
    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3853
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v2
    :try_end_1dc
    .catch Ljava/lang/Exception; {:try_start_1d4 .. :try_end_1dc} :catch_56a

    .line 3854
    :try_start_1dc
    const-string v3, " mThermalIgnoreTrafficSet= "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3855
    monitor-exit v2
    :try_end_1ee
    .catchall {:try_start_1dc .. :try_end_1ee} :catchall_564

    .line 3857
    :try_start_1ee
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\n\nHans Manage White Apps size= "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3858
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_211
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_23a

    .line 3859
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 3860
    .local v3, "ps":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4
    :try_end_226
    .catch Ljava/lang/Exception; {:try_start_1ee .. :try_end_226} :catch_56a

    .line 3861
    :try_start_226
    invoke-direct {p0, v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->dumpSingleAppInfoLocked(Lcom/android/server/hans/OplusHansPackage;Z)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3862
    monitor-exit v4
    :try_end_22e
    .catchall {:try_start_226 .. :try_end_22e} :catchall_237

    .line 3863
    :try_start_22e
    const-string v4, "\n"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_233
    .catch Ljava/lang/Exception; {:try_start_22e .. :try_end_233} :catch_56a

    .line 3858
    nop

    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v2, v2, 0x1

    goto :goto_211

    .line 3862
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    :catchall_237
    move-exception v5

    :try_start_238
    monitor-exit v4
    :try_end_239
    .catchall {:try_start_238 .. :try_end_239} :catchall_237

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_239
    throw v5

    .line 3867
    .end local v2    # "i":I
    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :cond_23a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\n\nHans Temp Manage White Apps size= "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3868
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_25d
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_286

    .line 3869
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 3870
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4
    :try_end_272
    .catch Ljava/lang/Exception; {:try_start_239 .. :try_end_272} :catch_56a

    .line 3871
    :try_start_272
    invoke-direct {p0, v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->dumpSingleAppInfoLocked(Lcom/android/server/hans/OplusHansPackage;Z)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3872
    monitor-exit v4
    :try_end_27a
    .catchall {:try_start_272 .. :try_end_27a} :catchall_283

    .line 3873
    :try_start_27a
    const-string v4, "\n"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_27f
    .catch Ljava/lang/Exception; {:try_start_27a .. :try_end_27f} :catch_56a

    .line 3868
    nop

    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v2, v2, 0x1

    goto :goto_25d

    .line 3872
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    :catchall_283
    move-exception v5

    :try_start_284
    monitor-exit v4
    :try_end_285
    .catchall {:try_start_284 .. :try_end_285} :catchall_283

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_285
    throw v5

    .line 3876
    .end local v2    # "i":I
    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :cond_286
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\n\nmInvalidHansWhitelist= "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3877
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_2a9
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_2d2

    .line 3878
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 3879
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4
    :try_end_2be
    .catch Ljava/lang/Exception; {:try_start_285 .. :try_end_2be} :catch_56a

    .line 3880
    :try_start_2be
    invoke-direct {p0, v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->dumpSingleAppInfoLocked(Lcom/android/server/hans/OplusHansPackage;Z)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3881
    monitor-exit v4
    :try_end_2c6
    .catchall {:try_start_2be .. :try_end_2c6} :catchall_2cf

    .line 3882
    :try_start_2c6
    const-string v4, "\n"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_2cb
    .catch Ljava/lang/Exception; {:try_start_2c6 .. :try_end_2cb} :catch_56a

    .line 3877
    nop

    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v2, v2, 0x1

    goto :goto_2a9

    .line 3881
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    :catchall_2cf
    move-exception v5

    :try_start_2d0
    monitor-exit v4
    :try_end_2d1
    .catchall {:try_start_2d0 .. :try_end_2d1} :catchall_2cf

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_2d1
    throw v5

    .line 3885
    .end local v2    # "i":I
    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :cond_2d2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\n\nHans Manage Third Apps size= "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3886
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_2f5
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_31e

    .line 3887
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/OplusHansPackage;

    .line 3888
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4
    :try_end_30a
    .catch Ljava/lang/Exception; {:try_start_2d1 .. :try_end_30a} :catch_56a

    .line 3889
    :try_start_30a
    invoke-direct {p0, v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->dumpSingleAppInfoLocked(Lcom/android/server/hans/OplusHansPackage;Z)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3890
    monitor-exit v4
    :try_end_312
    .catchall {:try_start_30a .. :try_end_312} :catchall_31b

    .line 3891
    :try_start_312
    const-string v4, "\n"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_317
    .catch Ljava/lang/Exception; {:try_start_312 .. :try_end_317} :catch_56a

    .line 3886
    nop

    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    add-int/lit8 v2, v2, 0x1

    goto :goto_2f5

    .line 3890
    .restart local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    :catchall_31b
    move-exception v5

    :try_start_31c
    monitor-exit v4
    :try_end_31d
    .catchall {:try_start_31c .. :try_end_31d} :catchall_31b

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_31d
    throw v5

    .line 3894
    .end local v2    # "i":I
    .end local v3    # "ps":Lcom/android/server/hans/OplusHansPackage;
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :cond_31e
    const-string v2, "\nNight_Dis_Net:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3895
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    monitor-enter v2
    :try_end_326
    .catch Ljava/lang/Exception; {:try_start_31d .. :try_end_326} :catch_56a

    .line 3896
    :try_start_326
    const-string/jumbo v3, "mForceTransToMiddleStateUidSet: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mForceTransToMiddleStateUidSet:Landroid/util/ArraySet;

    invoke-virtual {v4}, Landroid/util/ArraySet;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3897
    monitor-exit v2
    :try_end_33d
    .catchall {:try_start_326 .. :try_end_33d} :catchall_561

    .line 3899
    :try_start_33d
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V
    :try_end_342
    .catch Ljava/lang/Exception; {:try_start_33d .. :try_end_342} :catch_56a

    .line 3901
    :try_start_342
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\n\nRunning uid list:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_360
    .catchall {:try_start_342 .. :try_end_360} :catchall_559

    .line 3903
    :try_start_360
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3904
    nop

    .line 3906
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    monitor-enter v2
    :try_end_369
    .catch Ljava/lang/Exception; {:try_start_360 .. :try_end_369} :catch_56a

    .line 3907
    :try_start_369
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\n\nRunning UidAdjMap: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3908
    monitor-exit v2
    :try_end_388
    .catchall {:try_start_369 .. :try_end_388} :catchall_556

    .line 3910
    :try_start_388
    const-string v2, "MediaMute state: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isMediaMute()Z

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3911
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    monitor-enter v2
    :try_end_3a2
    .catch Ljava/lang/Exception; {:try_start_388 .. :try_end_3a2} :catch_56a

    .line 3912
    :try_start_3a2
    const-string v3, "  mMediaMutePlayerSet: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mMediaMutePlayerSet:Landroid/util/ArraySet;

    invoke-virtual {v4}, Landroid/util/ArraySet;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3913
    monitor-exit v2
    :try_end_3b8
    .catchall {:try_start_3a2 .. :try_end_3b8} :catchall_553

    .line 3915
    :try_start_3b8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "MinSystemScene:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3916
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "CameraMinSystemSubScene:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneId()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3917
    const-string v2, "  mExitCameraMinSystemTime: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    iget-wide v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mExitCameraMinSystemTime:J

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuffer;->append(J)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3918
    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3920
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ThermalLevel:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3921
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ThermalMngLevel:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3922
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ThermalPriorityLevel:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3923
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "ThermalImpScene:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getThermalImpScene()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->inThermalImpScene()Z

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3924
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 3925
    .local v2, "thermalSkipImpPkgs":Ljava/util/HashMap;, "Ljava/util/HashMap<Lcom/android/server/hans/OplusHansPackage;Ljava/lang/Integer;>;"
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    monitor-enter v3
    :try_end_4aa
    .catch Ljava/lang/Exception; {:try_start_3b8 .. :try_end_4aa} :catch_56a

    .line 3926
    :try_start_4aa
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v2, v4}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 3927
    monitor-exit v3
    :try_end_4b0
    .catchall {:try_start_4aa .. :try_end_4b0} :catchall_550

    .line 3928
    :try_start_4b0
    const-string v3, "Thermal skip list:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3929
    invoke-virtual {v2}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_4c3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_520

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 3930
    .local v4, "pkg":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {v2, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    .line 3931
    .local v5, "tempLevel":Ljava/lang/Integer;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\tLevel "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ": "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3932
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ","

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3933
    const-string v6, "\n"

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3934
    nop

    .end local v4    # "pkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v5    # "tempLevel":Ljava/lang/Integer;
    goto :goto_4c3

    .line 3935
    :cond_520
    const-string v3, "Thermal mng proxy partner list:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3936
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    monitor-enter v3
    :try_end_528
    .catch Ljava/lang/Exception; {:try_start_4b0 .. :try_end_528} :catch_56a

    .line 3937
    :try_start_528
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalProxyPartnerUid:Landroid/util/ArraySet;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    .line 3938
    monitor-exit v3
    :try_end_52e
    .catchall {:try_start_528 .. :try_end_52e} :catchall_54d

    .line 3940
    :try_start_52e
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string/jumbo v4, "mDSSkipBtSet: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 3941
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    monitor-enter v3
    :try_end_53d
    .catch Ljava/lang/Exception; {:try_start_52e .. :try_end_53d} :catch_56a

    .line 3942
    :try_start_53d
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    .line 3943
    monitor-exit v3
    :try_end_543
    .catchall {:try_start_53d .. :try_end_543} :catchall_54a

    .line 3945
    :try_start_543
    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_548
    .catch Ljava/lang/Exception; {:try_start_543 .. :try_end_548} :catch_56a

    .line 3948
    nop

    .end local v1    # "skipImportantPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v2    # "thermalSkipImpPkgs":Ljava/util/HashMap;, "Ljava/util/HashMap<Lcom/android/server/hans/OplusHansPackage;Ljava/lang/Integer;>;"
    goto :goto_585

    .line 3943
    .restart local v1    # "skipImportantPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v2    # "thermalSkipImpPkgs":Ljava/util/HashMap;, "Ljava/util/HashMap<Lcom/android/server/hans/OplusHansPackage;Ljava/lang/Integer;>;"
    :catchall_54a
    move-exception v4

    :try_start_54b
    monitor-exit v3
    :try_end_54c
    .catchall {:try_start_54b .. :try_end_54c} :catchall_54a

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_54c
    throw v4
    :try_end_54d
    .catch Ljava/lang/Exception; {:try_start_54c .. :try_end_54d} :catch_56a

    .line 3938
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_54d
    move-exception v4

    :try_start_54e
    monitor-exit v3
    :try_end_54f
    .catchall {:try_start_54e .. :try_end_54f} :catchall_54d

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_54f
    throw v4
    :try_end_550
    .catch Ljava/lang/Exception; {:try_start_54f .. :try_end_550} :catch_56a

    .line 3927
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_550
    move-exception v4

    :try_start_551
    monitor-exit v3
    :try_end_552
    .catchall {:try_start_551 .. :try_end_552} :catchall_550

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_552
    throw v4
    :try_end_553
    .catch Ljava/lang/Exception; {:try_start_552 .. :try_end_553} :catch_56a

    .line 3913
    .end local v2    # "thermalSkipImpPkgs":Ljava/util/HashMap;, "Ljava/util/HashMap<Lcom/android/server/hans/OplusHansPackage;Ljava/lang/Integer;>;"
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_553
    move-exception v3

    :try_start_554
    monitor-exit v2
    :try_end_555
    .catchall {:try_start_554 .. :try_end_555} :catchall_553

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_555
    throw v3
    :try_end_556
    .catch Ljava/lang/Exception; {:try_start_555 .. :try_end_556} :catch_56a

    .line 3908
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_556
    move-exception v3

    :try_start_557
    monitor-exit v2
    :try_end_558
    .catchall {:try_start_557 .. :try_end_558} :catchall_556

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_558
    throw v3

    .line 3903
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_559
    move-exception v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3904
    nop

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    throw v2
    :try_end_561
    .catch Ljava/lang/Exception; {:try_start_558 .. :try_end_561} :catch_56a

    .line 3897
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_561
    move-exception v3

    :try_start_562
    monitor-exit v2
    :try_end_563
    .catchall {:try_start_562 .. :try_end_563} :catchall_561

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_563
    throw v3
    :try_end_564
    .catch Ljava/lang/Exception; {:try_start_563 .. :try_end_564} :catch_56a

    .line 3855
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_564
    move-exception v3

    :try_start_565
    monitor-exit v2
    :try_end_566
    .catchall {:try_start_565 .. :try_end_566} :catchall_564

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_566
    throw v3
    :try_end_567
    .catch Ljava/lang/Exception; {:try_start_566 .. :try_end_567} :catch_56a

    .line 3851
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catchall_567
    move-exception v3

    :try_start_568
    monitor-exit v2
    :try_end_569
    .catchall {:try_start_568 .. :try_end_569} :catchall_567

    .end local v0    # "sb":Ljava/lang/StringBuffer;
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "importanceList":Z
    :try_start_569
    throw v3
    :try_end_56a
    .catch Ljava/lang/Exception; {:try_start_569 .. :try_end_56a} :catch_56a

    .line 3946
    .end local v1    # "skipImportantPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansPackage;>;"
    .restart local v0    # "sb":Ljava/lang/StringBuffer;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "importanceList":Z
    :catch_56a
    move-exception v1

    .line 3947
    .local v1, "e":Ljava/lang/Exception;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "dumpHansAppInfo e="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    .line 3949
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_585
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public dumpProcInfo()Ljava/lang/String;
    .registers 5

    .line 4047
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x64

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 4048
    .local v0, "sb":Ljava/lang/StringBuilder;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Running Uid Size "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4049
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "   "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4050
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public enterCpuHighLoadMode()V
    .registers 1

    .line 4352
    return-void
.end method

.method public enterFastFreeze(ILjava/lang/String;ILandroid/util/SparseIntArray;Ljava/lang/String;)I
    .registers 12
    .param p1, "requestId"    # I
    .param p2, "callerPkg"    # Ljava/lang/String;
    .param p3, "requestTimeout"    # I
    .param p4, "requestInfo"    # Landroid/util/SparseIntArray;
    .param p5, "reason"    # Ljava/lang/String;

    .line 2280
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOnTime:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckMinTime:J

    mul-long/2addr v4, v2

    cmp-long v0, v0, v4

    const/4 v1, -0x1

    if-gez v0, :cond_21

    .line 2281
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_20

    .line 2282
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v2, "device just screen on, don not trigger fast freeze"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 2284
    :cond_20
    return v1

    .line 2286
    :cond_21
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_2c

    .line 2287
    return v1

    .line 2289
    :cond_2c
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isFastFreezerOn()Z

    move-result v0

    if-eqz v0, :cond_35

    .line 2290
    const/16 v0, -0x63

    return v0

    .line 2293
    :cond_35
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevel()I

    move-result v0

    const/4 v1, 0x3

    if-lt v0, v1, :cond_43

    .line 2294
    const/16 v0, -0x5a

    return v0

    .line 2296
    :cond_43
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastFastFreezerEnterTime:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    sub-long/2addr v0, v2

    .line 2297
    .local v0, "lastFFInterval":J
    const/4 v2, -0x1

    .line 2298
    .local v2, "maxFFTimeout":I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_50
    invoke-virtual {p4}, Landroid/util/SparseIntArray;->size()I

    move-result v4

    if-ge v3, v4, :cond_6e

    .line 2299
    invoke-virtual {p4, v3}, Landroid/util/SparseIntArray;->keyAt(I)I

    move-result v4

    int-to-long v4, v4

    cmp-long v4, v0, v4

    if-ltz v4, :cond_6b

    .line 2300
    invoke-virtual {p4, v3}, Landroid/util/SparseIntArray;->valueAt(I)I

    move-result v4

    invoke-static {p3, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 2298
    :cond_6b
    add-int/lit8 v3, v3, 0x1

    goto :goto_50

    .line 2303
    .end local v3    # "i":I
    :cond_6e
    if-lez v2, :cond_a0

    .line 2304
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v4, 0x11

    invoke-virtual {v3, v4, p1, v2, p5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v3}, Landroid/os/Message;->sendToTarget()V

    .line 2305
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_9f

    .line 2306
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " request FF : "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 2308
    :cond_9f
    return v2

    .line 2310
    :cond_a0
    const/4 v3, 0x0

    return v3
.end method

.method public enterFastFreeze(ILjava/lang/String;)V
    .registers 9
    .param p1, "requestId"    # I
    .param p2, "reason"    # Ljava/lang/String;

    .line 2316
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOnTime:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x2

    iget-wide v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCheckMinTime:J

    mul-long/2addr v4, v2

    cmp-long v0, v0, v4

    if-gez v0, :cond_20

    .line 2317
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 2318
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "device just screen on, don not trigger fast freeze"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 2320
    :cond_1f
    return-void

    .line 2322
    :cond_20
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevel()I

    move-result v0

    const/4 v1, 0x1

    if-lt v0, v1, :cond_2c

    .line 2323
    return-void

    .line 2326
    :cond_2c
    const-string/jumbo v0, "fold-open"

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_40

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_40

    .line 2327
    return-void

    .line 2329
    :cond_40
    const-string v0, "cold-start"

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_51

    const-string/jumbo v0, "osense"

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c6

    .line 2331
    :cond_51
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedPkgName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->skipFastFreeze(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_d3

    .line 2332
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedPkgName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->skipAppSwitch(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_d3

    .line 2333
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getLastResumedPkgName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->skipAppSwitch(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_88

    goto :goto_d3

    .line 2337
    :cond_88
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedPkgName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->isFastFreezeHotEnable(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_c6

    .line 2339
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2341
    :try_start_9f
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0
    :try_end_b1
    .catchall {:try_start_9f .. :try_end_b1} :catchall_bf

    if-eqz v0, :cond_b9

    .line 2345
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2342
    return-void

    .line 2345
    :cond_b9
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2346
    goto :goto_c6

    .line 2345
    :catchall_bf
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2346
    throw v0

    .line 2349
    :cond_c6
    :goto_c6
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x11

    const/4 v2, -0x1

    invoke-virtual {v0, v1, p1, v2, p2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 2350
    return-void

    .line 2334
    :cond_d3
    :goto_d3
    return-void
.end method

.method public enterKillFrozenAppAlarm(Landroid/app/AlarmManager$OnAlarmListener;)V
    .registers 13
    .param p1, "listener"    # Landroid/app/AlarmManager$OnAlarmListener;

    .line 1717
    if-nez p1, :cond_3

    .line 1718
    return-void

    .line 1720
    :cond_3
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-nez v0, :cond_13

    .line 1721
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1723
    :cond_13
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    if-eqz v0, :cond_3d

    .line 1724
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    invoke-virtual {v0, p1}, Landroid/app/AlarmManager;->cancel(Landroid/app/AlarmManager$OnAlarmListener;)V

    .line 1725
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getKillFrozenAppIntervalTime()J

    move-result-wide v2

    add-long v6, v0, v2

    .line 1726
    .local v6, "triggerAtMillis":J
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAlarmManager:Landroid/app/AlarmManager;

    .line 1728
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getBgHandler()Landroid/os/Handler;

    move-result-object v10

    .line 1726
    const/4 v5, 0x3

    const-string/jumbo v8, "kill frozen app"

    move-object v9, p1

    .end local p1    # "listener":Landroid/app/AlarmManager$OnAlarmListener;
    .local v9, "listener":Landroid/app/AlarmManager$OnAlarmListener;
    invoke-virtual/range {v4 .. v10}, Landroid/app/AlarmManager;->setExact(IJLjava/lang/String;Landroid/app/AlarmManager$OnAlarmListener;Landroid/os/Handler;)V

    goto :goto_3e

    .line 1723
    .end local v6    # "triggerAtMillis":J
    .end local v9    # "listener":Landroid/app/AlarmManager$OnAlarmListener;
    .restart local p1    # "listener":Landroid/app/AlarmManager$OnAlarmListener;
    :cond_3d
    move-object v9, p1

    .line 1730
    .end local p1    # "listener":Landroid/app/AlarmManager$OnAlarmListener;
    .restart local v9    # "listener":Landroid/app/AlarmManager$OnAlarmListener;
    :goto_3e
    return-void
.end method

.method public enterLcdOn()V
    .registers 4

    .line 1398
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x15

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1399
    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 1402
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v2, 0x14

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1403
    const/4 v0, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 1405
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1407
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->notifySceneChanged(I)V

    .line 1408
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->unregisterKeyEventObserver()V

    .line 1409
    return-void
.end method

.method public enterNightDeepDoze()V
    .registers 4

    .line 1444
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_41

    .line 1445
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDozeMode()Z

    move-result v0

    if-eqz v0, :cond_41

    .line 1446
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDeepSleep()Z

    move-result v0

    if-nez v0, :cond_41

    .line 1447
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInNight()Z

    move-result v0

    if-eqz v0, :cond_41

    .line 1448
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x17

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_33

    .line 1449
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1451
    :cond_33
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1453
    :cond_41
    return-void
.end method

.method public enterStrictMode()V
    .registers 4

    .line 4370
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 4371
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4373
    :cond_f
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 4374
    return-void
.end method

.method public exitCpuHighLoadMode()V
    .registers 1

    .line 4361
    return-void
.end method

.method public exitDeepSleep(Ljava/lang/String;)V
    .registers 4
    .param p1, "reason"    # Ljava/lang/String;

    .line 1420
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0xc

    invoke-virtual {v0, v1, p1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1421
    return-void
.end method

.method public exitLcdOn()V
    .registers 3

    .line 1412
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1415
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->notifySceneChanged(I)V

    .line 1416
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->registerKeyEventObserver()V

    .line 1417
    return-void
.end method

.method public exitNightDeepDoze()V
    .registers 4

    .line 1456
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_2b

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_2b

    .line 1457
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x17

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 1458
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1460
    :cond_1d
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 1462
    :cond_2b
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->cancelExitNightDeepDozeAlarm()V

    .line 1463
    return-void
.end method

.method public exitStrictMode()V
    .registers 4

    .line 4377
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_2b

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_2b

    .line 4378
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 4379
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4381
    :cond_1d
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 4383
    :cond_2b
    return-void
.end method

.method public forceBackToRunning(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V
    .registers 6
    .param p1, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;

    .line 3064
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 3065
    :try_start_5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->forceTransitionState(ILjava/lang/String;)V

    .line 3066
    monitor-exit v0

    .line 3067
    return-void

    .line 3066
    :catchall_f
    move-exception v1

    monitor-exit v0
    :try_end_11
    .catchall {:try_start_5 .. :try_end_11} :catchall_f

    throw v1
.end method

.method public forceTransitionState(IILjava/lang/String;)V
    .registers 7
    .param p1, "uid"    # I
    .param p2, "destState"    # I
    .param p3, "reason"    # Ljava/lang/String;

    .line 3053
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 3054
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_1d

    .line 3055
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 3056
    :try_start_b
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-nez v2, :cond_18

    .line 3057
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, p2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->forceTransitionState(ILjava/lang/String;)V

    .line 3059
    :cond_18
    monitor-exit v1

    goto :goto_1d

    :catchall_1a
    move-exception v2

    monitor-exit v1
    :try_end_1c
    .catchall {:try_start_b .. :try_end_1c} :catchall_1a

    throw v2

    .line 3061
    :cond_1d
    :goto_1d
    return-void
.end method

.method public forceUnFreezeApp(Lcom/android/server/hans/OplusHansPackage;ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 9
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "uid"    # I
    .param p3, "ufzReason"    # Ljava/lang/String;
    .param p4, "subReason"    # Ljava/lang/String;

    .line 3031
    if-eqz p1, :cond_18

    .line 3032
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 3033
    :try_start_7
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v1

    if-eqz v1, :cond_13

    .line 3034
    invoke-virtual {p0, p1, p3, p4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v1

    monitor-exit v0

    return-object v1

    .line 3036
    :cond_13
    monitor-exit v0

    goto :goto_18

    :catchall_15
    move-exception v1

    monitor-exit v0
    :try_end_17
    .catchall {:try_start_7 .. :try_end_17} :catchall_15

    throw v1

    .line 3038
    :cond_18
    :goto_18
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v1, p2}, Lcom/android/server/hans/freeze/HansCGroup;->getRunningPidsByUid(I)Ljava/util/ArrayList;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, p2, v1, v2}, Lcom/android/server/hans/freeze/HansCGroup;->forceUnfreezeApp(ILjava/util/ArrayList;Ljava/lang/String;)V

    .line 3039
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v0
.end method

.method public freeze(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 5
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;

    .line 2728
    if-nez p1, :cond_5

    .line 2729
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    return-object v0

    .line 2731
    :cond_5
    const-string v0, "Preload_F"

    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 2732
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeForPreload(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    move-result-object v0

    return-object v0

    .line 2734
    :cond_12
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansRestriction()Lcom/android/server/hans/OplusHansRestriction;

    move-result-object v0

    .line 2735
    .local v0, "currentRestriction":Lcom/android/server/hans/OplusHansRestriction;
    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->freezeForSceneCombo(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    move-result-object v1

    return-object v1
.end method

.method public freezeAllApps(Ljava/lang/String;)V
    .registers 9
    .param p1, "reason"    # Ljava/lang/String;

    .line 2682
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2684
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 2685
    .local v0, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_b4

    .line 2686
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 2687
    .local v1, "ruid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v2

    if-ne v1, v2, :cond_26

    .line 2688
    goto :goto_b

    .line 2691
    :cond_26
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v2

    invoke-direct {p0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 2692
    .local v2, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v2, :cond_33

    .line 2693
    goto :goto_b

    .line 2697
    :cond_33
    invoke-static {}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getInstance()Lcom/android/server/oplus/osense/resource/AppStatusManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getDefaultLauncher()Ljava/lang/String;

    move-result-object v3

    .line 2698
    .local v3, "launcher":Ljava/lang/String;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_45

    .line 2699
    const-string/jumbo v4, "none"

    move-object v3, v4

    .line 2701
    :cond_45
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/am/OplusHansManager;->getLastResumedUid()I

    move-result v4

    if-ne v1, v4, :cond_5e

    .line 2702
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/am/OplusHansManager;->getCurResumedPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5e

    .line 2703
    goto :goto_b

    .line 2706
    :cond_5e
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4
    :try_end_63
    .catchall {:try_start_5 .. :try_end_63} :catchall_bb

    .line 2707
    :try_start_63
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v5

    if-nez v5, :cond_ae

    .line 2708
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v5

    if-nez v5, :cond_7e

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackApp(I)Z

    move-result v5

    if-eqz v5, :cond_7e

    goto :goto_ae

    .line 2712
    :cond_7e
    invoke-virtual {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->freezeViaSM(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2713
    monitor-exit v4
    :try_end_82
    .catchall {:try_start_63 .. :try_end_82} :catchall_b1

    .line 2714
    :try_start_82
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v4

    if-eqz v4, :cond_ac

    .line 2715
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "SceneManager freezeAllApps uid="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " reason: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V
    :try_end_ac
    .catchall {:try_start_82 .. :try_end_ac} :catchall_bb

    .line 2717
    .end local v1    # "ruid":I
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "launcher":Ljava/lang/String;
    :cond_ac
    goto/16 :goto_b

    .line 2709
    .restart local v1    # "ruid":I
    .restart local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local v3    # "launcher":Ljava/lang/String;
    :cond_ae
    :goto_ae
    :try_start_ae
    monitor-exit v4

    goto/16 :goto_b

    .line 2713
    :catchall_b1
    move-exception v5

    monitor-exit v4
    :try_end_b3
    .catchall {:try_start_ae .. :try_end_b3} :catchall_b1

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "reason":Ljava/lang/String;
    :try_start_b3
    throw v5
    :try_end_b4
    .catchall {:try_start_b3 .. :try_end_b4} :catchall_bb

    .line 2719
    .end local v0    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    .end local v1    # "ruid":I
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v3    # "launcher":Ljava/lang/String;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "reason":Ljava/lang/String;
    :cond_b4
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2720
    nop

    .line 2721
    return-void

    .line 2719
    :catchall_bb
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2720
    throw v0
.end method

.method public freezeAndTransState(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 6
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 2880
    if-nez p1, :cond_5

    .line 2881
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    return-object v0

    .line 2883
    :cond_5
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansRestriction()Lcom/android/server/hans/OplusHansRestriction;

    move-result-object v0

    .line 2884
    .local v0, "currentRestriction":Lcom/android/server/hans/OplusHansRestriction;
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2885
    :try_start_12
    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->freezeForSceneCombo(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    move-result-object v2

    .line 2886
    .local v2, "freezeState":Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    if-eq v2, v3, :cond_1e

    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    if-ne v2, v3, :cond_21

    .line 2887
    :cond_1e
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeViaSM(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2889
    :cond_21
    monitor-exit v1

    return-object v2

    .line 2890
    .end local v2    # "freezeState":Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    :catchall_23
    move-exception v2

    monitor-exit v1
    :try_end_25
    .catchall {:try_start_12 .. :try_end_25} :catchall_23

    throw v2
.end method

.method public freezeDirectlyForSceneCombo(Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;
    .registers 7
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 2848
    if-nez p1, :cond_5

    .line 2849
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    return-object v0

    .line 2852
    :cond_5
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansRestriction()Lcom/android/server/hans/OplusHansRestriction;

    move-result-object v0

    .line 2853
    .local v0, "currentRestriction":Lcom/android/server/hans/OplusHansRestriction;
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2854
    :try_start_12
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-eqz v2, :cond_1c

    .line 2855
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v2

    .line 2858
    :cond_1c
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansDBConfig;->isInImPkgConfigList(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_39

    .line 2859
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lcom/android/server/am/OplusHansManager;->setNetCare(ILjava/lang/String;)V

    .line 2862
    :cond_39
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    const-string v3, ""

    invoke-virtual {v2, p1, v3}, Lcom/android/server/hans/freeze/HansCGroup;->hansFreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Z

    move-result v2

    .line 2863
    .local v2, "isSuccessful":Z
    if-eqz v2, :cond_55

    .line 2865
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v3, p1, v0}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleDeny(Lcom/android/server/hans/OplusHansPackage;Lcom/android/server/hans/OplusHansRestriction;)V

    .line 2867
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v3

    invoke-virtual {v3, p1}, Lcom/android/server/hans/scene/HansSceneManager;->postFreezeCheck(Lcom/android/server/hans/OplusHansPackage;)V

    .line 2868
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v3

    .line 2870
    :cond_55
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Freezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    monitor-exit v1

    return-object v3

    .line 2872
    .end local v2    # "isSuccessful":Z
    :catchall_59
    move-exception v2

    monitor-exit v1
    :try_end_5b
    .catchall {:try_start_12 .. :try_end_5b} :catchall_59

    throw v2
.end method

.method public freezeViaSM(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 2928
    if-nez p1, :cond_3

    .line 2929
    return-void

    .line 2931
    :cond_3
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 2932
    :try_start_8
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->forceEnterFrozen()V

    .line 2933
    monitor-exit v0

    .line 2934
    return-void

    .line 2933
    :catchall_11
    move-exception v1

    monitor-exit v0
    :try_end_13
    .catchall {:try_start_8 .. :try_end_13} :catchall_11

    throw v1
.end method

.method public getAllHansAppByUid(I)Landroid/util/Pair;
    .registers 5
    .param p1, "uid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Landroid/util/Pair<",
            "Lcom/android/server/hans/OplusHansPackage;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 2411
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2413
    :try_start_5
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0
    :try_end_d
    .catchall {:try_start_5 .. :try_end_d} :catchall_2d

    .line 2415
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2416
    nop

    .line 2417
    if-eqz v0, :cond_2b

    .line 2418
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2419
    :try_start_1a
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v2

    monitor-exit v1

    return-object v2

    .line 2420
    :catchall_28
    move-exception v2

    monitor-exit v1
    :try_end_2a
    .catchall {:try_start_1a .. :try_end_2a} :catchall_28

    throw v2

    .line 2422
    :cond_2b
    const/4 v1, 0x0

    return-object v1

    .line 2415
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_2d
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2416
    throw v0
.end method

.method public getAppType(I)I
    .registers 5
    .param p1, "uid"    # I

    .line 2427
    :try_start_0
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2428
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_14

    .line 2429
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_b} :catch_15

    .line 2430
    :try_start_b
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v2

    monitor-exit v1

    return v2

    .line 2431
    :catchall_11
    move-exception v2

    monitor-exit v1
    :try_end_13
    .catchall {:try_start_b .. :try_end_13} :catchall_11

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "uid":I
    :try_start_13
    throw v2
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_14} :catch_15

    .line 2428
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "uid":I
    :cond_14
    goto :goto_16

    .line 2433
    :catch_15
    move-exception v0

    :goto_16
    nop

    .line 2434
    const/4 v0, -0x1

    return v0
.end method

.method public getCurrentCameraMinSysSubSceneId()I
    .registers 2

    .line 4812
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentCameraMinSysSubSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getCurrentMinSystemScene()I
    .registers 2

    .line 4808
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getDynamicScene(Ljava/lang/String;I)Ljava/lang/String;
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 4074
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isInRecentLockScene()Z

    move-result v0

    if-eqz v0, :cond_17

    .line 4075
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusHansManager;->isRecentSuperLockListApp(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_17

    .line 4076
    const-string v0, "dynamic-background"

    return-object v0

    .line 4078
    :cond_17
    const-string v0, " "

    return-object v0
.end method

.method public getHansAppByUid(I)Landroid/util/Pair;
    .registers 5
    .param p1, "uid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Landroid/util/Pair<",
            "Lcom/android/server/hans/OplusHansPackage;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 2395
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2397
    :try_start_5
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0
    :try_end_9
    .catchall {:try_start_5 .. :try_end_9} :catchall_29

    .line 2399
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2400
    nop

    .line 2401
    if-eqz v0, :cond_27

    .line 2402
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2403
    :try_start_16
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v2

    monitor-exit v1

    return-object v2

    .line 2404
    :catchall_24
    move-exception v2

    monitor-exit v1
    :try_end_26
    .catchall {:try_start_16 .. :try_end_26} :catchall_24

    throw v2

    .line 2406
    :cond_27
    const/4 v1, 0x0

    return-object v1

    .line 2399
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_29
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2400
    throw v0
.end method

.method public getHansMapReadLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
    .registers 2

    .line 442
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    return-object v0
.end method

.method public getHansMapWriteLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
    .registers 2

    .line 446
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    return-object v0
.end method

.method public getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;
    .registers 3
    .param p1, "uid"    # I

    .line 2386
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    return-object v0
.end method

.method public getHansPkgByUid(II)Lcom/android/server/hans/OplusHansPackage;
    .registers 5
    .param p1, "uid"    # I
    .param p2, "targetFlags"    # I

    .line 2377
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2379
    :try_start_5
    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0
    :try_end_9
    .catchall {:try_start_5 .. :try_end_9} :catchall_f

    .line 2381
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2379
    return-object v0

    .line 2381
    :catchall_f
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2382
    throw v0
.end method

.method public getHansPkgByUidLocked(I)Lcom/android/server/hans/OplusHansPackage;
    .registers 3
    .param p1, "uid"    # I

    .line 2390
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    return-object v0
.end method

.method public getHansRestriction()Lcom/android/server/hans/OplusHansRestriction;
    .registers 3

    .line 472
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 474
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestriction()Lcom/android/server/hans/OplusHansRestriction;

    move-result-object v0
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_11

    .line 476
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 474
    return-object v0

    .line 476
    :catchall_11
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 477
    throw v0
.end method

.method public getHansRestrictionLevel()I
    .registers 2

    .line 481
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getRestrictionLevel()I

    move-result v0

    return v0
.end method

.method public getLastLcdOnTime()J
    .registers 3

    .line 1787
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLastLcdOnTime:J

    return-wide v0
.end method

.method public getMainHandler()Landroid/os/Handler;
    .registers 2

    .line 450
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    return-object v0
.end method

.method public getMinAdjOfUid(I)I
    .registers 5
    .param p1, "uid"    # I

    .line 3713
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    monitor-enter v0

    .line 3714
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 3715
    .local v1, "adj":Ljava/lang/Integer;
    if-eqz v1, :cond_16

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v2

    goto :goto_18

    :cond_16
    const/16 v2, 0x3e9

    :goto_18
    monitor-exit v0

    return v2

    .line 3716
    .end local v1    # "adj":Ljava/lang/Integer;
    :catchall_1a
    move-exception v1

    monitor-exit v0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_1a

    throw v1
.end method

.method public getRunningSet()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 454
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 456
    :try_start_5
    new-instance v0, Landroid/util/ArraySet;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-direct {v0, v1}, Landroid/util/ArraySet;-><init>(Ljava/util/Collection;)V
    :try_end_c
    .catchall {:try_start_5 .. :try_end_c} :catchall_12

    .line 458
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 456
    return-object v0

    .line 458
    :catchall_12
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 459
    throw v0
.end method

.method public getSceneId()I
    .registers 2

    .line 4082
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getExtremeFgMode()Z

    move-result v0

    if-eqz v0, :cond_d

    .line 4083
    const/16 v0, 0x10

    return v0

    .line 4085
    :cond_d
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isCharging()Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 4086
    const/16 v0, 0x8

    return v0

    .line 4088
    :cond_1a
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 4089
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isFastFreezerOn()Z

    move-result v0

    if-eqz v0, :cond_2d

    .line 4090
    const/16 v0, 0x20

    return v0

    .line 4092
    :cond_2d
    const/4 v0, 0x4

    return v0

    .line 4095
    :cond_2f
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDeepSleep()Z

    move-result v0

    if-eqz v0, :cond_3b

    .line 4096
    const/4 v0, 0x1

    return v0

    .line 4098
    :cond_3b
    const/4 v0, 0x2

    return v0
.end method

.method public getSceneItemByName(Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneItem;
    .registers 3
    .param p1, "sceneName"    # Ljava/lang/String;

    .line 4104
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_5c

    :cond_7
    goto :goto_44

    :sswitch_8
    const-string v0, "deepSleepUidDisNet"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x4

    goto :goto_45

    :sswitch_12
    const-string v0, "FastFreezer"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x2

    goto :goto_45

    :sswitch_1c
    const-string v0, "LcdOn"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x0

    goto :goto_45

    :sswitch_26
    const-string v0, "DPUidDisNetWhenSwitchClose"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x5

    goto :goto_45

    :sswitch_30
    const-string v0, "deepSleep"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x3

    goto :goto_45

    :sswitch_3a
    const-string v0, "LcdOff"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/4 v0, 0x1

    goto :goto_45

    :goto_44
    const/4 v0, -0x1

    :goto_45
    packed-switch v0, :pswitch_data_76

    .line 4118
    const/4 v0, 0x0

    return-object v0

    .line 4116
    :pswitch_4a
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    .line 4114
    :pswitch_4d
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    .line 4112
    :pswitch_50
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    .line 4110
    :pswitch_53
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    .line 4108
    :pswitch_56
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    .line 4106
    :pswitch_59
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnScene:Lcom/android/server/hans/scene/HansSceneItem;

    return-object v0

    :sswitch_data_5c
    .sparse-switch
        -0x78adef7e -> :sswitch_3a
        -0x76b58ab5 -> :sswitch_30
        -0x4c7fb469 -> :sswitch_26
        0x45d7c6c -> :sswitch_1c
        0x325ea09f -> :sswitch_12
        0x66375d94 -> :sswitch_8
    .end sparse-switch

    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_59
        :pswitch_56
        :pswitch_53
        :pswitch_50
        :pswitch_4d
        :pswitch_4a
    .end packed-switch
.end method

.method public getSceneStr()Ljava/lang/String;
    .registers 5

    .line 4054
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4055
    .local v0, "sb":Ljava/lang/StringBuilder;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneCombo;->getName()Ljava/lang/String;

    move-result-object v1

    .line 4056
    .local v1, "comboName":Ljava/lang/String;
    if-eqz v1, :cond_5e

    .line 4057
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getExtremeFgMode()Z

    move-result v2

    if-eqz v2, :cond_33

    .line 4058
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "-Fg"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 4059
    .local v2, "extremeFgSceneStr":Ljava/lang/String;
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 4060
    .end local v2    # "extremeFgSceneStr":Ljava/lang/String;
    :cond_32
    goto :goto_5e

    :cond_33
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevel()I

    move-result v2

    if-lez v2, :cond_32

    .line 4061
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "StrictMode-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevel()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 4062
    .local v2, "strictSceneStr":Ljava/lang/String;
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 4065
    .end local v2    # "strictSceneStr":Ljava/lang/String;
    :cond_5e
    :goto_5e
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4066
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isFastFreezerOn()Z

    move-result v2

    if-eqz v2, :cond_84

    .line 4067
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "|"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v3}, Lcom/android/server/hans/scene/HansSceneItem;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4070
    :cond_84
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public getTargetFlagByAppClass(I)I
    .registers 3
    .param p1, "appClass"    # I

    .line 1203
    const/4 v0, 0x2

    sparse-switch p1, :sswitch_data_8

    .line 1211
    return v0

    .line 1209
    :sswitch_5
    return v0

    .line 1206
    :sswitch_6
    const/4 v0, 0x1

    return v0

    :sswitch_data_8
    .sparse-switch
        0x1 -> :sswitch_6
        0x2 -> :sswitch_5
        0x4 -> :sswitch_5
        0x10 -> :sswitch_6
    .end sparse-switch
.end method

.method public getTargetFlagByAppClass(Ljava/lang/String;I)I
    .registers 4
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "appClass"    # I

    .line 1195
    const/16 v0, 0x10

    if-ne p2, v0, :cond_d

    .line 1196
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->isRestrictSysOrGrayApp(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_d

    .line 1197
    const/4 v0, 0x0

    return v0

    .line 1199
    :cond_d
    invoke-virtual {p0, p2}, Lcom/android/server/hans/scene/HansSceneManager;->getTargetFlagByAppClass(I)I

    move-result v0

    return v0
.end method

.method public getThermalIgnoreTrafficSet()Landroid/util/ArraySet;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 4598
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 4599
    .local v0, "trafficSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v1

    .line 4600
    :try_start_8
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-virtual {v0, v2}, Landroid/util/ArraySet;->addAll(Landroid/util/ArraySet;)V

    .line 4601
    monitor-exit v1

    .line 4602
    return-object v0

    .line 4601
    :catchall_f
    move-exception v2

    monitor-exit v1
    :try_end_11
    .catchall {:try_start_8 .. :try_end_11} :catchall_f

    throw v2
.end method

.method public getThermalImpScene()I
    .registers 2

    .line 5195
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getThermalLevel()I
    .registers 2

    .line 4952
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getThermalMngLevel()I
    .registers 2

    .line 5144
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMngLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getThermalPriorityLevel()I
    .registers 2

    .line 5076
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalPriorityLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    return v0
.end method

.method public getUidFreezeRate(I)I
    .registers 23
    .param p1, "uid"    # I

    .line 3754
    move-object/from16 v1, p0

    move/from16 v2, p1

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isStatisticsEnable()Z

    move-result v0

    const/4 v3, 0x0

    if-nez v0, :cond_10

    .line 3755
    return v3

    .line 3757
    :cond_10
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    .line 3762
    .local v4, "now":J
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 3764
    :try_start_19
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0
    :try_end_21
    .catchall {:try_start_19 .. :try_end_21} :catchall_89

    move-object v6, v0

    .line 3765
    .local v6, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v6, :cond_2b

    .line 3766
    nop

    .line 3774
    iget-object v0, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3766
    return v3

    .line 3768
    :cond_2b
    :try_start_2b
    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v7

    monitor-enter v7
    :try_end_30
    .catchall {:try_start_2b .. :try_end_30} :catchall_89

    .line 3769
    :try_start_30
    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    .line 3770
    .local v0, "frozen":Z
    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getFreezeTime()J

    move-result-wide v8

    .line 3771
    .local v8, "freezeSnapShotTime":J
    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v10

    .line 3772
    .local v10, "enterBgSnapShotTime":J
    monitor-exit v7
    :try_end_3d
    .catchall {:try_start_30 .. :try_end_3d} :catchall_86

    .line 3774
    .end local v6    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    iget-object v6, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v6}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3775
    nop

    .line 3777
    const-wide/16 v6, 0x0

    .line 3778
    .local v6, "frozenDuTime":J
    const-wide/16 v12, 0x0

    .line 3779
    .local v12, "bgLiveDuTime":J
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v14

    invoke-virtual {v14, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->getUidFrozenAndLiveDuTime(I)Landroid/util/Pair;

    move-result-object v14

    .line 3780
    .local v14, "frozenAndBgLiveDuTimePair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Long;Ljava/lang/Long;>;"
    if-eqz v14, :cond_61

    .line 3781
    iget-object v15, v14, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v15, Ljava/lang/Long;

    invoke-virtual {v15}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    .line 3782
    iget-object v15, v14, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v15, Ljava/lang/Long;

    invoke-virtual {v15}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    .line 3784
    :cond_61
    const-wide/16 v15, 0x3e8

    const-wide/16 v17, 0x0

    if-eqz v0, :cond_71

    cmp-long v19, v8, v17

    if-lez v19, :cond_71

    .line 3785
    sub-long v19, v4, v8

    div-long v19, v19, v15

    add-long v6, v6, v19

    .line 3788
    :cond_71
    cmp-long v19, v10, v17

    if-lez v19, :cond_7b

    .line 3789
    sub-long v19, v4, v10

    div-long v19, v19, v15

    add-long v12, v12, v19

    .line 3791
    :cond_7b
    cmp-long v15, v12, v17

    if-eqz v15, :cond_85

    const-wide/16 v15, 0x64

    mul-long/2addr v15, v6

    div-long v2, v15, v12

    long-to-int v3, v2

    :cond_85
    return v3

    .line 3772
    .end local v0    # "frozen":Z
    .end local v8    # "freezeSnapShotTime":J
    .end local v10    # "enterBgSnapShotTime":J
    .end local v12    # "bgLiveDuTime":J
    .end local v14    # "frozenAndBgLiveDuTimePair":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Long;Ljava/lang/Long;>;"
    .local v6, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_86
    move-exception v0

    :try_start_87
    monitor-exit v7
    :try_end_88
    .catchall {:try_start_87 .. :try_end_88} :catchall_86

    .end local v4    # "now":J
    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "uid":I
    :try_start_88
    throw v0
    :try_end_89
    .catchall {:try_start_88 .. :try_end_89} :catchall_89

    .line 3774
    .end local v6    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .restart local v4    # "now":J
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "uid":I
    :catchall_89
    move-exception v0

    iget-object v2, v1, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3775
    throw v0
.end method

.method public handleFreezerExempt(I)V
    .registers 4
    .param p1, "uid"    # I

    .line 1171
    const-string v0, "FreezerExempt"

    const-string v1, ""

    invoke-virtual {p0, p1, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 1172
    return-void
.end method

.method public handleProcessDied(I)V
    .registers 2
    .param p1, "uid"    # I

    .line 4775
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->recordQuotaTaskStatus(I)V

    .line 4776
    return-void
.end method

.method public handleSceneChanged(IZ)V
    .registers 14
    .param p1, "sceneId"    # I
    .param p2, "enter"    # Z

    .line 843
    const-string/jumbo v0, "not found scene "

    const/4 v1, 0x0

    if-eqz p2, :cond_316

    .line 844
    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sparse-switch p1, :sswitch_data_4f2

    .line 1009
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    .line 1010
    goto/16 :goto_4f1

    .line 1006
    :sswitch_26
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->enterMinSystemScene(I)V

    .line 1007
    goto/16 :goto_4f1

    .line 991
    :sswitch_2b
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_4c

    .line 992
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getDeepSleepFreezeWhite()Z

    move-result v0

    if-eqz v0, :cond_3a

    goto :goto_3b

    :cond_3a
    move v2, v3

    :goto_3b
    move v10, v2

    .line 993
    .local v10, "targetFlags":I
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v8, 0x1fe

    const/16 v9, 0xf

    const-string v6, "dsUidDisNetDsSleepSwitchClose"

    const v7, 0x140b01f8

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 996
    .end local v10    # "targetFlags":I
    :cond_4c
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 997
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SCENE_ID_DP_UID_DISNET_WHEN_SWITCH_CLOSE: enter"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 998
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1000
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    goto/16 :goto_4f1

    .line 976
    :sswitch_69
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_8a

    .line 977
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getDeepSleepFreezeWhite()Z

    move-result v0

    if-eqz v0, :cond_78

    goto :goto_79

    :cond_78
    move v2, v3

    :goto_79
    move v10, v2

    .line 978
    .restart local v10    # "targetFlags":I
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v8, 0x1fe

    const/16 v9, 0x15

    const-string v6, "deepSleepUidDisNet"

    const v7, 0x140b01f8

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 981
    .end local v10    # "targetFlags":I
    :cond_8a
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_a5

    .line 982
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SCENE_ID_DP_UID_DISNET: enter"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 983
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 985
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 988
    :cond_a5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    invoke-direct {p0, v4, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addOrRemoveExtensionProxyFlagForAllHansPkg(ZI)V

    .line 989
    goto/16 :goto_4f1

    .line 943
    :sswitch_b0
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v0

    if-eqz v0, :cond_167

    .line 944
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isStrictModeEnable()Z

    move-result v0

    if-nez v0, :cond_c6

    goto/16 :goto_167

    .line 948
    :cond_c6
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_d9

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_d9

    .line 950
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateExtensionSceneByStrictMode(Lcom/android/server/hans/scene/HansScene;Z)V

    .line 953
    :cond_d9
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getStrictModeLevel()I

    move-result v0

    .line 954
    .local v0, "strictModeLevel":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "StrictMode-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    .line 955
    const/4 v2, 0x5

    .line 956
    .local v2, "strictModeTarget":I
    if-le v0, v4, :cond_fc

    .line 958
    const/4 v2, 0x7

    move v10, v2

    goto :goto_fd

    .line 956
    :cond_fc
    move v10, v2

    .line 960
    .end local v2    # "strictModeTarget":I
    .local v10, "strictModeTarget":I
    :goto_fd
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    iget-object v6, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    const/16 v8, 0x1fe

    const/4 v9, 0x4

    const v7, 0x1d6fbfff

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 965
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getStrictModeWidgetList(Z)Landroid/util/SparseArray;

    .line 966
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v1, v4}, Lcom/android/server/hans/scene/HansSceneManager;->updateExtensionSceneByStrictMode(Lcom/android/server/hans/scene/HansScene;Z)V

    .line 971
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "enter "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 972
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 973
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeSceneStr:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->freezeAllApps(Ljava/lang/String;)V

    .line 974
    .end local v0    # "strictModeLevel":I
    .end local v10    # "strictModeTarget":I
    goto/16 :goto_4f1

    .line 945
    :cond_167
    :goto_167
    return-void

    .line 925
    :sswitch_168
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v0

    if-eqz v0, :cond_1b5

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isCpuHighLoadSceneEnable()Z

    move-result v0

    if-nez v0, :cond_17d

    goto :goto_1b5

    .line 928
    :cond_17d
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_191

    .line 929
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string v6, "CpuHighLoad"

    const v7, 0x1d6fbfff

    const/16 v8, 0x1fe

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 935
    :cond_191
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 936
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 937
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "enter CpuHighLoad mode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 938
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 939
    iput-boolean v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInCpuHighLoadMode:Z

    goto/16 :goto_4f1

    .line 926
    :cond_1b5
    :goto_1b5
    return-void

    .line 846
    :sswitch_1b6
    const-string/jumbo v0, "enter night deep doze mode"

    .line 847
    .local v0, "nddEnterInfo":Ljava/lang/String;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v1, :cond_1ce

    .line 849
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string/jumbo v6, "nightDeepDoze"

    const v7, 0x1c0b0dfd

    const/16 v8, 0x1fe

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 855
    :cond_1ce
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v1, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v1

    if-nez v1, :cond_4f1

    .line 856
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 857
    iput-boolean v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInNightDeepDoze:Z

    .line 858
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 859
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 860
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    invoke-virtual {v1, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyNddSceneChange(Z)V

    .line 861
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v1, :cond_202

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v1, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v1

    if-nez v1, :cond_205

    .line 863
    :cond_202
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 865
    :cond_205
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->setExitNightDeepDozeAlarm()V

    goto/16 :goto_4f1

    .line 914
    .end local v0    # "nddEnterInfo":Ljava/lang/String;
    :sswitch_20a
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_21f

    .line 915
    new-instance v1, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v5, 0x14

    const/4 v6, 0x7

    const-string v2, "airPlane"

    const v3, 0x46fbbfe

    const/16 v4, 0x1fe

    invoke-direct/range {v1 .. v6}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 918
    :cond_21f
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isAirplane()Z

    move-result v0

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 919
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 920
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "enter air plane mode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 921
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    goto/16 :goto_4f1

    .line 899
    :sswitch_24b
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_256

    .line 900
    return-void

    .line 902
    :cond_256
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_26b

    .line 903
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v9, 0x9

    const/4 v10, 0x5

    const-string v6, "deppIdle"

    const v7, 0x1c0b0dfd

    const/16 v8, 0x1fe

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 906
    :cond_26b
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 907
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 908
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "enter LcdOff deep Idle mode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 909
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 910
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyDeepIdleSceneEnter(Z)V

    goto/16 :goto_4f1

    .line 883
    :sswitch_294
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_29f

    .line 884
    return-void

    .line 886
    :cond_29f
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_2b5

    .line 887
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v9, 0x8

    const/4 v10, 0x5

    const-string/jumbo v6, "idle"

    const v7, 0x1c0b0dfd

    const/16 v8, 0x1fe

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 890
    :cond_2b5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 891
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 892
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "enter LcdOff Idle mode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 893
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 894
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyIdleSceneEnter(Z)V

    goto/16 :goto_4f1

    .line 869
    :sswitch_2de
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v0, :cond_2ff

    .line 870
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getDeepSleepFreezeWhite()Z

    move-result v0

    if-eqz v0, :cond_2ed

    goto :goto_2ee

    :cond_2ed
    move v2, v3

    :goto_2ee
    move v10, v2

    .line 871
    .local v10, "targetFlags":I
    new-instance v5, Lcom/android/server/hans/scene/HansSceneItem;

    const/16 v8, 0x1fe

    const/16 v9, 0x15

    const-string v6, "deepSleep"

    const v7, 0x40b01e0

    invoke-direct/range {v5 .. v10}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 874
    .end local v10    # "targetFlags":I
    :cond_2ff
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-nez v0, :cond_4f1

    .line 875
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 877
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 878
    invoke-direct {p0, v4}, Lcom/android/server/hans/scene/HansSceneManager;->forceTransAppStateToMInNightDisNetScene(Z)V

    goto/16 :goto_4f1

    .line 1013
    :cond_316
    sparse-switch p1, :sswitch_data_524

    .line 1113
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    goto/16 :goto_4f1

    .line 1110
    :sswitch_333
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->exitMinSystemScene(I)V

    .line 1111
    goto/16 :goto_4f1

    .line 1096
    :sswitch_338
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_363

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_363

    .line 1097
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v2, "SCENE_ID_DP_UID_DISNET_WHEN_SWITCH_CLOSE: exit"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1098
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1100
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 1101
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDSSkipBtUids()V

    .line 1102
    const-string/jumbo v0, "uidDisNetWhenSwitchCloseScene"

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->exitDeepSleep(Ljava/lang/String;)V

    .line 1103
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitDpUidDisNetWhenOptSwitchClose()V

    .line 1105
    :cond_363
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitNightDeepDoze()V

    .line 1106
    goto/16 :goto_4f1

    .line 1084
    :sswitch_368
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    invoke-direct {p0, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addOrRemoveExtensionProxyFlagForAllHansPkg(ZI)V

    .line 1085
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_399

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_399

    .line 1086
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v2, "SCENE_ID_DP_UID_DISNET: exit"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1087
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1089
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 1090
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDSSkipBtUids()V

    .line 1091
    const-string/jumbo v0, "uidDisNet"

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->exitDeepSleep(Ljava/lang/String;)V

    .line 1093
    :cond_399
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitNightDeepDoze()V

    .line 1094
    goto/16 :goto_4f1

    .line 1074
    :sswitch_39e
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4f1

    .line 1075
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1076
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mStrictModeScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 1077
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeWidgetForStrictMode()V

    .line 1078
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "exit strictMode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1079
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    goto/16 :goto_4f1

    .line 1066
    :sswitch_3ca
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4f1

    .line 1067
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCpuHighLoadScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1068
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v2, "exit CpuHighLoad mode"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1069
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 1070
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInCpuHighLoadMode:Z

    goto/16 :goto_4f1

    .line 1015
    :sswitch_3f2
    const-string/jumbo v0, "exit night deep doze mode"

    .line 1016
    .local v0, "nddExitInfo":Ljava/lang/String;
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v2, :cond_4f1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v2, v3}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v2

    if-eqz v2, :cond_4f1

    .line 1017
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mNightDeepDozeScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1018
    iput-boolean v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInNightDeepDoze:Z

    .line 1019
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1020
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 1021
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyNddSceneChange(Z)V

    .line 1022
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v2, :cond_42b

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-nez v2, :cond_42b

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v2, :cond_449

    :cond_42b
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 1023
    invoke-virtual {v2, v3}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v2

    if-eqz v2, :cond_449

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepUidDisNetScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 1024
    invoke-virtual {v2, v3}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v2

    if-eqz v2, :cond_449

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDPUidDisNetWhenSwitchCloseScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 1025
    invoke-virtual {v2, v3}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v2

    if-nez v2, :cond_4f1

    .line 1027
    :cond_449
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    goto/16 :goto_4f1

    .line 1059
    .end local v0    # "nddExitInfo":Ljava/lang/String;
    :sswitch_44e
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4f1

    .line 1060
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAirPlaneScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1061
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v1, "exit air plane mode"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1062
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    goto/16 :goto_4f1

    .line 1051
    :sswitch_474
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4f1

    .line 1052
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1053
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v2, "exit LcdOff deep Idle mode"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1054
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 1055
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyDeepIdleSceneEnter(Z)V

    goto :goto_4f1

    .line 1043
    :sswitch_4a0
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4f1

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4f1

    .line 1044
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mIdleScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1045
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string/jumbo v2, "exit LcdOff Idle mode"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1046
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 1047
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyIdleSceneEnter(Z)V

    goto :goto_4f1

    .line 1032
    :sswitch_4cc
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    if-eqz v0, :cond_4ed

    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/scene/HansSceneCombo;->hasExtension(Lcom/android/server/hans/scene/HansScene;)Z

    move-result v0

    if-eqz v0, :cond_4ed

    .line 1033
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeExtensionScene(Lcom/android/server/hans/scene/HansScene;)V

    .line 1035
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 1036
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDSSkipBtUids()V

    .line 1037
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->forceTransAppStateToMInNightDisNetScene(Z)V

    .line 1038
    const-string v0, "deepSleep"

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->exitDeepSleep(Ljava/lang/String;)V

    .line 1040
    :cond_4ed
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->exitNightDeepDoze()V

    .line 1041
    nop

    .line 1117
    :cond_4f1
    :goto_4f1
    return-void

    :sswitch_data_4f2
    .sparse-switch
        0x1 -> :sswitch_2de
        0x2 -> :sswitch_294
        0x4 -> :sswitch_24b
        0x8 -> :sswitch_20a
        0x10 -> :sswitch_1b6
        0x20 -> :sswitch_168
        0x40 -> :sswitch_b0
        0x80 -> :sswitch_69
        0x100 -> :sswitch_2b
        0x200 -> :sswitch_26
        0x400 -> :sswitch_26
        0x800 -> :sswitch_26
    .end sparse-switch

    :sswitch_data_524
    .sparse-switch
        0x1 -> :sswitch_4cc
        0x2 -> :sswitch_4a0
        0x4 -> :sswitch_474
        0x8 -> :sswitch_44e
        0x10 -> :sswitch_3f2
        0x20 -> :sswitch_3ca
        0x40 -> :sswitch_39e
        0x80 -> :sswitch_368
        0x100 -> :sswitch_338
        0x200 -> :sswitch_333
        0x400 -> :sswitch_333
        0x800 -> :sswitch_333
    .end sparse-switch
.end method

.method public highLoadingFreeze()V
    .registers 1

    .line 4186
    return-void
.end method

.method public inFastFrozenList(I)Z
    .registers 4
    .param p1, "uid"    # I

    .line 1796
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 1798
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerFrozenPkgs:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->contains(I)Z

    move-result v0
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_11

    .line 1800
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1798
    return v0

    .line 1800
    :catchall_11
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 1801
    throw v0
.end method

.method public inThermalImpScene()Z
    .registers 3

    .line 5199
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const v1, 0x7fffffff

    and-int/2addr v0, v1

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method public initBaseSceneCombo(Z)V
    .registers 6
    .param p1, "isBootCompletedDone"    # Z

    .line 430
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->initSystemStatus()V

    .line 431
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    .line 432
    .local v0, "isScreenOn":Z
    if-eqz v0, :cond_16

    .line 433
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    goto :goto_1a

    .line 435
    :cond_16
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    .line 437
    :goto_1a
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "initBaseSceneCombo, hansBootCompleted="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " screenOn="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 439
    return-void
.end method

.method public isActiveUid(I)Z
    .registers 4
    .param p1, "uid"    # I

    .line 463
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 465
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0
    :try_end_f
    .catchall {:try_start_5 .. :try_end_f} :catchall_15

    .line 467
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 465
    return v0

    .line 467
    :catchall_15
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 468
    throw v0
.end method

.method public isFastFreezerOn()Z
    .registers 2

    .line 1792
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerOn:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    return v0
.end method

.method public isFrozen(I)Z
    .registers 5
    .param p1, "uid"    # I

    .line 2668
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2669
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v0, :cond_8

    .line 2670
    const/4 v1, 0x0

    return v1

    .line 2672
    :cond_8
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2673
    :try_start_d
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    monitor-exit v1

    return v2

    .line 2674
    :catchall_13
    move-exception v2

    monitor-exit v1
    :try_end_15
    .catchall {:try_start_d .. :try_end_15} :catchall_13

    throw v2
.end method

.method public isImportantForSceneCombo(Lcom/android/server/hans/OplusHansPackage;Z)Z
    .registers 4
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "checkedQuotaTask"    # Z

    .line 3227
    const-string v0, ""

    invoke-virtual {p0, p1, p2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->isImportantForSceneCombo(Lcom/android/server/hans/OplusHansPackage;ZLjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public isImportantForSceneCombo(Lcom/android/server/hans/OplusHansPackage;ZLjava/lang/String;)Z
    .registers 6
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "checkedQuotaTask"    # Z
    .param p3, "transReason"    # Ljava/lang/String;

    .line 3230
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    .line 3231
    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneCombo;->getImportanceFlags()I

    move-result v1

    .line 3230
    invoke-virtual {v0, p1, v1, p2, p3}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;IZLjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public isInCameraVocalScene()Z
    .registers 3

    .line 4816
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneId()I

    move-result v0

    const/4 v1, 0x4

    if-eq v0, v1, :cond_12

    .line 4817
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneId()I

    move-result v0

    const/16 v1, 0x8

    if-ne v0, v1, :cond_10

    goto :goto_12

    :cond_10
    const/4 v0, 0x0

    goto :goto_13

    :cond_12
    :goto_12
    const/4 v0, 0x1

    .line 4816
    :goto_13
    return v0
.end method

.method public isInCpuHighLoadMode()Z
    .registers 2

    .line 4364
    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInCpuHighLoadMode:Z

    return v0
.end method

.method public isInManagedGrayPkgSet(Ljava/lang/String;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;

    .line 756
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    monitor-enter v0

    .line 757
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedGrayPkgSet:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    monitor-exit v0

    return v1

    .line 758
    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public isInManagedMapWhitelist(I)Z
    .registers 4
    .param p1, "uid"    # I

    .line 747
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 749
    :try_start_5
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_16

    if-eqz v0, :cond_f

    const/4 v0, 0x1

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    .line 751
    :goto_10
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 749
    return v0

    .line 751
    :catchall_16
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 752
    throw v0
.end method

.method public isInMinSystemScene()Z
    .registers 2

    .line 4804
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCurrentMinSystemSceneId:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method

.method public isInThermalMode()Z
    .registers 2

    .line 4571
    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    return v0
.end method

.method public isTcpRetransmissionRestrict(I)Z
    .registers 5
    .param p1, "uid"    # I

    .line 4397
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    monitor-enter v0

    .line 4398
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    monitor-exit v0

    return v1

    .line 4399
    :catchall_f
    move-exception v1

    monitor-exit v0
    :try_end_11
    .catchall {:try_start_3 .. :try_end_11} :catchall_f

    throw v1
.end method

.method public isThermalIgnoreTraffic(I)Z
    .registers 5
    .param p1, "uid"    # I

    .line 4591
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 4592
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->contains(Ljava/lang/Object;)Z

    move-result v1

    monitor-exit v0

    return v1

    .line 4593
    :catchall_f
    move-exception v1

    monitor-exit v0
    :try_end_11
    .catchall {:try_start_3 .. :try_end_11} :catchall_f

    throw v1
.end method

.method public isThermalSkipImpPkg(Lcom/android/server/hans/OplusHansPackage;)Z
    .registers 4
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 5251
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    monitor-enter v0

    .line 5252
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    monitor-exit v0

    return v1

    .line 5253
    :catchall_b
    move-exception v1

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw v1
.end method

.method public killingFrozenApp(I)V
    .registers 11
    .param p1, "uid"    # I

    .line 1746
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 1747
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v1, :cond_b

    .line 1748
    return-void

    .line 1751
    :cond_b
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    .line 1752
    .local v3, "pkgName":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 1754
    :try_start_14
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    if-nez v0, :cond_40

    .line 1755
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "app has been unfrozen, ignore killing "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1756
    monitor-exit v2

    return-void

    .line 1759
    :cond_40
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->isKilledFrozenApp()Z

    move-result v0

    if-nez v0, :cond_6d

    .line 1760
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "kill frozen confing may be updated by rus, ignore killing "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1761
    monitor-exit v2

    return-void

    .line 1763
    :cond_6d
    monitor-exit v2
    :try_end_6e
    .catchall {:try_start_14 .. :try_end_6e} :catchall_b5

    .line 1765
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "kill frozen app "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " due to stay for a long time"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 1767
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {p1}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v4

    .line 1768
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    const-string/jumbo v7, "frozen app stay for a long time"

    .line 1767
    const/16 v5, 0xd

    const/16 v6, 0xbb8

    const/4 v8, 0x0

    invoke-interface/range {v2 .. v8}, Lcom/android/server/am/IOplusAthenaAmManager;->forceStopPackage(Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;)V

    .line 1770
    return-void

    .line 1763
    :catchall_b5
    move-exception v0

    :try_start_b6
    monitor-exit v2
    :try_end_b7
    .catchall {:try_start_b6 .. :try_end_b7} :catchall_b5

    throw v0
.end method

.method public matchTargetFlags(I)Z
    .registers 3
    .param p1, "targetId"    # I

    .line 4403
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v0

    and-int/2addr v0, p1

    if-eqz v0, :cond_b

    const/4 v0, 0x1

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    return v0
.end method

.method public noteAirplane(Z)V
    .registers 3
    .param p1, "isAirplane"    # Z

    .line 4672
    const/16 v0, 0x8

    invoke-virtual {p0, v0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 4673
    return-void
.end method

.method public noteBatteryCoolChargeModeChanged(Z)V
    .registers 2
    .param p1, "enter"    # Z

    .line 4697
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayIfSceneChanged(Z)V

    .line 4698
    return-void
.end method

.method public noteCharging(Z)V
    .registers 5
    .param p1, "isCharging"    # Z

    .line 4623
    if-eqz p1, :cond_14

    .line 4624
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    const-wide/16 v1, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/OplusHansManager;->sendChangedForSysBlackOrGrayMsg(J)V

    .line 4625
    invoke-static {}, Lcom/android/server/hans/app/KeyProcRecognize;->getInstance()Lcom/android/server/hans/app/KeyProcRecognize;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/app/KeyProcRecognize;->handlePowerConnected(Z)V

    goto :goto_23

    .line 4627
    :cond_14
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    .line 4628
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getLcdOffFastFreezeCheckTime()J

    move-result-wide v1

    .line 4627
    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/OplusHansManager;->sendChangedForSysBlackOrGrayMsg(J)V

    .line 4630
    :goto_23
    return-void
.end method

.method public noteDateChange()V
    .registers 1

    .line 4617
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->uploadHistory()V

    .line 4618
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateHansWLByAppUsage()V

    .line 4619
    return-void
.end method

.method public noteDeepSleepEndTime(J)V
    .registers 3
    .param p1, "endTime"    # J

    .line 4644
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->setDeepSleepPredictEndTimeMs(J)V

    .line 4645
    return-void
.end method

.method public noteDeepSleepNetStates(ZZZ)V
    .registers 5
    .param p1, "netStateBefore"    # Z
    .param p2, "curNetState"    # Z
    .param p3, "isDeepSleep"    # Z

    .line 4634
    const/4 v0, 0x1

    invoke-virtual {p0, v0, p3}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 4635
    return-void
.end method

.method public noteDeepSleepStartTime(J)V
    .registers 3
    .param p1, "startTime"    # J

    .line 4639
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->setDeepSleepPredictStartTimeMs(J)V

    .line 4640
    return-void
.end method

.method public noteDeepSleepUidDisconnectNet(Z)V
    .registers 3
    .param p1, "disNetEnable"    # Z

    .line 4649
    const/16 v0, 0x80

    invoke-virtual {p0, v0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 4650
    return-void
.end method

.method public noteDoze(Z)V
    .registers 4
    .param p1, "isDozeMode"    # Z

    .line 4682
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->changeNightDeepDoze(Z)V

    .line 4683
    if-nez p1, :cond_f

    .line 4684
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda6;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->post(Ljava/lang/Runnable;)Z

    .line 4686
    :cond_f
    return-void
.end method

.method public noteDsOrUidDisStatusWhenSwitchClose(Z)V
    .registers 3
    .param p1, "enter"    # Z

    .line 4654
    const/16 v0, 0x100

    invoke-virtual {p0, v0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 4655
    return-void
.end method

.method public noteFloatWindow(Ljava/util/ArrayList;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 4706
    .local p1, "floatPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    const/4 v0, 0x0

    .line 4707
    .local v0, "enter":Z
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 4708
    .local v1, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1e

    .line 4709
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 4710
    .local v2, "pkgName":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansDBConfig;->inThermalSmallWindowPkgList(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1d

    .line 4711
    const/4 v0, 0x1

    .line 4712
    goto :goto_1e

    .line 4714
    .end local v2    # "pkgName":Ljava/lang/String;
    :cond_1d
    goto :goto_5

    .line 4715
    :cond_1e
    :goto_1e
    const/4 v2, 0x4

    invoke-virtual {p0, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalImpScene(IZ)V

    .line 4716
    return-void
.end method

.method public noteGmsRestrictUpdated(ZI)V
    .registers 3
    .param p1, "isGmsRestricted"    # Z
    .param p2, "userId"    # I

    .line 4677
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->updateGmsRestrictPkg(ZI)V

    .line 4678
    return-void
.end method

.method public noteMediaMuteState(Z)V
    .registers 2
    .param p1, "muteState"    # Z

    .line 4916
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->notifyMediaMuteState(Z)V

    .line 4917
    return-void
.end method

.method public noteMinSystemSceneChanged(IZ)V
    .registers 11
    .param p1, "sceneId"    # I
    .param p2, "enter"    # Z

    .line 4787
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x25

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 4788
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4790
    :cond_f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const-wide/16 v6, 0x0

    const/16 v3, 0x25

    move v4, p1

    .end local p1    # "sceneId":I
    .local v4, "sceneId":I
    invoke-static/range {v2 .. v7}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/Object;J)V

    .line 4791
    return-void
.end method

.method public noteMinSystemSceneChanged(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 12
    .param p1, "scene"    # Ljava/lang/String;
    .param p2, "sceneMode"    # Ljava/lang/String;
    .param p3, "enter"    # Z

    .line 4794
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x25

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 4795
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 4797
    :cond_f
    if-eqz p3, :cond_13

    .line 4798
    iput-object p2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSetCameraMinSysSubScene:Ljava/lang/String;

    .line 4800
    :cond_13
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const-wide/16 v6, 0x0

    const/16 v3, 0x25

    const/16 v4, 0x400

    invoke-static/range {v2 .. v7}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/Object;J)V

    .line 4801
    return-void
.end method

.method public notePowerSave(Z)V
    .registers 2
    .param p1, "isPowerSaveMode"    # Z

    .line 4690
    if-nez p1, :cond_5

    .line 4691
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeProxyAlarmSetAsync()V

    .line 4693
    :cond_5
    return-void
.end method

.method public noteSecondDisplayStateChanged(I)V
    .registers 7
    .param p1, "scrState"    # I

    .line 2179
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x21

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 2180
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 2182
    :cond_f
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "secondDisplayStateChanged "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 2183
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "secondDisplayState "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 2184
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v0

    .line 2185
    .local v0, "curResumedUid":I
    if-nez p1, :cond_5d

    .line 2186
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v3, v1, v0, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v1

    const-wide/16 v3, 0x1388

    invoke-virtual {v2, v1, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_68

    .line 2187
    :cond_5d
    const/4 v1, 0x1

    if-ne p1, v1, :cond_68

    .line 2188
    const-string v1, "TopActivity"

    const-string/jumbo v2, "secondDisplay"

    invoke-virtual {p0, v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 2190
    :cond_68
    :goto_68
    return-void
.end method

.method public noteSplitWindow(Ljava/util/ArrayList;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 4720
    .local p1, "splitPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    const/4 v0, 0x0

    .line 4721
    .local v0, "enter":Z
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-le v1, v2, :cond_25

    .line 4722
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 4723
    .local v1, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    :goto_c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_25

    .line 4724
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 4725
    .local v2, "pkgName":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/server/hans/OplusHansDBConfig;->inThermalSmallWindowPkgList(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_24

    .line 4726
    const/4 v0, 0x1

    .line 4727
    goto :goto_25

    .line 4729
    .end local v2    # "pkgName":Ljava/lang/String;
    :cond_24
    goto :goto_c

    .line 4731
    .end local v1    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    :cond_25
    :goto_25
    const/16 v1, 0x8

    invoke-virtual {p0, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalImpScene(IZ)V

    .line 4732
    return-void
.end method

.method public noteThermalLevel(II)V
    .registers 5
    .param p1, "thermalLevel"    # I
    .param p2, "temperature"    # I

    .line 4659
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->updateThermalLevel(I)Z

    move-result v0

    if-eqz v0, :cond_40

    .line 4660
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "update ThermalMode:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInThermalMode()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", level:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "#"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 4661
    .local v0, "logInfo":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 4662
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 4664
    .end local v0    # "logInfo":Ljava/lang/String;
    :cond_40
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isChinaMode()Z

    move-result v0

    if-eqz v0, :cond_57

    .line 4665
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalGuardEnable()Z

    move-result v0

    if-eqz v0, :cond_57

    .line 4666
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalLevel(I)V

    .line 4668
    :cond_57
    return-void
.end method

.method public noteThermalMngLevelChange(I)V
    .registers 2
    .param p1, "mngLevel"    # I

    .line 4702
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalMngLevel(I)V

    .line 4703
    return-void
.end method

.method public notifyAppGoBackground(I)V
    .registers 3
    .param p1, "uid"    # I

    .line 2146
    const-string v0, ""

    invoke-virtual {p0, p1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifyAppGoBackground(ILjava/lang/String;)V

    .line 2147
    return-void
.end method

.method public notifyAppGoBackground(ILjava/lang/String;)V
    .registers 7
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;

    .line 2150
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_21

    .line 2151
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "notifyAppGoBackground, uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 2153
    :cond_21
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, p1, v1}, Lcom/android/server/am/OplusHansManager;->setTaskAffinityPackage(ZII)V

    .line 2155
    invoke-static {}, Lcom/android/server/cpulimit/OplusCpuFeature;->getInstance()Lcom/android/server/cpulimit/OplusCpuFeature;

    move-result-object v0

    invoke-virtual {v0, v2, p1, p2, v2}, Lcom/android/server/cpulimit/OplusCpuFeature;->appSwitchEventToCLU(ZILjava/lang/String;Z)V

    .line 2156
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 2158
    :try_start_36
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0
    :try_end_40
    .catchall {:try_start_36 .. :try_end_40} :catchall_77

    if-nez v0, :cond_48

    .line 2162
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2159
    return-void

    .line 2162
    :cond_48
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2163
    nop

    .line 2165
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2166
    .local v0, "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_69

    .line 2167
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2168
    :try_start_5d
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 2169
    monitor-exit v1

    goto :goto_69

    :catchall_66
    move-exception v2

    monitor-exit v1
    :try_end_68
    .catchall {:try_start_5d .. :try_end_68} :catchall_66

    throw v2

    .line 2172
    :cond_69
    :goto_69
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 2173
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_76

    .line 2174
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->enter()V

    .line 2176
    :cond_76
    return-void

    .line 2162
    .end local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_77
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 2163
    throw v0
.end method

.method public notifyAppGoForeground(ILjava/lang/String;)V
    .registers 15
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;

    .line 2113
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_21

    .line 2114
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "notifyAppGoForeground, uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 2117
    :cond_21
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2118
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_4a

    .line 2119
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v1

    const-string v2, "TopActivity"

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V

    .line 2121
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    const-string v2, "TopActivity"

    invoke-virtual {v1, v0, v2}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleAllow(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 2122
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2123
    :try_start_42
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->resetStateWhenFg()V

    .line 2124
    monitor-exit v1

    goto :goto_4a

    :catchall_47
    move-exception v2

    monitor-exit v1
    :try_end_49
    .catchall {:try_start_42 .. :try_end_49} :catchall_47

    throw v2

    .line 2126
    :cond_4a
    :goto_4a
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 2127
    .local v1, "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_8d

    .line 2128
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 2129
    :try_start_59
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-lez v3, :cond_7b

    .line 2130
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v10

    sub-long/2addr v8, v10

    invoke-virtual {v3, v4, v7, v8, v9}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyLiveTime(ILjava/lang/String;J)V

    .line 2132
    :cond_7b
    invoke-virtual {v1, v5, v6}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 2133
    monitor-exit v2
    :try_end_7f
    .catchall {:try_start_59 .. :try_end_7f} :catchall_8a

    .line 2134
    invoke-virtual {v1, v5, v6}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 2135
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setEnterFGTime(J)V

    goto :goto_8d

    .line 2133
    :catchall_8a
    move-exception v3

    :try_start_8b
    monitor-exit v2
    :try_end_8c
    .catchall {:try_start_8b .. :try_end_8c} :catchall_8a

    throw v3

    .line 2137
    :cond_8d
    :goto_8d
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, p1}, Lcom/android/server/am/OplusHansManager;->removeAudioSilenceInfo(I)V

    .line 2138
    invoke-static {}, Lcom/android/server/hans/OplusHansFreezeManagerService;->getInstance()Lcom/android/server/hans/OplusHansFreezeManagerService;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, Lcom/android/server/hans/OplusHansFreezeManagerService;->onUidHansStateChanged(Lcom/android/server/hans/OplusHansPackage;Z)V

    .line 2139
    invoke-static {}, Lcom/android/server/hans/revival/AppRevivalManager;->getInstance()Lcom/android/server/hans/revival/AppRevivalManager;

    move-result-object v2

    invoke-virtual {v2, p1}, Lcom/android/server/hans/revival/AppRevivalManager;->noteAppForeground(I)V

    .line 2142
    invoke-static {}, Lcom/android/server/cpulimit/OplusCpuFeature;->getInstance()Lcom/android/server/cpulimit/OplusCpuFeature;

    move-result-object v2

    const/4 v4, 0x1

    invoke-virtual {v2, v4, p1, p2, v3}, Lcom/android/server/cpulimit/OplusCpuFeature;->appSwitchEventToCLU(ZILjava/lang/String;Z)V

    .line 2143
    return-void
.end method

.method public notifyAppResQuota(ILjava/lang/String;)V
    .registers 4
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;

    .line 4782
    invoke-static {}, Lcom/android/server/hans/tarq/AppResQuotaManager;->getInstance()Lcom/android/server/hans/tarq/AppResQuotaManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/hans/tarq/AppResQuotaManager;->startCalcQuotaTime(ILjava/lang/String;)Z

    .line 4783
    invoke-static {}, Lcom/android/server/hans/OplusHansFreezeManagerService;->getInstance()Lcom/android/server/hans/OplusHansFreezeManagerService;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansFreezeManagerService;->notifySendingTransientTaskTimeoutMessage(I)V

    .line 4784
    return-void
.end method

.method public notifyBioUnlock()V
    .registers 2

    .line 2225
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->notifyBioUnlock()V

    .line 2226
    return-void
.end method

.method public notifyMediaMuteState(Z)V
    .registers 8
    .param p1, "muteState"    # Z

    .line 4920
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isAudioMediaMuteEnable()Z

    move-result v0

    if-eqz v0, :cond_3a

    if-nez p1, :cond_3a

    .line 4921
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getMutePlayerSet()Landroid/util/ArraySet;

    move-result-object v0

    .line 4922
    .local v0, "mutePlayerSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    invoke-virtual {v0}, Landroid/util/ArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_14
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_37

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 4923
    .local v2, "uid":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const-string v4, "MediaUnmute"

    const-string v5, ""

    invoke-virtual {p0, v3, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 4925
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v3, v4}, Lcom/android/server/am/OplusHansManager;->notifyRemoveAudioFrozen(I)V

    .line 4926
    .end local v2    # "uid":Ljava/lang/Integer;
    goto :goto_14

    .line 4927
    :cond_37
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->clearMutePlayerSet()V

    .line 4929
    .end local v0    # "mutePlayerSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    :cond_3a
    return-void
.end method

.method public onHansDisabled()V
    .registers 3

    .line 3219
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SceneManager hans disabled"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3220
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessage(I)Z

    .line 3221
    return-void
.end method

.method public onInit(Lcom/android/server/am/OplusHansManager;Landroid/content/Context;)V
    .registers 12
    .param p1, "hansManage"    # Lcom/android/server/am/OplusHansManager;
    .param p2, "context"    # Landroid/content/Context;

    .line 396
    iput-object p2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mContext:Landroid/content/Context;

    .line 397
    invoke-static {}, Lcom/android/server/hans/freeze/HansCGroup;->getInstance()Lcom/android/server/hans/freeze/HansCGroup;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    .line 400
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->registerUidObserver()V

    .line 401
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->initRunningUidSet()V

    .line 403
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateManagedMap()V

    .line 405
    new-instance v1, Lcom/android/server/hans/scene/HansSceneItem;

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, "LcdOn"

    const v3, 0x1d6fbfff

    const/16 v4, 0x1fe

    invoke-direct/range {v1 .. v6}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 407
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isExpRegion()Z

    move-result v0

    if-eqz v0, :cond_34

    .line 408
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnScene:Lcom/android/server/hans/scene/HansSceneItem;

    iget v1, v0, Lcom/android/server/hans/scene/HansSceneItem;->mImportanceFlags:I

    const/high16 v2, 0x100000

    or-int/2addr v1, v2

    iput v1, v0, Lcom/android/server/hans/scene/HansSceneItem;->mImportanceFlags:I

    .line 410
    :cond_34
    new-instance v2, Lcom/android/server/hans/scene/HansSceneItem;

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v3, "LcdOff"

    const v4, 0x1c0b0dfd

    const/16 v5, 0x1fe

    invoke-direct/range {v2 .. v7}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 412
    new-instance v3, Lcom/android/server/hans/scene/HansSceneItem;

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v4, "FastFreezer"

    const v5, 0x2eebfffe

    const/16 v6, 0xfe

    invoke-direct/range {v3 .. v8}, Lcom/android/server/hans/scene/HansSceneItem;-><init>(Ljava/lang/String;IIII)V

    iput-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mFastFreezerScene:Lcom/android/server/hans/scene/HansSceneItem;

    .line 414
    new-instance v0, Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;-><init>(Lcom/android/server/hans/scene/HansScene;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    .line 415
    new-instance v0, Lcom/android/server/hans/scene/HansSceneCombo;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffScene:Lcom/android/server/hans/scene/HansSceneItem;

    invoke-direct {v0, v1}, Lcom/android/server/hans/scene/HansSceneCombo;-><init>(Lcom/android/server/hans/scene/HansScene;)V

    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOffSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    .line 416
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->initBaseSceneCombo(Z)V

    .line 417
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, p0, v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->registerCallback(Lcom/android/server/hans/scene/IOplusBgSceneCallback;Landroid/os/Handler;)V

    .line 419
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    new-instance v1, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    invoke-direct {v1}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;-><init>()V

    .line 420
    const/16 v2, 0x3e8

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setCallingUid(I)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    .line 421
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setCallingPid(I)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    .line 422
    const-string v2, "HansMainHandler"

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setThreadName(Ljava/lang/String;)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    .line 423
    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->getThreadId()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setTid(I)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    .line 424
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setPid(I)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    .line 425
    const/16 v2, 0x3ee

    invoke-virtual {v1, v2}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->setEventId(I)Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;

    move-result-object v1

    .line 426
    invoke-virtual {v1}, Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams$Builder;->build()Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams;

    move-result-object v1

    .line 419
    invoke-virtual {v0, v1}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->reportKeyThread(Lcom/android/server/oplus/osense/feature/uaf/param/ReportParams;)Z

    .line 427
    return-void
.end method

.method public postFreezeCheck(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 5
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 4123
    if-nez p1, :cond_3

    .line 4124
    return-void

    .line 4131
    :cond_3
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->checkTransBinder(Lcom/android/server/hans/OplusHansPackage;)V

    .line 4132
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, 0x5

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2, v2, p1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 4133
    return-void
.end method

.method public postHighload(ZLandroid/util/ArrayMap;)V
    .registers 6
    .param p1, "state"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Landroid/util/ArrayMap<",
            "Ljava/lang/String;",
            "Landroid/util/SparseArray<",
            "Landroid/util/ArraySet<",
            "Ljava/lang/Integer;",
            ">;>;>;)V"
        }
    .end annotation

    .line 4267
    .local p2, "uidMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_2b

    .line 4268
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "handleHighload state: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " map: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 4270
    :cond_2b
    if-eqz p1, :cond_56

    .line 4271
    if-eqz p2, :cond_59

    invoke-virtual {p2}, Landroid/util/ArrayMap;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_59

    .line 4272
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInHighloadFreezing:Z

    .line 4273
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isCpuHighLoadFreezeEnable()Z

    move-result v0

    if-eqz v0, :cond_59

    .line 4274
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    .line 4275
    .local v0, "tmpMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    invoke-virtual {v0, p2}, Landroid/util/ArrayMap;->putAll(Landroid/util/ArrayMap;)V

    .line 4276
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v2, 0x12

    invoke-virtual {v1, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Message;->sendToTarget()V

    .line 4277
    .end local v0    # "tmpMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    goto :goto_59

    .line 4280
    :cond_56
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInHighloadFreezing:Z

    .line 4283
    :cond_59
    :goto_59
    return-void
.end method

.method public postSetFirewallDeny(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 7
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 4171
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x6

    const/4 v4, -0x1

    invoke-virtual {v0, v3, v1, v4, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 4172
    .local v0, "msg":Landroid/os/Message;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const-wide/16 v2, 0xbb8

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 4173
    return-void
.end method

.method public postSetFirewallDenyNow(I)V
    .registers 6
    .param p1, "uid"    # I

    .line 4176
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/4 v1, -0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x6

    invoke-virtual {v0, v3, p1, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 4177
    .local v0, "msg":Landroid/os/Message;
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(Landroid/os/Message;)Z

    .line 4178
    return-void
.end method

.method public recordContinuousTaskMaxDurationCancelTime(I)V
    .registers 8
    .param p1, "uid"    # I

    .line 4756
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackApp(I)Z

    move-result v0

    if-eqz v0, :cond_50

    .line 4757
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 4758
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_50

    .line 4759
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    .line 4760
    .local v1, "nowTime":J
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4761
    :try_start_1d
    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/OplusHansPackage;->setContinuousTaskCancelTimeInMaxDuration(J)V

    .line 4762
    monitor-exit v3
    :try_end_21
    .catchall {:try_start_1d .. :try_end_21} :catchall_4d

    .line 4763
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_50

    .line 4764
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "uid: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " continuous tasks cancel time(exceed max duration): "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    goto :goto_50

    .line 4762
    :catchall_4d
    move-exception v4

    :try_start_4e
    monitor-exit v3
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    throw v4

    .line 4769
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v1    # "nowTime":J
    :cond_50
    :goto_50
    return-void
.end method

.method public recordQuotaTaskStatus(I)V
    .registers 7
    .param p1, "uid"    # I

    .line 4738
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackApp(I)Z

    move-result v0

    if-eqz v0, :cond_58

    .line 4739
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 4740
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_58

    .line 4741
    invoke-static {}, Lcom/android/server/hans/tarq/AppResQuotaManager;->getInstance()Lcom/android/server/hans/tarq/AppResQuotaManager;

    move-result-object v1

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, p1, v2}, Lcom/android/server/hans/tarq/AppResQuotaManager;->getTaskStatus(ILjava/lang/String;)I

    move-result v1

    .line 4742
    .local v1, "taskStatus":I
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 4743
    :try_start_25
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setQuotaTaskStatus(I)V

    .line 4744
    monitor-exit v2
    :try_end_29
    .catchall {:try_start_25 .. :try_end_29} :catchall_55

    .line 4745
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_58

    .line 4746
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uid: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " taskStatus: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    goto :goto_58

    .line 4744
    :catchall_55
    move-exception v3

    :try_start_56
    monitor-exit v2
    :try_end_57
    .catchall {:try_start_56 .. :try_end_57} :catchall_55

    throw v3

    .line 4750
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v1    # "taskStatus":I
    :cond_58
    :goto_58
    return-void
.end method

.method public removeAllInvalidHansWlUid()V
    .registers 3

    .line 4411
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    if-eqz v0, :cond_e

    .line 4412
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda10;

    invoke-direct {v1, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda10;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->post(Ljava/lang/Runnable;)Z

    .line 4421
    :cond_e
    return-void
.end method

.method public removeAllSmMessages(Ljava/lang/String;)V
    .registers 8
    .param p1, "reason"    # Ljava/lang/String;

    .line 3166
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 3169
    const/4 v0, 0x1

    .local v0, "target":I
    :goto_6
    const/16 v1, 0x8

    if-ge v0, v1, :cond_45

    .line 3170
    const/4 v1, 0x0

    .line 3172
    .local v1, "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    packed-switch v0, :pswitch_data_4c

    :pswitch_e
    goto :goto_1d

    .line 3180
    :pswitch_f
    :try_start_f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3181
    goto :goto_1d

    .line 3177
    :pswitch_13
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3178
    goto :goto_1d

    .line 3174
    :pswitch_17
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3175
    goto :goto_1d

    .line 3197
    .end local v0    # "target":I
    .end local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_1b
    move-exception v0

    goto :goto_3c

    .line 3186
    .restart local v0    # "target":I
    .restart local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_1d
    if-eqz v1, :cond_42

    .line 3187
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_20
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_42

    .line 3188
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    .line 3189
    .local v3, "uid":I
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 3190
    .local v4, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_39

    .line 3191
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v5

    invoke-virtual {v5, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->exitSmFirstly(Ljava/lang/String;)V
    :try_end_39
    .catchall {:try_start_f .. :try_end_39} :catchall_1b

    .line 3187
    .end local v3    # "uid":I
    .end local v4    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_39
    add-int/lit8 v2, v2, 0x1

    goto :goto_20

    .line 3197
    .end local v0    # "target":I
    .end local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v2    # "i":I
    :goto_3c
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3198
    throw v0

    .line 3169
    .restart local v0    # "target":I
    :cond_42
    shl-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 3197
    .end local v0    # "target":I
    :cond_45
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3198
    nop

    .line 3199
    return-void

    :pswitch_data_4c
    .packed-switch 0x1
        :pswitch_17
        :pswitch_13
        :pswitch_e
        :pswitch_f
    .end packed-switch
.end method

.method public removeAllTcpUnfreezeMsg(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 2920
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x1e

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeEqualMessages(ILjava/lang/Object;)V

    .line 2921
    return-void
.end method

.method public removeFgFlag(Z)V
    .registers 3
    .param p1, "remove"    # Z

    .line 4190
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    if-eqz v0, :cond_9

    .line 4191
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mLcdOnSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->removeFgFlag(Z)V

    .line 4193
    :cond_9
    return-void
.end method

.method public removeFromManagedMap(II)V
    .registers 11
    .param p1, "uid"    # I
    .param p2, "targetFlags"    # I

    .line 582
    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->setDualAppsExistForAlignment(ILjava/lang/String;Z)V

    .line 583
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "removeFromManagedMap(), uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", targetFlags="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", mSceneCombo.getTargetFlags()="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v3}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 585
    const/4 v0, 0x0

    .line 586
    .local v0, "removeProxyBinder":Z
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 588
    const/4 v2, 0x1

    .local v2, "targetId":I
    :goto_41
    const/16 v3, 0x8

    if-ge v2, v3, :cond_104

    .line 589
    const/4 v3, 0x0

    .line 590
    .local v3, "targetMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    and-int v4, p2, v2

    const-string/jumbo v5, "uid="

    packed-switch v4, :pswitch_data_114

    :pswitch_4e
    goto :goto_a8

    .line 610
    :pswitch_4f
    :try_start_4f
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v3, v4

    .line 611
    goto :goto_a8

    .line 596
    :pswitch_53
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v3, v4

    .line 597
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v4, p1}, Landroid/util/SparseArray;->contains(I)Z

    move-result v4

    if-eqz v4, :cond_93

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v4, p1}, Landroid/util/SparseArray;->contains(I)Z

    move-result v4

    if-eqz v4, :cond_93

    .line 598
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v4

    if-eqz v4, :cond_8a

    .line 599
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " not in whitelist, removed from thirdlist."

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 601
    :cond_8a
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v3, v4

    .line 602
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v4, p1}, Landroid/util/SparseArray;->remove(I)V

    goto :goto_a8

    .line 604
    :cond_93
    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 606
    .local v4, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    invoke-virtual {v6, v4, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->uploadThirdWhiteAppStateEvent(Lcom/android/server/hans/OplusHansPackage;I)V

    .line 608
    .end local v4    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_a8

    .line 592
    :pswitch_a1
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v3, v4

    .line 593
    const/4 v0, 0x1

    .line 594
    goto :goto_a8

    .line 629
    .end local v2    # "targetId":I
    .end local v3    # "targetMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_a6
    move-exception v1

    goto :goto_fa

    .line 616
    .restart local v2    # "targetId":I
    .restart local v3    # "targetMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_a8
    if-eqz v3, :cond_100

    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->contains(I)Z

    move-result v4

    if-eqz v4, :cond_100

    .line 617
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v4

    and-int/2addr v4, v2

    if-eqz v4, :cond_d4

    .line 618
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    const-string/jumbo v6, "targetId is in SceneCombo\'s managed map, exit SM"

    invoke-virtual {v4, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 619
    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 620
    .local v4, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_d4

    .line 621
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v6

    const-string v7, "RemovedFromTargetMap"

    invoke-virtual {v6, v7}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V

    .line 624
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_d4
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " to be removed from targetId="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 625
    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->remove(I)V
    :try_end_f9
    .catchall {:try_start_4f .. :try_end_f9} :catchall_a6

    goto :goto_100

    .line 629
    .end local v2    # "targetId":I
    .end local v3    # "targetMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_fa
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 630
    throw v1

    .line 588
    .restart local v2    # "targetId":I
    :cond_100
    :goto_100
    shl-int/lit8 v2, v2, 0x1

    goto/16 :goto_41

    .line 629
    .end local v2    # "targetId":I
    :cond_104
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 630
    nop

    .line 631
    if-eqz v0, :cond_113

    .line 632
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Lcom/android/server/am/OplusHansManager;->removeProxyBinderByUid(I)V

    .line 634
    :cond_113
    return-void

    :pswitch_data_114
    .packed-switch 0x1
        :pswitch_a1
        :pswitch_53
        :pswitch_4e
        :pswitch_4f
    .end packed-switch
.end method

.method public removeInvalidHansWlUid(I)V
    .registers 3
    .param p1, "uid"    # I

    .line 4424
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->remove(I)V

    .line 4425
    return-void
.end method

.method public removeThermalIgnoreTraffic(I)V
    .registers 5
    .param p1, "uid"    # I

    .line 4583
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInThermalMode()Z

    move-result v0

    if-eqz v0, :cond_17

    .line 4584
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v0

    .line 4585
    :try_start_9
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/util/ArraySet;->remove(Ljava/lang/Object;)Z

    .line 4586
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_9 .. :try_end_16} :catchall_14

    throw v1

    .line 4588
    :cond_17
    :goto_17
    return-void
.end method

.method public removeThermalSkipImpPkg(Lcom/android/server/hans/OplusHansPackage;)V
    .registers 7
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;

    .line 5241
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    monitor-enter v0

    .line 5242
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalSkipImpPkgs:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    .line 5243
    .local v1, "remove":Ljava/lang/Integer;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_48

    .line 5244
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "mThermalSkipImpPkgs remove: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 5245
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", result: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 5244
    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 5247
    .end local v1    # "remove":Ljava/lang/Integer;
    :cond_48
    monitor-exit v0

    .line 5248
    return-void

    .line 5247
    :catchall_4a
    move-exception v1

    monitor-exit v0
    :try_end_4c
    .catchall {:try_start_3 .. :try_end_4c} :catchall_4a

    throw v1
.end method

.method public removedUidFromWhitelistByUsage(ZI)V
    .registers 8
    .param p1, "isRemove"    # Z
    .param p2, "uid"    # I

    .line 4498
    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eqz p1, :cond_58

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, p2}, Landroid/util/SparseArray;->contains(I)Z

    move-result v2

    if-nez v2, :cond_58

    .line 4500
    invoke-virtual {p0, p2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 4501
    .local v2, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v2, :cond_3a

    .line 4502
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_39

    .line 4503
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " hansPkg is null."

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4505
    :cond_39
    return-void

    .line 4507
    :cond_3a
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 4509
    :try_start_3f
    invoke-virtual {p0, p2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 4510
    invoke-virtual {p0, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V
    :try_end_45
    .catchall {:try_start_3f .. :try_end_45} :catchall_51

    .line 4512
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 4513
    nop

    .line 4514
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0, p2, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto :goto_c3

    .line 4512
    .restart local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_51
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 4513
    throw v0

    .line 4515
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_58
    if-nez p1, :cond_c3

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, p2}, Landroid/util/SparseArray;->contains(I)Z

    move-result v2

    if-eqz v2, :cond_c3

    .line 4517
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, p2}, Landroid/util/SparseArray;->remove(I)V

    .line 4518
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2, p2}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 4519
    .restart local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v2, :cond_99

    .line 4520
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_98

    .line 4521
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " hansPkg is null."

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 4523
    :cond_98
    return-void

    .line 4526
    :cond_99
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 4527
    :try_start_9e
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v4

    .line 4528
    .local v4, "appClass":I
    monitor-exit v3
    :try_end_a3
    .catchall {:try_start_9e .. :try_end_a3} :catchall_c0

    .line 4529
    if-eq v4, v1, :cond_a8

    const/4 v3, 0x4

    if-ne v4, v3, :cond_c4

    .line 4531
    :cond_a8
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 4533
    :try_start_ad
    invoke-virtual {p0, p2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 4534
    invoke-virtual {p0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V
    :try_end_b3
    .catchall {:try_start_ad .. :try_end_b3} :catchall_b9

    .line 4536
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 4537
    goto :goto_c4

    .line 4536
    :catchall_b9
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 4537
    throw v0

    .line 4528
    .end local v4    # "appClass":I
    :catchall_c0
    move-exception v0

    :try_start_c1
    monitor-exit v3
    :try_end_c2
    .catchall {:try_start_c1 .. :try_end_c2} :catchall_c0

    throw v0

    .line 4515
    .end local v2    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_c3
    :goto_c3
    nop

    .line 4540
    :cond_c4
    :goto_c4
    return-void
.end method

.method public report(IILjava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "status"    # I
    .param p2, "pid"    # I
    .param p3, "installStage"    # Ljava/lang/String;
    .param p4, "reason"    # Ljava/lang/String;

    .line 2212
    invoke-static {}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->getInstance()Lcom/android/server/hans/nativefreeze/NativeFreezeManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/android/server/hans/nativefreeze/NativeFreezeManager;->setDex2oatInfo(IILjava/lang/String;Ljava/lang/String;)V

    .line 2213
    return-void
.end method

.method public resetAppsNetState()V
    .registers 3

    .line 4200
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0x18

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 4201
    return-void
.end method

.method public resetManagedMapByUid(II)V
    .registers 6
    .param p1, "uid"    # I
    .param p2, "sourceMapFlag"    # I

    .line 1178
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 1180
    :try_start_5
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 1181
    .local v0, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 1182
    if-eqz v0, :cond_27

    .line 1184
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1
    :try_end_17
    .catchall {:try_start_5 .. :try_end_17} :catchall_2e

    .line 1185
    :try_start_17
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v2

    .line 1186
    .local v2, "appClass":I
    monitor-exit v1
    :try_end_1c
    .catchall {:try_start_17 .. :try_end_1c} :catchall_24

    .line 1187
    :try_start_1c
    invoke-virtual {p0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->getTargetFlagByAppClass(I)I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V
    :try_end_23
    .catchall {:try_start_1c .. :try_end_23} :catchall_2e

    goto :goto_27

    .line 1186
    .end local v2    # "appClass":I
    :catchall_24
    move-exception v2

    :try_start_25
    monitor-exit v1
    :try_end_26
    .catchall {:try_start_25 .. :try_end_26} :catchall_24

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "uid":I
    .end local p2    # "sourceMapFlag":I
    :try_start_26
    throw v2
    :try_end_27
    .catchall {:try_start_26 .. :try_end_27} :catchall_2e

    .line 1190
    .end local v0    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "uid":I
    .restart local p2    # "sourceMapFlag":I
    :cond_27
    :goto_27
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1191
    nop

    .line 1192
    return-void

    .line 1190
    :catchall_2e
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1191
    throw v0
.end method

.method public restrictAppWhenTcpRetransmission(Lcom/android/server/hans/OplusHansPackage;J)V
    .registers 9
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "delayTimeMs"    # J

    .line 2894
    if-nez p1, :cond_3

    .line 2895
    return-void

    .line 2897
    :cond_3
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_6d

    .line 2898
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    monitor-enter v0

    .line 2899
    :try_start_10
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 2900
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_10 .. :try_end_1e} :catchall_6a

    .line 2902
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2903
    :try_start_23
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    if-nez v0, :cond_3e

    .line 2904
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->removeAllTcpUnfreezeMsg(I)V

    .line 2905
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyLcdOffAlarm(I)V

    .line 2906
    const/16 v0, 0x1e

    .local v0, "msgCode":I
    goto :goto_47

    .line 2908
    .end local v0    # "msgCode":I
    :cond_3e
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->postSetFirewallDenyNow(I)V

    .line 2909
    const/16 v0, 0x1f

    .line 2911
    .restart local v0    # "msgCode":I
    :goto_47
    monitor-exit v1
    :try_end_48
    .catchall {:try_start_23 .. :try_end_48} :catchall_67

    .line 2912
    const-wide/16 v1, 0x0

    cmp-long v1, p2, v1

    if-lez v1, :cond_6d

    .line 2913
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, -0x1

    invoke-virtual {v1, v0, v2, v4, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    .line 2914
    .local v1, "msg":Landroid/os/Message;
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v2, v1, p2, p3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_6d

    .line 2911
    .end local v0    # "msgCode":I
    .end local v1    # "msg":Landroid/os/Message;
    :catchall_67
    move-exception v0

    :try_start_68
    monitor-exit v1
    :try_end_69
    .catchall {:try_start_68 .. :try_end_69} :catchall_67

    throw v0

    .line 2900
    :catchall_6a
    move-exception v1

    :try_start_6b
    monitor-exit v0
    :try_end_6c
    .catchall {:try_start_6b .. :try_end_6c} :catchall_6a

    throw v1

    .line 2917
    :cond_6d
    :goto_6d
    return-void
.end method

.method public setAdjTestSwitch(Z)V
    .registers 2
    .param p1, "testSwitch"    # Z

    .line 3703
    iput-boolean p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mAdjTestSwitch:Z

    .line 3704
    return-void
.end method

.method public setDeepSleepPredictEndTimeMs(J)V
    .registers 5
    .param p1, "deepSleepPredictEndTimeMs"    # J

    .line 4226
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeChanged:Z

    .line 4227
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeMs:J

    cmp-long v0, v0, p1

    if-eqz v0, :cond_b

    .line 4228
    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictEndTimeMs:J

    .line 4230
    :cond_b
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->sendOnceMessageIfStartAndEndChanged()V

    .line 4231
    return-void
.end method

.method public setDeepSleepPredictStartTimeMs(J)V
    .registers 5
    .param p1, "deepSleepPredictStartTimeMs"    # J

    .line 4218
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeChanged:Z

    .line 4219
    iget-wide v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeMs:J

    cmp-long v0, v0, p1

    if-eqz v0, :cond_b

    .line 4220
    iput-wide p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDeepSleepPredictStartTimeMs:J

    .line 4222
    :cond_b
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->sendOnceMessageIfStartAndEndChanged()V

    .line 4223
    return-void
.end method

.method public setPersistentUidToKernelIfNeeded(Lcom/android/server/hans/OplusHansPackage;Z)V
    .registers 6
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "add"    # Z

    .line 785
    if-eqz p1, :cond_65

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->isInImPkgConfigList(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_65

    .line 786
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkgName="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-eqz p2, :cond_41

    const-string v2, "added"

    goto :goto_44

    :cond_41
    const-string/jumbo v2, "removed"

    :goto_44
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " as persistent"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 787
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/hans/OplusHansPackage;Z)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 791
    :cond_65
    return-void
.end method

.method public setRestriction(I)V
    .registers 3
    .param p1, "flag"    # I

    .line 4196
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v0, p1}, Lcom/android/server/hans/scene/HansSceneCombo;->setRestrictionFlags(I)V

    .line 4197
    return-void
.end method

.method public setThermalImpScene(IZ)V
    .registers 8
    .param p1, "scene"    # I
    .param p2, "enter"    # Z

    .line 5203
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getThermalGuardEnable()Z

    move-result v0

    if-nez v0, :cond_b

    .line 5204
    return-void

    .line 5206
    :cond_b
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getThermalImpScene()I

    move-result v0

    .line 5207
    .local v0, "oldScene":I
    const/4 v1, 0x0

    const v2, 0x7fffffff

    if-eqz p2, :cond_29

    .line 5208
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

    or-int v4, v0, p1

    invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 5209
    and-int/2addr v2, v0

    if-nez v2, :cond_3c

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->inThermalImpScene()Z

    move-result v2

    if-eqz v2, :cond_3c

    .line 5210
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateThermalPriorityLevel(I)V

    goto :goto_3c

    .line 5213
    :cond_29
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalImpScene:Ljava/util/concurrent/atomic/AtomicInteger;

    not-int v4, p1

    and-int/2addr v4, v0

    invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 5214
    and-int/2addr v2, v0

    if-eqz v2, :cond_3c

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->inThermalImpScene()Z

    move-result v2

    if-nez v2, :cond_3c

    .line 5215
    invoke-direct {p0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateThermalPriorityLevel(I)V

    .line 5218
    :cond_3c
    :goto_3c
    return-void
.end method

.method public setThermalMode(Z)V
    .registers 8
    .param p1, "thermalMode"    # Z

    .line 4557
    iput-boolean p1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    .line 4558
    iget-boolean v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalMode:Z

    if-nez v0, :cond_39

    .line 4559
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 4560
    .local v0, "thermalIgnoreTrafficSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    monitor-enter v1

    .line 4561
    :try_start_e
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-virtual {v0, v2}, Landroid/util/ArraySet;->addAll(Landroid/util/ArraySet;)V

    .line 4562
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalIgnoreTrafficSet:Landroid/util/ArraySet;

    invoke-virtual {v2}, Landroid/util/ArraySet;->clear()V

    .line 4563
    monitor-exit v1
    :try_end_19
    .catchall {:try_start_e .. :try_end_19} :catchall_36

    .line 4564
    invoke-virtual {v0}, Landroid/util/ArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_39

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 4565
    .local v2, "uid":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const-string/jumbo v4, "exitThermal_thermalIgnoreTraffic"

    const-string v5, ""

    invoke-virtual {p0, v3, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 4566
    .end local v2    # "uid":Ljava/lang/Integer;
    goto :goto_1d

    .line 4563
    :catchall_36
    move-exception v2

    :try_start_37
    monitor-exit v1
    :try_end_38
    .catchall {:try_start_37 .. :try_end_38} :catchall_36

    throw v2

    .line 4568
    .end local v0    # "thermalIgnoreTrafficSet":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    :cond_39
    return-void
.end method

.method public skipNotificationInCameraVocalScene(Ljava/lang/String;I)Z
    .registers 7
    .param p1, "pkg"    # Ljava/lang/String;
    .param p2, "incomingUserId"    # I

    .line 5057
    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->isInCameraVocalScene()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    .line 5058
    return v1

    .line 5061
    :cond_8
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {p0}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentCameraMinSysSubSceneId()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansDBConfig;->getSkipNotiThermalLevel(I)I

    move-result v2

    if-ge v0, v2, :cond_1d

    .line 5062
    return v1

    .line 5065
    :cond_1d
    invoke-static {p1, p2}, Lcom/android/server/am/OplusHansManager;->getPackageUid(Ljava/lang/String;I)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getAppType(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v0, v2, :cond_3b

    .line 5066
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mThermalLevel:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getSkipIMNotiThermalLevel()I

    move-result v2

    if-lt v0, v2, :cond_3a

    .line 5067
    return v3

    .line 5072
    :cond_3a
    return v1

    .line 5070
    :cond_3b
    return v3
.end method

.method public unfreezeAllApps(Ljava/lang/String;)V
    .registers 11
    .param p1, "reason"    # Ljava/lang/String;

    .line 3074
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 3077
    const/4 v0, 0x1

    .local v0, "target":I
    :goto_6
    const/16 v1, 0x8

    if-ge v0, v1, :cond_73

    .line 3078
    const/4 v1, 0x0

    .line 3080
    .local v1, "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :try_start_b
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mSceneCombo:Lcom/android/server/hans/scene/HansSceneCombo;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneCombo;->getTargetFlags()I

    move-result v2

    and-int/2addr v2, v0

    packed-switch v2, :pswitch_data_7a

    :pswitch_15
    goto :goto_22

    .line 3088
    :pswitch_16
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3089
    goto :goto_22

    .line 3085
    :pswitch_1a
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3086
    goto :goto_22

    .line 3082
    :pswitch_1e
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3083
    nop

    .line 3094
    :goto_22
    if-eqz v1, :cond_69

    .line 3095
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_25
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_69

    .line 3096
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    .line 3097
    .local v3, "uid":I
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 3098
    .local v4, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_66

    .line 3099
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5
    :try_end_3c
    .catchall {:try_start_b .. :try_end_3c} :catchall_6c

    .line 3100
    :try_start_3c
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v6

    if-eqz v6, :cond_61

    .line 3102
    const-string v6, ""

    invoke-virtual {p0, v4, p1, v6}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 3103
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "SceneManager unfreezeAllApps uid="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3105
    :cond_61
    monitor-exit v5

    goto :goto_66

    :catchall_63
    move-exception v6

    monitor-exit v5
    :try_end_65
    .catchall {:try_start_3c .. :try_end_65} :catchall_63

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "reason":Ljava/lang/String;
    :try_start_65
    throw v6
    :try_end_66
    .catchall {:try_start_65 .. :try_end_66} :catchall_6c

    .line 3095
    .end local v3    # "uid":I
    .end local v4    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "reason":Ljava/lang/String;
    :cond_66
    :goto_66
    add-int/lit8 v2, v2, 0x1

    goto :goto_25

    .line 3077
    .end local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v2    # "i":I
    :cond_69
    shl-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 3111
    .end local v0    # "target":I
    :catchall_6c
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3112
    throw v0

    .line 3111
    :cond_73
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3112
    nop

    .line 3113
    return-void

    :pswitch_data_7a
    .packed-switch 0x1
        :pswitch_1e
        :pswitch_1a
        :pswitch_15
        :pswitch_16
    .end packed-switch
.end method

.method public unfreezeAllAppsForAllTargets(Ljava/lang/String;)V
    .registers 11
    .param p1, "reason"    # Ljava/lang/String;

    .line 3120
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 3123
    const/4 v0, 0x1

    .local v0, "target":I
    :goto_6
    const/16 v1, 0x8

    if-ge v0, v1, :cond_6d

    .line 3124
    const/4 v1, 0x0

    .line 3126
    .local v1, "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    packed-switch v0, :pswitch_data_74

    :pswitch_e
    goto :goto_1d

    .line 3134
    :pswitch_f
    :try_start_f
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3135
    goto :goto_1d

    .line 3131
    :pswitch_13
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3132
    goto :goto_1d

    .line 3128
    :pswitch_17
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    move-object v1, v2

    .line 3129
    goto :goto_1d

    .line 3157
    .end local v0    # "target":I
    .end local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_1b
    move-exception v0

    goto :goto_64

    .line 3140
    .restart local v0    # "target":I
    .restart local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :goto_1d
    if-eqz v1, :cond_6a

    .line 3141
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_20
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_6a

    .line 3142
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    .line 3143
    .local v3, "uid":I
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/hans/OplusHansPackage;

    .line 3144
    .local v4, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_61

    .line 3145
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5
    :try_end_37
    .catchall {:try_start_f .. :try_end_37} :catchall_1b

    .line 3146
    :try_start_37
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v6

    if-eqz v6, :cond_5c

    .line 3148
    const-string v6, ""

    invoke-virtual {p0, v4, p1, v6}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 3149
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "SceneManager unfreezeAllApps uid="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3151
    :cond_5c
    monitor-exit v5

    goto :goto_61

    :catchall_5e
    move-exception v6

    monitor-exit v5
    :try_end_60
    .catchall {:try_start_37 .. :try_end_60} :catchall_5e

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "reason":Ljava/lang/String;
    :try_start_60
    throw v6
    :try_end_61
    .catchall {:try_start_60 .. :try_end_61} :catchall_1b

    .line 3141
    .end local v3    # "uid":I
    .end local v4    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "reason":Ljava/lang/String;
    :cond_61
    :goto_61
    add-int/lit8 v2, v2, 0x1

    goto :goto_20

    .line 3157
    .end local v0    # "target":I
    .end local v1    # "managedMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v2    # "i":I
    :goto_64
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3158
    throw v0

    .line 3123
    .restart local v0    # "target":I
    :cond_6a
    shl-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 3157
    .end local v0    # "target":I
    :cond_6d
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3158
    nop

    .line 3159
    return-void

    :pswitch_data_74
    .packed-switch 0x1
        :pswitch_17
        :pswitch_13
        :pswitch_e
        :pswitch_f
    .end packed-switch
.end method

.method public unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 9
    .param p1, "uid"    # I
    .param p2, "reason"    # Ljava/lang/String;
    .param p3, "cpnInfo"    # Ljava/lang/String;

    .line 2956
    invoke-virtual {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 2957
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v0, :cond_9

    .line 2958
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v1

    .line 2960
    :cond_9
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 2961
    :try_start_e
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v2

    if-nez v2, :cond_18

    .line 2962
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    monitor-exit v1

    return-object v2

    .line 2965
    :cond_18
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-static {v4}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lcom/android/server/am/OplusHansManager;->isPreloadPkg(Ljava/lang/String;I)Z

    move-result v2

    .line 2966
    .local v2, "isPreloadApp":Z
    if-eqz v2, :cond_34

    .line 2967
    invoke-virtual {p0, v0, p2}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeForPreload(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v3

    monitor-exit v1

    return-object v3

    .line 2971
    :cond_34
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v3, v0, p2, p3}, Lcom/android/server/hans/freeze/HansCGroup;->hansUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    .line 2972
    .local v3, "isSuccessful":Z
    if-eqz v3, :cond_3f

    .line 2973
    invoke-direct {p0, v0, p2}, Lcom/android/server/hans/scene/HansSceneManager;->handleStateMachineUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 2975
    :cond_3f
    if-eqz v3, :cond_44

    sget-object v4, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    goto :goto_46

    :cond_44
    sget-object v4, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    :goto_46
    monitor-exit v1

    return-object v4

    .line 2976
    .end local v2    # "isPreloadApp":Z
    .end local v3    # "isSuccessful":Z
    :catchall_48
    move-exception v2

    monitor-exit v1
    :try_end_4a
    .catchall {:try_start_e .. :try_end_4a} :catchall_48

    throw v2
.end method

.method public unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 10
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;
    .param p3, "cpnInfo"    # Ljava/lang/String;

    .line 2983
    if-nez p1, :cond_5

    .line 2984
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v0

    .line 2986
    :cond_5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 2987
    :try_start_a
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v1

    if-nez v1, :cond_14

    .line 2988
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    monitor-exit v0

    return-object v1

    .line 2991
    :cond_14
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-static {v3}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lcom/android/server/am/OplusHansManager;->isPreloadPkg(Ljava/lang/String;I)Z

    move-result v1

    .line 2992
    .local v1, "isPreloadApp":Z
    if-eqz v1, :cond_30

    .line 2993
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeForPreload(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v2

    monitor-exit v0

    return-object v2

    .line 2996
    :cond_30
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v2, p1, p2, p3}, Lcom/android/server/hans/freeze/HansCGroup;->hansUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    .line 2998
    .local v2, "isSuccessful":Z
    if-eqz v2, :cond_50

    .line 2999
    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->handleStateMachineUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 3000
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    monitor-enter v3
    :try_end_3e
    .catchall {:try_start_a .. :try_end_3e} :catchall_59

    .line 3001
    :try_start_3e
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager;->mTcpRetransmissionRestrictSet:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 3002
    monitor-exit v3

    goto :goto_50

    :catchall_4d
    move-exception v4

    monitor-exit v3
    :try_end_4f
    .catchall {:try_start_3e .. :try_end_4f} :catchall_4d

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .end local p1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local p2    # "reason":Ljava/lang/String;
    .end local p3    # "cpnInfo":Ljava/lang/String;
    :try_start_4f
    throw v4

    .line 3004
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    .restart local p1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .restart local p2    # "reason":Ljava/lang/String;
    .restart local p3    # "cpnInfo":Ljava/lang/String;
    :cond_50
    :goto_50
    if-eqz v2, :cond_55

    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    goto :goto_57

    :cond_55
    sget-object v3, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    :goto_57
    monitor-exit v0

    return-object v3

    .line 3005
    .end local v1    # "isPreloadApp":Z
    .end local v2    # "isSuccessful":Z
    :catchall_59
    move-exception v1

    monitor-exit v0
    :try_end_5b
    .catchall {:try_start_4f .. :try_end_5b} :catchall_59

    throw v1
.end method

.method public unfreezeDSSkipBtUids()V
    .registers 6

    .line 5281
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 5282
    .local v0, "ufzSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    monitor-enter v1

    .line 5283
    :try_start_8
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 5284
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mDSSkipBtSet:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    .line 5285
    monitor-exit v1
    :try_end_13
    .catchall {:try_start_8 .. :try_end_13} :catchall_31

    .line 5286
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_17
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_30

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 5287
    .local v2, "uid":I
    const-string/jumbo v3, "exitDeepSleep"

    const-string v4, ""

    invoke-virtual {p0, v2, v3, v4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 5288
    .end local v2    # "uid":I
    goto :goto_17

    .line 5289
    :cond_30
    return-void

    .line 5285
    :catchall_31
    move-exception v2

    :try_start_32
    monitor-exit v1
    :try_end_33
    .catchall {:try_start_32 .. :try_end_33} :catchall_31

    throw v2
.end method

.method public unfreezeDirectly(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 6
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;
    .param p3, "cpnInfo"    # Ljava/lang/String;

    .line 2940
    if-nez p1, :cond_5

    .line 2941
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v0

    .line 2943
    :cond_5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 2944
    :try_start_a
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v1

    if-nez v1, :cond_14

    .line 2945
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    monitor-exit v0

    return-object v1

    .line 2948
    :cond_14
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {v1, p1, p2, p3}, Lcom/android/server/hans/freeze/HansCGroup;->hansUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1f

    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    goto :goto_21

    :cond_1f
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    :goto_21
    monitor-exit v0

    return-object v1

    .line 2949
    :catchall_23
    move-exception v1

    monitor-exit v0
    :try_end_25
    .catchall {:try_start_a .. :try_end_25} :catchall_23

    throw v1
.end method

.method public unfreezeForKernel(Lcom/android/server/hans/OplusHansPackage;ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 12
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "targetPid"    # I
    .param p3, "reason"    # Ljava/lang/String;
    .param p4, "cpnInfo"    # Ljava/lang/String;

    .line 3009
    if-nez p1, :cond_5

    .line 3010
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v0

    .line 3012
    :cond_5
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 3013
    .local v0, "unfreezing":Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    const/4 v1, 0x0

    .line 3014
    .local v1, "isForceUF":Z
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 3015
    :try_start_d
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v3

    if-eqz v3, :cond_30

    .line 3016
    if-lez p2, :cond_2a

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getFrozenPidList()Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_2a

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getFrozenPidList()Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2a

    .line 3017
    const/4 v1, 0x1

    .line 3019
    :cond_2a
    invoke-virtual {p0, p1, p3, p4}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    move-result-object v3

    move-object v0, v3

    goto :goto_33

    .line 3020
    :cond_30
    if-lez p2, :cond_33

    .line 3021
    const/4 v1, 0x1

    .line 3023
    :cond_33
    :goto_33
    monitor-exit v2
    :try_end_34
    .catchall {:try_start_d .. :try_end_34} :catchall_65

    .line 3024
    if-eqz v1, :cond_64

    .line 3025
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    new-instance v4, Ljava/util/ArrayList;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "unfreezeForKernel: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4, v5}, Lcom/android/server/hans/freeze/HansCGroup;->forceUnfreezeApp(ILjava/util/ArrayList;Ljava/lang/String;)V

    .line 3027
    :cond_64
    return-object v0

    .line 3023
    :catchall_65
    move-exception v3

    :try_start_66
    monitor-exit v2
    :try_end_67
    .catchall {:try_start_66 .. :try_end_67} :catchall_65

    throw v3
.end method

.method public unfreezeForPreload(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;
    .registers 9
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;

    .line 2819
    if-nez p1, :cond_5

    .line 2820
    sget-object v0, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->INVALID:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    return-object v0

    .line 2822
    :cond_5
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 2823
    :try_start_a
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v1

    if-nez v1, :cond_14

    .line 2824
    sget-object v1, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->HOLD:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    monitor-exit v0

    return-object v1

    .line 2828
    :cond_14
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mCgroup:Lcom/android/server/hans/freeze/HansCGroup;

    const-string v2, ""

    invoke-virtual {v1, p1, p2, v2}, Lcom/android/server/hans/freeze/HansCGroup;->hansUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    .line 2830
    .local v1, "isSuccessful":Z
    if-eqz v1, :cond_42

    .line 2831
    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->handleStateMachineUnfreezeLocked(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 2833
    const-string v2, "Activity"

    invoke-virtual {v2, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    const-string v2, "TopActivity"

    .line 2834
    invoke-virtual {v2, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    const-string v2, "Preload_F"

    .line 2835
    invoke-virtual {v2, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    .line 2836
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v3, 0x10

    const-wide/16 v4, 0x3e8

    invoke-static {v2, v3, p1, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->-$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;ILjava/lang/Object;J)V

    .line 2839
    :cond_42
    if-eqz v1, :cond_47

    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->TRUE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    goto :goto_49

    :cond_47
    sget-object v2, Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;->FALSE:Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    :goto_49
    monitor-exit v0

    return-object v2

    .line 2840
    .end local v1    # "isSuccessful":Z
    :catchall_4b
    move-exception v1

    monitor-exit v0
    :try_end_4d
    .catchall {:try_start_a .. :try_end_4d} :catchall_4b

    throw v1
.end method

.method public unfreezeProxyAlarmSetAsync()V
    .registers 3

    .line 3807
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda2;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->post(Ljava/lang/Runnable;)Z

    .line 3808
    return-void
.end method

.method public unfreezeViaSM(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V
    .registers 4
    .param p1, "hansPkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "reason"    # Ljava/lang/String;

    .line 3046
    if-nez p1, :cond_3

    .line 3047
    return-void

    .line 3049
    :cond_3
    invoke-virtual {p1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v0

    invoke-virtual {v0, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V

    .line 3050
    return-void
.end method

.method public updateGmsRestrictPkg(ZI)V
    .registers 9
    .param p1, "isRestrict"    # Z
    .param p2, "userId"    # I

    .line 762
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 764
    :try_start_5
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackageMap(I)Landroid/util/SparseArray;

    move-result-object v0

    .line 765
    .local v0, "gmsList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    if-eqz v0, :cond_49

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-nez v1, :cond_18

    goto :goto_49

    .line 768
    :cond_18
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_19
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_42

    .line 769
    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    .line 770
    .local v2, "uid":I
    invoke-static {v2}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v3

    .line 771
    .local v3, "appUserId":I
    if-eq p2, v3, :cond_2f

    if-nez p2, :cond_3f

    const/16 v4, 0x3e7

    if-ne v3, v4, :cond_3f

    .line 772
    :cond_2f
    const/4 v4, 0x1

    if-eqz p1, :cond_3c

    .line 773
    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {p0, v5, v4}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V

    goto :goto_3f

    .line 775
    :cond_3c
    invoke-virtual {p0, v2, v4}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V
    :try_end_3f
    .catchall {:try_start_5 .. :try_end_3f} :catchall_4f

    .line 768
    .end local v2    # "uid":I
    .end local v3    # "appUserId":I
    :cond_3f
    :goto_3f
    add-int/lit8 v1, v1, 0x1

    goto :goto_19

    .line 780
    .end local v0    # "gmsList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v1    # "i":I
    :cond_42
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 781
    nop

    .line 782
    return-void

    .line 780
    .restart local v0    # "gmsList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :cond_49
    :goto_49
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 766
    return-void

    .line 780
    .end local v0    # "gmsList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    :catchall_4f
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 781
    throw v0
.end method

.method public updateHansWLByAppUsage()V
    .registers 5

    .line 4407
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    new-instance v1, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/android/server/hans/scene/HansSceneManager$$ExternalSyntheticLambda3;-><init>(Lcom/android/server/hans/scene/HansSceneManager;)V

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getAppUsageMgsDelayTime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 4408
    return-void
.end method

.method public updateManagedMap()V
    .registers 4

    .line 500
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 503
    :try_start_5
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackageMap(I)Landroid/util/SparseArray;

    move-result-object v0

    .line 504
    .local v0, "tmpThirdList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    const/4 v2, 0x6

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackageMap(I)Landroid/util/SparseArray;

    move-result-object v1

    .line 506
    .local v1, "tmpWhiteList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->clear()V

    .line 507
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->clear()V

    .line 508
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mInvalidHansWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->clear()V

    .line 510
    iput-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapThird:Landroid/util/SparseArray;

    .line 511
    iput-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapWhitelist:Landroid/util/SparseArray;
    :try_end_2a
    .catchall {:try_start_5 .. :try_end_2a} :catchall_31

    .line 513
    .end local v0    # "tmpThirdList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    .end local v1    # "tmpWhiteList":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/hans/OplusHansPackage;>;"
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 514
    nop

    .line 515
    return-void

    .line 513
    :catchall_31
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 514
    throw v0
.end method

.method public updateManagedMapForPowerSave(Ljava/util/List;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 637
    .local p1, "expectedExWhitelist":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    if-nez p1, :cond_3

    .line 638
    return-void

    .line 640
    :cond_3
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 645
    :try_start_8
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .local v0, "i":I
    :goto_10
    const/4 v1, 0x4

    if-ltz v0, :cond_29

    .line 646
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    .line 647
    .local v2, "currentUid":I
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {p1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_26

    .line 648
    invoke-virtual {p0, v2, v1}, Lcom/android/server/hans/scene/HansSceneManager;->resetManagedMapByUid(II)V

    .line 645
    .end local v2    # "currentUid":I
    :cond_26
    add-int/lit8 v0, v0, -0x1

    goto :goto_10

    .line 654
    .end local v0    # "i":I
    :cond_29
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 655
    .local v0, "itInput":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :goto_2d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_53

    .line 656
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 657
    .local v2, "inputUid":I
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager;->mManagedMapExWhitelist:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->contains(I)Z

    move-result v3

    if-nez v3, :cond_52

    .line 658
    const/4 v3, 0x2

    invoke-direct {p0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUidLocked(II)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 659
    .local v4, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    invoke-virtual {p0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->removeFromManagedMap(II)V

    .line 660
    if-eqz v4, :cond_52

    .line 661
    invoke-virtual {p0, v4, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addToManagedMap(Lcom/android/server/hans/OplusHansPackage;I)V
    :try_end_52
    .catchall {:try_start_8 .. :try_end_52} :catchall_5a

    .line 664
    .end local v2    # "inputUid":I
    .end local v4    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_52
    goto :goto_2d

    .line 666
    .end local v0    # "itInput":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/Integer;>;"
    :cond_53
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 667
    nop

    .line 668
    return-void

    .line 666
    :catchall_5a
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 667
    throw v0
.end method

.method public updateMinAdjOfUid(II)V
    .registers 7
    .param p1, "uid"    # I
    .param p2, "adj"    # I

    .line 3707
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    monitor-enter v0

    .line 3708
    :try_start_3
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidAdjMap:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3709
    monitor-exit v0

    .line 3710
    return-void

    .line 3709
    :catchall_12
    move-exception v1

    monitor-exit v0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_12

    throw v1
.end method

.method public updateSysBlackOrGrayNowViaMsg()V
    .registers 3

    .line 1439
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    const/16 v1, 0xd

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->removeMessages(I)V

    .line 1440
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHandler:Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessage(I)Z

    .line 1441
    return-void
.end method

.method public updateSysBlackOrGrayPackage()V
    .registers 3

    .line 1224
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 1226
    :try_start_5
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackPackageLocked()V

    .line 1227
    invoke-direct {p0}, Lcom/android/server/hans/scene/HansSceneManager;->updateGrayPackageLocked()V
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_12

    .line 1229
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1230
    nop

    .line 1231
    return-void

    .line 1229
    :catchall_12
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapWriteLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 1230
    throw v0
.end method

.method public uploadHistory()V
    .registers 14

    .line 3720
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isStatisticsEnable()Z

    move-result v0

    if-nez v0, :cond_b

    .line 3721
    return-void

    .line 3723
    :cond_b
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    .line 3725
    :try_start_10
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 3726
    .local v0, "now":J
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager;->mRunningUidSet:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_a8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 3727
    .local v3, "uid":I
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 3728
    .local v4, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v4, :cond_35

    .line 3729
    goto :goto_1a

    .line 3731
    :cond_35
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5
    :try_end_3a
    .catchall {:try_start_10 .. :try_end_3a} :catchall_bd

    .line 3732
    :try_start_3a
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v6

    const-wide/16 v7, 0x0

    if-eqz v6, :cond_62

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getFreezeTime()J

    move-result-wide v9

    cmp-long v6, v9, v7

    if-lez v6, :cond_62

    .line 3733
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v9

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getFreezeTime()J

    move-result-wide v11

    sub-long v11, v0, v11

    invoke-virtual {v6, v9, v10, v11, v12}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyFrozenTime(ILjava/lang/String;J)V

    .line 3734
    invoke-virtual {v4, v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setFreezeTime(J)V

    .line 3736
    :cond_62
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v9

    cmp-long v6, v9, v7

    if-lez v6, :cond_82

    .line 3737
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v9

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v11

    sub-long v11, v0, v11

    invoke-virtual {v6, v9, v10, v11, v12}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyLiveTime(ILjava/lang/String;J)V

    .line 3738
    invoke-virtual {v4, v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 3740
    :cond_82
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterSMTime()J

    move-result-wide v9

    cmp-long v6, v9, v7

    if-lez v6, :cond_a2

    .line 3741
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterSMTime()J

    move-result-wide v9

    sub-long v9, v0, v9

    invoke-virtual {v6, v7, v8, v9, v10}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyEnterSMTime(ILjava/lang/String;J)V

    .line 3742
    invoke-virtual {v4, v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setEnterSMTime(J)V

    .line 3744
    :cond_a2
    monitor-exit v5

    .line 3745
    .end local v3    # "uid":I
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    goto/16 :goto_1a

    .line 3744
    .restart local v3    # "uid":I
    .restart local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :catchall_a5
    move-exception v2

    monitor-exit v5
    :try_end_a7
    .catchall {:try_start_3a .. :try_end_a7} :catchall_a5

    .end local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    :try_start_a7
    throw v2
    :try_end_a8
    .catchall {:try_start_a7 .. :try_end_a8} :catchall_bd

    .line 3747
    .end local v0    # "now":J
    .end local v3    # "uid":I
    .end local v4    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    .restart local p0    # "this":Lcom/android/server/hans/scene/HansSceneManager;
    :cond_a8
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3748
    nop

    .line 3749
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansHistoryManager;->uploadQuotaRusInfo()V

    .line 3750
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansHistoryManager;->uploadHansRecordData()V

    .line 3751
    return-void

    .line 3747
    :catchall_bd
    move-exception v0

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager;->mHansMapReadLock:Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    .line 3748
    throw v0
.end method
