.class public final Lcom/android/server/net/linkpower/monitor/MonitorService;
.super Ljava/lang/Object;
.source "MonitorService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/net/linkpower/monitor/MonitorService$MyWifiEventCallback;,
        Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;,
        Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;
    }
.end annotation


# static fields
.field public static final EVENT_DATA_LOCATION_REQUEST_CHANGED:I = 0x3

.field public static final EVENT_DATA_LOCATION_REQUEST_CHANGED_ARGS_LEN:I = 0x1

.field public static final EVENT_DATA_REQUEST_ON_WIFI_CHANGED:I = 0x2

.field public static final EVENT_DATA_REQUEST_ON_WIFI_CHANGED_ARGS_LEN:I = 0x3

.field public static final EVENT_DATE_CHANGED:I = 0xe

.field public static final EVENT_DEFAULT_NETWORK_STATE_CHANGED:I = 0x10

.field public static final EVENT_DEFAULT_NETWORK_STATE_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_REGISTER_PUSH_PROC_CHANGED:I = 0x11

.field public static final EVENT_REGISTER_PUSH_PROC_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_REGISTER_SKCONNECT_CHANGED:I = 0x12

.field public static final EVENT_REGISTER_SKCONNECT_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_REQUEST_SKCONNECT_INFO:I = 0x13

.field public static final EVENT_REQUEST_SKCONNECT_INFO_ARGS_LEN:I = 0x2

.field public static final EVENT_RUNNING_UID_CHANGED:I = 0x1

.field public static final EVENT_RUNNING_UID_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_SCREEN_OFF_STATE_CHANGED:I = 0xf

.field public static final EVENT_SCREEN_OFF_STATE_CHANGED_ARGS_LEN:I = 0x1

.field public static final EVENT_WIFI_HOTSPOT_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_WIFI_HOTSPOT_LOCAL_ONLY_CHANGED:I = 0xb

.field public static final EVENT_WIFI_HOTSPOT_TETHERED_CHANGED:I = 0xc

.field public static final EVENT_WIFI_P2P_CONN_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_WIFI_P2P_CONN_GC_CHANGED:I = 0xa

.field public static final EVENT_WIFI_P2P_CONN_GO_CHANGED:I = 0x9

.field public static final EVENT_WIFI_SCAN_CHANGED:I = 0x6

.field public static final EVENT_WIFI_SCAN_CHANGED_ARGS_LEN:I = 0x1

.field public static final EVENT_WIFI_SLA_CONN_CHANGED:I = 0xd

.field public static final EVENT_WIFI_SLA_CONN_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_WIFI_STA_CONN_CHANGED_ARGS_LEN:I = 0x2

.field public static final EVENT_WIFI_STA_CONN_PRIMARY_CHANGED:I = 0x7

.field public static final EVENT_WIFI_STA_CONN_SECONDARY_CHANGED:I = 0x8

.field private static final HANDLE_RUNNING_UID_ADD:I = 0x2

.field private static final HANDLE_RUNNING_UID_REMOVE:I = 0x3

.field private static final HANDLE_UPDATE_ACTIVE_MONITORS:I = 0x1

.field private static final MAX_SETTLE_SCENE_LEN:I = 0x4

.field private static final MONITOR_DUMP_ARGS_INDEX:I = 0x2

.field private static final MONITOR_DUMP_ARGS_LEN:I = 0x4

.field private static final NHS_INTENT_REQUEST_TRAFFIC_KERNEL_INFO:Ljava/lang/String; = "oplus.intent.action.MDPWR_UPDATE_TRAFFIC_KERNEL_INFO"

.field private static final SCREEN_CHANGED_IGNORE_MS:I = 0x2710

.field private static final SETTLE_ENTER:I = 0x1

.field private static final SETTLE_EXIT:I = 0x2

.field private static final SETTLE_NAME:[Ljava/lang/String;

.field private static final SETTLE_SCREEN_OFF:I = 0x1

.field private static final SETTLE_SCREEN_ON:I = 0x0

.field private static final SETTLE_SHORT_SCREEN_OFF:I = 0x2

.field private static final SETTLE_TEST:I = 0x3

.field private static final SHORT_SCREEN_OFF_MS:I = 0xdbba0

.field public static final TAG:Ljava/lang/String;

.field private static final WDC_INFO_TO_LINKPOWER:Ljava/lang/String; = "oplus.intent.action.WDC_INFO_TO_LINKPOWER"

.field private static final WIFI_CONN_CHANGED_IGNORE_MS:I = 0x7530

.field private static volatile sInstance:Lcom/android/server/net/linkpower/monitor/MonitorService;


# instance fields
.field private mActiveMonitors:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mBroadcastReceiver:Landroid/content/BroadcastReceiver;

.field private mCommSceneListener:Lcom/oplus/commscene/CommSceneListener;

.field private mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

.field private mConnectivityManager:Landroid/net/ConnectivityManager;

.field private final mContext:Landroid/content/Context;

.field private mHandler:Landroid/os/Handler;

.field private mLinkPowerRus:Lcom/android/server/net/linkpower/LinkPowerRus;

.field private final mLooper:Landroid/os/Looper;

.field private mMonitorEnabled:Z

.field private mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

.field private mOplusWifiManager:Landroid/net/wifi/OplusWifiManager;

.field private mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

.field private mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

.field private mRusUpdated:Z

.field private mRusVersion:I

.field private mSceneObjMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;",
            ">;"
        }
    .end annotation
.end field

.field private mScreenOffStamp:J

.field private mSupportMonitors:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mUidObserver:Landroid/app/IUidObserver;

.field private mWifiEventCallback:Landroid/net/wifi/OplusWifiEventCallback;


# direct methods
.method public static synthetic $r8$lambda$-tC5ZoMoMuM8-M-1L0TdJhDSoXI(Lcom/android/server/net/linkpower/monitor/MonitorService;ZLjava/util/function/Consumer;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$registerPushProcChanged$6(ZLjava/util/function/Consumer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$1cSD8OzCRUHQtWJc0PyRa9YiEYc(Lcom/android/server/net/linkpower/monitor/MonitorService;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$requestSkConnectInfo$8(II)V

    return-void
.end method

.method public static synthetic $r8$lambda$6sZTz77hDWsPSezse4A55GZBA4g(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$screenOn$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$8Dxfj2rxTv2A_OgI4BCFFR3vOOM(Lcom/android/server/net/linkpower/monitor/MonitorService;ZLjava/util/function/Consumer;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$registerSkConnectChanged$7(ZLjava/util/function/Consumer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$DfMAWkcHVYPyn1CdVbsvjqaUgwU(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$toLog$5()V

    return-void
.end method

.method public static synthetic $r8$lambda$PtG48ysjb7-GRnz52IV3dVL242Y(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$loopTick$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$R2VmK5VeO7rmAAqKp6z6zQ-zvt4(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$dailyReport$4()V

    return-void
.end method

.method public static synthetic $r8$lambda$tX-mv97gDrdGOYdCyZzeDvhygoU(Lcom/android/server/net/linkpower/monitor/MonitorService;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$new$0(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$upBzXYeaWuLAtTGBN-kA39yk7LQ(Lcom/android/server/net/linkpower/monitor/MonitorService;Ljava/util/Map;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$handleRusUpdate$9(Ljava/util/Map;)V

    return-void
.end method

.method public static synthetic $r8$lambda$y1J2F_cLURXzgJEmg18A1vM8nko(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->lambda$screenOff$2()V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetmHandler(Lcom/android/server/net/linkpower/monitor/MonitorService;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmSupportMonitors(Lcom/android/server/net/linkpower/monitor/MonitorService;)Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mdefaultNetworkOnAvailable(Lcom/android/server/net/linkpower/monitor/MonitorService;Landroid/net/Network;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->defaultNetworkOnAvailable(Landroid/net/Network;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mdefaultNetworkOnLost(Lcom/android/server/net/linkpower/monitor/MonitorService;Landroid/net/Network;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->defaultNetworkOnLost(Landroid/net/Network;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mhandleEvent(Lcom/android/server/net/linkpower/monitor/MonitorService;I[Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mupdateActiveMonitors(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateActiveMonitors()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mupdateRecords(Lcom/android/server/net/linkpower/monitor/MonitorService;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    return-void
.end method

.method static bridge synthetic -$$Nest$smmyLogD(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smmyLogE(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 67
    const-class v0, Lcom/android/server/net/linkpower/monitor/MonitorService;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    .line 108
    const-string v0, "S_S_OFF"

    const-string v1, "TEST"

    const-string v2, "S_ON"

    const-string v3, "S_OFF"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/os/Looper;)V
    .registers 6
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "looper"    # Landroid/os/Looper;

    .line 272
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 144
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mScreenOffStamp:J

    .line 146
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mMonitorEnabled:Z

    .line 147
    iput v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusVersion:I

    .line 148
    iput-boolean v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusUpdated:Z

    .line 273
    iput-object p1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    .line 274
    iput-object p2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    .line 275
    new-instance v0, Lcom/android/server/net/linkpower/monitor/MonitorService$1;

    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    invoke-direct {v0, p0, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService$1;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    .line 293
    invoke-static {}, Lcom/android/server/net/linkpower/LinkPowerRus;->getInstance()Lcom/android/server/net/linkpower/LinkPowerRus;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLinkPowerRus:Lcom/android/server/net/linkpower/LinkPowerRus;

    .line 294
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLinkPowerRus:Lcom/android/server/net/linkpower/LinkPowerRus;

    sget-object v1, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    new-instance v2, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda4;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1, v2}, Lcom/android/server/net/linkpower/LinkPowerRus;->listenRusUpdate(Ljava/lang/String;Ljava/util/function/Consumer;)V

    .line 295
    return-void
.end method

.method private defaultNetworkOnAvailable(Landroid/net/Network;)V
    .registers 9
    .param p1, "network"    # Landroid/net/Network;

    .line 633
    if-nez p1, :cond_3

    .line 634
    return-void

    .line 636
    :cond_3
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    if-nez v0, :cond_13

    .line 637
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    const-string v1, "connectivity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    .line 639
    :cond_13
    const/4 v0, 0x0

    .line 640
    .local v0, "update":Z
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    invoke-virtual {v1, p1}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v1

    .line 641
    .local v1, "nc":Landroid/net/NetworkCapabilities;
    const/16 v2, 0x10

    const/4 v3, 0x1

    if-eqz v1, :cond_37

    const/4 v4, 0x0

    invoke-virtual {v1, v4}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v5

    if-eqz v5, :cond_37

    .line 642
    nop

    .line 643
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v5, v4}, [Ljava/lang/Object;

    move-result-object v4

    .line 642
    invoke-direct {p0, v2, v4}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 644
    const/4 v0, 0x1

    .line 646
    :cond_37
    if-eqz v1, :cond_91

    invoke-virtual {v1, v3}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v4

    if-eqz v4, :cond_91

    .line 647
    nop

    .line 648
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v4, v5}, [Ljava/lang/Object;

    move-result-object v4

    .line 647
    invoke-direct {p0, v2, v4}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 649
    const/4 v0, 0x1

    .line 650
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mOplusWifiManager:Landroid/net/wifi/OplusWifiManager;

    if-nez v2, :cond_91

    .line 651
    new-instance v2, Landroid/net/wifi/OplusWifiManager;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    invoke-direct {v2, v4}, Landroid/net/wifi/OplusWifiManager;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mOplusWifiManager:Landroid/net/wifi/OplusWifiManager;

    .line 652
    new-instance v2, Lcom/android/server/net/linkpower/monitor/MonitorService$MyWifiEventCallback;

    const/4 v4, 0x0

    invoke-direct {v2, p0, v4}, Lcom/android/server/net/linkpower/monitor/MonitorService$MyWifiEventCallback;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;Lcom/android/server/net/linkpower/monitor/MonitorService-IA;)V

    iput-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mWifiEventCallback:Landroid/net/wifi/OplusWifiEventCallback;

    .line 653
    new-instance v2, Landroid/os/HandlerExecutor;

    new-instance v4, Landroid/os/Handler;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    invoke-direct {v4, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-direct {v2, v4}, Landroid/os/HandlerExecutor;-><init>(Landroid/os/Handler;)V

    .line 655
    .local v2, "executor":Ljava/util/concurrent/Executor;
    :try_start_71
    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mOplusWifiManager:Landroid/net/wifi/OplusWifiManager;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mWifiEventCallback:Landroid/net/wifi/OplusWifiEventCallback;

    invoke-virtual {v4, v2, v5}, Landroid/net/wifi/OplusWifiManager;->setWifiEventCallback(Ljava/util/concurrent/Executor;Landroid/net/wifi/OplusWifiEventCallback;)V
    :try_end_78
    .catch Landroid/os/RemoteException; {:try_start_71 .. :try_end_78} :catch_79

    .line 658
    goto :goto_91

    .line 656
    :catch_79
    move-exception v4

    .line 657
    .local v4, "e":Landroid/os/RemoteException;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "fail to set wifi event callback, e:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 661
    .end local v2    # "executor":Ljava/util/concurrent/Executor;
    .end local v4    # "e":Landroid/os/RemoteException;
    :cond_91
    :goto_91
    if-eqz v0, :cond_a7

    .line 662
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v2

    if-eqz v2, :cond_a0

    .line 663
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeMessages(I)V

    .line 665
    :cond_a0
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    const-wide/16 v4, 0x7530

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    .line 667
    :cond_a7
    return-void
.end method

.method private defaultNetworkOnLost(Landroid/net/Network;)V
    .registers 7
    .param p1, "network"    # Landroid/net/Network;

    .line 670
    if-nez p1, :cond_3

    .line 671
    return-void

    .line 673
    :cond_3
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    if-nez v0, :cond_13

    .line 674
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    const-string v1, "connectivity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    .line 676
    :cond_13
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    invoke-virtual {v0, p1}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v0

    .line 677
    .local v0, "nc":Landroid/net/NetworkCapabilities;
    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eqz v0, :cond_34

    invoke-virtual {v0, v2}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v3

    if-eqz v3, :cond_34

    .line 678
    nop

    .line 679
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v3, v4}, [Ljava/lang/Object;

    move-result-object v3

    .line 678
    invoke-direct {p0, v1, v3}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 681
    :cond_34
    if-eqz v0, :cond_4d

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v4

    if-eqz v4, :cond_4d

    .line 682
    nop

    .line 683
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v2, v3}, [Ljava/lang/Object;

    move-result-object v2

    .line 682
    invoke-direct {p0, v1, v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 685
    :cond_4d
    return-void
.end method

.method private doRusUpdate(Ljava/util/Map;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 831
    .local p1, "data":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    if-eqz p1, :cond_69

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_69

    .line 835
    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "do rus update, data:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-interface {p1}, Ljava/util/Map;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 836
    const-string/jumbo v0, "monitor_enabled"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 837
    .local v0, "monitorEnabledStr":Ljava/lang/String;
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_68

    .line 838
    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v1

    .line 839
    .local v1, "newValue":Z
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "update MonitorEnabled "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mMonitorEnabled:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " to "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogI(Ljava/lang/String;)V

    .line 840
    iget-boolean v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mMonitorEnabled:Z

    if-eq v1, v2, :cond_66

    .line 841
    if-eqz v1, :cond_63

    .line 842
    invoke-virtual {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->init()V

    goto :goto_66

    .line 844
    :cond_63
    invoke-virtual {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->exit()V

    .line 847
    :cond_66
    :goto_66
    iput-boolean v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mMonitorEnabled:Z

    .line 849
    .end local v1    # "newValue":Z
    :cond_68
    return-void

    .line 832
    .end local v0    # "monitorEnabledStr":Ljava/lang/String;
    :cond_69
    :goto_69
    const-string/jumbo v0, "failed to update rus, data is empty!"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 833
    return-void
.end method

.method public static getInstance(Landroid/content/Context;Landroid/os/Looper;)Lcom/android/server/net/linkpower/monitor/MonitorService;
    .registers 4
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "looper"    # Landroid/os/Looper;

    .line 298
    sget-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->sInstance:Lcom/android/server/net/linkpower/monitor/MonitorService;

    if-nez v0, :cond_17

    .line 299
    const-class v0, Lcom/android/server/net/linkpower/monitor/MonitorService;

    monitor-enter v0

    .line 300
    :try_start_7
    sget-object v1, Lcom/android/server/net/linkpower/monitor/MonitorService;->sInstance:Lcom/android/server/net/linkpower/monitor/MonitorService;

    if-nez v1, :cond_12

    .line 301
    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService;

    invoke-direct {v1, p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    sput-object v1, Lcom/android/server/net/linkpower/monitor/MonitorService;->sInstance:Lcom/android/server/net/linkpower/monitor/MonitorService;

    .line 303
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 305
    :cond_17
    :goto_17
    sget-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->sInstance:Lcom/android/server/net/linkpower/monitor/MonitorService;

    return-object v0
.end method

.method private handleEvent(I[Ljava/lang/Object;)V
    .registers 7
    .param p1, "event"    # I
    .param p2, "args"    # [Ljava/lang/Object;

    .line 747
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    if-nez v0, :cond_5

    .line 748
    return-void

    .line 750
    :cond_5
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-virtual {v0}, Lcom/android/server/net/linkpower/include/MonitorComposite;->getChildren()Ljava/util/List;

    move-result-object v0

    .line 751
    .local v0, "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 752
    .local v1, "records":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lcom/android/server/net/linkpower/include/MonitorRecord;>;"
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_14
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_24

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/net/linkpower/include/MonitorComponent;

    .line 753
    .local v3, "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    invoke-virtual {v3, p1, p2}, Lcom/android/server/net/linkpower/include/MonitorComponent;->handleEvent(I[Ljava/lang/Object;)V

    .line 754
    .end local v3    # "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    goto :goto_14

    .line 755
    :cond_24
    return-void
.end method

.method private handleRusUpdate(Ljava/lang/String;)V
    .registers 13
    .param p1, "rus"    # Ljava/lang/String;

    .line 772
    const-string/jumbo v0, "handleRusUpdate"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 774
    :try_start_6
    invoke-static {}, Lorg/xmlpull/v1/XmlPullParserFactory;->newInstance()Lorg/xmlpull/v1/XmlPullParserFactory;

    move-result-object v0

    .line 775
    .local v0, "factory":Lorg/xmlpull/v1/XmlPullParserFactory;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lorg/xmlpull/v1/XmlPullParserFactory;->setNamespaceAware(Z)V

    .line 776
    invoke-virtual {v0}, Lorg/xmlpull/v1/XmlPullParserFactory;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;

    move-result-object v2

    .line 777
    .local v2, "parser":Lorg/xmlpull/v1/XmlPullParser;
    new-instance v3, Ljava/io/StringReader;

    invoke-direct {v3, p1}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    .line 778
    .local v3, "stringReader":Ljava/io/StringReader;
    invoke-interface {v2, v3}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/Reader;)V

    .line 779
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v4

    .line 780
    .local v4, "eventType":I
    const/4 v5, 0x0

    .line 781
    .local v5, "strText":Ljava/lang/String;
    const/4 v6, 0x0

    .line 782
    .local v6, "strName":Ljava/lang/String;
    new-instance v7, Ljava/util/HashMap;

    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 783
    .local v7, "data":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    :goto_25
    if-eq v4, v1, :cond_11f

    .line 784
    packed-switch v4, :pswitch_data_146

    :pswitch_2a
    goto/16 :goto_118

    .line 810
    :pswitch_2c
    sget-object v8, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v8

    const/4 v9, 0x0

    if-eqz v8, :cond_4f

    iget-boolean v8, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusUpdated:Z

    if-eqz v8, :cond_4f

    iget-object v8, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-eqz v8, :cond_4f

    .line 811
    iput-boolean v9, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusUpdated:Z

    .line 812
    iget-object v8, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v9, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda1;

    invoke-direct {v9, p0, v7}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda1;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;Ljava/util/Map;)V

    invoke-virtual {v8, v9}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_118

    .line 816
    :cond_4f
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "failed to handle rus update, isUpdated:"

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-boolean v10, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusUpdated:Z

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, " handler:"

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-object v10, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-eqz v10, :cond_6c

    move v9, v1

    :cond_6c
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 819
    goto/16 :goto_118

    .line 788
    :pswitch_79
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v8

    .line 789
    .end local v6    # "strName":Ljava/lang/String;
    .local v8, "strName":Ljava/lang/String;
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v6

    move v4, v6

    .line 790
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getText()Ljava/lang/String;

    move-result-object v6
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_86} :catch_120

    .line 792
    .end local v5    # "strText":Ljava/lang/String;
    .local v6, "strText":Ljava/lang/String;
    :try_start_86
    const-string/jumbo v5, "version"

    invoke-virtual {v5, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_eb

    .line 793
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 794
    .local v5, "newVersion":I
    iget v9, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusVersion:I

    if-le v5, v9, :cond_cb

    .line 795
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "update "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    sget-object v10, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " rus, version "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget v10, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusVersion:I

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " to "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogI(Ljava/lang/String;)V

    .line 796
    iput v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusVersion:I

    .line 797
    iput-boolean v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRusUpdated:Z

    goto :goto_ea

    .line 799
    :cond_cb
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "failed to update "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    sget-object v10, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " rus, old version!"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 802
    .end local v5    # "newVersion":I
    :goto_ea
    goto :goto_ee

    .line 803
    :cond_eb
    invoke-interface {v7, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_ee
    .catch Ljava/lang/Exception; {:try_start_86 .. :try_end_ee} :catch_ef

    .line 807
    :goto_ee
    goto :goto_114

    .line 805
    :catch_ef
    move-exception v5

    .line 806
    .local v5, "e":Ljava/lang/Exception;
    :try_start_f0
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "failed to parse "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    sget-object v10, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " rus, e:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 808
    .end local v5    # "e":Ljava/lang/Exception;
    nop

    .line 823
    :goto_114
    move-object v5, v6

    move-object v6, v8

    goto :goto_118

    .line 786
    .end local v8    # "strName":Ljava/lang/String;
    .local v5, "strText":Ljava/lang/String;
    .local v6, "strName":Ljava/lang/String;
    :pswitch_117
    nop

    .line 823
    :goto_118
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v8
    :try_end_11c
    .catch Ljava/lang/Exception; {:try_start_f0 .. :try_end_11c} :catch_120

    move v4, v8

    goto/16 :goto_25

    .line 827
    .end local v0    # "factory":Lorg/xmlpull/v1/XmlPullParserFactory;
    .end local v2    # "parser":Lorg/xmlpull/v1/XmlPullParser;
    .end local v3    # "stringReader":Ljava/io/StringReader;
    .end local v4    # "eventType":I
    .end local v5    # "strText":Ljava/lang/String;
    .end local v6    # "strName":Ljava/lang/String;
    .end local v7    # "data":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    :cond_11f
    goto :goto_144

    .line 825
    :catch_120
    move-exception v0

    .line 826
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "failed to handle "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " rus update, e:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 828
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_144
    return-void

    nop

    :pswitch_data_146
    .packed-switch 0x0
        :pswitch_117
        :pswitch_2a
        :pswitch_79
        :pswitch_2c
    .end packed-switch
.end method

.method private handleSceneChanged(II)V
    .registers 6
    .param p1, "settleType"    # I
    .param p2, "state"    # I

    .line 561
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "handleSceneChanged in settleType "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " state is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 562
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-eqz v0, :cond_6e

    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_32

    goto :goto_6e

    .line 565
    :cond_32
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 566
    .local v0, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    if-nez v0, :cond_41

    .line 567
    return-void

    .line 569
    :cond_41
    const/4 v1, 0x1

    if-ne p2, v1, :cond_48

    .line 570
    invoke-virtual {v0, v1}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->setRunning(Z)V

    goto :goto_6d

    .line 571
    :cond_48
    const/4 v1, 0x2

    if-ne p2, v1, :cond_50

    .line 572
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->setRunning(Z)V

    goto :goto_6d

    .line 574
    :cond_50
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "unknown settle state:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "!"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 577
    :goto_6d
    return-void

    .line 563
    .end local v0    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    :cond_6e
    :goto_6e
    return-void
.end method

.method private synthetic lambda$dailyReport$4()V
    .registers 1

    .line 526
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->resetAndUpload()V

    .line 527
    return-void
.end method

.method private synthetic lambda$handleRusUpdate$9(Ljava/util/Map;)V
    .registers 2
    .param p1, "data"    # Ljava/util/Map;

    .line 813
    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->doRusUpdate(Ljava/util/Map;)V

    .line 814
    return-void
.end method

.method private synthetic lambda$loopTick$3()V
    .registers 7

    .line 512
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 513
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mCommSceneListener:Lcom/oplus/commscene/CommSceneListener;

    if-eqz v0, :cond_26

    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mCommSceneListener:Lcom/oplus/commscene/CommSceneListener;

    const/16 v1, 0x3e9

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/oplus/commscene/CommSceneListener;->inquireSceneState(II)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_26

    .line 515
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 516
    .local v0, "now":J
    iget-wide v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mScreenOffStamp:J

    sub-long v2, v0, v2

    const-wide/32 v4, 0xdbba0

    cmp-long v2, v2, v4

    if-ltz v2, :cond_26

    .line 517
    const/4 v2, 0x2

    invoke-direct {p0, v2, v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 520
    .end local v0    # "now":J
    :cond_26
    return-void
.end method

.method private synthetic lambda$new$0(Ljava/lang/String;)V
    .registers 2
    .param p1, "rus"    # Ljava/lang/String;

    .line 294
    invoke-direct {p0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleRusUpdate(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$registerPushProcChanged$6(ZLjava/util/function/Consumer;)V
    .registers 5
    .param p1, "register"    # Z
    .param p2, "consumer"    # Ljava/util/function/Consumer;

    .line 544
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    filled-new-array {v0, p2}, [Ljava/lang/Object;

    move-result-object v0

    const/16 v1, 0x11

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 545
    return-void
.end method

.method private synthetic lambda$registerSkConnectChanged$7(ZLjava/util/function/Consumer;)V
    .registers 5
    .param p1, "register"    # Z
    .param p2, "consumer"    # Ljava/util/function/Consumer;

    .line 550
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    filled-new-array {v0, p2}, [Ljava/lang/Object;

    move-result-object v0

    const/16 v1, 0x12

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 551
    return-void
.end method

.method private synthetic lambda$requestSkConnectInfo$8(II)V
    .registers 5
    .param p1, "uid"    # I
    .param p2, "pid"    # I

    .line 556
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    const/16 v1, 0x13

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 557
    return-void
.end method

.method private synthetic lambda$screenOff$2()V
    .registers 4

    .line 497
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mScreenOffStamp:J

    .line 498
    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/16 v2, 0xf

    invoke-direct {p0, v2, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 499
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 500
    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, v1, v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 501
    invoke-direct {p0, v0, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 502
    invoke-direct {p0, v2, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 503
    return-void
.end method

.method private synthetic lambda$screenOn$1()V
    .registers 4

    .line 482
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/16 v2, 0xf

    invoke-direct {p0, v2, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleEvent(I[Ljava/lang/Object;)V

    .line 483
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 484
    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 485
    const/4 v0, 0x2

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 486
    invoke-direct {p0, v0, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 487
    return-void
.end method

.method private synthetic lambda$toLog$5()V
    .registers 4

    .line 533
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-eqz v0, :cond_24

    .line 534
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_24

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 535
    .local v1, "entry":Ljava/util/Map$Entry;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 536
    .local v2, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    invoke-virtual {v2}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->toLog()V

    .line 537
    .end local v1    # "entry":Ljava/util/Map$Entry;
    .end local v2    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    goto :goto_e

    .line 539
    :cond_24
    return-void
.end method

.method private static myLogD(Ljava/lang/String;)V
    .registers 2
    .param p0, "log"    # Ljava/lang/String;

    .line 926
    sget-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-static {v0, p0}, Lcom/android/server/net/linkpower/helper/LinkPowerLogHelper;->myLogD(Ljava/lang/String;Ljava/lang/String;)V

    .line 927
    return-void
.end method

.method private static myLogE(Ljava/lang/String;)V
    .registers 2
    .param p0, "log"    # Ljava/lang/String;

    .line 930
    sget-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-static {v0, p0}, Lcom/android/server/net/linkpower/helper/LinkPowerLogHelper;->myLogE(Ljava/lang/String;Ljava/lang/String;)V

    .line 931
    return-void
.end method

.method private static myLogI(Ljava/lang/String;)V
    .registers 2
    .param p0, "log"    # Ljava/lang/String;

    .line 922
    sget-object v0, Lcom/android/server/net/linkpower/monitor/MonitorService;->TAG:Ljava/lang/String;

    invoke-static {v0, p0}, Lcom/android/server/net/linkpower/helper/LinkPowerLogHelper;->myLogI(Ljava/lang/String;Ljava/lang/String;)V

    .line 923
    return-void
.end method

.method private resetAndUpload()V
    .registers 6

    .line 758
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-eqz v0, :cond_3a

    .line 759
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 760
    .local v1, "entry":Ljava/util/Map$Entry;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 761
    .local v2, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    if-nez v2, :cond_23

    .line 762
    goto :goto_e

    .line 764
    :cond_23
    invoke-virtual {v2}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->getRunning()Z

    move-result v3

    .line 765
    .local v3, "running":Z
    invoke-virtual {v2}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->stop()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->upload()V

    .line 766
    invoke-virtual {v2}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->clear()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->setRunning(Z)V

    .line 767
    .end local v1    # "entry":Ljava/util/Map$Entry;
    .end local v2    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    .end local v3    # "running":Z
    goto :goto_e

    .line 769
    :cond_3a
    return-void
.end method

.method private updateActiveMonitors()V
    .registers 7

    .line 580
    const-string/jumbo v0, "updateActiveMonitors"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 581
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    if-eqz v0, :cond_e1

    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_14

    goto/16 :goto_e1

    .line 584
    :cond_14
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    if-nez v0, :cond_24

    .line 585
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    const-string v1, "connectivity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    .line 587
    :cond_24
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v0

    .line 588
    .local v0, "networkInfo":Landroid/net/NetworkInfo;
    const/4 v1, -0x1

    .line 589
    .local v1, "networkType":I
    if-eqz v0, :cond_37

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->isAvailable()Z

    move-result v2

    if-eqz v2, :cond_37

    .line 590
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getType()I

    move-result v1

    .line 593
    :cond_37
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    .line 594
    .local v2, "removeMonitors":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    const/4 v3, 0x1

    if-ne v1, v3, :cond_6d

    .line 595
    const-string v3, "data_traffic"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 596
    const-string v3, "data_in_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 597
    const-string v3, "data_out_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 598
    const-string v3, "data_wakeup_duration"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 599
    const-string v3, "data_im_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 600
    const-string v3, "data_align_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 601
    const-string v3, "data_keep_alive_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 602
    const-string v3, "data_re_in_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 603
    const-string v3, "data_re_out_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_a3

    .line 605
    :cond_6d
    const-string/jumbo v3, "wifi_traffic"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 606
    const-string/jumbo v3, "wifi_in_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 607
    const-string/jumbo v3, "wifi_out_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 608
    const-string/jumbo v3, "wifi_wakeup_duration"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 609
    const-string/jumbo v3, "wifi_im_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 610
    const-string/jumbo v3, "wifi_align_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 611
    const-string/jumbo v3, "wifi_keep_alive_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 612
    const-string/jumbo v3, "wifi_re_in_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 613
    const-string/jumbo v3, "wifi_re_out_wakeup"

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 616
    :goto_a3
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    if-nez v3, :cond_ae

    .line 617
    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    .line 619
    :cond_ae
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    invoke-interface {v3}, Ljava/util/Set;->clear()V

    .line 620
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    invoke-interface {v3, v4}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 621
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    invoke-interface {v3, v2}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    .line 623
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 624
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    if-eqz v3, :cond_e0

    .line 625
    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-virtual {v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->getChildren()Ljava/util/List;

    move-result-object v3

    .line 626
    .local v3, "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_d0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_e0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/net/linkpower/include/MonitorComponent;

    .line 627
    .local v5, "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    invoke-virtual {v5, v2}, Lcom/android/server/net/linkpower/include/MonitorComponent;->destroyRecord(Ljava/util/Set;)V

    .line 628
    .end local v5    # "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    goto :goto_d0

    .line 630
    .end local v3    # "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    :cond_e0
    return-void

    .line 582
    .end local v0    # "networkInfo":Landroid/net/NetworkInfo;
    .end local v1    # "networkType":I
    .end local v2    # "removeMonitors":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    :cond_e1
    :goto_e1
    return-void
.end method

.method private updateRecords()V
    .registers 7

    .line 713
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    if-nez v0, :cond_b

    .line 714
    const-string/jumbo v0, "updateRecords mRootComposite is null!"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 715
    return-void

    .line 717
    :cond_b
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    if-nez v0, :cond_16

    .line 718
    const-string/jumbo v0, "updateRecords mActiveMonitors is null!"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 719
    return-void

    .line 721
    :cond_16
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-virtual {v0}, Lcom/android/server/net/linkpower/include/MonitorComposite;->getChildren()Ljava/util/List;

    move-result-object v0

    .line 722
    .local v0, "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 723
    .local v1, "records":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lcom/android/server/net/linkpower/include/MonitorRecord;>;"
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_25
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_46

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/net/linkpower/include/MonitorComponent;

    .line 724
    .local v3, "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    invoke-virtual {v3, v4}, Lcom/android/server/net/linkpower/include/MonitorComponent;->requestRecords(Ljava/util/Set;)Ljava/util/Map;

    move-result-object v4

    .line 725
    .local v4, "r":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lcom/android/server/net/linkpower/include/MonitorRecord;>;"
    invoke-virtual {v3}, Lcom/android/server/net/linkpower/include/MonitorComponent;->updateRecords()V

    .line 726
    if-eqz v4, :cond_45

    invoke-interface {v4}, Ljava/util/Map;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_45

    .line 727
    invoke-interface {v1, v4}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    .line 729
    .end local v3    # "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    .end local v4    # "r":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lcom/android/server/net/linkpower/include/MonitorRecord;>;"
    :cond_45
    goto :goto_25

    .line 730
    :cond_46
    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_53

    .line 731
    const-string/jumbo v2, "updateRecords records is null!"

    invoke-static {v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 732
    return-void

    .line 735
    :cond_53
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-eqz v2, :cond_77

    .line 736
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_61
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_77

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 737
    .local v3, "entry":Ljava/util/Map$Entry;
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 738
    .local v4, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    invoke-virtual {v4, v1}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->addRecords(Ljava/util/Map;)V

    .line 739
    .end local v3    # "entry":Ljava/util/Map$Entry;
    .end local v4    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    goto :goto_61

    .line 741
    :cond_77
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    if-eqz v2, :cond_80

    .line 742
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-virtual {v2, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;->notifyRecords(Ljava/util/Map;)V

    .line 744
    :cond_80
    return-void
.end method


# virtual methods
.method public addListenRecords(Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;Ljava/util/Set;)V
    .registers 5
    .param p1, "callback"    # Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 688
    .local p2, "monitors":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "addListenRecords monitors is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-interface {p2}, Ljava/util/Set;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 689
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    if-nez v0, :cond_26

    .line 690
    new-instance v0, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-direct {v0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;Ljava/util/Set;)V

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    .line 691
    return-void

    .line 693
    :cond_26
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-virtual {v0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;->equals(Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;)Z

    move-result v0

    if-nez v0, :cond_2f

    .line 694
    return-void

    .line 697
    :cond_2f
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-virtual {v0, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;->addMonitors(Ljava/util/Set;)V

    .line 698
    return-void
.end method

.method public dailyReport()V
    .registers 3

    .line 524
    const-string v0, "dailyReport"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 525
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 528
    return-void
.end method

.method public dump(Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 10
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;

    .line 876
    if-eqz p1, :cond_d3

    if-nez p2, :cond_6

    goto/16 :goto_d3

    .line 879
    :cond_6
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-nez v0, :cond_11

    .line 880
    const-string/jumbo v0, "monitor service handler is null!"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 881
    return-void

    .line 883
    :cond_11
    array-length v0, p2

    const/4 v1, 0x4

    if-ne v0, v1, :cond_d2

    .line 884
    const/4 v0, 0x0

    .line 885
    .local v0, "actived":Z
    const/4 v1, 0x2

    aget-object v2, p2, v1

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v3

    const/4 v4, 0x1

    sparse-switch v3, :sswitch_data_d4

    :cond_21
    goto :goto_38

    :sswitch_22
    const-string/jumbo v3, "test_event_add"

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x0

    goto :goto_39

    :sswitch_2d
    const-string/jumbo v3, "test_event_active"

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    move v2, v4

    goto :goto_39

    :goto_38
    const/4 v2, -0x1

    :goto_39
    const/4 v3, 0x3

    packed-switch v2, :pswitch_data_de

    .line 915
    const-string/jumbo v1, "monitor unknown cmd!"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    goto/16 :goto_d2

    .line 904
    :pswitch_45
    aget-object v2, p2, v3

    invoke-static {v2}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    .line 905
    if-eqz v0, :cond_56

    .line 906
    invoke-direct {p0, v3, v4}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 907
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-virtual {v1, v4}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_5c

    .line 909
    :cond_56
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 910
    invoke-direct {p0, v3, v1}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 912
    :goto_5c
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "set monitor test_event_active to "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 913
    goto :goto_d2

    .line 887
    :pswitch_74
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-nez v1, :cond_7f

    .line 888
    const-string/jumbo v1, "monitor mSceneObjMap is null!"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 889
    goto :goto_d2

    .line 891
    :cond_7f
    aget-object v1, p2, v3

    invoke-static {v1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    .line 892
    if-eqz v0, :cond_a0

    .line 893
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    new-instance v4, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    sget-object v6, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    aget-object v3, v6, v3

    invoke-direct {v4, v5, v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_ba

    .line 895
    :cond_a0
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 896
    .local v1, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    if-eqz v1, :cond_ba

    .line 897
    invoke-virtual {v1}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->clear()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 898
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 901
    .end local v1    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    :cond_ba
    :goto_ba
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "set monitor test_event_add to "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 902
    nop

    .line 919
    .end local v0    # "actived":Z
    :cond_d2
    :goto_d2
    return-void

    .line 877
    :cond_d3
    :goto_d3
    return-void

    :sswitch_data_d4
    .sparse-switch
        -0x1c419528 -> :sswitch_2d
        0x7c46e0f -> :sswitch_22
    .end sparse-switch

    :pswitch_data_de
    .packed-switch 0x0
        :pswitch_74
        :pswitch_45
    .end packed-switch
.end method

.method public exit()V
    .registers 6

    .line 424
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    const/4 v1, 0x0

    if-eqz v0, :cond_35

    .line 425
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 426
    .local v2, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;>;"
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 427
    .local v3, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    if-eqz v3, :cond_2d

    .line 428
    invoke-virtual {v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->upload()V

    .line 429
    invoke-virtual {v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->stop()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->clear()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 431
    .end local v2    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;>;"
    .end local v3    # "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    :cond_2d
    goto :goto_f

    .line 432
    :cond_2e
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 433
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    .line 436
    :cond_35
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    if-eqz v0, :cond_67

    .line 437
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    if-eqz v0, :cond_60

    .line 438
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-virtual {v0}, Lcom/android/server/net/linkpower/include/MonitorComposite;->getChildren()Ljava/util/List;

    move-result-object v0

    .line 439
    .local v0, "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_47
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_59

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/net/linkpower/include/MonitorComponent;

    .line 440
    .local v3, "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    invoke-virtual {v3, v4}, Lcom/android/server/net/linkpower/include/MonitorComponent;->destroyRecord(Ljava/util/Set;)V

    .line 441
    .end local v3    # "leaf":Lcom/android/server/net/linkpower/include/MonitorComponent;
    goto :goto_47

    .line 442
    :cond_59
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    .line 443
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    .line 445
    .end local v0    # "leafs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/net/linkpower/include/MonitorComponent;>;"
    :cond_60
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-virtual {v0}, Lcom/android/server/net/linkpower/include/MonitorComposite;->clear()V

    .line 446
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    .line 448
    :cond_67
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    if-eqz v0, :cond_72

    .line 449
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 450
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mActiveMonitors:Ljava/util/Set;

    .line 453
    :cond_72
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mBroadcastReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_7f

    .line 454
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mBroadcastReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 455
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mBroadcastReceiver:Landroid/content/BroadcastReceiver;

    .line 458
    :cond_7f
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    if-nez v0, :cond_8f

    .line 459
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    const-string v2, "connectivity"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    .line 461
    :cond_8f
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    if-eqz v0, :cond_9c

    .line 462
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    invoke-virtual {v0, v2}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 463
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 466
    :cond_9c
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mUidObserver:Landroid/app/IUidObserver;

    if-eqz v0, :cond_c4

    .line 468
    :try_start_a0
    invoke-static {}, Landroid/app/ActivityManager;->getService()Landroid/app/IActivityManager;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mUidObserver:Landroid/app/IUidObserver;

    invoke-interface {v0, v2}, Landroid/app/IActivityManager;->unregisterUidObserver(Landroid/app/IUidObserver;)V
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_a0 .. :try_end_a9} :catch_aa

    .line 471
    goto :goto_c2

    .line 469
    :catch_aa
    move-exception v0

    .line 470
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "failed to unregister uid observer, e:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 472
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_c2
    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mUidObserver:Landroid/app/IUidObserver;

    .line 474
    :cond_c4
    return-void
.end method

.method public init()V
    .registers 9

    .line 309
    invoke-virtual {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->exit()V

    .line 310
    new-instance v0, Lcom/oplus/commscene/CommSceneListener;

    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-direct {v0, v1}, Lcom/oplus/commscene/CommSceneListener;-><init>(Landroid/os/Handler;)V

    iput-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mCommSceneListener:Lcom/oplus/commscene/CommSceneListener;

    .line 312
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 313
    .local v0, "filter":Landroid/content/IntentFilter;
    const-string v1, "android.intent.action.DATE_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 314
    const-string/jumbo v1, "oplus.intent.action.WDC_INFO_TO_LINKPOWER"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 315
    const-string/jumbo v1, "oplus.intent.action.MDPWR_UPDATE_TRAFFIC_KERNEL_INFO"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 316
    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$2;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$2;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mBroadcastReceiver:Landroid/content/BroadcastReceiver;

    .line 347
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mBroadcastReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 349
    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$3;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$3;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 359
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    if-nez v1, :cond_47

    .line 360
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    const-string v2, "connectivity"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/ConnectivityManager;

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    .line 362
    :cond_47
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mConnectivityManager:Landroid/net/ConnectivityManager;

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mNetworkCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    iget-object v3, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-virtual {v1, v2, v3}, Landroid/net/ConnectivityManager;->registerDefaultNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;Landroid/os/Handler;)V

    .line 364
    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$4;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$4;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mUidObserver:Landroid/app/IUidObserver;

    .line 391
    :try_start_57
    invoke-static {}, Landroid/app/ActivityManager;->getService()Landroid/app/IActivityManager;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mUidObserver:Landroid/app/IUidObserver;

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/16 v5, 0xe

    invoke-interface {v1, v2, v5, v3, v4}, Landroid/app/IActivityManager;->registerUidObserver(Landroid/app/IUidObserver;IILjava/lang/String;)V
    :try_end_64
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_64} :catch_65

    .line 397
    goto :goto_7d

    .line 395
    :catch_65
    move-exception v1

    .line 396
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "failed to register uid observer, e:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogE(Ljava/lang/String;)V

    .line 399
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_7d
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSupportMonitors:Ljava/util/Set;

    .line 401
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    .line 402
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    new-instance v4, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    sget-object v6, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    aget-object v2, v6, v2

    invoke-direct {v4, v5, v2}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v2

    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    new-instance v4, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    sget-object v6, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    aget-object v6, v6, v2

    invoke-direct {v4, v5, v6}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v4}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v4

    invoke-interface {v1, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 404
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    const/4 v3, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    iget-object v6, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    sget-object v7, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    aget-object v3, v7, v3

    invoke-direct {v5, v6, v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v3

    invoke-interface {v1, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 405
    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$5;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$5;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    .line 411
    new-instance v1, Lcom/android/server/net/linkpower/include/MonitorComposite;

    invoke-direct {v1}, Lcom/android/server/net/linkpower/include/MonitorComposite;-><init>()V

    iput-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    .line 412
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/monitor/MonitorLeafData;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    invoke-direct {v3, v4}, Lcom/android/server/net/linkpower/monitor/MonitorLeafData;-><init>(Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 413
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/monitor/MonitorLeafWiFi;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    invoke-direct {v3, v4}, Lcom/android/server/net/linkpower/monitor/MonitorLeafWiFi;-><init>(Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 414
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/monitor/MonitorLeafBluetooth;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    invoke-direct {v3, v4}, Lcom/android/server/net/linkpower/monitor/MonitorLeafBluetooth;-><init>(Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 415
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafKernelWakeup;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    invoke-direct {v3, v4, v5}, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafKernelWakeup;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 416
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafBpfWakeup;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    invoke-direct {v3, v4, v5}, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafBpfWakeup;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 417
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafAppTraffic;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    invoke-direct {v3, v4, v5}, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafAppTraffic;-><init>(Landroid/content/Context;Landroid/os/Looper;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 418
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafPushSock;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    iget-object v6, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    invoke-direct {v3, v4, v5, v6}, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafPushSock;-><init>(Landroid/content/Context;Landroid/os/Looper;Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 419
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRootComposite:Lcom/android/server/net/linkpower/include/MonitorComposite;

    new-instance v3, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafSockConnect;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mLooper:Landroid/os/Looper;

    iget-object v6, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mComponentCallback:Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;

    invoke-direct {v3, v4, v5, v6}, Lcom/android/server/net/linkpower/nwmonitor/MonitorLeafSockConnect;-><init>(Landroid/content/Context;Landroid/os/Looper;Lcom/android/server/net/linkpower/include/MonitorComponent$MyCallback;)V

    invoke-virtual {v1, v3}, Lcom/android/server/net/linkpower/include/MonitorComposite;->add(Lcom/android/server/net/linkpower/include/MonitorComponent;)V

    .line 420
    iget-object v1, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 421
    return-void
.end method

.method public loopTick()V
    .registers 3

    .line 507
    const-string/jumbo v0, "loopTick in"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 508
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-nez v0, :cond_b

    .line 509
    return-void

    .line 511
    :cond_b
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda6;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 521
    return-void
.end method

.method public registerPushProcChanged(ZLjava/util/function/Consumer;)V
    .registers 5
    .param p1, "register"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 543
    .local p2, "consumer":Ljava/util/function/Consumer;, "Ljava/util/function/Consumer<Ljava/lang/Object;>;"
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda9;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;ZLjava/util/function/Consumer;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 546
    return-void
.end method

.method public registerSkConnectChanged(ZLjava/util/function/Consumer;)V
    .registers 5
    .param p1, "register"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/util/function/Consumer<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 549
    .local p2, "consumer":Ljava/util/function/Consumer;, "Ljava/util/function/Consumer<Ljava/lang/Object;>;"
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda3;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;ZLjava/util/function/Consumer;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 552
    return-void
.end method

.method public removeListenRecords(Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;Ljava/util/Set;)V
    .registers 5
    .param p1, "callback"    # Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 701
    .local p2, "monitors":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "removeListenRecords monitors is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-interface {p2}, Ljava/util/Set;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 702
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    if-nez v0, :cond_20

    .line 703
    return-void

    .line 705
    :cond_20
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-virtual {v0, p1}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;->equals(Lcom/android/server/net/linkpower/monitor/MonitorService$MyCallback;)Z

    move-result v0

    if-nez v0, :cond_29

    .line 706
    return-void

    .line 709
    :cond_29
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mRecordListener:Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;

    invoke-virtual {v0, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$Listener;->removeMonitors(Ljava/util/Set;)V

    .line 710
    return-void
.end method

.method public requestSkConnectInfo(II)V
    .registers 5
    .param p1, "uid"    # I
    .param p2, "pid"    # I

    .line 555
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1, p2}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda7;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;II)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 558
    return-void
.end method

.method public screenOff()V
    .registers 3

    .line 491
    const-string/jumbo v0, "screenOff in"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 492
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-nez v0, :cond_b

    .line 493
    return-void

    .line 496
    :cond_b
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda8;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 504
    return-void
.end method

.method public screenOn()V
    .registers 3

    .line 477
    const-string/jumbo v0, "screenOn in"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 478
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    if-nez v0, :cond_b

    .line 479
    return-void

    .line 481
    :cond_b
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda5;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 488
    return-void
.end method

.method public startReporAppInfo()V
    .registers 7

    .line 852
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-nez v0, :cond_5

    .line 853
    return-void

    .line 855
    :cond_5
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    const/4 v1, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    new-instance v3, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    iget-object v4, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mContext:Landroid/content/Context;

    sget-object v5, Lcom/android/server/net/linkpower/monitor/MonitorService;->SETTLE_NAME:[Ljava/lang/String;

    aget-object v5, v5, v1

    invoke-direct {v3, v4, v5}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->start()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    move-result-object v3

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 856
    const-string v0, "StratReportAppInfo"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogI(Ljava/lang/String;)V

    .line 857
    const/4 v0, 0x1

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 858
    return-void
.end method

.method public stopReportAppInfo()V
    .registers 4

    .line 861
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    if-nez v0, :cond_5

    .line 862
    return-void

    .line 864
    :cond_5
    const-string/jumbo v0, "stopReportAppInfo"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogI(Ljava/lang/String;)V

    .line 865
    invoke-direct {p0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->updateRecords()V

    .line 866
    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, v1, v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->handleSceneChanged(II)V

    .line 867
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 868
    .local v0, "obj":Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;
    if-eqz v0, :cond_30

    .line 869
    invoke-virtual {v0}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->uploadAppInfo()V

    .line 870
    invoke-virtual {v0}, Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;->clear()Lcom/android/server/net/linkpower/monitor/MonitorSceneObj;

    .line 871
    iget-object v2, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mSceneObjMap:Ljava/util/Map;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 873
    :cond_30
    return-void
.end method

.method public toLog()V
    .registers 3

    .line 531
    const-string/jumbo v0, "toLog"

    invoke-static {v0}, Lcom/android/server/net/linkpower/monitor/MonitorService;->myLogD(Ljava/lang/String;)V

    .line 532
    iget-object v0, p0, Lcom/android/server/net/linkpower/monitor/MonitorService;->mHandler:Landroid/os/Handler;

    new-instance v1, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcom/android/server/net/linkpower/monitor/MonitorService$$ExternalSyntheticLambda2;-><init>(Lcom/android/server/net/linkpower/monitor/MonitorService;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 540
    return-void
.end method
