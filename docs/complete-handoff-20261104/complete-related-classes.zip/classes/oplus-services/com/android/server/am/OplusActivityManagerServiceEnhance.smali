.class public final Lcom/android/server/am/OplusActivityManagerServiceEnhance;
.super Landroid/app/IOplusActivityManager$Stub;
.source "OplusActivityManagerServiceEnhance.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/am/OplusActivityManagerServiceEnhance$CpuFilter;
    }
.end annotation


# static fields
.field private static final ACTION_READ_PAYJOY_FLAG:I = 0xf42b7

.field private static final ANDROID_M_CPU_UNIT_DEN:I = 0xa

.field private static final CPU_FILE_PATH:Ljava/lang/String;

.field private static DEBUG:Z = false

.field private static final GET_PKG_PRELOAD_FILES_TRANSACTION_FOR_NATIVIE:I = 0x2713

.field private static final GET_TASK_TRACKER_INFO:I = 0x2715

.field private static final HANS_NATIVE_UNFREEZE1_TRANSACTION:I = 0x2739

.field private static final HANS_NATIVE_UNFREEZE_TRANSACTION:I = 0x2738

.field private static final HANS_UNFREEZE_APP_FOR_INPUTDISPATCHER:I = 0x271a

.field private static final NOTIFY_FRAME_STATE_TO_STARTING_WINDOWS:I = 0x2716

.field private static final SET_GL_THREADS_TRANSACTION_FOR_NATIVIE:I = 0x2712

.field private static final SET_HWUI_TASK_THREADS_TRANSACTION_FOR_NATIVIE:I = 0x2711

.field private static final SET_KEY_THREADS_TRANSACTION_FOR_NATIVIE:I = 0x2719

.field private static final START_TASK_TRACKER:I = 0x2714

.field private static final TAG:Ljava/lang/String; = "OplusActivityManagerServiceEnhance"

.field private static final TASK_TRACKER_GROUP_RENDER:I = 0x2

.field private static final TASK_TRACKER_GROUP_UI:I = 0x1

.field private static final TRANSACTIONCODE_FOR_NATIVIE:I = 0x2710


# instance fields
.field private final mAms:Lcom/android/server/am/ActivityManagerService;

.field private final mAmsEx:Lcom/android/server/am/IOplusActivityManagerServiceEx;

.field private mContext:Landroid/content/Context;

.field private mCoreNum:I

.field private mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

.field private mDirectHelper:Lcom/android/server/am/ColorDirectActivityHelper;

.field private mFontVariationAdaptionUtils:Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;

.field private final mLock:Ljava/lang/Object;

.field private mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

.field private mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

.field private mOsenseClient:Lcom/oplus/osense/OsenseResClient;

.field mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

.field private mSecureKeyboardUtils:Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;

.field private mTotalSampleInterval:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 214
    const-string/jumbo v0, "persist.sys.assert.owmsen"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    .line 218
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/sys/devices/system/cpu"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->CPU_FILE_PATH:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V
    .registers 7
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p3, "amsEx"    # Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 248
    invoke-direct {p0}, Landroid/app/IOplusActivityManager$Stub;-><init>()V

    .line 220
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mLock:Ljava/lang/Object;

    .line 223
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    .line 224
    const/4 v1, 0x1

    iput v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCoreNum:I

    .line 225
    const-wide/16 v1, 0x1

    iput-wide v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    .line 226
    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    .line 239
    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    .line 246
    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    .line 249
    iput-object p2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    .line 250
    iput-object p3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAmsEx:Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 251
    iput-object p1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    .line 254
    new-instance v0, Lcom/android/server/am/ColorDirectActivityHelper;

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-direct {v0, v1, v2}, Lcom/android/server/am/ColorDirectActivityHelper;-><init>(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;)V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mDirectHelper:Lcom/android/server/am/ColorDirectActivityHelper;

    .line 258
    new-instance v0, Lcom/android/server/am/OplusUidCpuTimeReader;

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/android/server/am/OplusUidCpuTimeReader;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

    .line 260
    return-void
.end method

.method private getAllCoreNum()I
    .registers 7

    .line 1028
    const-string v0, "OplusActivityManagerServiceEnhance"

    const/4 v1, 0x1

    :try_start_3
    new-instance v2, Ljava/io/File;

    sget-object v3, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->CPU_FILE_PATH:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 1029
    .local v2, "dir":Ljava/io/File;
    new-instance v3, Lcom/android/server/am/OplusActivityManagerServiceEnhance$CpuFilter;

    invoke-direct {v3}, Lcom/android/server/am/OplusActivityManagerServiceEnhance$CpuFilter;-><init>()V

    invoke-virtual {v2, v3}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v3

    .line 1030
    .local v3, "files":[Ljava/io/File;
    if-nez v3, :cond_1c

    .line 1031
    const-string/jumbo v4, "files is null."

    invoke-static {v0, v4}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1032
    return v1

    .line 1034
    :cond_1c
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "CPU Count: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    array-length v5, v3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1035
    array-length v0, v3
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_34} :catch_35

    return v0

    .line 1036
    .end local v2    # "dir":Ljava/io/File;
    .end local v3    # "files":[Ljava/io/File;
    :catch_35
    move-exception v2

    .line 1037
    .local v2, "e":Ljava/lang/Exception;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "CPU Count: Failed. e ="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1038
    return v1
.end method

.method private isProcessRunningInner(ILjava/lang/String;)Z
    .registers 10
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;

    .line 2147
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v0

    .line 2148
    :try_start_6
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v1, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ProcessList;->getUidRecordLOSP(I)Lcom/android/server/am/UidRecord;

    move-result-object v1

    .line 2149
    .local v1, "uRecord":Lcom/android/server/am/UidRecord;
    if-eqz v1, :cond_4a

    .line 2150
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_11
    invoke-virtual {v1}, Lcom/android/server/am/UidRecord;->getNumOfProcs()I

    move-result v3

    if-ge v2, v3, :cond_4a

    .line 2151
    invoke-virtual {v1, v2}, Lcom/android/server/am/UidRecord;->getProcessRecordByIndex(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v3

    .line 2152
    .local v3, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v3, :cond_47

    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->getThread()Landroid/app/IApplicationThread;

    move-result-object v4

    if-eqz v4, :cond_47

    .line 2153
    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v4

    if-nez v4, :cond_47

    .line 2155
    const/4 v4, 0x1

    if-nez p2, :cond_31

    .line 2156
    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_6 .. :try_end_2d} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    return v4

    .line 2159
    :cond_31
    :try_start_31
    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->getPkgList()Lcom/android/server/am/PackageList;

    move-result-object v5

    new-instance v6, Lcom/android/server/am/OplusActivityManagerServiceEnhance$$ExternalSyntheticLambda0;

    invoke-direct {v6, p2}, Lcom/android/server/am/OplusActivityManagerServiceEnhance$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Lcom/android/server/am/PackageList;->searchEachPackage(Ljava/util/function/Function;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 2165
    .local v5, "result":Ljava/lang/String;
    if-eqz v5, :cond_47

    .line 2166
    monitor-exit v0
    :try_end_43
    .catchall {:try_start_31 .. :try_end_43} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    return v4

    .line 2150
    .end local v3    # "proc":Lcom/android/server/am/ProcessRecord;
    .end local v5    # "result":Ljava/lang/String;
    :cond_47
    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    .line 2171
    .end local v1    # "uRecord":Lcom/android/server/am/UidRecord;
    .end local v2    # "i":I
    :cond_4a
    :try_start_4a
    monitor-exit v0
    :try_end_4b
    .catchall {:try_start_4a .. :try_end_4b} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 2172
    const/4 v0, 0x0

    return v0

    .line 2171
    :catchall_50
    move-exception v1

    :try_start_51
    monitor-exit v0
    :try_end_52
    .catchall {:try_start_51 .. :try_end_52} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v1
.end method

.method static synthetic lambda$getProcCmdline$0(II)Z
    .registers 3
    .param p0, "callingPid"    # I
    .param p1, "pid"    # I

    .line 1120
    if-eq p1, p0, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method static synthetic lambda$isProcessRunningInner$1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p0, "pkgName"    # Ljava/lang/String;
    .param p1, "pkg"    # Ljava/lang/String;

    .line 2160
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 2161
    return-object p0

    .line 2163
    :cond_7
    const/4 v0, 0x0

    return-object v0
.end method

.method private sparseArrayLongToString(Landroid/util/SparseArray;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1341
    .local p1, "arrays":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/Long;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1342
    .local v0, "builder":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_6
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_2b

    .line 1343
    if-lez v1, :cond_13

    .line 1344
    const-string v2, ";"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1346
    :cond_13
    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1342
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 1348
    .end local v1    # "i":I
    :cond_2b
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-nez v1, :cond_36

    .line 1349
    const-string v1, "empty"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1351
    :cond_36
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method


# virtual methods
.method public activeGc([I)V
    .registers 5
    .param p1, "pid"    # [I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1142
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "activeGc"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1145
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_1a

    .line 1148
    const-string v0, "OplusActivityManagerServiceEnhance"

    const-string v1, "activeGc is deprecated interface, nothing will happened when called"

    invoke-static {v0, v1}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1149
    return-void

    .line 1146
    :cond_1a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "only allow system uid"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public addBackgroundRestrictedInfo(Ljava/lang/String;Ljava/util/List;)V
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 938
    .local p2, "targetPkgList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addBackgroundRestrictedInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 940
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Lcom/android/server/oplus/IOplusListManager;->addBackgroundRestrictedInfo(Ljava/lang/String;Ljava/util/List;)V

    .line 941
    return-void
.end method

.method public addFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "replacePkg"    # Ljava/lang/String;

    .line 868
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addFastAppThirdLogin"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 869
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusFastAppManager;->addFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    .line 870
    return-void
.end method

.method public addFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "originAppCpn"    # Ljava/lang/String;
    .param p2, "fastAppCpn"    # Ljava/lang/String;

    .line 880
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addFastAppWCPay"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 881
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusFastAppManager;->addFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    .line 882
    return-void
.end method

.method public addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .param p1, "srcPkgName"    # Ljava/lang/String;
    .param p2, "dstPkgName"    # Ljava/lang/String;
    .param p3, "signature"    # Ljava/lang/String;

    .line 856
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addMiniProgramShare"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 857
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/am/OplusFastAppManager;->addMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 858
    return-void
.end method

.method public addOplusLoopLoadTime(JLjava/lang/String;)V
    .registers 5
    .param p1, "endTime"    # J
    .param p3, "msg"    # Ljava/lang/String;

    .line 1690
    sget-object v0, Lcom/android/server/IOplusLooperStatsManager;->DEFAULT:Lcom/android/server/IOplusLooperStatsManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/IOplusLooperStatsManager;

    invoke-interface {v0, p1, p2, p3}, Lcom/android/server/IOplusLooperStatsManager;->addOplusLoopLoadTime(JLjava/lang/String;)V

    .line 1691
    return-void
.end method

.method public addOrRemoveOplusVerifyCodeListener(ZLcom/oplus/verifycode/IOplusVerifyCodeListener;)Z
    .registers 6
    .param p1, "add"    # Z
    .param p2, "listener"    # Lcom/oplus/verifycode/IOplusVerifyCodeListener;

    .line 1506
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addOrRemoveOplusVerifyCodeListener"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1508
    sget-object v0, Lcom/android/server/verifycode/IOplusVerificationCodeController;->DEFAULT:Lcom/android/server/verifycode/IOplusVerificationCodeController;

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/Object;

    invoke-static {v0, v2}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/verifycode/IOplusVerificationCodeController;

    invoke-interface {v0, p1, p2}, Lcom/android/server/verifycode/IOplusVerificationCodeController;->addOrRemoveOplusVerifyCodeListener(ZLcom/oplus/verifycode/IOplusVerifyCodeListener;)Z

    .line 1509
    return v1
.end method

.method public addPreventIndulgeList(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 955
    .local p1, "pkgNames":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addPreventIndulgeList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 957
    sget-object v0, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusAppStartupManager;->addPreventIndulgeList(Ljava/util/List;)V

    .line 958
    return-void
.end method

.method public addStageProtectInfo(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;JLcom/oplus/app/IOplusProtectConnection;)V
    .registers 21
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "protectPkg"    # Ljava/lang/String;
    .param p4, "reason"    # Ljava/lang/String;
    .param p5, "timeout"    # J
    .param p7, "connection"    # Lcom/oplus/app/IOplusProtectConnection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J",
            "Lcom/oplus/app/IOplusProtectConnection;",
            ")V"
        }
    .end annotation

    .line 792
    .local p3, "processList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "addStageProtectInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 794
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v5

    .line 795
    .local v5, "callingUid":I
    invoke-static {v5}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v6

    .line 796
    .local v6, "userId":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v3

    move-object v4, p1

    move-object v7, p2

    move-object/from16 v8, p3

    move-object/from16 v9, p4

    move-wide/from16 v10, p5

    move-object/from16 v12, p7

    invoke-interface/range {v3 .. v12}, Lcom/android/server/oplus/IOplusListManager;->addStageProtectInfo(Ljava/lang/String;IILjava/lang/String;Ljava/util/List;Ljava/lang/String;JLcom/oplus/app/IOplusProtectConnection;)V

    .line 798
    return-void
.end method

.method public anrViaTheiaEvent(ILjava/lang/String;)V
    .registers 14
    .param p1, "pid"    # I
    .param p2, "reason"    # Ljava/lang/String;

    .line 1410
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "anrViaTheiaEvent"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1413
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v1

    .line 1414
    :try_start_f
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v0

    move-object v3, v0

    .line 1415
    .local v3, "app":Lcom/android/server/am/ProcessRecord;
    monitor-exit v1
    :try_end_19
    .catchall {:try_start_f .. :try_end_19} :catchall_84

    .line 1416
    if-eqz v3, :cond_83

    .line 1418
    sget-object v0, Lcom/android/server/am/IOplusSecurityPermissionManager;->DEFAULT:Lcom/android/server/am/IOplusSecurityPermissionManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusSecurityPermissionManager;

    invoke-interface {v0, v3}, Lcom/android/server/am/IOplusSecurityPermissionManager;->isWaitingPermissionChoice(Lcom/android/server/am/ProcessRecord;)Z

    move-result v0

    if-eqz v0, :cond_2a

    .line 1419
    return-void

    .line 1421
    :cond_2a
    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->isInterestingToUserLocked()Z

    move-result v0

    if-nez v0, :cond_43

    iget-object v0, v3, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessStateRecord;->hasTopUi()Z

    move-result v0

    if-nez v0, :cond_43

    iget-object v0, v3, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessStateRecord;->hasOverlayUi()Z

    move-result v0

    if-eqz v0, :cond_41

    goto :goto_43

    :cond_41
    const/4 v0, 0x0

    goto :goto_44

    :cond_43
    :goto_43
    const/4 v0, 0x1

    .line 1422
    .local v0, "foreground":Z
    :goto_44
    if-eqz v0, :cond_83

    .line 1423
    const-string v1, "OplusActivityManagerServiceEnhance"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "anrViaTheiaEvent, pid = "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1424
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "App requested: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/os/TimeoutRecord;->forApp(Ljava/lang/String;)Lcom/android/internal/os/TimeoutRecord;

    move-result-object v9

    .line 1425
    .local v9, "timeoutRecord":Lcom/android/internal/os/TimeoutRecord;
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v1, Lcom/android/server/am/ActivityManagerService;->mAnrHelper:Lcom/android/server/am/AnrHelper;

    iget-object v5, v3, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual/range {v2 .. v10}, Lcom/android/server/am/AnrHelper;->appNotResponding(Lcom/android/server/am/ProcessRecord;Ljava/lang/String;Landroid/content/pm/ApplicationInfo;Ljava/lang/String;Lcom/android/server/wm/WindowProcessController;ZLcom/android/internal/os/TimeoutRecord;Z)V

    .line 1428
    .end local v0    # "foreground":Z
    .end local v9    # "timeoutRecord":Lcom/android/internal/os/TimeoutRecord;
    :cond_83
    return-void

    .line 1415
    .end local v3    # "app":Lcom/android/server/am/ProcessRecord;
    :catchall_84
    move-exception v0

    :try_start_85
    monitor-exit v1
    :try_end_86
    .catchall {:try_start_85 .. :try_end_86} :catchall_84

    throw v0
.end method

.method public asyncReportDalvikMem(Landroid/os/Bundle;IJJJ)V
    .registers 19
    .param p1, "activityThread"    # Landroid/os/Bundle;
    .param p2, "pid"    # I
    .param p3, "dalvikMax"    # J
    .param p5, "dalvikUsed"    # J
    .param p7, "uptime"    # J

    .line 1651
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/android/server/am/IOplusAthenaAmManager;

    move-object v2, p1

    move v3, p2

    move-wide v4, p3

    move-wide v6, p5

    move-wide/from16 v8, p7

    invoke-interface/range {v1 .. v9}, Lcom/android/server/am/IOplusAthenaAmManager;->asyncReportDalvikMem(Landroid/os/Bundle;IJJJ)V

    .line 1653
    return-void
.end method

.method public asyncReportFrames(Ljava/lang/String;I)V
    .registers 4
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "skippedFrames"    # I

    .line 289
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->asyncReportFrames(Ljava/lang/String;I)V

    .line 290
    return-void
.end method

.method public autoLayoutCall(Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 4
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 1698
    sget-object v0, Lcom/android/server/wm/IOplusAutoLayoutSystemServer;->DEFAULT:Lcom/android/server/wm/IOplusAutoLayoutSystemServer;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAutoLayoutSystemServer;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusAutoLayoutSystemServer;->autoLayoutCall(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public cleanPackageResources(Ljava/lang/String;I)V
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 1516
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "cleanPackageResources"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1518
    sget-object v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;->DEFAULT:Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/wm/IOplusAlwaysAliveManager;->cleanPackageRes(Ljava/lang/String;I)V

    .line 1519
    return-void
.end method

.method public clearApplicationUserData(Ljava/lang/String;ZLandroid/content/pm/IPackageDataObserver;I)Z
    .registers 9
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "keepState"    # Z
    .param p3, "observer"    # Landroid/content/pm/IPackageDataObserver;
    .param p4, "userId"    # I

    .line 1801
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1802
    const-string v1, "OplusActivityManager"

    const-string v2, "clearApplicationUserData"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1803
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_23

    .line 1806
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1808
    .local v1, "token":J
    :try_start_14
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1, p2, p3, p4}, Lcom/android/server/am/ActivityManagerService;->clearApplicationUserData(Ljava/lang/String;ZLandroid/content/pm/IPackageDataObserver;I)Z

    move-result v3
    :try_end_1a
    .catchall {:try_start_14 .. :try_end_1a} :catchall_1e

    .line 1810
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1808
    return v3

    .line 1810
    :catchall_1e
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1811
    throw v3

    .line 1804
    .end local v1    # "token":J
    :cond_23
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access clearApplicationUserData, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public clearFastStartConfig()Z
    .registers 4

    .line 1974
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string v2, "clearFastStartConfig"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1976
    :try_start_9
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0}, Lcom/android/server/am/IActivityManagerServiceExt;->clearFastStartConfig()Z

    move-result v0
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_11} :catch_12

    return v0

    .line 1977
    :catch_12
    move-exception v0

    .line 1978
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "clearFastStartConfig fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1979
    const/4 v1, 0x0

    return v1
.end method

.method public compactProcess(Landroid/os/Bundle;II)V
    .registers 7
    .param p1, "pids"    # Landroid/os/Bundle;
    .param p2, "compactionFlags"    # I
    .param p3, "advice"    # I

    .line 1443
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "compactProcess"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1444
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    .line 1445
    .local v0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    sget-object v1, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v1, v0, p2, p3}, Lcom/android/server/am/IOplusAthenaAmManager;->compactProcess(Ljava/util/List;II)V

    .line 1446
    return-void
.end method

.method public dumpProcPerfData(Landroid/os/Bundle;)Z
    .registers 5
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 1089
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string v2, "dumpProcPerfData"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1092
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_29

    .line 1095
    if-eqz p1, :cond_21

    .line 1098
    sget-object v0, Lcom/android/server/am/IOplusPerfManager;->DEFAULT:Lcom/android/server/am/IOplusPerfManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusPerfManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusPerfManager;->dumpProcPerfData(Landroid/os/Bundle;)Z

    move-result v0

    return v0

    .line 1096
    :cond_21
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "empty params"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 1093
    :cond_29
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "not system uid"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public enterFastFreezer(Ljava/lang/String;[IJLjava/lang/String;)V
    .registers 13
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "uids"    # [I
    .param p3, "timeout"    # J
    .param p5, "reason"    # Ljava/lang/String;

    .line 1324
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "enterFastFreezer"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1325
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/android/server/am/IOplusHansManager;

    move-object v2, p1

    move-object v3, p2

    move-wide v4, p3

    move-object v6, p5

    .end local p1    # "callerPkg":Ljava/lang/String;
    .end local p2    # "uids":[I
    .end local p3    # "timeout":J
    .end local p5    # "reason":Ljava/lang/String;
    .local v2, "callerPkg":Ljava/lang/String;
    .local v3, "uids":[I
    .local v4, "timeout":J
    .local v6, "reason":Ljava/lang/String;
    invoke-interface/range {v1 .. v6}, Lcom/android/server/am/IOplusHansManager;->enterFastFreezer(Ljava/lang/String;[IJLjava/lang/String;)I

    .line 1326
    return-void
.end method

.method public enterFastStart(Ljava/util/List;ILandroid/os/IBinder;)Z
    .registers 7
    .param p2, "duration"    # I
    .param p3, "binder"    # Landroid/os/IBinder;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I",
            "Landroid/os/IBinder;",
            ")Z"
        }
    .end annotation

    .line 1985
    .local p1, "pkgList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "enterFastStart"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1987
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1, p2, p3}, Lcom/android/server/am/IActivityManagerServiceExt;->enterFastStart(Ljava/util/List;ILandroid/os/IBinder;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 1988
    :catch_13
    move-exception v0

    .line 1989
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "enterFastStart fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1990
    const/4 v1, 0x0

    return v1
.end method

.method public executeResPreload(Ljava/lang/String;IILjava/lang/String;)V
    .registers 8
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "preloadType"    # I
    .param p4, "preloadReason"    # Ljava/lang/String;

    .line 1282
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "executeResPreload"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1283
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/android/server/am/IOplusResourcePreloadManager;->executeResPreload(Ljava/lang/String;IILjava/lang/String;)V

    .line 1284
    return-void
.end method

.method public exitFastFreezer(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "reason"    # Ljava/lang/String;

    .line 1330
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "exitFasterFreezer"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1331
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->exitFastFreezer(Ljava/lang/String;Ljava/lang/String;)V

    .line 1332
    return-void
.end method

.method public exitFastStart(Landroid/os/IBinder;)Z
    .registers 5
    .param p1, "binder"    # Landroid/os/IBinder;

    .line 2007
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "exitFastStart"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2009
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->exitFastStart(Landroid/os/IBinder;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 2010
    :catch_13
    move-exception v0

    .line 2011
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "exitFastStart fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2012
    const/4 v1, 0x0

    return v1
.end method

.method public favoriteQueryRule(Ljava/lang/String;Lcom/oplus/favorite/IOplusFavoriteQueryCallback;)V
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "callback"    # Lcom/oplus/favorite/IOplusFavoriteQueryCallback;

    .line 420
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mDirectHelper:Lcom/android/server/am/ColorDirectActivityHelper;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/ColorDirectActivityHelper;->favoriteQueryRule(Ljava/lang/String;Lcom/oplus/favorite/IOplusFavoriteQueryCallback;)V

    .line 421
    return-void
.end method

.method public finishFlexibleActivityOnTouchOutside(Landroid/os/IBinder;)Z
    .registers 3
    .param p1, "token"    # Landroid/os/IBinder;

    .line 1724
    const/4 v0, 0x0

    invoke-static {v0}, Lcom/android/server/wm/FlexibleWindowManagerService;->getInstance(Ljava/lang/Object;)Lcom/android/server/wm/FlexibleWindowManagerService;

    move-result-object v0

    .line 1725
    invoke-virtual {v0}, Lcom/android/server/wm/FlexibleWindowManagerService;->getFlexibleActivityController()Lcom/android/server/wm/IOplusFlexibleActivityController;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusFlexibleActivityController;->finishFlexibleActivityOnTouchOutside(Landroid/os/IBinder;)Z

    move-result v0

    .line 1724
    return v0
.end method

.method public finishNotOrderReceiver(Landroid/os/IBinder;IILjava/lang/String;Landroid/os/Bundle;Z)V
    .registers 15
    .param p1, "who"    # Landroid/os/IBinder;
    .param p2, "hasCode"    # I
    .param p3, "resultCode"    # I
    .param p4, "resultData"    # Ljava/lang/String;
    .param p5, "resultExtras"    # Landroid/os/Bundle;
    .param p6, "resultAbort"    # Z

    .line 1156
    sget-object v0, Lcom/android/server/am/IOplusBroadcastManager;->DEFAULT:Lcom/android/server/am/IOplusBroadcastManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/android/server/am/IOplusBroadcastManager;

    .line 1157
    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p5

    move v7, p6

    .end local p1    # "who":Landroid/os/IBinder;
    .end local p2    # "hasCode":I
    .end local p3    # "resultCode":I
    .end local p4    # "resultData":Ljava/lang/String;
    .end local p5    # "resultExtras":Landroid/os/Bundle;
    .end local p6    # "resultAbort":Z
    .local v2, "who":Landroid/os/IBinder;
    .local v3, "hasCode":I
    .local v4, "resultCode":I
    .local v5, "resultData":Ljava/lang/String;
    .local v6, "resultExtras":Landroid/os/Bundle;
    .local v7, "resultAbort":Z
    invoke-interface/range {v1 .. v7}, Lcom/android/server/am/IOplusBroadcastManager;->finishNotOrderReceiver(Landroid/os/IBinder;IILjava/lang/String;Landroid/os/Bundle;Z)V

    .line 1158
    return-void
.end method

.method public forceStopPackageAndSaveActivity(Ljava/lang/String;I)V
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I

    .line 1523
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "forceStopPackageAndSaveActivity"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1525
    sget-object v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;->DEFAULT:Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/wm/IOplusAlwaysAliveManager;->forceStopPackageAndSaveActivity(Ljava/lang/String;I)V

    .line 1526
    return-void
.end method

.method public forceTrimAppMemory(I)V
    .registers 5
    .param p1, "level"    # I

    .line 1047
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "forceTrimAppMemory"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1049
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusAthenaAmManager;->forceTrimAppMemory(I)V

    .line 1050
    return-void
.end method

.method public gameBgPureModeSwitch(Z)Z
    .registers 5
    .param p1, "on"    # Z

    .line 2050
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "gameBgPureModeSwitch"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2052
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->gameBgPureModeSwitch(Z)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 2053
    :catch_13
    move-exception v0

    .line 2054
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "gameBgPureModeSwitch fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2055
    const/4 v1, 0x0

    return v1
.end method

.method public getAccidentallyTouchData()Lcom/oplus/util/OplusAccidentallyTouchData;
    .registers 3

    .line 647
    sget-object v0, Landroid/view/IOplusAccidentallyTouchHelper;->DEFAULT:Landroid/view/IOplusAccidentallyTouchHelper;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Landroid/view/IOplusAccidentallyTouchHelper;

    invoke-interface {v0}, Landroid/view/IOplusAccidentallyTouchHelper;->getAccidentallyTouchData()Lcom/oplus/util/OplusAccidentallyTouchData;

    move-result-object v0

    return-object v0
.end method

.method public getAllDarkModeData()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/darkmode/OplusDarkModeData;",
            ">;"
        }
    .end annotation

    .line 1074
    sget-object v0, Lcom/android/server/IOplusDarkModeServiceManager;->DEFAULT:Lcom/android/server/IOplusDarkModeServiceManager;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/IOplusDarkModeServiceManager;

    invoke-interface {v0}, Lcom/android/server/IOplusDarkModeServiceManager;->getAllDarkModeDataEntity()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getAllVisibleTasksInfo(I)Ljava/util/List;
    .registers 5
    .param p1, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RecentTaskInfo;",
            ">;"
        }
    .end annotation

    .line 1397
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getAllVisibleTasksInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1399
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_20

    .line 1402
    sget-object v0, Lcom/android/server/wm/IOplusAthenaManager;->DEFAULT:Lcom/android/server/wm/IOplusAthenaManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAthenaManager;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusAthenaManager;->getAllVisibleTasksInfo(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 1400
    :cond_20
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "only allow system uid"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public getCompatModeSession()Lcom/oplus/compatmode/IOplusCompatModeSession;
    .registers 2

    .line 1586
    sget-object v0, Lcom/android/server/wm/IOplusCompatModeManager;->DEFAULT:Lcom/android/server/wm/IOplusCompatModeManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusCompatModeManager;

    invoke-interface {v0}, Lcom/android/server/wm/IOplusCompatModeManager;->getCompatModeSession()Lcom/oplus/compatmode/IOplusCompatModeSession;

    move-result-object v0

    return-object v0
.end method

.method public getConfigInfo(Ljava/lang/String;II)Landroid/os/Bundle;
    .registers 7
    .param p1, "configName"    # Ljava/lang/String;
    .param p2, "flag"    # I
    .param p3, "userId"    # I

    .line 910
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getConfigInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 911
    const/4 v0, 0x1

    if-ne p2, v0, :cond_17

    .line 912
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    invoke-interface {v0, p1, p3}, Lcom/android/server/oplus/IOplusListManager;->getConfigInfo(Ljava/lang/String;I)Landroid/os/Bundle;

    move-result-object v0

    return-object v0

    .line 914
    :cond_17
    const/4 v0, 0x0

    return-object v0
.end method

.method public getCpuLimitLatestLogs(Ljava/lang/String;)Landroid/os/SharedMemory;
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;

    .line 1375
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getCpuLimitLatestLog"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1376
    sget-object v0, Lcom/android/server/am/IOplusCpuLimitManager;->DEFAULT:Lcom/android/server/am/IOplusCpuLimitManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusCpuLimitManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusCpuLimitManager;->getCpuLimitLatestLog(Ljava/lang/String;)Landroid/os/SharedMemory;

    move-result-object v0

    return-object v0
.end method

.method public getCpuWorkingStats()Ljava/util/List;
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1000
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    const-wide/16 v1, 0x0

    if-nez v0, :cond_9

    .line 1001
    invoke-virtual {p0, v1, v2}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->updateCpuTracker(J)F

    .line 1003
    :cond_9
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1004
    .local v0, "returnList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-wide v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    cmp-long v1, v3, v1

    if-gtz v1, :cond_15

    .line 1005
    return-object v0

    .line 1007
    :cond_15
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v1}, Lcom/android/internal/os/ProcessCpuTracker;->countWorkingStats()I

    move-result v1

    .line 1008
    .local v1, "size":I
    const/16 v2, 0xa

    if-le v1, v2, :cond_21

    move v3, v2

    goto :goto_22

    :cond_21
    move v3, v1

    .line 1009
    .local v3, "maxSize":I
    :goto_22
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_23
    if-ge v4, v3, :cond_65

    .line 1010
    iget-object v5, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v5, v4}, Lcom/android/internal/os/ProcessCpuTracker;->getWorkingStats(I)Lcom/android/internal/os/ProcessCpuTracker$Stats;

    move-result-object v5

    .line 1011
    .local v5, "stats":Lcom/android/internal/os/ProcessCpuTracker$Stats;
    iget v6, v5, Lcom/android/internal/os/ProcessCpuTracker$Stats;->rel_utime:I

    .line 1012
    .local v6, "relUtime":I
    iget v7, v5, Lcom/android/internal/os/ProcessCpuTracker$Stats;->rel_stime:I

    .line 1013
    .local v7, "relStime":I
    nop

    .line 1014
    div-int/2addr v6, v2

    .line 1015
    div-int/2addr v7, v2

    .line 1017
    iget v8, v5, Lcom/android/internal/os/ProcessCpuTracker$Stats;->pid:I

    .line 1018
    .local v8, "pid":I
    iget-object v9, v5, Lcom/android/internal/os/ProcessCpuTracker$Stats;->name:Ljava/lang/String;

    .line 1019
    .local v9, "name":Ljava/lang/String;
    add-int v10, v6, v7

    int-to-float v10, v10

    const/high16 v11, 0x447a0000    # 1000.0f

    mul-float/2addr v10, v11

    iget-wide v11, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    long-to-float v11, v11

    div-float/2addr v10, v11

    .line 1020
    .local v10, "percent":F
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "="

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    .line 1021
    .local v11, "stat":Ljava/lang/String;
    invoke-interface {v0, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1009
    .end local v5    # "stats":Lcom/android/internal/os/ProcessCpuTracker$Stats;
    .end local v6    # "relUtime":I
    .end local v7    # "relStime":I
    .end local v8    # "pid":I
    .end local v9    # "name":Ljava/lang/String;
    .end local v10    # "percent":F
    .end local v11    # "stat":Ljava/lang/String;
    add-int/lit8 v4, v4, 0x1

    goto :goto_23

    .line 1023
    .end local v4    # "i":I
    :cond_65
    return-object v0
.end method

.method public getCurrentUser()I
    .registers 5

    .line 1816
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1817
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "getCurrentUser"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1818
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1821
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1823
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3}, Lcom/android/server/am/ActivityManagerService;->getCurrentUserId()I

    move-result v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1825
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1823
    return v3

    .line 1825
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1826
    throw v3

    .line 1819
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access getCurrentUser, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public getDarkModeData(Ljava/lang/String;)Lcom/oplus/darkmode/OplusDarkModeData;
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;

    .line 1067
    sget-object v0, Lcom/android/server/IOplusDarkModeServiceManager;->DEFAULT:Lcom/android/server/IOplusDarkModeServiceManager;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/IOplusDarkModeServiceManager;

    invoke-interface {v0, p1}, Lcom/android/server/IOplusDarkModeServiceManager;->getDarkModeDataEntity(Ljava/lang/String;)Lcom/oplus/darkmode/OplusDarkModeData;

    move-result-object v0

    .line 1068
    .local v0, "oplusDarkModeData":Lcom/oplus/darkmode/OplusDarkModeData;
    return-object v0
.end method

.method public getDisplayCompatData()Lcom/oplus/util/OplusDisplayCompatData;
    .registers 4

    .line 680
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getDisplayCompatData"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 682
    invoke-static {}, Lcom/oplus/util/OplusDisplayCompatUtils;->getInstance()Lcom/oplus/util/OplusDisplayCompatUtils;

    move-result-object v0

    invoke-virtual {v0}, Lcom/oplus/util/OplusDisplayCompatUtils;->getDisplayCompatData()Lcom/oplus/util/OplusDisplayCompatData;

    move-result-object v0

    return-object v0
.end method

.method public getDisplayOptimizationData()Lcom/oplus/util/OplusDisplayOptimizationData;
    .registers 2

    .line 672
    invoke-static {}, Lcom/oplus/util/OplusDisplayOptimizationUtils;->getInstance()Lcom/oplus/util/OplusDisplayOptimizationUtils;

    move-result-object v0

    invoke-virtual {v0}, Lcom/oplus/util/OplusDisplayOptimizationUtils;->getOptimizationData()Lcom/oplus/util/OplusDisplayOptimizationData;

    move-result-object v0

    return-object v0
.end method

.method public getDownloadingList(IZ)Ljava/util/List;
    .registers 6
    .param p1, "thresholdSpeed"    # I
    .param p2, "rough"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .line 1459
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getDownloadingList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1460
    invoke-static {}, Lcom/android/server/am/OplusAthenaTrafficMonitor;->getInstance()Lcom/android/server/am/OplusAthenaTrafficMonitor;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusAthenaTrafficMonitor;->getDownloadingList(IZ)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getFastAppReplacePkg(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p1, "callerPkg"    # Ljava/lang/String;

    .line 1677
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/am/OplusFastAppManager;->getFastAppReplacePkg(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getFontVariationAdaptionData(Ljava/lang/String;)I
    .registers 3
    .param p1, "name"    # Ljava/lang/String;

    .line 1237
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mFontVariationAdaptionUtils:Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;

    if-eqz v0, :cond_b

    .line 1238
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mFontVariationAdaptionUtils:Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;

    invoke-virtual {v0, p1}, Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;->getAdaptionValueFormSystem(Ljava/lang/String;)I

    move-result v0

    return v0

    .line 1240
    :cond_b
    const/4 v0, 0x0

    return v0
.end method

.method public getGlobalPkgWhiteList(I)Ljava/util/List;
    .registers 4
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 778
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-interface {v0, v1, p1}, Lcom/android/server/oplus/IOplusListManager;->getGlobalWhiteList(Landroid/content/Context;I)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method

.method public getGlobalProcessWhiteList()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 783
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-interface {v0, v1}, Lcom/android/server/oplus/IOplusListManager;->getGlobalProcessWhiteList(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method

.method public getLoopCpuLoad()I
    .registers 2

    .line 1685
    sget-object v0, Lcom/android/server/IOplusLooperStatsManager;->DEFAULT:Lcom/android/server/IOplusLooperStatsManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/IOplusLooperStatsManager;

    invoke-interface {v0}, Lcom/android/server/IOplusLooperStatsManager;->getLoopCpuLoad()I

    move-result v0

    return v0
.end method

.method public getNavbarSettingsConfigs()Landroid/os/Bundle;
    .registers 5

    .line 2195
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2196
    .local v0, "bundle":Landroid/os/Bundle;
    sget-object v1, Lcom/android/server/wm/IOplusNavBarBgSystemServer;->DEFAULT:Lcom/android/server/wm/IOplusNavBarBgSystemServer;

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v1, v2}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/wm/IOplusNavBarBgSystemServer;

    .line 2197
    .local v1, "oplusNavBarBgSystemServer":Lcom/android/server/wm/IOplusNavBarBgSystemServer;
    const-string/jumbo v2, "is_navbar_handle_hide"

    invoke-interface {v1}, Lcom/android/server/wm/IOplusNavBarBgSystemServer;->isNavbarHandleHide()Z

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 2198
    const-string/jumbo v2, "is_gesture_mode"

    invoke-interface {v1}, Lcom/android/server/wm/IOplusNavBarBgSystemServer;->isGestureMode()Z

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 2199
    return-object v0
.end method

.method public getPackageFreezeDataInfos(Landroid/os/Bundle;)Ljava/util/List;
    .registers 5
    .param p1, "pids"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .line 1488
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getPackageFreezeDataInfos"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1490
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    .line 1491
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    .line 1490
    invoke-interface {v0, v1}, Lcom/android/server/am/IOplusAthenaAmManager;->getPackageFreezeDataInfos(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getPayJoyFlag()I
    .registers 4

    .line 1761
    invoke-static {}, Landroid/payjoy/PayJoyCustomizedManager;->getInstance()Landroid/payjoy/PayJoyCustomizedManager;

    move-result-object v0

    .line 1762
    .local v0, "pcm":Landroid/payjoy/PayJoyCustomizedManager;
    if-eqz v0, :cond_16

    invoke-virtual {v0}, Landroid/payjoy/PayJoyCustomizedManager;->isPayJoyCustState()Z

    move-result v1

    if-eqz v1, :cond_16

    .line 1763
    const-string v1, "OplusActivityManagerServiceEnhance"

    const-string/jumbo v2, "payjoy control is true"

    invoke-static {v1, v2}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1764
    const/4 v1, 0x1

    return v1

    .line 1766
    :cond_16
    const/4 v1, 0x0

    return v1
.end method

.method public getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1315
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oppo.permission.OPPO_COMPONENT_SAFE"

    const-string/jumbo v2, "getPkgPreloadFiles"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1316
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusResourcePreloadManager;->getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getPreloadIOSize()J
    .registers 4

    .line 1294
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getPreloadIOSize"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1295
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusResourcePreloadManager;->getPreloadIOSize()J

    move-result-wide v0

    return-wide v0
.end method

.method public getPreloadPkgList()Landroid/os/Bundle;
    .registers 4

    .line 1309
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getPreloadPkgList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1310
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusResourcePreloadManager;->getPreloadPkgList()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public getPreloadStatus(Ljava/lang/String;I)Z
    .registers 6
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I

    .line 1300
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getPreloadStatus"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1301
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusResourcePreloadManager;->isPkgPreload(Ljava/lang/String;I)Z

    move-result v0

    return v0
.end method

.method public getProcCmdline([I)Ljava/util/List;
    .registers 9
    .param p1, "pids"    # [I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1119
    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    .line 1120
    .local v0, "callingPid":I
    invoke-static {p1}, Ljava/util/Arrays;->stream([I)Ljava/util/stream/IntStream;

    move-result-object v1

    new-instance v2, Lcom/android/server/am/OplusActivityManagerServiceEnhance$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance$$ExternalSyntheticLambda1;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/IntStream;->anyMatch(Ljava/util/function/IntPredicate;)Z

    move-result v1

    .line 1121
    .local v1, "requiredOtherProcessName":Z
    if-eqz v1, :cond_1e

    .line 1122
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v3, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v4, "getProcCmdline"

    invoke-virtual {v2, v3, v4}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1126
    :cond_1e
    new-instance v2, Ljava/util/ArrayList;

    array-length v3, p1

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 1127
    .local v2, "cmdLines":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    array-length v3, p1

    const/4 v4, 0x0

    :goto_26
    if-ge v4, v3, :cond_38

    aget v5, p1, v4

    .line 1128
    .local v5, "pid":I
    invoke-static {}, Lcom/android/server/am/OplusPerfManager;->getInstance()Lcom/android/server/am/OplusPerfManager;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcom/android/server/am/OplusPerfManager;->getCmdlineName(I)Ljava/lang/String;

    move-result-object v6

    .line 1129
    .local v6, "name":Ljava/lang/String;
    invoke-interface {v2, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1127
    .end local v5    # "pid":I
    .end local v6    # "name":Ljava/lang/String;
    add-int/lit8 v4, v4, 0x1

    goto :goto_26

    .line 1131
    :cond_38
    sget-boolean v3, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v3, :cond_55

    .line 1132
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "getProcCmdline cmdLines="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "OplusActivityManagerServiceEnhance"

    invoke-static {v4, v3}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1134
    :cond_55
    return-object v2
.end method

.method public getProcCommonInfoList(I)Ljava/util/List;
    .registers 5
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1106
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getProcCommonInfoList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1109
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_20

    .line 1112
    sget-object v0, Lcom/android/server/am/IOplusPerfManager;->DEFAULT:Lcom/android/server/am/IOplusPerfManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusPerfManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusPerfManager;->getProcCommonInfoList(I)Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 1110
    :cond_20
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "not system uid"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public getProcDependency(I)Ljava/util/List;
    .registers 5
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusProcDependData;",
            ">;"
        }
    .end annotation

    .line 747
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getProcDependency"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 749
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusAthenaAmManager;->getProcDependency(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getProcDependencyByUserId(Ljava/lang/String;I)Ljava/util/List;
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusProcDependData;",
            ">;"
        }
    .end annotation

    .line 754
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getProcDependency"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 756
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusAthenaAmManager;->getProcDependency(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;
    .registers 6
    .param p1, "pids"    # [I

    .line 1846
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1847
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "getProcessMemoryInfo"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1848
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1851
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1853
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;

    move-result-object v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1855
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1853
    return-object v3

    .line 1855
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1856
    throw v3

    .line 1849
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access getProcessMemoryInfo, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public getReflectData()Lcom/oplus/util/OplusReflectData;
    .registers 2

    .line 895
    invoke-static {}, Lcom/oplus/util/OplusReflectDataUtils;->getInstance()Lcom/oplus/util/OplusReflectDataUtils;

    move-result-object v0

    invoke-virtual {v0}, Lcom/oplus/util/OplusReflectDataUtils;->getData()Lcom/oplus/util/OplusReflectData;

    move-result-object v0

    return-object v0
.end method

.method public getResPreloadInfo(II)Landroid/os/Bundle;
    .registers 6
    .param p1, "days"    # I
    .param p2, "userId"    # I

    .line 1288
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getResPreloadInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1289
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusResourcePreloadManager;->getResPreloadInfo(II)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public getResolveData()Lcom/oplus/util/OplusResolveData;
    .registers 2

    .line 664
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/OplusResolverRusManager;->getInstance(Landroid/content/Context;)Lcom/android/server/OplusResolverRusManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/OplusResolverRusManager;->getData()Lcom/oplus/util/OplusResolveData;

    move-result-object v0

    return-object v0
.end method

.method public getRunningAppProcessInfos(Landroid/os/Bundle;)Ljava/util/List;
    .registers 5
    .param p1, "pids"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningAppProcessInfo;",
            ">;"
        }
    .end annotation

    .line 1480
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getRunningAppProcessInfos"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1482
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    .line 1483
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    .line 1482
    invoke-interface {v0, v1}, Lcom/android/server/am/IOplusAthenaAmManager;->getRunningAppProcessInfos(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getRunningAppProcesses()Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningAppProcessInfo;",
            ">;"
        }
    .end annotation

    .line 1861
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1862
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "getRunningAppProcesses"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1863
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1866
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1868
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3}, Lcom/android/server/am/ActivityManagerService;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1870
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1868
    return-object v3

    .line 1870
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1871
    throw v3

    .line 1864
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access getRunningAppProcesses, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public getRunningPidsByUid(I)[I
    .registers 9
    .param p1, "uid"    # I

    .line 1530
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getRunningPidsByUid"

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1532
    sget-object v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;->DEFAULT:Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAlwaysAliveManager;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusAlwaysAliveManager;->getRunningPidsByUid(I)Ljava/util/List;

    move-result-object v0

    .line 1533
    .local v0, "pids":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [I

    .line 1534
    .local v1, "rets":[I
    const/4 v2, 0x0

    .line 1535
    .local v2, "i":I
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_24
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3a

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    .line 1536
    .local v4, "e":Ljava/lang/Integer;
    add-int/lit8 v5, v2, 0x1

    .end local v2    # "i":I
    .local v5, "i":I
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v1, v2

    .line 1537
    .end local v4    # "e":Ljava/lang/Integer;
    move v2, v5

    goto :goto_24

    .line 1538
    .end local v5    # "i":I
    .restart local v2    # "i":I
    :cond_3a
    return-object v1
.end method

.method public getRunningProcesses()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/oplus/util/OplusPackageFreezeData;",
            ">;"
        }
    .end annotation

    .line 921
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getRunningProcesses"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 922
    sget-object v0, Lcom/android/server/am/IOplusSceneManager;->DEFAULT:Lcom/android/server/am/IOplusSceneManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusSceneManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusSceneManager;->getRunningProcesses()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getRunningServices(I)Ljava/util/List;
    .registers 7
    .param p1, "maxNum"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningServiceInfo;",
            ">;"
        }
    .end annotation

    .line 1891
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1892
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "getRunningServices"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1893
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_25

    .line 1896
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1898
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const/4 v4, 0x0

    invoke-virtual {v3, p1, v4}, Lcom/android/server/am/ActivityManagerService;->getServices(II)Ljava/util/List;

    move-result-object v3
    :try_end_1c
    .catchall {:try_start_15 .. :try_end_1c} :catchall_20

    .line 1900
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1898
    return-object v3

    .line 1900
    :catchall_20
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1901
    throw v3

    .line 1894
    .end local v1    # "token":J
    :cond_25
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access getRunningServices, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public getRunningTasks(I)Ljava/util/List;
    .registers 6
    .param p1, "maxValue"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Landroid/app/ActivityManager$RunningTaskInfo;",
            ">;"
        }
    .end annotation

    .line 1786
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1787
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "getRunningTasks"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1788
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1791
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1793
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->getTasks(I)Ljava/util/List;

    move-result-object v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1795
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1793
    return-object v3

    .line 1795
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1796
    throw v3

    .line 1789
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access getRunningTasks, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public getSecureKeyboardData()Lcom/oplus/util/OplusSecureKeyboardData;
    .registers 2

    .line 654
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mSecureKeyboardUtils:Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;

    if-nez v0, :cond_a

    .line 655
    new-instance v0, Lcom/oplus/util/OplusSecureKeyboardData;

    invoke-direct {v0}, Lcom/oplus/util/OplusSecureKeyboardData;-><init>()V

    return-object v0

    .line 657
    :cond_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mSecureKeyboardUtils:Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;

    invoke-virtual {v0}, Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;->getData()Lcom/oplus/util/OplusSecureKeyboardData;

    move-result-object v0

    return-object v0
.end method

.method public getStageProtectList(I)Ljava/util/List;
    .registers 5
    .param p1, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 827
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getStageProtectList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 829
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 830
    .local v0, "callingUid":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v1

    invoke-interface {v1, p1, v0}, Lcom/android/server/oplus/IOplusListManager;->getStageProtectList(II)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

.method public getStageProtectListAsUser(II)Ljava/util/List;
    .registers 6
    .param p1, "type"    # I
    .param p2, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 835
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getStageProtectListAsUser"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 837
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 838
    .local v0, "callingUid":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v1

    invoke-interface {v1, p1, v0, p2}, Lcom/android/server/oplus/IOplusListManager;->getStageProtectListAsUser(III)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

.method public getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/ArrayList;
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "type"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 811
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getStageProtectListFromPkg"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 813
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 814
    .local v0, "callingUid":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v1

    invoke-interface {v1, p1, v0}, Lcom/android/server/oplus/IOplusListManager;->getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    return-object v1
.end method

.method public bridge synthetic getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 194
    invoke-virtual {p0, p1, p2}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->getStageProtectListFromPkg(Ljava/lang/String;I)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1
.end method

.method public getStageProtectListFromPkgAsUser(Ljava/lang/String;II)Ljava/util/List;
    .registers 7
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "type"    # I
    .param p3, "userId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "II)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 819
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getStageProtectListFromPkgAsUser"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 821
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 822
    .local v0, "callingUid":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v1

    invoke-interface {v1, p1, v0, p3}, Lcom/android/server/oplus/IOplusListManager;->getStageProtectListFromPkgAsUser(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v1

    return-object v1
.end method

.method public getStartPermission(Ljava/util/List;)Landroid/os/Bundle;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Landroid/os/Bundle;"
        }
    .end annotation

    .line 2091
    .local p1, "packageList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "getStartPermission"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2092
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 2093
    .local v0, "callingUid":I
    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_1b

    .line 2094
    invoke-static {}, Lcom/android/server/am/OplusAppStartupConfig;->getInstance()Lcom/android/server/am/OplusAppStartupConfig;

    move-result-object v1

    invoke-virtual {v1, p1}, Lcom/android/server/am/OplusAppStartupConfig;->getStartupConfigInfo(Ljava/util/List;)Landroid/os/Bundle;

    move-result-object v1

    return-object v1

    .line 2096
    :cond_1b
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    return-object v1
.end method

.method public getTaskPkgList(I)Ljava/util/List;
    .registers 5
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 761
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getTaskPkgList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 763
    sget-object v0, Lcom/android/server/wm/IOplusAthenaManager;->DEFAULT:Lcom/android/server/wm/IOplusAthenaManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAthenaManager;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusAthenaManager;->getTaskPkgList(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getTerminateObservers()[I
    .registers 8

    .line 1612
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getTerminateObservers"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1614
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusOsenseCommonManager;->getTerminateObservers()Ljava/util/List;

    move-result-object v0

    .line 1615
    .local v0, "observers":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [I

    .line 1616
    .local v1, "rets":[I
    const/4 v2, 0x0

    .line 1617
    .local v2, "i":I
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_22
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_38

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    .line 1618
    .local v4, "observer":Ljava/lang/Integer;
    add-int/lit8 v5, v2, 0x1

    .end local v2    # "i":I
    .local v5, "i":I
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v1, v2

    .line 1619
    .end local v4    # "observer":Ljava/lang/Integer;
    move v2, v5

    goto :goto_22

    .line 1620
    .end local v5    # "i":I
    .restart local v2    # "i":I
    :cond_38
    return-object v1
.end method

.method public getTopLoadPidsInfos(I)Ljava/util/List;
    .registers 5
    .param p1, "num"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1388
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getTopLoadPidsInfos"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1389
    sget-object v0, Lcom/android/server/am/IOplusSceneManager;->DEFAULT:Lcom/android/server/am/IOplusSceneManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusSceneManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusSceneManager;->getTopLoadPidsInfos(I)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getTotalCpuLoadPercent()J
    .registers 4

    .line 1383
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "getTotalCpuLoadPercent"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1384
    sget-object v0, Lcom/android/server/am/IOplusSceneManager;->DEFAULT:Lcom/android/server/am/IOplusSceneManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusSceneManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusSceneManager;->getTotalCpuLoadPercent()J

    move-result-wide v0

    return-wide v0
.end method

.method public getTrafficBytesList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;
    .registers 6
    .param p1, "uids"    # Landroid/os/Bundle;
    .param p2, "outBundle"    # Landroid/os/Bundle;

    .line 1356
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oppo.permission.OPPO_COMPONENT_SAFE"

    const-string/jumbo v2, "getTrafficBytesList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1357
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    .line 1358
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    .line 1357
    invoke-interface {v0, v1}, Lcom/android/server/am/IOplusOsenseCommonManager;->getTrafficBytesList(Ljava/util/ArrayList;)Landroid/util/SparseArray;

    move-result-object v0

    .line 1360
    .local v0, "arrays":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/Long;>;"
    invoke-direct {p0, v0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->sparseArrayLongToString(Landroid/util/SparseArray;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public getTrafficPacketList(Landroid/os/Bundle;Landroid/os/Bundle;)Ljava/lang/String;
    .registers 6
    .param p1, "uids"    # Landroid/os/Bundle;
    .param p2, "outBundle"    # Landroid/os/Bundle;

    .line 1365
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oppo.permission.OPPO_COMPONENT_SAFE"

    const-string/jumbo v2, "getTrafficPacketList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1366
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    .line 1367
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    .line 1366
    invoke-interface {v0, v1}, Lcom/android/server/am/IOplusOsenseCommonManager;->getTrafficPacketList(Ljava/util/ArrayList;)Landroid/util/SparseArray;

    move-result-object v0

    .line 1368
    .local v0, "arrays":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/lang/Long;>;"
    invoke-direct {p0, v0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->sparseArrayLongToString(Landroid/util/SparseArray;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public getTsaInfo(Ljava/lang/String;IJJ)Landroid/os/Bundle;
    .registers 14
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "tid"    # I
    .param p3, "startNanoTime"    # J
    .param p5, "endNanoTime"    # J

    .line 2042
    invoke-static {}, Lcom/oplus/tsabpf/OplusTsaBpfManager;->getInstance()Lcom/oplus/tsabpf/OplusTsaBpfManager;

    move-result-object v0

    move-object v1, p1

    move v2, p2

    move-wide v3, p3

    move-wide v5, p5

    .end local p1    # "packageName":Ljava/lang/String;
    .end local p2    # "tid":I
    .end local p3    # "startNanoTime":J
    .end local p5    # "endNanoTime":J
    .local v1, "packageName":Ljava/lang/String;
    .local v2, "tid":I
    .local v3, "startNanoTime":J
    .local v5, "endNanoTime":J
    invoke-virtual/range {v0 .. v6}, Lcom/oplus/tsabpf/OplusTsaBpfManager;->getTsaInfo(Ljava/lang/String;IJJ)Landroid/os/Bundle;

    move-result-object p1

    return-object p1
.end method

.method public getUXIconData()Lcom/oplus/util/OplusUXIconData;
    .registers 2

    .line 1435
    invoke-static {}, Lcom/android/server/OplusUXIconRusManager;->getInstance()Lcom/android/server/OplusUXIconRusManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/OplusUXIconRusManager;->getData()Lcom/oplus/util/OplusUXIconData;

    move-result-object v0

    return-object v0
.end method

.method public getUidCpuWorkingStats()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 547
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 548
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 549
    .local v0, "returnList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

    invoke-virtual {v1}, Lcom/android/server/am/OplusUidCpuTimeReader;->update()V

    .line 550
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

    invoke-virtual {v1}, Lcom/android/server/am/OplusUidCpuTimeReader;->calTopUid()V

    .line 551
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

    invoke-virtual {v1}, Lcom/android/server/am/OplusUidCpuTimeReader;->getUidCpuWorkingStats()Ljava/util/List;

    move-result-object v0

    .line 552
    sget-boolean v1, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v1, :cond_3b

    .line 553
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "getUidCpuWorkingStats returnList="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 555
    :cond_3b
    return-object v0
.end method

.method public grantOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 576
    const-string/jumbo v0, "grantOplusPermissionByGroup"

    :try_start_3
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string v2, "android.permission.GRANT_RUNTIME_PERMISSIONS"

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_a
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_a} :catch_b

    .line 579
    goto :goto_14

    .line 577
    :catch_b
    move-exception v1

    .line 578
    .local v1, "ex":Ljava/lang/SecurityException;
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v3, "oplus.permission.OPLUS_COMPONENT_SAFE"

    invoke-virtual {v2, v3, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 580
    .end local v1    # "ex":Ljava/lang/SecurityException;
    :goto_14
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    if-eqz v0, :cond_1d

    .line 581
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->grantOplusPermissionsFromRuntime(Ljava/lang/String;Ljava/lang/String;)V

    .line 584
    :cond_1d
    return-void
.end method

.method public grantUriPermissionToUser(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/net/Uri;II)V
    .registers 13
    .param p1, "caller"    # Landroid/app/IApplicationThread;
    .param p2, "targetPkg"    # Ljava/lang/String;
    .param p3, "uri"    # Landroid/net/Uri;
    .param p4, "modeFlags"    # I
    .param p5, "userId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1706
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    move v6, p5

    .end local p1    # "caller":Landroid/app/IApplicationThread;
    .end local p2    # "targetPkg":Ljava/lang/String;
    .end local p3    # "uri":Landroid/net/Uri;
    .end local p4    # "modeFlags":I
    .end local p5    # "userId":I
    .local v2, "caller":Landroid/app/IApplicationThread;
    .local v3, "targetPkg":Ljava/lang/String;
    .local v4, "uri":Landroid/net/Uri;
    .local v5, "modeFlags":I
    .local v6, "userId":I
    invoke-interface/range {v1 .. v6}, Lcom/android/server/am/IActivityManagerServiceExt;->grantUriPermissionToUser(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/net/Uri;II)V

    .line 1707
    return-void
.end method

.method public handleAppForNotification(Ljava/lang/String;II)V
    .registers 7
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .param p3, "otherInfo"    # I

    .line 638
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "handleAppForNotification"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 640
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Lcom/android/server/oplus/IOplusListManager;->handleAppForNotification(Ljava/lang/String;II)V

    .line 641
    return-void
.end method

.method public handleAppFromControlCenter(Ljava/lang/String;I)V
    .registers 6
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 846
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "handleAppFromControlCenter"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 848
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Lcom/android/server/oplus/IOplusListManager;->handleAppFromControlCenter(Ljava/lang/String;I)V

    .line 849
    return-void
.end method

.method public hookAfterBindApplicationFinished(Ljava/lang/String;IIILjava/lang/String;)V
    .registers 7
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "pid"    # I
    .param p4, "uid"    # I
    .param p5, "processName"    # Ljava/lang/String;

    .line 406
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1, p2, p3}, Lcom/android/server/am/IOplusResourcePreloadManager;->notifyBindApplicationFinished(Ljava/lang/String;II)V

    .line 410
    sget-object v0, Lcom/android/server/pm/IOplusVirtualAppManager;->DEFAULT:Lcom/android/server/pm/IOplusVirtualAppManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/pm/IOplusVirtualAppManager;

    invoke-interface {v0, p4, p3, p1, p5}, Lcom/android/server/pm/IOplusVirtualAppManager;->handleProcessStart(IILjava/lang/String;Ljava/lang/String;)V

    .line 412
    return-void
.end method

.method public inDownloading(IIZ)Z
    .registers 7
    .param p1, "uid"    # I
    .param p2, "thresholdSpeed"    # I
    .param p3, "rough"    # Z

    .line 1453
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "inDownloading"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1454
    invoke-static {}, Lcom/android/server/am/OplusAthenaTrafficMonitor;->getInstance()Lcom/android/server/am/OplusAthenaTrafficMonitor;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/am/OplusAthenaTrafficMonitor;->inDownloading(IIZ)Z

    move-result v0

    return v0
.end method

.method public isFrozenByHans(Ljava/lang/String;I)Z
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 1336
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "isFrozenByHans"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1337
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->isFrozenByHans(Ljava/lang/String;I)Z

    move-result v0

    return v0
.end method

.method public isNightMode()Z
    .registers 3

    .line 1079
    const-class v0, Lcom/android/server/UiModeManagerInternal;

    invoke-static {v0}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/UiModeManagerInternal;

    .line 1080
    .local v0, "uiModeManagerInternal":Lcom/android/server/UiModeManagerInternal;
    if-eqz v0, :cond_12

    invoke-virtual {v0}, Lcom/android/server/UiModeManagerInternal;->isNightMode()Z

    move-result v1

    if-eqz v1, :cond_12

    const/4 v1, 0x1

    goto :goto_13

    :cond_12
    const/4 v1, 0x0

    .line 1081
    .local v1, "isNightMode":Z
    :goto_13
    return v1
.end method

.method public isPermissionInterceptEnabled()Z
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 619
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    if-eqz v0, :cond_b

    .line 620
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    invoke-virtual {v0}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->isPermissionInterceptEnabled()Z

    move-result v0

    return v0

    .line 622
    :cond_b
    const/4 v0, 0x0

    return v0
.end method

.method public isPkgProcessRunning(Ljava/lang/String;Ljava/lang/String;I)Z
    .registers 8
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "processName"    # Ljava/lang/String;
    .param p3, "userId"    # I

    .line 2131
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v0}, Lcom/android/server/am/ActivityManagerService;->getPackageManagerInternal()Landroid/content/pm/PackageManagerInternal;

    move-result-object v0

    const-wide/16 v1, 0x0

    invoke-virtual {v0, p1, v1, v2, p3}, Landroid/content/pm/PackageManagerInternal;->getPackageUid(Ljava/lang/String;JI)I

    move-result v0

    .line 2132
    .local v0, "uid":I
    if-gez v0, :cond_10

    .line 2133
    const/4 v1, 0x0

    return v1

    .line 2135
    :cond_10
    if-eqz p2, :cond_17

    .line 2137
    invoke-virtual {p0, v0, p2}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->isUidProcessRunning(ILjava/lang/String;)Z

    move-result v1

    return v1

    .line 2140
    :cond_17
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v2, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v3, "isProcessRunning"

    invoke-virtual {v1, v2, v3}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2142
    invoke-direct {p0, v0, p1}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->isProcessRunningInner(ILjava/lang/String;)Z

    move-result v1

    return v1
.end method

.method public isUidProcessRunning(ILjava/lang/String;)Z
    .registers 6
    .param p1, "uid"    # I
    .param p2, "processName"    # Ljava/lang/String;

    .line 2114
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "isProcessRunning"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2116
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v0

    .line 2117
    if-eqz p2, :cond_30

    .line 2119
    :try_start_12
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v1, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v1, p2, p1}, Lcom/android/server/am/ProcessList;->getProcessRecordLocked(Ljava/lang/String;I)Lcom/android/server/am/ProcessRecord;

    move-result-object v1

    .line 2120
    .local v1, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v1, :cond_2a

    invoke-virtual {v1}, Lcom/android/server/am/ProcessRecord;->getThread()Landroid/app/IApplicationThread;

    move-result-object v2

    if-eqz v2, :cond_2a

    .line 2121
    invoke-virtual {v1}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v2

    if-nez v2, :cond_2a

    const/4 v2, 0x1

    goto :goto_2b

    :cond_2a
    const/4 v2, 0x0

    :goto_2b
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_12 .. :try_end_2c} :catchall_3a

    .line 2120
    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    return v2

    .line 2124
    .end local v1    # "proc":Lcom/android/server/am/ProcessRecord;
    :cond_30
    const/4 v1, 0x0

    :try_start_31
    invoke-direct {p0, p1, v1}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->isProcessRunningInner(ILjava/lang/String;)Z

    move-result v1

    monitor-exit v0
    :try_end_36
    .catchall {:try_start_31 .. :try_end_36} :catchall_3a

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    return v1

    .line 2126
    :catchall_3a
    move-exception v1

    :try_start_3b
    monitor-exit v0
    :try_end_3c
    .catchall {:try_start_3b .. :try_end_3c} :catchall_3a

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v1
.end method

.method public killPidForce(I)V
    .registers 2
    .param p1, "pid"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 633
    return-void
.end method

.method public notifyAppKillReason(IIIILjava/lang/String;)V
    .registers 13
    .param p1, "pid"    # I
    .param p2, "uid"    # I
    .param p3, "reason"    # I
    .param p4, "subReason"    # I
    .param p5, "msg"    # Ljava/lang/String;

    .line 1223
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "notifyAppKillReason"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1225
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_25

    .line 1228
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/android/server/am/IOplusAthenaAmManager;

    .line 1229
    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .end local p1    # "pid":I
    .end local p2    # "uid":I
    .end local p3    # "reason":I
    .end local p4    # "subReason":I
    .end local p5    # "msg":Ljava/lang/String;
    .local v2, "pid":I
    .local v3, "uid":I
    .local v4, "reason":I
    .local v5, "subReason":I
    .local v6, "msg":Ljava/lang/String;
    invoke-interface/range {v1 .. v6}, Lcom/android/server/am/IOplusAthenaAmManager;->notifyAppKillReason(IIIILjava/lang/String;)V

    .line 1230
    return-void

    .line 1226
    .end local v2    # "pid":I
    .end local v3    # "uid":I
    .end local v4    # "reason":I
    .end local v5    # "subReason":I
    .end local v6    # "msg":Ljava/lang/String;
    .restart local p1    # "pid":I
    .restart local p2    # "uid":I
    .restart local p3    # "reason":I
    .restart local p4    # "subReason":I
    .restart local p5    # "msg":Ljava/lang/String;
    :cond_25
    move v2, p1

    move v3, p2

    .end local p1    # "pid":I
    .end local p2    # "uid":I
    .restart local v2    # "pid":I
    .restart local v3    # "uid":I
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p2, "only allow system uid"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public notifyAthenaOnekeyClearRunning(I)V
    .registers 5
    .param p1, "state"    # I

    .line 1269
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "notifyAthenaOnekeyClearRunning"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1271
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_1f

    .line 1274
    sget-object v0, Lcom/android/server/wm/IOplusAthenaManager;->DEFAULT:Lcom/android/server/wm/IOplusAthenaManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAthenaManager;

    invoke-interface {v0, p1}, Lcom/android/server/wm/IOplusAthenaManager;->notifyAthenaOnekeyClearRunning(I)V

    .line 1275
    return-void

    .line 1272
    :cond_1f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "only allow system uid"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public notifyGameStatus(Landroid/os/Bundle;)I
    .registers 5
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 1733
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "notifyGameStatus"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1735
    sget-object v0, Lcom/android/server/am/IOplusSlcDispatchManager;->DEFAULT:Lcom/android/server/am/IOplusSlcDispatchManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusSlcDispatchManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusSlcDispatchManager;->notifyGameStatus(Landroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method public notifyProcessTerminate([ILjava/lang/String;)V
    .registers 8
    .param p1, "pids"    # [I
    .param p2, "reason"    # Ljava/lang/String;

    .line 1624
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "notifyProcessTerminate"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1626
    new-instance v0, Ljava/util/ArrayList;

    array-length v1, p1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 1627
    .local v0, "pidList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    array-length v1, p1

    const/4 v2, 0x0

    :goto_13
    if-ge v2, v1, :cond_21

    aget v3, p1, v2

    .line 1628
    .local v3, "pid":I
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1627
    .end local v3    # "pid":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_13

    .line 1630
    :cond_21
    sget-object v1, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v1, v0, p2}, Lcom/android/server/am/IOplusOsenseCommonManager;->notifyProcessTerminate(Ljava/util/List;Ljava/lang/String;)V

    .line 1631
    return-void
.end method

.method public notifyProcessTerminateFinish(Lcom/oplus/app/IProcessTerminateObserver;)V
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/IProcessTerminateObserver;

    .line 1606
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "notifyProcessTerminateFinish"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1608
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->notifyProcessTerminateFinish(Lcom/oplus/app/IProcessTerminateObserver;)V

    .line 1609
    return-void
.end method

.method public notifyUiSwitched(Ljava/lang/String;I)V
    .registers 6
    .param p1, "uiInfo"    # Ljava/lang/String;
    .param p2, "status"    # I

    .line 1497
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "notifyUiSwitched"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1499
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->notifyUiSwitched(Ljava/lang/String;I)Z

    .line 1500
    sget-object v0, Lcom/oplus/uifirst/IOplusUIFirstManager;->DEFAULT:Lcom/oplus/uifirst/IOplusUIFirstManager;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {v0, v1}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/oplus/uifirst/IOplusUIFirstManager;

    .line 1501
    .local v0, "ouim":Lcom/oplus/uifirst/IOplusUIFirstManager;
    invoke-interface {v0, p1, p2}, Lcom/oplus/uifirst/IOplusUIFirstManager;->notifyUiSwitched(Ljava/lang/String;I)V

    .line 1502
    return-void
.end method

.method public onBackPressedOnTheiaMonitor(J)V
    .registers 5
    .param p1, "pressNow"    # J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 389
    invoke-static {}, Lcom/android/server/theia/TheiaUtil;->getInstance()Lcom/android/server/theia/TheiaUtil;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p1, p2, v1}, Lcom/android/server/theia/TheiaUtil;->onBackPressedOnTheiaMonitor(JLandroid/content/Context;)V

    .line 390
    return-void
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 10
    .param p1, "code"    # I
    .param p2, "data"    # Landroid/os/Parcel;
    .param p3, "reply"    # Landroid/os/Parcel;
    .param p4, "flags"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 429
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    const-string v1, "OplusActivityManagerServiceEnhance"

    if-eqz v0, :cond_1d

    .line 430
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "onTransact code="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 433
    :cond_1d
    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/IOplusActivityManager$Stub;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_25

    .line 434
    return v2

    .line 436
    :cond_25
    packed-switch p1, :pswitch_data_e0

    .line 536
    :pswitch_28
    const/4 v0, 0x0

    return v0

    .line 530
    :pswitch_2a
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 531
    .local v0, "uid":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "InputDispatcher preAnr notify hans to check uid "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " frozen state"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 532
    sget-object v1, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v1, v0}, Lcom/android/server/am/IOplusHansManager;->unFreezeForInputDispatcher(I)V

    .line 533
    return v2

    .line 490
    .end local v0    # "uid":I
    :pswitch_56
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 491
    .local v0, "op":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 492
    .local v1, "pid":I
    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v3

    .line 493
    .local v3, "tids":[I
    invoke-virtual {p0, v0, v1, v3}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->setKeyThreads(II[I)V

    .line 494
    return v2

    .line 523
    .end local v0    # "op":I
    .end local v1    # "pid":I
    .end local v3    # "tids":[I
    :pswitch_66
    invoke-virtual {p2}, Landroid/os/Parcel;->readString8()Ljava/lang/String;

    move-result-object v0

    .line 524
    .local v0, "layerName":Ljava/lang/String;
    sget-object v1, Lcom/android/server/wm/IOplusStartingWindowManager;->DEFAULT:Lcom/android/server/wm/IOplusStartingWindowManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/wm/IOplusStartingWindowManager;

    invoke-interface {v1, v0}, Lcom/android/server/wm/IOplusStartingWindowManager;->notifyRemoveDelayedStartingWindow(Ljava/lang/String;)V

    .line 525
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 526
    return v2

    .line 517
    .end local v0    # "layerName":Ljava/lang/String;
    :pswitch_79
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    invoke-static {v0, v1}, Landroid/os/PerformanceManager;->readUxTaskTrack(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 518
    return v2

    .line 512
    :pswitch_89
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    invoke-static {v2, v0, v2}, Landroid/os/PerformanceManager;->addTaskTrackPid(IIZ)V

    .line 513
    const/4 v0, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    invoke-static {v0, v1, v2}, Landroid/os/PerformanceManager;->addTaskTrackPid(IIZ)V

    .line 514
    return v2

    .line 498
    :pswitch_99
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    .line 499
    .local v0, "pkgName":Ljava/lang/String;
    invoke-virtual {p0, v0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->getPkgPreloadFiles(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    .line 500
    .local v1, "pathlist":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-nez v1, :cond_a9

    .line 501
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v3

    .line 503
    :cond_a9
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 504
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 505
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_b7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 506
    .local v4, "file":Ljava/lang/String;
    invoke-virtual {p3, v4}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 507
    .end local v4    # "file":Ljava/lang/String;
    goto :goto_b7

    .line 508
    :cond_c7
    return v2

    .line 483
    .end local v0    # "pkgName":Ljava/lang/String;
    .end local v1    # "pathlist":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :pswitch_c8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 484
    .local v0, "pid":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 485
    .local v1, "tid":I
    invoke-virtual {p0, v0, v1}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->setGlThreads(II)V

    .line 486
    return v2

    .line 476
    .end local v0    # "pid":I
    .end local v1    # "tid":I
    :pswitch_d4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 477
    .restart local v0    # "pid":I
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v1

    .line 478
    .restart local v1    # "tid":I
    invoke-virtual {p0, v0, v1}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->setHwuiTaskThreads(II)V

    .line 479
    return v2

    :pswitch_data_e0
    .packed-switch 0x2711
        :pswitch_d4
        :pswitch_c8
        :pswitch_99
        :pswitch_89
        :pswitch_79
        :pswitch_66
        :pswitch_28
        :pswitch_28
        :pswitch_56
        :pswitch_2a
    .end packed-switch
.end method

.method public putConfigInfo(Ljava/lang/String;Landroid/os/Bundle;II)Z
    .registers 8
    .param p1, "configName"    # Ljava/lang/String;
    .param p2, "bundle"    # Landroid/os/Bundle;
    .param p3, "flag"    # I
    .param p4, "userId"    # I

    .line 901
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "putConfigInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 902
    const/4 v0, 0x1

    if-ne p3, v0, :cond_17

    .line 903
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v0

    invoke-interface {v0, p1, p2, p4}, Lcom/android/server/oplus/IOplusListManager;->putConfigInfo(Ljava/lang/String;Landroid/os/Bundle;I)Z

    move-result v0

    return v0

    .line 905
    :cond_17
    const/4 v0, 0x0

    return v0
.end method

.method public putFastStartConfig(Ljava/lang/String;)Z
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;

    .line 1963
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "putFastStartConfig"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1965
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->putFastStartConfig(Ljava/lang/String;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 1966
    :catch_13
    move-exception v0

    .line 1967
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "putFastStartConfig fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1968
    const/4 v1, 0x0

    return v1
.end method

.method public queryProcessNameFromPid(I)Ljava/lang/String;
    .registers 5
    .param p1, "pid"    # I

    .line 1205
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.LOG"

    const-string/jumbo v2, "queryProcessNameFromPid"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1207
    if-gtz p1, :cond_f

    .line 1208
    const-string v0, ""

    return-object v0

    .line 1210
    :cond_f
    const-string v0, ""

    .line 1212
    .local v0, "procName":Ljava/lang/String;
    sget-boolean v1, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v1, :cond_38

    .line 1213
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "queryProcessNameFromPid pid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",procName="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1215
    :cond_38
    return-object v0
.end method

.method public queryUsageStats(IJJ)Ljava/util/List;
    .registers 14
    .param p1, "intervalType"    # I
    .param p2, "beginTime"    # J
    .param p4, "endTime"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJJ)",
            "Ljava/util/List<",
            "Landroid/app/usage/UsageStats;",
            ">;"
        }
    .end annotation

    .line 1465
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "queryUsageStats"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1466
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 1467
    .local v0, "callerUid":I
    invoke-static {}, Landroid/os/UserHandle;->getCallingUserId()I

    move-result v2

    .line 1468
    .local v2, "callerUserId":I
    const/16 v1, 0x3e8

    if-ne v0, v1, :cond_27

    .line 1471
    sget-object v1, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/IOplusAthenaAmManager;

    move v3, p1

    move-wide v4, p2

    move-wide v6, p4

    .end local p1    # "intervalType":I
    .end local p2    # "beginTime":J
    .end local p4    # "endTime":J
    .local v3, "intervalType":I
    .local v4, "beginTime":J
    .local v6, "endTime":J
    invoke-interface/range {v1 .. v7}, Lcom/android/server/am/IOplusAthenaAmManager;->queryUsageStatsForUser(IIJJ)Ljava/util/List;

    move-result-object p1

    return-object p1

    .line 1469
    .end local v3    # "intervalType":I
    .end local v4    # "beginTime":J
    .end local v6    # "endTime":J
    .restart local p1    # "intervalType":I
    .restart local p2    # "beginTime":J
    .restart local p4    # "endTime":J
    :cond_27
    move v3, p1

    move-wide v4, p2

    .end local p1    # "intervalType":I
    .end local p2    # "beginTime":J
    .restart local v3    # "intervalType":I
    .restart local v4    # "beginTime":J
    new-instance p1, Ljava/lang/SecurityException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo p3, "permission denied for not system uid: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public registerAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;Ljava/lang/String;)V
    .registers 6
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;
    .param p2, "packageName"    # Ljava/lang/String;

    .line 733
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oppo.permission.safe.LOG"

    const-string/jumbo v2, "registerAbConfigCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 734
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusEapManager;->registerAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;Ljava/lang/String;)V

    .line 735
    return-void
.end method

.method public registerComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z
    .registers 6
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "observer"    # Lcom/oplus/osense/complexscene/IComplexSceneObserver;

    .line 1660
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.WINDOW"

    const-string/jumbo v2, "registerComplexSceneObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1662
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    const/4 v1, 0x0

    invoke-interface {v0, p1, p2, v1}, Lcom/android/server/am/IOplusOsenseCommonManager;->registerComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;Landroid/os/Handler;)Z

    move-result v0

    return v0
.end method

.method public registerEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eap/IOplusEapDataCallback;

    .line 697
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "registerEapDataCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 699
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->registerEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    .line 700
    return-void
.end method

.method public registerErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    .line 718
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "registerErrorInfoCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 720
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->registerErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 721
    return-void
.end method

.method public registerHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/app/IOplusHansListener;

    .line 1250
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "registerHansListener"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1251
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->registerHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v0

    return v0
.end method

.method public registerProcessObserver(Landroid/app/IProcessObserver;I)V
    .registers 6
    .param p1, "observer"    # Landroid/app/IProcessObserver;
    .param p2, "flags"    # I

    .line 2105
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "android.permission.SET_ACTIVITY_WATCHER"

    const-string/jumbo v2, "registerProcessObserver()"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2107
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessList;->getWrapper()Lcom/android/server/am/IProcessListWrapper;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IProcessListWrapper;->registerProcessObserver(Landroid/app/IProcessObserver;I)V

    .line 2108
    return-void
.end method

.method public registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/IProcessTerminateObserver;

    .line 1594
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "registerTerminateObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1596
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->registerTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0
.end method

.method public registerTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/ITerminateObserver;

    .line 1634
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "registerTerminateStateObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1636
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->registerTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v0

    return v0
.end method

.method public removeFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "replacePkg"    # Ljava/lang/String;

    .line 874
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "removeFastAppThirdLogin"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 875
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusFastAppManager;->removeFastAppThirdLogin(Ljava/lang/String;Ljava/lang/String;)V

    .line 876
    return-void
.end method

.method public removeFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "originAppCpn"    # Ljava/lang/String;
    .param p2, "fastAppCpn"    # Ljava/lang/String;

    .line 886
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "removeFastAppWCPay"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 887
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusFastAppManager;->removeFastAppWCPay(Ljava/lang/String;Ljava/lang/String;)V

    .line 888
    return-void
.end method

.method public removeMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .param p1, "srcPkgName"    # Ljava/lang/String;
    .param p2, "dstPkgName"    # Ljava/lang/String;
    .param p3, "signature"    # Ljava/lang/String;

    .line 862
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "removeMiniProgramShare"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 863
    invoke-static {}, Lcom/android/server/am/OplusFastAppManager;->getInstance()Lcom/android/server/am/OplusFastAppManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/am/OplusFastAppManager;->removeMiniProgramShare(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 864
    return-void
.end method

.method public removeStageProtectInfo(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "protectPkg"    # Ljava/lang/String;
    .param p2, "callerPkg"    # Ljava/lang/String;

    .line 802
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "removeStageProtectInfo"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 804
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    .line 805
    .local v0, "callingUid":I
    invoke-static {v0}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v1

    .line 806
    .local v1, "userId":I
    invoke-static {}, Lcom/android/server/oplus/OplusListManager;->getInstance()Lcom/android/server/oplus/IOplusListManager;

    move-result-object v2

    invoke-interface {v2, p1, p2, v1}, Lcom/android/server/oplus/IOplusListManager;->removeStageProtectInfo(Ljava/lang/String;Ljava/lang/String;I)V

    .line 807
    return-void
.end method

.method public removeTask(I)Z
    .registers 6
    .param p1, "taskId"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 1772
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "removeTask"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1773
    .local v0, "returnCode":I
    const/16 v1, 0x3e9

    if-ne v0, v1, :cond_24

    .line 1776
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1778
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->removeTask(I)Z

    move-result v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1780
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1778
    return v3

    .line 1780
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1781
    throw v3

    .line 1774
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access removeTask, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public reportBindApplicationFinished(Ljava/lang/String;II)V
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "userId"    # I
    .param p3, "pid"    # I

    .line 401
    sget-object v0, Lcom/android/server/am/IOplusResourcePreloadManager;->DEFAULT:Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusResourcePreloadManager;

    invoke-interface {v0, p1, p2, p3}, Lcom/android/server/am/IOplusResourcePreloadManager;->notifyBindApplicationFinished(Ljava/lang/String;II)V

    .line 402
    return-void
.end method

.method public reportSkippedFrames(JZZJ)V
    .registers 18
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J

    .line 1164
    const/4 v1, 0x0

    .line 1165
    .local v1, "processName":Ljava/lang/String;
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v2

    .line 1166
    :try_start_6
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v0

    .line 1167
    .local v0, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v0, :cond_19

    .line 1168
    iget-object v3, v0, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;
    :try_end_16
    .catchall {:try_start_6 .. :try_end_16} :catchall_3b

    move-object v1, v3

    move-object v4, v1

    goto :goto_1a

    .line 1167
    :cond_19
    move-object v4, v1

    .line 1170
    .end local v0    # "proc":Lcom/android/server/am/ProcessRecord;
    .end local v1    # "processName":Ljava/lang/String;
    .local v4, "processName":Ljava/lang/String;
    :goto_1a
    :try_start_1a
    monitor-exit v2
    :try_end_1b
    .catchall {:try_start_1a .. :try_end_1b} :catchall_38

    .line 1171
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-nez v0, :cond_29

    .line 1172
    sget-object v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->DEFAULT:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    .line 1174
    :cond_29
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-eqz v0, :cond_37

    .line 1175
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    move-wide v5, p1

    move v7, p3

    move v8, p4

    move-wide/from16 v9, p5

    invoke-interface/range {v3 .. v10}, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->saveSkippedFramesRecordToList(Ljava/lang/String;JZZJ)V

    .line 1177
    :cond_37
    return-void

    .line 1170
    :catchall_38
    move-exception v0

    move-object v1, v4

    goto :goto_3c

    .end local v4    # "processName":Ljava/lang/String;
    .restart local v1    # "processName":Ljava/lang/String;
    :catchall_3b
    move-exception v0

    :goto_3c
    :try_start_3c
    monitor-exit v2
    :try_end_3d
    .catchall {:try_start_3c .. :try_end_3d} :catchall_3b

    throw v0
.end method

.method public reportSkippedFramesActivityName(JZZJLjava/lang/String;Ljava/lang/String;)V
    .registers 19
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J
    .param p7, "pckName"    # Ljava/lang/String;
    .param p8, "activityName"    # Ljava/lang/String;

    .line 1193
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-nez v0, :cond_e

    .line 1194
    sget-object v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->DEFAULT:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    .line 1196
    :cond_e
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-eqz v0, :cond_1f

    .line 1197
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    move-wide v4, p1

    move v6, p3

    move v7, p4

    move-wide v8, p5

    move-object/from16 v2, p7

    move-object/from16 v3, p8

    invoke-interface/range {v1 .. v9}, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->saveSkippedFramesRecordToList(Ljava/lang/String;Ljava/lang/String;JZZJ)V

    .line 1200
    :cond_1f
    return-void
.end method

.method public reportSkippedFramesProcName(JZZJLjava/lang/String;)V
    .registers 17
    .param p1, "currentTime"    # J
    .param p3, "isAnimation"    # Z
    .param p4, "isForeground"    # Z
    .param p5, "skippedFrames"    # J
    .param p7, "pckName"    # Ljava/lang/String;

    .line 1183
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-nez v0, :cond_e

    .line 1184
    sget-object v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->DEFAULT:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    .line 1186
    :cond_e
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    if-eqz v0, :cond_1d

    .line 1187
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusAmsUtils:Lcom/android/server/wm/IOplusAmsUtilsFeatrue;

    move-wide v3, p1

    move v5, p3

    move v6, p4

    move-wide v7, p5

    move-object/from16 v2, p7

    invoke-interface/range {v1 .. v8}, Lcom/android/server/wm/IOplusAmsUtilsFeatrue;->saveSkippedFramesRecordToList(Ljava/lang/String;JZZJ)V

    .line 1189
    :cond_1d
    return-void
.end method

.method public requestDeviceFolded(IZ)Z
    .registers 7
    .param p1, "folded"    # I
    .param p2, "enableSecDisplay"    # Z

    .line 1547
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.PRIVATE"

    const-string/jumbo v2, "requestDeviceFolded"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1548
    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    .line 1549
    .local v0, "callingPid":I
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1551
    .local v1, "ident":J
    :try_start_12
    sget-object v3, Lcom/android/server/wm/IOplusFoldingAngleManager;->DEFAULT:Lcom/android/server/wm/IOplusFoldingAngleManager;

    invoke-static {v3}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v3

    check-cast v3, Lcom/android/server/wm/IOplusFoldingAngleManager;

    invoke-interface {v3, p1, p2, v0}, Lcom/android/server/wm/IOplusFoldingAngleManager;->requestDeviceFoldedBySoft(IZI)Z

    move-result v3
    :try_end_1e
    .catchall {:try_start_12 .. :try_end_1e} :catchall_22

    .line 1553
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1551
    return v3

    .line 1553
    :catchall_22
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1554
    throw v3
.end method

.method public revokeOplusPermissionByGroup(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 589
    const-string/jumbo v0, "revokeOplusPermissionByGroup"

    :try_start_3
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string v2, "android.permission.REVOKE_RUNTIME_PERMISSIONS"

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_a
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_a} :catch_b

    .line 592
    goto :goto_14

    .line 590
    :catch_b
    move-exception v1

    .line 591
    .local v1, "ex":Ljava/lang/SecurityException;
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v3, "oplus.permission.OPLUS_COMPONENT_SAFE"

    invoke-virtual {v2, v3, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 593
    .end local v1    # "ex":Ljava/lang/SecurityException;
    :goto_14
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    if-eqz v0, :cond_1d

    .line 594
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->revokeOplusPermissionsFromRuntime(Ljava/lang/String;Ljava/lang/String;)V

    .line 597
    :cond_1d
    return-void
.end method

.method public sendFlingTransit(Landroid/view/MotionEvent;I)V
    .registers 6
    .param p1, "ev"    # Landroid/view/MotionEvent;
    .param p2, "duration"    # I

    .line 1560
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    if-nez v0, :cond_e

    const-class v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    invoke-static {v0}, Lcom/oplus/osense/OsenseResClient;->get(Ljava/lang/Class;)Lcom/oplus/osense/OsenseResClient;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    if-eqz v0, :cond_1b

    .line 1561
    :cond_e
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0

    .line 1563
    .local v0, "token":J
    :try_start_12
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    invoke-virtual {v2, p1, p2}, Lcom/oplus/osense/OsenseResClient;->osenseSendFling(Landroid/view/MotionEvent;I)V
    :try_end_17
    .catchall {:try_start_12 .. :try_end_17} :catchall_27

    .line 1565
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1566
    nop

    .line 1568
    .end local v0    # "token":J
    :cond_1b
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->asyncReportFling(Landroid/view/MotionEvent;I)V

    .line 1569
    return-void

    .line 1565
    .restart local v0    # "token":J
    :catchall_27
    move-exception v2

    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1566
    throw v2
.end method

.method public sendTheiaEvent(JLandroid/content/Intent;)V
    .registers 6
    .param p1, "category"    # J
    .param p3, "args"    # Landroid/content/Intent;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 393
    invoke-static {}, Lcom/android/server/theia/TheiaUtil;->getInstance()Lcom/android/server/theia/TheiaUtil;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p1, p2, p3, v1}, Lcom/android/server/theia/TheiaUtil;->sendTheiaEvent(JLandroid/content/Intent;Landroid/content/Context;)V

    .line 394
    return-void
.end method

.method public setAppFreeze(Ljava/lang/String;Landroid/os/Bundle;)Z
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "data"    # Landroid/os/Bundle;

    .line 1260
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "setAppFreeze"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1261
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->setAppFreeze(Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public setAppStartMonitorController(Lcom/oplus/app/IOplusAppStartController;)V
    .registers 5
    .param p1, "watcher"    # Lcom/oplus/app/IOplusAppStartController;

    .line 929
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "setAppStartMonitorController"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 930
    invoke-static {}, Lcom/android/server/am/HandleApplicationCrash;->getInstance()Lcom/android/server/am/HandleApplicationCrash;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/am/HandleApplicationCrash;->setAppStartMonitorController(Lcom/oplus/app/IOplusAppStartController;)V

    .line 931
    return-void
.end method

.method public setDynamicBlackList(Ljava/util/List;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 1996
    .local p1, "blackList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "setDynamicBlackList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1998
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->setDynamicBlackList(Ljava/util/List;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 1999
    :catch_13
    move-exception v0

    .line 2000
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setDynamicBlackList fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2001
    const/4 v1, 0x0

    return v1
.end method

.method public setGameBgPureGameScene(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6
    .param p1, "gamePkg"    # Ljava/lang/String;
    .param p2, "gameAssistantPkg"    # Ljava/lang/String;

    .line 2072
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "setGameBgPureGameScene"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2074
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IActivityManagerServiceExt;->setGameBgPureGameScene(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 2075
    :catch_13
    move-exception v0

    .line 2076
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setGameBgPureGameScene fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2077
    const/4 v1, 0x0

    return v1
.end method

.method public setGameBgPureModeBlackList(Ljava/util/List;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 2061
    .local p1, "blackList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "setGameBgPureModeBlackList"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2063
    :try_start_a
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->setGameBgPureModeBlackList(Ljava/util/List;)Z

    move-result v0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_12} :catch_13

    return v0

    .line 2064
    :catch_13
    move-exception v0

    .line 2065
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setGameBgPureModeBlackList fail. e ="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusActivityManagerServiceEnhance"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2066
    const/4 v1, 0x0

    return v1
.end method

.method public setGameSpaceController(Lcom/oplus/app/IOplusGameSpaceController;)V
    .registers 5
    .param p1, "controller"    # Lcom/oplus/app/IOplusGameSpaceController;

    .line 688
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "setGameSpaceController"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 690
    sget-object v0, Lcom/android/server/am/IOplusJoystickManager;->DEFAULT:Lcom/android/server/am/IOplusJoystickManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusJoystickManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusJoystickManager;->setGameSpaceController(Lcom/oplus/app/IOplusGameSpaceController;)V

    .line 691
    return-void
.end method

.method public setGlThreads(II)V
    .registers 8
    .param p1, "pid"    # I
    .param p2, "tid"    # I

    .line 336
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    if-ne p1, v0, :cond_7

    .line 337
    return-void

    .line 342
    :cond_7
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v0

    .line 343
    :try_start_c
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v1, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v1

    .line 344
    .local v1, "proc":Lcom/android/server/am/ProcessRecord;
    monitor-exit v0
    :try_end_15
    .catchall {:try_start_c .. :try_end_15} :catchall_61

    .line 346
    if-eqz v1, :cond_39

    .line 347
    monitor-enter v1

    .line 348
    :try_start_18
    invoke-virtual {v1}, Lcom/android/server/am/ProcessRecord;->getRenderThreadTid()I

    move-result v0

    .line 349
    .local v0, "renderThreadTid":I
    if-ne p2, v0, :cond_20

    .line 350
    monitor-exit v1

    return-void

    .line 352
    :cond_20
    sget-object v2, Lcom/oplus/uifirst/IOplusUIFirstManager;->DEFAULT:Lcom/oplus/uifirst/IOplusUIFirstManager;

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v2, v3}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/oplus/uifirst/IOplusUIFirstManager;

    iget-object v3, v1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget v4, v1, Lcom/android/server/am/ProcessRecord;->uid:I

    invoke-interface {v2, v3, v4, p1, p2}, Lcom/oplus/uifirst/IOplusUIFirstManager;->addApplicationGlThread(Ljava/lang/String;III)V

    .line 353
    .end local v0    # "renderThreadTid":I
    monitor-exit v1

    goto :goto_39

    :catchall_36
    move-exception v0

    monitor-exit v1
    :try_end_38
    .catchall {:try_start_18 .. :try_end_38} :catchall_36

    throw v0

    .line 355
    :cond_39
    :goto_39
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v0, :cond_60

    .line 356
    const-string v0, "OplusActivityManagerServiceEnhance"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "setGlThreads detect "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 358
    :cond_60
    return-void

    .line 344
    .end local v1    # "proc":Lcom/android/server/am/ProcessRecord;
    :catchall_61
    move-exception v1

    :try_start_62
    monitor-exit v0
    :try_end_63
    .catchall {:try_start_62 .. :try_end_63} :catchall_61

    throw v1
.end method

.method public setHwuiTaskThreads(II)V
    .registers 7
    .param p1, "pid"    # I
    .param p2, "tid"    # I

    .line 310
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    if-ne p1, v0, :cond_7

    .line 311
    return-void

    .line 313
    :cond_7
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v0, :cond_2e

    .line 314
    const-string v0, "OplusActivityManagerServiceEnhance"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setHwuiTaskThreads pid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",tid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 318
    :cond_2e
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v0

    .line 319
    :try_start_33
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v1, v1, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v1

    .line 320
    .local v1, "proc":Lcom/android/server/am/ProcessRecord;
    monitor-exit v0
    :try_end_3c
    .catchall {:try_start_33 .. :try_end_3c} :catchall_6b

    .line 322
    if-eqz v1, :cond_6a

    .line 323
    monitor-enter v1

    .line 324
    :try_start_3f
    iget-object v0, v1, Lcom/android/server/am/ProcessRecord;->mHwuiTaskThreads:Landroid/util/IntArray;

    invoke-virtual {v0, p2}, Landroid/util/IntArray;->add(I)V

    .line 326
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v0

    iget-object v2, v1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget v3, v1, Lcom/android/server/am/ProcessRecord;->uid:I

    invoke-virtual {v0, v2, p1, p2, v3}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->reportAppHwuiTaskAdded(Ljava/lang/String;III)Z

    .line 327
    sget-object v0, Lcom/oplus/uifirst/IOplusUIFirstManager;->DEFAULT:Lcom/oplus/uifirst/IOplusUIFirstManager;

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v0, v2}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/oplus/uifirst/IOplusUIFirstManager;

    iget-object v2, v1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget v3, v1, Lcom/android/server/am/ProcessRecord;->uid:I

    invoke-interface {v0, v2, v3, p1, p2}, Lcom/oplus/uifirst/IOplusUIFirstManager;->addApplicationHwuiTaskThread(Ljava/lang/String;III)V

    .line 328
    monitor-exit v1

    goto :goto_6a

    :catchall_67
    move-exception v0

    monitor-exit v1
    :try_end_69
    .catchall {:try_start_3f .. :try_end_69} :catchall_67

    throw v0

    .line 330
    :cond_6a
    :goto_6a
    return-void

    .line 320
    .end local v1    # "proc":Lcom/android/server/am/ProcessRecord;
    :catchall_6b
    move-exception v1

    :try_start_6c
    monitor-exit v0
    :try_end_6d
    .catchall {:try_start_6c .. :try_end_6d} :catchall_6b

    throw v1
.end method

.method public setKeyThreads(II[I)V
    .registers 12
    .param p1, "op"    # I
    .param p2, "pid"    # I
    .param p3, "tids"    # [I

    .line 362
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    if-ne p2, v0, :cond_7

    .line 363
    return-void

    .line 366
    :cond_7
    const/4 v1, 0x0

    .line 368
    .local v1, "proc":Lcom/android/server/am/ProcessRecord;
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v2

    .line 369
    :try_start_d
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v0, p2}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v0

    move-object v1, v0

    .line 370
    monitor-exit v2
    :try_end_17
    .catchall {:try_start_d .. :try_end_17} :catchall_53

    .line 372
    if-eqz v1, :cond_4f

    .line 373
    monitor-enter v1

    .line 374
    :try_start_1a
    sget-object v0, Lcom/oplus/uifirst/IOplusUIFirstManager;->DEFAULT:Lcom/oplus/uifirst/IOplusUIFirstManager;

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v0, v2}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/oplus/uifirst/IOplusUIFirstManager;

    iget-object v0, v1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v3, v0, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget v4, v1, Lcom/android/server/am/ProcessRecord;->uid:I
    :try_end_2c
    .catchall {:try_start_1a .. :try_end_2c} :catchall_45

    move v5, p1

    move v6, p2

    move-object v7, p3

    .end local p1    # "op":I
    .end local p2    # "pid":I
    .end local p3    # "tids":[I
    .local v5, "op":I
    .local v6, "pid":I
    .local v7, "tids":[I
    :try_start_2f
    invoke-interface/range {v2 .. v7}, Lcom/oplus/uifirst/IOplusUIFirstManager;->setApplicationKeyThreads(Ljava/lang/String;III[I)V

    .line 375
    monitor-exit v1
    :try_end_33
    .catchall {:try_start_2f .. :try_end_33} :catchall_4c

    .line 378
    invoke-static {}, Lcom/oplus/closeloop/OplusCloseLoopManager;->getInstance()Lcom/oplus/closeloop/OplusCloseLoopManager;

    move-result-object p1

    if-eqz p1, :cond_52

    .line 379
    invoke-static {}, Lcom/oplus/closeloop/OplusCloseLoopManager;->getInstance()Lcom/oplus/closeloop/OplusCloseLoopManager;

    move-result-object p1

    iget-object p2, v1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object p2, p2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {p1, p2, v5}, Lcom/oplus/closeloop/OplusCloseLoopManager;->notifyFlutterStatus(Ljava/lang/String;I)V

    goto :goto_52

    .line 375
    .end local v5    # "op":I
    .end local v6    # "pid":I
    .end local v7    # "tids":[I
    .restart local p1    # "op":I
    .restart local p2    # "pid":I
    .restart local p3    # "tids":[I
    :catchall_45
    move-exception v0

    move v5, p1

    move v6, p2

    move-object v7, p3

    move-object p1, v0

    .end local p1    # "op":I
    .end local p2    # "pid":I
    .end local p3    # "tids":[I
    .restart local v5    # "op":I
    .restart local v6    # "pid":I
    .restart local v7    # "tids":[I
    :goto_4a
    :try_start_4a
    monitor-exit v1
    :try_end_4b
    .catchall {:try_start_4a .. :try_end_4b} :catchall_4c

    throw p1

    :catchall_4c
    move-exception v0

    move-object p1, v0

    goto :goto_4a

    .line 372
    .end local v5    # "op":I
    .end local v6    # "pid":I
    .end local v7    # "tids":[I
    .restart local p1    # "op":I
    .restart local p2    # "pid":I
    .restart local p3    # "tids":[I
    :cond_4f
    move v5, p1

    move v6, p2

    move-object v7, p3

    .line 383
    .end local p1    # "op":I
    .end local p2    # "pid":I
    .end local p3    # "tids":[I
    .restart local v5    # "op":I
    .restart local v6    # "pid":I
    .restart local v7    # "tids":[I
    :cond_52
    :goto_52
    return-void

    .line 370
    .end local v5    # "op":I
    .end local v6    # "pid":I
    .end local v7    # "tids":[I
    .restart local p1    # "op":I
    .restart local p2    # "pid":I
    .restart local p3    # "tids":[I
    :catchall_53
    move-exception v0

    move v5, p1

    move v6, p2

    move-object v7, p3

    move-object p1, v0

    .end local p1    # "op":I
    .end local p2    # "pid":I
    .end local p3    # "tids":[I
    .restart local v5    # "op":I
    .restart local v6    # "pid":I
    .restart local v7    # "tids":[I
    :goto_58
    :try_start_58
    monitor-exit v2
    :try_end_59
    .catchall {:try_start_58 .. :try_end_59} :catchall_5a

    throw p1

    :catchall_5a
    move-exception v0

    move-object p1, v0

    goto :goto_58
.end method

.method public setPayJoyFlag(I)Z
    .registers 6
    .param p1, "payjoyFlag"    # I

    .line 1743
    invoke-static {}, Lcom/oplus/content/OplusFeatureConfigManager;->getInstance()Lcom/oplus/content/OplusFeatureConfigManager;

    move-result-object v0

    const-string/jumbo v1, "oplus.software.payjoy_support"

    invoke-virtual {v0, v1}, Lcom/oplus/content/OplusFeatureConfigManager;->hasFeature(Ljava/lang/String;)Z

    move-result v0

    .line 1745
    .local v0, "isPayjoyEnabled":Z
    const/4 v1, 0x0

    const-string v2, "OplusActivityManagerServiceEnhance"

    if-eqz v0, :cond_21

    .line 1746
    invoke-static {}, Landroid/payjoy/PayJoyCustomizedManager;->getInstance()Landroid/payjoy/PayJoyCustomizedManager;

    move-result-object v3

    .line 1747
    .local v3, "pcm":Landroid/payjoy/PayJoyCustomizedManager;
    if-eqz v3, :cond_20

    .line 1748
    invoke-virtual {v3}, Landroid/payjoy/PayJoyCustomizedManager;->activatePayJoyControl()V

    .line 1749
    const-string v1, "activatePayJoyControl true"

    invoke-static {v2, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1750
    const/4 v1, 0x1

    return v1

    .line 1752
    :cond_20
    return v1

    .line 1754
    .end local v3    # "pcm":Landroid/payjoy/PayJoyCustomizedManager;
    :cond_21
    const-string/jumbo v3, "payjoyFlag is noPayjoyEnabled feature "

    invoke-static {v2, v3}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 1755
    return v1
.end method

.method public setPermissionInterceptEnable(Z)V
    .registers 6
    .param p1, "enabled"    # Z

    .line 605
    const-string/jumbo v0, "setPermissionInterceptEnable"

    :try_start_3
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v2, "oplus.permission.OPLUS_COMPONENT_SAFE"

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_b} :catch_c

    .line 608
    goto :goto_14

    .line 606
    :catch_c
    move-exception v1

    .line 607
    .local v1, "ex":Ljava/lang/SecurityException;
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string v3, "android.permission.GRANT_RUNTIME_PERMISSIONS"

    invoke-virtual {v2, v3, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 609
    .end local v1    # "ex":Ljava/lang/SecurityException;
    :goto_14
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    if-eqz v0, :cond_1d

    .line 610
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    invoke-virtual {v0, p1}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->setPermissionInterceptEnable(Z)V

    .line 612
    :cond_1d
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v0, :cond_3a

    .line 613
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setPermissionInterceptEnable pkg="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusActivityManagerServiceEnhance"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 615
    :cond_3a
    return-void
.end method

.method public setPermissionRecordController(Lcom/oplus/app/IOplusPermissionRecordController;)V
    .registers 5
    .param p1, "watcher"    # Lcom/oplus/app/IOplusPermissionRecordController;

    .line 1057
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "setPermissionRecordController"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1058
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {v0}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->getInstance(Lcom/android/server/am/ActivityManagerService;)Lcom/android/server/am/OplusPermissionInterceptPolicy;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->setPermissionRecordController(Lcom/oplus/app/IOplusPermissionRecordController;)V

    .line 1059
    return-void
.end method

.method public setPreventIndulgeController(Lcom/oplus/app/IOplusAppStartController;)V
    .registers 5
    .param p1, "controller"    # Lcom/oplus/app/IOplusAppStartController;

    .line 948
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "setPreventIndulgeController"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 950
    sget-object v0, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusAppStartupManager;->setPreventIndulgeController(Lcom/oplus/app/IOplusAppStartController;)V

    .line 951
    return-void
.end method

.method public setSceneActionTransit(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 8
    .param p1, "scene"    # Ljava/lang/String;
    .param p2, "action"    # Ljava/lang/String;
    .param p3, "timeout"    # I

    .line 1573
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    if-nez v0, :cond_e

    const-class v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    invoke-static {v0}, Lcom/oplus/osense/OsenseResClient;->get(Ljava/lang/Class;)Lcom/oplus/osense/OsenseResClient;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    if-eqz v0, :cond_20

    .line 1574
    :cond_e
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0

    .line 1576
    .local v0, "token":J
    :try_start_12
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOsenseClient:Lcom/oplus/osense/OsenseResClient;

    new-instance v3, Lcom/oplus/osense/info/OsenseSaRequest;

    invoke-direct {v3, p1, p2, p3}, Lcom/oplus/osense/info/OsenseSaRequest;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Lcom/oplus/osense/OsenseResClient;->osenseSetSceneAction(Lcom/oplus/osense/info/OsenseSaRequest;)J
    :try_end_1c
    .catchall {:try_start_12 .. :try_end_1c} :catchall_21

    .line 1578
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1579
    nop

    .line 1581
    .end local v0    # "token":J
    :cond_20
    return-void

    .line 1578
    .restart local v0    # "token":J
    :catchall_21
    move-exception v2

    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1579
    throw v2
.end method

.method public setSystemProperties(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3
    .param p1, "properties"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 628
    return-void
.end method

.method public startActivity(Landroid/content/Intent;)V
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;

    .line 1921
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1922
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "startActivity"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1923
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1926
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1928
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-virtual {v3, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1a
    .catchall {:try_start_15 .. :try_end_1a} :catchall_1f

    .line 1930
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1931
    nop

    .line 1932
    return-void

    .line 1930
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1931
    throw v3

    .line 1924
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access startActivity, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public startActivityAsUser(Landroid/content/Intent;Landroid/os/Bundle;Landroid/os/UserHandle;)V
    .registers 8
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "options"    # Landroid/os/Bundle;
    .param p3, "userHandle"    # Landroid/os/UserHandle;

    .line 1936
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1937
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "startActivityAsUser"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1938
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1941
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1943
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-virtual {v3, p1, p2, p3}, Landroid/content/Context;->startActivityAsUser(Landroid/content/Intent;Landroid/os/Bundle;Landroid/os/UserHandle;)V
    :try_end_1a
    .catchall {:try_start_15 .. :try_end_1a} :catchall_1f

    .line 1945
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1946
    nop

    .line 1947
    return-void

    .line 1945
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1946
    throw v3

    .line 1939
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access startActivityAsUser, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public startProcess(Ljava/lang/String;I)I
    .registers 6
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "userId"    # I

    .line 1952
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.android.launcher.permission.ACTION_DEEP_PROTECT_START_APP"

    const-string/jumbo v2, "startProcess"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1953
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0

    .line 1955
    .local v0, "origId":J
    :try_start_e
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v2, p1, p2}, Lcom/android/server/am/IActivityManagerServiceExt;->startProcess(Ljava/lang/String;I)I

    move-result v2
    :try_end_16
    .catchall {:try_start_e .. :try_end_16} :catchall_1a

    .line 1957
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1955
    return v2

    .line 1957
    :catchall_1a
    move-exception v2

    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1958
    throw v2
.end method

.method public startProcessWithFreeze(Ljava/lang/String;I)Z
    .registers 9
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 2180
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.android.launcher.permission.ACTION_DEEP_PROTECT_START_APP"

    const-string/jumbo v2, "startProcessWithFreeze"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 2181
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0

    .line 2183
    .local v0, "origId":J
    :try_start_e
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v2, p1, p2}, Lcom/android/server/am/IActivityManagerServiceExt;->startProcessWithFreeze(Ljava/lang/String;I)Z

    move-result v2
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_16} :catch_1d
    .catchall {:try_start_e .. :try_end_16} :catchall_1b

    .line 2184
    .local v2, "result":Z
    nop

    .line 2189
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 2184
    return v2

    .line 2189
    .end local v2    # "result":Z
    :catchall_1b
    move-exception v2

    goto :goto_3c

    .line 2185
    :catch_1d
    move-exception v2

    .line 2186
    .local v2, "e":Ljava/lang/Exception;
    :try_start_1e
    const-string v3, "OplusActivityManagerServiceEnhance"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Error in startProcessWithFreeze: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 2187
    nop

    .end local v0    # "origId":J
    .end local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEnhance;
    .end local p1    # "packageName":Ljava/lang/String;
    .end local p2    # "uid":I
    throw v2
    :try_end_3c
    .catchall {:try_start_1e .. :try_end_3c} :catchall_1b

    .line 2189
    .end local v2    # "e":Ljava/lang/Exception;
    .restart local v0    # "origId":J
    .restart local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEnhance;
    .restart local p1    # "packageName":Ljava/lang/String;
    .restart local p2    # "uid":I
    :goto_3c
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 2190
    throw v2
.end method

.method public startUserInBackground(I)Z
    .registers 6
    .param p1, "userId"    # I

    .line 1906
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1907
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "startUserInBackground"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1908
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1911
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1913
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->startUserInBackground(I)Z

    move-result v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1915
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1913
    return v3

    .line 1915
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1916
    throw v3

    .line 1909
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access startUserInBackground, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public switchUser(I)Z
    .registers 6
    .param p1, "userId"    # I

    .line 1876
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1877
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "switchUser"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1878
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1881
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1883
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->switchUser(I)Z

    move-result v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1885
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1883
    return v3

    .line 1885
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1886
    throw v3

    .line 1879
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access switchUser, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public syncPermissionRecord()V
    .registers 4

    .line 770
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "syncPermissionRecord"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 771
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {v0}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->getInstance(Lcom/android/server/am/ActivityManagerService;)Lcom/android/server/am/OplusPermissionInterceptPolicy;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->syncPermissionRecord()V

    .line 772
    return-void
.end method

.method public systemReady()V
    .registers 3

    .line 263
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    if-eqz v0, :cond_d

    .line 264
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {v0}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->getInstance(Lcom/android/server/am/ActivityManagerService;)Lcom/android/server/am/OplusPermissionInterceptPolicy;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    goto :goto_15

    .line 266
    :cond_d
    const-string v0, "OplusActivityManagerServiceEnhance"

    const-string/jumbo v1, "mPermissionInterceptPolicy init error ams is null"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 270
    :goto_15
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;->getInstance(Landroid/content/Context;)Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mFontVariationAdaptionUtils:Lcom/android/server/graphics/fonts/OplusFontVariationAdaptionUtils;

    .line 271
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;->getInstance(Landroid/content/Context;)Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mSecureKeyboardUtils:Lcom/android/server/inputmethod/OplusSecureKeyboardUtils;

    .line 273
    return-void
.end method

.method public trimSystemMemory(IZ)V
    .registers 6
    .param p1, "level"    # I
    .param p2, "needGc"    # Z

    .line 1714
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "trimSystemMemory"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1716
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusAthenaAmManager;->trimSystemMemory(IZ)V

    .line 1717
    return-void
.end method

.method public unfreezeForKernel(IIILjava/lang/String;I)V
    .registers 6
    .param p1, "type"    # I
    .param p2, "callerPid"    # I
    .param p3, "targetUid"    # I
    .param p4, "rpcName"    # Ljava/lang/String;
    .param p5, "code"    # I

    .line 283
    return-void
.end method

.method public unfreezeForKernelTargetPid(IIIIILjava/lang/String;I)V
    .registers 8
    .param p1, "type"    # I
    .param p2, "callerPid"    # I
    .param p3, "callerUid"    # I
    .param p4, "targetPid"    # I
    .param p5, "targetUid"    # I
    .param p6, "rpcName"    # Ljava/lang/String;
    .param p7, "code"    # I

    .line 303
    return-void
.end method

.method public unregisterAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    .line 739
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oppo.permission.safe.LOG"

    const-string/jumbo v2, "unregisterAbConfigCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 740
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->unregisterAbConfigCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 741
    return-void
.end method

.method public unregisterComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z
    .registers 6
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "observer"    # Lcom/oplus/osense/complexscene/IComplexSceneObserver;

    .line 1667
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.WINDOW"

    const-string/jumbo v2, "unregisterComplexSceneObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1669
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusOsenseCommonManager;->unregisterComplexSceneObserver(Landroid/os/Bundle;Lcom/oplus/osense/complexscene/IComplexSceneObserver;)Z

    move-result v0

    return v0
.end method

.method public unregisterEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eap/IOplusEapDataCallback;

    .line 704
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "unregisterEapDataCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 706
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->unregisterEapDataCallback(Lcom/oplus/eap/IOplusEapDataCallback;)V

    .line 707
    return-void
.end method

.method public unregisterErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V
    .registers 5
    .param p1, "callback"    # Lcom/oplus/eventhub/sdk/aidl/IEventCallback;

    .line 725
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "unregisterErrorInfoCallback"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 727
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->unregisterErrorInfoCallback(Lcom/oplus/eventhub/sdk/aidl/IEventCallback;)V

    .line 728
    return-void
.end method

.method public unregisterHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z
    .registers 6
    .param p1, "callerPkg"    # Ljava/lang/String;
    .param p2, "listener"    # Lcom/oplus/app/IOplusHansListener;

    .line 1255
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "unregisterHansListener"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1256
    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0, p1, p2}, Lcom/android/server/am/IOplusHansManager;->unregisterHansListener(Ljava/lang/String;Lcom/oplus/app/IOplusHansListener;)Z

    move-result v0

    return v0
.end method

.method public unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/IProcessTerminateObserver;

    .line 1600
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string v1, "com.oplus.permission.safe.APP_MANAGER"

    const-string/jumbo v2, "unregisterTerminateObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1602
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->unregisterTerminateObserver(Lcom/oplus/app/IProcessTerminateObserver;)Z

    move-result v0

    return v0
.end method

.method public unregisterTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z
    .registers 5
    .param p1, "observer"    # Lcom/oplus/app/ITerminateObserver;

    .line 1640
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "unregisterTerminateStateObserver"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 1642
    sget-object v0, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusOsenseCommonManager;->unregisterTerminateStateObserver(Lcom/oplus/app/ITerminateObserver;)Z

    move-result v0

    return v0
.end method

.method public updateANRDumpState(Landroid/os/SharedMemory;)V
    .registers 5
    .param p1, "data"    # Landroid/os/SharedMemory;

    .line 710
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const-string/jumbo v2, "updateANRDumpState"

    invoke-virtual {v0, v1, v2}, Lcom/android/server/am/ActivityManagerService;->enforceCallingPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 712
    sget-object v0, Lcom/android/server/am/IOplusEapManager;->DEFAULT:Lcom/android/server/am/IOplusEapManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusEapManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusEapManager;->updateANRDumpState(Landroid/os/SharedMemory;)V

    .line 713
    return-void
.end method

.method public updateConfiguration(Landroid/content/res/Configuration;)Z
    .registers 6
    .param p1, "configuration"    # Landroid/content/res/Configuration;

    .line 1831
    invoke-static {}, Lcom/oplus/shield/OplusAuthCheck;->getInstance()Lcom/oplus/shield/OplusAuthCheck;

    move-result-object v0

    .line 1832
    const-string v1, "OplusActivityManager"

    const-string/jumbo v2, "updateConfiguration"

    invoke-virtual {v0, v1, v2}, Lcom/oplus/shield/OplusAuthCheck;->checkCallingAuthCode(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1833
    .local v0, "checkResult":I
    const/16 v1, 0x3e9

    if-ne v1, v0, :cond_24

    .line 1836
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    .line 1838
    .local v1, "token":J
    :try_start_15
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v3, p1}, Lcom/android/server/am/ActivityManagerService;->updateConfiguration(Landroid/content/res/Configuration;)Z

    move-result v3
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1f

    .line 1840
    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1838
    return v3

    .line 1840
    :catchall_1f
    move-exception v3

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    .line 1841
    throw v3

    .line 1834
    .end local v1    # "token":J
    :cond_24
    new-instance v1, Ljava/lang/SecurityException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to access updateConfiguration, return code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public updateCpuTracker(J)F
    .registers 13
    .param p1, "lastUpdateTime"    # J

    .line 976
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    if-nez v0, :cond_17

    .line 977
    new-instance v0, Lcom/android/internal/os/ProcessCpuTracker;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/os/ProcessCpuTracker;-><init>(Z)V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    .line 978
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v0}, Lcom/android/internal/os/ProcessCpuTracker;->init()V

    .line 979
    invoke-direct {p0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->getAllCoreNum()I

    move-result v0

    iput v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCoreNum:I

    .line 981
    :cond_17
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v0}, Lcom/android/internal/os/ProcessCpuTracker;->update()V

    .line 982
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 983
    .local v0, "now":J
    sub-long v2, v0, p1

    iget v4, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCoreNum:I

    int-to-long v4, v4

    mul-long/2addr v2, v4

    iput-wide v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    .line 984
    iget-wide v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-gtz v2, :cond_32

    .line 985
    const/4 v2, 0x0

    return v2

    .line 987
    :cond_32
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v2}, Lcom/android/internal/os/ProcessCpuTracker;->getLastUserTime()I

    move-result v2

    .line 988
    .local v2, "relUserTime":I
    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v3}, Lcom/android/internal/os/ProcessCpuTracker;->getLastSystemTime()I

    move-result v3

    .line 989
    .local v3, "relSystemTime":I
    iget-object v4, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mCpuTracker:Lcom/android/internal/os/ProcessCpuTracker;

    invoke-virtual {v4}, Lcom/android/internal/os/ProcessCpuTracker;->getLastIrqTime()I

    move-result v4

    .line 990
    .local v4, "relIrqTime":I
    add-int v5, v2, v3

    add-int/2addr v5, v4

    int-to-long v5, v5

    .line 991
    .local v5, "totalBusyTime":J
    nop

    .line 992
    const-wide/16 v7, 0xa

    div-long/2addr v5, v7

    .line 994
    long-to-float v7, v5

    const/high16 v8, 0x447a0000    # 1000.0f

    mul-float/2addr v7, v8

    iget-wide v8, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mTotalSampleInterval:J

    long-to-float v8, v8

    div-float/2addr v7, v8

    .line 995
    .local v7, "totalPercent":F
    return v7
.end method

.method public updatePermissionChoice(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 8
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "permission"    # Ljava/lang/String;
    .param p3, "choice"    # I

    .line 561
    const-string/jumbo v0, "updatePermissionChoice"

    :try_start_3
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v2, "oplus.permission.OPLUS_COMPONENT_SAFE"

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_b} :catch_c

    .line 564
    goto :goto_14

    .line 562
    :catch_c
    move-exception v1

    .line 563
    .local v1, "ex":Ljava/lang/SecurityException;
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string v3, "android.permission.GRANT_RUNTIME_PERMISSIONS"

    invoke-virtual {v2, v3, v0}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 565
    .end local v1    # "ex":Ljava/lang/SecurityException;
    :goto_14
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    if-eqz v0, :cond_1d

    .line 566
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mPermissionInterceptPolicy:Lcom/android/server/am/OplusPermissionInterceptPolicy;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/am/OplusPermissionInterceptPolicy;->updatePermissionChoice(Ljava/lang/String;Ljava/lang/String;I)V

    .line 568
    :cond_1d
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->DEBUG:Z

    if-eqz v0, :cond_44

    .line 569
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "updatePermissionChoice pkg="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ",permission="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusActivityManagerServiceEnhance"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 571
    :cond_44
    return-void
.end method

.method public updateTsaMap(Ljava/lang/String;IZ)V
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "tid"    # I
    .param p3, "toTop"    # Z

    .line 2029
    invoke-static {}, Lcom/oplus/tsabpf/OplusTsaBpfManager;->getInstance()Lcom/oplus/tsabpf/OplusTsaBpfManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/oplus/tsabpf/OplusTsaBpfManager;->updateTsaMap(Ljava/lang/String;IZ)V

    .line 2030
    return-void
.end method

.method public updateUidCpuTracker()V
    .registers 4

    .line 542
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mContext:Landroid/content/Context;

    const-string/jumbo v1, "oplus.permission.OPLUS_COMPONENT_SAFE"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->enforceCallingOrSelfPermission(Ljava/lang/String;Ljava/lang/String;)V

    .line 543
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->mOplusUidCpuTimeReader:Lcom/android/server/am/OplusUidCpuTimeReader;

    invoke-virtual {v0}, Lcom/android/server/am/OplusUidCpuTimeReader;->update()V

    .line 544
    return-void
.end method
