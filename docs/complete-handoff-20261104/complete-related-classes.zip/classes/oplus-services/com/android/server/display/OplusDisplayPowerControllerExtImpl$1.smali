.class Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;
.super Ljava/lang/Object;
.source "OplusDisplayPowerControllerExtImpl.java"

# interfaces
.implements Landroid/hardware/display/DisplayManager$DisplayListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private mDisplayHeight:I

.field private final mDisplayManagerInternal:Landroid/hardware/display/DisplayManagerInternal;

.field private mDisplayWidth:I

.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V
    .registers 3
    .param p1, "this$0"    # Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 1675
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1676
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayWidth:I

    .line 1677
    iput v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayHeight:I

    .line 1678
    const-class v0, Landroid/hardware/display/DisplayManagerInternal;

    invoke-static {v0}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManagerInternal;

    iput-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayManagerInternal:Landroid/hardware/display/DisplayManagerInternal;

    return-void
.end method


# virtual methods
.method public onDisplayAdded(I)V
    .registers 2
    .param p1, "displayId"    # I

    .line 1683
    return-void
.end method

.method public onDisplayChanged(I)V
    .registers 9
    .param p1, "displayId"    # I

    .line 1692
    if-nez p1, :cond_72

    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayManagerInternal:Landroid/hardware/display/DisplayManagerInternal;

    if-eqz v0, :cond_72

    .line 1693
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayManagerInternal:Landroid/hardware/display/DisplayManagerInternal;

    invoke-virtual {v0, p1}, Landroid/hardware/display/DisplayManagerInternal;->getDisplayInfo(I)Landroid/view/DisplayInfo;

    move-result-object v0

    .line 1694
    .local v0, "displayInfo":Landroid/view/DisplayInfo;
    if-eqz v0, :cond_72

    .line 1695
    invoke-virtual {v0}, Landroid/view/DisplayInfo;->getNaturalWidth()I

    move-result v1

    .line 1696
    .local v1, "newWidth":I
    invoke-virtual {v0}, Landroid/view/DisplayInfo;->getNaturalHeight()I

    move-result v2

    .line 1697
    .local v2, "newHeight":I
    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayWidth:I

    if-lez v3, :cond_66

    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayHeight:I

    if-lez v3, :cond_66

    iget v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayWidth:I

    if-eq v1, v3, :cond_66

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v3

    if-eqz v3, :cond_66

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/display/DisplayPowerState;->getWrapper()Lcom/android/server/display/IDisplayPowerStateWrapper;

    move-result-object v3

    invoke-interface {v3}, Lcom/android/server/display/IDisplayPowerStateWrapper;->getColorFadePrepared()Z

    move-result v3

    if-eqz v3, :cond_66

    .line 1698
    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/display/DisplayPowerState;->getColorFadeLevel()F

    move-result v3

    .line 1699
    .local v3, "level":F
    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/display/DisplayPowerState;->dismissColorFade()V

    .line 1700
    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v5}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmContext(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/content/Context;

    move-result-object v5

    const/4 v6, 0x2

    invoke-virtual {v4, v5, v6}, Lcom/android/server/display/DisplayPowerState;->prepareColorFade(Landroid/content/Context;I)Z

    .line 1701
    iget-object v4, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPowerState(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/DisplayPowerState;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/android/server/display/DisplayPowerState;->setColorFadeLevel(F)V

    .line 1703
    .end local v3    # "level":F
    :cond_66
    invoke-virtual {v0}, Landroid/view/DisplayInfo;->getNaturalWidth()I

    move-result v3

    iput v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayWidth:I

    .line 1704
    invoke-virtual {v0}, Landroid/view/DisplayInfo;->getNaturalHeight()I

    move-result v3

    iput v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$1;->mDisplayHeight:I

    .line 1707
    .end local v0    # "displayInfo":Landroid/view/DisplayInfo;
    .end local v1    # "newWidth":I
    .end local v2    # "newHeight":I
    :cond_72
    return-void
.end method

.method public onDisplayRemoved(I)V
    .registers 2
    .param p1, "displayId"    # I

    .line 1688
    return-void
.end method
