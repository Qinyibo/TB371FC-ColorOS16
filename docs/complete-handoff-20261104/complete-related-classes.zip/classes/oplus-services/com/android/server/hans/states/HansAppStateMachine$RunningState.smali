.class Lcom/android/server/hans/states/HansAppStateMachine$RunningState;
.super Lcom/android/server/hans/states/State;
.source "HansAppStateMachine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/states/HansAppStateMachine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "RunningState"
.end annotation


# instance fields
.field restrictNet:Z

.field retry:I

.field final synthetic this$0:Lcom/android/server/hans/states/HansAppStateMachine;


# direct methods
.method public constructor <init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p1, "this$0"    # Lcom/android/server/hans/states/HansAppStateMachine;
    .param p2, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 251
    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-direct {p0}, Lcom/android/server/hans/states/State;-><init>()V

    .line 252
    new-instance v0, Lcom/android/server/hans/states/action/RunningAction;

    invoke-direct {v0, p2}, Lcom/android/server/hans/states/action/RunningAction;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->mAction:Lcom/android/server/hans/states/action/Action;

    .line 253
    return-void
.end method

.method private canRestrictNet(Ljava/lang/String;ILjava/lang/String;)V
    .registers 5
    .param p1, "impReason"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .param p3, "pkgName"    # Ljava/lang/String;

    .line 484
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_39

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 485
    invoke-virtual {v0, p1}, Lcom/android/server/hans/OplusHansDBConfig;->restrictRStateNetEnable(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_39

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 486
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->keyProcAlarmEnable()Z

    move-result v0

    if-eqz v0, :cond_39

    .line 487
    const-string v0, "audioFocus"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_39

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 488
    invoke-virtual {v0, p3, p1}, Lcom/android/server/hans/OplusHansDBConfig;->inTargetTypeKeyPorcMonitorList(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_39

    .line 489
    invoke-direct {p0, p1, p2, p3}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNonKeyProcsNet(Ljava/lang/String;ILjava/lang/String;)V

    .line 491
    :cond_39
    return-void
.end method

.method private isImportantForSMToMiddle()Z
    .registers 6

    .line 413
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->isImportantForSM(Z)Z

    move-result v0

    .line 415
    .local v0, "isImportant":Z
    if-eqz v0, :cond_9c

    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansDBConfig;->isSysBlackApp(I)Z

    move-result v1

    if-eqz v1, :cond_9c

    .line 417
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 418
    :try_start_28
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getQuotaTaskStatus()I

    move-result v2

    .line 419
    .local v2, "taskStatus":I
    monitor-exit v1
    :try_end_33
    .catchall {:try_start_28 .. :try_end_33} :catchall_99

    .line 420
    and-int/lit8 v1, v2, 0x2

    if-nez v1, :cond_9c

    .line 421
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansDBConfig;->isBgModeImportantReason(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9c

    .line 422
    const/4 v0, 0x0

    .line 423
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_9c

    .line 424
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " has importance="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 425
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " without applying continuous task."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 424
    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    goto :goto_9c

    .line 419
    .end local v2    # "taskStatus":I
    :catchall_99
    move-exception v2

    :try_start_9a
    monitor-exit v1
    :try_end_9b
    .catchall {:try_start_9a .. :try_end_9b} :catchall_99

    throw v2

    .line 429
    :cond_9c
    :goto_9c
    return v0
.end method

.method private restrictNonKeyProcsNet(Ljava/lang/String;ILjava/lang/String;)V
    .registers 7
    .param p1, "impReason"    # Ljava/lang/String;
    .param p2, "uid"    # I
    .param p3, "pkgName"    # Ljava/lang/String;

    .line 494
    iget v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    const/4 v1, 0x3

    if-ge v0, v1, :cond_71

    iget-boolean v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    if-nez v0, :cond_71

    .line 495
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/am/OplusHansManager;->restrictRStateNonKeyProcsNet(Ljava/lang/String;ILjava/lang/String;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    .line 496
    iget-boolean v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    if-nez v0, :cond_1d

    .line 497
    iget v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    .line 499
    :cond_1d
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_71

    .line 500
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "restrictNonKeyProcsNet: uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " impReason: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", restrictNet: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", retry: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 503
    :cond_71
    return-void
.end method

.method private transToFrozen()V
    .registers 2

    .line 433
    const-string v0, ""

    invoke-direct {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen(Ljava/lang/String;)V

    .line 434
    return-void
.end method

.method private transToFrozen(Ljava/lang/String;)V
    .registers 13
    .param p1, "transReason"    # Ljava/lang/String;

    .line 437
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    if-eqz v0, :cond_5a

    .line 438
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R is already frozen"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 439
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_35b

    .line 440
    :cond_5a
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x1

    invoke-virtual {v0, v1, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->isImportantForSM(ZLjava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_183

    .line 441
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " cannot transition from R to F, importance="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 442
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v2, "R->F"

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->addImportanceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 444
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v2, v3, v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckExistingQuotaTask(Lcom/android/server/hans/states/HansAppStateMachine;ILjava/lang/String;Ljava/lang/String;)V

    .line 445
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v0, v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->canRestrictNet(Ljava/lang/String;ILjava/lang/String;)V

    .line 446
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-nez v0, :cond_35b

    .line 447
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    .line 448
    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v7

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v9

    .line 447
    const/4 v8, 0x1

    invoke-virtual/range {v4 .. v9}, Lcom/android/server/hans/OplusHansDBConfig;->getImportantAdditionalRepeatTime(Ljava/lang/String;IIZI)J

    move-result-wide v3

    invoke-virtual {v0, v2, v3, v4}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 449
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    goto/16 :goto_35b

    .line 452
    :cond_183
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    .line 453
    .local v4, "curElapsedTime":J
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v2

    sub-long v9, v4, v2

    .line 454
    .local v9, "deltaTime":J
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v2

    cmp-long v0, v9, v2

    if-gtz v0, :cond_25f

    .line 455
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/android/server/am/OplusHansManager;->hasTouchedWindow(ILjava/lang/String;)I

    move-result v0

    if-ne v0, v1, :cond_213

    .line 456
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v1

    sub-long/2addr v1, v9

    const/16 v3, 0x15

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 457
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " can not transition from R to F. reason: inputEvent"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 458
    return-void

    .line 460
    :cond_213
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_25f

    .line 461
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " no input event"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 465
    :cond_25f
    const-string v0, "Super_F"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2dc

    .line 466
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 467
    :try_start_272
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansPackage;->setSuperFRZMode(Z)V

    .line 468
    monitor-exit v2
    :try_end_27c
    .catchall {:try_start_272 .. :try_end_27c} :catchall_2d9

    .line 469
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyFrzOkInSpFRZ(ILjava/lang/String;)V

    .line 470
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "sp_FRZ uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 471
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", frozen by super freeze"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 470
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_350

    .line 468
    :catchall_2d9
    move-exception v0

    :try_start_2da
    monitor-exit v2
    :try_end_2db
    .catchall {:try_start_2da .. :try_end_2db} :catchall_2d9

    throw v0

    .line 473
    :cond_2dc
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeTime()J

    move-result-wide v6

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v8

    invoke-static/range {v3 .. v8}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckDelayFreeze(Lcom/android/server/hans/states/HansAppStateMachine;JJLjava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    .line 474
    .local v0, "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_350

    .line 475
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " can not transition from R to F. reason: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 476
    return-void

    .line 479
    .end local v0    # "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    :cond_350
    :goto_350
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 481
    .end local v4    # "curElapsedTime":J
    .end local v9    # "deltaTime":J
    :cond_35b
    :goto_35b
    return-void
.end method

.method private transToMiddle(Z)V
    .registers 11
    .param p1, "needImportanceCheck"    # Z

    .line 394
    if-eqz p1, :cond_105

    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->isImportantForSMToMiddle()Z

    move-result v0

    if-eqz v0, :cond_105

    .line 395
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " cannot transition from R to M, importance="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 396
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "R->M"

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addImportanceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 398
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v0, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->canRestrictNet(Ljava/lang/String;ILjava/lang/String;)V

    .line 399
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-nez v0, :cond_14b

    .line 400
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v3

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 401
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v6

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v8

    .line 400
    const/4 v7, 0x1

    invoke-virtual/range {v3 .. v8}, Lcom/android/server/hans/OplusHansDBConfig;->getImportantAdditionalRepeatTime(Ljava/lang/String;IIZI)J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 402
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    goto :goto_14b

    .line 405
    :cond_105
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmMiddleState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 407
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 408
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v6

    .line 407
    const-string v8, ""

    invoke-virtual/range {v2 .. v8}, Lcom/android/server/hans/OplusHansDBConfig;->getMtoFCheckTime(ILjava/lang/String;IJLjava/lang/String;)J

    move-result-wide v1

    const/16 v3, 0x8

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 410
    :cond_14b
    :goto_14b
    return-void
.end method


# virtual methods
.method public enter()V
    .registers 4

    .line 257
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    .line 258
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->recoverNonKeyProcsNet()V

    .line 259
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mrecordEnterSMTime(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    .line 260
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R enter(), D stay="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 261
    return-void
.end method

.method public exit()V
    .registers 4

    .line 266
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R exit(), R stay="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 268
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->mAction:Lcom/android/server/hans/states/action/Action;

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->clearAction()V

    .line 269
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 270
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mrecordEnterSMTime(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    .line 271
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 390
    const-string v0, "Running"

    return-object v0
.end method

.method public processMessage(Landroid/os/Message;)Z
    .registers 13
    .param p1, "msg"    # Landroid/os/Message;

    .line 275
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v4, "uid="

    const-string v5, ", pkg="

    sparse-switch v0, :sswitch_data_4b4

    .line 383
    return v3

    .line 369
    :sswitch_e
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    const-string/jumbo v1, "sp_FRZ uid="

    if-eqz v0, :cond_53

    .line 370
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 371
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " CMD_RtoF_SUPER_FREEZE"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 370
    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 373
    :cond_53
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 374
    .local v0, "transReason":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v2

    if-eqz v2, :cond_a4

    .line 375
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 376
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", FF is on, delay transition to F until FF exit."

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 375
    invoke-virtual {v2, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 377
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoFinFastFrzOnSuperFZMode(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto/16 :goto_4b2

    .line 379
    :cond_a4
    invoke-direct {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen(Ljava/lang/String;)V

    .line 381
    goto/16 :goto_4b2

    .line 364
    .end local v0    # "transReason":Ljava/lang/String;
    :sswitch_a9
    invoke-direct {p0, v2}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToMiddle(Z)V

    .line 365
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->addForceTransToMiddleStateUid(I)V

    .line 366
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", transition from R to M, reason=force "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 367
    goto/16 :goto_4b2

    .line 352
    :sswitch_103
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 353
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 354
    .local v0, "destState":I
    const/4 v1, 0x2

    if-ne v0, v1, :cond_115

    .line 355
    invoke-direct {p0, v3}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToMiddle(Z)V

    goto :goto_129

    .line 356
    :cond_115
    const/4 v1, 0x3

    if-ne v0, v1, :cond_11c

    .line 357
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen()V

    goto :goto_129

    .line 358
    :cond_11c
    if-nez v0, :cond_129

    .line 359
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 361
    :cond_129
    :goto_129
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ", transition from R to "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getStateName(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ", reason="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 362
    goto/16 :goto_4b2

    .line 347
    .end local v0    # "destState":I
    :sswitch_17f
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->removeAllMessages()V

    .line 348
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 349
    .local v0, "reason":Ljava/lang/String;
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " SM all messages removed, reason: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 350
    goto/16 :goto_4b2

    .line 342
    .end local v0    # "reason":Ljava/lang/String;
    :sswitch_1ca
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-nez v0, :cond_4b2

    .line 343
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen()V

    goto/16 :goto_4b2

    .line 301
    :sswitch_1d9
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mremoveAllMessagesExceptEnterSM(Lcom/android/server/hans/states/HansAppStateMachine;)V

    .line 302
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R exit SM"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 303
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 304
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 305
    goto/16 :goto_4b2

    .line 307
    :sswitch_230
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 308
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_4b2

    .line 309
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen()V

    goto/16 :goto_4b2

    .line 323
    :sswitch_244
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z

    move-result v0

    const-string v1, "FF exit, uid="

    if-eqz v0, :cond_297

    .line 324
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v6}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v6}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, " R transition to F"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 325
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen()V

    .line 326
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    .line 327
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    .line 329
    :cond_297
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z

    move-result v0

    if-eqz v0, :cond_2e3

    .line 330
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " R transition to M"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 331
    invoke-direct {p0, v3}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToMiddle(Z)V

    .line 332
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    .line 334
    :cond_2e3
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRtoFinFastFrzOnSuperFZMode(Lcom/android/server/hans/states/HansAppStateMachine;)Z

    move-result v0

    if-eqz v0, :cond_4b2

    .line 335
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "sp_FRZ FF exit, uid="

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 336
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " R transition to F."

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 335
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 337
    const-string v0, "Super_F"

    invoke-direct {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen(Ljava/lang/String;)V

    .line 338
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoFinFastFrzOnSuperFZMode(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto/16 :goto_4b2

    .line 277
    :sswitch_336
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v2, 0x67

    invoke-virtual {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 278
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 279
    .local v0, "curResumedUid":I
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    if-ne v2, v0, :cond_390

    .line 280
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " R LCD ON, is curResumedUid, transition to Default"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 282
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_4b2

    .line 284
    :cond_390
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v2

    if-nez v2, :cond_4b2

    .line 286
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v6

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 287
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v8

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v9

    .line 286
    invoke-virtual/range {v5 .. v10}, Lcom/android/server/hans/OplusHansDBConfig;->getRtoMCheckTime(ILjava/lang/String;IJ)J

    move-result-wide v4

    invoke-virtual {v2, v1, v4, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    goto/16 :goto_4b2

    .line 313
    .end local v0    # "curResumedUid":I
    :sswitch_3d5
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-eqz v0, :cond_422

    .line 314
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R CMD_FREEZE but FastFreeze is on, delay the transition to F until FastFreezerExit"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 316
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto/16 :goto_4b2

    .line 318
    :cond_422
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R CMD_FREEZE"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 319
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToFrozen()V

    .line 321
    goto :goto_4b2

    .line 293
    :sswitch_462
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-eqz v0, :cond_4ae

    .line 294
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " R FastFreeze is on, delay the transition to M until FastFreezerExit"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 295
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto :goto_4b2

    .line 297
    :cond_4ae
    invoke-direct {p0, v3}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->transToMiddle(Z)V

    .line 299
    nop

    .line 385
    :cond_4b2
    :goto_4b2
    return v3

    nop

    :sswitch_data_4b4
    .sparse-switch
        0x4 -> :sswitch_462
        0x15 -> :sswitch_3d5
        0x65 -> :sswitch_336
        0x66 -> :sswitch_244
        0x67 -> :sswitch_230
        0x69 -> :sswitch_1d9
        0x6e -> :sswitch_1ca
        0x6f -> :sswitch_17f
        0x70 -> :sswitch_103
        0x71 -> :sswitch_a9
        0x73 -> :sswitch_e
    .end sparse-switch
.end method

.method public recoverNonKeyProcsNet()V
    .registers 5

    .line 506
    iget-boolean v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_59

    .line 507
    iput-boolean v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->restrictNet:Z

    .line 508
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_59

    .line 509
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "recoverNonKeyProcsNet: uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " retry: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 512
    :cond_59
    iput v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;->retry:I

    .line 513
    return-void
.end method
