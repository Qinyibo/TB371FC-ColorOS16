.class Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;
.super Lcom/android/server/hans/states/State;
.source "HansAppStateMachine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/states/HansAppStateMachine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "MiddleState"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/hans/states/HansAppStateMachine;


# direct methods
.method public constructor <init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V
    .registers 4
    .param p1, "this$0"    # Lcom/android/server/hans/states/HansAppStateMachine;
    .param p2, "hansPackage"    # Lcom/android/server/hans/OplusHansPackage;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 518
    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-direct {p0}, Lcom/android/server/hans/states/State;-><init>()V

    .line 519
    new-instance v0, Lcom/android/server/hans/states/action/MiddleAction;

    invoke-direct {v0, p2}, Lcom/android/server/hans/states/action/MiddleAction;-><init>(Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->mAction:Lcom/android/server/hans/states/action/Action;

    .line 520
    return-void
.end method

.method private transToFrozen()V
    .registers 13

    .line 668
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v0

    const-string v1, ", pkg="

    const-string/jumbo v2, "uid="

    if-eqz v0, :cond_5a

    .line 669
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " M is already frozen"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 670
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_2b5

    .line 671
    :cond_5a
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->isImportantForSM(Z)Z

    move-result v0

    const/16 v4, 0x8

    if-eqz v0, :cond_15e

    .line 672
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " cannot transition from M to F, importance="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 673
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v5, "M->F"

    invoke-virtual {v0, v5, v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addImportanceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 675
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getImportantReason()Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v1, v2, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckExistingQuotaTask(Lcom/android/server/hans/states/HansAppStateMachine;ILjava/lang/String;Ljava/lang/String;)V

    .line 676
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-nez v0, :cond_2b5

    .line 677
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 678
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v7

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v8

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v10

    .line 677
    const/4 v9, 0x0

    invoke-virtual/range {v5 .. v10}, Lcom/android/server/hans/OplusHansDBConfig;->getImportantAdditionalRepeatTime(Ljava/lang/String;IIZI)J

    move-result-wide v1

    invoke-virtual {v0, v4, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 679
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v1

    add-int/2addr v1, v3

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    goto/16 :goto_2b5

    .line 682
    :cond_15e
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    .line 683
    .local v6, "curElapsedTime":J
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeTime()J

    move-result-wide v8

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v10

    invoke-static/range {v5 .. v10}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mcheckDelayFreeze(Lcom/android/server/hans/states/HansAppStateMachine;JJLjava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    .line 684
    .local v0, "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    iget-object v5, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1de

    .line 685
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v5, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Long;

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-virtual {v3, v4, v8, v9}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 686
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " can not transition from M to F. reason: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeReason()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 687
    return-void

    .line 689
    :cond_1de
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v8

    sub-long v8, v6, v8

    .line 690
    .local v8, "deltaTime":J
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v10

    cmp-long v5, v8, v10

    if-gtz v5, :cond_2aa

    .line 691
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v5

    iget-object v10, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v10}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v10

    invoke-virtual {v10}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v10

    iget-object v11, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v11}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v11

    invoke-virtual {v11}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v10, v11}, Lcom/android/server/am/OplusHansManager;->hasTouchedWindow(ILjava/lang/String;)I

    move-result v5

    if-ne v5, v3, :cond_263

    .line 692
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansDBConfig;->getInputTimeout()J

    move-result-wide v10

    sub-long/2addr v10, v8

    invoke-virtual {v3, v4, v10, v11}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 693
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " can not transition from M to F. reason: inputEvent"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 694
    return-void

    .line 696
    :cond_263
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v3

    if-eqz v3, :cond_2aa

    .line 697
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " no input event"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 702
    :cond_2aa
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 704
    .end local v0    # "delayFreeze":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Boolean;Ljava/lang/Long;>;"
    .end local v6    # "curElapsedTime":J
    .end local v8    # "deltaTime":J
    :cond_2b5
    :goto_2b5
    return-void
.end method

.method private transToRunning()V
    .registers 9

    .line 661
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmRunningState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 663
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 664
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v5

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v6

    .line 663
    invoke-virtual/range {v2 .. v7}, Lcom/android/server/hans/OplusHansDBConfig;->getRtoMCheckTime(ILjava/lang/String;IJ)J

    move-result-wide v1

    const/4 v3, 0x4

    invoke-virtual {v0, v3, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 665
    return-void
.end method


# virtual methods
.method public enter()V
    .registers 4

    .line 524
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " M enter(), R stay="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 525
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 527
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V

    .line 529
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->mAction:Lcom/android/server/hans/states/action/Action;

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->executeAction()V

    .line 530
    return-void
.end method

.method public exit()V
    .registers 4

    .line 534
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "uid="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", pkg="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " M exit(), M stay="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 536
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->mAction:Lcom/android/server/hans/states/action/Action;

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->clearAction()V

    .line 537
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 538
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v1, 0x72

    invoke-virtual {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 539
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 657
    const-string v0, "Middle"

    return-object v0
.end method

.method public processMessage(Landroid/os/Message;)Z
    .registers 14
    .param p1, "msg"    # Landroid/os/Message;

    .line 544
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    const/16 v2, 0x8

    const-string/jumbo v3, "uid="

    const-string v4, ", pkg="

    sparse-switch v0, :sswitch_data_4e4

    .line 650
    return v1

    .line 633
    :sswitch_e
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-nez v0, :cond_4e2

    .line 634
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 635
    .local v0, "duration":I
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    .line 636
    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v8

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v9

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v11

    .line 635
    const/4 v10, 0x0

    invoke-virtual/range {v6 .. v11}, Lcom/android/server/hans/OplusHansDBConfig;->getImportantAdditionalRepeatTime(Ljava/lang/String;IIZI)J

    move-result-wide v5

    .line 637
    .local v5, "stateDuration":J
    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v7}, Lcom/android/server/hans/states/HansAppStateMachine;->getUpTimeDuration()J

    move-result-wide v7

    sub-long v7, v5, v7

    .line 638
    .local v7, "remainDuration":J
    const-wide/16 v9, 0x1388

    cmp-long v9, v7, v9

    if-gez v9, :cond_ff

    .line 639
    const-wide/16 v9, 0x0

    cmp-long v9, v7, v9

    if-ltz v9, :cond_62

    int-to-long v9, v0

    add-long/2addr v9, v7

    goto :goto_63

    :cond_62
    int-to-long v9, v0

    .line 640
    .local v9, "delayTime":J
    :goto_63
    iget-object v11, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v11, v2, v9, v10}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    .line 641
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_bf

    .line 642
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v11, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v11}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v11

    invoke-virtual {v11}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v11

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "  delay to F, reason="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", delay "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 645
    :cond_bf
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "  delay Freeze. delay "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "delayFreeze"

    invoke-virtual {v2, v4, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->addHistoryInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 647
    .end local v0    # "duration":I
    .end local v5    # "stateDuration":J
    .end local v7    # "remainDuration":J
    .end local v9    # "delayTime":J
    :cond_ff
    goto/16 :goto_4e2

    .line 621
    :sswitch_101
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 622
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 623
    .local v0, "destState":I
    const/4 v2, 0x3

    if-ne v0, v2, :cond_113

    .line 624
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    goto :goto_126

    .line 625
    :cond_113
    if-ne v0, v1, :cond_119

    .line 626
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToRunning()V

    goto :goto_126

    .line 627
    :cond_119
    if-nez v0, :cond_126

    .line 628
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v5

    invoke-virtual {v2, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 630
    :cond_126
    :goto_126
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", transition from M to "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getStateName(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", reason="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 631
    goto/16 :goto_4e2

    .line 616
    .end local v0    # "destState":I
    :sswitch_17c
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->removeAllMessages()V

    .line 617
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 618
    .local v0, "reason":Ljava/lang/String;
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " SM all messages removed, reason: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 619
    goto/16 :goto_4e2

    .line 611
    .end local v0    # "reason":Ljava/lang/String;
    :sswitch_1c7
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-nez v0, :cond_4e2

    .line 612
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    goto/16 :goto_4e2

    .line 578
    :sswitch_1d6
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 579
    .local v0, "curResumedUid":I
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    if-ne v2, v0, :cond_233

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v2

    if-eqz v2, :cond_233

    .line 580
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " M Deepsleep OFF, is top app, transition to Default"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 581
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_4e2

    .line 582
    :cond_233
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansImportance(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansImportance;

    const/16 v5, 0xe1d

    invoke-virtual {v2, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->isInImportanceList(I)Z

    move-result v2

    if-eqz v2, :cond_4e2

    .line 583
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " M Deepsleep OFF, transition to Running"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 584
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToRunning()V

    goto/16 :goto_4e2

    .line 546
    .end local v0    # "curResumedUid":I
    :sswitch_283
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mremoveAllMessagesExceptEnterSM(Lcom/android/server/hans/states/HansAppStateMachine;)V

    .line 547
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " M exit SM"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 548
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V

    .line 549
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    .line 550
    goto/16 :goto_4e2

    .line 588
    :sswitch_2da
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 589
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-nez v0, :cond_4e2

    .line 590
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    goto/16 :goto_4e2

    .line 604
    :sswitch_2ee
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z

    move-result v0

    if-eqz v0, :cond_4e2

    .line 605
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "FF exit, uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " M transition to F"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 606
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    .line 607
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto/16 :goto_4e2

    .line 560
    :sswitch_33f
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    const/16 v5, 0x67

    invoke-virtual {v0, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 561
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 562
    .restart local v0    # "curResumedUid":I
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    if-ne v5, v0, :cond_399

    .line 563
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " M LCD ON, is top app, transition to Default"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 565
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto/16 :goto_4e2

    .line 566
    :cond_399
    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v6}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$mgetLcdOffSkipImportance(Lcom/android/server/hans/states/HansAppStateMachine;)I

    move-result v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/states/HansAppStateMachine;->isInImportanceList(I)Z

    move-result v5

    if-eqz v5, :cond_3e8

    .line 567
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v5}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " M LCD ON, transition to Running"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 568
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToRunning()V

    goto/16 :goto_4e2

    .line 570
    :cond_3e8
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-virtual {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v3

    if-nez v3, :cond_4e2

    .line 572
    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansDBConfig;->getAutoStartMtoFCheckTime()J

    move-result-wide v4

    invoke-virtual {v3, v2, v4, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(IJ)V

    goto/16 :goto_4e2

    .line 594
    .end local v0    # "curResumedUid":I
    :sswitch_405
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-eqz v0, :cond_452

    .line 595
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " M CMD_FREEZE but FastFreeze is on, delay the transition to F until FastFreezerExit"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 597
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto/16 :goto_4e2

    .line 599
    :cond_452
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " M CMD_FREEZE"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 600
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    .line 602
    goto :goto_4e2

    .line 552
    :sswitch_492
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isFastFreezeOn()Z

    move-result v0

    if-eqz v0, :cond_4de

    .line 553
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v3}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " M FastFreeze is on, delay the transition to F until FastFreezerExit"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 554
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->this$0:Lcom/android/server/hans/states/HansAppStateMachine;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->-$$Nest$fputmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V

    goto :goto_4e2

    .line 556
    :cond_4de
    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;->transToFrozen()V

    .line 558
    nop

    .line 652
    :cond_4e2
    :goto_4e2
    return v1

    nop

    :sswitch_data_4e4
    .sparse-switch
        0x8 -> :sswitch_492
        0x15 -> :sswitch_405
        0x65 -> :sswitch_33f
        0x66 -> :sswitch_2ee
        0x67 -> :sswitch_2da
        0x69 -> :sswitch_283
        0x6d -> :sswitch_1d6
        0x6e -> :sswitch_1c7
        0x6f -> :sswitch_17c
        0x70 -> :sswitch_101
        0x72 -> :sswitch_e
    .end sparse-switch
.end method
