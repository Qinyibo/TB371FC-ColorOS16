.class public final synthetic Lcom/android/server/display/OplusDisplayPowerControllerExtImpl-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
