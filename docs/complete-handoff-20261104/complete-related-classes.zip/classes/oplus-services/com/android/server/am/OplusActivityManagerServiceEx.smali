.class public final Lcom/android/server/am/OplusActivityManagerServiceEx;
.super Lcom/android/server/am/OplusDefaultActivityManagerServiceEx;
.source "OplusActivityManagerServiceEx.java"

# interfaces
.implements Lcom/android/server/am/IOplusActivityManagerServiceEx;


# static fields
.field private static final DEBUG:Z

.field private static final TAG:Ljava/lang/String; = "OplusActivityManagerServiceEx"


# instance fields
.field private mAMSEnhance:Lcom/android/server/am/OplusActivityManagerServiceEnhance;

.field private mMessageHelper:Lcom/android/server/am/OplusActivityManagerMessageHelper;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 52
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEx;->DEBUG:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;)V
    .registers 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "ams"    # Lcom/android/server/am/ActivityManagerService;

    .line 59
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusDefaultActivityManagerServiceEx;-><init>(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;)V

    .line 60
    const-string v0, "OplusActivityManagerServiceEx"

    const-string v1, "create"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusActivityManagerServiceEx;->init(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;)V

    .line 62
    return-void
.end method

.method private init(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;)V
    .registers 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "ams"    # Lcom/android/server/am/ActivityManagerService;

    .line 112
    new-instance v0, Lcom/android/server/am/OplusActivityManagerMessageHelper;

    invoke-direct {v0, p1, p0}, Lcom/android/server/am/OplusActivityManagerMessageHelper;-><init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mMessageHelper:Lcom/android/server/am/OplusActivityManagerMessageHelper;

    .line 114
    new-instance v0, Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    invoke-direct {v0, p1, p2, p0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;-><init>(Landroid/content/Context;Lcom/android/server/am/ActivityManagerService;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAMSEnhance:Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    .line 115
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAMSEnhance:Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    invoke-virtual {p2, v0}, Lcom/android/server/am/ActivityManagerService;->setExtension(Landroid/os/IBinder;)V

    .line 118
    invoke-static {}, Lcom/android/server/OplusServiceRegistry;->getInstance()Lcom/android/server/OplusServiceRegistry;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1, p0}, Lcom/android/server/OplusServiceRegistry;->serviceInit(ILcom/android/server/IOplusCommonManagerServiceEx;)V

    .line 119
    return-void
.end method


# virtual methods
.method public clearPendingBackupUid(I)V
    .registers 3
    .param p1, "uid"    # I

    .line 224
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mActivityManagerServiceExt:Lcom/android/server/am/IActivityManagerServiceExt;

    invoke-interface {v0, p1}, Lcom/android/server/am/IActivityManagerServiceExt;->hookClearPendingBackup(I)V

    .line 225
    return-void
.end method

.method public enableWmShellProtoLogs([Ljava/lang/String;Ljava/io/PrintWriter;Ljava/io/FileDescriptor;)V
    .registers 14
    .param p1, "args"    # [Ljava/lang/String;
    .param p2, "pw"    # Ljava/io/PrintWriter;
    .param p3, "fd"    # Ljava/io/FileDescriptor;

    .line 176
    if-eqz p2, :cond_64

    if-eqz p3, :cond_64

    if-nez p1, :cond_b

    move-object v7, p1

    move-object v4, p2

    move-object v3, p3

    goto/16 :goto_67

    .line 179
    :cond_b
    :try_start_b
    invoke-static {p3}, Landroid/os/ParcelFileDescriptor;->dup(Ljava/io/FileDescriptor;)Landroid/os/ParcelFileDescriptor;

    move-result-object v0
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_f} :catch_44

    move-object v1, v0

    .line 180
    .local v1, "pfd":Landroid/os/ParcelFileDescriptor;
    :try_start_10
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v0, Lcom/android/server/am/ActivityManagerService;->mServices:Lcom/android/server/am/ActiveServices;

    const-string v5, "SystemUIService"
    :try_end_16
    .catchall {:try_start_10 .. :try_end_16} :catchall_30

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v6, 0x0

    move-object v7, p1

    move-object v4, p2

    move-object v3, p3

    .end local p1    # "args":[Ljava/lang/String;
    .end local p2    # "pw":Ljava/io/PrintWriter;
    .end local p3    # "fd":Ljava/io/FileDescriptor;
    .local v3, "fd":Ljava/io/FileDescriptor;
    .local v4, "pw":Ljava/io/PrintWriter;
    .local v7, "args":[Ljava/lang/String;
    :try_start_1c
    invoke-virtual/range {v2 .. v9}, Lcom/android/server/am/ActiveServices;->dumpService(Ljava/io/FileDescriptor;Ljava/io/PrintWriter;Ljava/lang/String;[I[Ljava/lang/String;IZ)Z

    move-result p1

    if-nez p1, :cond_27

    .line 181
    const-string p1, "No services match: SystemUIService"

    invoke-virtual {v4, p1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    :try_end_27
    .catchall {:try_start_1c .. :try_end_27} :catchall_2d

    .line 183
    :cond_27
    if-eqz v1, :cond_2c

    :try_start_29
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_2c} :catch_41

    .line 185
    .end local v1    # "pfd":Landroid/os/ParcelFileDescriptor;
    :cond_2c
    goto :goto_63

    .line 179
    .restart local v1    # "pfd":Landroid/os/ParcelFileDescriptor;
    :catchall_2d
    move-exception v0

    move-object p1, v0

    goto :goto_35

    .end local v3    # "fd":Ljava/io/FileDescriptor;
    .end local v4    # "pw":Ljava/io/PrintWriter;
    .end local v7    # "args":[Ljava/lang/String;
    .restart local p1    # "args":[Ljava/lang/String;
    .restart local p2    # "pw":Ljava/io/PrintWriter;
    .restart local p3    # "fd":Ljava/io/FileDescriptor;
    :catchall_30
    move-exception v0

    move-object v7, p1

    move-object v4, p2

    move-object v3, p3

    move-object p1, v0

    .end local p1    # "args":[Ljava/lang/String;
    .end local p2    # "pw":Ljava/io/PrintWriter;
    .end local p3    # "fd":Ljava/io/FileDescriptor;
    .restart local v3    # "fd":Ljava/io/FileDescriptor;
    .restart local v4    # "pw":Ljava/io/PrintWriter;
    .restart local v7    # "args":[Ljava/lang/String;
    :goto_35
    if-eqz v1, :cond_40

    :try_start_37
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_3a
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3b

    goto :goto_40

    :catchall_3b
    move-exception v0

    move-object p2, v0

    :try_start_3d
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v3    # "fd":Ljava/io/FileDescriptor;
    .end local v4    # "pw":Ljava/io/PrintWriter;
    .end local v7    # "args":[Ljava/lang/String;
    .end local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEx;
    :cond_40
    :goto_40
    throw p1
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_41} :catch_41

    .line 183
    .end local v1    # "pfd":Landroid/os/ParcelFileDescriptor;
    .restart local v3    # "fd":Ljava/io/FileDescriptor;
    .restart local v4    # "pw":Ljava/io/PrintWriter;
    .restart local v7    # "args":[Ljava/lang/String;
    .restart local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEx;
    :catch_41
    move-exception v0

    move-object p1, v0

    goto :goto_49

    .end local v3    # "fd":Ljava/io/FileDescriptor;
    .end local v4    # "pw":Ljava/io/PrintWriter;
    .end local v7    # "args":[Ljava/lang/String;
    .restart local p1    # "args":[Ljava/lang/String;
    .restart local p2    # "pw":Ljava/io/PrintWriter;
    .restart local p3    # "fd":Ljava/io/FileDescriptor;
    :catch_44
    move-exception v0

    move-object v7, p1

    move-object v4, p2

    move-object v3, p3

    move-object p1, v0

    .line 184
    .end local p2    # "pw":Ljava/io/PrintWriter;
    .end local p3    # "fd":Ljava/io/FileDescriptor;
    .restart local v3    # "fd":Ljava/io/FileDescriptor;
    .restart local v4    # "pw":Ljava/io/PrintWriter;
    .restart local v7    # "args":[Ljava/lang/String;
    .local p1, "e":Ljava/lang/Exception;
    :goto_49
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Failed to handle logging command: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v4, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 186
    .end local p1    # "e":Ljava/lang/Exception;
    :goto_63
    return-void

    .line 176
    .end local v3    # "fd":Ljava/io/FileDescriptor;
    .end local v4    # "pw":Ljava/io/PrintWriter;
    .end local v7    # "args":[Ljava/lang/String;
    .local p1, "args":[Ljava/lang/String;
    .restart local p2    # "pw":Ljava/io/PrintWriter;
    .restart local p3    # "fd":Ljava/io/FileDescriptor;
    :cond_64
    move-object v7, p1

    move-object v4, p2

    move-object v3, p3

    .line 177
    .end local p1    # "args":[Ljava/lang/String;
    .end local p2    # "pw":Ljava/io/PrintWriter;
    .end local p3    # "fd":Ljava/io/FileDescriptor;
    .restart local v3    # "fd":Ljava/io/FileDescriptor;
    .restart local v4    # "pw":Ljava/io/PrintWriter;
    .restart local v7    # "args":[Ljava/lang/String;
    :goto_67
    return-void
.end method

.method public forceStopPackageWithoutRestart(Ljava/lang/String;Ljava/lang/String;)V
    .registers 19
    .param p1, "packageName"    # Ljava/lang/String;
    .param p2, "reason"    # Ljava/lang/String;

    .line 153
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    :try_start_4
    const-string v0, "OplusActivityManagerServiceEx"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "forceStopPackageWithoutRestart "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 154
    invoke-static {}, Landroid/app/AppGlobals;->getPackageManager()Landroid/content/pm/IPackageManager;

    move-result-object v0

    const-wide/32 v3, 0x20000

    const/4 v5, 0x0

    invoke-interface {v0, v2, v3, v4, v5}, Landroid/content/pm/IPackageManager;->getApplicationInfo(Ljava/lang/String;JI)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    move-object v3, v0

    .line 157
    .local v3, "ai":Landroid/content/pm/ApplicationInfo;
    iget-object v4, v1, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v4
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_30} :catch_58

    .line 158
    if-eqz v3, :cond_4d

    .line 159
    :try_start_32
    iget-object v5, v1, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v6, v3, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget v0, v3, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-static {v0}, Landroid/os/UserHandle;->getAppId(I)I

    move-result v7

    iget v0, v3, Landroid/content/pm/ApplicationInfo;->uid:I

    .line 160
    invoke-static {v0}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v14

    .line 159
    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x1

    move-object/from16 v15, p2

    invoke-virtual/range {v5 .. v15}, Lcom/android/server/am/ActivityManagerService;->forceStopPackageLocked(Ljava/lang/String;IZZZZZZILjava/lang/String;)Z

    .line 162
    :cond_4d
    monitor-exit v4
    :try_end_4e
    .catchall {:try_start_32 .. :try_end_4e} :catchall_52

    :try_start_4e
    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V
    :try_end_51
    .catch Ljava/lang/Exception; {:try_start_4e .. :try_end_51} :catch_58

    .line 165
    .end local v3    # "ai":Landroid/content/pm/ApplicationInfo;
    goto :goto_72

    .line 162
    .restart local v3    # "ai":Landroid/content/pm/ApplicationInfo;
    :catchall_52
    move-exception v0

    :try_start_53
    monitor-exit v4
    :try_end_54
    .catchall {:try_start_53 .. :try_end_54} :catchall_52

    :try_start_54
    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .end local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEx;
    .end local p1    # "packageName":Ljava/lang/String;
    .end local p2    # "reason":Ljava/lang/String;
    throw v0
    :try_end_58
    .catch Ljava/lang/Exception; {:try_start_54 .. :try_end_58} :catch_58

    .line 163
    .end local v3    # "ai":Landroid/content/pm/ApplicationInfo;
    .restart local p0    # "this":Lcom/android/server/am/OplusActivityManagerServiceEx;
    .restart local p1    # "packageName":Ljava/lang/String;
    .restart local p2    # "reason":Ljava/lang/String;
    :catch_58
    move-exception v0

    .line 164
    .local v0, "e":Ljava/lang/Exception;
    const-string v3, "OplusActivityManagerServiceEx"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "failed to stop package "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 166
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_72
    return-void
.end method

.method public handleMessage(Landroid/os/Message;I)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "whichHandler"    # I

    .line 100
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerServiceEx;->DEBUG:Z

    if-eqz v0, :cond_27

    .line 101
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "handleMessage msg = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " handler = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusActivityManagerServiceEx"

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 103
    :cond_27
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mMessageHelper:Lcom/android/server/am/OplusActivityManagerMessageHelper;

    if-eqz v0, :cond_30

    .line 104
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mMessageHelper:Lcom/android/server/am/OplusActivityManagerMessageHelper;

    invoke-virtual {v0, p1, p2}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->handleMessage(Landroid/os/Message;I)Z

    .line 106
    :cond_30
    return-void
.end method

.method public isBackupRestoreType(Ljava/lang/String;I)Z
    .registers 8
    .param p1, "processName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 194
    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v1, p1, p2}, Lcom/android/server/am/ActivityManagerService;->getProcessRecordLocked(Ljava/lang/String;I)Lcom/android/server/am/ProcessRecord;

    move-result-object v1

    .line 195
    .local v1, "processRecordLocked":Lcom/android/server/am/ProcessRecord;
    if-nez v1, :cond_a

    .line 196
    return v0

    .line 198
    :cond_a
    invoke-virtual {v1}, Lcom/android/server/am/ProcessRecord;->getHostingRecord()Lcom/android/server/am/HostingRecord;

    move-result-object v2

    .line 199
    .local v2, "hostingRecord":Lcom/android/server/am/HostingRecord;
    if-nez v2, :cond_11

    .line 200
    return v0

    .line 202
    :cond_11
    const-string v3, "backup"

    invoke-virtual {v2}, Lcom/android/server/am/HostingRecord;->getType()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1b} :catch_1c

    return v0

    .line 203
    .end local v1    # "processRecordLocked":Lcom/android/server/am/ProcessRecord;
    .end local v2    # "hostingRecord":Lcom/android/server/am/HostingRecord;
    :catch_1c
    move-exception v1

    .line 204
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "isBackupRestoreType has exception: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "OplusActivityManagerServiceEx"

    invoke-static {v3, v2}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 205
    return v0
.end method

.method public isBackupType(Ljava/lang/String;I)Z
    .registers 7
    .param p1, "processName"    # Ljava/lang/String;
    .param p2, "uid"    # I

    .line 212
    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v1, p1, p2}, Lcom/android/server/am/ActivityManagerService;->getProcessRecordLocked(Ljava/lang/String;I)Lcom/android/server/am/ProcessRecord;

    move-result-object v1

    .line 213
    .local v1, "processRecordLocked":Lcom/android/server/am/ProcessRecord;
    if-nez v1, :cond_a

    .line 214
    return v0

    .line 216
    :cond_a
    invoke-virtual {v1}, Lcom/android/server/am/ProcessRecord;->isInFullBackup()Z

    move-result v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_e} :catch_f

    return v0

    .line 217
    .end local v1    # "processRecordLocked":Lcom/android/server/am/ProcessRecord;
    :catch_f
    move-exception v1

    .line 218
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "isBackupType has exception: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "OplusActivityManagerServiceEx"

    invoke-static {v3, v2}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 219
    return v0
.end method

.method public onStart()V
    .registers 3

    .line 94
    const-string v0, "OplusActivityManagerServiceEx"

    const-string/jumbo v1, "onStart"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 95
    return-void
.end method

.method public startPersistentApp(Ljava/lang/String;)V
    .registers 10
    .param p1, "packageName"    # Ljava/lang/String;

    .line 134
    const-string v1, "OplusActivityManagerServiceEx"

    :try_start_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "startPersistentApp "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 135
    invoke-static {}, Landroid/app/AppGlobals;->getPackageManager()Landroid/content/pm/IPackageManager;

    move-result-object v0

    const-wide/32 v2, 0x20000

    const/4 v4, 0x0

    invoke-interface {v0, p1, v2, v3, v4}, Landroid/content/pm/IPackageManager;->getApplicationInfo(Ljava/lang/String;JI)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    move-object v3, v0

    .line 138
    .local v3, "ai":Landroid/content/pm/ApplicationInfo;
    if-eqz v3, :cond_40

    iget v0, v3, Landroid/content/pm/ApplicationInfo;->flags:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_40

    .line 139
    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v2 .. v7}, Lcom/android/server/am/ActivityManagerService;->addAppLocked(Landroid/content/pm/ApplicationInfo;Ljava/lang/String;ZLjava/lang/String;I)Lcom/android/server/am/ProcessRecord;

    move-result-object v0

    .line 141
    .local v0, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v0, :cond_40

    .line 142
    iget-object v2, v0, Lcom/android/server/am/ProcessRecord;->mProfile:Lcom/android/server/am/ProcessProfileRecord;

    const/4 v4, 0x2

    invoke-virtual {v2, v4}, Lcom/android/server/am/ProcessProfileRecord;->addHostingComponentType(I)V
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_40} :catch_41

    .line 147
    .end local v0    # "proc":Lcom/android/server/am/ProcessRecord;
    .end local v3    # "ai":Landroid/content/pm/ApplicationInfo;
    :cond_40
    goto :goto_59

    .line 145
    :catch_41
    move-exception v0

    .line 146
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "failed to start persistent app "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 148
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_59
    return-void
.end method

.method public systemReady()V
    .registers 4

    .line 66
    const-string v0, "OplusActivityManagerServiceEx"

    const-string/jumbo v1, "systemReady"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    invoke-static {}, Lcom/android/server/OplusServiceRegistry;->getInstance()Lcom/android/server/OplusServiceRegistry;

    move-result-object v0

    const/16 v1, 0x16

    invoke-virtual {v0, v1}, Lcom/android/server/OplusServiceRegistry;->serviceReady(I)V

    .line 70
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAMSEnhance:Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    if-eqz v0, :cond_1a

    .line 71
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAMSEnhance:Lcom/android/server/am/OplusActivityManagerServiceEnhance;

    invoke-virtual {v0}, Lcom/android/server/am/OplusActivityManagerServiceEnhance;->systemReady()V

    .line 77
    :cond_1a
    sget-object v0, Lcom/android/server/pm/IOplusDataFreeManager;->DEFAULT:Lcom/android/server/pm/IOplusDataFreeManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/pm/IOplusDataFreeManager;

    invoke-interface {v0}, Lcom/android/server/pm/IOplusDataFreeManager;->generatePlaceHolderFiles()V

    .line 82
    iget-object v0, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {v0}, Lcom/android/server/am/ColorInjector$ActivityManagerService;->init(Lcom/android/server/am/ActivityManagerService;)V

    .line 87
    sget-object v0, Lcom/android/server/hypermode/IOplusHyperModeFeature;->DEFAULT:Lcom/android/server/hypermode/IOplusHyperModeFeature;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/hypermode/IOplusHyperModeFeature;

    iget-object v1, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerServiceEx;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mContext:Landroid/content/Context;

    invoke-interface {v0, v1, v2}, Lcom/android/server/hypermode/IOplusHyperModeFeature;->init(Lcom/android/server/am/ActivityManagerService;Landroid/content/Context;)V

    .line 89
    return-void
.end method
