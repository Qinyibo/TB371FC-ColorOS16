.class Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;
.super Landroid/content/BroadcastReceiver;
.source "RfcommOemManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->registerReceiverInner()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;


# direct methods
.method constructor <init>(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V
    .registers 2
    .param p1, "this$0"    # Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 122
    iput-object p1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;->this$0:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 12
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 125
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    .line 127
    .local v0, "action":Ljava/lang/String;
    const-string v1, "android.intent.action.PACKAGE_FULLY_REMOVED"

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_99

    .line 128
    invoke-static {}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object v1

    const-string v2, "BluetoothTransfer: received ACTION_PACKAGE_FULLY_REMOVED"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    const-string v1, "android.intent.extra.UID"

    const/4 v2, -0x1

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    .line 131
    .local v1, "uninstallAppUid":I
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;->this$0:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    monitor-enter v2

    .line 132
    :try_start_1f
    iget-object v3, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;->this$0:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    invoke-static {v3}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->-$$Nest$fgetmServerMap(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .line 133
    .local v3, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;>;"
    :goto_2d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_94

    .line 134
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 135
    .local v4, "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/util/Pair;

    iget-object v5, v5, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_93

    .line 136
    invoke-static {}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "BluetoothTransfer: disableRfcomm removing uid: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 137
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :try_end_6d
    .catchall {:try_start_1f .. :try_end_6d} :catchall_96

    .line 138
    .local v5, "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    if-eqz v5, :cond_7d

    .line 140
    :try_start_6f
    invoke-virtual {v5}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit()V
    :try_end_72
    .catch Ljava/io/IOException; {:try_start_6f .. :try_end_72} :catch_73
    .catchall {:try_start_6f .. :try_end_72} :catchall_96

    .line 143
    goto :goto_7d

    .line 141
    :catch_73
    move-exception v6

    .line 142
    .local v6, "e":Ljava/io/IOException;
    :try_start_74
    invoke-static {}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object v7

    const-string v8, "BluetoothTransfer: Socket is already closed, nothing to do"

    invoke-static {v7, v8, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 145
    .end local v6    # "e":Ljava/io/IOException;
    :cond_7d
    :goto_7d
    invoke-interface {v3}, Ljava/util/Iterator;->remove()V

    .line 146
    iget-object v6, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager$2;->this$0:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/util/Pair;

    iget-object v7, v7, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v7, Ljava/util/UUID;

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->-$$Nest$mremoveRfcommServerData(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;Ljava/lang/String;)V

    .line 148
    .end local v4    # "server":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;"
    .end local v5    # "serverThread":Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
    :cond_93
    goto :goto_2d

    .line 149
    .end local v3    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Landroid/util/Pair<Ljava/util/UUID;Ljava/lang/Integer;>;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;>;>;"
    :cond_94
    monitor-exit v2

    goto :goto_99

    :catchall_96
    move-exception v3

    monitor-exit v2
    :try_end_98
    .catchall {:try_start_74 .. :try_end_98} :catchall_96

    throw v3

    .line 151
    .end local v1    # "uninstallAppUid":I
    :cond_99
    :goto_99
    return-void
.end method
