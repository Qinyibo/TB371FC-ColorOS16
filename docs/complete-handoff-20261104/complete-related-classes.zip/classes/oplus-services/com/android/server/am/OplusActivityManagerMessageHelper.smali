.class public final Lcom/android/server/am/OplusActivityManagerMessageHelper;
.super Lcom/android/server/am/OplusActivityManagerCommonHelper;
.source "OplusActivityManagerMessageHelper.java"


# static fields
.field static final NOT_ALLOWED_START_MSG:I = 0x3ea

.field static final OPLUS_AMS_MSG_INDEX:I = 0x3e9

.field static final RESET_SLEEP_CHECK_FLAG_MSG:I = 0x3ed

.field static final SHOW_ACTIVITY_BEHIND_KEYGUARD_MSG:I = 0x3ee

.field static final START_OPLUS_SITE_MSG:I = 0x3eb

.field private static final TAG:Ljava/lang/String; = "OplusActivityManagerMessageHelper"


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V
    .registers 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "amsEx"    # Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 55
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusActivityManagerCommonHelper;-><init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V

    .line 56
    return-void
.end method

.method private handleBgMessage(Landroid/os/Message;)Z
    .registers 3
    .param p1, "msg"    # Landroid/os/Message;

    .line 139
    const/4 v0, 0x0

    return v0
.end method

.method private handleKillMessage(Landroid/os/Message;)Z
    .registers 3
    .param p1, "msg"    # Landroid/os/Message;

    .line 144
    const/4 v0, 0x0

    return v0
.end method

.method private handleMainMessage(Landroid/os/Message;)Z
    .registers 3
    .param p1, "msg"    # Landroid/os/Message;

    .line 90
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_14

    goto :goto_11

    .line 93
    :pswitch_6
    sget-object v0, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v0, p1}, Lcom/android/server/am/IOplusAppStartupManager;->handOplusSiteMsg(Landroid/os/Message;)V

    .line 97
    :goto_11
    const/4 v0, 0x0

    return v0

    nop

    :pswitch_data_14
    .packed-switch 0x3eb
        :pswitch_6
    .end packed-switch
.end method

.method private handleUiMessage(Landroid/os/Message;)Z
    .registers 8
    .param p1, "msg"    # Landroid/os/Message;

    .line 101
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_d0

    goto/16 :goto_cf

    .line 105
    :pswitch_8
    invoke-static {}, Lcom/android/server/wm/OplusAppStartupManagerHelper;->getInstance()Lcom/android/server/wm/OplusAppStartupManagerHelper;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/am/OplusActivityManagerMessageHelper;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-virtual {v0, v2}, Lcom/android/server/wm/OplusAppStartupManagerHelper;->canShowDialogs(Lcom/android/server/am/ActivityManagerService;)Z

    move-result v0

    if-eqz v0, :cond_cf

    .line 106
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 107
    .local v0, "packageName":Ljava/lang/String;
    if-eqz v0, :cond_25

    .line 108
    sget-object v2, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v2}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v2, v0}, Lcom/android/server/am/IOplusAppStartupManager;->handleAppStartForbidden(Ljava/lang/String;)V

    .line 110
    :cond_25
    sget-object v2, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v2}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v2}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogTitleText()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_b3

    sget-object v2, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    .line 111
    invoke-static {v2}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v2}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogContentText()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_b3

    sget-object v2, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    .line 112
    invoke-static {v2}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v2}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogButtonText()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_b3

    .line 113
    new-instance v2, Landroid/app/AlertDialog$Builder;

    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerMessageHelper;->mContext:Landroid/content/Context;

    sget-object v4, Lcom/oplus/theme/IOplusThemeStyle;->DEFAULT:Lcom/oplus/theme/IOplusThemeStyle;

    new-array v5, v1, [Ljava/lang/Object;

    invoke-static {v4, v5}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v4

    check-cast v4, Lcom/oplus/theme/IOplusThemeStyle;

    const v5, 0xc030007

    invoke-interface {v4, v5}, Lcom/oplus/theme/IOplusThemeStyle;->getDialogThemeStyle(I)I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v2

    .line 114
    .local v2, "dialog":Landroid/app/AlertDialog;
    invoke-virtual {v2}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/16 v4, 0x7d3

    invoke-virtual {v3, v4}, Landroid/view/Window;->setType(I)V

    .line 115
    invoke-virtual {v2, v1}, Landroid/app/AlertDialog;->setCancelable(Z)V

    .line 116
    sget-object v3, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v3}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v3}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogTitleText()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 117
    sget-object v3, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v3}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v3}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogContentText()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 118
    sget-object v3, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v3}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v3}, Lcom/android/server/am/IOplusAppStartupManager;->getDialogButtonText()Ljava/lang/String;

    move-result-object v3

    .line 119
    invoke-virtual {p1}, Landroid/os/Message;->getTarget()Landroid/os/Handler;

    move-result-object v4

    const/16 v5, 0x30

    invoke-virtual {v4, v5, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    .line 118
    const/4 v5, -0x1

    invoke-virtual {v2, v5, v3, v4}, Landroid/app/AlertDialog;->setButton(ILjava/lang/CharSequence;Landroid/os/Message;)V

    .line 120
    invoke-virtual {v2}, Landroid/app/AlertDialog;->show()V

    .line 121
    .end local v2    # "dialog":Landroid/app/AlertDialog;
    goto :goto_c4

    .line 122
    :cond_b3
    new-instance v2, Lcom/android/server/am/BaseErrorDialog;

    iget-object v3, p0, Lcom/android/server/am/OplusActivityManagerMessageHelper;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v3, v3, Lcom/android/server/am/ActivityManagerService;->mUiContext:Landroid/content/Context;

    invoke-direct {v2, v3}, Lcom/android/server/am/BaseErrorDialog;-><init>(Landroid/content/Context;)V

    .line 123
    .local v2, "d":Landroid/app/Dialog;
    invoke-virtual {v2}, Landroid/app/Dialog;->show()V

    .line 124
    nop

    .line 125
    .end local v2    # "d":Landroid/app/Dialog;
    invoke-virtual {v2}, Landroid/app/Dialog;->dismiss()V

    .line 126
    nop

    .line 129
    :goto_c4
    sget-object v2, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v2}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/IOplusAppStartupManager;

    invoke-interface {v2}, Lcom/android/server/am/IOplusAppStartupManager;->resetDialogShowText()V

    .line 134
    .end local v0    # "packageName":Ljava/lang/String;
    :cond_cf
    :goto_cf
    return v1

    :pswitch_data_d0
    .packed-switch 0x3ea
        :pswitch_8
    .end packed-switch
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;I)Z
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "whichHandler"    # I

    .line 61
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v1, v2}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->checkCodeValid(III)Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "OplusActivityManagerMessageHelper"

    if-nez v0, :cond_28

    .line 62
    sget-boolean v0, Lcom/android/server/am/OplusActivityManagerMessageHelper;->DEBUG:Z

    if-eqz v0, :cond_27

    .line 63
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Invalid message = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    :cond_27
    return v1

    .line 67
    :cond_28
    packed-switch p2, :pswitch_data_56

    .line 81
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unknow handle = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 82
    return v1

    .line 78
    :pswitch_42
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->handleKillMessage(Landroid/os/Message;)Z

    move-result v0

    return v0

    .line 75
    :pswitch_47
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->handleBgMessage(Landroid/os/Message;)Z

    move-result v0

    return v0

    .line 72
    :pswitch_4c
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->handleUiMessage(Landroid/os/Message;)Z

    move-result v0

    return v0

    .line 69
    :pswitch_51
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusActivityManagerMessageHelper;->handleMainMessage(Landroid/os/Message;)Z

    move-result v0

    return v0

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_51
        :pswitch_4c
        :pswitch_47
        :pswitch_42
    .end packed-switch
.end method
