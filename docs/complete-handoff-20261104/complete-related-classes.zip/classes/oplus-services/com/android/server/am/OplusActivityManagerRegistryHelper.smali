.class public final Lcom/android/server/am/OplusActivityManagerRegistryHelper;
.super Lcom/android/server/am/OplusActivityManagerCommonHelper;
.source "OplusActivityManagerRegistryHelper.java"


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V
    .registers 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "amsEx"    # Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 27
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusActivityManagerCommonHelper;-><init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V

    .line 28
    return-void
.end method


# virtual methods
.method public registerColorCustomManager()V
    .registers 1

    .line 33
    return-void
.end method
