.class Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;
.super Landroid/os/Handler;
.source "OplusDisplayPowerControllerExtImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "DPCExtWorkHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method public constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Looper;)V
    .registers 4
    .param p2, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 403
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    .line 404
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 405
    invoke-static {p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DPCExtWorkHandler init"

    invoke-static {p1, v0}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 406
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;

    .line 410
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "DPCExtWorkHandler handleMessage:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 411
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_52

    goto :goto_50

    .line 413
    :pswitch_24
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmOplusAutomaticBrightnessController(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusAutomaticBrightnessController;

    move-result-object v0

    if-eqz v0, :cond_44

    .line 414
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/android/server/display/util/OplusBrightnessPoint;

    .line 415
    .local v0, "point":Lcom/android/server/display/util/OplusBrightnessPoint;
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmOplusAutomaticBrightnessController(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusAutomaticBrightnessController;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/display/OplusAutomaticBrightnessController;->updateTargetBrightnessPoint(Lcom/android/server/display/util/OplusBrightnessPoint;)V

    .line 416
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmOplusAutomaticBrightnessController(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusAutomaticBrightnessController;

    move-result-object v1

    iget v2, v0, Lcom/android/server/display/util/OplusBrightnessPoint;->backlight:F

    invoke-virtual {v1, v2}, Lcom/android/server/display/OplusAutomaticBrightnessController;->onTargetBrightnessChanged(F)V

    .line 418
    .end local v0    # "point":Lcom/android/server/display/util/OplusBrightnessPoint;
    :cond_44
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$DPCExtWorkHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    iget-object v0, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->sendUpdatePowerState()V

    .line 419
    nop

    .line 423
    :goto_50
    return-void

    nop

    :pswitch_data_52
    .packed-switch 0x7b
        :pswitch_24
    .end packed-switch
.end method
