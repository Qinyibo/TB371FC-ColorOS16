.class public final synthetic Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
