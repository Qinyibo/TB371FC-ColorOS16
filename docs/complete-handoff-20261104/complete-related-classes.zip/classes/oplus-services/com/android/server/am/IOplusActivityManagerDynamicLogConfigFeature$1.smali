.class Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature$1;
.super Ljava/lang/Object;
.source "IOplusActivityManagerDynamicLogConfigFeature.java"

# interfaces
.implements Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
