.class Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"

# interfaces
.implements Lcom/oplus/hardware/devicecase/OplusDeviceCaseStateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "CoverStateCallback"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;


# direct methods
.method private constructor <init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 438
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff-IA;)V
    .registers 3

    invoke-direct {p0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    return-void
.end method


# virtual methods
.method public onStateChanged(I)V
    .registers 6
    .param p1, "state"    # I

    .line 441
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmOplusDebug(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z

    move-result v0

    const-string v1, "OplusProximitySensorScreenOnOff"

    if-eqz v0, :cond_54

    .line 442
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "cover state change, old = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I

    move-result v3

    invoke-static {v2, v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$mformatCoverState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ": "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", new = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    .line 444
    invoke-static {v3, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$mformatCoverState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 442
    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 447
    :cond_54
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fputmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;I)V

    .line 448
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_81

    .line 449
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    .line 450
    .local v2, "time":J
    const-string v0, "cover mode close, need onproximity Negative"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 451
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmDisplayPowerController(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/display/DisplayPowerController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 452
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v2, v3, v1}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->handleCoverModeProximitySensorEvent(JZ)V

    .line 454
    .end local v2    # "time":J
    :cond_81
    return-void
.end method
