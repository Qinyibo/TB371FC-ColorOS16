.class Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;
.super Landroid/database/ContentObserver;
.source "OplusDisplayPowerControllerExtImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SettingsObserver"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Handler;)V
    .registers 3
    .param p2, "handler"    # Landroid/os/Handler;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 1986
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    .line 1987
    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 1988
    return-void
.end method


# virtual methods
.method public onChange(ZLandroid/net/Uri;)V
    .registers 6
    .param p1, "selfChange"    # Z
    .param p2, "uri"    # Landroid/net/Uri;

    .line 2004
    invoke-static {}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$sfgetOPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2d

    .line 2005
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmContext(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string/jumbo v1, "oplus_customize_recovery_settings_state"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v0

    if-eqz v0, :cond_1f

    const/4 v2, 0x1

    .line 2007
    .local v2, "isRecovery":Z
    :cond_1f
    if-eqz v2, :cond_2d

    .line 2008
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$SettingsObserver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    iget-object v0, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->setAutoBrightnessAdjustment(F)V

    .line 2011
    .end local v2    # "isRecovery":Z
    :cond_2d
    return-void
.end method

.method public register(Landroid/content/ContentResolver;)V
    .registers 5
    .param p1, "contentResolver"    # Landroid/content/ContentResolver;

    .line 1991
    invoke-static {}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$sfgetOPLUS_CUSTOMIZE_RECOVERY_SETTINGS_STATE_URI()Landroid/net/Uri;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, -0x1

    invoke-virtual {p1, v0, v1, p0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;I)V

    .line 1996
    return-void
.end method

.method public unregister(Landroid/content/ContentResolver;)V
    .registers 2
    .param p1, "contentResolver"    # Landroid/content/ContentResolver;

    .line 1999
    invoke-virtual {p1, p0}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 2000
    return-void
.end method
