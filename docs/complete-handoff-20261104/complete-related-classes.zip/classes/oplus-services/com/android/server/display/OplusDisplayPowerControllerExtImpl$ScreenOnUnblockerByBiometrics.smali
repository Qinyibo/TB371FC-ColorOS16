.class final Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;
.super Ljava/lang/Object;
.source "OplusDisplayPowerControllerExtImpl.java"

# interfaces
.implements Lcom/android/server/policy/WindowManagerPolicy$ScreenOnListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "ScreenOnUnblockerByBiometrics"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method private constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 730
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Lcom/android/server/display/OplusDisplayPowerControllerExtImpl-IA;)V
    .registers 3

    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V

    return-void
.end method


# virtual methods
.method public onScreenOn()V
    .registers 3

    .line 733
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmHandler(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    move-result-object v0

    const/16 v1, 0x3e9

    invoke-virtual {v0, v1, p0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 734
    .local v0, "msg":Landroid/os/Message;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Message;->setAsynchronous(Z)V

    .line 735
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmHandler(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->sendMessage(Landroid/os/Message;)Z

    .line 736
    return-void
.end method
