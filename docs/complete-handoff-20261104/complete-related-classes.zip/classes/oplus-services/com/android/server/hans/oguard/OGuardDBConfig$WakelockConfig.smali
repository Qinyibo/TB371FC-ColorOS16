.class public Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;
.super Ljava/lang/Object;
.source "OGuardDBConfig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/oguard/OGuardDBConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "WakelockConfig"
.end annotation


# instance fields
.field private enable:Z

.field private fgsPolicyMap:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap<",
            "Ljava/lang/String;",
            "Lcom/android/server/hans/oguard/OGuardDBConfig$FgsPolicy;",
            ">;"
        }
    .end annotation
.end field

.field private name:Ljava/lang/String;

.field private validFgsList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private wakelockBlackAppTypeList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private wakelockBlackPkgList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private wakelockWhiteAppTypeList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private wakelockWhitePkgList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/android/server/hans/oguard/OGuardDBConfig;)V
    .registers 3
    .param p1, "this$0"    # Lcom/android/server/hans/oguard/OGuardDBConfig;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 1906
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1907
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->enable:Z

    .line 1909
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhitePkgList:Ljava/util/ArrayList;

    .line 1910
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhiteAppTypeList:Ljava/util/ArrayList;

    .line 1911
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackPkgList:Ljava/util/ArrayList;

    .line 1912
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackAppTypeList:Ljava/util/ArrayList;

    .line 1913
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->validFgsList:Ljava/util/ArrayList;

    .line 1914
    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->fgsPolicyMap:Landroid/util/ArrayMap;

    return-void
.end method


# virtual methods
.method public enable()Z
    .registers 2

    .line 1925
    iget-boolean v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->enable:Z

    return v0
.end method

.method public getFgsPolicy(Ljava/lang/String;)Lcom/android/server/hans/oguard/OGuardDBConfig$FgsPolicy;
    .registers 3
    .param p1, "type"    # Ljava/lang/String;

    .line 1972
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->fgsPolicyMap:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/oguard/OGuardDBConfig$FgsPolicy;

    return-object v0
.end method

.method public getValidFgsList()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1964
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->validFgsList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getWakelockBlackAppTypeList()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1956
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackAppTypeList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getWakelockBlackPkgList()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1949
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackPkgList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getWakelockWhiteAppTypeList()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1941
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhiteAppTypeList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getWakelockWhitePkgList()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1933
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhitePkgList:Ljava/util/ArrayList;

    return-object v0
.end method

.method public setEnable(Z)V
    .registers 2
    .param p1, "enable"    # Z

    .line 1921
    iput-boolean p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->enable:Z

    .line 1922
    return-void
.end method

.method public setFgsPolicy(Ljava/lang/String;Lcom/android/server/hans/oguard/OGuardDBConfig$FgsPolicy;)V
    .registers 4
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "fgsPolicy"    # Lcom/android/server/hans/oguard/OGuardDBConfig$FgsPolicy;

    .line 1968
    iget-object v0, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->fgsPolicyMap:Landroid/util/ArrayMap;

    invoke-virtual {v0, p1, p2}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1969
    return-void
.end method

.method public setName(Ljava/lang/String;)V
    .registers 2
    .param p1, "name"    # Ljava/lang/String;

    .line 1917
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->name:Ljava/lang/String;

    .line 1918
    return-void
.end method

.method public setValidFgsList(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 1960
    .local p1, "validFgsList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->validFgsList:Ljava/util/ArrayList;

    .line 1961
    return-void
.end method

.method public setWakelockBlackAppTypeList(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 1953
    .local p1, "wakelockBlackAppTypeList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackAppTypeList:Ljava/util/ArrayList;

    .line 1954
    return-void
.end method

.method public setWakelockBlackPkgList(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1945
    .local p1, "wakelockBlackPkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackPkgList:Ljava/util/ArrayList;

    .line 1946
    return-void
.end method

.method public setWakelockWhiteAppTypeList(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 1937
    .local p1, "wakelockWhiteAppTypeList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhiteAppTypeList:Ljava/util/ArrayList;

    .line 1938
    return-void
.end method

.method public setWakelockWhitePkgList(Ljava/util/ArrayList;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1929
    .local p1, "wakelockWhitePkgList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    iput-object p1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhitePkgList:Ljava/util/ArrayList;

    .line 1930
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1977
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "WakelockConfig{ enable: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->enable:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " name: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " wakelockWhitePkgList: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhitePkgList:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " wakelockWhiteAppTypeList: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockWhiteAppTypeList:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " wakelockBlackPkgList: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackPkgList:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " wakelockBlackAppTypeList: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->wakelockBlackAppTypeList:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " validFgsList: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->validFgsList:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " fgsPolicyMap: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/oguard/OGuardDBConfig$WakelockConfig;->fgsPolicyMap:Landroid/util/ArrayMap;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
