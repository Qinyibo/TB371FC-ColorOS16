.class Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;
.super Ljava/lang/Object;
.source "OplusGestureAnimationManagerPolicy.java"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->playReboundAnimIfNeed()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

.field final synthetic val$t:Landroid/view/SurfaceControl$Transaction;


# direct methods
.method constructor <init>(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;Landroid/view/SurfaceControl$Transaction;)V
    .registers 3
    .param p1, "this$0"    # Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 493
    iput-object p1, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    iput-object p2, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->val$t:Landroid/view/SurfaceControl$Transaction;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 7
    .param p1, "valueAnimator"    # Landroid/animation/ValueAnimator;

    .line 496
    iget-object v0, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v0}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$fgetmAnimationSurface(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;)Landroid/view/SurfaceControl;

    move-result-object v0

    if-eqz v0, :cond_46

    iget-object v0, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v0}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$fgetmAnimationSurface(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;)Landroid/view/SurfaceControl;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/SurfaceControl;->isValid()Z

    move-result v0

    if-eqz v0, :cond_46

    .line 497
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    .line 498
    .local v0, "tmpProgress":F
    iget-object v1, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v1}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$fgetmScale(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;)F

    move-result v1

    iget-object v2, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v2}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$mgetZoomThresholdScale(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;)F

    move-result v2

    iget-object v3, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v3}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$fgetmScale(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;)F

    move-result v3

    sub-float/2addr v2, v3

    mul-float/2addr v2, v0

    add-float/2addr v1, v2

    .line 499
    .local v1, "scale":F
    iget-object v2, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    invoke-static {v2, v1}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$fputmFinalScale(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;F)V

    .line 500
    iget-object v2, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->this$0:Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;

    iget-object v3, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->val$t:Landroid/view/SurfaceControl$Transaction;

    const-string v4, "Rebound-EnalrgeAnim"

    invoke-static {v2, v3, v1, v4}, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;->-$$Nest$mupdateFourDragAnimSurface(Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy;Landroid/view/SurfaceControl$Transaction;FLjava/lang/String;)V

    .line 501
    iget-object v2, p0, Lcom/android/server/oplus/input/exinputservice/globalgesture/OplusGestureAnimationManagerPolicy$4;->val$t:Landroid/view/SurfaceControl$Transaction;

    invoke-virtual {v2}, Landroid/view/SurfaceControl$Transaction;->apply()V

    .line 503
    .end local v0    # "tmpProgress":F
    .end local v1    # "scale":F
    :cond_46
    return-void
.end method
