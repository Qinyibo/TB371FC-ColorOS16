.class Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;


# direct methods
.method constructor <init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V
    .registers 2
    .param p1, "this$0"    # Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 674
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 677
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPMS(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/power/PowerManagerService;

    move-result-object v0

    const/16 v1, 0x64

    if-eqz v0, :cond_50

    .line 678
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPMS(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/power/PowerManagerService;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/power/PowerManagerService;->getWrapper()Lcom/android/server/power/IPowerManagerServiceWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/power/IPowerManagerServiceWrapper;->getLock()Ljava/lang/Object;

    move-result-object v0

    .line 679
    .local v0, "lock":Ljava/lang/Object;
    monitor-enter v0

    .line 680
    :try_start_19
    const-string v2, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v3, "onProximityPositiveForceSuspend"

    invoke-static {v2, v3}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 681
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmPMS(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/power/PowerManagerService;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/power/PowerManagerService;->getWrapper()Lcom/android/server/power/IPowerManagerServiceWrapper;

    move-result-object v2

    const/4 v3, 0x1

    invoke-interface {v2, v3}, Lcom/android/server/power/IPowerManagerServiceWrapper;->setProximityPositive(Z)V

    .line 682
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_19 .. :try_end_30} :catchall_4d

    .line 683
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2, v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fputmIsPositiveForceSuspend(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V

    .line 684
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmContext(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Landroid/content/Context;

    move-result-object v2

    const-string/jumbo v3, "power"

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/PowerManager;

    .line 685
    .local v2, "pm":Landroid/os/PowerManager;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v4, v1, v5}, Landroid/os/PowerManager;->goToSleep(JII)V

    .line 686
    .end local v0    # "lock":Ljava/lang/Object;
    .end local v2    # "pm":Landroid/os/PowerManager;
    goto :goto_57

    .line 682
    .restart local v0    # "lock":Ljava/lang/Object;
    :catchall_4d
    move-exception v1

    :try_start_4e
    monitor-exit v0
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    throw v1

    .line 687
    .end local v0    # "lock":Ljava/lang/Object;
    :cond_50
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string v2, "OnProximityPositiveSuspendRunnable: PMS is null!"

    invoke-static {v0, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 689
    :goto_57
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;->this$0:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-static {v0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->-$$Nest$fgetmDisplayPowerController(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/display/DisplayPowerController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    .line 690
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->getWakelockController()Lcom/android/server/display/WakelockController;

    move-result-object v0

    .line 691
    .local v0, "wakelockController":Lcom/android/server/display/WakelockController;
    if-eqz v0, :cond_73

    .line 692
    invoke-virtual {v0, v1}, Lcom/android/server/display/WakelockController;->releaseWakelock(I)Z

    goto :goto_7a

    .line 694
    :cond_73
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string v2, "OnProximityPositiveSuspendRunnable: callbacks is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 696
    :goto_7a
    return-void
.end method
