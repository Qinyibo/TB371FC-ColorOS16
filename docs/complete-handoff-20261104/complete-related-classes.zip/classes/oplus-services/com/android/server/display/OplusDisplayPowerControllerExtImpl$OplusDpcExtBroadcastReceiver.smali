.class final Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;
.super Ljava/lang/Object;
.source "OplusDisplayPowerControllerExtImpl.java"

# interfaces
.implements Lcom/android/server/display/util/OplusDisplayBrightnessBroadcastReceiver$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "OplusDpcExtBroadcastReceiver"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method private constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 1772
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Lcom/android/server/display/OplusDisplayPowerControllerExtImpl-IA;)V
    .registers 3

    invoke-direct {p0, p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;-><init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)V

    return-void
.end method


# virtual methods
.method public onBroadcastReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 8
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 1775
    const/4 v0, 0x0

    .line 1776
    .local v0, "packageName":Ljava/lang/String;
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    sparse-switch v2, :sswitch_data_b2

    :cond_e
    goto :goto_23

    :sswitch_f
    const-string v2, "android.intent.action.PACKAGE_ADDED"

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    move v1, v3

    goto :goto_24

    :sswitch_19
    const-string v2, "android.intent.action.PACKAGE_REMOVED"

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    move v1, v4

    goto :goto_24

    :goto_23
    const/4 v1, -0x1

    :goto_24
    const-string/jumbo v2, "mIsOplusTest = "

    packed-switch v1, :pswitch_data_bc

    goto/16 :goto_b0

    .line 1785
    :pswitch_2c
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v0

    .line 1786
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmDisplaySpecialPkgList(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_4d

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmDisplaySpecialPkgList(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4d

    .line 1787
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1, v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fputmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Z)V

    .line 1789
    :cond_4d
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Z

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1790
    goto :goto_b0

    .line 1778
    :pswitch_6e
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v0

    .line 1779
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmDisplaySpecialPkgList(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_8f

    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmDisplaySpecialPkgList(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8f

    .line 1780
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1, v4}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fputmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Z)V

    .line 1782
    :cond_8f
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDpcExtBroadcastReceiver;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v3}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmIsOplusTest(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Z

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 1783
    nop

    .line 1794
    :goto_b0
    return-void

    nop

    :sswitch_data_b2
    .sparse-switch
        0x1f50b9c2 -> :sswitch_19
        0x5c1076e2 -> :sswitch_f
    .end sparse-switch

    :pswitch_data_bc
    .packed-switch 0x0
        :pswitch_6e
        :pswitch_2c
    .end packed-switch
.end method
