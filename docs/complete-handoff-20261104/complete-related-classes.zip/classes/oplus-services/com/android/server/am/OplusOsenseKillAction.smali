.class public Lcom/android/server/am/OplusOsenseKillAction;
.super Ljava/lang/Object;
.source "OplusOsenseKillAction.java"

# interfaces
.implements Lcom/oplus/datasync/IOplusDataSyncModule;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/am/OplusOsenseKillAction$KillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$INSTANCE;,
        Lcom/android/server/am/OplusOsenseKillAction$KillHandler;,
        Lcom/android/server/am/OplusOsenseKillAction$BloKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$DumpKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$NirvanaKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$BgLimitKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$BgLimitThermalKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$CameraLowFreeKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$GameLowFreeKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$LowMemQbKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$LowMemKillContext;,
        Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    }
.end annotation


# static fields
.field public static final APP_FEATURE_ATHENA_PROACTIVE_CLEAN:Ljava/lang/String; = "athena.kill.proactive_clean"

.field private static final AREA:Ljava/lang/String;

.field private static final AREA_DOMESTIC:Ljava/lang/String; = "domestic"

.field private static final ATHENA_CUSTOM_CONFIG_FLAG:Ljava/lang/String; = "athena_custom_config_flag"

.field private static final ATHENA_REMOTE_CONFIG_FLAG:Ljava/lang/String; = "athena_remote_config_flag"

.field private static final BLO_LEVEL_II:I = 0x2

.field private static final BRAND:Ljava/lang/String;

.field private static final BRAND_ONEPLUS:Ljava/lang/String; = "OnePlus"

.field private static final CLEAR_DETAIL_INFO_FLAG:Ljava/lang/String; = "clear_detail_info_flag"

.field public static final CONFIG_TYPE_BASE:I = 0x1

.field public static final CONFIG_TYPE_BLAST_POLICY_TYPE_LIST:I = 0x9

.field public static final CONFIG_TYPE_BLAST_SCENE_LIST:I = 0x8

.field public static final CONFIG_TYPE_CACHED_CLEAN_ONLY_POLICY_TYPE_LIST:I = 0x6

.field public static final CONFIG_TYPE_CCH_PROCESS_WHITELIST:I = 0xa

.field public static final CONFIG_TYPE_PACKAGE_WHITELIST:I = 0x3

.field public static final CONFIG_TYPE_PROCESS_WHITELIST:I = 0x2

.field public static final CONFIG_TYPE_SKIP_CLEAR_POLICY_TYPE_LIST:I = 0x5

.field public static final CONFIG_TYPE_SKIP_SCENE_LIST:I = 0x4

.field public static final CONFIG_TYPE_WHITELISTED_SERVICES:I = 0x7

.field private static final DATASYNC_FLAG_KEY:Ljava/lang/String; = "data_sync_flag_key"

.field private static final DEFAULT_HISTORY_SIZE:I = 0x32

.field private static final INVALID_TIME:I = -0x1

.field private static final LRU_SORT_BY_ADJ:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;"
        }
    .end annotation
.end field

.field private static final LRU_SORT_BY_PKG:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;"
        }
    .end annotation
.end field

.field private static final LRU_SORT_PROCESS_BY_MEM:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_CPU_HOGGING:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_CPU_UI_FZ_MEM:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_FZ_MEM:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_IMP:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_RECENT_APP_RULE:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_RECENT_LRU:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MRU_SORT_BY_UI_FZ_MEM:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;"
        }
    .end annotation
.end field

.field private static final MSG_EXEC_LOWMEM:I = 0x2

.field private static final MSG_INIT_2TH:I = 0x1

.field public static final OSENSE_KILL_THREAD_NAME:Ljava/lang/String; = "osense.kill"

.field private static final PROTECTED_GAME_MEM_THRESHOLD:I = 0x10

.field private static final SKIP_REASON_ACTIVE:Ljava/lang/String; = "treat-like-active"

.field private static final SKIP_REASON_AGING_VERSION_WHITE_PKG:Ljava/lang/String; = "aging-version-white-pkg"

.field private static final SKIP_REASON_APPCARE:Ljava/lang/String; = "protect-appcare"

.field private static final SKIP_REASON_ATHENA_WHITE_PKG:Ljava/lang/String; = "athena-white-pkg"

.field private static final SKIP_REASON_AUDIO_PLAY_PROCESS_RECORD:Ljava/lang/String; = "audio-play-process-record"

.field private static final SKIP_REASON_CAC_TARGET:Ljava/lang/String; = "cac-clean-target"

.field private static final SKIP_REASON_DEF_LAUNCHER:Ljava/lang/String; = "def_launcher"

.field private static final SKIP_REASON_DEPEND_BY_OTHER:Ljava/lang/String; = "depend-by-other"

.field private static final SKIP_REASON_HIGH_ADJ:Ljava/lang/String; = "high-adj"

.field private static final SKIP_REASON_ISOLATED:Ljava/lang/String; = "isolated-proc"

.field private static final SKIP_REASON_NON_ACTIVITY_PKG:Ljava/lang/String; = "non_activity_pkg"

.field private static final SKIP_REASON_NON_UI_APP:Ljava/lang/String; = "non-ui-app"

.field private static final SKIP_REASON_PRCP_PROCESS:Ljava/lang/String; = "prcp-proc"

.field private static final SKIP_REASON_PROTECT_PKG:Ljava/lang/String; = "protect-pkg"

.field private static final SKIP_REASON_PROTECT_PROC:Ljava/lang/String; = "protected-proc"

.field private static final SKIP_REASON_SHOWN_UI:Ljava/lang/String; = "shown-ui"

.field private static final SKIP_REASON_TEST_TOOL_PKG:Ljava/lang/String; = "test-tool-pkg"

.field private static final SKIP_REASON_WHITE_LIST_SVC:Ljava/lang/String; = "white-listed-service"

.field private static final SKIP_REVIVAL_SLOT_PKG:Ljava/lang/String; = "revival_slot_pkg"

.field private static final SUBREASON_ATOMIC_CLEAN:I = 0x400

.field private static final SUBREASON_BGLIMIT_GRP_CLEAN:I = 0x403

.field private static final SUBREASON_CAMERA_RELEASE_GRP_CLEAN:I = 0x404

.field private static final SUBREASON_GAME_RELEASE_GRP_CLEAN:I = 0x405

.field private static final SUBREASON_LOWMEM_GRP_CLEAN:I = 0x401

.field private static final SUBREASON_NIRVANA_GRP_CLEAN:I = 0x402

.field private static final SYNC_MODULE_ATOMIC_CLEAN:Ljava/lang/String; = "AtomicClean"

.field public static final TAG:Ljava/lang/String; = "KillAction"

.field private static final TOTAL_MEM_GB:I

.field private static final TYPE_KILL_PROCESS:I = 0x1

.field private static final TYPE_KILL_PROCESS_AND_GROUP:I = 0x3

.field private static final TYPE_KILL_PROCESS_QUIET:I = 0x2

.field private static final TYPE_KILL_PROCESS_QUIET_AND_GROUP:I = 0x4

.field private static final sImportantProcState:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final sImportantStatus:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;",
            ">;"
        }
    .end annotation
.end field

.field private static final sIsAgingVersion:Z

.field private static final sKillableProcState:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final sMyPid:I

.field private static final sUsefifo:Z

.field private static final sVerboseReason:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mAms:Lcom/android/server/am/ActivityManagerService;

.field private mBloFeatureLevel:I

.field private final mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

.field private final mConfigUtil:Lcom/android/server/am/ConfigUtil;

.field private mContext:Landroid/content/Context;

.field private final mFreezeTracker:Lcom/android/server/am/OplusFreezeStateTracker;

.field private mGMSExt:Lcom/android/server/app/IGameManagerServiceExt;

.field private final mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

.field private mHandlerThread:Landroid/os/HandlerThread;

.field private mHandlerThreadTid:I

.field private final mHistory:[Lcom/android/server/am/KillInfo;

.field private mHistoryIdx:I

.field private final mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/RemoteCallbackList<",
            "Lcom/oplus/datasync/ISysStateChangeCallback;",
            ">;"
        }
    .end annotation
.end field

.field private volatile mInBloMoreBg:Z

.field private volatile mInBloPerf:Z

.field private mInvalidKillCnt:I

.field private mLastInvalidKillTime:J

.field private mLastPurposeMemMB:I

.field private mLastStartActivityUid:I

.field private mLastValidScanAvailMem:J

.field private mLastValidScanTime:J

.field private mNumLastCachedProcesses:I

.field private mProcLock:Lcom/android/server/am/ActivityManagerGlobalLock;

.field private final mQuickBoot:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private volatile mReady:Z

.field private final mSetDebugDisable:Z


# direct methods
.method public static synthetic $r8$lambda$bHcH-tyEsVeBRPu0Nzyd7naZu_I(Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ProcessInfo;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->lambda$scanOomAdjIfNeeded$0(Lcom/android/server/am/ProcessInfo;)Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$fputmBloFeatureLevel(Lcom/android/server/am/OplusOsenseKillAction;I)V
    .registers 2

    iput p1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mBloFeatureLevel:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmHandlerThreadTid(Lcom/android/server/am/OplusOsenseKillAction;I)V
    .registers 2

    iput p1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmReady(Lcom/android/server/am/OplusOsenseKillAction;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mReady:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$mallSelectedByCachedClean(Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ProcessGroup;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->allSelectedByCachedClean(Lcom/android/server/am/ProcessGroup;)Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mexecuteInner(Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->executeInner(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mgetGameService(Lcom/android/server/am/OplusOsenseKillAction;)Lcom/android/server/app/IGameManagerServiceExt;
    .registers 1

    invoke-direct {p0}, Lcom/android/server/am/OplusOsenseKillAction;->getGameService()Lcom/android/server/app/IGameManagerServiceExt;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mshouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/server/am/OplusOsenseKillAction;->shouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$sfgetsIsAgingVersion()Z
    .registers 1

    sget-boolean v0, Lcom/android/server/am/OplusOsenseKillAction;->sIsAgingVersion:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetsVerboseReason()Ljava/util/Set;
    .registers 1

    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 155
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getTotalProcMemInfoGB()I

    move-result v0

    sput v0, Lcom/android/server/am/OplusOsenseKillAction;->TOTAL_MEM_GB:I

    .line 164
    const-string/jumbo v0, "ro.product.brand"

    invoke-static {v0}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->BRAND:Ljava/lang/String;

    .line 165
    const-string/jumbo v0, "ro.oplus.image.system_ext.area"

    invoke-static {v0}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->AREA:Ljava/lang/String;

    .line 205
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    .line 207
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_SYSTEM_WINDOW:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 208
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_FOCUS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 209
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_RECORDER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 210
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_GPS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 211
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_BT:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 212
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_VPN_CONN:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 213
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_WALLPAPER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 214
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_INPUT:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 215
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_WIDGET:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 216
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_TRAFFIC:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 217
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_RECENT_LOCKED:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 218
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_SCREEN_RECORDER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 219
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_PROTECTED_GAME:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 220
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    sget-object v1, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_FLASH_BACK:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 223
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    .line 225
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 226
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 227
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 228
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v2, 0xc

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 229
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v2, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 230
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v2, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 231
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v2, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 232
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/4 v2, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 233
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v2, 0x8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 234
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v3, 0xb

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 235
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v3, 0xd

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 236
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v3, 0xe

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 237
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sImportantProcState:Ljava/util/Set;

    const/16 v3, 0xf

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 240
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    .line 242
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/4 v3, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 243
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 244
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/16 v2, 0xa

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 245
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/16 v2, 0x10

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 246
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/16 v2, 0x11

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 247
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/16 v2, 0x12

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 248
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    const/16 v2, 0x13

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 251
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    .line 253
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string/jumbo v2, "prcp-proc"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 254
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string/jumbo v2, "non-ui-app"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 255
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string/jumbo v2, "isolated-proc"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 256
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string v2, "cac-clean-target"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 257
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string/jumbo v2, "high-adj"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 258
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->sVerboseReason:Ljava/util/Set;

    const-string/jumbo v2, "treat-like-active"

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 263
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    sput v0, Lcom/android/server/am/OplusOsenseKillAction;->sMyPid:I

    .line 264
    const-string/jumbo v0, "persist.sys.agingtest"

    const-string v2, "0"

    invoke-static {v0, v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "1"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusOsenseKillAction;->sIsAgingVersion:Z

    .line 265
    const-string/jumbo v0, "persist.sys.atomic.use_fifo"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusOsenseKillAction;->sUsefifo:Z

    .line 2811
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda10;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda10;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_RECENT_LRU:Ljava/util/Comparator;

    .line 2823
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda11;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda11;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_RECENT_APP_RULE:Ljava/util/Comparator;

    .line 2843
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda12;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda12;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_IMP:Ljava/util/Comparator;

    .line 2853
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda13;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda13;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_FZ_MEM:Ljava/util/Comparator;

    .line 2866
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda14;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda14;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_CPU_UI_FZ_MEM:Ljava/util/Comparator;

    .line 2893
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda15;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda15;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_UI_FZ_MEM:Ljava/util/Comparator;

    .line 2914
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda16;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda16;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->LRU_SORT_BY_PKG:Ljava/util/Comparator;

    .line 2925
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda17;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda17;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->LRU_SORT_BY_ADJ:Ljava/util/Comparator;

    .line 2935
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda18;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda18;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->LRU_SORT_PROCESS_BY_MEM:Ljava/util/Comparator;

    .line 2939
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda19;

    invoke-direct {v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda19;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_CPU_HOGGING:Ljava/util/Comparator;

    return-void
.end method

.method private constructor <init>()V
    .registers 5

    .line 307
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 268
    const/16 v0, 0x32

    new-array v0, v0, [Lcom/android/server/am/KillInfo;

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    .line 269
    invoke-static {}, Lcom/android/server/am/ConfigUtil;->getInstance()Lcom/android/server/am/ConfigUtil;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    .line 270
    new-instance v0, Landroid/os/RemoteCallbackList;

    invoke-direct {v0}, Landroid/os/RemoteCallbackList;-><init>()V

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    .line 271
    invoke-static {}, Lcom/android/server/am/OplusFreezeStateTracker;->getInstance()Lcom/android/server/am/OplusFreezeStateTracker;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mFreezeTracker:Lcom/android/server/am/OplusFreezeStateTracker;

    .line 273
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mQuickBoot:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 275
    const-string/jumbo v0, "persist.debug.disable_atomic_clean"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mSetDebugDisable:Z

    .line 285
    iput-boolean v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mReady:Z

    .line 286
    iput v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastPurposeMemMB:I

    .line 287
    iput v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    .line 288
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanTime:J

    .line 289
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getMemInfoAvailMB()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanAvailMem:J

    .line 290
    iput v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    .line 291
    const-wide/16 v2, -0x1

    iput-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    .line 292
    iput v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistoryIdx:I

    .line 297
    iput v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    .line 308
    new-instance v0, Landroid/os/HandlerThread;

    const-string/jumbo v1, "osense.kill"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThread:Landroid/os/HandlerThread;

    .line 309
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThread:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    .line 310
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;-><init>(Lcom/android/server/am/OplusOsenseKillAction;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    .line 311
    invoke-static {}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->create()Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    .line 312
    return-void
.end method

.method synthetic constructor <init>(Lcom/android/server/am/OplusOsenseKillAction-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/android/server/am/OplusOsenseKillAction;-><init>()V

    return-void
.end method

.method private allSelectedByCachedClean(Lcom/android/server/am/ProcessGroup;)Z
    .registers 7
    .param p1, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1554
    iget-object v0, p1, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    .line 1555
    .local v0, "pkgProcs":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessInfo;>;"
    const/4 v1, 0x1

    .line 1556
    .local v1, "allSelected":Z
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessInfo;

    .line 1557
    .local v3, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v4, v3, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-nez v4, :cond_19

    .line 1558
    const/4 v1, 0x0

    .line 1559
    goto :goto_1a

    .line 1561
    .end local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_19
    goto :goto_7

    .line 1562
    :cond_1a
    :goto_1a
    return v1
.end method

.method private checkBindEachOther(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/Set;Ljava/lang/String;)V
    .registers 10
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p3, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/OplusOsenseKillAction$KillContext;",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 1801
    .local p2, "checkList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_56

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/ProcessInfo;

    .line 1802
    .local v1, "pi":Lcom/android/server/am/ProcessInfo;
    const/4 v2, 0x1

    .line 1803
    .local v2, "flag":Z
    iget-object v3, v1, Lcom/android/server/am/ProcessInfo;->mServiceServers:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_17
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_38

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 1806
    .local v4, "server":Lcom/android/server/am/ProcessInfo;
    if-eqz v4, :cond_37

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mServiceClients:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_37

    .line 1809
    iget-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_37

    .line 1810
    const/4 v2, 0x0

    .line 1811
    goto :goto_38

    .line 1814
    .end local v4    # "server":Lcom/android/server/am/ProcessInfo;
    :cond_37
    goto :goto_17

    .line 1815
    :cond_38
    :goto_38
    if-eqz v2, :cond_55

    .line 1816
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "all svc client in candidate list: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "KillAction"

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1817
    invoke-virtual {p1, v1, p3}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1819
    .end local v1    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v2    # "flag":Z
    :cond_55
    goto :goto_4

    .line 1820
    :cond_56
    return-void
.end method

.method private checkIfCachedCleanOnly(Ljava/lang/String;)Z
    .registers 3
    .param p1, "policyType"    # Ljava/lang/String;

    .line 766
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->cachedCleanOnly(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private checkIsolatedProcess(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 9
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 1855
    iget-object v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 1856
    .local v0, "originalLength":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_7
    if-ge v1, v0, :cond_53

    .line 1857
    iget-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/ProcessInfo;

    .line 1859
    .local v2, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v3, v2, Lcom/android/server/am/ProcessInfo;->mServiceServers:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_17
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_50

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 1860
    .local v4, "serverPi":Lcom/android/server/am/ProcessInfo;
    iget-boolean v5, v4, Lcom/android/server/am/ProcessInfo;->isolated:Z

    if-eqz v5, :cond_4f

    .line 1861
    iget-object v5, v2, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    invoke-virtual {p1, v4, v5}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1862
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "find isolated process "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " for "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "KillAction"

    invoke-static {v6, v5}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1864
    .end local v4    # "serverPi":Lcom/android/server/am/ProcessInfo;
    :cond_4f
    goto :goto_17

    .line 1856
    .end local v2    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_50
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    .line 1866
    .end local v1    # "i":I
    :cond_53
    return-void
.end method

.method private checkProviderClientKillable(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/Set;Ljava/lang/String;)Ljava/util/Set;
    .registers 13
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p3, "reason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/OplusOsenseKillAction$KillContext;",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;"
        }
    .end annotation

    .line 1823
    .local p2, "checkList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    new-instance v0, Landroid/util/ArraySet;

    invoke-direct {v0}, Landroid/util/ArraySet;-><init>()V

    .line 1824
    .local v0, "checkServiceBindStatusList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    new-instance v1, Landroid/util/ArraySet;

    invoke-direct {v1}, Landroid/util/ArraySet;-><init>()V

    .line 1825
    .local v1, "checkBindEachOtherList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const-string v4, "KillAction"

    if-eqz v3, :cond_56

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessInfo;

    .line 1826
    .local v3, "pi":Lcom/android/server/am/ProcessInfo;
    const/4 v5, 0x1

    .line 1827
    .local v5, "flag":Z
    iget-object v6, v3, Lcom/android/server/am/ProcessInfo;->mProviderClients:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_23
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3a

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 1830
    .local v7, "clientPi":Lcom/android/server/am/ProcessInfo;
    iget-object v8, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v8, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_39

    .line 1831
    const/4 v5, 0x0

    .line 1832
    goto :goto_3a

    .line 1834
    .end local v7    # "clientPi":Lcom/android/server/am/ProcessInfo;
    :cond_39
    goto :goto_23

    .line 1835
    :cond_3a
    :goto_3a
    if-eqz v5, :cond_55

    .line 1836
    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1837
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "all provider client in candidate list, check svc bind status: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1839
    .end local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v5    # "flag":Z
    :cond_55
    goto :goto_e

    .line 1840
    :cond_56
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_98

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessInfo;

    .line 1841
    .restart local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    invoke-direct {p0, p1, v3, v1}, Lcom/android/server/am/OplusOsenseKillAction;->checkServiceBindStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/util/Set;)Ljava/lang/String;

    move-result-object v5

    .line 1842
    .local v5, "svcBindStatus":Ljava/lang/String;
    if-eqz v5, :cond_94

    .line 1843
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "skip "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " for "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " in provider client killable"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1844
    goto :goto_5a

    .line 1846
    :cond_94
    invoke-virtual {p1, v3, p3}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1847
    .end local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v5    # "svcBindStatus":Ljava/lang/String;
    goto :goto_5a

    .line 1848
    :cond_98
    return-object v1
.end method

.method private checkServiceBindStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/util/Set;)Ljava/lang/String;
    .registers 11
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/OplusOsenseKillAction$KillContext;",
            "Lcom/android/server/am/ProcessInfo;",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1760
    .local p3, "reCheckList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    const/4 v0, 0x0

    .line 1761
    .local v0, "svcBindStatus":Ljava/lang/String;
    const/4 v1, 0x0

    invoke-virtual {p2, v1}, Lcom/android/server/am/ProcessInfo;->hasServiceClient(Z)Z

    move-result v1

    if-eqz v1, :cond_76

    .line 1762
    const/4 v1, 0x0

    .line 1763
    .local v1, "hasActiveClient":Z
    const/4 v2, 0x0

    .line 1765
    .local v2, "bindingToClientSvc":Z
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mServiceClients:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_10
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const-string v5, "KillAction"

    if-eqz v4, :cond_38

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 1767
    .local v4, "client":Lcom/android/server/am/ProcessInfo;
    invoke-virtual {v4}, Lcom/android/server/am/ProcessInfo;->isFreezeStable()Z

    move-result v6

    if-nez v6, :cond_37

    iget-object v6, v4, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-nez v6, :cond_37

    .line 1768
    const-string/jumbo v3, "svc client %s not been freeze stable"

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v3, v6}, Lcom/android/server/am/LogUtil;->formatV(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1769
    const/4 v1, 0x1

    .line 1770
    const/4 v3, 0x1

    iput-boolean v3, p2, Lcom/android/server/am/ProcessInfo;->mHasActiveClient:Z

    .line 1771
    goto :goto_38

    .line 1773
    .end local v4    # "client":Lcom/android/server/am/ProcessInfo;
    :cond_37
    goto :goto_10

    .line 1778
    :cond_38
    :goto_38
    if-nez v1, :cond_62

    .line 1779
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mServiceServers:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_40
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_62

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 1782
    .local v4, "server":Lcom/android/server/am/ProcessInfo;
    if-eqz v4, :cond_61

    iget-object v6, p2, Lcom/android/server/am/ProcessInfo;->mServiceClients:Ljava/util/List;

    invoke-interface {v6, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_61

    .line 1783
    const-string v3, "bind each other, cur=%s, other=%s"

    filled-new-array {p2, v4}, [Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v3, v6}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1784
    const/4 v2, 0x1

    .line 1785
    goto :goto_62

    .line 1787
    .end local v4    # "server":Lcom/android/server/am/ProcessInfo;
    :cond_61
    goto :goto_40

    .line 1789
    :cond_62
    :goto_62
    if-nez v1, :cond_66

    if-eqz v2, :cond_6f

    .line 1790
    :cond_66
    if-eqz v1, :cond_6c

    const-string/jumbo v3, "has-active-client"

    goto :goto_6e

    :cond_6c
    const-string v3, "bind-each-other"

    :goto_6e
    move-object v0, v3

    .line 1792
    :cond_6f
    if-eqz v2, :cond_76

    if-eqz p3, :cond_76

    .line 1793
    invoke-interface {p3, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1796
    .end local v1    # "hasActiveClient":Z
    .end local v2    # "bindingToClientSvc":Z
    :cond_76
    return-object v0
.end method

.method private checkSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)Ljava/lang/String;
    .registers 13
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 770
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v0

    if-eqz v0, :cond_27

    .line 771
    const-string v0, "KillAction"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "no need to kill for enough mem: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getAvailMemoryMB()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 772
    const-string/jumbo v0, "enough-memory"

    return-object v0

    .line 774
    :cond_27
    iget-object v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->type:Ljava/lang/String;

    if-nez v0, :cond_37

    .line 775
    const-string v0, "KillAction"

    const-string/jumbo v1, "unknown request type"

    invoke-static {v0, v1}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 776
    const-string/jumbo v0, "unknown-type"

    return-object v0

    .line 781
    :cond_37
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getAvailMemoryMB()J

    move-result-wide v0

    .line 782
    .local v0, "avail":J
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    .line 783
    .local v2, "now":J
    iget v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->contextType:I

    const/4 v5, 0x4

    if-eq v4, v5, :cond_c8

    iget v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    iget v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastPurposeMemMB:I

    if-gt v4, v5, :cond_c8

    iget-wide v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanAvailMem:J

    sub-long/2addr v4, v0

    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    .line 785
    invoke-virtual {v6}, Lcom/android/server/am/ConfigUtil;->getValidMemChangeThres()I

    move-result v6

    int-to-long v6, v6

    cmp-long v4, v4, v6

    if-gez v4, :cond_c8

    iget-wide v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanTime:J

    sub-long v4, v2, v4

    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    .line 786
    invoke-virtual {v6}, Lcom/android/server/am/ConfigUtil;->getAdjacentKillThres()I

    move-result v6

    int-to-long v6, v6

    cmp-long v4, v4, v6

    if-gez v4, :cond_c8

    .line 787
    const-string v4, "KillAction"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "last: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanAvailMem:J

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb, "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanTime:J

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastPurposeMemMB:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb, now: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb, "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 789
    const-string/jumbo v4, "reclaim-continuously"

    return-object v4

    .line 793
    :cond_c8
    iget v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    if-lez v4, :cond_135

    .line 794
    const/4 v4, 0x0

    .line 795
    .local v4, "numCachedProcesses":I
    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v5, v5, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v5

    .line 796
    :try_start_d2
    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v6, v6, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v6}, Lcom/android/server/am/ActivityManagerService$PidMap;->size()I

    move-result v6

    const/4 v7, 0x1

    sub-int/2addr v6, v7

    .local v6, "i":I
    :goto_dc
    if-ltz v6, :cond_101

    .line 797
    iget-object v8, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v8, v8, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v8, v6}, Lcom/android/server/am/ActivityManagerService$PidMap;->valueAt(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v8

    .line 798
    .local v8, "app":Lcom/android/server/am/ProcessRecord;
    if-eqz v8, :cond_fe

    iget-object v9, v8, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v9}, Lcom/android/server/am/ProcessStateRecord;->getSetProcState()I

    move-result v9

    const/16 v10, 0xe

    if-gt v9, v10, :cond_fc

    iget-object v9, v8, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    .line 799
    invoke-virtual {v9}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v9

    const/16 v10, 0x320

    if-le v9, v10, :cond_fe

    .line 800
    :cond_fc
    add-int/lit8 v4, v4, 0x1

    .line 796
    .end local v8    # "app":Lcom/android/server/am/ProcessRecord;
    :cond_fe
    add-int/lit8 v6, v6, -0x1

    goto :goto_dc

    .line 803
    .end local v6    # "i":I
    :cond_101
    monitor-exit v5
    :try_end_102
    .catchall {:try_start_d2 .. :try_end_102} :catchall_132

    .line 804
    const-string v5, "KillAction"

    const-string/jumbo v6, "numCachedProcesses=%d, mNumLastCachedProcesses=%d"

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    iget v9, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v8, v9}, [Ljava/lang/Object;

    move-result-object v8

    invoke-static {v5, v6, v8}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 806
    iget v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    if-gt v4, v5, :cond_12e

    iget-wide v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    sub-long v5, v2, v5

    iget-object v8, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    iget-boolean v9, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    .line 807
    invoke-virtual {v8, v9}, Lcom/android/server/am/ConfigUtil;->getStableFzThresHold(Z)I

    move-result v8

    int-to-long v8, v8

    cmp-long v5, v5, v8

    if-gez v5, :cond_12e

    goto :goto_12f

    :cond_12e
    const/4 v7, 0x0

    :goto_12f
    iput-boolean v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanSkip:Z

    goto :goto_135

    .line 803
    :catchall_132
    move-exception v6

    :try_start_133
    monitor-exit v5
    :try_end_134
    .catchall {:try_start_133 .. :try_end_134} :catchall_132

    throw v6

    .line 809
    .end local v4    # "numCachedProcesses":I
    :cond_135
    :goto_135
    iget-boolean v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanOnly:Z

    if-eqz v4, :cond_141

    iget-boolean v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanSkip:Z

    if-eqz v4, :cond_141

    .line 810
    const-string/jumbo v4, "no-killable-cached-process"

    return-object v4

    .line 813
    :cond_141
    const/4 v4, 0x0

    return-object v4
.end method

.method private collectServiceComponent(Lcom/android/server/am/ProcessRecord;Lcom/android/server/am/ProcessInfo;)V
    .registers 9
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1888
    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mServices:Lcom/android/server/am/ProcessServiceRecord;

    .line 1889
    .local v0, "psr":Lcom/android/server/am/ProcessServiceRecord;
    invoke-virtual {v0}, Lcom/android/server/am/ProcessServiceRecord;->numberOfRunningServices()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .local v1, "is":I
    :goto_8
    if-ltz v1, :cond_2c

    .line 1890
    invoke-virtual {v0, v1}, Lcom/android/server/am/ProcessServiceRecord;->getRunningServiceAt(I)Lcom/android/server/am/ServiceRecord;

    move-result-object v3

    .line 1891
    .local v3, "s":Lcom/android/server/am/ServiceRecord;
    invoke-virtual {v3}, Lcom/android/server/am/ServiceRecord;->getComponentName()Landroid/content/ComponentName;

    move-result-object v4

    invoke-virtual {p2, v4}, Lcom/android/server/am/ProcessInfo;->addServiceComponent(Landroid/content/ComponentName;)V

    .line 1892
    iget-boolean v4, p2, Lcom/android/server/am/ProcessInfo;->defaultStopAllSvcIfKilled:Z

    if-eqz v4, :cond_29

    .line 1893
    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Lcom/android/server/am/ServiceRecord;->canStopIfKilled(Z)Z

    move-result v5

    if-eqz v5, :cond_27

    invoke-virtual {v3}, Lcom/android/server/am/ServiceRecord;->hasAutoCreateConnections()Z

    move-result v5

    if-nez v5, :cond_27

    move v4, v2

    :cond_27
    iput-boolean v4, p2, Lcom/android/server/am/ProcessInfo;->defaultStopAllSvcIfKilled:Z

    .line 1889
    .end local v3    # "s":Lcom/android/server/am/ServiceRecord;
    :cond_29
    add-int/lit8 v1, v1, -0x1

    goto :goto_8

    .line 1896
    .end local v1    # "is":I
    :cond_2c
    return-void
.end method

.method private continuouslyInvalidKill(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)Z
    .registers 4
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 835
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    iget-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->getContinuouslyInvalidKillThres()I

    move-result v1

    if-lt v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method private dumpMyMemItem(Ljava/util/ArrayList;Ljava/lang/StringBuilder;Ljava/lang/String;Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;)V
    .registers 11
    .param p2, "sb"    # Ljava/lang/StringBuilder;
    .param p3, "prefix"    # Ljava/lang/String;
    .param p4, "item"    # Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/StringBuilder;",
            "Ljava/lang/String;",
            "Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;",
            ")V"
        }
    .end annotation

    .line 2162
    .local p1, "lines":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "%s%s: %-60s%s"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->swapPss:J

    .line 2163
    invoke-static {v1, v2}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v1

    const-string v2, ")"

    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v1

    const-string v3, "(%s in swap%s"

    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2164
    .local v0, "format":Ljava/lang/String;
    const/4 v1, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2165
    iget-wide v3, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->pss:J

    invoke-static {v3, v4}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->label:Ljava/lang/String;

    .line 2166
    iget v4, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->userId:I

    if-eqz v4, :cond_4f

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, " (user "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v5, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->userId:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_51

    :cond_4f
    const-string v2, ""

    :goto_51
    filled-new-array {p3, v1, v3, v2}, [Ljava/lang/Object;

    move-result-object v1

    .line 2165
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2167
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2168
    iget-object v1, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->subitems:Ljava/util/ArrayList;

    if-eqz v1, :cond_90

    .line 2169
    iget-object v1, p4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->subitems:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_90

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    .line 2170
    .local v2, "it":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "    "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, p1, p2, v3, v2}, Lcom/android/server/am/OplusOsenseKillAction;->dumpMyMemItem(Ljava/util/ArrayList;Ljava/lang/StringBuilder;Ljava/lang/String;Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;)V

    .line 2171
    .end local v2    # "it":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    goto :goto_6d

    .line 2173
    :cond_90
    return-void
.end method

.method private executeInner(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 12
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 651
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->initKillContext(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 652
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "[atomic clean] start "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getRequestInfo()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", invalid-cnt="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 654
    .local v0, "logInfo":Ljava/lang/String;
    const-wide/16 v1, 0x40

    invoke-static {v1, v2, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 655
    const-string v3, "KillAction"

    invoke-static {v3, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 658
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->checkSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)Ljava/lang/String;

    move-result-object v3

    .line 659
    .local v3, "skipType":Ljava/lang/String;
    if-eqz v3, :cond_55

    .line 660
    const-string v4, "KillAction"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "[atomic clean] end: skip for "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 661
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->triggerMemoryGuardIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 662
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 663
    return-void

    .line 667
    :cond_55
    const/4 v4, 0x2

    iput v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 668
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->preScan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 670
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    .line 671
    .local v4, "waitAmsStart":J
    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v6

    .line 672
    :try_start_65
    const-string/jumbo v7, "groupProcessLocked"

    invoke-static {v1, v2, v7}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 673
    iget v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    sub-long/2addr v8, v4

    long-to-int v8, v8

    add-int/2addr v7, v8

    iput v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    .line 674
    new-instance v7, Ljava/util/ArrayList;

    iget-object v8, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v8, v8, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v8}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, p1, v7}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 675
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 677
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->scan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 679
    const/4 v7, 0x7

    iput v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 680
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->executeKill(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 681
    monitor-exit v6
    :try_end_93
    .catchall {:try_start_65 .. :try_end_93} :catchall_e5

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 682
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v6

    iput-wide v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endUpTime:J

    .line 683
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getMemInfoAvailMB()J

    move-result-wide v6

    iput-wide v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endAvailMB:J

    .line 684
    const-string v6, "KillAction"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "[atomic clean] end requestId="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->requestId:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ", endAvail="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-wide v8, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endAvailMB:J

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string/jumbo v8, "mb, "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 685
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getExecuteInfo()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 684
    invoke-static {v6, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 687
    const/16 v6, 0x8

    iput v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 688
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->triggerMemoryGuardIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 689
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->finishScan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 690
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 691
    return-void

    .line 681
    :catchall_e5
    move-exception v1

    :try_start_e6
    monitor-exit v6
    :try_end_e7
    .catchall {:try_start_e6 .. :try_end_e7} :catchall_e5

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v1
.end method

.method private executeKill(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 23
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 2354
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string/jumbo v0, "executeKill"

    const-wide/16 v3, 0x40

    invoke-static {v3, v4, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2355
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    .line 2356
    .local v5, "killStart":J
    const/4 v7, 0x0

    .line 2358
    .local v7, "localCnt":I
    iget-object v0, v1, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v8, v0, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v8

    .line 2360
    :try_start_16
    iget-object v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .local v0, "i":I
    :goto_1e
    if-ltz v0, :cond_61

    .line 2361
    iget-object v9, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v9, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/android/server/am/ProcessGroup;

    .line 2362
    .local v9, "group":Lcom/android/server/am/ProcessGroup;
    const/4 v10, 0x0

    .local v10, "j":I
    :goto_29
    iget-object v11, v9, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-ge v10, v11, :cond_5e

    .line 2363
    iget-object v11, v9, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/android/server/am/ProcessInfo;

    .line 2364
    .local v11, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v12, v9, Lcom/android/server/am/ProcessGroup;->mCleanType:Ljava/lang/String;

    if-nez v12, :cond_41

    iget-object v12, v11, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-eqz v12, :cond_5b

    .line 2365
    :cond_41
    iget-object v12, v1, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v12, v12, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    iget v13, v11, Lcom/android/server/am/ProcessInfo;->mPid:I

    invoke-virtual {v12, v13}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v12

    .line 2366
    .local v12, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v12, :cond_5b

    invoke-virtual {v11}, Lcom/android/server/am/ProcessInfo;->getProcessName()Ljava/lang/String;

    move-result-object v13

    iget-object v14, v12, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    invoke-virtual {v13, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_5b

    .line 2367
    iput-object v12, v11, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    .line 2362
    .end local v11    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v12    # "proc":Lcom/android/server/am/ProcessRecord;
    :cond_5b
    add-int/lit8 v10, v10, 0x1

    goto :goto_29

    .line 2360
    .end local v9    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v10    # "j":I
    :cond_5e
    add-int/lit8 v0, v0, -0x1

    goto :goto_1e

    .line 2372
    .end local v0    # "i":I
    :cond_61
    monitor-exit v8
    :try_end_62
    .catchall {:try_start_16 .. :try_end_62} :catchall_235

    .line 2374
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v9

    .line 2375
    .local v9, "waitAmsStart":J
    iget-object v11, v1, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v11

    .line 2376
    :try_start_6c
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v12

    .line 2378
    .local v12, "syncStart":J
    iget-object v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .restart local v0    # "i":I
    :goto_78
    if-ltz v0, :cond_fb

    .line 2379
    invoke-virtual {v2}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakKill()Z

    move-result v8

    if-eqz v8, :cond_c3

    .line 2380
    const-string v8, "KillAction"

    move-wide/from16 v16, v3

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "release enough memory or killing too much, pss="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-wide/16 v18, 0x400

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedPssKB:J

    div-long v14, v14, v18

    invoke-virtual {v3, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "mb, anonRss="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    invoke-virtual {v3, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "mb, swap="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    invoke-virtual {v3, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "mb"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v8, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2384
    goto :goto_ff

    .line 2386
    :cond_c3
    move-wide/from16 v16, v3

    iget-object v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessGroup;

    .line 2387
    .local v3, "group":Lcom/android/server/am/ProcessGroup;
    iget-object v4, v3, Lcom/android/server/am/ProcessGroup;->mCleanType:Ljava/lang/String;

    if-nez v4, :cond_f5

    .line 2388
    const/4 v4, 0x0

    .local v4, "j":I
    :goto_d2
    iget-object v8, v3, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-ge v4, v8, :cond_f5

    .line 2389
    iget-object v8, v3, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v8, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessInfo;

    .line 2390
    .local v8, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v14, v8, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-eqz v14, :cond_f2

    .line 2391
    iget-object v14, v8, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    invoke-direct {v1, v2, v8, v14}, Lcom/android/server/am/OplusOsenseKillAction;->killOneProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 2392
    iget-object v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanKilledList:Ljava/util/List;

    invoke-interface {v14, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2393
    add-int/lit8 v7, v7, 0x1

    .line 2388
    .end local v8    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_f2
    add-int/lit8 v4, v4, 0x1

    goto :goto_d2

    .line 2378
    .end local v3    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v4    # "j":I
    :cond_f5
    add-int/lit8 v0, v0, -0x1

    move-wide/from16 v3, v16

    goto/16 :goto_78

    :cond_fb
    move-wide/from16 v16, v3

    const-wide/16 v18, 0x400

    .line 2398
    .end local v0    # "i":I
    :goto_ff
    const/4 v0, 0x0

    .restart local v0    # "i":I
    :goto_100
    iget-object v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v0, v3, :cond_1b8

    .line 2399
    invoke-virtual {v2}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakKill()Z

    move-result v3

    if-eqz v3, :cond_14d

    .line 2400
    const-string v3, "KillAction"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "release enough memory or killing too much, pss="

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedPssKB:J

    div-long v14, v14, v18

    invoke-virtual {v4, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v8, "mb, anonRss="

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    invoke-virtual {v4, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v8, "mb, swap="

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-wide v14, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    invoke-virtual {v4, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v8, "mb"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2404
    goto :goto_1ba

    .line 2406
    :cond_14d
    iget-object v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessGroup;

    .line 2407
    .restart local v3    # "group":Lcom/android/server/am/ProcessGroup;
    const/4 v4, 0x0

    .line 2408
    .local v4, "interrupt":Z
    const-string v8, "KillAction"

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "clean process of "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-static {v8, v14}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2409
    const/4 v8, 0x0

    .local v8, "j":I
    :goto_173
    iget-object v14, v3, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v14

    if-ge v8, v14, :cond_1ac

    .line 2410
    if-nez v4, :cond_18e

    .line 2411
    invoke-static {}, Lcom/android/server/am/OplusOsenseCompressAction;->getInstance()Lcom/android/server/am/OplusOsenseCompressAction;

    move-result-object v14

    iget v15, v3, Lcom/android/server/am/ProcessGroup;->mUid:I

    move/from16 v20, v0

    .end local v0    # "i":I
    .local v20, "i":I
    const-string/jumbo v0, "group-clean"

    invoke-virtual {v14, v15, v0}, Lcom/android/server/am/OplusOsenseCompressAction;->cancelMemcgBgCompressUid(ILjava/lang/String;)Z

    move-result v0

    move v4, v0

    .end local v4    # "interrupt":Z
    .local v0, "interrupt":Z
    goto :goto_190

    .line 2410
    .end local v20    # "i":I
    .local v0, "i":I
    .restart local v4    # "interrupt":Z
    :cond_18e
    move/from16 v20, v0

    .line 2414
    .end local v0    # "i":I
    .restart local v20    # "i":I
    :goto_190
    iget-object v0, v3, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/ProcessInfo;

    .line 2415
    .local v0, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v14, v0, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-eqz v14, :cond_1a7

    .line 2416
    iget-object v14, v3, Lcom/android/server/am/ProcessGroup;->mCleanType:Ljava/lang/String;

    invoke-virtual {v2}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getGroupCleanReasonCode()I

    move-result v15

    invoke-direct {v1, v2, v0, v14, v15}, Lcom/android/server/am/OplusOsenseKillAction;->killOneProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/lang/String;I)V

    .line 2417
    add-int/lit8 v7, v7, 0x1

    .line 2409
    .end local v0    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_1a7
    add-int/lit8 v8, v8, 0x1

    move/from16 v0, v20

    goto :goto_173

    .end local v20    # "i":I
    .local v0, "i":I
    :cond_1ac
    move/from16 v20, v0

    .line 2420
    .end local v0    # "i":I
    .end local v8    # "j":I
    .restart local v20    # "i":I
    iget-object v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->killedGroupList:Ljava/util/List;

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2398
    nop

    .end local v3    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v4    # "interrupt":Z
    add-int/lit8 v0, v20, 0x1

    .end local v20    # "i":I
    .restart local v0    # "i":I
    goto/16 :goto_100

    :cond_1b8
    move/from16 v20, v0

    .line 2422
    .end local v0    # "i":I
    :goto_1ba
    monitor-exit v11
    :try_end_1bb
    .catchall {:try_start_6c .. :try_end_1bb} :catchall_22f

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 2423
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 2424
    .local v3, "killEndTime":J
    sub-long v14, v3, v5

    long-to-int v0, v14

    iput v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->killDurMs:I

    .line 2425
    iget v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    sub-long v14, v12, v9

    long-to-int v8, v14

    add-int/2addr v0, v8

    iput v0, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    .line 2426
    const-string v0, "KillAction"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "done execute kill, pi2app="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sub-long v14, v9, v5

    invoke-virtual {v8, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string/jumbo v11, "ms, monitor="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sub-long v14, v12, v9

    invoke-virtual {v8, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string/jumbo v11, "ms, kill="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sub-long v14, v3, v12

    invoke-virtual {v8, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string/jumbo v11, "ms, total="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sub-long v14, v3, v5

    invoke-virtual {v8, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string/jumbo v11, "ms, kill cnt="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-object v11, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    .line 2430
    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v11, ", local cnt="

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 2426
    invoke-static {v0, v8}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2431
    invoke-static/range {v16 .. v17}, Landroid/os/Trace;->traceEnd(J)V

    .line 2432
    return-void

    .line 2422
    .end local v3    # "killEndTime":J
    .end local v12    # "syncStart":J
    :catchall_22f
    move-exception v0

    :try_start_230
    monitor-exit v11
    :try_end_231
    .catchall {:try_start_230 .. :try_end_231} :catchall_22f

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v0

    .line 2372
    .end local v9    # "waitAmsStart":J
    :catchall_235
    move-exception v0

    :try_start_236
    monitor-exit v8
    :try_end_237
    .catchall {:try_start_236 .. :try_end_237} :catchall_235

    throw v0
.end method

.method private finishScan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 11
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 867
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isInValidKillAction()Z

    move-result v0

    if-eqz v0, :cond_a

    .line 868
    invoke-direct {p0}, Lcom/android/server/am/OplusOsenseKillAction;->incInvalidKill()V

    goto :goto_17

    .line 870
    :cond_a
    invoke-direct {p0}, Lcom/android/server/am/OplusOsenseKillAction;->resetInvalidKill()V

    .line 872
    iget-wide v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endAvailMB:J

    iput-wide v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanAvailMem:J

    .line 873
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanTime:J

    .line 875
    :goto_17
    iget v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    iput v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastPurposeMemMB:I

    .line 877
    const/4 v0, 0x0

    iput v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    .line 878
    iget-object v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_24
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/ProcessInfo;

    .line 879
    .local v1, "pi":Lcom/android/server/am/ProcessInfo;
    invoke-virtual {v1}, Lcom/android/server/am/ProcessInfo;->getCurProcState()I

    move-result v2

    const/16 v3, 0xe

    if-gt v2, v3, :cond_40

    .line 880
    invoke-virtual {v1}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v2

    const/16 v3, 0x320

    if-le v2, v3, :cond_46

    .line 881
    :cond_40
    iget v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    .line 883
    .end local v1    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_46
    goto :goto_24

    .line 884
    :cond_47
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->reportToOsenseLogger(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 885
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->reportKillDetailInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 886
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->saveToHistory(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 887
    invoke-static {}, Lcom/android/server/oplus/osense/scene/SceneRecogManager;->getInstance()Lcom/android/server/oplus/osense/scene/SceneRecogManager;

    move-result-object v0

    iget-wide v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    long-to-int v1, v1

    invoke-virtual {v0, v1}, Lcom/android/server/oplus/osense/scene/SceneRecogManager;->notifyMemoryReleased(I)V

    .line 888
    invoke-static {}, Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;->getInstance()Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;

    move-result-object v2

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v3

    iget-object v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    .line 889
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    iget-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedMemMB:J

    iget-wide v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseAnonRssMB:J

    .line 888
    invoke-virtual/range {v2 .. v8}, Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;->onClearFinished(Ljava/lang/String;IJJ)V

    .line 891
    return-void
.end method

.method private getAllProcCheckSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Lcom/android/server/app/IGameManagerServiceExt;J)Ljava/lang/String;
    .registers 13
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;
    .param p3, "gms"    # Lcom/android/server/app/IGameManagerServiceExt;
    .param p4, "start"    # J

    .line 1392
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isProtectPkg()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1393
    const-string/jumbo v0, "protect-pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1395
    :cond_c
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isRevivalSlotPkg()Z

    move-result v0

    if-eqz v0, :cond_18

    .line 1396
    const-string/jumbo v0, "revival_slot_pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1399
    :cond_18
    invoke-virtual {p0, p2}, Lcom/android/server/am/OplusOsenseKillAction;->getImportantProcState(Lcom/android/server/am/ProcessGroup;)I

    move-result v0

    .line 1400
    .local v0, "impProcState":I
    const/4 v1, -0x1

    if-eq v0, v1, :cond_26

    .line 1401
    invoke-static {v0}, Landroid/app/ActivityManager;->procStateToString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1403
    :cond_26
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusOsenseKillAction;->getImportantAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Ljava/lang/String;

    move-result-object v1

    .line 1404
    .local v1, "impStatus":Ljava/lang/String;
    if-eqz v1, :cond_2f

    .line 1405
    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1408
    :cond_2f
    iget v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    if-gtz v2, :cond_54

    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusOsenseKillAction;->isRecentlyUsedApp(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Z

    move-result v2

    if-eqz v2, :cond_54

    .line 1409
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "recent-used-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v2

    .line 1411
    :cond_54
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->skipNonUiApp()Z

    move-result v2

    if-eqz v2, :cond_66

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v2

    if-eqz v2, :cond_66

    .line 1412
    const-string/jumbo v2, "non-ui-app"

    iput-object v2, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v2

    .line 1415
    :cond_66
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v2

    if-eqz v2, :cond_b1

    invoke-direct {p0, p2}, Lcom/android/server/am/OplusOsenseKillAction;->allSelectedByCachedClean(Lcom/android/server/am/ProcessGroup;)Z

    move-result v2

    if-nez v2, :cond_b1

    .line 1416
    const/4 v2, 0x0

    .line 1417
    .local v2, "skipType":Ljava/lang/String;
    iget-boolean v3, p2, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-eqz v3, :cond_7b

    .line 1418
    const-string/jumbo v2, "sys-app-not-all-selected"

    goto :goto_ac

    .line 1420
    :cond_7b
    iget-object v3, p2, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_81
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_ac

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 1421
    .local v4, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v5, v4, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-nez v5, :cond_a1

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Lcom/android/server/am/ProcessInfo;->hasProviderClient(Z)Z

    move-result v6

    if-nez v6, :cond_9e

    .line 1422
    invoke-virtual {v4, v5}, Lcom/android/server/am/ProcessInfo;->hasServiceClient(Z)Z

    move-result v5

    if-eqz v5, :cond_a1

    .line 1423
    :cond_9e
    const-string v2, "depend-by-other"

    .line 1424
    goto :goto_ac

    .line 1426
    :cond_a1
    invoke-direct {p0, p1, p4, p5, v4}, Lcom/android/server/am/OplusOsenseKillAction;->shouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z

    move-result v5

    if-eqz v5, :cond_ab

    .line 1427
    const-string/jumbo v2, "treat-like-active"

    .line 1428
    goto :goto_ac

    .line 1430
    .end local v4    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_ab
    goto :goto_81

    .line 1432
    :cond_ac
    :goto_ac
    if-eqz v2, :cond_b1

    .line 1433
    iput-object v2, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v2

    .line 1436
    .end local v2    # "skipType":Ljava/lang/String;
    :cond_b1
    if-eqz p3, :cond_cb

    iget-boolean v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    if-eqz v2, :cond_cb

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v2

    if-nez v2, :cond_cb

    iget-object v2, p2, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    .line 1437
    invoke-interface {p3, v2}, Lcom/android/server/app/IGameManagerServiceExt;->isGamePkg(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 1438
    const-string/jumbo v2, "game-in-qb-mode"

    iput-object v2, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v2

    .line 1440
    :cond_cb
    const/4 v2, 0x0

    return-object v2
.end method

.method private getAllProcCheckSkipTypeForRecentBgApp(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Lcom/android/server/app/IGameManagerServiceExt;J)Ljava/lang/String;
    .registers 9
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;
    .param p3, "gms"    # Lcom/android/server/app/IGameManagerServiceExt;
    .param p4, "start"    # J

    .line 1445
    invoke-virtual {p1, p2}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getProtectType(Lcom/android/server/am/ProcessGroup;)Ljava/lang/String;

    move-result-object v0

    .line 1446
    .local v0, "skip":Ljava/lang/String;
    if-eqz v0, :cond_7

    .line 1447
    return-object v0

    .line 1450
    :cond_7
    iget-boolean v1, p2, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-nez v1, :cond_16

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isAthenaWhitePkg()Z

    move-result v1

    if-eqz v1, :cond_16

    .line 1451
    const-string v1, "athena-white-pkg"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1454
    :cond_16
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isAgingVersionWhitePkg()Z

    move-result v1

    if-eqz v1, :cond_21

    .line 1455
    const-string v1, "aging-version-white-pkg"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1458
    :cond_21
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isTestToolPkg()Z

    move-result v1

    if-eqz v1, :cond_2d

    .line 1459
    const-string/jumbo v1, "test-tool-pkg"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1462
    :cond_2d
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->skipNonUiApp()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v1

    if-eqz v1, :cond_3f

    .line 1463
    const-string/jumbo v1, "non-ui-app"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1466
    :cond_3f
    iget-object v1, p2, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4e

    .line 1467
    const-string v1, "def_launcher"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1470
    :cond_4e
    iget-object v1, p2, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->isNonActivityPackage(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5c

    .line 1471
    const-string/jumbo v1, "non_activity_pkg"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1474
    :cond_5c
    const/4 v1, 0x0

    return-object v1
.end method

.method private static getAppPackageName(Lcom/android/server/am/ProcessRecord;)Ljava/lang/String;
    .registers 3
    .param p0, "app"    # Lcom/android/server/am/ProcessRecord;

    .line 2952
    invoke-virtual {p0}, Lcom/android/server/am/ProcessRecord;->getPackageList()[Ljava/lang/String;

    move-result-object v0

    .line 2953
    .local v0, "pkgList":[Ljava/lang/String;
    if-eqz v0, :cond_d

    array-length v1, v0

    if-lez v1, :cond_d

    .line 2954
    const/4 v1, 0x0

    aget-object v1, v0, v1

    return-object v1

    .line 2956
    :cond_d
    iget-object v1, p0, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    return-object v1
.end method

.method private getCchEmptyCheckSkipReason(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;JLjava/util/Set;Ljava/util/Set;)Ljava/lang/String;
    .registers 12
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .param p3, "start"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/OplusOsenseKillAction$KillContext;",
            "Lcom/android/server/am/ProcessInfo;",
            "J",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessInfo;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1658
    .local p5, "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .local p6, "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    const/4 v0, 0x0

    .line 1659
    .local v0, "isNonPrcpFgsApp":Z
    invoke-direct {p0, p2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldCheckCacheClean(Lcom/android/server/am/ProcessInfo;)Z

    move-result v1

    if-nez v1, :cond_14

    invoke-direct {p0, p2}, Lcom/android/server/am/OplusOsenseKillAction;->isNonPerceptibleFgServiceApp(Lcom/android/server/am/ProcessInfo;)Z

    move-result v1

    move v0, v1

    if-nez v1, :cond_14

    .line 1660
    const-string/jumbo v1, "prcp-proc"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1665
    :cond_14
    if-eqz v0, :cond_2f

    .line 1666
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "don\'t check adj for non perceptible fgs app: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "KillAction"

    invoke-static {v2, v1}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4d

    .line 1667
    :cond_2f
    iget-object v1, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v1}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v1

    const/16 v2, 0x320

    if-lt v1, v2, :cond_47

    .line 1668
    :cond_3f
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v1

    const/16 v2, 0x1f4

    if-ge v1, v2, :cond_4d

    .line 1669
    :cond_47
    const-string/jumbo v1, "high-adj"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1672
    :cond_4d
    :goto_4d
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v1

    if-nez v1, :cond_5f

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isPreloadProc()Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 1673
    const-string/jumbo v1, "preload-app"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1677
    :cond_5f
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasActivitiesOrRecentTasks()Z

    move-result v1

    if-nez v1, :cond_17b

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasShownUi()Z

    move-result v1

    if-eqz v1, :cond_6d

    goto/16 :goto_17b

    .line 1681
    :cond_6d
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isProtectProcess()Z

    move-result v1

    if-eqz v1, :cond_79

    .line 1682
    const-string/jumbo v1, "protected-proc"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1685
    :cond_79
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isAudioPlayRecordProcess()Z

    move-result v1

    if-eqz v1, :cond_84

    .line 1686
    const-string v1, "audio-play-process-record"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1690
    :cond_84
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->numberOfRunningServices()I

    move-result v1

    if-gtz v1, :cond_90

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->numberOfProviders()I

    move-result v1

    if-lez v1, :cond_dd

    .line 1693
    :cond_90
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isIsolated()Z

    move-result v1

    if-eqz v1, :cond_9c

    .line 1694
    const-string/jumbo v1, "isolated-proc"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1697
    :cond_9c
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v1

    if-nez v1, :cond_ae

    invoke-direct {p0, p1, p3, p4, p2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z

    move-result v1

    if-eqz v1, :cond_ae

    .line 1698
    const-string/jumbo v1, "treat-like-active"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1700
    :cond_ae
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isWhiteListedForService()Z

    move-result v1

    if-eqz v1, :cond_ba

    .line 1701
    const-string/jumbo v1, "white-listed-service"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1706
    :cond_ba
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->allowRestart()Z

    move-result v1

    if-eqz v1, :cond_c5

    .line 1708
    const-string v1, "allow-svc-restart"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1710
    :cond_c5
    iget-object v1, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v1}, Lcom/android/server/am/ProcessGroup;->isCchWhiteListPkg()Z

    move-result v1

    if-eqz v1, :cond_d2

    .line 1711
    const-string v1, "cch-white-list-pkg"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1713
    :cond_d2
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isCchProtectProcess()Z

    move-result v1

    if-eqz v1, :cond_dd

    .line 1714
    const-string v1, "cch-protect-process"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1719
    :cond_dd
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->providerHasClientActivities()Z

    move-result v1

    if-eqz v1, :cond_ec

    .line 1721
    invoke-interface {p5, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1722
    const-string/jumbo v1, "has-provider-client"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1726
    :cond_ec
    invoke-direct {p0, p1, p2, p6}, Lcom/android/server/am/OplusOsenseKillAction;->checkServiceBindStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/util/Set;)Ljava/lang/String;

    move-result-object v1

    .line 1727
    .local v1, "svcBindStatus":Ljava/lang/String;
    if-eqz v1, :cond_f5

    .line 1728
    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1731
    :cond_f5
    iget-object v2, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-direct {p0, p1, v2}, Lcom/android/server/am/OplusOsenseKillAction;->getImportantAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Ljava/lang/String;

    move-result-object v2

    .line 1732
    .local v2, "impStatus":Ljava/lang/String;
    if-eqz v2, :cond_100

    .line 1733
    iput-object v2, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v2

    .line 1736
    :cond_100
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->isProtectPkg()Z

    move-result v3

    if-eqz v3, :cond_10e

    .line 1737
    const-string/jumbo v3, "protect-pkg"

    iput-object v3, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v3

    .line 1740
    :cond_10e
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->isRevivalSlotPkg()Z

    move-result v3

    if-eqz v3, :cond_11c

    .line 1741
    const-string/jumbo v3, "revival_slot_pkg"

    iput-object v3, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v3

    .line 1744
    :cond_11c
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v3

    if-nez v3, :cond_14f

    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    .line 1745
    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v3

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v4}, Lcom/android/server/am/ConfigUtil;->getThresholdForCchEmptyCheck()I

    move-result v4

    if-gt v3, v4, :cond_14f

    .line 1746
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "recent-used-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v4}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v3

    .line 1749
    :cond_14f
    const-string v3, "OnePlus"

    sget-object v4, Lcom/android/server/am/OplusOsenseKillAction;->BRAND:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_179

    const-string v3, "domestic"

    sget-object v4, Lcom/android/server/am/OplusOsenseKillAction;->AREA:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_179

    sget v3, Lcom/android/server/am/OplusOsenseKillAction;->TOTAL_MEM_GB:I

    const/16 v4, 0x10

    if-lt v3, v4, :cond_179

    .line 1751
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v3, v3, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-virtual {p1, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isInHeatGamePkgList(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_179

    .line 1752
    const-string/jumbo v3, "game-package"

    iput-object v3, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v3

    .line 1756
    :cond_179
    const/4 v3, 0x0

    return-object v3

    .line 1678
    .end local v1    # "svcBindStatus":Ljava/lang/String;
    .end local v2    # "impStatus":Ljava/lang/String;
    :cond_17b
    :goto_17b
    const-string/jumbo v1, "shown-ui"

    iput-object v1, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v1
.end method

.method private getGameService()Lcom/android/server/app/IGameManagerServiceExt;
    .registers 2

    .line 1018
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mGMSExt:Lcom/android/server/app/IGameManagerServiceExt;

    if-eqz v0, :cond_7

    .line 1019
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mGMSExt:Lcom/android/server/app/IGameManagerServiceExt;

    return-object v0

    .line 1021
    :cond_7
    invoke-static {}, Lcom/android/server/app/GameManagerServiceExtImpl;->getService()Lcom/android/server/app/IGameManagerServiceExt;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mGMSExt:Lcom/android/server/app/IGameManagerServiceExt;

    .line 1022
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mGMSExt:Lcom/android/server/app/IGameManagerServiceExt;

    return-object v0
.end method

.method private getImportantAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Ljava/lang/String;
    .registers 8
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1480
    iget-boolean v0, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatusValid:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_10

    .line 1481
    iget-object v0, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatus:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    if-eqz v0, :cond_f

    iget-object v0, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatus:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v0}, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_f
    return-object v1

    .line 1483
    :cond_10
    sget-object v0, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_INVALID_TYPE:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1484
    .local v0, "impAppStatus":Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;
    iget-object v2, p2, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_18
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_37

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1485
    .local v3, "type":Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;
    sget-object v4, Lcom/android/server/am/OplusOsenseKillAction;->sImportantStatus:Ljava/util/Set;

    invoke-interface {v4, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_36

    .line 1486
    move-object v0, v3

    .line 1487
    sget-object v4, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_TRAFFIC:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    if-eq v0, v4, :cond_36

    sget-object v4, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_GPS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    if-eq v0, v4, :cond_36

    .line 1489
    goto :goto_37

    .line 1492
    .end local v3    # "type":Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;
    :cond_36
    goto :goto_18

    .line 1493
    :cond_37
    :goto_37
    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_INVALID_TYPE:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    const/4 v3, 0x1

    if-eq v0, v2, :cond_8c

    .line 1494
    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_TRAFFIC:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    if-eq v0, v2, :cond_44

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_GPS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    if-ne v0, v2, :cond_83

    :cond_44
    iget-object v2, p2, Lcom/android/server/am/ProcessGroup;->mProcStates:Ljava/util/Set;

    .line 1495
    const/4 v4, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_83

    .line 1496
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "pkg: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " has "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " without fgs, try to kill it"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "KillAction"

    invoke-static {v4, v2}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_8c

    .line 1499
    :cond_83
    iput-boolean v3, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatusValid:Z

    .line 1500
    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatus:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1501
    invoke-virtual {v0}, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->getName()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 1505
    :cond_8c
    :goto_8c
    iput-boolean v3, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatusValid:Z

    .line 1506
    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->cachedImportantAppStatus:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1507
    return-object v1
.end method

.method public static getInstance()Lcom/android/server/am/OplusOsenseKillAction;
    .registers 1

    .line 304
    invoke-static {}, Lcom/android/server/am/OplusOsenseKillAction$INSTANCE;->-$$Nest$sfgetsInstance()Lcom/android/server/am/OplusOsenseKillAction;

    move-result-object v0

    return-object v0
.end method

.method private getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .registers 5
    .param p1, "extra"    # Landroid/os/Bundle;
    .param p2, "contextType"    # I

    .line 627
    if-nez p2, :cond_a

    .line 628
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$DumpKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$DumpKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 629
    :cond_a
    const/4 v0, 0x3

    if-ne p2, v0, :cond_15

    .line 630
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$NirvanaKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$NirvanaKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 631
    :cond_15
    const/4 v0, 0x4

    if-ne p2, v0, :cond_20

    .line 632
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$BgLimitKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$BgLimitKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 633
    :cond_20
    const/4 v0, 0x5

    if-ne p2, v0, :cond_2b

    .line 634
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$BgLimitThermalKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$BgLimitThermalKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 635
    :cond_2b
    const/4 v0, 0x6

    if-ne p2, v0, :cond_36

    .line 636
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$CameraLowFreeKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$CameraLowFreeKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 637
    :cond_36
    const/4 v0, 0x7

    if-ne p2, v0, :cond_41

    .line 638
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$GameLowFreeKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$GameLowFreeKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 640
    :cond_41
    sget v0, Lcom/android/server/am/OplusOsenseKillAction;->TOTAL_MEM_GB:I

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->getMinTotalMemAllowQB()I

    move-result v1

    if-lt v0, v1, :cond_5d

    .line 641
    const-string/jumbo v0, "qbmode"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_5d

    .line 642
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$LowMemQbKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$LowMemQbKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0

    .line 644
    :cond_5d
    new-instance v0, Lcom/android/server/am/OplusOsenseKillAction$LowMemKillContext;

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v0, p1, p0, v1}, Lcom/android/server/am/OplusOsenseKillAction$LowMemKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    return-object v0
.end method

.method private getKillContextType(Ljava/lang/String;Ljava/lang/String;)I
    .registers 5
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "scene"    # Ljava/lang/String;

    .line 611
    const/4 v0, 0x1

    .line 612
    .local v0, "contextType":I
    if-eqz p2, :cond_d

    const-string v1, "BgLimit-Level-Thermal"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_d

    .line 613
    const/4 v0, 0x5

    goto :goto_36

    .line 614
    :cond_d
    if-eqz p2, :cond_19

    const-string v1, "BgLimit"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_19

    .line 615
    const/4 v0, 0x4

    goto :goto_36

    .line 616
    :cond_19
    const-string v1, "NirvanaLowFree"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_23

    .line 617
    const/4 v0, 0x3

    goto :goto_36

    .line 618
    :cond_23
    const-string v1, "CamLowFree"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    .line 619
    const/4 v0, 0x6

    goto :goto_36

    .line 620
    :cond_2d
    const-string v1, "GameLowFree"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_36

    .line 621
    const/4 v0, 0x7

    .line 623
    :cond_36
    :goto_36
    return v0
.end method

.method private getNonUiCheckSkipReason(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;)Ljava/lang/String;
    .registers 5
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1227
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isIsolated()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1228
    const-string/jumbo v0, "isolated-proc"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1230
    :cond_c
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasActivitiesOrRecentTasks()Z

    move-result v0

    if-nez v0, :cond_8c

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasShownUi()Z

    move-result v0

    if-eqz v0, :cond_19

    goto :goto_8c

    .line 1233
    :cond_19
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->providerHasClientActivities()Z

    move-result v0

    if-eqz v0, :cond_25

    .line 1234
    const-string/jumbo v0, "has-act-provider-client"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1236
    :cond_25
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isProtectProcess()Z

    move-result v0

    if-eqz v0, :cond_31

    .line 1237
    const-string/jumbo v0, "protected-proc"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1239
    :cond_31
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->getCurProcState()I

    move-result v0

    const/4 v1, 0x3

    if-gt v0, v1, :cond_43

    .line 1240
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->getCurProcState()I

    move-result v0

    invoke-static {v0}, Landroid/app/ActivityManager;->procStateToString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1242
    :cond_43
    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Lcom/android/server/am/ProcessInfo;->hasProviderClient(Z)Z

    move-result v1

    if-nez v1, :cond_87

    invoke-virtual {p2, v0}, Lcom/android/server/am/ProcessInfo;->hasServiceClient(Z)Z

    move-result v0

    if-eqz v0, :cond_51

    goto :goto_87

    .line 1245
    :cond_51
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isWhiteListedForService()Z

    move-result v0

    if-eqz v0, :cond_5d

    .line 1246
    const-string/jumbo v0, "white-listed-service"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1248
    :cond_5d
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isAudioPlayRecordProcess()Z

    move-result v0

    if-eqz v0, :cond_68

    .line 1249
    const-string v0, "audio-play-process-record"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1252
    :cond_68
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->numberOfRunningServices()I

    move-result v0

    if-lez v0, :cond_85

    .line 1253
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->allowRestart()Z

    move-result v0

    if-eqz v0, :cond_7a

    .line 1254
    const-string/jumbo v0, "svc-allow-restart"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1256
    :cond_7a
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isCchProtectProcess()Z

    move-result v0

    if-eqz v0, :cond_85

    .line 1257
    const-string v0, "cch-protect-process"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1260
    :cond_85
    const/4 v0, 0x0

    return-object v0

    .line 1243
    :cond_87
    :goto_87
    const-string v0, "depend-by-other"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1231
    :cond_8c
    :goto_8c
    const-string/jumbo v0, "shown-ui"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0
.end method

.method private getNonUiCheckSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Z)Ljava/lang/String;
    .registers 7
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;
    .param p3, "serviceBumpUnFzRestricted"    # Z

    .line 1179
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1180
    const-string/jumbo v0, "non-ui-app"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1183
    :cond_c
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->getThresholdForNonUiCheck()I

    move-result v1

    if-gt v0, v1, :cond_33

    .line 1184
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "recent-used-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1187
    :cond_33
    iget-boolean v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isUrgency:Z

    if-nez v0, :cond_52

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->uiHoggingCpu()Z

    move-result v0

    if-eqz v0, :cond_3e

    goto :goto_52

    .line 1191
    :cond_3e
    if-nez p3, :cond_46

    .line 1192
    const-string/jumbo v0, "svc-bump-unfz-not-restricted"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1194
    :cond_46
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_86

    .line 1195
    const-string/jumbo v0, "not-fz-stable"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1188
    :cond_52
    :goto_52
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "do not check fz for "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memCritical:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "KillAction"

    invoke-static {v1, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1198
    :cond_86
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isProtectPkg()Z

    move-result v0

    if-eqz v0, :cond_92

    .line 1199
    const-string/jumbo v0, "protect-pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1201
    :cond_92
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isRevivalSlotPkg()Z

    move-result v0

    if-eqz v0, :cond_9e

    .line 1202
    const-string/jumbo v0, "revival_slot_pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1204
    :cond_9e
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isCchWhiteListPkg()Z

    move-result v0

    if-eqz v0, :cond_a9

    .line 1205
    const-string v0, "cch-white-list-pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1207
    :cond_a9
    invoke-direct {p0, p1, p2}, Lcom/android/server/am/OplusOsenseKillAction;->getImportantAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Ljava/lang/String;

    move-result-object v0

    .line 1208
    .local v0, "impStatus":Ljava/lang/String;
    if-eqz v0, :cond_b2

    .line 1209
    iput-object v0, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1211
    :cond_b2
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->isOnDeviceIdleList()Z

    move-result v1

    if-eqz v1, :cond_be

    .line 1213
    const-string/jumbo v1, "idle-whitelist"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1215
    :cond_be
    const-string v1, "OnePlus"

    sget-object v2, Lcom/android/server/am/OplusOsenseKillAction;->BRAND:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e6

    const-string v1, "domestic"

    sget-object v2, Lcom/android/server/am/OplusOsenseKillAction;->AREA:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e6

    sget v1, Lcom/android/server/am/OplusOsenseKillAction;->TOTAL_MEM_GB:I

    const/16 v2, 0x10

    if-lt v1, v2, :cond_e6

    .line 1217
    iget-object v1, p2, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-virtual {p1, v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isInHeatGamePkgList(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e6

    .line 1218
    const-string/jumbo v1, "game-package"

    iput-object v1, p2, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    return-object v1

    .line 1221
    :cond_e6
    const/4 v1, 0x0

    return-object v1
.end method

.method private getProviderClient(Lcom/android/server/am/ProcessRecord;)Ljava/util/Set;
    .registers 9
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/ProcessRecord;",
            ")",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessRecord;",
            ">;"
        }
    .end annotation

    .line 1910
    new-instance v0, Landroid/util/ArraySet;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Landroid/util/ArraySet;-><init>(I)V

    .line 1911
    .local v0, "clients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    iget-object v1, p1, Lcom/android/server/am/ProcessRecord;->mProviders:Lcom/android/server/am/ProcessProviderRecord;

    .line 1912
    .local v1, "ppr":Lcom/android/server/am/ProcessProviderRecord;
    invoke-virtual {v1}, Lcom/android/server/am/ProcessProviderRecord;->numberOfProviders()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .local v2, "pi":I
    :goto_e
    if-ltz v2, :cond_33

    .line 1913
    invoke-virtual {v1, v2}, Lcom/android/server/am/ProcessProviderRecord;->getProviderAt(I)Lcom/android/server/am/ContentProviderRecord;

    move-result-object v3

    .line 1914
    .local v3, "cpr":Lcom/android/server/am/ContentProviderRecord;
    iget-object v4, v3, Lcom/android/server/am/ContentProviderRecord;->connections:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    .local v4, "ci":I
    :goto_1c
    if-ltz v4, :cond_30

    .line 1915
    iget-object v5, v3, Lcom/android/server/am/ContentProviderRecord;->connections:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ContentProviderConnection;

    .line 1916
    .local v5, "conn":Lcom/android/server/am/ContentProviderConnection;
    iget-object v6, v5, Lcom/android/server/am/ContentProviderConnection;->client:Lcom/android/server/am/ProcessRecord;

    .line 1917
    .local v6, "client":Lcom/android/server/am/ProcessRecord;
    if-eq v6, p1, :cond_2d

    .line 1918
    invoke-interface {v0, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1914
    .end local v5    # "conn":Lcom/android/server/am/ContentProviderConnection;
    .end local v6    # "client":Lcom/android/server/am/ProcessRecord;
    :cond_2d
    add-int/lit8 v4, v4, -0x1

    goto :goto_1c

    .line 1912
    .end local v3    # "cpr":Lcom/android/server/am/ContentProviderRecord;
    .end local v4    # "ci":I
    :cond_30
    add-int/lit8 v2, v2, -0x1

    goto :goto_e

    .line 1922
    .end local v2    # "pi":I
    :cond_33
    return-object v0
.end method

.method private getProviderServer(Lcom/android/server/am/ProcessRecord;)Ljava/util/List;
    .registers 7
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/ProcessRecord;",
            ")",
            "Ljava/util/List<",
            "Lcom/android/server/am/ProcessRecord;",
            ">;"
        }
    .end annotation

    .line 1926
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1927
    .local v0, "serverList":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    iget-object v1, p1, Lcom/android/server/am/ProcessRecord;->mProviders:Lcom/android/server/am/ProcessProviderRecord;

    .line 1928
    .local v1, "ppr":Lcom/android/server/am/ProcessProviderRecord;
    invoke-virtual {v1}, Lcom/android/server/am/ProcessProviderRecord;->numberOfProviderConnections()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .local v2, "i":I
    :goto_d
    if-ltz v2, :cond_22

    .line 1929
    invoke-virtual {v1, v2}, Lcom/android/server/am/ProcessProviderRecord;->getProviderConnectionAt(I)Lcom/android/server/am/ContentProviderConnection;

    move-result-object v3

    .line 1930
    .local v3, "cpc":Lcom/android/server/am/ContentProviderConnection;
    iget-object v4, v3, Lcom/android/server/am/ContentProviderConnection;->provider:Lcom/android/server/am/ContentProviderRecord;

    iget-object v4, v4, Lcom/android/server/am/ContentProviderRecord;->proc:Lcom/android/server/am/ProcessRecord;

    .line 1931
    .local v4, "provider":Lcom/android/server/am/ProcessRecord;
    if-eqz v4, :cond_1f

    if-ne v4, p1, :cond_1c

    .line 1932
    goto :goto_1f

    .line 1934
    :cond_1c
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1928
    .end local v3    # "cpc":Lcom/android/server/am/ContentProviderConnection;
    .end local v4    # "provider":Lcom/android/server/am/ProcessRecord;
    :cond_1f
    :goto_1f
    add-int/lit8 v2, v2, -0x1

    goto :goto_d

    .line 1936
    .end local v2    # "i":I
    :cond_22
    return-object v0
.end method

.method private getServiceClient(Lcom/android/server/am/ProcessRecord;)Ljava/util/Set;
    .registers 12
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/ProcessRecord;",
            ")",
            "Ljava/util/Set<",
            "Lcom/android/server/am/ProcessRecord;",
            ">;"
        }
    .end annotation

    .line 1869
    new-instance v0, Landroid/util/ArraySet;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Landroid/util/ArraySet;-><init>(I)V

    .line 1870
    .local v0, "clients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    iget-object v1, p1, Lcom/android/server/am/ProcessRecord;->mServices:Lcom/android/server/am/ProcessServiceRecord;

    .line 1871
    .local v1, "psr":Lcom/android/server/am/ProcessServiceRecord;
    invoke-virtual {v1}, Lcom/android/server/am/ProcessServiceRecord;->numberOfRunningServices()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .local v2, "is":I
    :goto_e
    if-ltz v2, :cond_49

    .line 1872
    invoke-virtual {v1, v2}, Lcom/android/server/am/ProcessServiceRecord;->getRunningServiceAt(I)Lcom/android/server/am/ServiceRecord;

    move-result-object v3

    .line 1873
    .local v3, "s":Lcom/android/server/am/ServiceRecord;
    invoke-virtual {v3}, Lcom/android/server/am/ServiceRecord;->getConnections()Landroid/util/ArrayMap;

    move-result-object v4

    .line 1874
    .local v4, "serviceConnections":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Landroid/os/IBinder;Ljava/util/ArrayList<Lcom/android/server/am/ConnectionRecord;>;>;"
    invoke-virtual {v4}, Landroid/util/ArrayMap;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    .local v5, "conni":I
    :goto_1e
    if-ltz v5, :cond_46

    .line 1875
    invoke-virtual {v4, v5}, Landroid/util/ArrayMap;->valueAt(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/ArrayList;

    .line 1876
    .local v6, "clist":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ConnectionRecord;>;"
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_27
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_43

    .line 1877
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ConnectionRecord;

    .line 1878
    .local v8, "cr":Lcom/android/server/am/ConnectionRecord;
    iget-object v9, v8, Lcom/android/server/am/ConnectionRecord;->binding:Lcom/android/server/am/AppBindRecord;

    iget-object v9, v9, Lcom/android/server/am/AppBindRecord;->client:Lcom/android/server/am/ProcessRecord;

    if-eq v9, p1, :cond_40

    .line 1879
    iget-object v9, v8, Lcom/android/server/am/ConnectionRecord;->binding:Lcom/android/server/am/AppBindRecord;

    iget-object v9, v9, Lcom/android/server/am/AppBindRecord;->client:Lcom/android/server/am/ProcessRecord;

    invoke-interface {v0, v9}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1876
    .end local v8    # "cr":Lcom/android/server/am/ConnectionRecord;
    :cond_40
    add-int/lit8 v7, v7, 0x1

    goto :goto_27

    .line 1874
    .end local v6    # "clist":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ConnectionRecord;>;"
    .end local v7    # "i":I
    :cond_43
    add-int/lit8 v5, v5, -0x1

    goto :goto_1e

    .line 1871
    .end local v3    # "s":Lcom/android/server/am/ServiceRecord;
    .end local v4    # "serviceConnections":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Landroid/os/IBinder;Ljava/util/ArrayList<Lcom/android/server/am/ConnectionRecord;>;>;"
    .end local v5    # "conni":I
    :cond_46
    add-int/lit8 v2, v2, -0x1

    goto :goto_e

    .line 1884
    .end local v2    # "is":I
    :cond_49
    return-object v0
.end method

.method private getServiceServer(Lcom/android/server/am/ProcessRecord;Lcom/android/server/am/ProcessInfo;)Ljava/util/List;
    .registers 12
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/ProcessRecord;",
            "Lcom/android/server/am/ProcessInfo;",
            ")",
            "Ljava/util/List<",
            "Lcom/android/server/am/ProcessRecord;",
            ">;"
        }
    .end annotation

    .line 1940
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1941
    .local v0, "serverList":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    iget-object v1, p1, Lcom/android/server/am/ProcessRecord;->mServices:Lcom/android/server/am/ProcessServiceRecord;

    .line 1942
    .local v1, "psr":Lcom/android/server/am/ProcessServiceRecord;
    invoke-virtual {v1}, Lcom/android/server/am/ProcessServiceRecord;->numberOfConnections()I

    move-result v2

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    .local v2, "i":I
    :goto_d
    if-ltz v2, :cond_5e

    .line 1943
    invoke-virtual {v1, v2}, Lcom/android/server/am/ProcessServiceRecord;->getConnectionAt(I)Lcom/android/server/am/ConnectionRecord;

    move-result-object v4

    .line 1944
    .local v4, "cr":Lcom/android/server/am/ConnectionRecord;
    invoke-virtual {v4}, Lcom/android/server/am/ConnectionRecord;->getFlags()J

    move-result-wide v5

    const-wide/16 v7, 0x2

    and-long/2addr v5, v7

    const-wide/16 v7, 0x0

    cmp-long v5, v5, v7

    if-eqz v5, :cond_27

    .line 1945
    iget-object v5, v4, Lcom/android/server/am/ConnectionRecord;->binding:Lcom/android/server/am/AppBindRecord;

    iget-object v5, v5, Lcom/android/server/am/AppBindRecord;->service:Lcom/android/server/am/ServiceRecord;

    iget-object v5, v5, Lcom/android/server/am/ServiceRecord;->isolationHostProc:Lcom/android/server/am/ProcessRecord;

    goto :goto_2d

    :cond_27
    iget-object v5, v4, Lcom/android/server/am/ConnectionRecord;->binding:Lcom/android/server/am/AppBindRecord;

    iget-object v5, v5, Lcom/android/server/am/AppBindRecord;->service:Lcom/android/server/am/ServiceRecord;

    iget-object v5, v5, Lcom/android/server/am/ServiceRecord;->app:Lcom/android/server/am/ProcessRecord;

    .line 1946
    .local v5, "service":Lcom/android/server/am/ProcessRecord;
    :goto_2d
    if-eqz v5, :cond_5b

    if-ne v5, p1, :cond_32

    .line 1947
    goto :goto_5b

    .line 1949
    :cond_32
    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1950
    invoke-virtual {v5}, Lcom/android/server/am/ProcessRecord;->isPersistent()Z

    move-result v6

    if-eqz v6, :cond_5b

    const-string v6, "com.android.systemui"

    iget-object v7, v5, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5b

    iget-object v6, v4, Lcom/android/server/am/ConnectionRecord;->binding:Lcom/android/server/am/AppBindRecord;

    iget-object v6, v6, Lcom/android/server/am/AppBindRecord;->service:Lcom/android/server/am/ServiceRecord;

    .line 1952
    invoke-virtual {v6}, Lcom/android/server/am/ServiceRecord;->getComponentName()Landroid/content/ComponentName;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v6

    .line 1951
    const-string v7, "com.oplus.flashback.service.FlashViewsService"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5b

    .line 1953
    iput-boolean v3, p2, Lcom/android/server/am/ProcessInfo;->mFlashBackClient:Z

    .line 1942
    .end local v4    # "cr":Lcom/android/server/am/ConnectionRecord;
    .end local v5    # "service":Lcom/android/server/am/ProcessRecord;
    :cond_5b
    :goto_5b
    add-int/lit8 v2, v2, -0x1

    goto :goto_d

    .line 1956
    .end local v2    # "i":I
    :cond_5e
    return-object v0
.end method

.method private getSkipReasonForCheckOomAdj(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;J)Ljava/lang/String;
    .registers 7
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .param p3, "start"    # J

    .line 1068
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isIsolated()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1069
    const-string/jumbo v0, "isolated-proc"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1071
    :cond_c
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasActivitiesOrRecentTasks()Z

    move-result v0

    if-nez v0, :cond_dc

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hasShownUi()Z

    move-result v0

    if-eqz v0, :cond_1a

    goto/16 :goto_dc

    .line 1074
    :cond_1a
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->providerHasClientActivities()Z

    move-result v0

    if-eqz v0, :cond_26

    .line 1075
    const-string/jumbo v0, "has-act-pr-client"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1077
    :cond_26
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isProtectProcess()Z

    move-result v0

    if-eqz v0, :cond_32

    .line 1078
    const-string/jumbo v0, "protected-proc"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1080
    :cond_32
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v0

    if-nez v0, :cond_44

    invoke-direct {p0, p1, p3, p4, p2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z

    move-result v0

    if-eqz v0, :cond_44

    .line 1081
    const-string/jumbo v0, "treat-like-active"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1083
    :cond_44
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isWhiteListedForService()Z

    move-result v0

    if-eqz v0, :cond_50

    .line 1084
    const-string/jumbo v0, "white-listed-service"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1086
    :cond_50
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isAudioPlayRecordProcess()Z

    move-result v0

    if-eqz v0, :cond_5b

    .line 1087
    const-string v0, "audio-play-process-record"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1090
    :cond_5b
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->numberOfRunningServices()I

    move-result v0

    if-lez v0, :cond_7e

    .line 1091
    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-boolean v0, v0, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-eqz v0, :cond_73

    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->allowRestart()Z

    move-result v0

    if-eqz v0, :cond_73

    .line 1092
    const-string/jumbo v0, "sys-svc-allow-restart"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1094
    :cond_73
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->isCchProtectProcess()Z

    move-result v0

    if-eqz v0, :cond_7e

    .line 1095
    const-string v0, "cch-protect-process"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1098
    :cond_7e
    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v0

    if-nez v0, :cond_b1

    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    .line 1099
    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->getThresholdForCchEmptyCheck()I

    move-result v1

    if-gt v0, v1, :cond_b1

    .line 1100
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "recent-used-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v1}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1102
    :cond_b1
    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->isCchWhiteListPkg()Z

    move-result v0

    if-eqz v0, :cond_be

    .line 1103
    const-string v0, "cch-white-list-pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1105
    :cond_be
    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->isProtectPkg()Z

    move-result v0

    if-eqz v0, :cond_cc

    .line 1106
    const-string/jumbo v0, "protect-pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1108
    :cond_cc
    iget-object v0, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->isRevivalSlotPkg()Z

    move-result v0

    if-eqz v0, :cond_da

    .line 1109
    const-string/jumbo v0, "revival_slot_pkg"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0

    .line 1111
    :cond_da
    const/4 v0, 0x0

    return-object v0

    .line 1072
    :cond_dc
    :goto_dc
    const-string/jumbo v0, "shown-ui"

    iput-object v0, p2, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    return-object v0
.end method

.method private getTaskRecentIdx(Ljava/util/Map;Lcom/android/server/am/ProcessGroup;)I
    .registers 6
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;>;",
            "Lcom/android/server/am/ProcessGroup;",
            ")I"
        }
    .end annotation

    .line 3407
    .local p1, "taskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    iget v0, p2, Lcom/android/server/am/ProcessGroup;->mUserId:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    .line 3408
    .local v0, "userTaskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;"
    const v1, 0x7fffffff

    if-nez v0, :cond_12

    .line 3409
    return v1

    .line 3411
    :cond_12
    iget-object v2, p2, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 3412
    .local v2, "idx":Ljava/lang/Integer;
    if-nez v2, :cond_1d

    goto :goto_21

    :cond_1d
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v1

    :goto_21
    return v1
.end method

.method private groupApp(Ljava/io/PrintWriter;)V
    .registers 13
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3437
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 3438
    .local v0, "extra":Landroid/os/Bundle;
    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v2

    .line 3439
    .local v2, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iput-wide v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    .line 3440
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iput-wide v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startCurrent:J

    .line 3441
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3442
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3443
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v3

    .line 3444
    :try_start_22
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v5, v5, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v5}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v2, v4}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 3445
    monitor-exit v3
    :try_end_33
    .catchall {:try_start_22 .. :try_end_33} :catchall_1cc

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3446
    iget-object v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    new-array v1, v1, [Lcom/android/server/am/ProcessGroup;

    invoke-interface {v3, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lcom/android/server/am/ProcessGroup;

    .line 3447
    .local v1, "fzMemMru":[Lcom/android/server/am/ProcessGroup;
    sget-object v3, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_FZ_MEM:Ljava/util/Comparator;

    invoke-direct {p0, v1, v3}, Lcom/android/server/am/OplusOsenseKillAction;->resortInactiveTaskApp([Lcom/android/server/am/ProcessGroup;Ljava/util/Comparator;)V

    .line 3449
    new-instance v3, Ljava/util/ArrayList;

    iget-object v4, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 3450
    .local v3, "uiFzMemMru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    sget-object v4, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_UI_FZ_MEM:Ljava/util/Comparator;

    invoke-interface {v3, v4}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3452
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_52
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_69

    .line 3453
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    aget-object v6, v1, v4

    if-eq v5, v6, :cond_66

    .line 3454
    const-string v5, "MRU_SORT_BY_UI_FZ_MEM works incorrectly."

    invoke-virtual {p1, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3455
    return-void

    .line 3452
    :cond_66
    add-int/lit8 v4, v4, 0x1

    goto :goto_52

    .line 3458
    .end local v4    # "i":I
    :cond_69
    const-string v4, "###mru sort by lru###"

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3459
    const/4 v4, 0x0

    .restart local v4    # "i":I
    :goto_6f
    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_e4

    .line 3460
    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ProcessGroup;

    .line 3461
    .local v5, "group":Lcom/android/server/am/ProcessGroup;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "  #"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " fz="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3462
    const/4 v6, 0x0

    .local v6, "j":I
    :goto_b2
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_e1

    .line 3463
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 3464
    .local v7, "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "        "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-wide v9, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v7, v9, v10}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3462
    .end local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v6, v6, 0x1

    goto :goto_b2

    .line 3459
    .end local v5    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v6    # "j":I
    :cond_e1
    add-int/lit8 v4, v4, 0x1

    goto :goto_6f

    .line 3467
    .end local v4    # "i":I
    :cond_e4
    const-string v4, "###mru sort by fz mem###"

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3468
    const/4 v4, 0x0

    .restart local v4    # "i":I
    :goto_ea
    array-length v5, v1

    if-ge v4, v5, :cond_154

    .line 3469
    aget-object v5, v1, v4

    .line 3470
    .restart local v5    # "group":Lcom/android/server/am/ProcessGroup;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "  #"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " fz="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3471
    const/4 v6, 0x0

    .restart local v6    # "j":I
    :goto_122
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_151

    .line 3472
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 3473
    .restart local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "        "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-wide v9, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v7, v9, v10}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3471
    .end local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v6, v6, 0x1

    goto :goto_122

    .line 3468
    .end local v5    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v6    # "j":I
    :cond_151
    add-int/lit8 v4, v4, 0x1

    goto :goto_ea

    .line 3476
    .end local v4    # "i":I
    :cond_154
    const-string v4, "###mru sort by ui fz mem###"

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3477
    const/4 v4, 0x0

    .restart local v4    # "i":I
    :goto_15a
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_1cb

    .line 3478
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ProcessGroup;

    .line 3479
    .restart local v5    # "group":Lcom/android/server/am/ProcessGroup;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "  #"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " fz="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3480
    const/4 v6, 0x0

    .restart local v6    # "j":I
    :goto_199
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_1c8

    .line 3481
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 3482
    .restart local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "        "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-wide v9, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v7, v9, v10}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3480
    .end local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v6, v6, 0x1

    goto :goto_199

    .line 3477
    .end local v5    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v6    # "j":I
    :cond_1c8
    add-int/lit8 v4, v4, 0x1

    goto :goto_15a

    .line 3485
    .end local v4    # "i":I
    :cond_1cb
    return-void

    .line 3445
    .end local v1    # "fzMemMru":[Lcom/android/server/am/ProcessGroup;
    .end local v3    # "uiFzMemMru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    :catchall_1cc
    move-exception v1

    :try_start_1cd
    monitor-exit v3
    :try_end_1ce
    .catchall {:try_start_1cd .. :try_end_1ce} :catchall_1cc

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v1
.end method

.method private groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V
    .registers 20
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/server/am/OplusOsenseKillAction$KillContext;",
            "Ljava/util/List<",
            "Lcom/android/server/am/ProcessRecord;",
            ">;)V"
        }
    .end annotation

    .line 2626
    .local p2, "lru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 2628
    .local v3, "start":J
    const-string/jumbo v5, "setUpProcessGroup"

    const-wide/16 v6, 0x40

    invoke-static {v6, v7, v5}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2629
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    const/4 v8, 0x1

    sub-int/2addr v5, v8

    .local v5, "i":I
    :goto_18
    const-string v9, "KillAction"

    if-ltz v5, :cond_14d

    .line 2630
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/android/server/am/ProcessRecord;

    .line 2632
    .local v10, "app":Lcom/android/server/am/ProcessRecord;
    invoke-virtual {v10}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v11

    if-eqz v11, :cond_42

    .line 2633
    iget-object v9, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->dyingProcesses:Ljava/util/List;

    invoke-virtual {v10}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v11

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v9, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2634
    iget-wide v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->dyingPss:J

    iget-object v9, v10, Lcom/android/server/am/ProcessRecord;->mProfile:Lcom/android/server/am/ProcessProfileRecord;

    invoke-virtual {v9}, Lcom/android/server/am/ProcessProfileRecord;->getLastPss()J

    move-result-wide v13

    add-long/2addr v11, v13

    iput-wide v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->dyingPss:J

    .line 2635
    goto/16 :goto_149

    .line 2637
    :cond_42
    invoke-direct {v0, v10}, Lcom/android/server/am/OplusOsenseKillAction;->isInvalidProcessRecordLocked(Lcom/android/server/am/ProcessRecord;)Z

    move-result v11

    if-eqz v11, :cond_7d

    .line 2638
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v12, "find invalid process: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    iget-object v12, v10, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, ":"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v10}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v13

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    .line 2639
    invoke-virtual {v10}, Lcom/android/server/am/ProcessRecord;->getCurProcState()I

    move-result v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    .line 2638
    invoke-static {v9, v11}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2640
    goto/16 :goto_149

    .line 2642
    :cond_7d
    new-instance v9, Lcom/android/server/am/ProcessInfo;

    invoke-direct {v9, v1, v10, v5}, Lcom/android/server/am/ProcessInfo;-><init>(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessRecord;I)V

    .line 2643
    .local v9, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v12, v9, Lcom/android/server/am/ProcessInfo;->mPid:I

    invoke-virtual {v11, v12, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 2644
    iget-object v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v11, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2645
    iget-object v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    if-eqz v11, :cond_bd

    .line 2646
    iget-object v11, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    iget v12, v9, Lcom/android/server/am/ProcessInfo;->mPid:I

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v11, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/android/server/am/MemNodeItem;

    .line 2647
    .local v11, "memNodeItem":Lcom/android/server/am/MemNodeItem;
    if-eqz v11, :cond_bd

    .line 2648
    invoke-virtual {v11}, Lcom/android/server/am/MemNodeItem;->totalRssAnon()J

    move-result-wide v12

    const-wide/16 v14, 0x400

    div-long/2addr v12, v14

    iput-wide v12, v9, Lcom/android/server/am/ProcessInfo;->mAnonMemoryMB:J

    .line 2649
    invoke-virtual {v11}, Lcom/android/server/am/MemNodeItem;->getRss()I

    move-result v12

    div-int/lit16 v12, v12, 0x400

    int-to-long v12, v12

    iput-wide v12, v9, Lcom/android/server/am/ProcessInfo;->mRssMemoryMB:J

    .line 2650
    invoke-virtual {v11}, Lcom/android/server/am/MemNodeItem;->getSwap()I

    move-result v12

    div-int/lit16 v12, v12, 0x400

    int-to-long v12, v12

    iput-wide v12, v9, Lcom/android/server/am/ProcessInfo;->mSwapMemoryMB:J

    .line 2655
    .end local v11    # "memNodeItem":Lcom/android/server/am/MemNodeItem;
    :cond_bd
    invoke-static {v10}, Lcom/android/server/am/OplusOsenseKillAction;->getAppPackageName(Lcom/android/server/am/ProcessRecord;)Ljava/lang/String;

    move-result-object v11

    .line 2656
    .local v11, "pkgName":Ljava/lang/String;
    iget-object v12, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupMap:Lcom/android/internal/app/ProcessMap;

    iget v13, v10, Lcom/android/server/am/ProcessRecord;->userId:I

    invoke-virtual {v12, v11, v13}, Lcom/android/internal/app/ProcessMap;->get(Ljava/lang/String;I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/android/server/am/ProcessGroup;

    .line 2657
    .local v12, "group":Lcom/android/server/am/ProcessGroup;
    if-nez v12, :cond_116

    .line 2658
    new-instance v13, Lcom/android/server/am/ProcessGroup;

    iget v14, v10, Lcom/android/server/am/ProcessRecord;->userId:I

    iget-object v15, v10, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget v15, v15, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-direct {v13, v1, v11, v14, v15}, Lcom/android/server/am/ProcessGroup;-><init>(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/lang/String;II)V

    move-object v12, v13

    .line 2660
    iget-object v13, v10, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget v13, v13, Landroid/content/pm/ApplicationInfo;->flags:I

    and-int/lit16 v13, v13, 0x81

    if-nez v13, :cond_ee

    iget-object v13, v10, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget v13, v13, Landroid/content/pm/ApplicationInfo;->uid:I

    .line 2661
    invoke-static {v13}, Landroid/os/UserHandle;->isApp(I)Z

    move-result v13

    if-nez v13, :cond_ec

    goto :goto_ee

    :cond_ec
    const/4 v13, 0x0

    goto :goto_ef

    :cond_ee
    :goto_ee
    move v13, v8

    :goto_ef
    iput-boolean v13, v12, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    .line 2662
    iput v5, v12, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    .line 2663
    invoke-virtual {v1, v12}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->updateAndGetGroupStatus(Lcom/android/server/am/ProcessGroup;)Ljava/util/Set;

    move-result-object v13

    .line 2664
    .local v13, "statusTypeList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;"
    if-eqz v13, :cond_fe

    .line 2665
    iget-object v14, v12, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    invoke-interface {v14, v13}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 2667
    :cond_fe
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupMap:Lcom/android/internal/app/ProcessMap;

    iget v15, v10, Lcom/android/server/am/ProcessRecord;->userId:I

    invoke-virtual {v14, v11, v15, v12}, Lcom/android/internal/app/ProcessMap;->put(Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/Object;

    .line 2668
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v14, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2669
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->recentTaskIdxMap:Ljava/util/Map;

    if-eqz v14, :cond_116

    .line 2670
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->recentTaskIdxMap:Ljava/util/Map;

    invoke-direct {v0, v14, v12}, Lcom/android/server/am/OplusOsenseKillAction;->getTaskRecentIdx(Ljava/util/Map;Lcom/android/server/am/ProcessGroup;)I

    move-result v14

    iput v14, v12, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    .line 2673
    .end local v13    # "statusTypeList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;"
    :cond_116
    invoke-virtual {v12}, Lcom/android/server/am/ProcessGroup;->invalidTaskLru()Z

    move-result v13

    if-eqz v13, :cond_143

    invoke-virtual {v9}, Lcom/android/server/am/ProcessInfo;->hasActivities()Z

    move-result v13

    if-eqz v13, :cond_143

    .line 2674
    invoke-virtual {v9}, Lcom/android/server/am/ProcessInfo;->getCachedIsHomeProcess()Z

    move-result v13

    if-nez v13, :cond_143

    .line 2675
    invoke-static {}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getInstance()Lcom/android/server/oplus/osense/resource/AppStatusManager;

    move-result-object v13

    invoke-virtual {v13}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getDefaultLauncher()Ljava/lang/String;

    move-result-object v13

    iget-object v14, v12, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-virtual {v13, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_143

    .line 2676
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getNextTaskLruIdx()I

    move-result v13

    iput v13, v12, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    .line 2677
    iget v13, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curBgCount:I

    add-int/2addr v13, v8

    iput v13, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curBgCount:I

    .line 2680
    :cond_143
    invoke-virtual {v12, v9}, Lcom/android/server/am/ProcessGroup;->add(Lcom/android/server/am/ProcessInfo;)V

    .line 2681
    invoke-virtual {v9, v12}, Lcom/android/server/am/ProcessInfo;->setProcessGroup(Lcom/android/server/am/ProcessGroup;)V

    .line 2629
    .end local v9    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v10    # "app":Lcom/android/server/am/ProcessRecord;
    .end local v11    # "pkgName":Ljava/lang/String;
    .end local v12    # "group":Lcom/android/server/am/ProcessGroup;
    :goto_149
    add-int/lit8 v5, v5, -0x1

    goto/16 :goto_18

    .line 2683
    .end local v5    # "i":I
    :cond_14d
    invoke-static {v6, v7}, Landroid/os/Trace;->traceEnd(J)V

    .line 2684
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    .line 2687
    .local v10, "doneFirstLoop":J
    const-string/jumbo v5, "updateProcessInfoLocked"

    invoke-static {v6, v7, v5}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2688
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    sub-int/2addr v5, v8

    .restart local v5    # "i":I
    :goto_15f
    if-ltz v5, :cond_179

    .line 2689
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessRecord;

    .line 2690
    .local v8, "app":Lcom/android/server/am/ProcessRecord;
    iget-object v12, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    invoke-virtual {v8}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/android/server/am/ProcessInfo;

    .line 2691
    .local v12, "pi":Lcom/android/server/am/ProcessInfo;
    invoke-direct {v0, v1, v12, v8}, Lcom/android/server/am/OplusOsenseKillAction;->updateProcessInfoLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessRecord;)V

    .line 2688
    .end local v8    # "app":Lcom/android/server/am/ProcessRecord;
    .end local v12    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v5, v5, -0x1

    goto :goto_15f

    .line 2693
    .end local v5    # "i":I
    :cond_179
    invoke-static {v6, v7}, Landroid/os/Trace;->traceEnd(J)V

    .line 2694
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    .line 2697
    .local v5, "doneUpdateProcessInfo":J
    iget-object v7, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    .line 2698
    .local v7, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    :goto_186
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1a2

    .line 2699
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessGroup;

    .line 2700
    .local v8, "group":Lcom/android/server/am/ProcessGroup;
    iget v12, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    if-lez v12, :cond_199

    .line 2701
    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->updateAppCareList()V

    .line 2703
    :cond_199
    iget v12, v8, Lcom/android/server/am/ProcessGroup;->mMinProcState:I

    const/4 v13, 0x2

    if-ge v12, v13, :cond_1a1

    .line 2704
    invoke-interface {v7}, Ljava/util/Iterator;->remove()V

    .line 2706
    .end local v8    # "group":Lcom/android/server/am/ProcessGroup;
    :cond_1a1
    goto :goto_186

    .line 2707
    :cond_1a2
    iget-object v8, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    .line 2708
    .local v8, "processInfoIterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessInfo;>;"
    :goto_1a8
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_1e7

    .line 2709
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/android/server/am/ProcessInfo;

    .line 2710
    .restart local v12    # "pi":Lcom/android/server/am/ProcessInfo;
    invoke-virtual {v12}, Lcom/android/server/am/ProcessInfo;->isFullyUpdated()Z

    move-result v13

    if-eqz v13, :cond_1c0

    invoke-virtual {v12}, Lcom/android/server/am/ProcessInfo;->inValid()Z

    move-result v13

    if-eqz v13, :cond_1e6

    .line 2712
    :cond_1c0
    invoke-interface {v8}, Ljava/util/Iterator;->remove()V

    .line 2713
    iget-object v13, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v14, v12, Lcom/android/server/am/ProcessInfo;->mPid:I

    invoke-virtual {v13, v14}, Landroid/util/SparseArray;->remove(I)V

    .line 2715
    iget-object v13, v12, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v13, v12}, Lcom/android/server/am/ProcessGroup;->remove(Lcom/android/server/am/ProcessInfo;)V

    .line 2716
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v14, "find a poor pi: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v9, v13}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2718
    .end local v12    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_1e6
    goto :goto_1a8

    .line 2719
    :cond_1e7
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v12

    .line 2721
    .local v12, "doneIdleList":J
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    sget-object v15, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_CPU_HOGGING:Ljava/util/Comparator;

    invoke-interface {v14, v15}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 2723
    iget-object v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    sget-object v15, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_IMP:Ljava/util/Comparator;

    invoke-interface {v14, v15}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 2724
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v14

    sub-long/2addr v14, v3

    long-to-int v14, v14

    iput v14, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processGroupDurMs:I

    .line 2725
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v15, "group process done, total="

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    iget v15, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processGroupDurMs:I

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v14

    const-string/jumbo v15, "ms, firstLoop="

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    move-wide v15, v3

    .end local v3    # "start":J
    .local v15, "start":J
    sub-long v2, v10, v15

    invoke-virtual {v14, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "ms, updateProcessInfo="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sub-long v3, v5, v10

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "ms, idleList="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sub-long v3, v12, v5

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "ms, curBg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curBgCount:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2730
    return-void
.end method

.method private handleDumpAudioPlayProcessRecord(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 6
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3552
    invoke-static {}, Lcom/android/server/oplus/osense/resource/ResourceCallback;->getInstance()Lcom/android/server/oplus/osense/resource/ResourceCallback;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/oplus/osense/resource/ResourceCallback;->getAudioPlayProcessRecord()Landroid/util/ArraySet;

    move-result-object v0

    .line 3553
    .local v0, "pidSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/Integer;>;"
    const-string v1, "audio play process record:"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3554
    invoke-interface {v0}, Ljava/util/Set;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3555
    return-void
.end method

.method private handleDumpSvcRestart(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 12
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3540
    move v0, p3

    .line 3541
    .local v0, "opti":I
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v1

    .line 3542
    add-int/lit8 v2, v0, 0x1

    .end local v0    # "opti":I
    .local v2, "opti":I
    :try_start_9
    aget-object v0, p2, v0
    :try_end_b
    .catchall {:try_start_9 .. :try_end_b} :catchall_4d

    .line 3543
    .local v0, "processName":Ljava/lang/String;
    add-int/lit8 v3, v2, 0x1

    .end local v2    # "opti":I
    .local v3, "opti":I
    :try_start_d
    aget-object v2, p2, v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 3544
    .local v2, "uid":Ljava/lang/Integer;
    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v4, v0, v5}, Lcom/android/server/am/ProcessList;->getProcessRecordLocked(Ljava/lang/String;I)Lcom/android/server/am/ProcessRecord;

    move-result-object v4

    .line 3545
    .local v4, "app":Lcom/android/server/am/ProcessRecord;
    sget-object v5, Lcom/android/server/am/IOplusAppStartupManager;->DEFAULT:Lcom/android/server/am/IOplusAppStartupManager;

    invoke-static {v5}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/IOplusAppStartupManager;

    .line 3546
    invoke-interface {v5, v4}, Lcom/android/server/am/IOplusAppStartupManager;->isAllowRestartService(Lcom/android/server/am/ProcessRecord;)Z

    move-result v5

    .line 3547
    .local v5, "ret":Z
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "allow = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3548
    .end local v0    # "processName":Ljava/lang/String;
    .end local v2    # "uid":Ljava/lang/Integer;
    .end local v4    # "app":Lcom/android/server/am/ProcessRecord;
    .end local v5    # "ret":Z
    monitor-exit v1
    :try_end_46
    .catchall {:try_start_d .. :try_end_46} :catchall_4a

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3549
    return-void

    .line 3548
    :catchall_4a
    move-exception v0

    move v2, v3

    goto :goto_4e

    .end local v3    # "opti":I
    .local v2, "opti":I
    :catchall_4d
    move-exception v0

    :goto_4e
    :try_start_4e
    monitor-exit v1
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v0
.end method

.method private handleRealKill(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 13
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3175
    move v0, p3

    .line 3176
    .local v0, "opti":I
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 3177
    .local v1, "bundle":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 3178
    .local v2, "requestFromQbPolicy":Z
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 3179
    .local v3, "hoggingCpuPids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    :goto_c
    array-length v4, p2

    if-ge v0, v4, :cond_1c7

    .line 3180
    add-int/lit8 v4, v0, 0x1

    .end local v0    # "opti":I
    .local v4, "opti":I
    aget-object v0, p2, v0

    const-string v5, "="

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 3181
    .local v0, "kv":[Ljava/lang/String;
    array-length v5, v0

    const/4 v6, 0x2

    if-ne v5, v6, :cond_1a9

    .line 3184
    const/4 v5, 0x0

    aget-object v6, v0, v5

    const-string/jumbo v7, "purposeMemory"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v8, 0x1

    if-eqz v6, :cond_35

    .line 3185
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3186
    :cond_35
    aget-object v6, v0, v5

    const-string/jumbo v7, "purposeFreeMB"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4b

    .line 3187
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3188
    :cond_4b
    aget-object v6, v0, v5

    const-string v7, "appcareThreshold"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_60

    .line 3189
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3190
    :cond_60
    aget-object v6, v0, v5

    const-string/jumbo v7, "triggerUsedSwapPercent"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_76

    .line 3191
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3192
    :cond_76
    aget-object v6, v0, v5

    const-string/jumbo v7, "purposeUsedSwapPercent"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_8c

    .line 3193
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3194
    :cond_8c
    aget-object v6, v0, v5

    const-string/jumbo v7, "releaseSwapSize"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a2

    .line 3195
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3196
    :cond_a2
    aget-object v6, v0, v5

    const-string/jumbo v7, "swapAppcareThreshold"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_b8

    .line 3197
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3198
    :cond_b8
    aget-object v6, v0, v5

    const-string/jumbo v7, "type"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_ca

    .line 3199
    aget-object v5, v0, v8

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_188

    .line 3200
    :cond_ca
    aget-object v6, v0, v5

    const-string/jumbo v7, "scene"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_dc

    .line 3201
    aget-object v5, v0, v8

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_188

    .line 3202
    :cond_dc
    aget-object v6, v0, v5

    const-string/jumbo v7, "requestId"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_f2

    .line 3203
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto/16 :goto_188

    .line 3204
    :cond_f2
    aget-object v6, v0, v5

    const-string/jumbo v7, "requestFromQbPolicy"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_108

    .line 3205
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v2

    .line 3206
    invoke-virtual {v1, v7, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    goto/16 :goto_188

    .line 3207
    :cond_108
    aget-object v6, v0, v5

    const-string v7, "bootMode"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_120

    .line 3208
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Lcom/android/server/oplus/osense/feature/blo/OplusBloManager$SceneType;->getScene(I)Lcom/android/server/oplus/osense/feature/blo/OplusBloManager$SceneType;

    move-result-object v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putObject(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_188

    .line 3209
    :cond_120
    aget-object v6, v0, v5

    const-string/jumbo v7, "resumePkgName"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_131

    .line 3210
    aget-object v5, v0, v8

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_188

    .line 3211
    :cond_131
    aget-object v6, v0, v5

    const-string/jumbo v7, "resumeIndex"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_146

    .line 3212
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto :goto_188

    .line 3213
    :cond_146
    aget-object v6, v0, v5

    const-string/jumbo v7, "resumeRounds"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_15b

    .line 3214
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto :goto_188

    .line 3215
    :cond_15b
    aget-object v6, v0, v5

    const-string/jumbo v7, "qbmode"

    invoke-virtual {v7, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_170

    .line 3216
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v5

    invoke-virtual {v1, v7, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_188

    .line 3217
    :cond_170
    const-string/jumbo v6, "hoggingCpuPid"

    aget-object v5, v0, v5

    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_18b

    .line 3218
    aget-object v5, v0, v8

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3222
    .end local v0    # "kv":[Ljava/lang/String;
    :goto_188
    move v0, v4

    goto/16 :goto_c

    .line 3220
    .restart local v0    # "kv":[Ljava/lang/String;
    :cond_18b
    new-instance v5, Ljava/lang/IllegalArgumentException;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "unknown args: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    add-int/lit8 v7, v4, -0x1

    aget-object v7, p2, v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 3182
    :cond_1a9
    new-instance v5, Ljava/lang/IllegalArgumentException;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "format error: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    add-int/lit8 v7, v4, -0x1

    aget-object v7, p2, v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 3223
    .end local v4    # "opti":I
    .local v0, "opti":I
    :cond_1c7
    const-string/jumbo v4, "thirdAppPidList"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 3224
    if-eqz v2, :cond_1d3

    .line 3225
    invoke-virtual {p0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->executeForQB(Landroid/os/Bundle;)Z

    goto :goto_1dc

    .line 3227
    :cond_1d3
    invoke-static {}, Lcom/android/server/oplus/osense/policy/PolicyManager;->getInstance()Lcom/android/server/oplus/osense/policy/PolicyManager;

    move-result-object v4

    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;->POLICY_CLEAN:Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;

    invoke-virtual {v4, v5, v1}, Lcom/android/server/oplus/osense/policy/PolicyManager;->notifyDataToPolicy(Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;Landroid/os/Bundle;)V

    .line 3229
    :goto_1dc
    return-void
.end method

.method private handleSpecialRequest(ILandroid/os/Bundle;)Z
    .registers 8
    .param p1, "contextType"    # I
    .param p2, "extra"    # Landroid/os/Bundle;

    .line 593
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mBloFeatureLevel:I

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne v0, v2, :cond_23

    iget-boolean v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    if-nez v0, :cond_e

    iget-boolean v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    if-eqz v0, :cond_23

    .line 594
    :cond_e
    if-ne p1, v1, :cond_22

    .line 595
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    new-instance v3, Lcom/android/server/am/OplusOsenseKillAction$BloKillContext;

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-direct {v3, p2, p0, v4}, Lcom/android/server/am/OplusOsenseKillAction$BloKillContext;-><init>(Landroid/os/Bundle;Lcom/android/server/am/OplusOsenseKillAction;Lcom/android/server/am/ConfigUtil;)V

    invoke-virtual {v0, v2, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 597
    .local v0, "msg":Landroid/os/Message;
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    invoke-virtual {v2, v0}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->sendMessage(Landroid/os/Message;)Z

    .line 599
    .end local v0    # "msg":Landroid/os/Message;
    :cond_22
    return v1

    .line 601
    :cond_23
    const/4 v0, 0x4

    if-eq p1, v0, :cond_2c

    const/4 v0, 0x5

    if-ne p1, v0, :cond_2a

    goto :goto_2c

    .line 607
    :cond_2a
    const/4 v0, 0x0

    return v0

    .line 603
    :cond_2c
    :goto_2c
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    invoke-direct {p0, p2, p1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 604
    .restart local v0    # "msg":Landroid/os/Message;
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    invoke-virtual {v2, v0}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->sendMessage(Landroid/os/Message;)Z

    .line 605
    return v1
.end method

.method private hasStartedService(Lcom/android/server/am/ProcessRecord;)Z
    .registers 7
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;

    .line 1899
    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mServices:Lcom/android/server/am/ProcessServiceRecord;

    .line 1900
    .local v0, "psr":Lcom/android/server/am/ProcessServiceRecord;
    invoke-virtual {v0}, Lcom/android/server/am/ProcessServiceRecord;->numberOfRunningServices()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .local v1, "is":I
    :goto_8
    if-ltz v1, :cond_16

    .line 1901
    invoke-virtual {v0, v1}, Lcom/android/server/am/ProcessServiceRecord;->getRunningServiceAt(I)Lcom/android/server/am/ServiceRecord;

    move-result-object v3

    .line 1902
    .local v3, "s":Lcom/android/server/am/ServiceRecord;
    iget-boolean v4, v3, Lcom/android/server/am/ServiceRecord;->startRequested:Z

    if-eqz v4, :cond_13

    .line 1903
    return v2

    .line 1900
    .end local v3    # "s":Lcom/android/server/am/ServiceRecord;
    :cond_13
    add-int/lit8 v1, v1, -0x1

    goto :goto_8

    .line 1906
    .end local v1    # "is":I
    :cond_16
    const/4 v1, 0x0

    return v1
.end method

.method private incInvalidKill()V
    .registers 9

    .line 817
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 818
    .local v0, "now":J
    iget-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    const-wide/16 v4, -0x1

    cmp-long v2, v2, v4

    const/4 v3, 0x1

    if-eqz v2, :cond_24

    .line 819
    iget-wide v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    sub-long v4, v0, v4

    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v2}, Lcom/android/server/am/ConfigUtil;->getInvalidKillThres()I

    move-result v2

    int-to-long v6, v2

    cmp-long v2, v4, v6

    if-gtz v2, :cond_24

    .line 820
    iget v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    add-int/2addr v2, v3

    iput v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    .line 821
    iput-wide v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    .line 822
    return-void

    .line 825
    :cond_24
    iput-wide v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    .line 826
    iput v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    .line 827
    return-void
.end method

.method private initKillContext(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 16
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 695
    iget-object v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->extra:Landroid/os/Bundle;

    .line 696
    .local v0, "extra":Landroid/os/Bundle;
    const-string/jumbo v1, "requestId"

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->requestId:I

    .line 697
    const-string/jumbo v1, "scene"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->scene:Ljava/lang/String;

    .line 698
    const-string/jumbo v1, "type"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->type:Ljava/lang/String;

    .line 699
    iget-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->type:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->checkIfCachedCleanOnly(Ljava/lang/String;)Z

    move-result v1

    iput-boolean v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanOnly:Z

    .line 702
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iput-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    .line 703
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iput-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startCurrent:J

    .line 704
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iput-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startElapsed:J

    .line 705
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getMemInfoAvailMB()J

    move-result-wide v3

    iput-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startAvailMB:J

    .line 706
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getMemInfoFreeMB()J

    move-result-wide v3

    iput-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startFreeMB:J

    .line 707
    invoke-static {}, Landroid/app/ActivityManager;->getCurrentUser()I

    move-result v1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    .line 708
    invoke-static {}, Lcom/oplus/content/OplusFeatureConfigManager;->getInstance()Lcom/oplus/content/OplusFeatureConfigManager;

    move-result-object v1

    const-string/jumbo v3, "oplus.software.hans_restriction"

    invoke-virtual {v1, v3}, Lcom/oplus/content/OplusFeatureConfigManager;->hasFeature(Ljava/lang/String;)Z

    move-result v1

    iput-boolean v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isChinaModel:Z

    .line 710
    sget-boolean v1, Lcom/android/server/am/OplusOsenseKillAction;->sIsAgingVersion:Z

    iput-boolean v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->agingVersion:Z

    .line 711
    const/4 v1, 0x1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 712
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->continuouslyInvalidKill(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)Z

    move-result v3

    iput-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->continuouslyInvalidKill:Z

    .line 713
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startAvailMB:J

    iget-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v5}, Lcom/android/server/am/ConfigUtil;->getCriticalMemThres()I

    move-result v5

    int-to-long v5, v5

    cmp-long v3, v3, v5

    const/4 v4, 0x0

    if-gez v3, :cond_74

    move v3, v1

    goto :goto_75

    :cond_74
    move v3, v4

    :goto_75
    iput-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memCritical:Z

    .line 714
    iget-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    if-eqz v3, :cond_85

    iget-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->continuouslyInvalidKill:Z

    if-nez v3, :cond_83

    iget-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memCritical:Z

    if-eqz v3, :cond_85

    :cond_83
    move v3, v1

    goto :goto_86

    :cond_85
    move v3, v4

    :goto_86
    iput-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isUrgency:Z

    .line 716
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isBlastAndCanHandle()Z

    move-result v3

    iput-boolean v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->handlingBlast:Z

    .line 719
    const-string/jumbo v3, "thirdAppPidList"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    .line 720
    .local v3, "pidList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    if-eqz v3, :cond_a2

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_a2

    .line 721
    iget-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cpuHoggingPids:Ljava/util/Set;

    invoke-interface {v5, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 723
    :cond_a2
    const-string/jumbo v5, "sysAppPidList"

    invoke-virtual {v0, v5}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    .line 724
    if-eqz v3, :cond_b6

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_b6

    .line 725
    iget-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cpuHoggingPids:Ljava/util/Set;

    invoke-interface {v5, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 728
    :cond_b6
    const-string/jumbo v5, "minBgCount"

    invoke-virtual {v0, v5, v4}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    iput v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    .line 729
    const-string v5, "bgActivityAppCount"

    invoke-virtual {v0, v5, v4}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    iput v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->bgActivityAppCount:I

    .line 730
    const-string/jumbo v5, "maxAppCare"

    const/16 v6, 0x64

    invoke-virtual {v0, v5, v6}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    iput v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->maxAppCare:I

    .line 733
    const-string/jumbo v5, "purposeMemory"

    invoke-virtual {v0, v5, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    iput v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    .line 734
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    if-lez v5, :cond_ed

    .line 735
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    int-to-long v5, v5

    iget-wide v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startAvailMB:J

    sub-long/2addr v5, v7

    .line 736
    const-wide/16 v7, 0x0

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    iput-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseAnonRssMB:J

    .line 740
    :cond_ed
    const-string/jumbo v5, "purposeFreeMB"

    invoke-virtual {v0, v5, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    iput v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeFreeMB:I

    .line 741
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeFreeMB:I

    if-lez v5, :cond_108

    .line 742
    iget-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseAnonRssMB:J

    iget v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeFreeMB:I

    int-to-long v7, v7

    iget-wide v9, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startFreeMB:J

    sub-long/2addr v7, v9

    invoke-static {v5, v6, v7, v8}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    iput-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseAnonRssMB:J

    .line 747
    :cond_108
    const-wide/16 v5, 0x0

    .line 748
    .local v5, "actualSwapTotalMem":J
    const-wide/16 v7, 0x0

    .line 749
    .local v7, "actualSwapFreeMem":J
    sget-object v9, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v9}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v9

    check-cast v9, Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-interface {v9}, Lcom/android/server/am/IOplusAthenaAmManager;->readZramInfoMB()[I

    move-result-object v9

    .line 750
    .local v9, "zramInfo":[I
    if-eqz v9, :cond_123

    .line 751
    aget v10, v9, v4

    int-to-long v5, v10

    .line 752
    aget v1, v9, v1

    int-to-long v10, v1

    move-wide v7, v10

    iput-wide v10, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startSwapFreeMB:J

    .line 754
    :cond_123
    const-string/jumbo v1, "purposeUsedSwapPercent"

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeUsedSwapPercent:I

    .line 755
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeUsedSwapPercent:I

    if-lez v1, :cond_156

    .line 756
    const-string/jumbo v1, "triggerUsedSwapPercent"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->triggerUsedSwapPercent:I

    .line 757
    const-string/jumbo v1, "releaseSwapSize"

    invoke-virtual {v0, v1, v4}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->releaseSwapSize:I

    .line 758
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeUsedSwapPercent:I

    int-to-long v1, v1

    mul-long/2addr v1, v5

    const-wide/16 v10, 0x64

    div-long/2addr v1, v10

    sub-long v1, v5, v1

    .line 760
    .local v1, "purposeFreeSwapMB":J
    sub-long v10, v1, v7

    iget v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->releaseSwapSize:I

    int-to-long v12, v4

    .line 761
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v10

    iput-wide v10, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseSwapMB:J

    .line 763
    .end local v1    # "purposeFreeSwapMB":J
    :cond_156
    return-void
.end method

.method private isInvalidProcessRecordLocked(Lcom/android/server/am/ProcessRecord;)Z
    .registers 5
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;

    .line 2616
    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->getThread()Landroid/app/IApplicationThread;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_3e

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mErrorState:Lcom/android/server/am/ProcessErrorStateRecord;

    .line 2617
    invoke-virtual {v0}, Lcom/android/server/am/ProcessErrorStateRecord;->isCrashing()Z

    move-result v0

    if-nez v0, :cond_3e

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mErrorState:Lcom/android/server/am/ProcessErrorStateRecord;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessErrorStateRecord;->isNotResponding()Z

    move-result v0

    if-nez v0, :cond_3e

    .line 2618
    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->isRemoved()Z

    move-result v0

    if-nez v0, :cond_3c

    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v0

    if-lez v0, :cond_3c

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    if-eqz v0, :cond_3c

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    if-eqz v0, :cond_3c

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mProfile:Lcom/android/server/am/ProcessProfileRecord;

    if-eqz v0, :cond_3c

    iget-object v0, p1, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    .line 2620
    invoke-virtual {v0}, Lcom/android/server/am/ProcessStateRecord;->getCurProcState()I

    move-result v0

    const/16 v2, 0x14

    if-ne v0, v2, :cond_3a

    goto :goto_3c

    :cond_3a
    const/4 v1, 0x0

    goto :goto_3d

    :cond_3c
    :goto_3c
    nop

    .line 2618
    :goto_3d
    return v1

    .line 2622
    :cond_3e
    return v1
.end method

.method private isNonPerceptibleFgServiceApp(Lcom/android/server/am/ProcessInfo;)Z
    .registers 5
    .param p1, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1576
    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget v0, v0, Lcom/android/server/am/ProcessGroup;->mMinProcState:I

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eq v0, v2, :cond_9

    .line 1577
    return v1

    .line 1579
    :cond_9
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getCurProcState()I

    move-result v0

    if-eq v0, v2, :cond_10

    .line 1580
    return v1

    .line 1582
    :cond_10
    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v0

    if-eqz v0, :cond_19

    .line 1583
    return v1

    .line 1585
    :cond_19
    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-boolean v0, v0, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-nez v0, :cond_5c

    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->info:Landroid/content/pm/ApplicationInfo;

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->uid:I

    const/16 v2, 0x2710

    if-ge v0, v2, :cond_28

    goto :goto_5c

    .line 1588
    :cond_28
    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v0, v0, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_FOCUS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b

    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v0, v0, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_GPS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1589
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b

    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v0, v0, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_RECORDER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1590
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b

    iget-object v0, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v0, v0, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v2, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_TRAFFIC:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 1591
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_59

    goto :goto_5b

    .line 1594
    :cond_59
    const/4 v0, 0x1

    return v0

    .line 1592
    :cond_5b
    :goto_5b
    return v1

    .line 1586
    :cond_5c
    :goto_5c
    return v1
.end method

.method private isRecentlyUsedApp(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;)Z
    .registers 6
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1545
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v0

    if-nez v0, :cond_16

    .line 1546
    invoke-virtual {p2}, Lcom/android/server/am/ProcessGroup;->getAppLruIndex()I

    move-result v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    iget-boolean v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    invoke-virtual {v1, v2}, Lcom/android/server/am/ConfigUtil;->getThresholdForGroupCheck(Z)I

    move-result v1

    if-gt v0, v1, :cond_16

    .line 1547
    const/4 v0, 0x1

    return v0

    .line 1550
    :cond_16
    const/4 v0, 0x0

    return v0
.end method

.method private killLocked(Lcom/android/server/am/ProcessRecord;Ljava/lang/String;Ljava/lang/String;IIZ)V
    .registers 13
    .param p1, "app"    # Lcom/android/server/am/ProcessRecord;
    .param p2, "reason"    # Ljava/lang/String;
    .param p3, "description"    # Ljava/lang/String;
    .param p4, "reasonCode"    # I
    .param p5, "subReason"    # I
    .param p6, "noisy"    # Z

    .line 2494
    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->isKilledByAm()Z

    move-result v0

    if-nez v0, :cond_ee

    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v0

    if-nez v0, :cond_ee

    .line 2495
    iget v0, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-static {v0}, Landroid/os/Process;->getThreadGroupLeader(I)I

    move-result v0

    iget v1, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    if-eq v0, v1, :cond_3d

    .line 2496
    const-string v0, "KillAction"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " is reused by others, skip kill ["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 2497
    return-void

    .line 2500
    :cond_3d
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "O-Kill: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-wide/16 v1, 0x40

    invoke-static {v1, v2, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2501
    if-eqz p6, :cond_91

    .line 2502
    const-string v0, "KillAction"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Killing "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->toShortString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " (adj "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v4}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "): "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2505
    :cond_91
    iget v0, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    if-lez v0, :cond_c9

    .line 2506
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v0, v0, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v0, p1, p4, p5, p3}, Lcom/android/server/am/ProcessList;->noteAppKill(Lcom/android/server/am/ProcessRecord;IILjava/lang/String;)V

    .line 2507
    iget v0, p1, Lcom/android/server/am/ProcessRecord;->userId:I

    .line 2508
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v3, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v4, p1, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    iget-object v5, p1, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v5}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v0, v3, v4, v5, p2}, [Ljava/lang/Object;

    move-result-object v0

    .line 2507
    const/16 v3, 0x7547

    invoke-static {v3, v0}, Landroid/util/EventLog;->writeEvent(I[Ljava/lang/Object;)I

    .line 2509
    iget v0, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-static {v0}, Landroid/os/Process;->killProcessQuiet(I)V

    .line 2510
    iget v0, p1, Lcom/android/server/am/ProcessRecord;->uid:I

    iget v3, p1, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-static {v0, v3}, Lcom/android/server/am/ProcessList;->killProcessGroup(II)V

    .line 2512
    :cond_c9
    invoke-virtual {p1}, Lcom/android/server/am/ProcessRecord;->isPersistent()Z

    move-result v0

    if-nez v0, :cond_eb

    .line 2513
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mProcLock:Lcom/android/server/am/ActivityManagerGlobalLock;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForProcLockedSection()V

    monitor-enter v0

    .line 2514
    const/4 v3, 0x1

    :try_start_d6
    invoke-virtual {p1, v3}, Lcom/android/server/am/ProcessRecord;->setKilled(Z)V

    .line 2515
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    invoke-virtual {p1, v3, v4}, Lcom/android/server/am/ProcessRecord;->setKillTime(J)V

    .line 2516
    monitor-exit v0
    :try_end_e1
    .catchall {:try_start_d6 .. :try_end_e1} :catchall_e5

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterProcLockedSection()V

    goto :goto_eb

    :catchall_e5
    move-exception v1

    :try_start_e6
    monitor-exit v0
    :try_end_e7
    .catchall {:try_start_e6 .. :try_end_e7} :catchall_e5

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterProcLockedSection()V

    throw v1

    .line 2518
    :cond_eb
    :goto_eb
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 2520
    :cond_ee
    return-void
.end method

.method private killOneProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V
    .registers 5
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .param p3, "reason"    # Ljava/lang/String;

    .line 2435
    const/16 v0, 0x400

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/android/server/am/OplusOsenseKillAction;->killOneProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/lang/String;I)V

    .line 2436
    return-void
.end method

.method private killOneProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Ljava/lang/String;I)V
    .registers 22
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .param p3, "reason"    # Ljava/lang/String;
    .param p4, "subReasonCode"    # I

    .line 2439
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    iget-object v3, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    const-string v4, "KillAction"

    if-nez v3, :cond_24

    .line 2440
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "no app to kill: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 2441
    return-void

    .line 2443
    :cond_24
    iget-object v3, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v3

    if-eqz v3, :cond_46

    .line 2444
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "already be killed: %s"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v4, v3, v5}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 2445
    return-void

    .line 2447
    :cond_46
    iget v3, v1, Lcom/android/server/am/ProcessInfo;->mPid:I

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v5}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v5

    if-eq v3, v5, :cond_6a

    .line 2448
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "pid reuse of "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2449
    return-void

    .line 2451
    :cond_6a
    iget-object v3, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessRecord;->getWindowProcessController()Lcom/android/server/wm/WindowProcessController;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/wm/WindowProcessController;->getWrapper()Lcom/android/server/wm/IWindowProcessControllerWrapper;

    move-result-object v3

    invoke-interface {v3}, Lcom/android/server/wm/IWindowProcessControllerWrapper;->getExtImpl()Lcom/android/server/wm/IWindowProcessControllerExt;

    move-result-object v3

    invoke-interface {v3}, Lcom/android/server/wm/IWindowProcessControllerExt;->waitActivityToAttach()Z

    move-result v3

    const-string/jumbo v5, "skip kill "

    if-eqz v3, :cond_9e

    .line 2452
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, ": waiting activity to attach"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2453
    return-void

    .line 2455
    :cond_9e
    iget v3, v1, Lcom/android/server/am/ProcessInfo;->mUid:I

    invoke-static {}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getInstance()Lcom/android/server/oplus/osense/resource/AppStatusManager;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getCurTopUid()I

    move-result v6

    if-ne v3, v6, :cond_c7

    .line 2456
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, ": pending top app"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2457
    return-void

    .line 2459
    :cond_c7
    iget v3, v1, Lcom/android/server/am/ProcessInfo;->mUid:I

    move-object/from16 v6, p0

    iget v7, v6, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    if-ne v3, v7, :cond_ec

    .line 2460
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, ": starting activity"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2461
    return-void

    .line 2463
    :cond_ec
    const-string/jumbo v3, "killLocked"

    const-wide/16 v13, 0x40

    invoke-static {v13, v14, v3}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2464
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v15

    .line 2465
    .local v15, "start":J
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 2466
    .local v3, "killMsg":Ljava/lang/StringBuilder;
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "[("

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v7, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    iget-object v7, v7, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v7}, Lcom/android/server/am/ProcessStateRecord;->getAdjType()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2467
    const-string v5, ")"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2468
    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v5, v5, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    invoke-interface {v5}, Ljava/util/Set;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_128

    .line 2469
    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v5, v5, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 2471
    :cond_128
    const-string v5, "]"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2472
    iget-boolean v5, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    if-eqz v5, :cond_13f

    .line 2473
    iget-object v5, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v5}, Lcom/android/server/am/ProcessRecord;->getWrapper()Lcom/android/server/am/IProcessRecordWrapper;

    move-result-object v5

    invoke-interface {v5}, Lcom/android/server/am/IProcessRecordWrapper;->getExtImpl()Lcom/android/server/am/IProcessRecordExt;

    move-result-object v5

    const/4 v7, 0x1

    invoke-interface {v5, v7}, Lcom/android/server/am/IProcessRecordExt;->setExplicitDisableRestart(Z)V

    .line 2476
    :cond_13f
    iget-object v7, v1, Lcom/android/server/am/ProcessInfo;->mToBeKill:Lcom/android/server/am/ProcessRecord;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v10, 0xd

    const/4 v12, 0x0

    move/from16 v11, p4

    invoke-direct/range {v6 .. v12}, Lcom/android/server/am/OplusOsenseKillAction;->killLocked(Lcom/android/server/am/ProcessRecord;Ljava/lang/String;Ljava/lang/String;IIZ)V

    .line 2478
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    .line 2479
    .local v5, "killEndTime":J
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Kill "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-wide v8, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v1, v8, v9}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ": "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    sub-long v8, v5, v15

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string/jumbo v8, "ms"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2482
    invoke-virtual {v1}, Lcom/android/server/am/ProcessInfo;->getReclaimedMem()J

    move-result-wide v7

    .line 2483
    .local v7, "reclaimedMem":J
    iget-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedPssKB:J

    invoke-virtual {v1}, Lcom/android/server/am/ProcessInfo;->getLastPss()J

    move-result-wide v11

    add-long/2addr v9, v11

    iput-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedPssKB:J

    .line 2484
    iget-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    iget-wide v11, v1, Lcom/android/server/am/ProcessInfo;->mAnonMemoryMB:J

    add-long/2addr v9, v11

    iput-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    .line 2485
    iget-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedMemMB:J

    add-long/2addr v9, v7

    iput-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedMemMB:J

    .line 2486
    iget-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    iget-wide v11, v1, Lcom/android/server/am/ProcessInfo;->mSwapMemoryMB:J

    add-long/2addr v9, v11

    iput-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    .line 2487
    iget-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedRssMB:J

    iget-wide v11, v1, Lcom/android/server/am/ProcessInfo;->mRssMemoryMB:J

    add-long/2addr v9, v11

    iput-wide v9, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedRssMB:J

    .line 2488
    iget-object v4, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    invoke-interface {v4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2489
    invoke-static {v13, v14}, Landroid/os/Trace;->traceEnd(J)V

    .line 2490
    return-void
.end method

.method static synthetic lambda$dumpRecentIdx$17(Landroid/util/Pair;Landroid/util/Pair;)I
    .registers 4
    .param p0, "left"    # Landroid/util/Pair;
    .param p1, "right"    # Landroid/util/Pair;

    .line 3429
    iget-object v0, p0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$getProcessPssRawData$4(Landroid/util/SparseArray;Landroid/os/Debug$MemoryInfo;Ljava/util/ArrayList;[J[J[Ljava/util/ArrayList;Lcom/android/internal/os/ProcessCpuTracker$Stats;)V
    .registers 26
    .param p0, "procMemsMap"    # Landroid/util/SparseArray;
    .param p1, "info"    # Landroid/os/Debug$MemoryInfo;
    .param p2, "procMems"    # Ljava/util/ArrayList;
    .param p3, "oomPss"    # [J
    .param p4, "oomSwapPss"    # [J
    .param p5, "oomProcs"    # [Ljava/util/ArrayList;
    .param p6, "st"    # Lcom/android/internal/os/ProcessCpuTracker$Stats;

    .line 2220
    move-object/from16 v0, p6

    iget-wide v1, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->vsize:J

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-lez v1, :cond_8f

    iget v1, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->pid:I

    move-object/from16 v2, p0

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v1

    if-gez v1, :cond_91

    .line 2221
    iget v1, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->pid:I

    move-object/from16 v3, p1

    invoke-static {v1, v3}, Landroid/os/Debug;->getMemoryInfo(ILandroid/os/Debug$MemoryInfo;)Z

    move-result v1

    if-nez v1, :cond_1f

    .line 2222
    return-void

    .line 2224
    :cond_1f
    new-instance v4, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->name:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, " (pid "

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v5, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->pid:I

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, ")"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->name:Ljava/lang/String;

    .line 2225
    invoke-virtual {v3}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v1

    int-to-long v7, v1

    invoke-virtual {v3}, Landroid/os/Debug$MemoryInfo;->getSummaryTotalSwapPss()I

    move-result v1

    int-to-long v9, v1

    .line 2226
    invoke-virtual {v3}, Landroid/os/Debug$MemoryInfo;->getTotalRss()I

    move-result v1

    int-to-long v11, v1

    iget v15, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->pid:I

    iget v1, v0, Lcom/android/internal/os/ProcessCpuTracker$Stats;->uid:I

    .line 2227
    invoke-static {v1}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v16

    const/16 v17, 0x0

    const/16 v18, -0x3e8

    const-wide/16 v13, 0x0

    invoke-direct/range {v4 .. v18}, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJIIZI)V

    .line 2228
    .local v4, "pssItem":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    move-object/from16 v1, p2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2229
    const/4 v5, 0x0

    aget-wide v6, p3, v5

    invoke-virtual {v3}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v8

    int-to-long v8, v8

    add-long/2addr v6, v8

    aput-wide v6, p3, v5

    .line 2230
    aget-wide v6, p4, v5

    invoke-virtual {v3}, Landroid/os/Debug$MemoryInfo;->getSummaryTotalSwapPss()I

    move-result v8

    int-to-long v8, v8

    add-long/2addr v6, v8

    aput-wide v6, p4, v5

    .line 2231
    aget-object v6, p5, v5

    if-nez v6, :cond_89

    .line 2232
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    aput-object v6, p5, v5

    .line 2234
    :cond_89
    aget-object v5, p5, v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_95

    .line 2220
    .end local v4    # "pssItem":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    :cond_8f
    move-object/from16 v2, p0

    :cond_91
    move-object/from16 v3, p1

    move-object/from16 v1, p2

    .line 2236
    :goto_95
    return-void
.end method

.method static synthetic lambda$getProcessPssRawData$5(Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;)I
    .registers 6
    .param p0, "lhs"    # Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    .param p1, "rhs"    # Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    .line 2239
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->adj:I

    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->adj:I

    if-eq v0, v1, :cond_f

    .line 2240
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->adj:I

    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->adj:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0

    .line 2242
    :cond_f
    iget-wide v0, p1, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->pss:J

    iget-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->pss:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$getProcessPssRawData$6(Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;)I
    .registers 6
    .param p0, "lhs"    # Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    .param p1, "rhs"    # Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    .line 2253
    iget-wide v0, p1, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->pss:J

    iget-wide v2, p0, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->pss:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$printMemNodeInfo$18(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/io/PrintWriter;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/android/server/am/ProcessRecord;)V
    .registers 6
    .param p0, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "match"    # Ljava/util/concurrent/atomic/AtomicBoolean;
    .param p3, "r"    # Lcom/android/server/am/ProcessRecord;

    .line 3524
    iget-object v0, p3, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v0

    if-ltz v0, :cond_3f

    invoke-virtual {p3}, Lcom/android/server/am/ProcessRecord;->isKilled()Z

    move-result v0

    if-nez v0, :cond_3f

    invoke-virtual {p3}, Lcom/android/server/am/ProcessRecord;->isKilledByAm()Z

    move-result v0

    if-nez v0, :cond_3f

    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    .line 3525
    invoke-virtual {p3}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_3f

    .line 3526
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "get memory info failed: missing "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3527
    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 3529
    :cond_3f
    return-void
.end method

.method static synthetic lambda$scanAllProcIfNeeded$3(Lcom/android/server/am/ProcessGroup;)Z
    .registers 3
    .param p0, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1286
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mNumCchTargets:I

    iget-object v1, p0, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method static synthetic lambda$scanNonUiProcIfNeeded$2(Lcom/android/server/am/ProcessGroup;)Z
    .registers 2
    .param p0, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1131
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->invalidTaskLru()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method private synthetic lambda$scanOomAdjIfNeeded$0(Lcom/android/server/am/ProcessInfo;)Z
    .registers 4
    .param p1, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1040
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->getOomCheckAdjThres()I

    move-result v1

    if-lt v0, v1, :cond_e

    const/4 v0, 0x1

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    :goto_f
    return v0
.end method

.method static synthetic lambda$scanOomAdjIfNeeded$1(Lcom/android/server/am/ProcessInfo;)Z
    .registers 2
    .param p0, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1041
    iget-object v0, p0, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method static synthetic lambda$static$10(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 6
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2855
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_e

    .line 2856
    const/4 v0, -0x1

    return v0

    .line 2858
    :cond_e
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_1c

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_1c

    .line 2859
    const/4 v0, 0x1

    return v0

    .line 2863
    :cond_1c
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v0

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v2

    sub-long/2addr v0, v2

    long-to-int v0, v0

    return v0
.end method

.method static synthetic lambda$static$11(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 6
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2868
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->hoggingCpu()Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_e

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->hoggingCpu()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 2869
    return v1

    .line 2871
    :cond_e
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->hoggingCpu()Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_1c

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->hoggingCpu()Z

    move-result v0

    if-nez v0, :cond_1c

    .line 2872
    return v2

    .line 2874
    :cond_1c
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v0

    if-eqz v0, :cond_4d

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v0

    if-eqz v0, :cond_4d

    .line 2876
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_35

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_35

    .line 2877
    return v1

    .line 2879
    :cond_35
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_42

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_42

    .line 2880
    return v2

    .line 2884
    :cond_42
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v0

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v2

    sub-long/2addr v0, v2

    long-to-int v0, v0

    return v0

    .line 2886
    :cond_4d
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-eq v0, v1, :cond_59

    .line 2887
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    sub-int/2addr v0, v1

    return v0

    .line 2890
    :cond_59
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method static synthetic lambda$static$12(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 6
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2894
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v0

    if-eqz v0, :cond_33

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v0

    if-eqz v0, :cond_33

    .line 2896
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_1a

    .line 2897
    const/4 v0, -0x1

    return v0

    .line 2899
    :cond_1a
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-nez v0, :cond_28

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v0

    if-eqz v0, :cond_28

    .line 2900
    const/4 v0, 0x1

    return v0

    .line 2904
    :cond_28
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v0

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v2

    sub-long/2addr v0, v2

    long-to-int v0, v0

    return v0

    .line 2906
    :cond_33
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-eq v0, v1, :cond_3f

    .line 2907
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    sub-int/2addr v0, v1

    return v0

    .line 2910
    :cond_3f
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method static synthetic lambda$static$13(Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessInfo;)I
    .registers 6
    .param p0, "left"    # Lcom/android/server/am/ProcessInfo;
    .param p1, "right"    # Lcom/android/server/am/ProcessInfo;

    .line 2915
    iget-object v0, p0, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget v0, v0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    .line 2916
    .local v0, "leftIdx":I
    iget-object v1, p1, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget v1, v1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    .line 2917
    .local v1, "rightIdx":I
    if-eq v0, v1, :cond_d

    .line 2918
    sub-int v2, v0, v1

    return v2

    .line 2921
    :cond_d
    iget v2, p0, Lcom/android/server/am/ProcessInfo;->mIdx:I

    iget v3, p1, Lcom/android/server/am/ProcessInfo;->mIdx:I

    sub-int/2addr v2, v3

    return v2
.end method

.method static synthetic lambda$static$14(Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessInfo;)I
    .registers 4
    .param p0, "left"    # Lcom/android/server/am/ProcessInfo;
    .param p1, "right"    # Lcom/android/server/am/ProcessInfo;

    .line 2926
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v0

    invoke-virtual {p0}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v1

    if-eq v0, v1, :cond_14

    .line 2927
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v0

    invoke-virtual {p0}, Lcom/android/server/am/ProcessInfo;->getCurAdj()I

    move-result v1

    sub-int/2addr v0, v1

    return v0

    .line 2930
    :cond_14
    iget v0, p0, Lcom/android/server/am/ProcessInfo;->mIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessInfo;->mIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method static synthetic lambda$static$15(Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessInfo;)I
    .registers 6
    .param p0, "left"    # Lcom/android/server/am/ProcessInfo;
    .param p1, "right"    # Lcom/android/server/am/ProcessInfo;

    .line 2936
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getReclaimedMem()J

    move-result-wide v0

    invoke-virtual {p0}, Lcom/android/server/am/ProcessInfo;->getReclaimedMem()J

    move-result-wide v2

    sub-long/2addr v0, v2

    long-to-int v0, v0

    return v0
.end method

.method static synthetic lambda$static$16(Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessInfo;)I
    .registers 4
    .param p0, "left"    # Lcom/android/server/am/ProcessInfo;
    .param p1, "right"    # Lcom/android/server/am/ProcessInfo;

    .line 2941
    invoke-virtual {p0}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v0

    if-nez v0, :cond_e

    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 2942
    const/4 v0, -0x1

    return v0

    .line 2944
    :cond_e
    invoke-virtual {p0}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->hoggingCpu()Z

    move-result v0

    if-nez v0, :cond_1c

    .line 2945
    const/4 v0, 0x1

    return v0

    .line 2948
    :cond_1c
    iget v0, p1, Lcom/android/server/am/ProcessInfo;->mIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessInfo;->mIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method static synthetic lambda$static$7(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 4
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2812
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    if-eq v0, v1, :cond_f

    .line 2813
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0

    .line 2816
    :cond_f
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-eq v0, v1, :cond_1e

    .line 2817
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0

    .line 2820
    :cond_1e
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method static synthetic lambda$static$8(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 4
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2826
    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->getMaxAppCare()I

    move-result v0

    if-nez v0, :cond_31

    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->getMaxAppCare()I

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_31

    .line 2830
    :cond_d
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    if-eq v0, v1, :cond_1c

    .line 2831
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0

    .line 2834
    :cond_1c
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-eq v0, v1, :cond_2b

    .line 2835
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0

    .line 2838
    :cond_2b
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    sub-int/2addr v0, v1

    return v0

    .line 2827
    :cond_31
    :goto_31
    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->getMaxAppCare()I

    move-result v0

    invoke-virtual {p0}, Lcom/android/server/am/ProcessGroup;->getMaxAppCare()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$static$9(Lcom/android/server/am/ProcessGroup;Lcom/android/server/am/ProcessGroup;)I
    .registers 4
    .param p0, "left"    # Lcom/android/server/am/ProcessGroup;
    .param p1, "right"    # Lcom/android/server/am/ProcessGroup;

    .line 2846
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-eq v0, v1, :cond_c

    .line 2847
    iget v0, p0, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    sub-int/2addr v0, v1

    return v0

    .line 2850
    :cond_c
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v1, p0, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    sub-int/2addr v0, v1

    return v0
.end method

.method private makeString(Ljava/lang/String;Ljava/util/Collection;)Ljava/lang/String;
    .registers 9
    .param p1, "type"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/util/Collection<",
            "TT;>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 996
    .local p2, "list":Ljava/util/Collection;, "Ljava/util/Collection<TT;>;"
    invoke-interface {p2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 997
    .local v0, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<TT;>;"
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_1e

    .line 998
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":{}"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 1000
    :cond_1e
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 1001
    .local v1, "sb":Ljava/lang/StringBuilder;
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ":{"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1003
    :goto_2c
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 1004
    .local v2, "i":Ljava/lang/Object;, "TT;"
    instance-of v3, v2, Landroid/util/Pair;

    if-eqz v3, :cond_49

    .line 1005
    move-object v3, v2

    check-cast v3, Landroid/util/Pair;

    .line 1006
    .local v3, "p":Landroid/util/Pair;
    iget-object v4, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    const/16 v5, 0x3a

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1007
    .end local v3    # "p":Landroid/util/Pair;
    goto :goto_4c

    .line 1008
    :cond_49
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1010
    :goto_4c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_5d

    .line 1011
    const/16 v3, 0x7d

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    return-object v3

    .line 1013
    :cond_5d
    const/16 v3, 0x2c

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 1014
    .end local v2    # "i":Ljava/lang/Object;, "TT;"
    goto :goto_2c
.end method

.method private notifySysState(Landroid/os/Bundle;)V
    .registers 9
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 976
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    monitor-enter v0

    .line 978
    :try_start_3
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    invoke-virtual {v1}, Landroid/os/RemoteCallbackList;->beginBroadcast()I

    move-result v1

    .line 979
    .local v1, "size":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_a
    if-ge v2, v1, :cond_23

    .line 980
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    invoke-virtual {v3, v2}, Landroid/os/RemoteCallbackList;->getBroadcastItem(I)Landroid/os/IInterface;

    move-result-object v3

    check-cast v3, Lcom/oplus/datasync/ISysStateChangeCallback;
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_14} :catch_2b
    .catchall {:try_start_3 .. :try_end_14} :catchall_29

    .line 983
    .local v3, "callback":Lcom/oplus/datasync/ISysStateChangeCallback;
    :try_start_14
    invoke-interface {v3, p1}, Lcom/oplus/datasync/ISysStateChangeCallback;->onSysStateChanged(Landroid/os/Bundle;)V
    :try_end_17
    .catch Landroid/os/RemoteException; {:try_start_14 .. :try_end_17} :catch_18
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_17} :catch_2b
    .catchall {:try_start_14 .. :try_end_17} :catchall_29

    .line 986
    goto :goto_20

    .line 984
    :catch_18
    move-exception v4

    .line 985
    .local v4, "e":Landroid/os/RemoteException;
    :try_start_19
    const-string v5, "KillAction"

    const-string v6, "Error NotifySysState:"

    invoke-static {v5, v6, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 979
    .end local v3    # "callback":Lcom/oplus/datasync/ISysStateChangeCallback;
    .end local v4    # "e":Landroid/os/RemoteException;
    :goto_20
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    .line 988
    .end local v2    # "i":I
    :cond_23
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    invoke-virtual {v2}, Landroid/os/RemoteCallbackList;->finishBroadcast()V
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_28} :catch_2b
    .catchall {:try_start_19 .. :try_end_28} :catchall_29

    .line 991
    .end local v1    # "size":I
    goto :goto_33

    .line 992
    :catchall_29
    move-exception v1

    goto :goto_35

    .line 989
    :catch_2b
    move-exception v1

    .line 990
    .local v1, "e":Ljava/lang/Exception;
    :try_start_2c
    const-string v2, "KillAction"

    const-string v3, "Exception NotifySysState:"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 992
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_33
    monitor-exit v0

    .line 993
    return-void

    .line 992
    :goto_35
    monitor-exit v0
    :try_end_36
    .catchall {:try_start_2c .. :try_end_36} :catchall_29

    throw v1
.end method

.method private preScan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 2
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 2599
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2600
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2601
    return-void
.end method

.method private printAppStatus(Ljava/io/PrintWriter;)V
    .registers 16
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 2961
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 2962
    .local v0, "extra":Landroid/os/Bundle;
    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v1

    .line 2963
    .local v1, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-direct {p0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2964
    invoke-direct {p0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2965
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v2

    .line 2966
    :try_start_16
    new-instance v3, Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v4}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v1, v3}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 2967
    monitor-exit v2
    :try_end_27
    .catchall {:try_start_16 .. :try_end_27} :catchall_169

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 2968
    iget-object v2, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->pkgStatus:Lcom/android/internal/app/ProcessMap;

    invoke-virtual {v2}, Lcom/android/internal/app/ProcessMap;->getMap()Landroid/util/ArrayMap;

    move-result-object v2

    .line 2969
    .local v2, "map":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;>;"
    const-string v3, "#keep warming services: "

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2970
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "  "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerService;->mConstants:Lcom/android/server/am/ActivityManagerConstants;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerConstants;->KEEP_WARMING_SERVICES:Landroid/util/ArraySet;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2971
    const-string v3, "#app status: "

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2972
    invoke-virtual {v2}, Landroid/util/ArrayMap;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_5e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_e6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 2973
    .local v4, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;>;"
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 2974
    .local v5, "pkgName":Ljava/lang/String;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/util/SparseArray;

    .line 2975
    .local v6, "allStatusUser":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;"
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_77
    invoke-virtual {v6}, Landroid/util/SparseArray;->size()I

    move-result v8

    if-ge v7, v8, :cond_e4

    .line 2976
    invoke-virtual {v6, v7}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v8

    .line 2977
    .local v8, "userId":I
    invoke-virtual {v6, v7}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Set;

    .line 2978
    .local v9, "pkgStatus":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;"
    invoke-interface {v9}, Ljava/util/Set;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_e1

    .line 2979
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "  pkg="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " user="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " status="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p1, v10}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 2980
    invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_b7
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_de

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 2981
    .local v11, "type":Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11}, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->getName()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {p1, v12}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 2982
    .end local v11    # "type":Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;
    goto :goto_b7

    .line 2983
    :cond_de
    invoke-virtual {p1}, Ljava/io/PrintWriter;->println()V

    .line 2975
    .end local v8    # "userId":I
    .end local v9    # "pkgStatus":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;"
    :cond_e1
    add-int/lit8 v7, v7, 0x1

    goto :goto_77

    .line 2986
    .end local v4    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;>;"
    .end local v5    # "pkgName":Ljava/lang/String;
    .end local v6    # "allStatusUser":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;"
    .end local v7    # "i":I
    :cond_e4
    goto/16 :goto_5e

    .line 2987
    :cond_e6
    const-string v3, "#self protect proc:"

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2988
    iget-object v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->selfProtectProcMap:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_f5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_12e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 2989
    .local v4, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 2990
    .restart local v5    # "pkgName":Ljava/lang/String;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/List;

    .line 2991
    .local v6, "procList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, " pkg="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " procs="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2992
    .end local v4    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;"
    .end local v5    # "pkgName":Ljava/lang/String;
    .end local v6    # "procList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    goto :goto_f5

    .line 2993
    :cond_12e
    const-string v3, "#self protect pkg:"

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2994
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->selfProtectPkg:Ljava/util/List;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2995
    const-string v3, "#heat game pkg:"

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2996
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->heatGamePkgList:Ljava/util/List;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 2997
    return-void

    .line 2967
    .end local v2    # "map":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;>;>;"
    :catchall_169
    move-exception v3

    :try_start_16a
    monitor-exit v2
    :try_end_16b
    .catchall {:try_start_16a .. :try_end_16b} :catchall_169

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v3
.end method

.method private printFzState(Ljava/io/PrintWriter;)V
    .registers 8
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3166
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 3167
    .local v0, "extra":Landroid/os/Bundle;
    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v1

    .line 3168
    .local v1, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mQuickBoot:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    iput-boolean v2, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    .line 3169
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "qbmode="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3170
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mFreezeTracker:Lcom/android/server/am/OplusFreezeStateTracker;

    iget-object v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v3}, Lcom/android/server/am/ConfigUtil;->isEnableNextPossibleUnfzCheck()Z

    move-result v3

    iget-object v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    iget-boolean v5, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    .line 3171
    invoke-virtual {v4, v5}, Lcom/android/server/am/ConfigUtil;->getStableFzThresHold(Z)I

    move-result v4

    .line 3170
    const v5, 0xea60

    invoke-virtual {v2, p1, v3, v5, v4}, Lcom/android/server/am/OplusFreezeStateTracker;->dump(Ljava/io/PrintWriter;ZII)V

    .line 3172
    return-void
.end method

.method private printHelp(Ljava/io/PrintWriter;)V
    .registers 3
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3488
    const-string v0, "atomic dump options:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3489
    const-string v0, "  config: print config"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3490
    const-string v0, "  state: print working state"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3491
    const-string v0, "  app-state: print app state"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3492
    const-string v0, "  fz: print app fz state"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3493
    const-string v0, "  group: print process group"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3494
    const-string v0, "  sort: test sorted list"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3495
    const-string v0, "  mem_node: test memory read"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3496
    const-string v0, "  scan: scan but not kill process"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3497
    const-string v0, "  history: print kill history"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3498
    const-string v0, "  kill <type> <purposeMB> [doKill]"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3499
    return-void
.end method

.method private printHistory(Ljava/io/PrintWriter;)V
    .registers 7
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3502
    const-string v0, "### kill history ###"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3503
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    monitor-enter v0

    .line 3504
    :try_start_8
    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistoryIdx:I

    add-int/lit8 v1, v1, -0x1

    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v2, v2

    add-int/2addr v1, v2

    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v2, v2

    rem-int/2addr v1, v2

    .line 3505
    .local v1, "idx":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_15
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v3, v3

    if-ge v2, v3, :cond_5c

    .line 3506
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    aget-object v3, v3, v1

    if-nez v3, :cond_21

    .line 3507
    goto :goto_5c

    .line 3509
    :cond_21
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " * ["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "] "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    aget-object v4, v4, v1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3510
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    aget-object v3, v3, v1

    const-string v4, "   "

    invoke-virtual {v3, v4, p1}, Lcom/android/server/am/KillInfo;->dump(Ljava/lang/String;Ljava/io/PrintWriter;)V

    .line 3511
    add-int/lit8 v3, v1, -0x1

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v4, v4

    add-int/2addr v3, v4

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v4, v4

    rem-int/2addr v3, v4

    move v1, v3

    .line 3505
    add-int/lit8 v2, v2, 0x1

    goto :goto_15

    .line 3513
    .end local v1    # "idx":I
    .end local v2    # "i":I
    :cond_5c
    :goto_5c
    monitor-exit v0

    .line 3514
    return-void

    .line 3513
    :catchall_5e
    move-exception v1

    monitor-exit v0
    :try_end_60
    .catchall {:try_start_8 .. :try_end_60} :catchall_5e

    throw v1
.end method

.method private printMemNodeInfo(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 12
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3517
    move v0, p3

    .line 3518
    .local v0, "opti":I
    array-length v1, p2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ge v0, v1, :cond_13

    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v0, p2, v0

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_12

    move v0, v2

    goto :goto_15

    :cond_12
    move v0, v1

    .end local v1    # "opti":I
    .restart local v0    # "opti":I
    :cond_13
    move v1, v0

    move v0, v3

    .line 3519
    .local v0, "doPrint":Z
    .restart local v1    # "opti":I
    :goto_15
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    invoke-direct {p0, v4, v3}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v4

    .line 3520
    .local v4, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-direct {p0, v4}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3521
    new-instance v5, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v5, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 3522
    .local v5, "match":Ljava/util/concurrent/atomic/AtomicBoolean;
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v2

    .line 3523
    :try_start_2c
    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v6, v6, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    new-instance v7, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda0;

    invoke-direct {v7, v4, p1, v5}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/io/PrintWriter;Ljava/util/concurrent/atomic/AtomicBoolean;)V

    invoke-virtual {v6, v3, v7}, Lcom/android/server/am/ProcessList;->forEachLruProcessesLOSP(ZLjava/util/function/Consumer;)V

    .line 3530
    monitor-exit v2
    :try_end_39
    .catchall {:try_start_2c .. :try_end_39} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3531
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_4f

    .line 3532
    const-string/jumbo v2, "get memory info success"

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3533
    if-eqz v0, :cond_4f

    .line 3534
    iget-object v2, v4, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    invoke-static {p1, v2}, Lcom/android/server/am/MemUtil;->printProcNodeMem(Ljava/io/PrintWriter;Ljava/util/Map;)V

    .line 3537
    :cond_4f
    return-void

    .line 3530
    :catchall_50
    move-exception v3

    :try_start_51
    monitor-exit v2
    :try_end_52
    .catchall {:try_start_51 .. :try_end_52} :catchall_50

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v3
.end method

.method private printPart1(Ljava/io/PrintWriter;Lcom/android/server/am/OplusOsenseKillAction$KillContext;Z)V
    .registers 16
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p3, "groupCheck"    # Z

    .line 3062
    const-string/jumbo v0, "target cached lru:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3063
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_7
    iget-object v1, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const-string v2, "  #"

    const-string v3, " "

    const-string v4, ": "

    if-ge v0, v1, :cond_4c

    .line 3064
    iget-object v1, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/ProcessInfo;

    .line 3065
    .local v1, "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v5, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v1, v5, v6}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v1, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3063
    .end local v1    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    .line 3067
    .end local v0    # "i":I
    :cond_4c
    const-string v0, "      "

    const-string v1, " fz="

    if-eqz p3, :cond_d6

    .line 3068
    const-string v5, "\ntarget group lru:"

    invoke-virtual {p1, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3069
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_58
    iget-object v6, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_d6

    .line 3070
    iget-object v6, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessGroup;

    .line 3071
    .local v6, "group":Lcom/android/server/am/ProcessGroup;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3072
    const/4 v7, 0x0

    .local v7, "j":I
    :goto_95
    iget-object v8, v6, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-ge v7, v8, :cond_d3

    .line 3073
    iget-object v8, v6, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessInfo;

    .line 3074
    .local v8, "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-wide v10, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v8, v10, v11}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 3075
    iget-object v10, v8, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    if-eqz v10, :cond_c3

    iget-object v10, v8, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    goto :goto_c5

    :cond_c3
    iget-object v10, v8, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    :goto_c5
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 3074
    invoke-virtual {p1, v9}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3072
    .end local v8    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v7, v7, 0x1

    goto :goto_95

    .line 3069
    .end local v6    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v7    # "j":I
    :cond_d3
    add-int/lit8 v5, v5, 0x1

    goto :goto_58

    .line 3079
    .end local v5    # "i":I
    :cond_d6
    const-string v2, "\nskip group mru:"

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3080
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_dc
    iget-object v5, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v2, v5, :cond_181

    .line 3081
    iget-object v5, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ProcessGroup;

    .line 3082
    .local v5, "group":Lcom/android/server/am/ProcessGroup;
    iget-object v6, v5, Lcom/android/server/am/ProcessGroup;->mCleanType:Ljava/lang/String;

    if-eqz v6, :cond_f2

    .line 3083
    goto/16 :goto_17d

    .line 3085
    :cond_f2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " #"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    .line 3086
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    if-eqz v7, :cond_131

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-object v8, v5, Lcom/android/server/am/ProcessGroup;->mSkipReason:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    goto :goto_133

    :cond_131
    const-string v7, ""

    :goto_133
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 3085
    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3087
    const/4 v6, 0x0

    .local v6, "j":I
    :goto_13f
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_17d

    .line 3088
    iget-object v7, v5, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 3089
    .local v7, "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-wide v9, p2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v7, v9, v10}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3090
    iget-object v9, v7, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    if-eqz v9, :cond_16d

    iget-object v9, v7, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    goto :goto_16f

    :cond_16d
    iget-object v9, v7, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    :goto_16f
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 3089
    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3087
    .end local v7    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v6, v6, 0x1

    goto :goto_13f

    .line 3080
    .end local v5    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v6    # "j":I
    :cond_17d
    :goto_17d
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_dc

    .line 3093
    .end local v2    # "i":I
    :cond_181
    return-void
.end method

.method private printPart2(Ljava/io/PrintWriter;Lcom/android/server/am/OplusOsenseKillAction$KillContext;I)V
    .registers 21
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p3, "releaseTarget"    # I

    .line 3096
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move/from16 v2, p3

    const/4 v3, 0x0

    .line 3097
    .local v3, "release":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 3098
    .local v4, "killList":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessInfo;>;"
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_d
    iget-object v6, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_2d

    .line 3099
    iget-object v6, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessInfo;

    .line 3100
    .local v6, "pi":Lcom/android/server/am/ProcessInfo;
    int-to-long v7, v3

    invoke-virtual {v6}, Lcom/android/server/am/ProcessInfo;->getReclaimedMem()J

    move-result-wide v9

    add-long/2addr v7, v9

    long-to-int v3, v7

    .line 3101
    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 3102
    if-lt v3, v2, :cond_2a

    .line 3103
    goto :goto_2d

    .line 3098
    .end local v6    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_2a
    add-int/lit8 v5, v5, 0x1

    goto :goto_d

    .line 3106
    .end local v5    # "i":I
    :cond_2d
    :goto_2d
    const-string v5, "\ndefault lru:"

    invoke-virtual {v0, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3107
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "target="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ", need to kill "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " processes"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3108
    const-string/jumbo v5, "kill List: "

    invoke-virtual {v0, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3109
    const/4 v9, 0x0

    .local v9, "i":I
    :goto_64
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v10

    const-string v11, ": "

    const-string v12, "      "

    if-ge v9, v10, :cond_9b

    .line 3110
    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/android/server/am/ProcessInfo;

    .line 3111
    .local v10, "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    iget-wide v13, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v10, v13, v14}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    iget-object v12, v10, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3109
    .end local v10    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v9, v9, 0x1

    goto :goto_64

    .line 3114
    .end local v9    # "i":I
    :cond_9b
    iget-object v9, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    sget-object v10, Lcom/android/server/am/OplusOsenseKillAction;->LRU_SORT_PROCESS_BY_MEM:Ljava/util/Comparator;

    invoke-interface {v9, v10}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3115
    const/4 v3, 0x0

    .line 3116
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 3117
    const/4 v9, 0x0

    .restart local v9    # "i":I
    :goto_a7
    iget-object v10, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_c7

    .line 3118
    iget-object v10, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/android/server/am/ProcessInfo;

    .line 3119
    .restart local v10    # "pi":Lcom/android/server/am/ProcessInfo;
    int-to-long v13, v3

    invoke-virtual {v10}, Lcom/android/server/am/ProcessInfo;->getReclaimedMem()J

    move-result-wide v15

    add-long/2addr v13, v15

    long-to-int v3, v13

    .line 3120
    invoke-interface {v4, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 3121
    if-lt v3, v2, :cond_c4

    .line 3122
    goto :goto_c7

    .line 3117
    .end local v10    # "pi":Lcom/android/server/am/ProcessInfo;
    :cond_c4
    add-int/lit8 v9, v9, 0x1

    goto :goto_a7

    .line 3125
    .end local v9    # "i":I
    :cond_c7
    :goto_c7
    const-string v9, "\nlarge mem first lru:"

    invoke-virtual {v0, v9}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3126
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3127
    invoke-virtual {v0, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3128
    const/4 v5, 0x0

    .restart local v5    # "i":I
    :goto_f4
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_127

    .line 3129
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessInfo;

    .line 3130
    .restart local v6    # "pi":Lcom/android/server/am/ProcessInfo;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-wide v8, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    invoke-virtual {v6, v8, v9}, Lcom/android/server/am/ProcessInfo;->toLongString(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget-object v8, v6, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3128
    .end local v6    # "pi":Lcom/android/server/am/ProcessInfo;
    add-int/lit8 v5, v5, 0x1

    goto :goto_f4

    .line 3132
    .end local v5    # "i":I
    :cond_127
    return-void
.end method

.method private printState(Ljava/io/PrintWriter;)V
    .registers 7
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3304
    const-string v0, "#### working state ####"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3305
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Enable: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3306
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Ready: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mReady:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3307
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "CgroupV2: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isCgroupV2()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3308
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "serviceBumpUnFzRestricted: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 3309
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->serviceBumpUnFzReasonListSize()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_6e

    const/4 v1, 0x1

    goto :goto_6f

    :cond_6e
    move v1, v2

    :goto_6f
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3308
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3310
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "chinaModel: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/oplus/content/OplusFeatureConfigManager;->getInstance()Lcom/oplus/content/OplusFeatureConfigManager;

    move-result-object v1

    const-string/jumbo v3, "oplus.software.hans_restriction"

    invoke-virtual {v1, v3}, Lcom/oplus/content/OplusFeatureConfigManager;->hasFeature(Ljava/lang/String;)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3312
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "sIsAgingVersion: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-boolean v1, Lcom/android/server/am/OplusOsenseKillAction;->sIsAgingVersion:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3313
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "qbMode: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mQuickBoot:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3314
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "lastValidScanTime: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanTime:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3315
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LastValidScanAvailMem: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastValidScanAvailMem:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3316
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "InvalidKillCnt: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3317
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LastInvalidKillTime: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3318
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LastPurposeMemMB: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastPurposeMemMB:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3319
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "NumLastCachedProcesses: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mNumLastCachedProcesses:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3320
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "handlerThreadTid: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3321
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "total: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getMemInfoTotalGB()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 3322
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getTotalProcMemInfoGB()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3321
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3323
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "osvelte available: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/MemUtil;->isOSvelteAvailable()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3324
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "mem monitor exist: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/android/server/am/MemUtil;->isMemMonitorExist()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3325
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "proactive_clean: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mContext:Landroid/content/Context;

    .line 3326
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    .line 3325
    const-string v3, "athena.kill.proactive_clean"

    invoke-static {v1, v3, v2}, Lcom/oplus/content/AppfeatureHelper;->getBoolean(Landroid/content/ContentResolver;Ljava/lang/String;Z)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3327
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LastStartActivityUid: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3328
    return-void
.end method

.method private printWhiteList(Ljava/io/PrintWriter;)V
    .registers 9
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3285
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 3286
    .local v0, "whitelist":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v1

    .line 3287
    :try_start_b
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mDeviceIdleAllowlist:[I

    array-length v3, v2

    const/4 v4, 0x0

    :goto_11
    if-ge v4, v3, :cond_20

    aget v5, v2, v4

    .line 3288
    .local v5, "val":I
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 3287
    nop

    .end local v5    # "val":I
    add-int/lit8 v4, v4, 0x1

    goto :goto_11

    .line 3290
    :cond_20
    monitor-exit v1
    :try_end_21
    .catchall {:try_start_b .. :try_end_21} :catchall_7d

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3291
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_28
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 3292
    .local v2, "uid":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uid:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3293
    const/4 v3, 0x0

    .line 3295
    .local v3, "pkgNames":[Ljava/lang/String;
    :try_start_50
    invoke-static {}, Landroid/app/AppGlobals;->getPackageManager()Landroid/content/pm/IPackageManager;

    move-result-object v4

    invoke-interface {v4, v2}, Landroid/content/pm/IPackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v4
    :try_end_58
    .catch Landroid/os/RemoteException; {:try_start_50 .. :try_end_58} :catch_5a

    move-object v3, v4

    .line 3298
    goto :goto_5b

    .line 3296
    :catch_5a
    move-exception v4

    .line 3299
    :goto_5b
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "    pkg:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    if-eqz v3, :cond_6d

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    goto :goto_70

    :cond_6d
    const-string/jumbo v5, "unknown"

    :goto_70
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3300
    .end local v2    # "uid":I
    .end local v3    # "pkgNames":[Ljava/lang/String;
    goto :goto_28

    .line 3301
    :cond_7c
    return-void

    .line 3290
    :catchall_7d
    move-exception v2

    :try_start_7e
    monitor-exit v1
    :try_end_7f
    .catchall {:try_start_7e .. :try_end_7f} :catchall_7d

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v2
.end method

.method private recentlyActiveProcess(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z
    .registers 15
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "startTime"    # J
    .param p4, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1972
    invoke-virtual {p4}, Lcom/android/server/am/ProcessInfo;->isFreezeStable()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_13

    .line 1973
    const-string v0, "%s been freeze stable, we can skip check active time"

    filled-new-array {p4}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "KillAction"

    invoke-static {v3, v0, v2}, Lcom/android/server/am/LogUtil;->formatV(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1974
    return v1

    .line 1977
    :cond_13
    invoke-virtual {p4}, Lcom/android/server/am/ProcessInfo;->getLastActivityTime()J

    move-result-wide v2

    sub-long v2, p2, v2

    .line 1979
    .local v2, "lastUseTime":J
    const-wide/16 v4, 0x1

    .line 1980
    .local v4, "multiplier":J
    iget v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->contextType:I

    const/4 v6, 0x3

    if-ne v0, v6, :cond_2e

    iget-boolean v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanOnly:Z

    if-eqz v0, :cond_2e

    iget v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    if-ne v0, v6, :cond_2e

    .line 1982
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->getNirvanaInactiveThresholdMultiplier()J

    move-result-wide v4

    .line 1984
    :cond_2e
    iget v0, p4, Lcom/android/server/am/ProcessInfo;->mCurProcState:I

    const/16 v6, 0xa

    const/4 v7, 0x1

    if-ne v0, v6, :cond_53

    iget-object v0, p4, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-boolean v0, v0, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-eqz v0, :cond_53

    .line 1985
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->checkLongTimeStartedService()Z

    move-result v0

    if-nez v0, :cond_44

    .line 1986
    return v7

    .line 1990
    :cond_44
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    iget-boolean v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    invoke-virtual {v0, v6}, Lcom/android/server/am/ConfigUtil;->getSystemInactiveMsThresHold(Z)J

    move-result-wide v8

    mul-long/2addr v8, v4

    cmp-long v0, v2, v8

    if-gez v0, :cond_52

    move v1, v7

    :cond_52
    return v1

    .line 1992
    :cond_53
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    iget-boolean v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    invoke-virtual {v0, v6}, Lcom/android/server/am/ConfigUtil;->getInactiveMsThresHold(Z)J

    move-result-wide v8

    mul-long/2addr v8, v4

    cmp-long v0, v2, v8

    if-gez v0, :cond_61

    move v1, v7

    :cond_61
    return v1
.end method

.method private reportKillDetailInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 7
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 961
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 962
    .local v0, "bundle":Landroid/os/Bundle;
    const-string v1, "data_sync_flag_key"

    const-string v2, "clear_detail_info_flag"

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 963
    const-string v1, "ClearType"

    const/16 v2, 0x400

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 964
    iget-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const-string v2, "KillCnt"

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 965
    const-string v1, "SkipCnt"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 966
    const-string v1, "PreMemSizeMB"

    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startAvailMB:J

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 967
    const-string v1, "ReclaimMemSizeMB"

    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 968
    const-string v1, "PrepareDurationMs"

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getPrepareDurMs()I

    move-result v3

    invoke-virtual {v0, v1, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 969
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getScanDurMs()I

    move-result v1

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getKillDurMs()I

    move-result v3

    add-int/2addr v1, v3

    const-string v3, "KillDurationMs"

    invoke-virtual {v0, v3, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 970
    const-string v1, "FinishDurationMs"

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 971
    const-string v1, "TotalDurationMs"

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getTotalDurMs()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 972
    invoke-direct {p0, v0}, Lcom/android/server/am/OplusOsenseKillAction;->notifySysState(Landroid/os/Bundle;)V

    .line 973
    return-void
.end method

.method private reportToOsenseLogger(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 12
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 926
    iget v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->requestId:I

    if-gez v0, :cond_12

    const-string/jumbo v0, "nirvana"

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    .line 927
    return-void

    .line 929
    :cond_12
    const-string/jumbo v0, "reportToOsenseLogger"

    const-wide/16 v1, 0x40

    invoke-static {v1, v2, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 930
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 931
    .local v0, "policyInfo":Ljava/lang/StringBuilder;
    new-instance v3, Landroid/util/ArraySet;

    invoke-direct {v3}, Landroid/util/ArraySet;-><init>()V

    .line 932
    .local v3, "killUids":Landroid/util/ArraySet;, "Landroid/util/ArraySet<Ljava/lang/Integer;>;"
    iget-object v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2a
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_42

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ProcessInfo;

    .line 933
    .local v5, "killedPi":Lcom/android/server/am/ProcessInfo;
    iget-object v6, v5, Lcom/android/server/am/ProcessInfo;->info:Landroid/content/pm/ApplicationInfo;

    iget v6, v6, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/util/ArraySet;->add(Ljava/lang/Object;)Z

    .line 934
    .end local v5    # "killedPi":Lcom/android/server/am/ProcessInfo;
    goto :goto_2a

    .line 935
    :cond_42
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 936
    .local v4, "stageTime":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processGroupDurMs:I

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->updateStatusDurMs:I

    add-int/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 937
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cchCheckDurMs:I

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->nonUiCheckDurMs:I

    add-int/2addr v5, v6

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCheckDurMs:I

    add-int/2addr v5, v6

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->oomCheckDurMs:I

    add-int/2addr v5, v6

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->killDurMs:I

    add-int/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 939
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 940
    iget-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endUpTime:J

    iget-wide v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    sub-long/2addr v5, v7

    long-to-int v5, v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 942
    const-string v5, "REASON: Atomic-Clean name: "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 943
    const-string v5, " type: "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->type:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 944
    const-string v5, " scene: "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->scene:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 945
    invoke-virtual {v3}, Landroid/util/ArraySet;->isEmpty()Z

    move-result v5

    const/16 v6, 0x20

    if-nez v5, :cond_b6

    .line 946
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "KILL"

    invoke-direct {p0, v7, v3}, Lcom/android/server/am/OplusOsenseKillAction;->makeString(Ljava/lang/String;Ljava/util/Collection;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 948
    :cond_b6
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_c9

    .line 949
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "TIME"

    invoke-direct {p0, v6, v4}, Lcom/android/server/am/OplusOsenseKillAction;->makeString(Ljava/lang/String;Ljava/util/Collection;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 951
    :cond_c9
    const-string v5, " RES:["

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 952
    const/16 v6, 0x2c

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedRssMB:J

    invoke-virtual {v5, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 953
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const/16 v6, 0x5d

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 955
    invoke-static {}, Lcom/android/server/oplus/osense/logger/nrtfeature/appmng/AppMngLog;->getInstance()Lcom/android/server/oplus/osense/logger/nrtfeature/appmng/AppMngLog;

    move-result-object v5

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->requestId:I

    .line 956
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 955
    const/4 v8, 0x1

    const-string/jumbo v9, "kill"

    invoke-virtual {v5, v6, v8, v9, v7}, Lcom/android/server/oplus/osense/logger/nrtfeature/appmng/AppMngLog;->addOSensePolicyInfo(IILjava/lang/String;Ljava/lang/String;)V

    .line 957
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 958
    return-void
.end method

.method private resetInvalidKill()V
    .registers 3

    .line 830
    const/4 v0, 0x0

    iput v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInvalidKillCnt:I

    .line 831
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastInvalidKillTime:J

    .line 832
    return-void
.end method

.method private resortInactiveTaskApp([Lcom/android/server/am/ProcessGroup;Ljava/util/Comparator;)V
    .registers 8
    .param p1, "mruAllGroups"    # [Lcom/android/server/am/ProcessGroup;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/android/server/am/ProcessGroup;",
            "Ljava/util/Comparator<",
            "Lcom/android/server/am/ProcessGroup;",
            ">;)V"
        }
    .end annotation

    .line 1372
    .local p2, "c":Ljava/util/Comparator;, "Ljava/util/Comparator<Lcom/android/server/am/ProcessGroup;>;"
    const/4 v0, -0x1

    .local v0, "start":I
    array-length v1, p1

    .line 1373
    .local v1, "end":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_3
    array-length v3, p1

    const/4 v4, -0x1

    if-ge v2, v3, :cond_25

    .line 1374
    if-eq v0, v4, :cond_d

    array-length v3, p1

    if-eq v1, v3, :cond_d

    .line 1375
    goto :goto_25

    .line 1377
    :cond_d
    aget-object v3, p1, v2

    .line 1378
    .local v3, "group":Lcom/android/server/am/ProcessGroup;
    if-ne v0, v4, :cond_18

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v4

    if-eqz v4, :cond_18

    .line 1379
    move v0, v2

    .line 1381
    :cond_18
    array-length v4, p1

    if-ne v1, v4, :cond_22

    invoke-virtual {v3}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v4

    if-eqz v4, :cond_22

    .line 1382
    move v1, v2

    .line 1373
    .end local v3    # "group":Lcom/android/server/am/ProcessGroup;
    :cond_22
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .line 1385
    .end local v2    # "i":I
    :cond_25
    :goto_25
    if-eq v0, v4, :cond_2a

    .line 1386
    invoke-static {p1, v0, v1, p2}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    .line 1388
    :cond_2a
    return-void
.end method

.method private saveToHistory(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 8
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 894
    const-string/jumbo v0, "saveToHistory"

    const-wide/16 v1, 0x40

    invoke-static {v1, v2, v0}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 895
    new-instance v0, Lcom/android/server/am/KillInfo;

    invoke-direct {v0}, Lcom/android/server/am/KillInfo;-><init>()V

    .line 896
    .local v0, "ki":Lcom/android/server/am/KillInfo;
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->requestId:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->requestId:I

    .line 897
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startAvailMB:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->startAvailMB:J

    .line 898
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    int-to-long v3, v3

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->purposeMB:J

    .line 899
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedAnonRssMB:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->reclaimedMB:J

    .line 900
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->reclaimedSwapMB:J

    .line 901
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseSwapMB:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->purposeReleaseSwapMB:J

    .line 902
    iget-object v3, v0, Lcom/android/server/am/KillInfo;->killedList:Ljava/util/List;

    iget-object v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->allKilledList:Ljava/util/List;

    invoke-interface {v3, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 903
    iget-object v3, v0, Lcom/android/server/am/KillInfo;->killedList:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_33
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_43

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessInfo;

    .line 904
    .local v4, "pi":Lcom/android/server/am/ProcessInfo;
    invoke-virtual {v4}, Lcom/android/server/am/ProcessInfo;->trim()V

    .line 905
    .end local v4    # "pi":Lcom/android/server/am/ProcessInfo;
    goto :goto_33

    .line 907
    :cond_43
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->startTime:J

    .line 908
    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endUpTime:J

    iput-wide v3, v0, Lcom/android/server/am/KillInfo;->endTime:J

    .line 910
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->updateStatusDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->updateStatusDurMs:I

    .line 911
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processGroupDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->processGroupDurMs:I

    .line 912
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cchCheckDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->cchCheckDurMs:I

    .line 913
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->nonUiCheckDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->nonUiCheckDurMs:I

    .line 914
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->oomCheckDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->oomCheckDurMs:I

    .line 915
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCheckDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->groupCheckDurMs:I

    .line 916
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->killDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->killDurMs:I

    .line 917
    iget v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->monitorWaitDurMs:I

    iput v3, v0, Lcom/android/server/am/KillInfo;->monitorWaitDurMs:I

    .line 918
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    monitor-enter v3

    .line 919
    :try_start_6e
    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    iget v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistoryIdx:I

    aput-object v0, v4, v5

    .line 920
    iget v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistoryIdx:I

    add-int/lit8 v4, v4, 0x1

    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistory:[Lcom/android/server/am/KillInfo;

    array-length v5, v5

    rem-int/2addr v4, v5

    iput v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHistoryIdx:I

    .line 921
    monitor-exit v3
    :try_end_7f
    .catchall {:try_start_6e .. :try_end_7f} :catchall_83

    .line 922
    invoke-static {v1, v2}, Landroid/os/Trace;->traceEnd(J)V

    .line 923
    return-void

    .line 921
    :catchall_83
    move-exception v1

    :try_start_84
    monitor-exit v3
    :try_end_85
    .catchall {:try_start_84 .. :try_end_85} :catchall_83

    throw v1
.end method

.method private scan(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 3
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 2604
    const/4 v0, 0x3

    iput v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 2605
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->scanCchEmptyProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2606
    const/4 v0, 0x4

    iput v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 2607
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->scanNonUiProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2608
    const/4 v0, 0x5

    iput v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 2609
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->scanOomAdjIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2610
    const/4 v0, 0x6

    iput v0, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->currentStage:I

    .line 2611
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->scanAllProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2612
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->checkIsolatedProcess(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2613
    return-void
.end method

.method private scanAllProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 22
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 1268
    move-object/from16 v1, p1

    const-string/jumbo v6, "scanAllProc"

    .line 1269
    .local v6, "TAG":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v0

    const-string/jumbo v7, "scanAllProc"

    if-eqz v0, :cond_2a

    .line 1270
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "skip scan all proc for "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1271
    return-void

    .line 1273
    :cond_2a
    const/4 v0, 0x3

    iget v2, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->contextType:I

    if-ne v0, v2, :cond_31

    const/4 v0, 0x1

    goto :goto_32

    :cond_31
    const/4 v0, 0x0

    :goto_32
    move v9, v0

    .line 1274
    .local v9, "nirvana":Z
    if-eqz v9, :cond_49

    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->bgAppMismatch()Z

    move-result v0

    if-eqz v0, :cond_49

    .line 1275
    const-string/jumbo v0, "oops, bg app monitor get messed up"

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1276
    invoke-static {}, Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;->getInstance()Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/oplus/osense/memory/nirvana/NirvanaManager;->onBgAppMonitorReset()V

    .line 1277
    return-void

    .line 1279
    :cond_49
    const-wide/16 v10, 0x40

    invoke-static {v10, v11, v7}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 1280
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    .line 1281
    .local v4, "start":J
    iput-wide v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curStageStartUpTime:J

    .line 1282
    const-string v0, "----------start check all proc---------------"

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1283
    invoke-direct/range {p0 .. p0}, Lcom/android/server/am/OplusOsenseKillAction;->getGameService()Lcom/android/server/app/IGameManagerServiceExt;

    move-result-object v3

    .line 1285
    .local v3, "gms":Lcom/android/server/app/IGameManagerServiceExt;
    iget-object v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v0

    new-instance v2, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda5;

    invoke-direct {v2}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda5;-><init>()V

    .line 1286
    invoke-interface {v0, v2}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v0

    invoke-static {}, Ljava/util/stream/Collectors;->toList()Ljava/util/stream/Collector;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/util/List;

    .line 1287
    .local v12, "mruAllGroups":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    iget v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    if-lez v0, :cond_81

    .line 1288
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_RECENT_APP_RULE:Ljava/util/Comparator;

    invoke-interface {v12, v0}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    goto :goto_9e

    .line 1289
    :cond_81
    iget-boolean v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->isUrgency:Z

    if-nez v0, :cond_93

    iget-boolean v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->handlingBlast:Z

    if-nez v0, :cond_93

    iget-object v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cpuHoggingPids:Ljava/util/Set;

    .line 1290
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_93

    if-eqz v9, :cond_9e

    .line 1291
    :cond_93
    const-string/jumbo v0, "sort by ui fz mem"

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1292
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_CPU_UI_FZ_MEM:Ljava/util/Comparator;

    invoke-interface {v12, v0}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 1295
    :cond_9e
    :goto_9e
    iget v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    .line 1296
    .local v0, "minBgCount":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    move-object v13, v2

    .line 1297
    .local v13, "mruPendingKillList":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    const/4 v2, 0x0

    move v14, v0

    move v15, v2

    .end local v0    # "minBgCount":I
    .local v14, "minBgCount":I
    .local v15, "i":I
    :goto_a9
    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v0

    if-ge v15, v0, :cond_143

    .line 1298
    invoke-interface {v12, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/android/server/am/ProcessGroup;

    .line 1299
    .local v2, "group":Lcom/android/server/am/ProcessGroup;
    invoke-static {}, Lcom/android/server/am/LogUtil;->logVerbose()Z

    move-result v0

    if-eqz v0, :cond_e3

    .line 1300
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v16, 0x1

    const-string v8, "all#"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, " "

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->v(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_e5

    .line 1299
    :cond_e3
    const/16 v16, 0x1

    .line 1303
    :goto_e5
    const/4 v8, 0x0

    .line 1304
    .local v8, "skipType":Ljava/lang/String;
    iget v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    if-lez v0, :cond_f3

    .line 1305
    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lcom/android/server/am/OplusOsenseKillAction;->getAllProcCheckSkipTypeForRecentBgApp(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Lcom/android/server/app/IGameManagerServiceExt;J)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v1, p1

    goto :goto_fb

    .line 1308
    :cond_f3
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v5}, Lcom/android/server/am/OplusOsenseKillAction;->getAllProcCheckSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Lcom/android/server/app/IGameManagerServiceExt;J)Ljava/lang/String;

    move-result-object v8

    .line 1311
    :goto_fb
    if-eqz v8, :cond_138

    .line 1313
    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v0

    if-nez v0, :cond_132

    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->activityPackage()Z

    move-result v0

    if-eqz v0, :cond_132

    .line 1314
    invoke-static {}, Lcom/android/server/oplus/osense/logger/OsenseLogger;->isDebugLog()Z

    move-result v0

    if-eqz v0, :cond_12d

    .line 1315
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-wide/from16 v17, v10

    const-string/jumbo v10, "remove skipped bg: "

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->v(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_12f

    .line 1314
    :cond_12d
    move-wide/from16 v17, v10

    .line 1317
    :goto_12f
    add-int/lit8 v14, v14, -0x1

    goto :goto_134

    .line 1313
    :cond_132
    move-wide/from16 v17, v10

    .line 1319
    :goto_134
    invoke-virtual {v1, v7, v2, v8}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->printSkipLog(Ljava/lang/String;Lcom/android/server/am/ProcessGroup;Ljava/lang/String;)V

    .line 1320
    goto :goto_13d

    .line 1322
    :cond_138
    move-wide/from16 v17, v10

    invoke-interface {v13, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1297
    .end local v2    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v8    # "skipType":Ljava/lang/String;
    :goto_13d
    add-int/lit8 v15, v15, 0x1

    move-wide/from16 v10, v17

    goto/16 :goto_a9

    :cond_143
    move-wide/from16 v17, v10

    const/16 v16, 0x1

    .line 1325
    .end local v15    # "i":I
    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 1326
    .local v0, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    :goto_14b
    if-lez v14, :cond_18c

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_18c

    .line 1327
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/ProcessGroup;

    .line 1328
    .restart local v2    # "group":Lcom/android/server/am/ProcessGroup;
    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v8

    if-nez v8, :cond_18b

    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->activityPackage()Z

    move-result v8

    if-eqz v8, :cond_18b

    .line 1329
    add-int/lit8 v14, v14, -0x1

    .line 1330
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    .line 1331
    invoke-static {}, Lcom/android/server/oplus/osense/logger/OsenseLogger;->isDebugLog()Z

    move-result v8

    if-eqz v8, :cond_18b

    .line 1332
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "remove excepted bg: "

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v2}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Lcom/android/server/am/LogUtil;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 1335
    .end local v2    # "group":Lcom/android/server/am/ProcessGroup;
    :cond_18b
    goto :goto_14b

    .line 1337
    :cond_18c
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getGroupCleanReason()Ljava/lang/String;

    move-result-object v2

    .line 1338
    .local v2, "reason":Ljava/lang/String;
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v8

    add-int/lit8 v8, v8, -0x1

    .local v8, "i":I
    :goto_196
    if-ltz v8, :cond_1e8

    .line 1339
    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/android/server/am/ProcessGroup;

    .line 1340
    .local v10, "group":Lcom/android/server/am/ProcessGroup;
    const/4 v11, 0x0

    .line 1341
    .local v11, "add":Z
    const/4 v15, 0x0

    .local v15, "j":I
    :goto_1a0
    move-object/from16 v16, v0

    .end local v0    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    .local v16, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    iget-object v0, v10, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v15, v0, :cond_1ce

    .line 1342
    iget-object v0, v10, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v0, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/ProcessInfo;

    .line 1343
    .local v0, "pi":Lcom/android/server/am/ProcessInfo;
    move-object/from16 v19, v3

    .end local v3    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    .local v19, "gms":Lcom/android/server/app/IGameManagerServiceExt;
    iget-object v3, v0, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-eqz v3, :cond_1b9

    .line 1344
    goto :goto_1c7

    .line 1346
    :cond_1b9
    invoke-virtual {v0}, Lcom/android/server/am/ProcessInfo;->isProtectProcess()Z

    move-result v3

    if-eqz v3, :cond_1c0

    .line 1347
    goto :goto_1c7

    .line 1350
    :cond_1c0
    const/4 v3, 0x0

    iput-object v3, v0, Lcom/android/server/am/ProcessInfo;->mSkipReason:Ljava/lang/String;

    .line 1351
    iput-object v2, v0, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    .line 1352
    const/4 v3, 0x1

    move v11, v3

    .line 1341
    .end local v0    # "pi":Lcom/android/server/am/ProcessInfo;
    :goto_1c7
    add-int/lit8 v15, v15, 0x1

    move-object/from16 v0, v16

    move-object/from16 v3, v19

    goto :goto_1a0

    .end local v19    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    .restart local v3    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    :cond_1ce
    move-object/from16 v19, v3

    .line 1354
    .end local v3    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    .end local v15    # "j":I
    .restart local v19    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    if-eqz v11, :cond_1d5

    .line 1355
    invoke-virtual {v1, v10, v2}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToGroupCleanList(Lcom/android/server/am/ProcessGroup;Ljava/lang/String;)V

    .line 1357
    :cond_1d5
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v0

    if-eqz v0, :cond_1e1

    .line 1358
    const-string v0, "break check all proc for enough memory"

    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1359
    goto :goto_1ec

    .line 1338
    .end local v10    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v11    # "add":Z
    :cond_1e1
    add-int/lit8 v8, v8, -0x1

    move-object/from16 v0, v16

    move-object/from16 v3, v19

    goto :goto_196

    .end local v16    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    .end local v19    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    .local v0, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    .restart local v3    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    :cond_1e8
    move-object/from16 v16, v0

    move-object/from16 v19, v3

    .line 1363
    .end local v0    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    .end local v3    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    .end local v8    # "i":I
    .restart local v16    # "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Lcom/android/server/am/ProcessGroup;>;"
    .restart local v19    # "gms":Lcom/android/server/app/IGameManagerServiceExt;
    :goto_1ec
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    sub-long/2addr v10, v4

    long-to-int v0, v10

    iput v0, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCheckDurMs:I

    .line 1364
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "done check all group, killablePss="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v10, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanKillablePss:J

    invoke-virtual {v0, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v3, "kb, killableAnonRss="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v10, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanKillableAnonRssMB:J

    invoke-virtual {v0, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v3, "mb, time: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCheckDurMs:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v3, "ms, candidate group cnt:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->groupCleanCandidateLruList:Ljava/util/List;

    .line 1367
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1364
    invoke-static {v7, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1368
    invoke-static/range {v17 .. v18}, Landroid/os/Trace;->traceEnd(J)V

    .line 1369
    return-void
.end method

.method private scanApp(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 14
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3135
    move v0, p3

    .line 3136
    .local v0, "opti":I
    array-length v1, p2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ge v0, v1, :cond_13

    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v0, p2, v0

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_12

    move v0, v3

    goto :goto_15

    :cond_12
    move v0, v1

    .end local v1    # "opti":I
    .restart local v0    # "opti":I
    :cond_13
    move v1, v0

    move v0, v2

    .line 3137
    .local v0, "adjCheck":Z
    .restart local v1    # "opti":I
    :goto_15
    array-length v4, p2

    if-ge v1, v4, :cond_25

    add-int/lit8 v4, v1, 0x1

    .end local v1    # "opti":I
    .local v4, "opti":I
    aget-object v1, p2, v1

    invoke-static {v1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_24

    move v1, v3

    goto :goto_27

    :cond_24
    move v1, v4

    .end local v4    # "opti":I
    .restart local v1    # "opti":I
    :cond_25
    move v4, v1

    move v1, v2

    .line 3138
    .local v1, "groupCheck":Z
    .restart local v4    # "opti":I
    :goto_27
    array-length v5, p2

    if-ge v4, v5, :cond_36

    add-int/lit8 v5, v4, 0x1

    .end local v4    # "opti":I
    .local v5, "opti":I
    aget-object v4, p2, v4

    invoke-static {v4}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_35

    goto :goto_38

    :cond_35
    move v4, v5

    .end local v5    # "opti":I
    .restart local v4    # "opti":I
    :cond_36
    move v3, v2

    move v5, v4

    .line 3139
    .end local v4    # "opti":I
    .local v3, "handlingBlast":Z
    .restart local v5    # "opti":I
    :goto_38
    array-length v4, p2

    if-ge v5, v4, :cond_44

    add-int/lit8 v4, v5, 0x1

    .end local v5    # "opti":I
    .restart local v4    # "opti":I
    aget-object v5, p2, v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    goto :goto_46

    .end local v4    # "opti":I
    .restart local v5    # "opti":I
    :cond_44
    move v4, v5

    move v5, v2

    .line 3141
    .restart local v4    # "opti":I
    .local v5, "releaseTarget":I
    :goto_46
    new-instance v6, Landroid/os/Bundle;

    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 3142
    .local v6, "extra":Landroid/os/Bundle;
    invoke-direct {p0, v6, v2}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v2

    .line 3143
    .local v2, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    iput-wide v7, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    .line 3144
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    iput-wide v7, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startCurrent:J

    .line 3145
    iput-boolean v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->handlingBlast:Z

    .line 3147
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3148
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3149
    iget-object v7, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v7

    .line 3150
    :try_start_69
    new-instance v8, Ljava/util/ArrayList;

    iget-object v9, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v9, v9, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v9}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v2, v8}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 3151
    monitor-exit v7
    :try_end_7a
    .catchall {:try_start_69 .. :try_end_7a} :catchall_94

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3152
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->scanCchEmptyProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3153
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->scanNonUiProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3154
    if-eqz v0, :cond_88

    .line 3155
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->scanOomAdjIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3157
    :cond_88
    if-eqz v1, :cond_8d

    .line 3158
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->scanAllProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3161
    :cond_8d
    invoke-direct {p0, p1, v2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->printPart1(Ljava/io/PrintWriter;Lcom/android/server/am/OplusOsenseKillAction$KillContext;Z)V

    .line 3162
    invoke-direct {p0, p1, v2, v5}, Lcom/android/server/am/OplusOsenseKillAction;->printPart2(Ljava/io/PrintWriter;Lcom/android/server/am/OplusOsenseKillAction$KillContext;I)V

    .line 3163
    return-void

    .line 3151
    :catchall_94
    move-exception v8

    :try_start_95
    monitor-exit v7
    :try_end_96
    .catchall {:try_start_95 .. :try_end_96} :catchall_94

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v8
.end method

.method private scanCchEmptyProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 17
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 1604
    move-object/from16 v0, p1

    const-string/jumbo v7, "scanCchEmptyProc"

    .line 1605
    .local v7, "TAG":Ljava/lang/String;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 1606
    .local v3, "start":J
    iput-wide v3, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curStageStartUpTime:J

    .line 1607
    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v1

    if-eqz v1, :cond_3b

    .line 1608
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "skip scan cch empty for "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", avail="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 1609
    invoke-static {}, Lcom/android/server/oplus/osense/utils/MemoryReaderUtils;->getAvailMemoryMB()J

    move-result-wide v5

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1608
    invoke-static {v7, v1}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1610
    return-void

    .line 1612
    :cond_3b
    const-wide/16 v8, 0x40

    invoke-static {v8, v9, v7}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 1613
    const-string v1, "Cached"

    invoke-virtual {v0, v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getAtomicCleanReason(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 1614
    .local v10, "reason":Ljava/lang/String;
    new-instance v5, Landroid/util/ArraySet;

    invoke-direct {v5}, Landroid/util/ArraySet;-><init>()V

    .line 1615
    .local v5, "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    new-instance v6, Landroid/util/ArraySet;

    invoke-direct {v6}, Landroid/util/ArraySet;-><init>()V

    .line 1617
    .local v6, "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    iget-object v1, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    move v11, v1

    .local v11, "i":I
    :goto_59
    if-ltz v11, :cond_9c

    .line 1618
    iget-object v1, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v1, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lcom/android/server/am/ProcessInfo;

    .line 1619
    .local v2, "pi":Lcom/android/server/am/ProcessInfo;
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v1

    const-string v12, "cch#%d: %s"

    invoke-static {v7, v12, v1}, Lcom/android/server/am/LogUtil;->formatV(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1620
    move-object v1, v0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lcom/android/server/am/OplusOsenseKillAction;->getCchEmptyCheckSkipReason(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;JLjava/util/Set;Ljava/util/Set;)Ljava/lang/String;

    move-result-object v12

    .line 1622
    move-object v13, v5

    move-object v14, v6

    .end local v5    # "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .end local v6    # "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .local v12, "skipReason":Ljava/lang/String;
    .local v13, "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .local v14, "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    if-eqz v12, :cond_83

    .line 1623
    move-object/from16 v0, p1

    move-object v1, v7

    move-object v5, v12

    .end local v7    # "TAG":Ljava/lang/String;
    .end local v12    # "skipReason":Ljava/lang/String;
    .local v1, "TAG":Ljava/lang/String;
    .local v5, "skipReason":Ljava/lang/String;
    invoke-virtual/range {v0 .. v5}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->printSkipLog(Ljava/lang/String;Lcom/android/server/am/ProcessInfo;JLjava/lang/String;)V

    .line 1624
    goto :goto_96

    .line 1628
    .end local v1    # "TAG":Ljava/lang/String;
    .end local v5    # "skipReason":Ljava/lang/String;
    .restart local v7    # "TAG":Ljava/lang/String;
    .restart local v12    # "skipReason":Ljava/lang/String;
    :cond_83
    move-object/from16 v0, p1

    move-object v1, v7

    move-object v5, v12

    .end local v7    # "TAG":Ljava/lang/String;
    .end local v12    # "skipReason":Ljava/lang/String;
    .restart local v1    # "TAG":Ljava/lang/String;
    .restart local v5    # "skipReason":Ljava/lang/String;
    invoke-virtual {v0, v2, v10}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1629
    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v7

    if-eqz v7, :cond_96

    .line 1630
    const-string v7, "break cch check for enough killable memory"

    invoke-static {v1, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1631
    goto :goto_9f

    .line 1617
    .end local v2    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v5    # "skipReason":Ljava/lang/String;
    :cond_96
    :goto_96
    add-int/lit8 v11, v11, -0x1

    move-object v7, v1

    move-object v5, v13

    move-object v6, v14

    goto :goto_59

    .end local v1    # "TAG":Ljava/lang/String;
    .end local v13    # "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .end local v14    # "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .local v5, "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .restart local v6    # "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .restart local v7    # "TAG":Ljava/lang/String;
    :cond_9c
    move-object v13, v5

    move-object v14, v6

    move-object v1, v7

    .line 1634
    .end local v5    # "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .end local v6    # "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .end local v7    # "TAG":Ljava/lang/String;
    .end local v11    # "i":I
    .restart local v1    # "TAG":Ljava/lang/String;
    .restart local v13    # "reCheckProviderApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    .restart local v14    # "reCheckServiceApps":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    :goto_9f
    const-string v2, "+++++++ start double check +++++++"

    invoke-static {v1, v2}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1635
    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v2

    if-nez v2, :cond_ad

    .line 1636
    invoke-direct {p0, v0, v14, v10}, Lcom/android/server/am/OplusOsenseKillAction;->checkBindEachOther(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/Set;Ljava/lang/String;)V

    .line 1638
    :cond_ad
    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v2

    if-nez v2, :cond_c0

    .line 1639
    invoke-direct {p0, v0, v13, v10}, Lcom/android/server/am/OplusOsenseKillAction;->checkProviderClientKillable(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/Set;Ljava/lang/String;)Ljava/util/Set;

    move-result-object v2

    .line 1640
    .local v2, "bindEachOtherList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    invoke-virtual {v0}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v5

    if-nez v5, :cond_c0

    .line 1641
    invoke-direct {p0, v0, v2, v10}, Lcom/android/server/am/OplusOsenseKillAction;->checkBindEachOther(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/Set;Ljava/lang/String;)V

    .line 1646
    .end local v2    # "bindEachOtherList":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessInfo;>;"
    :cond_c0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v11

    sub-long/2addr v11, v3

    long-to-int v2, v11

    iput v2, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cchCheckDurMs:I

    .line 1647
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "cch check done: killablePss="

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v11, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanKillablePss:J

    invoke-virtual {v2, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v5, "kb, killableAnonRss="

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v11, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanKillableAnonRssMB:J

    invoke-virtual {v2, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v5, "mb, time="

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v5, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cchCheckDurMs:I

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v5, "ms, candidate cnt: "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v5, v0, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cachedCleanCandidateLruList:Ljava/util/List;

    .line 1650
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1647
    invoke-static {v1, v2}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1651
    invoke-static {v8, v9}, Landroid/os/Trace;->traceEnd(J)V

    .line 1652
    return-void
.end method

.method private scanForSimulateKill(Ljava/io/PrintWriter;[Ljava/lang/String;ILcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/lang/String;)V
    .registers 11
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I
    .param p4, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p5, "type"    # Ljava/lang/String;

    .line 3233
    move v0, p3

    .line 3234
    .local v0, "opti":I
    const-string v1, "cch"

    invoke-virtual {v1, p5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 3235
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanCchEmptyProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    goto/16 :goto_79

    .line 3236
    :cond_e
    const-string/jumbo v1, "nonui"

    invoke-virtual {v1, p5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 3237
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanNonUiProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    goto/16 :goto_79

    .line 3238
    :cond_1c
    const-string v1, "adj"

    invoke-virtual {v1, p5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_28

    .line 3239
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanOomAdjIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    goto :goto_79

    .line 3240
    :cond_28
    const-string v1, "all"

    invoke-virtual {v1, p5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_73

    .line 3241
    array-length v1, p2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ge v0, v1, :cond_42

    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v0, p2, v0

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_41

    move v0, v3

    goto :goto_44

    :cond_41
    move v0, v1

    .end local v1    # "opti":I
    .restart local v0    # "opti":I
    :cond_42
    move v1, v0

    move v0, v2

    .line 3242
    .local v0, "adj":Z
    .restart local v1    # "opti":I
    :goto_44
    array-length v4, p2

    if-ge v1, v4, :cond_55

    add-int/lit8 v4, v1, 0x1

    .end local v1    # "opti":I
    .local v4, "opti":I
    aget-object v1, p2, v1

    invoke-static {v1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_54

    move v2, v3

    move v1, v4

    goto :goto_55

    :cond_54
    move v1, v4

    .line 3243
    .end local v4    # "opti":I
    .restart local v1    # "opti":I
    .local v2, "group":Z
    :cond_55
    :goto_55
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanCchEmptyProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3244
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanNonUiProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3245
    if-eqz v0, :cond_66

    invoke-virtual {p4}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v3

    if-nez v3, :cond_66

    .line 3246
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanOomAdjIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3248
    :cond_66
    if-eqz v2, :cond_71

    invoke-virtual {p4}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v3

    if-nez v3, :cond_71

    .line 3249
    invoke-direct {p0, p4}, Lcom/android/server/am/OplusOsenseKillAction;->scanAllProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3251
    .end local v0    # "adj":Z
    .end local v2    # "group":Z
    :cond_71
    move v0, v1

    goto :goto_79

    .line 3252
    .end local v1    # "opti":I
    .local v0, "opti":I
    :cond_73
    const-string/jumbo v1, "unknown kill type"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3254
    :goto_79
    return-void
.end method

.method private scanNonUiProcIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 25
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 1115
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string/jumbo v2, "scanNonUiProc"

    .line 1116
    .local v2, "TAG":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v3

    if-eqz v3, :cond_29

    .line 1117
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "skip scan non ui process for "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1118
    return-void

    .line 1120
    :cond_29
    const-wide/16 v7, 0x40

    invoke-static {v7, v8, v2}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 1121
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    .line 1122
    .local v4, "start":J
    const-wide/16 v9, 0x0

    .line 1123
    .local v9, "collectedPss":J
    const-wide/16 v11, 0x0

    .line 1124
    .local v11, "collectedAnonRssMB":J
    const/4 v3, 0x0

    .line 1125
    .local v3, "collectedProcNum":I
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansDBConfig;->serviceBumpUnFzReasonListSize()I

    move-result v6

    const/4 v13, 0x1

    if-lez v6, :cond_44

    move v6, v13

    goto :goto_45

    :cond_44
    const/4 v6, 0x0

    :goto_45
    move v14, v6

    .line 1126
    .local v14, "serviceBumpUnFzRestricted":Z
    const-string v6, "NonUi"

    invoke-virtual {v1, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getAtomicCleanReason(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 1127
    .local v15, "reason":Ljava/lang/String;
    iput-wide v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curStageStartUpTime:J

    .line 1129
    const-string v6, "----------start check non ui proc-----------"

    invoke-static {v2, v6}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1130
    iget-object v6, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v6

    move-wide/from16 v16, v7

    new-instance v7, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda1;

    invoke-direct {v7}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda1;-><init>()V

    .line 1131
    invoke-interface {v6, v7}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v6

    invoke-static {}, Ljava/util/stream/Collectors;->toList()Ljava/util/stream/Collector;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    check-cast v7, Ljava/util/List;

    .line 1132
    .local v7, "mruAllGroups":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    iget-object v6, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->cpuHoggingPids:Ljava/util/Set;

    invoke-interface {v6}, Ljava/util/Set;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_82

    .line 1133
    const-string/jumbo v6, "sort by ui fz mem"

    invoke-static {v2, v6}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1134
    sget-object v6, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_CPU_UI_FZ_MEM:Ljava/util/Comparator;

    invoke-interface {v7, v6}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 1138
    :cond_82
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v6

    sub-int/2addr v6, v13

    move v8, v6

    .local v8, "i":I
    :goto_88
    if-ltz v8, :cond_130

    .line 1139
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v13, v6

    check-cast v13, Lcom/android/server/am/ProcessGroup;

    .line 1140
    .local v13, "group":Lcom/android/server/am/ProcessGroup;
    invoke-static {}, Lcom/android/server/am/LogUtil;->logVerbose()Z

    move-result v6

    if-eqz v6, :cond_bf

    .line 1141
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v18, v3

    .end local v3    # "collectedProcNum":I
    .local v18, "collectedProcNum":I
    const-string/jumbo v3, "non-ui#"

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, ": "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v13}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->v(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_c1

    .line 1140
    .end local v18    # "collectedProcNum":I
    .restart local v3    # "collectedProcNum":I
    :cond_bf
    move/from16 v18, v3

    .line 1144
    .end local v3    # "collectedProcNum":I
    .restart local v18    # "collectedProcNum":I
    :goto_c1
    invoke-direct {v0, v1, v13, v14}, Lcom/android/server/am/OplusOsenseKillAction;->getNonUiCheckSkipType(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessGroup;Z)Ljava/lang/String;

    move-result-object v3

    .line 1145
    .local v3, "skipType":Ljava/lang/String;
    if-eqz v3, :cond_d0

    .line 1146
    invoke-virtual {v1, v2, v13, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->printSkipLog(Ljava/lang/String;Lcom/android/server/am/ProcessGroup;Ljava/lang/String;)V

    .line 1147
    move-wide/from16 v21, v4

    move/from16 v3, v18

    goto/16 :goto_12a

    .line 1149
    :cond_d0
    const/4 v6, 0x0

    move-wide/from16 v19, v11

    move-wide v10, v9

    move v9, v6

    .end local v11    # "collectedAnonRssMB":J
    .local v9, "j":I
    .local v10, "collectedPss":J
    .local v19, "collectedAnonRssMB":J
    :goto_d5
    iget-object v6, v13, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v9, v6, :cond_111

    .line 1150
    iget-object v6, v13, Lcom/android/server/am/ProcessGroup;->mProcs:Ljava/util/List;

    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessInfo;

    .line 1151
    .local v6, "pi":Lcom/android/server/am/ProcessInfo;
    iget-object v12, v6, Lcom/android/server/am/ProcessInfo;->mKilledReason:Ljava/lang/String;

    if-eqz v12, :cond_eb

    .line 1152
    move-object v12, v3

    goto :goto_f7

    .line 1154
    :cond_eb
    move-object v12, v3

    move-object v3, v6

    .end local v6    # "pi":Lcom/android/server/am/ProcessInfo;
    .local v3, "pi":Lcom/android/server/am/ProcessInfo;
    .local v12, "skipType":Ljava/lang/String;
    invoke-direct {v0, v1, v3}, Lcom/android/server/am/OplusOsenseKillAction;->getNonUiCheckSkipReason(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;)Ljava/lang/String;

    move-result-object v6

    .line 1155
    .local v6, "skipReason":Ljava/lang/String;
    if-eqz v6, :cond_fa

    .line 1156
    invoke-virtual/range {v1 .. v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->printSkipLog(Ljava/lang/String;Lcom/android/server/am/ProcessInfo;JLjava/lang/String;)V

    .line 1157
    nop

    .line 1149
    .end local v6    # "skipReason":Ljava/lang/String;
    .end local v12    # "skipType":Ljava/lang/String;
    .local v3, "skipType":Ljava/lang/String;
    :goto_f7
    move-wide/from16 v21, v4

    .end local v3    # "skipType":Ljava/lang/String;
    .restart local v12    # "skipType":Ljava/lang/String;
    goto :goto_10b

    .line 1159
    .local v3, "pi":Lcom/android/server/am/ProcessInfo;
    .restart local v6    # "skipReason":Ljava/lang/String;
    :cond_fa
    invoke-virtual {v1, v3, v15}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1160
    add-int/lit8 v18, v18, 0x1

    .line 1161
    invoke-virtual {v3}, Lcom/android/server/am/ProcessInfo;->getLastPss()J

    move-result-wide v21

    add-long v10, v10, v21

    .line 1162
    move-wide/from16 v21, v4

    .end local v4    # "start":J
    .local v21, "start":J
    iget-wide v4, v3, Lcom/android/server/am/ProcessInfo;->mAnonMemoryMB:J

    add-long v19, v19, v4

    .line 1149
    .end local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v6    # "skipReason":Ljava/lang/String;
    :goto_10b
    add-int/lit8 v9, v9, 0x1

    move-object v3, v12

    move-wide/from16 v4, v21

    goto :goto_d5

    .end local v12    # "skipType":Ljava/lang/String;
    .end local v21    # "start":J
    .local v3, "skipType":Ljava/lang/String;
    .restart local v4    # "start":J
    :cond_111
    move-object v12, v3

    move-wide/from16 v21, v4

    .line 1164
    .end local v3    # "skipType":Ljava/lang/String;
    .end local v4    # "start":J
    .end local v9    # "j":I
    .restart local v12    # "skipType":Ljava/lang/String;
    .restart local v21    # "start":J
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v3

    if-eqz v3, :cond_125

    .line 1165
    const-string v3, "break non ui check for enough killable memory"

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1166
    move-wide v9, v10

    move-wide/from16 v11, v19

    move/from16 v3, v18

    goto :goto_134

    .line 1164
    :cond_125
    move-wide v9, v10

    move-wide/from16 v11, v19

    move/from16 v3, v18

    .line 1138
    .end local v10    # "collectedPss":J
    .end local v12    # "skipType":Ljava/lang/String;
    .end local v13    # "group":Lcom/android/server/am/ProcessGroup;
    .end local v18    # "collectedProcNum":I
    .end local v19    # "collectedAnonRssMB":J
    .local v3, "collectedProcNum":I
    .local v9, "collectedPss":J
    .restart local v11    # "collectedAnonRssMB":J
    :goto_12a
    add-int/lit8 v8, v8, -0x1

    move-wide/from16 v4, v21

    goto/16 :goto_88

    .end local v21    # "start":J
    .restart local v4    # "start":J
    :cond_130
    move/from16 v18, v3

    move-wide/from16 v21, v4

    .line 1169
    .end local v4    # "start":J
    .end local v8    # "i":I
    .restart local v21    # "start":J
    :goto_134
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    sub-long v4, v4, v21

    long-to-int v4, v4

    iput v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->nonUiCheckDurMs:I

    .line 1170
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "done check non ui proc: killablePss="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "kb, killableAnonRss="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "mb, time="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v5, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->nonUiCheckDurMs:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v5, "ms, collected proc num: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1174
    invoke-static/range {v16 .. v17}, Landroid/os/Trace;->traceEnd(J)V

    .line 1175
    return-void
.end method

.method private scanOomAdjIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 24
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 1026
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string/jumbo v2, "scanOomAdj"

    .line 1027
    .local v2, "TAG":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v3

    if-eqz v3, :cond_29

    .line 1028
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "skip scan oom adj for "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1029
    return-void

    .line 1031
    :cond_29
    const-wide/16 v7, 0x40

    invoke-static {v7, v8, v2}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 1032
    const-string v3, "----------start check oom adj---------------"

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1033
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    .line 1034
    .local v4, "start":J
    const-wide/16 v9, 0x0

    .line 1035
    .local v9, "collectedPss":J
    const-wide/16 v11, 0x0

    .line 1036
    .local v11, "collectedAnonRssMB":J
    const/4 v3, 0x0

    .line 1037
    .local v3, "collectedProcNum":I
    const-string v6, "Oom"

    invoke-virtual {v1, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->getAtomicCleanReason(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 1038
    .local v13, "reason":Ljava/lang/String;
    iput-wide v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curStageStartUpTime:J

    .line 1039
    iget-object v6, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcesses:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v6

    new-instance v14, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda2;

    invoke-direct {v14, v0}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda2;-><init>(Lcom/android/server/am/OplusOsenseKillAction;)V

    .line 1040
    invoke-interface {v6, v14}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v6

    new-instance v14, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda3;

    invoke-direct {v14}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda3;-><init>()V

    .line 1041
    invoke-interface {v6, v14}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v6

    sget-object v14, Lcom/android/server/am/OplusOsenseKillAction;->LRU_SORT_BY_ADJ:Ljava/util/Comparator;

    invoke-interface {v6, v14}, Ljava/util/stream/Stream;->sorted(Ljava/util/Comparator;)Ljava/util/stream/Stream;

    move-result-object v6

    invoke-static {}, Ljava/util/stream/Collectors;->toList()Ljava/util/stream/Collector;

    move-result-object v14

    invoke-interface {v6, v14}, Ljava/util/stream/Stream;->collect(Ljava/util/stream/Collector;)Ljava/lang/Object;

    move-result-object v6

    move-object v14, v6

    check-cast v14, Ljava/util/List;

    .line 1042
    .local v14, "cachedProcessList":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessInfo;>;"
    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v15

    move-wide/from16 v16, v11

    move-wide v10, v9

    move v9, v3

    .end local v3    # "collectedProcNum":I
    .end local v11    # "collectedAnonRssMB":J
    .local v9, "collectedProcNum":I
    .local v10, "collectedPss":J
    .local v16, "collectedAnonRssMB":J
    :goto_75
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_b6

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/ProcessInfo;

    .line 1043
    .local v3, "pi":Lcom/android/server/am/ProcessInfo;
    const-string v6, "cached#: %s"

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v12

    invoke-static {v2, v6, v12}, Lcom/android/server/am/LogUtil;->formatV(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1044
    invoke-direct {v0, v1, v3, v4, v5}, Lcom/android/server/am/OplusOsenseKillAction;->getSkipReasonForCheckOomAdj(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;J)Ljava/lang/String;

    move-result-object v6

    .line 1045
    .local v6, "skipReason":Ljava/lang/String;
    if-eqz v6, :cond_94

    .line 1046
    invoke-virtual/range {v1 .. v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->printSkipLog(Ljava/lang/String;Lcom/android/server/am/ProcessInfo;JLjava/lang/String;)V

    .line 1047
    goto :goto_75

    .line 1049
    :cond_94
    invoke-virtual {v1, v3, v13}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->addToCachedCleanList(Lcom/android/server/am/ProcessInfo;Ljava/lang/String;)V

    .line 1050
    add-int/lit8 v9, v9, 0x1

    .line 1051
    invoke-virtual {v3}, Lcom/android/server/am/ProcessInfo;->getLastPss()J

    move-result-wide v18

    add-long v10, v10, v18

    .line 1052
    move-wide/from16 v18, v7

    iget-wide v7, v3, Lcom/android/server/am/ProcessInfo;->mAnonMemoryMB:J

    add-long v16, v16, v7

    .line 1054
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldBreakScan()Z

    move-result v7

    if-eqz v7, :cond_b3

    .line 1055
    const-string v7, "break oom adj check for enough killable memory"

    invoke-static {v2, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1056
    move-wide/from16 v6, v16

    goto :goto_ba

    .line 1058
    .end local v3    # "pi":Lcom/android/server/am/ProcessInfo;
    .end local v6    # "skipReason":Ljava/lang/String;
    :cond_b3
    move-wide/from16 v7, v18

    goto :goto_75

    .line 1042
    :cond_b6
    move-wide/from16 v18, v7

    move-wide/from16 v6, v16

    .line 1059
    .end local v16    # "collectedAnonRssMB":J
    .local v6, "collectedAnonRssMB":J
    :goto_ba
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v15

    move-wide/from16 v20, v4

    .end local v4    # "start":J
    .local v20, "start":J
    sub-long v3, v15, v20

    long-to-int v3, v3

    iput v3, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->oomCheckDurMs:I

    .line 1060
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "done check oom cached proc: killablePss="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "kb, killableAnonRss="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "mb, time="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, v1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->oomCheckDurMs:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string/jumbo v4, "ms, collected proc num: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 1064
    invoke-static/range {v18 .. v19}, Landroid/os/Trace;->traceEnd(J)V

    .line 1065
    return-void
.end method

.method public static setThreadUx(IZ)V
    .registers 6
    .param p0, "tid"    # I
    .param p1, "promotion"    # Z

    .line 2524
    const/16 v0, 0x3ef

    if-eqz p1, :cond_1b

    .line 2525
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->isUafKeyThreadEnabled()Z

    move-result v1

    if-eqz v1, :cond_18

    .line 2526
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->requestSysResource(IILandroid/os/Bundle;)Z

    .line 2527
    return-void

    .line 2529
    :cond_18
    const/16 v0, 0x81

    .local v0, "value":I
    goto :goto_2e

    .line 2531
    .end local v0    # "value":I
    :cond_1b
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->isUafKeyThreadEnabled()Z

    move-result v1

    if-eqz v1, :cond_2d

    .line 2532
    invoke-static {}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->getInstance()Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/oplus/osense/feature/uaf/OplusUserAwareManager;->releaseSysResource(I)Z

    .line 2533
    return-void

    .line 2535
    :cond_2d
    const/4 v0, 0x1

    .line 2537
    .restart local v0    # "value":I
    :goto_2e
    invoke-static {}, Lcom/oplus/uifirst/OplusUIFirstManager;->getInstance()Lcom/oplus/uifirst/OplusUIFirstManager;

    move-result-object v1

    sget v2, Lcom/android/server/am/OplusOsenseKillAction;->sMyPid:I

    invoke-virtual {v1, v2, p0, v0}, Lcom/oplus/uifirst/OplusUIFirstManager;->setUxThreadValueByFile(III)V

    .line 2538
    return-void
.end method

.method private shouldCheckCacheClean(Lcom/android/server/am/ProcessInfo;)Z
    .registers 4
    .param p1, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1566
    invoke-virtual {p1}, Lcom/android/server/am/ProcessInfo;->getCurProcState()I

    move-result v0

    .line 1567
    .local v0, "procstate":I
    const/16 v1, 0x13

    if-eq v0, v1, :cond_13

    const/16 v1, 0x11

    if-eq v0, v1, :cond_13

    const/16 v1, 0xa

    if-ne v0, v1, :cond_11

    goto :goto_13

    .line 1572
    :cond_11
    const/4 v1, 0x0

    return v1

    .line 1570
    :cond_13
    :goto_13
    const/4 v1, 0x1

    return v1
.end method

.method private shouldTreatLikeActive(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z
    .registers 11
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "startTime"    # J
    .param p4, "pi"    # Lcom/android/server/am/ProcessInfo;

    .line 1960
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/server/am/OplusOsenseKillAction;->recentlyActiveProcess(Lcom/android/server/am/OplusOsenseKillAction$KillContext;JLcom/android/server/am/ProcessInfo;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    .line 1961
    return v1

    .line 1963
    :cond_8
    invoke-virtual {p4}, Lcom/android/server/am/ProcessInfo;->recentlyStartupSelfDevApp()Z

    move-result v0

    if-eqz v0, :cond_23

    .line 1964
    iget-wide v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startElapsed:J

    iget-wide v4, p4, Lcom/android/server/am/ProcessInfo;->mStartElapsedTime:J

    sub-long/2addr v2, v4

    .line 1965
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    filled-new-array {p4, v0}, [Ljava/lang/Object;

    move-result-object v0

    .line 1964
    const-string v2, "KillAction"

    const-string v3, "%s is recently startup: %d"

    invoke-static {v2, v3, v0}, Lcom/android/server/am/LogUtil;->formatV(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1966
    return v1

    .line 1968
    :cond_23
    const/4 v0, 0x0

    return v0
.end method

.method private simulateKill(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 14
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3257
    move v0, p3

    .line 3258
    .local v0, "opti":I
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v7, p2, v0

    .line 3259
    .local v7, "type":Ljava/lang/String;
    const-string/jumbo v0, "real"

    invoke-virtual {v0, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 3260
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->handleRealKill(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_33

    .line 3261
    :cond_12
    const-string/jumbo v0, "updateForbidList"

    invoke-virtual {v0, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_37

    .line 3262
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 3263
    .local v0, "bundle":Landroid/os/Bundle;
    const-string/jumbo v2, "type"

    const-string/jumbo v3, "over-speed"

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3264
    invoke-static {}, Lcom/android/server/oplus/osense/policy/PolicyManager;->getInstance()Lcom/android/server/oplus/osense/policy/PolicyManager;

    move-result-object v2

    sget-object v3, Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;->POLICY_CLEAN:Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;

    invoke-virtual {v2, v3, v0}, Lcom/android/server/oplus/osense/policy/PolicyManager;->notifyDataToPolicy(Lcom/android/server/oplus/osense/OsenseConstants$PolicyType;Landroid/os/Bundle;)V

    .line 3265
    .end local v0    # "bundle":Landroid/os/Bundle;
    nop

    .line 3282
    :goto_33
    move-object v3, p1

    move-object v4, p2

    move-object p1, p0

    goto :goto_88

    .line 3266
    :cond_37
    add-int/lit8 v0, v1, 0x1

    .end local v1    # "opti":I
    .local v0, "opti":I
    aget-object v1, p2, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 3267
    .local v1, "purpose":I
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    move-object v8, v2

    .line 3268
    .local v8, "extra":Landroid/os/Bundle;
    const-string/jumbo v2, "purposeMemory"

    invoke-virtual {v8, v2, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 3269
    add-int/lit8 v5, v0, 0x1

    .end local v0    # "opti":I
    .local v5, "opti":I
    aget-object v0, p2, v0

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v9

    .line 3270
    .local v9, "doKill":Z
    const/4 v0, 0x0

    invoke-direct {p0, v8, v0}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v6

    .line 3271
    .local v6, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-direct {p0, v6}, Lcom/android/server/am/OplusOsenseKillAction;->initKillContext(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3272
    invoke-direct {p0, v6}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3273
    invoke-direct {p0, v6}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3274
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v2

    .line 3275
    :try_start_67
    new-instance v0, Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v3, v3, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v3}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v6, v0}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 3276
    monitor-exit v2
    :try_end_78
    .catchall {:try_start_67 .. :try_end_78} :catchall_89

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3277
    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    .end local p1    # "pw":Ljava/io/PrintWriter;
    .end local p2    # "args":[Ljava/lang/String;
    .local v3, "pw":Ljava/io/PrintWriter;
    .local v4, "args":[Ljava/lang/String;
    invoke-direct/range {v2 .. v7}, Lcom/android/server/am/OplusOsenseKillAction;->scanForSimulateKill(Ljava/io/PrintWriter;[Ljava/lang/String;ILcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/lang/String;)V

    .line 3278
    move-object p1, v2

    if-eqz v9, :cond_87

    .line 3279
    invoke-direct {p0, v6}, Lcom/android/server/am/OplusOsenseKillAction;->executeKill(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3282
    .end local v1    # "purpose":I
    .end local v6    # "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .end local v8    # "extra":Landroid/os/Bundle;
    .end local v9    # "doKill":Z
    :cond_87
    move v1, v5

    .end local v5    # "opti":I
    .local v1, "opti":I
    :goto_88
    return-void

    .line 3276
    .end local v3    # "pw":Ljava/io/PrintWriter;
    .end local v4    # "args":[Ljava/lang/String;
    .local v1, "purpose":I
    .restart local v5    # "opti":I
    .restart local v6    # "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .restart local v8    # "extra":Landroid/os/Bundle;
    .restart local v9    # "doKill":Z
    .restart local p1    # "pw":Ljava/io/PrintWriter;
    .restart local p2    # "args":[Ljava/lang/String;
    :catchall_89
    move-exception v0

    move-object v3, p1

    move-object v4, p2

    move-object p1, p0

    move-object p2, v0

    .end local p1    # "pw":Ljava/io/PrintWriter;
    .end local p2    # "args":[Ljava/lang/String;
    .restart local v3    # "pw":Ljava/io/PrintWriter;
    .restart local v4    # "args":[Ljava/lang/String;
    :goto_8e
    :try_start_8e
    monitor-exit v2
    :try_end_8f
    .catchall {:try_start_8e .. :try_end_8f} :catchall_93

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw p2

    :catchall_93
    move-exception v0

    move-object p2, v0

    goto :goto_8e
.end method

.method private sortApp(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 16
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3000
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 3001
    .local v0, "extra":Landroid/os/Bundle;
    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v2

    .line 3002
    .local v2, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iput-wide v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    .line 3003
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iput-wide v3, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startCurrent:J

    .line 3004
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3005
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3006
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v3

    .line 3007
    :try_start_22
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v5, v5, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v5}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v2, v4}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 3008
    monitor-exit v3
    :try_end_33
    .catchall {:try_start_22 .. :try_end_33} :catchall_1d0

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3009
    const/4 v3, 0x1

    .line 3010
    .local v3, "success":Z
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_38
    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    if-ge v4, v5, :cond_ae

    .line 3011
    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/ProcessGroup;

    .line 3012
    .local v5, "left":Lcom/android/server/am/ProcessGroup;
    iget-object v6, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    add-int/lit8 v7, v4, 0x1

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessGroup;

    .line 3013
    .local v6, "right":Lcom/android/server/am/ProcessGroup;
    iget v7, v5, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-gt v7, v8, :cond_66

    iget v7, v5, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-ne v7, v8, :cond_ab

    iget v7, v5, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    if-ge v7, v8, :cond_ab

    .line 3015
    :cond_66
    const/4 v3, 0x0

    .line 3016
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "MRU_SORT_BY_IMP failed: left="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 3017
    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " fz="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v5}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ", right="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 3018
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " fz="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 3016
    invoke-virtual {p1, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3010
    .end local v5    # "left":Lcom/android/server/am/ProcessGroup;
    .end local v6    # "right":Lcom/android/server/am/ProcessGroup;
    :cond_ab
    add-int/lit8 v4, v4, 0x1

    goto :goto_38

    .line 3022
    .end local v4    # "i":I
    :cond_ae
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 3023
    .local v4, "uiFzMemMru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    sget-object v5, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_UI_FZ_MEM:Ljava/util/Comparator;

    invoke-interface {v4, v5}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3024
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_bb
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    if-ge v5, v6, :cond_1a0

    .line 3025
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/server/am/ProcessGroup;

    .line 3026
    .local v6, "left":Lcom/android/server/am/ProcessGroup;
    add-int/lit8 v7, v5, 0x1

    invoke-interface {v4, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessGroup;

    .line 3027
    .local v7, "right":Lcom/android/server/am/ProcessGroup;
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v8

    if-eqz v8, :cond_145

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->inactiveTask()Z

    move-result v8

    if-eqz v8, :cond_145

    .line 3028
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    if-nez v8, :cond_e9

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    if-nez v8, :cond_ff

    .line 3029
    :cond_e9
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v8

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v9

    if-ne v8, v9, :cond_19c

    .line 3030
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v8

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->getUnCachedCleanAnonRssMB()J

    move-result-wide v10

    cmp-long v8, v8, v10

    if-lez v8, :cond_19c

    .line 3031
    :cond_ff
    const/4 v3, 0x0

    .line 3032
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "MRU_SORT_BY_UI_FZ_MEM failed for inactiveTask: left="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3033
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " fz="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ", right="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3034
    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " fz="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 3032
    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    goto :goto_19c

    .line 3038
    :cond_145
    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v9, v7, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-gt v8, v9, :cond_157

    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    iget v9, v7, Lcom/android/server/am/ProcessGroup;->mTaskLruIdx:I

    if-ne v8, v9, :cond_19c

    iget v8, v6, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    iget v9, v7, Lcom/android/server/am/ProcessGroup;->mLruIdx:I

    if-ge v8, v9, :cond_19c

    .line 3040
    :cond_157
    const/4 v3, 0x0

    .line 3041
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "MRU_SORT_BY_UI_FZ_MEM failed for imp: left="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3042
    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " fz="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v6}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ", right="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3043
    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " fz="

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v7}, Lcom/android/server/am/ProcessGroup;->isFreezeStable()Z

    move-result v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 3041
    invoke-virtual {p1, v8}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3024
    .end local v6    # "left":Lcom/android/server/am/ProcessGroup;
    .end local v7    # "right":Lcom/android/server/am/ProcessGroup;
    :cond_19c
    :goto_19c
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_bb

    .line 3047
    .end local v5    # "i":I
    :cond_1a0
    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    new-array v1, v1, [Lcom/android/server/am/ProcessGroup;

    invoke-interface {v5, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lcom/android/server/am/ProcessGroup;

    .line 3048
    .local v1, "fzMemMru":[Lcom/android/server/am/ProcessGroup;
    sget-object v5, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_FZ_MEM:Ljava/util/Comparator;

    invoke-direct {p0, v1, v5}, Lcom/android/server/am/OplusOsenseKillAction;->resortInactiveTaskApp([Lcom/android/server/am/ProcessGroup;Ljava/util/Comparator;)V

    .line 3049
    const/4 v5, 0x0

    .restart local v5    # "i":I
    :goto_1b0
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_1c7

    .line 3050
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    aget-object v7, v1, v5

    if-eq v6, v7, :cond_1c4

    .line 3051
    const/4 v3, 0x0

    .line 3052
    const-string v6, "MRU_SORT_BY_UI_FZ_MEM works incorrectly."

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3049
    :cond_1c4
    add-int/lit8 v5, v5, 0x1

    goto :goto_1b0

    .line 3056
    .end local v5    # "i":I
    :cond_1c7
    if-eqz v3, :cond_1cf

    .line 3057
    const-string/jumbo v5, "sort test pass"

    invoke-virtual {p1, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3059
    :cond_1cf
    return-void

    .line 3008
    .end local v1    # "fzMemMru":[Lcom/android/server/am/ProcessGroup;
    .end local v3    # "success":Z
    .end local v4    # "uiFzMemMru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    :catchall_1d0
    move-exception v1

    :try_start_1d1
    monitor-exit v3
    :try_end_1d2
    .catchall {:try_start_1d1 .. :try_end_1d2} :catchall_1d0

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v1
.end method

.method private triggerMemoryGuardIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 11
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 839
    invoke-virtual {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->shouldTriggerMemoryGuard()Z

    move-result v0

    .line 840
    .local v0, "trigger":Z
    if-eqz v0, :cond_49

    .line 842
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    if-lez v1, :cond_1a

    .line 843
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeMemoryMB:I

    iget-wide v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedMemMB:J

    long-to-int v2, v2

    sub-int/2addr v1, v2

    .line 844
    .local v1, "purposeMemory":I
    if-lez v1, :cond_1a

    .line 845
    iget-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->extra:Landroid/os/Bundle;

    const-string/jumbo v3, "purposeMemory"

    invoke-virtual {v2, v3, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 849
    .end local v1    # "purposeMemory":I
    :cond_1a
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->releaseSwapSize:I

    if-lez v1, :cond_31

    .line 850
    iget v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->releaseSwapSize:I

    iget-wide v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    long-to-int v2, v2

    sub-int/2addr v1, v2

    .line 851
    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 852
    .local v1, "releaseSwapSize":I
    iget-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->extra:Landroid/os/Bundle;

    const-string/jumbo v3, "releaseSwapSize"

    invoke-virtual {v2, v3, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 854
    .end local v1    # "releaseSwapSize":I
    :cond_31
    const-string/jumbo v1, "trigger releaseMemory"

    const-wide/16 v2, 0x40

    invoke-static {v2, v3, v1}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 855
    sget-object v1, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/am/IOplusAthenaAmManager;

    iget-object v4, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->extra:Landroid/os/Bundle;

    invoke-interface {v1, v4}, Lcom/android/server/am/IOplusAthenaAmManager;->releaseMemory(Landroid/os/Bundle;)I

    .line 856
    invoke-static {v2, v3}, Landroid/os/Trace;->traceEnd(J)V

    .line 858
    :cond_49
    iget-wide v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseAnonRssMB:J

    iget-wide v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedMemMB:J

    sub-long/2addr v1, v3

    const-wide/16 v3, 0x0

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    .line 859
    .local v1, "anonRssMore":J
    iget-wide v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->purposeReleaseSwapMB:J

    iget-wide v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->reclaimedSwapMB:J

    sub-long/2addr v5, v7

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    .line 860
    .local v3, "swapMore":J
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb more anonRss to reclaim, "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb more swapMb to reclaim, "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 862
    if-eqz v0, :cond_7d

    const-string v6, "<trigger>"

    goto :goto_7f

    :cond_7d
    const-string v6, "<skip>"

    :goto_7f
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " mem guard, cur avail="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->endAvailMB:J

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string/jumbo v6, "mb, bundle: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->extra:Landroid/os/Bundle;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 860
    const-string v6, "KillAction"

    invoke-static {v6, v5}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 864
    return-void
.end method

.method private updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 9
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 2563
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 2564
    .local v0, "start":J
    const-string/jumbo v2, "updateAppStatus"

    const-wide/16 v3, 0x40

    invoke-static {v3, v4, v2}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2566
    new-instance v2, Lcom/android/server/am/StatusUtil;

    invoke-direct {v2}, Lcom/android/server/am/StatusUtil;-><init>()V

    .line 2567
    .local v2, "util":Lcom/android/server/am/StatusUtil;
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_TRAFFIC:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getTrafficAppList()Ljava/util/ArrayList;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Ljava/util/ArrayList;)V

    .line 2568
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_FOCUS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getAudioFocusList()Ljava/util/ArrayList;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Ljava/util/ArrayList;)V

    .line 2569
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_GPS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getNavigationList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2570
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_BT:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getBluetoothList()Ljava/util/ArrayList;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Ljava/util/ArrayList;)V

    .line 2571
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_SYSTEM_WINDOW:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getVisibleWindowList()Ljava/util/ArrayList;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Ljava/util/ArrayList;)V

    .line 2573
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getDefaultLauncherList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2574
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_SMS:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getDefaultSmsList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2575
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_DIALER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getDefaultDialerList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2577
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_VPN_CONN:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getVpnConnectionList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2578
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_INPUT:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getCurrentInputMethod()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2579
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_SCREEN_RECORDER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getScreenRecordList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2580
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_WALLPAPER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getWallpaperList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2581
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_WIDGET:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getWidgetsList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2582
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_AUDIO_RECORDER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getAudioRecordList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2583
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_FOREGROUND_SERVICE:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getForegroundServiceList()Landroid/util/SparseArray;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Landroid/util/SparseArray;)V

    .line 2585
    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_RECENT_LOCKED:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    iget v6, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    invoke-virtual {v2, v6}, Lcom/android/server/am/StatusUtil;->getRecentLockList(I)Ljava/util/Map;

    move-result-object v6

    invoke-static {p1, v5, v6}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mmergeToPkgStatusMap(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;Ljava/util/Map;)V

    .line 2586
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    invoke-virtual {v2, v5}, Lcom/android/server/am/StatusUtil;->getSelfProtectProcMap(I)Ljava/util/Map;

    move-result-object v5

    iput-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->selfProtectProcMap:Ljava/util/Map;

    .line 2587
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    invoke-virtual {v2, v5}, Lcom/android/server/am/StatusUtil;->getSelfProtectPkgList(I)Ljava/util/List;

    move-result-object v5

    iput-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->selfProtectPkg:Ljava/util/List;

    .line 2588
    invoke-virtual {v2}, Lcom/android/server/am/StatusUtil;->getAmsEmptyKillFilterList()Ljava/util/List;

    move-result-object v5

    iput-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->emptyProcProtectList:Ljava/util/List;

    .line 2589
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    invoke-virtual {v2, v5}, Lcom/android/server/am/StatusUtil;->getProtectedGameApp(I)Ljava/util/List;

    move-result-object v5

    iput-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->heatGamePkgList:Ljava/util/List;

    .line 2590
    invoke-static {p1}, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->-$$Nest$mupdateAudioFocusStackIfNeeded(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 2591
    iget v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    if-lez v5, :cond_d2

    .line 2592
    invoke-static {}, Lcom/android/server/wm/OplusAthenaManager;->getInstance()Lcom/android/server/wm/OplusAthenaManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/wm/OplusAthenaManager;->getRawTasksIndex()Ljava/util/Map;

    move-result-object v5

    iput-object v5, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->recentTaskIdxMap:Ljava/util/Map;

    .line 2594
    :cond_d2
    invoke-static {v3, v4}, Landroid/os/Trace;->traceEnd(J)V

    .line 2595
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    sub-long/2addr v3, v0

    long-to-int v3, v3

    iput v3, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->updateStatusDurMs:I

    .line 2596
    return-void
.end method

.method private updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V
    .registers 9
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    .line 2541
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 2542
    .local v0, "start":J
    invoke-static {}, Lcom/android/server/am/MemUtil;->isOSvelteAvailable()Z

    move-result v2

    const-wide/16 v3, 0x40

    if-eqz v2, :cond_32

    .line 2543
    const-string/jumbo v2, "getAllProcMemStats"

    invoke-static {v3, v4, v2}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2544
    const/4 v2, 0x0

    new-array v5, v2, [I

    const v6, 0x207ff

    invoke-static {v5, v6, v2}, Lcom/android/server/am/MemUtil;->getProcMemStatsByPids([III)Ljava/util/Map;

    move-result-object v2

    iput-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    .line 2546
    invoke-static {v3, v4}, Landroid/os/Trace;->traceEnd(J)V

    .line 2547
    iget-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_32

    .line 2548
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    sub-long/2addr v2, v0

    long-to-int v2, v2

    iput v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->readMemoryDurMs:I

    .line 2549
    return-void

    .line 2552
    :cond_32
    invoke-static {}, Lcom/android/server/am/MemUtil;->isMemMonitorExist()Z

    move-result v2

    if-eqz v2, :cond_48

    .line 2553
    const-string/jumbo v2, "getProcMemNodeMap"

    invoke-static {v3, v4, v2}, Landroid/os/Trace;->traceBegin(JLjava/lang/String;)V

    .line 2554
    invoke-static {}, Lcom/android/server/am/MemUtil;->getProcMemNodeMap()Ljava/util/Map;

    move-result-object v2

    iput-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    .line 2555
    invoke-static {v3, v4}, Landroid/os/Trace;->traceEnd(J)V

    goto :goto_4f

    .line 2557
    :cond_48
    new-instance v2, Landroid/util/ArrayMap;

    invoke-direct {v2}, Landroid/util/ArrayMap;-><init>()V

    iput-object v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->memNodeItemMap:Ljava/util/Map;

    .line 2559
    :goto_4f
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    sub-long/2addr v2, v0

    long-to-int v2, v2

    iput v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->readMemoryDurMs:I

    .line 2560
    return-void
.end method

.method private updateProcessInfoLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Lcom/android/server/am/ProcessInfo;Lcom/android/server/am/ProcessRecord;)V
    .registers 16
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "pi"    # Lcom/android/server/am/ProcessInfo;
    .param p3, "app"    # Lcom/android/server/am/ProcessRecord;

    .line 2734
    if-eqz p2, :cond_1be

    if-nez p3, :cond_6

    goto/16 :goto_1be

    .line 2737
    :cond_6
    invoke-virtual {p2}, Lcom/android/server/am/ProcessInfo;->setFullyUpdated()V

    .line 2738
    iget-object v0, p3, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v0}, Lcom/android/server/am/ProcessStateRecord;->getCurProcState()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_13

    .line 2741
    return-void

    .line 2744
    :cond_13
    invoke-direct {p0, p3, p2}, Lcom/android/server/am/OplusOsenseKillAction;->collectServiceComponent(Lcom/android/server/am/ProcessRecord;Lcom/android/server/am/ProcessInfo;)V

    .line 2745
    invoke-direct {p0, p3}, Lcom/android/server/am/OplusOsenseKillAction;->getServiceClient(Lcom/android/server/am/ProcessRecord;)Ljava/util/Set;

    move-result-object v0

    .line 2746
    .local v0, "svcClients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const-string/jumbo v3, "oops, can not find client pi: "

    const/4 v4, 0x1

    const-string v5, ", "

    const-string v6, "KillAction"

    if-eqz v2, :cond_87

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/am/ProcessRecord;

    .line 2747
    .local v2, "client":Lcom/android/server/am/ProcessRecord;
    iget-object v7, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v8, v2, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v7, v8}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessInfo;

    .line 2748
    .local v7, "clientPi":Lcom/android/server/am/ProcessInfo;
    if-nez v7, :cond_53

    .line 2749
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2750
    goto :goto_1e

    .line 2752
    :cond_53
    iget v3, v7, Lcom/android/server/am/ProcessInfo;->mPid:I

    iget v8, p2, Lcom/android/server/am/ProcessInfo;->mPid:I

    if-ne v3, v8, :cond_79

    .line 2753
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "self binding client is not interesting: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2754
    goto :goto_1e

    .line 2756
    :cond_79
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v5, v7, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    if-eq v3, v5, :cond_81

    .line 2757
    iput-boolean v4, p2, Lcom/android/server/am/ProcessInfo;->mHasOtherPkgServiceClient:Z

    .line 2759
    :cond_81
    iget-object v3, p2, Lcom/android/server/am/ProcessInfo;->mServiceClients:Ljava/util/List;

    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2760
    .end local v2    # "client":Lcom/android/server/am/ProcessRecord;
    .end local v7    # "clientPi":Lcom/android/server/am/ProcessInfo;
    goto :goto_1e

    .line 2762
    :cond_87
    invoke-direct {p0, p3}, Lcom/android/server/am/OplusOsenseKillAction;->getProviderClient(Lcom/android/server/am/ProcessRecord;)Ljava/util/Set;

    move-result-object v1

    .line 2763
    .local v1, "prClients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_8f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_f8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessRecord;

    .line 2764
    .local v7, "client":Lcom/android/server/am/ProcessRecord;
    iget-object v8, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v9, v7, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v8, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessInfo;

    .line 2765
    .local v8, "clientPi":Lcom/android/server/am/ProcessInfo;
    if-nez v8, :cond_bc

    .line 2766
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v6, v9}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2767
    goto :goto_8f

    .line 2769
    :cond_bc
    iget v9, v8, Lcom/android/server/am/ProcessInfo;->mPid:I

    iget v10, p2, Lcom/android/server/am/ProcessInfo;->mPid:I

    if-ne v9, v10, :cond_e2

    .line 2770
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "self provider client is not interesting: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v6, v9}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2771
    goto :goto_8f

    .line 2773
    :cond_e2
    iget-object v9, p2, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    iget-object v10, v8, Lcom/android/server/am/ProcessInfo;->mGroup:Lcom/android/server/am/ProcessGroup;

    if-eq v9, v10, :cond_ea

    .line 2774
    iput-boolean v4, p2, Lcom/android/server/am/ProcessInfo;->mHasOtherPkgProviderClient:Z

    .line 2776
    :cond_ea
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->hasActivitiesOrRecentTasks()Z

    move-result v9

    if-eqz v9, :cond_f2

    .line 2777
    iput-boolean v4, p2, Lcom/android/server/am/ProcessInfo;->mProviderHasClientActivities:Z

    .line 2779
    :cond_f2
    iget-object v9, p2, Lcom/android/server/am/ProcessInfo;->mProviderClients:Ljava/util/List;

    invoke-interface {v9, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2780
    .end local v7    # "client":Lcom/android/server/am/ProcessRecord;
    .end local v8    # "clientPi":Lcom/android/server/am/ProcessInfo;
    goto :goto_8f

    .line 2782
    :cond_f8
    invoke-direct {p0, p3, p2}, Lcom/android/server/am/OplusOsenseKillAction;->getServiceServer(Lcom/android/server/am/ProcessRecord;Lcom/android/server/am/ProcessInfo;)Ljava/util/List;

    move-result-object v2

    .line 2783
    .local v2, "svcServers":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_100
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const-string/jumbo v7, "oops, can not find server pi: "

    if-eqz v4, :cond_15c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessRecord;

    .line 2784
    .local v4, "server":Lcom/android/server/am/ProcessRecord;
    iget-object v8, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v9, v4, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v8, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessInfo;

    .line 2785
    .local v8, "serverPi":Lcom/android/server/am/ProcessInfo;
    if-nez v8, :cond_130

    .line 2786
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2787
    goto :goto_100

    .line 2789
    :cond_130
    iget v7, v8, Lcom/android/server/am/ProcessInfo;->mPid:I

    iget v9, p2, Lcom/android/server/am/ProcessInfo;->mPid:I

    if-ne v7, v9, :cond_156

    .line 2790
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "self binding server is not interesting: "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2791
    goto :goto_100

    .line 2793
    :cond_156
    iget-object v7, p2, Lcom/android/server/am/ProcessInfo;->mServiceServers:Ljava/util/List;

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2794
    .end local v4    # "server":Lcom/android/server/am/ProcessRecord;
    .end local v8    # "serverPi":Lcom/android/server/am/ProcessInfo;
    goto :goto_100

    .line 2796
    :cond_15c
    invoke-direct {p0, p3}, Lcom/android/server/am/OplusOsenseKillAction;->getProviderServer(Lcom/android/server/am/ProcessRecord;)Ljava/util/List;

    move-result-object v3

    .line 2797
    .local v3, "prServers":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_164
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1bd

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessRecord;

    .line 2798
    .local v8, "server":Lcom/android/server/am/ProcessRecord;
    iget-object v9, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->processMap:Landroid/util/SparseArray;

    iget v10, v8, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-virtual {v9, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/android/server/am/ProcessInfo;

    .line 2799
    .local v9, "serverPi":Lcom/android/server/am/ProcessInfo;
    if-nez v9, :cond_191

    .line 2800
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v6, v10}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2801
    goto :goto_164

    .line 2803
    :cond_191
    iget v10, v9, Lcom/android/server/am/ProcessInfo;->mPid:I

    iget v11, p2, Lcom/android/server/am/ProcessInfo;->mPid:I

    if-ne v10, v11, :cond_1b7

    .line 2804
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "self provider server is not interesting: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v6, v10}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 2805
    goto :goto_164

    .line 2807
    :cond_1b7
    iget-object v10, p2, Lcom/android/server/am/ProcessInfo;->mProviderServers:Ljava/util/List;

    invoke-interface {v10, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2808
    .end local v8    # "server":Lcom/android/server/am/ProcessRecord;
    .end local v9    # "serverPi":Lcom/android/server/am/ProcessInfo;
    goto :goto_164

    .line 2809
    :cond_1bd
    return-void

    .line 2735
    .end local v0    # "svcClients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    .end local v1    # "prClients":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/am/ProcessRecord;>;"
    .end local v2    # "svcServers":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    .end local v3    # "prServers":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessRecord;>;"
    :cond_1be
    :goto_1be
    return-void
.end method


# virtual methods
.method public appFreezeStable(Lcom/android/server/am/OplusOsenseKillAction$KillContext;IJ)Z
    .registers 12
    .param p1, "killContext"    # Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    .param p2, "uid"    # I
    .param p3, "now"    # J

    .line 2004
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mFreezeTracker:Lcom/android/server/am/OplusFreezeStateTracker;

    iget-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    .line 2005
    invoke-virtual {v1}, Lcom/android/server/am/ConfigUtil;->isEnableNextPossibleUnfzCheck()Z

    move-result v4

    iget-object v1, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->config:Lcom/android/server/am/ConfigUtil;

    iget-boolean v2, p1, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->quickBoot:Z

    .line 2006
    invoke-virtual {v1, v2}, Lcom/android/server/am/ConfigUtil;->getStableFzThresHold(Z)I

    move-result v6

    .line 2004
    const v5, 0xea60

    move v1, p2

    move-wide v2, p3

    .end local p2    # "uid":I
    .end local p3    # "now":J
    .local v1, "uid":I
    .local v2, "now":J
    invoke-virtual/range {v0 .. v6}, Lcom/android/server/am/OplusFreezeStateTracker;->appFreezeStable(IJZII)Z

    move-result p2

    return p2
.end method

.method boostPriority()V
    .registers 3

    .line 4535
    sget-boolean v0, Lcom/android/server/am/OplusOsenseKillAction;->sUsefifo:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_b

    .line 4536
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    invoke-static {v0, v1}, Lcom/android/server/am/ActivityManagerService;->scheduleAsFifoPriority(IZ)Z

    goto :goto_10

    .line 4538
    :cond_b
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    invoke-static {v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->setThreadUx(IZ)V

    .line 4540
    :goto_10
    return-void
.end method

.method public dump(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 8
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3558
    move v0, p3

    .line 3559
    .local v0, "opti":I
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v0, p2, v0

    .line 3560
    .local v0, "cmd":Ljava/lang/String;
    const-string/jumbo v2, "kill"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_13

    .line 3561
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->simulateKill(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto/16 :goto_dc

    .line 3562
    :cond_13
    const-string/jumbo v2, "group"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    .line 3563
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->groupApp(Ljava/io/PrintWriter;)V

    goto/16 :goto_dc

    .line 3564
    :cond_21
    const-string v2, "app-state"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2e

    .line 3565
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printAppStatus(Ljava/io/PrintWriter;)V

    goto/16 :goto_dc

    .line 3566
    :cond_2e
    const-string/jumbo v2, "state"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3c

    .line 3567
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printState(Ljava/io/PrintWriter;)V

    goto/16 :goto_dc

    .line 3568
    :cond_3c
    const-string/jumbo v2, "sort"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4a

    .line 3569
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->sortApp(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto/16 :goto_dc

    .line 3570
    :cond_4a
    const-string/jumbo v2, "fz"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_58

    .line 3571
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printFzState(Ljava/io/PrintWriter;)V

    goto/16 :goto_dc

    .line 3572
    :cond_58
    const-string/jumbo v2, "white_list"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_66

    .line 3573
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printWhiteList(Ljava/io/PrintWriter;)V

    goto/16 :goto_dc

    .line 3574
    :cond_66
    const-string/jumbo v2, "mem_node"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_73

    .line 3575
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->printMemNodeInfo(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_dc

    .line 3576
    :cond_73
    const-string v2, "config"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_81

    .line 3577
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v2, p1}, Lcom/android/server/am/ConfigUtil;->dump(Ljava/io/PrintWriter;)V

    goto :goto_dc

    .line 3578
    :cond_81
    const-string/jumbo v2, "history"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8e

    .line 3579
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printHistory(Ljava/io/PrintWriter;)V

    goto :goto_dc

    .line 3580
    :cond_8e
    const-string/jumbo v2, "svc-restart"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9b

    .line 3581
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->handleDumpSvcRestart(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_dc

    .line 3582
    :cond_9b
    const-string v2, "audio-play-process-record"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a7

    .line 3583
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->handleDumpAudioPlayProcessRecord(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_dc

    .line 3584
    :cond_a7
    const-string/jumbo v2, "scan"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b4

    .line 3585
    invoke-direct {p0, p1, p2, v1}, Lcom/android/server/am/OplusOsenseKillAction;->scanApp(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_dc

    .line 3586
    :cond_b4
    const-string v2, "clear_appcare"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_c2

    .line 3587
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    invoke-virtual {v2, p1, p2, v1}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->dump(Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_dc

    .line 3589
    :cond_c2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "unknown cmd: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3590
    invoke-direct {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->printHelp(Ljava/io/PrintWriter;)V

    .line 3592
    :goto_dc
    return-void
.end method

.method public dumpBgActivityAppLru(Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 15
    .param p1, "pw"    # Ljava/io/PrintWriter;
    .param p2, "args"    # [Ljava/lang/String;
    .param p3, "fopti"    # I

    .line 3331
    move v0, p3

    .line 3332
    .local v0, "opti":I
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "opti":I
    .local v1, "opti":I
    aget-object v0, p2, v0

    .line 3333
    .local v0, "cmd":Ljava/lang/String;
    const/4 v2, 0x0

    .line 3334
    .local v2, "killContext":Lcom/android/server/am/OplusOsenseKillAction$KillContext;
    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 3335
    .local v3, "extra":Landroid/os/Bundle;
    const-string v4, "TYPE_DUMP"

    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_19

    .line 3336
    const/4 v4, 0x0

    invoke-direct {p0, v3, v4}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v2

    goto :goto_29

    .line 3337
    :cond_19
    const-string v4, "BGLIMIT_LEVEL_THERMAL"

    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_29

    .line 3338
    const/4 v4, 0x5

    invoke-direct {p0, v3, v4}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v2

    .line 3340
    const/4 v4, 0x1

    iput v4, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->minBgCount:I

    .line 3343
    :cond_29
    :goto_29
    if-nez v2, :cond_32

    .line 3344
    const-string/jumbo v4, "invalid cmd killContext is null"

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3345
    return-void

    .line 3348
    :cond_32
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    iput-wide v4, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startUpTime:J

    .line 3349
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iput-wide v4, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->startCurrent:J

    .line 3350
    invoke-static {}, Landroid/app/ActivityManager;->getCurrentUser()I

    move-result v4

    iput v4, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->curUserId:I

    .line 3351
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateAppStatus(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3352
    invoke-direct {p0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->updateMemNodeInfo(Lcom/android/server/am/OplusOsenseKillAction$KillContext;)V

    .line 3353
    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v4

    .line 3354
    :try_start_50
    new-instance v5, Ljava/util/ArrayList;

    iget-object v6, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v6, v6, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v6}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0, v2, v5}, Lcom/android/server/am/OplusOsenseKillAction;->groupProcessLocked(Lcom/android/server/am/OplusOsenseKillAction$KillContext;Ljava/util/List;)V

    .line 3355
    monitor-exit v4
    :try_end_61
    .catchall {:try_start_50 .. :try_end_61} :catchall_195

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 3356
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, v2, Lcom/android/server/am/OplusOsenseKillAction$KillContext;->mruAllProcessGroups:Ljava/util/List;

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 3358
    .local v4, "activityAppLru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    invoke-static {}, Lcom/android/server/wm/OplusAthenaManager;->getInstance()Lcom/android/server/wm/OplusAthenaManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/wm/OplusAthenaManager;->getRawTasksIndex()Ljava/util/Map;

    move-result-object v5

    .line 3359
    .local v5, "taskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_77
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_8a

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessGroup;

    .line 3360
    .local v7, "group":Lcom/android/server/am/ProcessGroup;
    invoke-direct {p0, v5, v7}, Lcom/android/server/am/OplusOsenseKillAction;->getTaskRecentIdx(Ljava/util/Map;Lcom/android/server/am/ProcessGroup;)I

    move-result v8

    iput v8, v7, Lcom/android/server/am/ProcessGroup;->mRecentIdx:I

    .line 3361
    .end local v7    # "group":Lcom/android/server/am/ProcessGroup;
    goto :goto_77

    .line 3363
    :cond_8a
    const-string v6, "ams lru: "

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3364
    sget-object v6, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_IMP:Ljava/util/Comparator;

    invoke-interface {v4, v6}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3365
    const/4 v6, 0x0

    .line 3366
    .local v6, "i":I
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_99
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_df

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessGroup;

    .line 3367
    .local v8, "group":Lcom/android/server/am/ProcessGroup;
    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v9

    if-eqz v9, :cond_ac

    .line 3368
    goto :goto_99

    .line 3370
    :cond_ac
    iget-object v9, v8, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v10, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v9, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_b7

    .line 3371
    goto :goto_99

    .line 3373
    :cond_b7
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "#"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    add-int/lit8 v10, v6, 0x1

    .end local v6    # "i":I
    .local v10, "i":I
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v9, ": "

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3374
    .end local v8    # "group":Lcom/android/server/am/ProcessGroup;
    move v6, v10

    goto :goto_99

    .line 3376
    .end local v10    # "i":I
    .restart local v6    # "i":I
    :cond_df
    const-string/jumbo v7, "recent lru: "

    invoke-virtual {p1, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3377
    sget-object v7, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_RECENT_LRU:Ljava/util/Comparator;

    invoke-interface {v4, v7}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3378
    const/4 v6, 0x0

    .line 3379
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_ef
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_135

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessGroup;

    .line 3380
    .restart local v8    # "group":Lcom/android/server/am/ProcessGroup;
    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v9

    if-eqz v9, :cond_102

    .line 3381
    goto :goto_ef

    .line 3383
    :cond_102
    iget-object v9, v8, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v10, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v9, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_10d

    .line 3384
    goto :goto_ef

    .line 3386
    :cond_10d
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "#"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    add-int/lit8 v10, v6, 0x1

    .end local v6    # "i":I
    .restart local v10    # "i":I
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v9, ": "

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3387
    .end local v8    # "group":Lcom/android/server/am/ProcessGroup;
    move v6, v10

    goto :goto_ef

    .line 3389
    .end local v10    # "i":I
    .restart local v6    # "i":I
    :cond_135
    const-string/jumbo v7, "recent lru for appcare: "

    invoke-virtual {p1, v7}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3390
    sget-object v7, Lcom/android/server/am/OplusOsenseKillAction;->MRU_SORT_BY_RECENT_APP_RULE:Ljava/util/Comparator;

    invoke-interface {v4, v7}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 3391
    const/4 v6, 0x0

    .line 3392
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_145
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_194

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/android/server/am/ProcessGroup;

    .line 3393
    .restart local v8    # "group":Lcom/android/server/am/ProcessGroup;
    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->isNonUiApp()Z

    move-result v9

    if-eqz v9, :cond_158

    .line 3394
    goto :goto_145

    .line 3396
    :cond_158
    iget-object v9, v8, Lcom/android/server/am/ProcessGroup;->mAppStatus:Ljava/util/Set;

    sget-object v10, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    invoke-interface {v9, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_163

    .line 3397
    goto :goto_145

    .line 3399
    :cond_163
    iget-object v9, v8, Lcom/android/server/am/ProcessGroup;->mPackageName:Ljava/lang/String;

    invoke-virtual {p0, v9}, Lcom/android/server/am/OplusOsenseKillAction;->isNonActivityPackage(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_16c

    .line 3400
    goto :goto_145

    .line 3402
    :cond_16c
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "#"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    add-int/lit8 v10, v6, 0x1

    .end local v6    # "i":I
    .restart local v10    # "i":I
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v9, ": "

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v8}, Lcom/android/server/am/ProcessGroup;->pkgString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3403
    .end local v8    # "group":Lcom/android/server/am/ProcessGroup;
    move v6, v10

    goto :goto_145

    .line 3404
    .end local v10    # "i":I
    .restart local v6    # "i":I
    :cond_194
    return-void

    .line 3355
    .end local v4    # "activityAppLru":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/am/ProcessGroup;>;"
    .end local v5    # "taskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    .end local v6    # "i":I
    :catchall_195
    move-exception v5

    :try_start_196
    monitor-exit v4
    :try_end_197
    .catchall {:try_start_196 .. :try_end_197} :catchall_195

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v5
.end method

.method public dumpRecentIdx(Ljava/io/PrintWriter;)V
    .registers 15
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 3416
    invoke-static {}, Lcom/android/server/wm/OplusAthenaManager;->getInstance()Lcom/android/server/wm/OplusAthenaManager;

    move-result-object v0

    .line 3417
    invoke-virtual {v0}, Lcom/android/server/wm/OplusAthenaManager;->getRawTasksIndex()Ljava/util/Map;

    move-result-object v0

    .line 3418
    .local v0, "taskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 3419
    .local v1, "recentList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/util/Pair<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 3420
    .local v3, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    .line 3421
    .local v4, "userId":I
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    .line 3422
    .local v5, "userTaskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;"
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_39
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_79

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    .line 3423
    .local v7, "userEntry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Integer;>;"
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 3424
    .local v8, "pkgName":Ljava/lang/String;
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    .line 3425
    .local v9, "recentIdx":I
    new-instance v10, Landroid/util/Pair;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, ":"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-direct {v10, v11, v12}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3426
    .end local v7    # "userEntry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Integer;>;"
    .end local v8    # "pkgName":Ljava/lang/String;
    .end local v9    # "recentIdx":I
    goto :goto_39

    .line 3427
    .end local v3    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;"
    .end local v4    # "userId":I
    .end local v5    # "userTaskIndexMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;"
    :cond_79
    goto :goto_15

    .line 3428
    :cond_7a
    new-instance v2, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda6;

    invoke-direct {v2}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda6;-><init>()V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    .line 3431
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_86
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_b9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/Pair;

    .line 3432
    .local v3, "tsk":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/String;Ljava/lang/Integer;>;"
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "#"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ": "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 3433
    .end local v3    # "tsk":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/String;Ljava/lang/Integer;>;"
    goto :goto_86

    .line 3434
    :cond_b9
    return-void
.end method

.method public execute(Landroid/os/Bundle;)Z
    .registers 32
    .param p1, "extra"    # Landroid/os/Bundle;

    .line 477
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v3, ", bloP="

    const-string v4, ", bloM="

    const-string v5, ", appcare="

    const-string v6, ", cchOnly="

    const-string v7, ", type="

    const-string v8, ", scene="

    const-string v9, ", enable="

    const-string/jumbo v10, "requestId"

    const-string v11, ", req_id="

    const-string/jumbo v12, "skip reason: "

    const-string v13, "KillAction"

    const-string/jumbo v0, "type"

    invoke-virtual {v2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 478
    .local v14, "type":Ljava/lang/String;
    const-string/jumbo v0, "scene"

    invoke-virtual {v2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 479
    .local v15, "scene":Ljava/lang/String;
    const-string v0, "appcareThreshold"

    move-object/from16 v16, v13

    const/4 v13, 0x0

    move-object/from16 v17, v3

    invoke-virtual {v2, v0, v13}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v3

    .line 480
    .local v3, "appcareThreshold":I
    move v0, v13

    invoke-direct {v1, v14}, Lcom/android/server/am/OplusOsenseKillAction;->checkIfCachedCleanOnly(Ljava/lang/String;)Z

    move-result v13

    .line 481
    .local v13, "cchOnly":Z
    move-object/from16 v18, v4

    invoke-direct {v1, v14, v15}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContextType(Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    .line 483
    .local v4, "contextType":I
    move/from16 v19, v0

    const-string v0, "common_external_kill"

    invoke-virtual {v0, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    move/from16 v20, v0

    const/4 v0, 0x1

    if-eqz v20, :cond_51

    .line 484
    invoke-virtual/range {p0 .. p1}, Lcom/android/server/am/OplusOsenseKillAction;->executeCommonExternalKill(Landroid/os/Bundle;)V

    .line 485
    return v0

    .line 486
    :cond_51
    move/from16 v20, v0

    const-string v0, "common_external_force_stop"

    invoke-virtual {v0, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5f

    .line 487
    invoke-virtual/range {p0 .. p1}, Lcom/android/server/am/OplusOsenseKillAction;->executeCommonExternalForceStop(Landroid/os/Bundle;)V

    .line 488
    return v20

    .line 491
    :cond_5f
    move/from16 v21, v4

    .end local v4    # "contextType":I
    .local v21, "contextType":I
    const/4 v4, 0x0

    .line 493
    .local v4, "skipReason":Ljava/lang/String;
    move-object/from16 v22, v4

    .end local v4    # "skipReason":Ljava/lang/String;
    .local v22, "skipReason":Ljava/lang/String;
    :try_start_64
    const-string/jumbo v0, "performance_quick_start"

    invoke-virtual {v0, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    if-eqz v0, :cond_80

    .line 494
    const-string/jumbo v0, "level"

    invoke-virtual {v2, v0, v4}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    move/from16 v4, v20

    if-ne v0, v4, :cond_7b

    const/4 v4, 0x1

    goto :goto_7d

    :cond_7b
    move/from16 v4, v19

    :goto_7d
    invoke-virtual {v1, v4}, Lcom/android/server/am/OplusOsenseKillAction;->updateQuickBootMode(Z)V

    .line 496
    :cond_80
    invoke-virtual {v1, v14}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkipClearPolicyType(Ljava/lang/String;)Z

    move-result v0
    :try_end_84
    .catchall {:try_start_64 .. :try_end_84} :catchall_2f8

    if-eqz v0, :cond_fe

    .line 497
    :try_start_86
    const-string/jumbo v0, "non-low-mem-req"
    :try_end_89
    .catchall {:try_start_86 .. :try_end_89} :catchall_f3

    .line 498
    .end local v22    # "skipReason":Ljava/lang/String;
    .local v0, "skipReason":Ljava/lang/String;
    nop

    .line 511
    nop

    .line 512
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 513
    const/4 v11, -0x1

    invoke-virtual {v2, v10, v11}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v10

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 514
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    move-object/from16 v5, v18

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-boolean v5, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    move-object/from16 v5, v17

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-boolean v5, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 512
    move-object/from16 v5, v16

    invoke-static {v5, v4}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 498
    return v19

    .line 511
    .end local v0    # "skipReason":Ljava/lang/String;
    .restart local v22    # "skipReason":Ljava/lang/String;
    :catchall_f3
    move-exception v0

    move-object/from16 v23, v17

    move-object/from16 v4, v18

    move-object/from16 v28, v16

    move-object/from16 v29, v23

    goto/16 :goto_2ff

    .line 500
    :cond_fe
    move-object/from16 v23, v17

    move-object/from16 v4, v18

    move/from16 v4, v21

    .end local v21    # "contextType":I
    .local v4, "contextType":I
    :try_start_104
    invoke-direct {v1, v4, v2}, Lcom/android/server/am/OplusOsenseKillAction;->handleSpecialRequest(ILandroid/os/Bundle;)Z

    move-result v0
    :try_end_108
    .catchall {:try_start_104 .. :try_end_108} :catchall_2ee

    if-eqz v0, :cond_17c

    .line 501
    nop

    .line 511
    if-eqz v22, :cond_177

    .line 512
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v12, v22

    .end local v22    # "skipReason":Ljava/lang/String;
    .local v12, "skipReason":Ljava/lang/String;
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 513
    const/4 v11, -0x1

    invoke-virtual {v2, v10, v11}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 514
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v9

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v5, v18

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v5, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v5, v23

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v5, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 512
    move-object/from16 v5, v16

    invoke-static {v5, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_179

    .line 511
    .end local v12    # "skipReason":Ljava/lang/String;
    .restart local v22    # "skipReason":Ljava/lang/String;
    :cond_177
    move-object/from16 v12, v22

    .line 501
    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v12    # "skipReason":Ljava/lang/String;
    :goto_179
    const/16 v20, 0x1

    return v20

    .line 503
    .end local v12    # "skipReason":Ljava/lang/String;
    .restart local v22    # "skipReason":Ljava/lang/String;
    :cond_17c
    move-object/from16 v24, v16

    move-object/from16 v25, v18

    move-object/from16 v26, v23

    move-object/from16 v16, v5

    move-object/from16 v5, v22

    .end local v22    # "skipReason":Ljava/lang/String;
    .local v5, "skipReason":Ljava/lang/String;
    :try_start_186
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v0
    :try_end_18a
    .catchall {:try_start_186 .. :try_end_18a} :catchall_2e0

    if-eqz v0, :cond_261

    :try_start_18c
    invoke-virtual {v1, v15, v14, v3}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkip(Ljava/lang/String;Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_1a0

    move/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move-object/from16 v16, v24

    move-object/from16 v4, v25

    move-object/from16 v27, v26

    goto/16 :goto_26d

    .line 508
    :cond_1a0
    iget-object v0, v1, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;
    :try_end_1a2
    .catchall {:try_start_18c .. :try_end_1a2} :catchall_24e

    move/from16 v17, v3

    .end local v3    # "appcareThreshold":I
    .local v17, "appcareThreshold":I
    :try_start_1a4
    invoke-direct {v1, v2, v4}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v3
    :try_end_1a8
    .catchall {:try_start_1a4 .. :try_end_1a8} :catchall_239

    move/from16 v21, v4

    const/4 v4, 0x2

    .end local v4    # "contextType":I
    .restart local v21    # "contextType":I
    :try_start_1ab
    invoke-virtual {v0, v4, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 509
    .local v0, "msg":Landroid/os/Message;
    iget-object v3, v1, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    invoke-virtual {v3, v0}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->sendMessage(Landroid/os/Message;)Z

    move-result v3
    :try_end_1b5
    .catchall {:try_start_1ab .. :try_end_1b5} :catchall_226

    .line 511
    if-eqz v5, :cond_223

    .line 512
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 513
    const/4 v11, -0x1

    invoke-virtual {v2, v10, v11}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v10

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 514
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    move-object/from16 v6, v16

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v6, v17

    .end local v17    # "appcareThreshold":I
    .local v6, "appcareThreshold":I
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    move-object/from16 v7, v25

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-boolean v7, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    move-object/from16 v7, v26

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-boolean v7, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 512
    move-object/from16 v7, v24

    invoke-static {v7, v4}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_225

    .line 511
    .end local v6    # "appcareThreshold":I
    .restart local v17    # "appcareThreshold":I
    :cond_223
    move/from16 v6, v17

    .line 509
    .end local v17    # "appcareThreshold":I
    .restart local v6    # "appcareThreshold":I
    :goto_225
    return v3

    .line 511
    .end local v0    # "msg":Landroid/os/Message;
    .end local v6    # "appcareThreshold":I
    .restart local v17    # "appcareThreshold":I
    :catchall_226
    move-exception v0

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move/from16 v3, v17

    move-object/from16 v16, v24

    move-object/from16 v4, v25

    move-object/from16 v27, v26

    move-object/from16 v28, v16

    move-object/from16 v29, v27

    .end local v5    # "skipReason":Ljava/lang/String;
    .end local v17    # "appcareThreshold":I
    .restart local v3    # "appcareThreshold":I
    .restart local v22    # "skipReason":Ljava/lang/String;
    goto/16 :goto_2ff

    .end local v3    # "appcareThreshold":I
    .end local v21    # "contextType":I
    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v4    # "contextType":I
    .restart local v5    # "skipReason":Ljava/lang/String;
    .restart local v17    # "appcareThreshold":I
    :catchall_239
    move-exception v0

    move/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move/from16 v3, v17

    move-object/from16 v16, v24

    move-object/from16 v4, v25

    move-object/from16 v27, v26

    move-object/from16 v28, v16

    move-object/from16 v29, v27

    .end local v4    # "contextType":I
    .end local v5    # "skipReason":Ljava/lang/String;
    .end local v17    # "appcareThreshold":I
    .restart local v3    # "appcareThreshold":I
    .restart local v21    # "contextType":I
    .restart local v22    # "skipReason":Ljava/lang/String;
    goto/16 :goto_2ff

    .end local v21    # "contextType":I
    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v4    # "contextType":I
    .restart local v5    # "skipReason":Ljava/lang/String;
    :catchall_24e
    move-exception v0

    move/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move-object/from16 v16, v24

    move-object/from16 v4, v25

    move-object/from16 v27, v26

    move-object/from16 v28, v16

    move-object/from16 v29, v27

    goto/16 :goto_2ed

    .line 503
    :cond_261
    move/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move-object/from16 v16, v24

    move-object/from16 v4, v25

    move-object/from16 v27, v26

    .line 505
    .end local v4    # "contextType":I
    .end local v5    # "skipReason":Ljava/lang/String;
    .restart local v21    # "contextType":I
    .restart local v22    # "skipReason":Ljava/lang/String;
    :goto_26d
    :try_start_26d
    const-string/jumbo v0, "should-skip"
    :try_end_270
    .catchall {:try_start_26d .. :try_end_270} :catchall_2da

    .line 506
    .end local v22    # "skipReason":Ljava/lang/String;
    .local v0, "skipReason":Ljava/lang/String;
    nop

    .line 511
    nop

    .line 512
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 513
    const/4 v11, -0x1

    invoke-virtual {v2, v10, v11}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v10

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 514
    invoke-virtual/range {p0 .. p0}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v9

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object/from16 v4, p0

    iget-boolean v5, v4, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object/from16 v5, v27

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v5, v4, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 512
    move-object/from16 v5, v16

    invoke-static {v5, v1}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 506
    return v13

    .line 511
    .end local v0    # "skipReason":Ljava/lang/String;
    .restart local v22    # "skipReason":Ljava/lang/String;
    :catchall_2da
    move-exception v0

    move-object/from16 v28, v16

    move-object/from16 v29, v27

    goto :goto_2ff

    .end local v21    # "contextType":I
    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v4    # "contextType":I
    .restart local v5    # "skipReason":Ljava/lang/String;
    :catchall_2e0
    move-exception v0

    move/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v5, v16

    move-object/from16 v28, v24

    move-object/from16 v4, v25

    move-object/from16 v29, v26

    .end local v4    # "contextType":I
    .end local v5    # "skipReason":Ljava/lang/String;
    .restart local v21    # "contextType":I
    .restart local v22    # "skipReason":Ljava/lang/String;
    :goto_2ed
    goto :goto_2ff

    .end local v21    # "contextType":I
    .restart local v4    # "contextType":I
    :catchall_2ee
    move-exception v0

    move/from16 v21, v4

    move-object/from16 v28, v16

    move-object/from16 v4, v18

    move-object/from16 v29, v23

    .end local v4    # "contextType":I
    .restart local v21    # "contextType":I
    goto :goto_2ff

    :catchall_2f8
    move-exception v0

    move-object/from16 v28, v16

    move-object/from16 v29, v17

    move-object/from16 v4, v18

    :goto_2ff
    if-eqz v22, :cond_36b

    .line 512
    move-object/from16 v16, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v12, v22

    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v12    # "skipReason":Ljava/lang/String;
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 513
    const/4 v11, -0x1

    invoke-virtual {v2, v10, v11}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 514
    invoke-virtual {v1}, Lcom/android/server/am/OplusOsenseKillAction;->isEnable()Z

    move-result v9

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v4, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v5, v29

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v4, v1, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 512
    move-object/from16 v5, v28

    invoke-static {v5, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_36f

    .line 511
    .end local v12    # "skipReason":Ljava/lang/String;
    .restart local v22    # "skipReason":Ljava/lang/String;
    :cond_36b
    move-object/from16 v16, v0

    move-object/from16 v12, v22

    .line 518
    .end local v22    # "skipReason":Ljava/lang/String;
    .restart local v12    # "skipReason":Ljava/lang/String;
    :goto_36f
    throw v16
.end method

.method public executeCommonExternalForceStop(Landroid/os/Bundle;)V
    .registers 10
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 379
    const-string/jumbo v0, "reason"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 380
    .local v6, "reason":Ljava/lang/String;
    const-string v0, "KillAction"

    if-eqz v6, :cond_4d

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_12

    goto :goto_4d

    .line 384
    :cond_12
    const-string/jumbo v1, "pkgName"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 385
    .local v2, "pkgName":Ljava/lang/String;
    if-eqz v2, :cond_46

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_22

    goto :goto_46

    .line 389
    :cond_22
    const-string/jumbo v1, "userId"

    const/4 v3, -0x1

    invoke-virtual {p1, v1, v3}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 390
    .local v1, "userId":I
    if-ne v1, v3, :cond_33

    .line 391
    const-string/jumbo v3, "invalid userId"

    invoke-static {v0, v3}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 392
    return-void

    .line 394
    :cond_33
    sget-object v0, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusAthenaAmManager;

    const/16 v5, 0x15

    const/4 v7, 0x0

    const/16 v4, 0xd

    move v3, v1

    move-object v1, v0

    .end local v1    # "userId":I
    .local v3, "userId":I
    invoke-interface/range {v1 .. v7}, Lcom/android/server/am/IOplusAthenaAmManager;->forceStopPackage(Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;)V

    .line 396
    return-void

    .line 386
    .end local v3    # "userId":I
    :cond_46
    :goto_46
    const-string/jumbo v1, "invalid pkgName"

    invoke-static {v0, v1}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 387
    return-void

    .line 381
    .end local v2    # "pkgName":Ljava/lang/String;
    :cond_4d
    :goto_4d
    const-string/jumbo v1, "no stop reason"

    invoke-static {v0, v1}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 382
    return-void
.end method

.method public executeCommonExternalKill(Landroid/os/Bundle;)V
    .registers 10
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 326
    const-string/jumbo v0, "reason"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 327
    .local v0, "reason":Ljava/lang/String;
    if-eqz v0, :cond_ce

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_11

    goto/16 :goto_ce

    .line 331
    :cond_11
    const-string/jumbo v1, "pid"

    const/4 v2, -0x1

    invoke-virtual {p1, v1, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 332
    .local v1, "pid":I
    if-ne v1, v2, :cond_24

    .line 333
    const-string v2, "KillAction"

    const-string/jumbo v3, "invalid pid"

    invoke-static {v2, v3}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 334
    return-void

    .line 337
    :cond_24
    const/4 v3, 0x0

    .line 338
    .local v3, "app":Lcom/android/server/am/ProcessRecord;
    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    monitor-enter v4

    .line 339
    :try_start_2a
    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v5, v5, Lcom/android/server/am/ActivityManagerService;->mPidsSelfLocked:Lcom/android/server/am/ActivityManagerService$PidMap;

    invoke-virtual {v5, v1}, Lcom/android/server/am/ActivityManagerService$PidMap;->get(I)Lcom/android/server/am/ProcessRecord;

    move-result-object v5

    move-object v3, v5

    .line 340
    monitor-exit v4
    :try_end_34
    .catchall {:try_start_2a .. :try_end_34} :catchall_cb

    .line 342
    const-string/jumbo v4, "killType"

    const/4 v5, 0x0

    invoke-virtual {p1, v4, v5}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v4

    .line 343
    .local v4, "killType":I
    const/4 v5, 0x1

    if-ne v4, v5, :cond_43

    .line 344
    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    goto :goto_82

    .line 345
    :cond_43
    const/4 v5, 0x2

    if-ne v4, v5, :cond_4a

    .line 346
    invoke-static {v1}, Landroid/os/Process;->killProcessQuiet(I)V

    goto :goto_82

    .line 347
    :cond_4a
    const/4 v5, 0x3

    if-ne v4, v5, :cond_66

    .line 348
    const-string/jumbo v5, "uid"

    invoke-virtual {p1, v5, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    .line 349
    .local v5, "uid":I
    if-ne v5, v2, :cond_5f

    .line 350
    const-string v2, "KillAction"

    const-string/jumbo v6, "invalid uid"

    invoke-static {v2, v6}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 351
    return-void

    .line 353
    :cond_5f
    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 354
    invoke-static {v5, v1}, Landroid/os/Process;->killProcessGroup(II)I

    .line 355
    .end local v5    # "uid":I
    goto :goto_82

    :cond_66
    const/4 v5, 0x4

    if-ne v4, v5, :cond_c2

    .line 356
    const-string/jumbo v5, "uid"

    invoke-virtual {p1, v5, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    .line 357
    .restart local v5    # "uid":I
    if-ne v5, v2, :cond_7b

    .line 358
    const-string v2, "KillAction"

    const-string/jumbo v6, "invalid uid"

    invoke-static {v2, v6}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 359
    return-void

    .line 361
    :cond_7b
    invoke-static {v1}, Landroid/os/Process;->killProcessQuiet(I)V

    .line 362
    invoke-static {v5, v1}, Landroid/os/Process;->killProcessGroup(II)I

    .line 363
    .end local v5    # "uid":I
    nop

    .line 368
    :goto_82
    if-eqz v3, :cond_c1

    .line 369
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v2

    .line 370
    :try_start_8a
    iget-object v5, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v5, v5, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    const/16 v6, 0xd

    const/16 v7, 0xc

    invoke-virtual {v5, v3, v6, v7, v0}, Lcom/android/server/am/ProcessList;->noteAppKill(Lcom/android/server/am/ProcessRecord;IILjava/lang/String;)V

    .line 372
    monitor-exit v2
    :try_end_96
    .catchall {:try_start_8a .. :try_end_96} :catchall_bb

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 373
    iget v2, v3, Lcom/android/server/am/ProcessRecord;->userId:I

    .line 374
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v5, v3, Lcom/android/server/am/ProcessRecord;->mPid:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget-object v6, v3, Lcom/android/server/am/ProcessRecord;->processName:Ljava/lang/String;

    iget-object v7, v3, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v7}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v2, v5, v6, v7, v0}, [Ljava/lang/Object;

    move-result-object v2

    .line 373
    const/16 v5, 0x7547

    invoke-static {v5, v2}, Landroid/util/EventLog;->writeEvent(I[Ljava/lang/Object;)I

    goto :goto_c1

    .line 372
    :catchall_bb
    move-exception v5

    :try_start_bc
    monitor-exit v2
    :try_end_bd
    .catchall {:try_start_bc .. :try_end_bd} :catchall_bb

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v5

    .line 376
    :cond_c1
    :goto_c1
    return-void

    .line 364
    :cond_c2
    const-string v2, "KillAction"

    const-string/jumbo v5, "invalid kill type"

    invoke-static {v2, v5}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 365
    return-void

    .line 340
    .end local v4    # "killType":I
    :catchall_cb
    move-exception v2

    :try_start_cc
    monitor-exit v4
    :try_end_cd
    .catchall {:try_start_cc .. :try_end_cd} :catchall_cb

    throw v2

    .line 328
    .end local v1    # "pid":I
    .end local v3    # "app":Lcom/android/server/am/ProcessRecord;
    :cond_ce
    :goto_ce
    const-string v1, "KillAction"

    const-string/jumbo v2, "no kill reason"

    invoke-static {v1, v2}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 329
    return-void
.end method

.method public executeForQB(Landroid/os/Bundle;)Z
    .registers 3
    .param p1, "extra"    # Landroid/os/Bundle;

    .line 434
    const/4 v0, 0x0

    return v0
.end method

.method public executeNirvanaClear(Landroid/os/Bundle;)Z
    .registers 7
    .param p1, "extra"    # Landroid/os/Bundle;

    .line 522
    const-string/jumbo v0, "type"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 523
    .local v0, "type":Ljava/lang/String;
    const-string/jumbo v1, "scene"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 524
    .local v1, "scene":Ljava/lang/String;
    const/4 v2, 0x0

    invoke-virtual {p0, v1, v0, v2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkip(Ljava/lang/String;Ljava/lang/String;I)Z

    move-result v3

    if-nez v3, :cond_2b

    .line 525
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    .line 526
    invoke-direct {p0, v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContextType(Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-direct {p0, p1, v3}, Lcom/android/server/am/OplusOsenseKillAction;->getKillContext(Landroid/os/Bundle;I)Lcom/android/server/am/OplusOsenseKillAction$KillContext;

    move-result-object v3

    .line 525
    const/4 v4, 0x2

    invoke-virtual {v2, v4, v3}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    .line 527
    .local v2, "msg":Landroid/os/Message;
    iget-object v3, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    invoke-virtual {v3, v2}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->sendMessage(Landroid/os/Message;)Z

    move-result v3

    return v3

    .line 529
    .end local v2    # "msg":Landroid/os/Message;
    :cond_2b
    return v2
.end method

.method public getAllBgActivityApp()Landroid/util/SparseArray;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/SparseArray<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;>;>;"
        }
    .end annotation

    .line 533
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    if-nez v0, :cond_6

    .line 534
    const/4 v0, 0x0

    return-object v0

    .line 536
    :cond_6
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    .line 537
    .local v0, "allBgActivityApps":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/Integer;>;>;>;"
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForLockedSection()V

    monitor-enter v1

    .line 538
    :try_start_11
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v2}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v2

    .line 539
    .local v2, "activeProcesses":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ProcessRecord;>;"
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    .local v3, "i":I
    :goto_1f
    if-ltz v3, :cond_80

    .line 540
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/ProcessRecord;

    .line 541
    .local v4, "app":Lcom/android/server/am/ProcessRecord;
    invoke-direct {p0, v4}, Lcom/android/server/am/OplusOsenseKillAction;->isInvalidProcessRecordLocked(Lcom/android/server/am/ProcessRecord;)Z

    move-result v5

    if-eqz v5, :cond_2e

    .line 542
    goto :goto_7d

    .line 544
    :cond_2e
    invoke-virtual {v4}, Lcom/android/server/am/ProcessRecord;->hasActivities()Z

    move-result v5

    if-nez v5, :cond_35

    .line 545
    goto :goto_7d

    .line 547
    :cond_35
    iget-object v5, v4, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v5, v5, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {p0, v5}, Lcom/android/server/am/OplusOsenseKillAction;->isNonActivityPackage(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_40

    .line 548
    goto :goto_7d

    .line 550
    :cond_40
    iget-object v5, v4, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget v5, v5, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-virtual {v0, v5}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    .line 551
    .local v5, "pkgProcessesMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/Integer;>;>;"
    if-nez v5, :cond_59

    .line 552
    new-instance v6, Landroid/util/ArrayMap;

    invoke-direct {v6}, Landroid/util/ArrayMap;-><init>()V

    move-object v5, v6

    .line 553
    iget-object v6, v4, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget v6, v6, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-virtual {v0, v6, v5}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 555
    :cond_59
    iget-object v6, v4, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v6, v6, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Set;

    .line 556
    .local v6, "processSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/Integer;>;"
    if-nez v6, :cond_72

    .line 557
    new-instance v7, Landroid/util/ArraySet;

    invoke-direct {v7}, Landroid/util/ArraySet;-><init>()V

    move-object v6, v7

    .line 558
    iget-object v7, v4, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v7, v7, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-interface {v5, v7, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 560
    :cond_72
    invoke-virtual {v4}, Lcom/android/server/am/ProcessRecord;->getPid()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 539
    .end local v4    # "app":Lcom/android/server/am/ProcessRecord;
    .end local v5    # "pkgProcessesMap":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/Integer;>;>;"
    .end local v6    # "processSet":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/Integer;>;"
    :goto_7d
    add-int/lit8 v3, v3, -0x1

    goto :goto_1f

    .line 562
    .end local v2    # "activeProcesses":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ProcessRecord;>;"
    .end local v3    # "i":I
    :cond_80
    monitor-exit v1
    :try_end_81
    .catchall {:try_start_11 .. :try_end_81} :catchall_85

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    .line 563
    return-object v0

    .line 562
    :catchall_85
    move-exception v2

    :try_start_86
    monitor-exit v1
    :try_end_87
    .catchall {:try_start_86 .. :try_end_87} :catchall_85

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterLockedSection()V

    throw v2
.end method

.method public getAppCareForProcState(I)I
    .registers 3
    .param p1, "procState"    # I

    .line 422
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    invoke-virtual {v0, p1}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->getAppCareForProcState(I)I

    move-result v0

    return v0
.end method

.method public getAppcareForRecentIdx(I)I
    .registers 3
    .param p1, "recentIdx"    # I

    .line 430
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    invoke-virtual {v0, p1}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->getAppcareForRecentIdx(I)I

    move-result v0

    return v0
.end method

.method public getAppcareListForAppStatus(Ljava/util/Set;)Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;",
            ">;)",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 426
    .local p1, "appStatusSet":Ljava/util/Set;, "Ljava/util/Set<Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;>;"
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    invoke-virtual {v0, p1}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->getAppcareListForAppStatus(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public getConfigUtil()Lcom/android/server/am/ConfigUtil;
    .registers 2

    .line 4578
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    return-object v0
.end method

.method public getImportantProcState(Lcom/android/server/am/ProcessGroup;)I
    .registers 8
    .param p1, "group"    # Lcom/android/server/am/ProcessGroup;

    .line 1511
    iget-boolean v0, p1, Lcom/android/server/am/ProcessGroup;->cachedImportantProcStateValid:Z

    if-eqz v0, :cond_7

    .line 1512
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->cachedImportantProcState:I

    return v0

    .line 1514
    :cond_7
    const/4 v0, -0x1

    .line 1517
    .local v0, "imp":I
    iget v1, p1, Lcom/android/server/am/ProcessGroup;->mMinProcState:I

    const/4 v2, 0x3

    if-gt v1, v2, :cond_f

    .line 1518
    iget v0, p1, Lcom/android/server/am/ProcessGroup;->mMinProcState:I

    .line 1520
    :cond_f
    iget-object v1, p1, Lcom/android/server/am/ProcessGroup;->mProcStates:Ljava/util/Set;

    const/16 v2, 0xe

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1f

    .line 1521
    const/16 v0, 0xe

    .line 1523
    :cond_1f
    const/4 v1, -0x1

    const/4 v2, 0x1

    if-ne v0, v1, :cond_67

    .line 1524
    iget-object v1, p1, Lcom/android/server/am/ProcessGroup;->mProcStates:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_29
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_67

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 1525
    .local v3, "state":I
    sget-object v4, Lcom/android/server/am/OplusOsenseKillAction;->sKillableProcState:Ljava/util/Set;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_47

    .line 1526
    move v0, v3

    .line 1527
    goto :goto_67

    .line 1530
    :cond_47
    invoke-virtual {p1}, Lcom/android/server/am/ProcessGroup;->invalidAppLru()Z

    move-result v4

    if-nez v4, :cond_5a

    iget-boolean v4, p1, Lcom/android/server/am/ProcessGroup;->mSystem:Z

    if-nez v4, :cond_5a

    iget v4, p1, Lcom/android/server/am/ProcessGroup;->mUid:I

    const/16 v5, 0x2710

    if-ge v4, v5, :cond_58

    goto :goto_5a

    :cond_58
    const/4 v4, 0x0

    goto :goto_5b

    :cond_5a
    :goto_5a
    move v4, v2

    .line 1532
    .local v4, "skipFgs":Z
    :goto_5b
    if-eqz v4, :cond_66

    const/4 v5, 0x4

    if-eq v3, v5, :cond_64

    const/16 v5, 0x8

    if-ne v3, v5, :cond_66

    .line 1534
    :cond_64
    move v0, v3

    .line 1535
    goto :goto_67

    .line 1537
    .end local v3    # "state":I
    .end local v4    # "skipFgs":Z
    :cond_66
    goto :goto_29

    .line 1539
    :cond_67
    :goto_67
    iput-boolean v2, p1, Lcom/android/server/am/ProcessGroup;->cachedImportantProcStateValid:Z

    .line 1540
    iput v0, p1, Lcom/android/server/am/ProcessGroup;->cachedImportantProcState:I

    .line 1541
    return v0
.end method

.method public getProcessLruRawData(Z)Ljava/util/ArrayList;
    .registers 15
    .param p1, "sortByAdj"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 2053
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2054
    .local v0, "infos":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    if-nez v1, :cond_10

    .line 2055
    const-string/jumbo v1, "none AMS"

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2056
    return-object v0

    .line 2058
    :cond_10
    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v2, 0x100

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 2059
    .local v1, "sb":Ljava/lang/StringBuilder;
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v2, v2, Lcom/android/server/am/ActivityManagerService;->mProcLock:Lcom/android/server/am/ActivityManagerGlobalLock;

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->boostPriorityForProcLockedSection()V

    monitor-enter v2

    .line 2060
    :try_start_1f
    new-instance v3, Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v4, v4, Lcom/android/server/am/ActivityManagerService;->mProcessList:Lcom/android/server/am/ProcessList;

    invoke-virtual {v4}, Lcom/android/server/am/ProcessList;->getLruProcessesLOSP()Ljava/util/ArrayList;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 2061
    .local v3, "lruProcesses":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ProcessRecord;>;"
    if-eqz p1, :cond_3a

    .line 2062
    new-instance v4, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda4;

    invoke-direct {v4}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda4;-><init>()V

    invoke-static {v4}, Ljava/util/Comparator;->comparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    .line 2064
    :cond_3a
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    .line 2065
    .local v4, "current":J
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    .local v6, "i":I
    :goto_44
    if-ltz v6, :cond_121

    .line 2066
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/server/am/ProcessRecord;

    .line 2067
    .local v7, "proc":Lcom/android/server/am/ProcessRecord;
    if-eqz v7, :cond_11d

    iget-object v8, v7, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    if-eqz v8, :cond_11d

    iget-object v8, v7, Lcom/android/server/am/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v8, v8, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    if-eqz v8, :cond_11d

    .line 2068
    const/4 v8, 0x0

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2069
    const/16 v9, 0x23

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2070
    const/16 v9, 0xa

    const/16 v10, 0x20

    if-ge v6, v9, :cond_6a

    .line 2071
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2073
    :cond_6a
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2074
    const-string v9, ": "

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2075
    iget-object v9, v7, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v9}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v9

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2076
    const/16 v9, 0x2f

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2077
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->getStartElapsedTime()J

    move-result-wide v11

    sub-long v11, v4, v11

    invoke-virtual {v1, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 2078
    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2079
    iget-object v9, v7, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v9}, Lcom/android/server/am/ProcessStateRecord;->getSetAdj()I

    move-result v9

    invoke-static {v9, v8}, Lcom/android/server/am/ProcessList;->makeOomAdjString(IZ)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2080
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2081
    iget-object v8, v7, Lcom/android/server/am/ProcessRecord;->mState:Lcom/android/server/am/ProcessStateRecord;

    invoke-virtual {v8}, Lcom/android/server/am/ProcessStateRecord;->getCurProcState()I

    move-result v8

    invoke-static {v8}, Lcom/android/server/am/ProcessList;->makeProcStateString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2082
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2083
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->toShortString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2084
    iget-object v8, v7, Lcom/android/server/am/ProcessRecord;->mServices:Lcom/android/server/am/ProcessServiceRecord;

    .line 2085
    .local v8, "psr":Lcom/android/server/am/ProcessServiceRecord;
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->hasActivitiesOrRecentTasks()Z

    move-result v9

    if-nez v9, :cond_c7

    invoke-virtual {v8}, Lcom/android/server/am/ProcessServiceRecord;->hasClientActivities()Z

    move-result v9

    if-nez v9, :cond_c7

    .line 2086
    invoke-virtual {v8}, Lcom/android/server/am/ProcessServiceRecord;->isTreatedLikeActivity()Z

    move-result v9

    if-eqz v9, :cond_116

    .line 2087
    :cond_c7
    const-string v9, " act:"

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2088
    const/4 v9, 0x0

    .line 2089
    .local v9, "printed":Z
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->hasActivities()Z

    move-result v10

    if-eqz v10, :cond_d9

    .line 2090
    const-string v10, "activities"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2091
    const/4 v9, 0x1

    .line 2093
    :cond_d9
    invoke-virtual {v7}, Lcom/android/server/am/ProcessRecord;->hasRecentTasks()Z

    move-result v10

    if-eqz v10, :cond_ee

    .line 2094
    if-eqz v9, :cond_e7

    .line 2095
    const-string/jumbo v10, "|"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2097
    :cond_e7
    const-string/jumbo v10, "recents"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2098
    const/4 v9, 0x1

    .line 2100
    :cond_ee
    invoke-virtual {v8}, Lcom/android/server/am/ProcessServiceRecord;->hasClientActivities()Z

    move-result v10

    if-eqz v10, :cond_102

    .line 2101
    if-eqz v9, :cond_fc

    .line 2102
    const-string/jumbo v10, "|"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2104
    :cond_fc
    const-string v10, "client"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2105
    const/4 v9, 0x1

    .line 2107
    :cond_102
    invoke-virtual {v8}, Lcom/android/server/am/ProcessServiceRecord;->isTreatedLikeActivity()Z

    move-result v10

    if-eqz v10, :cond_116

    .line 2108
    if-eqz v9, :cond_110

    .line 2109
    const-string/jumbo v10, "|"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2111
    :cond_110
    const-string/jumbo v10, "treated"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2114
    .end local v9    # "printed":Z
    :cond_116
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2065
    .end local v7    # "proc":Lcom/android/server/am/ProcessRecord;
    .end local v8    # "psr":Lcom/android/server/am/ProcessServiceRecord;
    :cond_11d
    add-int/lit8 v6, v6, -0x1

    goto/16 :goto_44

    .line 2117
    .end local v3    # "lruProcesses":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/ProcessRecord;>;"
    .end local v4    # "current":J
    .end local v6    # "i":I
    :cond_121
    monitor-exit v2
    :try_end_122
    .catchall {:try_start_1f .. :try_end_122} :catchall_126

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterProcLockedSection()V

    .line 2118
    return-object v0

    .line 2117
    :catchall_126
    move-exception v3

    :try_start_127
    monitor-exit v2
    :try_end_128
    .catchall {:try_start_127 .. :try_end_128} :catchall_126

    invoke-static {}, Lcom/android/server/am/ActivityManagerService;->resetPriorityAfterProcLockedSection()V

    throw v3
.end method

.method public getProcessPssRawData()Ljava/util/ArrayList;
    .registers 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 2176
    move-object/from16 v0, p0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 2177
    .local v1, "infos":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    sget-object v2, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_LABEL:[Ljava/lang/String;

    array-length v2, v2

    new-array v7, v2, [J

    .line 2178
    .local v7, "oomPss":[J
    sget-object v2, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_LABEL:[Ljava/lang/String;

    array-length v2, v2

    new-array v8, v2, [J

    .line 2179
    .local v8, "oomSwapPss":[J
    sget-object v2, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_LABEL:[Ljava/lang/String;

    array-length v2, v2

    new-array v9, v2, [Ljava/util/ArrayList;

    .line 2181
    .local v9, "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 2182
    .local v2, "sb":Ljava/lang/StringBuilder;
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 2183
    .local v6, "procMems":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    new-instance v4, Landroid/util/SparseArray;

    invoke-direct {v4}, Landroid/util/SparseArray;-><init>()V

    .line 2185
    .local v4, "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    new-instance v3, Landroid/os/Debug$MemoryInfo;

    invoke-direct {v3}, Landroid/os/Debug$MemoryInfo;-><init>()V

    move-object v10, v3

    .line 2186
    .local v10, "mi":Landroid/os/Debug$MemoryInfo;
    sget-object v3, Lcom/android/server/am/IOplusAthenaAmManager;->DEFAULT:Lcom/android/server/am/IOplusAthenaAmManager;

    .line 2187
    invoke-static {v3}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v3

    check-cast v3, Lcom/android/server/am/IOplusAthenaAmManager;

    const/4 v5, 0x0

    invoke-interface {v3, v5}, Lcom/android/server/am/IOplusAthenaAmManager;->getPackageFreezeDataInfos(Ljava/util/List;)Ljava/util/List;

    move-result-object v11

    .line 2188
    .local v11, "allApps":Ljava/util/List;, "Ljava/util/List<Lcom/oplus/util/OplusPackageFreezeData;>;"
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_3c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_10e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/oplus/util/OplusPackageFreezeData;

    .line 2189
    .local v5, "proc":Lcom/oplus/util/OplusPackageFreezeData;
    if-nez v5, :cond_4b

    .line 2190
    goto :goto_3c

    .line 2192
    :cond_4b
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getPid()I

    move-result v12

    invoke-static {v12, v10}, Landroid/os/Debug;->getMemoryInfo(ILandroid/os/Debug$MemoryInfo;)Z

    move-result v12

    if-nez v12, :cond_56

    .line 2193
    goto :goto_3c

    .line 2195
    :cond_56
    new-instance v13, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 2196
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getProcessName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v14, " (pid "

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getPid()I

    move-result v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v14, ")"

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    .line 2197
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getProcessName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v10}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v12

    move-object/from16 v28, v8

    move-object/from16 v29, v9

    .end local v8    # "oomSwapPss":[J
    .end local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .local v28, "oomSwapPss":[J
    .local v29, "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    int-to-long v8, v12

    invoke-virtual {v10}, Landroid/os/Debug$MemoryInfo;->getSummaryTotalSwapPss()I

    move-result v12

    move-wide/from16 v16, v8

    int-to-long v8, v12

    .line 2198
    invoke-virtual {v10}, Landroid/os/Debug$MemoryInfo;->getTotalRss()I

    move-result v12

    move-wide/from16 v18, v8

    int-to-long v8, v12

    .line 2199
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getPid()I

    move-result v24

    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getUserId()I

    move-result v25

    const/16 v26, 0x0

    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getCurAdj()I

    move-result v27

    const-wide/16 v22, 0x0

    move-wide/from16 v20, v8

    invoke-direct/range {v13 .. v27}, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJIIZI)V

    .line 2200
    .local v13, "pssItem":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2201
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getPid()I

    move-result v8

    invoke-virtual {v4, v8, v13}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 2203
    const/4 v8, 0x0

    .local v8, "oomIndex":I
    :goto_b8
    array-length v9, v7

    if-ge v8, v9, :cond_102

    .line 2204
    array-length v9, v7

    add-int/lit8 v9, v9, -0x1

    if-eq v8, v9, :cond_da

    .line 2205
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getCurAdj()I

    move-result v9

    sget-object v12, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_ADJ:[I

    aget v12, v12, v8

    if-lt v9, v12, :cond_d7

    .line 2206
    invoke-virtual {v5}, Lcom/oplus/util/OplusPackageFreezeData;->getCurAdj()I

    move-result v9

    sget-object v12, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_ADJ:[I

    add-int/lit8 v14, v8, 0x1

    aget v12, v12, v14

    if-ge v9, v12, :cond_d7

    goto :goto_da

    .line 2203
    :cond_d7
    add-int/lit8 v8, v8, 0x1

    goto :goto_b8

    .line 2207
    :cond_da
    :goto_da
    aget-wide v14, v7, v8

    invoke-virtual {v10}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v9

    move-object/from16 v16, v3

    move-object v12, v4

    .end local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .local v12, "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    int-to-long v3, v9

    add-long/2addr v14, v3

    aput-wide v14, v7, v8

    .line 2208
    aget-wide v3, v28, v8

    invoke-virtual {v10}, Landroid/os/Debug$MemoryInfo;->getSummaryTotalSwapPss()I

    move-result v9

    int-to-long v14, v9

    add-long/2addr v3, v14

    aput-wide v3, v28, v8

    .line 2209
    aget-object v3, v29, v8

    if-nez v3, :cond_fc

    .line 2210
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    aput-object v3, v29, v8

    .line 2212
    :cond_fc
    aget-object v3, v29, v8

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2213
    goto :goto_105

    .line 2203
    .end local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    :cond_102
    move-object/from16 v16, v3

    move-object v12, v4

    .line 2216
    .end local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v5    # "proc":Lcom/oplus/util/OplusPackageFreezeData;
    .end local v8    # "oomIndex":I
    .end local v13    # "pssItem":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    .restart local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    :goto_105
    move-object v4, v12

    move-object/from16 v3, v16

    move-object/from16 v8, v28

    move-object/from16 v9, v29

    goto/16 :goto_3c

    .line 2217
    .end local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v28    # "oomSwapPss":[J
    .end local v29    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .local v8, "oomSwapPss":[J
    .restart local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    :cond_10e
    move-object v12, v4

    move-object/from16 v28, v8

    move-object/from16 v29, v9

    .end local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v8    # "oomSwapPss":[J
    .end local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v28    # "oomSwapPss":[J
    .restart local v29    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    iget-object v3, v0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    if-eqz v3, :cond_12e

    .line 2218
    new-instance v5, Landroid/os/Debug$MemoryInfo;

    invoke-direct {v5}, Landroid/os/Debug$MemoryInfo;-><init>()V

    .line 2219
    .local v5, "info":Landroid/os/Debug$MemoryInfo;
    iget-object v3, v0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    iget-object v13, v3, Lcom/android/server/am/ActivityManagerService;->mAppProfiler:Lcom/android/server/am/AppProfiler;

    new-instance v3, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda7;

    move-object v4, v12

    move-object/from16 v8, v28

    move-object/from16 v9, v29

    .end local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v28    # "oomSwapPss":[J
    .end local v29    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v8    # "oomSwapPss":[J
    .restart local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    invoke-direct/range {v3 .. v9}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda7;-><init>(Landroid/util/SparseArray;Landroid/os/Debug$MemoryInfo;Ljava/util/ArrayList;[J[J[Ljava/util/ArrayList;)V

    invoke-virtual {v13, v3}, Lcom/android/server/am/AppProfiler;->forAllCpuStats(Ljava/util/function/Consumer;)V

    goto :goto_133

    .line 2217
    .end local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v5    # "info":Landroid/os/Debug$MemoryInfo;
    .end local v8    # "oomSwapPss":[J
    .end local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v28    # "oomSwapPss":[J
    .restart local v29    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    :cond_12e
    move-object v4, v12

    move-object/from16 v8, v28

    move-object/from16 v9, v29

    .line 2238
    .end local v12    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .end local v28    # "oomSwapPss":[J
    .end local v29    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v4    # "procMemsMap":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    .restart local v8    # "oomSwapPss":[J
    .restart local v9    # "oomProcs":[Ljava/util/ArrayList;, "[Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    :goto_133
    new-instance v3, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda8;

    invoke-direct {v3}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda8;-><init>()V

    invoke-static {v6, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 2244
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 2245
    .local v3, "oomMems":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;>;"
    const/4 v5, 0x0

    .local v5, "j":I
    :goto_141
    array-length v12, v7

    const-wide/16 v13, 0x0

    if-ge v5, v12, :cond_17c

    .line 2246
    aget-wide v15, v7, v5

    cmp-long v12, v15, v13

    if-eqz v12, :cond_179

    .line 2247
    sget-object v12, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_LABEL:[Ljava/lang/String;

    aget-object v14, v12, v5

    .line 2248
    .local v14, "label":Ljava/lang/String;
    new-instance v13, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    aget-wide v16, v7, v5

    aget-wide v18, v8, v5

    sget-object v12, Lcom/android/server/am/ActivityManagerService;->DUMP_MEM_OOM_ADJ:[I

    aget v24, v12, v5

    const/16 v26, 0x0

    const/16 v27, -0x2710

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const/16 v25, 0x0

    move-object v15, v14

    invoke-direct/range {v13 .. v27}, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJIIZI)V

    .line 2251
    .local v13, "item":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    aget-object v12, v9, v5

    iput-object v12, v13, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->subitems:Ljava/util/ArrayList;

    .line 2252
    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2253
    iget-object v12, v13, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;->subitems:Ljava/util/ArrayList;

    new-instance v15, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda9;

    invoke-direct {v15}, Lcom/android/server/am/OplusOsenseKillAction$$ExternalSyntheticLambda9;-><init>()V

    invoke-static {v12, v15}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 2245
    .end local v13    # "item":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    .end local v14    # "label":Ljava/lang/String;
    :cond_179
    add-int/lit8 v5, v5, 0x1

    goto :goto_141

    .line 2256
    .end local v5    # "j":I
    :cond_17c
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_180
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_194

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;

    .line 2257
    .local v12, "it":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    if-eqz v12, :cond_193

    .line 2258
    const-string v15, "  "

    invoke-direct {v0, v1, v2, v15, v12}, Lcom/android/server/am/OplusOsenseKillAction;->dumpMyMemItem(Ljava/util/ArrayList;Ljava/lang/StringBuilder;Ljava/lang/String;Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;)V

    .line 2260
    .end local v12    # "it":Lcom/android/server/am/OplusOsenseKillAction$MyMemItem;
    :cond_193
    goto :goto_180

    .line 2261
    :cond_194
    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2262
    const/16 v12, 0xa

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2263
    invoke-static {}, Landroid/os/Debug;->getDmabufMappedSizeKb()J

    move-result-wide v15

    .line 2264
    .local v15, "dmabufMapped":J
    invoke-static {}, Landroid/os/Debug;->getDmabufTotalExportedKb()J

    move-result-wide v17

    .line 2265
    .local v17, "totalExportedDmabuf":J
    cmp-long v12, v17, v13

    move-wide/from16 v19, v13

    const-string v13, " ("

    if-ltz v12, :cond_1da

    .line 2266
    sub-long v21, v17, v15

    .line 2267
    .local v21, "dmabufUnmapped":J
    const-string v12, "DMA-BUF: "

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-static/range {v17 .. v18}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2268
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-static/range {v15 .. v16}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v14, " mapped + "

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2269
    invoke-static/range {v21 .. v22}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v14, " unmapped)"

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2271
    .end local v21    # "dmabufUnmapped":J
    :cond_1da
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2273
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2274
    invoke-static {}, Landroid/os/Debug;->getDmabufHeapTotalExportedKb()J

    move-result-wide v21

    .line 2275
    .local v21, "totalDmabufHeapExported":J
    cmp-long v12, v21, v19

    if-ltz v12, :cond_1f9

    .line 2276
    const-string v12, "DMA-BUF Heaps: "

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-static/range {v21 .. v22}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2278
    :cond_1f9
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2280
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2281
    invoke-static {}, Landroid/os/Debug;->getDmabufHeapPoolsSizeKb()J

    move-result-wide v23

    .line 2282
    .local v23, "totalDmabufHeapPool":J
    cmp-long v12, v23, v19

    if-ltz v12, :cond_218

    .line 2283
    const-string v12, "DMA-BUF Heaps pool: "

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-static/range {v23 .. v24}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2285
    :cond_218
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2287
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2288
    invoke-static {}, Landroid/os/Debug;->getGpuTotalUsageKb()J

    move-result-wide v25

    .line 2289
    .local v25, "gpuUsage":J
    cmp-long v12, v25, v19

    if-ltz v12, :cond_26a

    .line 2290
    invoke-static {}, Landroid/os/Debug;->getGpuPrivateMemoryKb()J

    move-result-wide v27

    .line 2291
    .local v27, "gpuPrivateUsage":J
    cmp-long v12, v27, v19

    const-string v14, "      GPU: "

    if-ltz v12, :cond_25f

    .line 2292
    sub-long v19, v25, v27

    .line 2293
    .local v19, "gpuDmaBufUsage":J
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2294
    invoke-static/range {v25 .. v26}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2295
    invoke-static/range {v19 .. v20}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " dmabuf + "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2296
    invoke-static/range {v27 .. v28}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " private)"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2297
    .end local v19    # "gpuDmaBufUsage":J
    goto :goto_26a

    .line 2298
    :cond_25f
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-static/range {v25 .. v26}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2301
    .end local v27    # "gpuPrivateUsage":J
    :cond_26a
    :goto_26a
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2303
    new-instance v12, Lcom/android/internal/util/MemInfoReader;

    invoke-direct {v12}, Lcom/android/internal/util/MemInfoReader;-><init>()V

    .line 2304
    .local v12, "memInfo":Lcom/android/internal/util/MemInfoReader;
    invoke-virtual {v12}, Lcom/android/internal/util/MemInfoReader;->readMemInfo()V

    .line 2305
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 2306
    const-string v5, "     ZRAM: "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2307
    invoke-virtual {v12}, Lcom/android/internal/util/MemInfoReader;->getZramTotalSizeKb()J

    move-result-wide v13

    invoke-static {v13, v14}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, " physical used for "

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2308
    invoke-virtual {v12}, Lcom/android/internal/util/MemInfoReader;->getSwapTotalSizeKb()J

    move-result-wide v13

    invoke-virtual {v12}, Lcom/android/internal/util/MemInfoReader;->getSwapFreeSizeKb()J

    move-result-wide v19

    sub-long v13, v13, v19

    invoke-static {v13, v14}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, " in swap ("

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2309
    invoke-virtual {v12}, Lcom/android/internal/util/MemInfoReader;->getSwapTotalSizeKb()J

    move-result-wide v13

    invoke-static {v13, v14}, Lcom/android/server/am/ActivityManagerService;->stringifyKBSize(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, " total swap)"

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2310
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2311
    return-object v1
.end method

.method public handleAppStart(ILjava/lang/String;Landroid/content/ComponentName;)V
    .registers 7
    .param p1, "uid"    # I
    .param p2, "packageName"    # Ljava/lang/String;
    .param p3, "componentName"    # Landroid/content/ComponentName;

    .line 574
    iput p1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    .line 575
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0, p2, p3}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "KillAction"

    const-string/jumbo v2, "handleAppStart: %d %s %s"

    invoke-static {v1, v2, v0}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 576
    return-void
.end method

.method public init(Lcom/android/server/am/ActivityManagerService;Landroid/content/Context;)V
    .registers 5
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "context"    # Landroid/content/Context;

    .line 315
    iput-object p1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mAms:Lcom/android/server/am/ActivityManagerService;

    .line 316
    iget-object v0, p1, Lcom/android/server/am/ActivityManagerService;->mProcLock:Lcom/android/server/am/ActivityManagerGlobalLock;

    iput-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mProcLock:Lcom/android/server/am/ActivityManagerGlobalLock;

    .line 317
    iput-object p2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mContext:Landroid/content/Context;

    .line 318
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandler:Lcom/android/server/am/OplusOsenseKillAction$KillHandler;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/android/server/am/OplusOsenseKillAction$KillHandler;->sendEmptyMessage(I)Z

    .line 319
    return-void
.end method

.method public isEnable()Z
    .registers 3

    .line 2010
    iget-boolean v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mSetDebugDisable:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    .line 2011
    return v1

    .line 2013
    :cond_6
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->isEnable()Z

    move-result v0

    if-eqz v0, :cond_22

    iget-boolean v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mReady:Z

    if-eqz v0, :cond_22

    sget-object v0, Lcom/android/server/am/IOplusHansManager;->DEFAULT:Lcom/android/server/am/IOplusHansManager;

    .line 2014
    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/am/IOplusHansManager;

    invoke-interface {v0}, Lcom/android/server/am/IOplusHansManager;->isCgroupV2()Z

    move-result v0

    if-eqz v0, :cond_22

    const/4 v1, 0x1

    goto :goto_23

    :cond_22
    nop

    .line 2013
    :goto_23
    return v1
.end method

.method public isNonActivityPackage(Ljava/lang/String;)Z
    .registers 3
    .param p1, "packageName"    # Ljava/lang/String;

    .line 567
    sget-object v0, Lcom/android/server/am/ConfigUtil;->DEFAULT_NON_ACTIVITY_PKG_LIST:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public onActivityIdle(Landroid/content/pm/ActivityInfo;)V
    .registers 5
    .param p1, "aInfo"    # Landroid/content/pm/ActivityInfo;

    .line 583
    if-eqz p1, :cond_1f

    iget-object v0, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    if-nez v0, :cond_7

    goto :goto_1f

    .line 586
    :cond_7
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    iget-object v1, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    if-ne v0, v1, :cond_12

    .line 587
    const/4 v0, 0x0

    iput v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mLastStartActivityUid:I

    .line 589
    :cond_12
    const-string/jumbo v0, "onActivityIdle: %s"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "KillAction"

    invoke-static {v2, v0, v1}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 590
    return-void

    .line 584
    :cond_1f
    :goto_1f
    return-void
.end method

.method public onBloSceneChange(IZ)V
    .registers 5
    .param p1, "id"    # I
    .param p2, "status"    # Z

    .line 407
    sget-object v0, Lcom/android/server/am/OplusOsenseKillAction$1;->$SwitchMap$com$android$server$oplus$osense$feature$blo$OplusBloManager$SceneType:[I

    invoke-static {p1}, Lcom/android/server/oplus/osense/feature/blo/OplusBloManager$SceneType;->getScene(I)Lcom/android/server/oplus/osense/feature/blo/OplusBloManager$SceneType;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/oplus/osense/feature/blo/OplusBloManager$SceneType;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_18

    goto :goto_16

    .line 413
    :pswitch_10
    iput-boolean p2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInBloMoreBg:Z

    .line 414
    goto :goto_16

    .line 409
    :pswitch_13
    iput-boolean p2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mInBloPerf:Z

    .line 410
    nop

    .line 419
    :goto_16
    return-void

    nop

    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_13
        :pswitch_10
    .end packed-switch
.end method

.method public onPackageStatusChange(Ljava/lang/String;Ljava/lang/String;ZI)V
    .registers 5
    .param p1, "pkgName"    # Ljava/lang/String;
    .param p2, "action"    # Ljava/lang/String;
    .param p3, "isReInstall"    # Z
    .param p4, "uid"    # I

    .line 404
    return-void
.end method

.method public onUserStatusChange(IZ)V
    .registers 3
    .param p1, "userId"    # I
    .param p2, "isUserStarted"    # Z

    .line 400
    return-void
.end method

.method public passThroughAppCare(I)Z
    .registers 3
    .param p1, "appcareThreshold"    # I

    .line 2028
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->getPassThroughAppCareThreshold()I

    move-result v0

    if-lt p1, v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method

.method public registerSysStateChangeObserver(Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/datasync/ISysStateChangeCallback;

    .line 457
    if-nez p1, :cond_4

    .line 458
    const/4 v0, 0x0

    return v0

    .line 460
    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "registerSysStateChangeObserver: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "KillAction"

    invoke-static {v1, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 461
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    invoke-virtual {v0, p1}, Landroid/os/RemoteCallbackList;->register(Landroid/os/IInterface;)Z

    move-result v0

    return v0
.end method

.method resetPriority()V
    .registers 3

    .line 4543
    sget-boolean v0, Lcom/android/server/am/OplusOsenseKillAction;->sUsefifo:Z

    if-eqz v0, :cond_b

    .line 4544
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/android/server/am/ActivityManagerService;->scheduleAsRegularPriority(IZ)Z

    goto :goto_11

    .line 4546
    :cond_b
    iget v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mHandlerThreadTid:I

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/android/server/am/OplusOsenseKillAction;->setThreadUx(IZ)V

    .line 4548
    :goto_11
    return-void
.end method

.method public shouldSkip(Ljava/lang/String;Ljava/lang/String;I)Z
    .registers 5
    .param p1, "scene"    # Ljava/lang/String;
    .param p2, "policyType"    # Ljava/lang/String;
    .param p3, "appcareThreshold"    # I

    .line 2022
    sget-object v0, Lcom/android/server/pm/IOplusFullmodeManager;->DEFAULT:Lcom/android/server/pm/IOplusFullmodeManager;

    invoke-static {v0}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/pm/IOplusFullmodeManager;

    invoke-interface {v0}, Lcom/android/server/pm/IOplusFullmodeManager;->isClosedSuperFirewall()Z

    move-result v0

    if-nez v0, :cond_29

    .line 2023
    invoke-virtual {p0, p1}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkipScene(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_29

    invoke-virtual {p0, p2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkipClearPolicyType(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_29

    .line 2024
    invoke-virtual {p0, p1, p2}, Lcom/android/server/am/OplusOsenseKillAction;->shouldSkipBlast(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_29

    invoke-virtual {p0, p3}, Lcom/android/server/am/OplusOsenseKillAction;->passThroughAppCare(I)Z

    move-result v0

    if-eqz v0, :cond_27

    goto :goto_29

    :cond_27
    const/4 v0, 0x0

    goto :goto_2a

    :cond_29
    :goto_29
    const/4 v0, 0x1

    .line 2022
    :goto_2a
    return v0
.end method

.method public shouldSkipBlast(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 4
    .param p1, "scene"    # Ljava/lang/String;
    .param p2, "type"    # Ljava/lang/String;

    .line 2044
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->isBlastScene(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p2}, Lcom/android/server/am/ConfigUtil;->isBlastPolicyType(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_13

    .line 2049
    :cond_11
    const/4 v0, 0x0

    return v0

    .line 2046
    :cond_13
    :goto_13
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->isEnableBlastHandle()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public shouldSkipClearPolicyType(Ljava/lang/String;)Z
    .registers 3
    .param p1, "type"    # Ljava/lang/String;

    .line 2040
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->shouldSkipClearPolicyType(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public shouldSkipScene(Ljava/lang/String;)Z
    .registers 3
    .param p1, "scene"    # Ljava/lang/String;

    .line 2032
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->shouldSkipScene(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public supportProactiveClean(Ljava/lang/String;)Z
    .registers 3
    .param p1, "processName"    # Ljava/lang/String;

    .line 2122
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->isEnableProactiveClean()Z

    move-result v0

    if-nez v0, :cond_a

    .line 2123
    const/4 v0, 0x0

    return v0

    .line 2125
    :cond_a
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0}, Lcom/android/server/am/ConfigUtil;->isEnableProactiveCleanBlackList()Z

    move-result v0

    if-eqz v0, :cond_19

    .line 2126
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->isProactiveCleanProcess(Ljava/lang/String;)Z

    move-result v0

    return v0

    .line 2128
    :cond_19
    const/4 v0, 0x1

    return v0
.end method

.method public unregisterSysStateChangeObserver(Lcom/oplus/datasync/ISysStateChangeCallback;)Z
    .registers 4
    .param p1, "observer"    # Lcom/oplus/datasync/ISysStateChangeCallback;

    .line 466
    if-nez p1, :cond_4

    .line 467
    const/4 v0, 0x0

    return v0

    .line 469
    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "unregisterSysStateChangeObserver: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "KillAction"

    invoke-static {v1, v0}, Lcom/android/server/am/LogUtil;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 470
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mISysStateChangeCallbacks:Landroid/os/RemoteCallbackList;

    invoke-virtual {v0, p1}, Landroid/os/RemoteCallbackList;->unregister(Landroid/os/IInterface;)Z

    move-result v0

    return v0
.end method

.method public updateAppData(Landroid/os/Bundle;)Z
    .registers 6
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 439
    const/4 v0, 0x0

    const-string v1, "KillAction"

    if-nez p1, :cond_c

    .line 440
    const-string/jumbo v2, "updateAppData... bundle is null"

    invoke-static {v1, v2}, Lcom/android/server/am/LogUtil;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 441
    return v0

    .line 443
    :cond_c
    invoke-virtual {p1}, Landroid/os/Bundle;->toString()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string/jumbo v3, "updateAppData: %s "

    invoke-static {v1, v3, v2}, Lcom/android/server/am/LogUtil;->formatD(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 445
    const-string v1, "athena_remote_config_flag"

    const-string v2, "data_sync_flag_key"

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_39

    .line 446
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mClearAppCare:Lcom/android/server/oplus/osense/prockill/ClearAppCare;

    invoke-virtual {v0, p1}, Lcom/android/server/oplus/osense/prockill/ClearAppCare;->updateAthenaConfig(Landroid/os/Bundle;)V

    .line 447
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->updateProactiveCleanConfig(Landroid/os/Bundle;)V

    .line 448
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v0, p1}, Lcom/android/server/am/ConfigUtil;->updateAthenaRemoteConfig(Landroid/os/Bundle;)Z

    move-result v0

    return v0

    .line 449
    :cond_39
    const-string v1, "athena_custom_config_flag"

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4b

    .line 450
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/android/server/am/OplusOsenseKillAction;->updateConfig(Landroid/os/Bundle;Z)Z

    move-result v0

    return v0

    .line 452
    :cond_4b
    return v0
.end method

.method public updateConfig(Landroid/os/Bundle;Z)Z
    .registers 7
    .param p1, "bundle"    # Landroid/os/Bundle;
    .param p2, "custom"    # Z

    .line 2315
    const/4 v0, 0x0

    .line 2316
    .local v0, "ret":I
    const-string v1, "atomicCleanConfig"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    .line 2317
    iget-object v2, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    .line 2318
    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v1

    .line 2317
    invoke-virtual {v2, v1, p2}, Lcom/android/server/am/ConfigUtil;->updateBaseConfig(Landroid/os/Bundle;Z)Z

    move-result v1

    if-eqz v1, :cond_18

    .line 2318
    move v1, v3

    goto :goto_19

    :cond_18
    const/4 v1, 0x2

    :goto_19
    or-int/2addr v0, v1

    .line 2320
    :cond_1a
    const-string v1, "atomicCleanProcessWhiteList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2e

    .line 2321
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateProcessWhiteListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_2c

    move v1, v3

    goto :goto_2d

    :cond_2c
    const/4 v1, 0x4

    :goto_2d
    or-int/2addr v0, v1

    .line 2323
    :cond_2e
    const-string v1, "atomicCleanCchProcessWhiteList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_43

    .line 2324
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateCchProcessWhiteListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_40

    move v1, v3

    goto :goto_42

    :cond_40
    const/16 v1, 0x400

    :goto_42
    or-int/2addr v0, v1

    .line 2326
    :cond_43
    const-string v1, "atomicCleanPackageWhiteList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/16 v2, 0x8

    if-eqz v1, :cond_59

    .line 2327
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updatePkgWhiteListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_57

    move v1, v3

    goto :goto_58

    :cond_57
    move v1, v2

    :goto_58
    or-int/2addr v0, v1

    .line 2329
    :cond_59
    const-string v1, "atomicCleanCchPackageWhiteList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6b

    .line 2330
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateCchPkgWhiteListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_6a

    move v2, v3

    :cond_6a
    or-int/2addr v0, v2

    .line 2332
    :cond_6b
    const-string v1, "atomicCleanSkipSceneList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 2333
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateSkipSceneListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_7d

    move v1, v3

    goto :goto_7f

    :cond_7d
    const/16 v1, 0x10

    :goto_7f
    or-int/2addr v0, v1

    .line 2335
    :cond_80
    const-string v1, "atomicCleanSkipClearPolicyTypeList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_95

    .line 2336
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateSkipClearPolicyTypeListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_92

    move v1, v3

    goto :goto_94

    :cond_92
    const/16 v1, 0x20

    :goto_94
    or-int/2addr v0, v1

    .line 2338
    :cond_95
    const-string v1, "atomicCleanCachedCleanOnlyPolicyTypeList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_aa

    .line 2339
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateCachedCleanOnlyPolicyTypeListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_a7

    move v1, v3

    goto :goto_a9

    :cond_a7
    const/16 v1, 0x40

    :goto_a9
    or-int/2addr v0, v1

    .line 2341
    :cond_aa
    const-string v1, "atomicCleanWhitelistedServices"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_bf

    .line 2342
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateWhitelistedServicesConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_bc

    move v1, v3

    goto :goto_be

    :cond_bc
    const/16 v1, 0x80

    :goto_be
    or-int/2addr v0, v1

    .line 2344
    :cond_bf
    const-string v1, "atomicCleanBlastSceneList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_d4

    .line 2345
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateBlastSceneListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_d1

    move v1, v3

    goto :goto_d3

    :cond_d1
    const/16 v1, 0x100

    :goto_d3
    or-int/2addr v0, v1

    .line 2347
    :cond_d4
    const-string v1, "atomicCleanBlastPolicyTypeList"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e9

    .line 2348
    iget-object v1, p0, Lcom/android/server/am/OplusOsenseKillAction;->mConfigUtil:Lcom/android/server/am/ConfigUtil;

    invoke-virtual {v1, p1}, Lcom/android/server/am/ConfigUtil;->updateBlastPolicyTypeListConfig(Landroid/os/Bundle;)Z

    move-result v1

    if-eqz v1, :cond_e6

    move v1, v3

    goto :goto_e8

    :cond_e6
    const/16 v1, 0x200

    :goto_e8
    or-int/2addr v0, v1

    .line 2350
    :cond_e9
    if-nez v0, :cond_ec

    const/4 v3, 0x1

    :cond_ec
    return v3
.end method

.method public updateQuickBootMode(Z)V
    .registers 3
    .param p1, "enter"    # Z

    .line 322
    iget-object v0, p0, Lcom/android/server/am/OplusOsenseKillAction;->mQuickBoot:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 323
    return-void
.end method
