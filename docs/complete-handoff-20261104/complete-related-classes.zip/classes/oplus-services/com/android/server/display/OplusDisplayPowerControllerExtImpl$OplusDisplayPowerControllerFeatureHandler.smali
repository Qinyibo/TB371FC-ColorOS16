.class Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;
.super Landroid/os/Handler;
.source "OplusDisplayPowerControllerExtImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "OplusDisplayPowerControllerFeatureHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;


# direct methods
.method public constructor <init>(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;Landroid/os/Looper;)V
    .registers 4
    .param p2, "looper"    # Landroid/os/Looper;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 376
    iput-object p1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    .line 377
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 378
    invoke-static {p1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "OplusDisplayPowerControllerFeatureHandler init"

    invoke-static {p1, v0}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 379
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;

    .line 383
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetTAG(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "handleMessage:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 384
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_60

    :pswitch_24
    goto :goto_5f

    .line 393
    :pswitch_25
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmContext(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/content/Context;

    move-result-object v0

    const-class v1, Landroid/hardware/display/DisplayManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManager;

    .line 394
    .local v0, "displayManager":Landroid/hardware/display/DisplayManager;
    iget-object v1, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmDisplayListener(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Landroid/hardware/display/DisplayManager$DisplayListener;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v2}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmHandler(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    .line 395
    goto :goto_5f

    .line 387
    .end local v0    # "displayManager":Landroid/hardware/display/DisplayManager;
    :pswitch_43
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    invoke-static {v0}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->-$$Nest$fgetmPendingScreenOnUnblockerFromBiometrics(Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;)Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$ScreenOnUnblockerByBiometrics;

    move-result-object v0

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    if-ne v0, v1, :cond_5f

    .line 388
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    const-string v1, "MSG_SCREEN_ON_UNBLOCKED_BY_BIOMETRICS"

    invoke-virtual {v0, v1}, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->unblockScreenOnByBiometrics(Ljava/lang/String;)V

    .line 389
    iget-object v0, p0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl$OplusDisplayPowerControllerFeatureHandler;->this$0:Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;

    iget-object v0, v0, Lcom/android/server/display/OplusDisplayPowerControllerExtImpl;->mDpc:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->updatePowerState()V

    .line 399
    :cond_5f
    :goto_5f
    return-void

    :pswitch_data_60
    .packed-switch 0x3e9
        :pswitch_43
        :pswitch_24
        :pswitch_25
    .end packed-switch
.end method
