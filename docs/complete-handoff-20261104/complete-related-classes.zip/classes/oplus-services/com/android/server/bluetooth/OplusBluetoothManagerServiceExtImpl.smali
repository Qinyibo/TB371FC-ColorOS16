.class public Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;
.super Ljava/lang/Object;
.source "OplusBluetoothManagerServiceExtImpl.java"

# interfaces
.implements Lcom/android/server/bluetooth/IOplusBluetoothManagerServiceExt;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;,
        Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;
    }
.end annotation


# static fields
.field private static final ACTION_RESET_BLUETOOTH:Ljava/lang/String; = "android.bluetooth.adapter.action.RESET_BLUETOOTH"

.field private static final APP_FEATURE_CUSTOMIZE_ENABLE_BLUETOOTH:Ljava/lang/String; = "oplus.software.connectivity.enable_bluetooth"

.field private static final BLUETOOTH_MANAGER_SERVICE:Ljava/lang/String; = "bluetooth_manager"

.field private static final BLUETOOTH_OFF:I = 0x0

.field private static final BLUETOOTH_ON_AIRPLANE:I = 0x2

.field private static final BLUETOOTH_ON_BLUETOOTH:I = 0x1

.field private static final BROADCAST_PERMISSION_BLUETOOTH_RESET:Ljava/lang/String; = "com.android.bluetooth.permission.RESET_BLUETOOTH"

.field private static final GMS_PACKAGENAME:Ljava/lang/String; = "com.google.android.gms"

.field private static final KEY_OPLUSTESTMODE_PERMISSION:Ljava/lang/String; = "persist.sys.permission.enable"

.field private static final MAX_ERROR_RESTART_RETRIES:I = 0x6

.field private static final MAX_SAVE_RETRIES:I = 0x3

.field private static final MESSAGE_GET_NAME_AND_ADDRESS:I = 0xc8

.field private static final MESSAGE_RESET_BLUETOOTH:I = 0x1

.field private static final MESSAGE_SAVE_NAME_AND_ADDRESS:I = 0x2

.field private static final MESSAGE_SET_FORGROUND_USER_ID:I = 0x3

.field private static final PACKAGE_NAME_DEFAULT:Ljava/lang/String; = "com.oplus.oshare"

.field private static final PACKAGE_NAME_OPLUS:Ljava/lang/String;

.field private static final PACKAGE_NAME_OSHARE:Ljava/lang/String;

.field private static final PROPERTY_ENGINEER_AGING_MODE:Ljava/lang/String; = "sys.oplus.eng.aging"

.field private static final PROPERTY_MY_ENG_IMG_TYPE:Ljava/lang/String; = "ro.oplus.image.my_engineering.type"

.field private static final TAG:Ljava/lang/String; = "OplusBluetoothManagerServiceExtImpl"

.field private static final TIMEOUT_SAVE_MS:I = 0x1f4

.field private static final disableBlutoothCompletelyApp:[Ljava/lang/String;


# instance fields
.field private DBG:Z

.field private mBluetoothAdapterExt:Landroid/bluetooth/BluetoothAdapterExtImpl;

.field private mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

.field private final mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

.field private mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

.field private mBtSwitchLog:Lcom/android/server/bluetooth/bugreport/OplusBtSwitchLog;

.field private mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

.field private mContext:Landroid/content/Context;

.field private mIgnoreNextCrash:Z

.field private mIsBluetoothBinded:Z

.field private final mOplusBluetoothCallback:Landroid/bluetooth/IOplusBluetoothCallback;

.field private mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

.field private mOplusBluetoothRfTestCheck:Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

.field private mOplusBtFwDumpCheck:Lcom/android/server/bluetooth/btfwdump/OplusBluetoothFirmwareDumpCheck;

.field private mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

.field private final mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

.field private final mOplusReceiver:Landroid/content/BroadcastReceiver;

.field private final mOplusServiceLifecycleCallback:Landroid/bluetooth/BluetoothAdapterExtImpl$OplusServiceLifecycleCallback;


# direct methods
.method static bridge synthetic -$$Nest$fgetDBG(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmBms(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Lcom/android/server/bluetooth/BluetoothManagerService;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmBtSwitchRecorder(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmContext(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusBluetoothCallback(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Landroid/bluetooth/IOplusBluetoothCallback;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothCallback:Landroid/bluetooth/IOplusBluetoothCallback;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusBluetoothMonitorManager(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusBtOidt(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusHandler(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;
    .registers 1

    iget-object p0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mwaitForBleOn(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)Z
    .registers 1

    invoke-direct {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->waitForBleOn()Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 96
    invoke-static {}, Landroid/common/CustomizeFrameworkFactory;->getInstance()Landroid/common/CustomizeFrameworkFactory;

    move-result-object v0

    sget-object v1, Landroid/convert/ICustomizeTransformHelper;->DEFAULT:Landroid/convert/ICustomizeTransformHelper;

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {v0, v1, v2}, Landroid/common/CustomizeFrameworkFactory;->getFeature(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Landroid/convert/ICustomizeTransformHelper;

    .line 97
    const-string v1, "config_oplus_transmission_pkg"

    invoke-interface {v0, v1}, Landroid/convert/ICustomizeTransformHelper;->getTransfromCacheFeature(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    sput-object v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->PACKAGE_NAME_OPLUS:Ljava/lang/String;

    .line 99
    sget-object v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->PACKAGE_NAME_OPLUS:Ljava/lang/String;

    if-nez v0, :cond_20

    const-string v0, "com.oplus.oshare"

    goto :goto_22

    :cond_20
    sget-object v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->PACKAGE_NAME_OPLUS:Ljava/lang/String;

    :goto_22
    sput-object v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->PACKAGE_NAME_OSHARE:Ljava/lang/String;

    .line 111
    const-string v0, "com.android.systemui"

    const-string v1, "com.oplus.autotest.otest.phenix"

    const-string v2, "com.oplus.logkit"

    const-string v3, "com.oplus.wirelesssettings"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->disableBlutoothCompletelyApp:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 4
    .param p1, "base"    # Ljava/lang/Object;

    .line 232
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 93
    const-string/jumbo v0, "ro.build.release_type"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_19

    .line 94
    const-string/jumbo v0, "persist.sys.assert.panic"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_17

    goto :goto_19

    :cond_17
    move v0, v1

    goto :goto_1a

    :cond_19
    :goto_19
    const/4 v0, 0x1

    :goto_1a
    iput-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    .line 134
    iput-boolean v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIsBluetoothBinded:Z

    .line 135
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    .line 136
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    .line 137
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchLog:Lcom/android/server/bluetooth/bugreport/OplusBtSwitchLog;

    .line 139
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    .line 140
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    .line 141
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtFwDumpCheck:Lcom/android/server/bluetooth/btfwdump/OplusBluetoothFirmwareDumpCheck;

    .line 142
    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothRfTestCheck:Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

    .line 145
    iput-boolean v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIgnoreNextCrash:Z

    .line 147
    new-instance v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$1;

    invoke-direct {v0, p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$1;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)V

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothCallback:Landroid/bluetooth/IOplusBluetoothCallback;

    .line 194
    new-instance v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$2;

    invoke-direct {v0, p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$2;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)V

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusServiceLifecycleCallback:Landroid/bluetooth/BluetoothAdapterExtImpl$OplusServiceLifecycleCallback;

    .line 215
    new-instance v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$3;

    invoke-direct {v0, p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$3;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)V

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusReceiver:Landroid/content/BroadcastReceiver;

    .line 233
    move-object v0, p1

    check-cast v0, Lcom/android/server/bluetooth/BluetoothManagerService;

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    .line 234
    new-instance v0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    invoke-static {}, Lcom/android/server/IoThread;->get()Lcom/android/server/IoThread;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/IoThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    .line 235
    new-instance v0, Lcom/android/server/bluetooth/BluetoothManagerServiceEnhancer;

    invoke-direct {v0, p0}, Lcom/android/server/bluetooth/BluetoothManagerServiceEnhancer;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)V

    .line 236
    .local v0, "bmsExt":Lcom/android/server/bluetooth/BluetoothManagerServiceEnhancer;
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v1}, Lcom/android/server/bluetooth/BluetoothManagerService;->getBinder()Landroid/bluetooth/IBluetoothManager$Stub;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/bluetooth/IBluetoothManager$Stub;->setExtension(Landroid/os/IBinder;)V

    .line 237
    new-instance v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    invoke-direct {v1, p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;-><init>(Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;)V

    iput-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    .line 238
    return-void
.end method

.method private dcsEventToString(I)Ljava/lang/String;
    .registers 3
    .param p1, "event"    # I

    .line 679
    packed-switch p1, :pswitch_data_18

    .line 691
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 687
    :pswitch_8
    const-string/jumbo v0, "set_ble_app_account"

    return-object v0

    .line 685
    :pswitch_c
    const-string/jumbo v0, "record_error_event"

    return-object v0

    .line 683
    :pswitch_10
    const-string/jumbo v0, "record_adapter_state_change"

    return-object v0

    .line 681
    :pswitch_14
    const-string/jumbo v0, "record_app_call"

    return-object v0

    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_14
        :pswitch_10
        :pswitch_c
        :pswitch_8
    .end packed-switch
.end method

.method private init()V
    .registers 7

    .line 242
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0, v1}, Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;->getInstance(Ljava/lang/Object;Landroid/content/Context;)Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    .line 243
    invoke-direct {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->initExtendFeature()V

    .line 245
    const-string/jumbo v0, "ro.oplus.image.my_engineering.type"

    const-string v1, ""

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "factory"

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "OplusBluetoothManagerServiceExtImpl"

    const/4 v2, 0x1

    if-eqz v0, :cond_3a

    .line 246
    const-string/jumbo v0, "save bluetooth state_on to enable in factory build"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 247
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v0

    invoke-interface {v0, v2}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->persistBluetoothSetting(I)V

    .line 248
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v0

    invoke-interface {v0, v2}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->setEnableExternal(Z)V

    .line 254
    :cond_3a
    invoke-static {}, Landroid/os/oplusdevicepolicy/OplusDevicepolicyManager;->getInstance()Landroid/os/oplusdevicepolicy/OplusDevicepolicyManager;

    move-result-object v0

    .line 255
    .local v0, "policyManager":Landroid/os/oplusdevicepolicy/OplusDevicepolicyManager;
    const-string/jumbo v3, "persist.sys.oplus.bt.policy_switch"

    if-eqz v0, :cond_52

    const/4 v4, 0x3

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    .line 256
    invoke-virtual {v0, v3, v2}, Landroid/os/oplusdevicepolicy/OplusDevicepolicyManager;->getData(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v5

    .line 255
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_58

    .line 257
    :cond_52
    invoke-virtual {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->isOplusCustomizeBluetoothEnabled()Z

    move-result v4

    if-eqz v4, :cond_74

    .line 258
    :cond_58
    iget-boolean v3, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v3, :cond_61

    .line 259
    const-string v3, "The bluetooth_policy is MODE_BT_ENABLED and save bluetooth\'state ON to enable."

    invoke-static {v1, v3}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 261
    :cond_61
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v1}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v1

    invoke-interface {v1, v2}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->persistBluetoothSetting(I)V

    .line 262
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v1}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v1

    invoke-interface {v1, v2}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->setEnableExternal(Z)V

    goto :goto_8e

    .line 264
    :cond_74
    if-eqz v0, :cond_8e

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    .line 265
    invoke-virtual {v0, v3, v2}, Landroid/os/oplusdevicepolicy/OplusDevicepolicyManager;->getData(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    .line 264
    invoke-virtual {v4, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8e

    .line 267
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v2}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v2

    invoke-interface {v2, v1}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->persistBluetoothSetting(I)V

    .line 270
    :cond_8e
    :goto_8e
    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    .line 271
    .local v1, "filter":Landroid/content/IntentFilter;
    const-string v2, "android.bluetooth.adapter.action.RESET_BLUETOOTH"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 272
    const/16 v2, 0x3e8

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->setPriority(I)V

    .line 273
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusReceiver:Landroid/content/BroadcastReceiver;

    const-string v4, "com.android.bluetooth.permission.RESET_BLUETOOTH"

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v1, v4, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    .line 274
    return-void
.end method

.method private initExtendFeature()V
    .registers 2

    .line 277
    invoke-static {}, Lcom/android/server/bluetooth/utils/OplusBtFeatureConfigHelper;->hasSwithLogReport()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 278
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/bugreport/OplusBtSwitchLog;->makeSingleInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/bugreport/OplusBtSwitchLog;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchLog:Lcom/android/server/bluetooth/bugreport/OplusBtSwitchLog;

    .line 281
    :cond_e
    invoke-static {}, Lcom/android/server/bluetooth/utils/OplusBtFeatureConfigHelper;->hasIotEnablelogging()Z

    move-result v0

    if-eqz v0, :cond_24

    .line 282
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;->makeSingleInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    .line 283
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;->makeSingleInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    .line 286
    :cond_24
    invoke-static {}, Lcom/android/server/bluetooth/utils/OplusBtFeatureConfigHelper;->hasBtOidt()Z

    move-result v0

    if-eqz v0, :cond_32

    .line 287
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;->getInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    .line 290
    :cond_32
    invoke-static {}, Lcom/android/server/bluetooth/utils/OplusBtFeatureConfigHelper;->hasBtSsrDump()Z

    move-result v0

    if-eqz v0, :cond_40

    .line 291
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/btfwdump/OplusBluetoothFirmwareDumpCheck;->makeSingleInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/btfwdump/OplusBluetoothFirmwareDumpCheck;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtFwDumpCheck:Lcom/android/server/bluetooth/btfwdump/OplusBluetoothFirmwareDumpCheck;

    .line 294
    :cond_40
    invoke-static {}, Lcom/android/server/bluetooth/utils/OplusBtFeatureConfigHelper;->hasBtRfTestCheck()Z

    move-result v0

    if-eqz v0, :cond_4e

    .line 295
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;->makeSingleInstance(Landroid/content/Context;)Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothRfTestCheck:Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

    .line 297
    :cond_4e
    return-void
.end method

.method private isPackageNameMatched(Ljava/lang/String;)Z
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;

    .line 536
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1
    sget-object v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->disableBlutoothCompletelyApp:[Ljava/lang/String;

    array-length v1, v1

    if-ge v0, v1, :cond_15

    .line 537
    sget-object v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->disableBlutoothCompletelyApp:[Ljava/lang/String;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_12

    .line 538
    const/4 v1, 0x1

    return v1

    .line 536
    :cond_12
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 541
    .end local v0    # "i":I
    :cond_15
    const/4 v0, 0x0

    return v0
.end method

.method private setDebugMode()V
    .registers 3

    .line 421
    const-string/jumbo v0, "ro.build.release_type"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 422
    const-string/jumbo v0, "persist.sys.assert.panic"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_14

    :cond_13
    const/4 v1, 0x1

    :cond_14
    iput-boolean v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    .line 427
    return-void
.end method

.method private waitForBleOn()Z
    .registers 5

    .line 661
    const/4 v0, 0x0

    .line 662
    .local v0, "i":I
    :goto_1
    const/16 v1, 0xa

    if-ge v0, v1, :cond_27

    .line 663
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v1}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v1

    invoke-interface {v1}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->getBluetooth()Landroid/bluetooth/IBluetooth;

    move-result-object v1

    .line 664
    .local v1, "iBluetooth":Landroid/bluetooth/IBluetooth;
    if-nez v1, :cond_12

    .line 665
    goto :goto_27

    .line 667
    :cond_12
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v2}, Lcom/android/server/bluetooth/BluetoothManagerService;->getState()I

    move-result v2

    const/16 v3, 0xf

    if-ne v2, v3, :cond_1e

    .line 668
    const/4 v2, 0x1

    return v2

    .line 671
    :cond_1e
    const-wide/16 v2, 0x12c

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    .line 672
    nop

    .end local v1    # "iBluetooth":Landroid/bluetooth/IBluetooth;
    add-int/lit8 v0, v0, 0x1

    .line 673
    goto :goto_1

    .line 674
    :cond_27
    :goto_27
    const-string v1, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v2, "waitForBleOn time out"

    invoke-static {v1, v2}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 675
    const/4 v1, 0x0

    return v1
.end method


# virtual methods
.method public attemptUploadNextCrashEvt(I)V
    .registers 10
    .param p1, "errorRecoveryRetryCounter"    # I

    .line 629
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIgnoreNextCrash:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    .line 630
    iput-boolean v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIgnoreNextCrash:Z

    .line 631
    return-void

    .line 633
    :cond_8
    nop

    .line 634
    const/4 v0, 0x7

    if-ge p1, v0, :cond_d

    goto :goto_e

    :cond_d
    const/4 v1, 0x1

    :goto_e
    move v5, v1

    .line 633
    const/4 v3, 0x3

    const/16 v4, 0x11

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, p0

    invoke-virtual/range {v2 .. v7}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->oplusDcsEventReport(IIILjava/lang/Object;Landroid/os/Bundle;)V

    .line 635
    return-void
.end method

.method public dealEnableFailbyDeadBinder()V
    .registers 3

    .line 638
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string v1, "binder dead after receive, ignore next crash evt"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 639
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIgnoreNextCrash:Z

    .line 640
    return-void
.end method

.method public isOplusCustomizeBluetoothEnabled()Z
    .registers 4

    .line 728
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string/jumbo v1, "oplus.software.connectivity.enable_bluetooth"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lcom/oplus/content/AppfeatureHelper;->getBoolean(Landroid/content/ContentResolver;Ljava/lang/String;Z)Z

    move-result v0

    .line 729
    .local v0, "isBluetoothEnabled":Z
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "isOplusCusomizeBluetoothEnabled: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "OplusBluetoothManagerServiceExtImpl"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 730
    return v0
.end method

.method public oplusCheckDisablePermitted(Ljava/lang/String;)Z
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;

    .line 452
    const-string v0, "com.google.android.gms"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 453
    const-string/jumbo v0, "sys.oplus.eng.aging"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 454
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v2, "gms package disable bluetooth is not permitted in aging mode"

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 455
    return v1

    .line 457
    :cond_1b
    const/4 v0, 0x1

    return v0
.end method

.method public oplusCheckEnablePermitted(Ljava/lang/String;)Z
    .registers 5
    .param p1, "packageName"    # Ljava/lang/String;

    .line 441
    const-string v0, "com.google.android.gms"

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 442
    const-string/jumbo v0, "sys.oplus.eng.aging"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 443
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v2, "gms package enable bluetooth is not permitted in aging mode"

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 444
    return v1

    .line 446
    :cond_1b
    const/4 v0, 0x1

    return v0
.end method

.method public oplusClearBleApp(Ljava/lang/String;)V
    .registers 4
    .param p1, "packageName"    # Ljava/lang/String;

    .line 528
    invoke-direct {p0, p1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->isPackageNameMatched(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_17

    .line 529
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    monitor-enter v0

    .line 530
    :try_start_9
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v1}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v1

    invoke-interface {v1}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->clearBleApps()V

    .line 531
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_9 .. :try_end_16} :catchall_14

    throw v1

    .line 533
    :cond_17
    :goto_17
    return-void
.end method

.method public oplusDcsEventReport(IIILjava/lang/Object;Landroid/os/Bundle;)V
    .registers 10
    .param p1, "eventCode"    # I
    .param p2, "p1"    # I
    .param p3, "p2"    # I
    .param p4, "obj"    # Ljava/lang/Object;
    .param p5, "data"    # Landroid/os/Bundle;

    .line 462
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    const-string v1, "OplusBluetoothManagerServiceExtImpl"

    if-eqz v0, :cond_21

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "oplusDcsEventReport(), eventCode: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-direct {p0, p1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->dcsEventToString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 463
    :cond_21
    packed-switch p1, :pswitch_data_ec

    goto/16 :goto_ea

    .line 517
    :pswitch_26
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    if-eqz v0, :cond_ea

    .line 518
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    invoke-virtual {v0, p2}, Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;->setBleAppCount(I)V

    goto/16 :goto_ea

    .line 510
    :pswitch_31
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v0, :cond_4c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "report dcs error code = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 511
    :cond_4c
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    if-eqz v0, :cond_ea

    .line 512
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    invoke-virtual {v0, p2, p3}, Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;->recordErrorEvent(II)V

    goto/16 :goto_ea

    .line 465
    :pswitch_57
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v0, :cond_7c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "preState = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", newState = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 475
    :cond_7c
    const/16 v0, 0xe

    if-eq p3, v0, :cond_84

    const/16 v0, 0xa

    if-ne p3, v0, :cond_87

    .line 477
    :cond_84
    invoke-direct {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->setDebugMode()V

    .line 479
    :cond_87
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    if-eqz v0, :cond_90

    .line 480
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    invoke-virtual {v0, p2, p3}, Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;->recordAdapterStateChange(II)V

    .line 482
    :cond_90
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothRfTestCheck:Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

    if-eqz v0, :cond_ea

    .line 483
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothRfTestCheck:Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;

    invoke-virtual {v0, p2, p3}, Lcom/android/server/bluetooth/rftest/OplusBluetoothRfTestCheck;->processBluetoothStateChanged(II)V

    goto :goto_ea

    .line 488
    :pswitch_9a
    move-object v0, p4

    check-cast v0, Ljava/lang/String;

    .line 489
    .local v0, "packageName":Ljava/lang/String;
    iget-boolean v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v2, :cond_cb

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "appCallType = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", reason = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", packageName = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 501
    :cond_cb
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    if-eqz v1, :cond_de

    .line 502
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v2}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v2

    invoke-interface {v2}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->syncEnableDisableFlag()Landroid/os/Bundle;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;->syncEnableDisableFlag(Landroid/os/Bundle;)V

    .line 504
    :cond_de
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    if-eqz v1, :cond_ea

    .line 505
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtAppCallRecorder:Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {v1, v0, p2, p3, v2}, Lcom/android/server/bluetooth/dcs/OplusBtAppCallStats;->recordAppCall(Ljava/lang/String;II[Ljava/lang/Object;)V

    .line 525
    .end local v0    # "packageName":Ljava/lang/String;
    :cond_ea
    :goto_ea
    return-void

    nop

    :pswitch_data_ec
    .packed-switch 0x1
        :pswitch_9a
        :pswitch_57
        :pswitch_31
        :pswitch_26
    .end packed-switch
.end method

.method public oplusFactoryReset()V
    .registers 2

    .line 431
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    if-nez v0, :cond_5

    .line 432
    return-void

    .line 435
    :cond_5
    invoke-virtual {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->waitForBluetoothProcesseExit()Z

    .line 436
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBtOidt:Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/oidt/OplusBluetoothDiagnoseTool;->bluetoothOidtFactoryReset()V

    .line 437
    return-void
.end method

.method public oplusHandleOnBootPhase()V
    .registers 3

    .line 300
    invoke-static {}, Landroid/bluetooth/BluetoothAdapterExtImpl;->getInstance()Landroid/bluetooth/BluetoothAdapterExtImpl;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothAdapterExt:Landroid/bluetooth/BluetoothAdapterExtImpl;

    .line 301
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothAdapterExt:Landroid/bluetooth/BluetoothAdapterExtImpl;

    if-nez v0, :cond_12

    .line 302
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string v1, "bluetooth service not completed"

    invoke-static {v0, v1}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 303
    return-void

    .line 305
    :cond_12
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothAdapterExt:Landroid/bluetooth/BluetoothAdapterExtImpl;

    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusServiceLifecycleCallback:Landroid/bluetooth/BluetoothAdapterExtImpl$OplusServiceLifecycleCallback;

    invoke-virtual {v0, v1}, Landroid/bluetooth/BluetoothAdapterExtImpl;->oplusRegisterServiceLifecycleCallback(Landroid/bluetooth/BluetoothAdapterExtImpl$OplusServiceLifecycleCallback;)Z

    .line 306
    invoke-direct {p0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->init()V

    .line 307
    return-void
.end method

.method public oplusHandleOnbind()V
    .registers 2

    .line 621
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIsBluetoothBinded:Z

    .line 622
    return-void
.end method

.method public oplusHandleUnbind()V
    .registers 2

    .line 625
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIsBluetoothBinded:Z

    .line 626
    return-void
.end method

.method public oplusPropagateForegroundUserId(I)Z
    .registers 5
    .param p1, "foregroundUserId"    # I

    .line 712
    const-string/jumbo v0, "persist.sys.permission.enable"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v1

    .line 713
    .local v0, "isOplusTestMode":Z
    if-eqz v0, :cond_29

    .line 714
    iget-boolean v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v1, :cond_17

    .line 715
    const-string v1, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v2, "oplusPropagateForegroundUserId"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 717
    :cond_17
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    if-eqz v1, :cond_29

    .line 718
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    .line 719
    const/4 v2, 0x3

    invoke-virtual {v1, v2}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 720
    .local v1, "msg":Landroid/os/Message;
    iput p1, v1, Landroid/os/Message;->arg1:I

    .line 721
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    invoke-virtual {v2, v1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->sendMessage(Landroid/os/Message;)Z

    .line 724
    .end local v1    # "msg":Landroid/os/Message;
    :cond_29
    return v0
.end method

.method public oplusRemoveSaveRemoteNameAndAddressMsg()V
    .registers 3

    .line 657
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->removeMessages(I)V

    .line 658
    return-void
.end method

.method public oplusSaveRemoteNameAndAddress()Z
    .registers 6

    .line 643
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBms:Lcom/android/server/bluetooth/BluetoothManagerService;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/BluetoothManagerService;->getWrapper()Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/bluetooth/IBluetoothManagerServiceWrapper;->getBluetooth()Landroid/bluetooth/IBluetooth;

    move-result-object v0

    .line 644
    .local v0, "iBluetooth":Landroid/bluetooth/IBluetooth;
    iget-object v1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    .line 645
    .local v1, "saveMsg":Landroid/os/Message;
    const/4 v2, 0x0

    iput v2, v1, Landroid/os/Message;->arg1:I

    .line 646
    if-eqz v0, :cond_1c

    .line 647
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    invoke-virtual {v2, v1}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_23

    .line 651
    :cond_1c
    iget-object v2, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusHandler:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;

    const-wide/16 v3, 0x1f4

    invoke-virtual {v2, v1, v3, v4}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$OplusBluetoothHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 653
    :goto_23
    const/4 v2, 0x1

    return v2
.end method

.method public registerBtMonitStateCallback(Ljava/lang/String;Ljava/util/List;Landroid/bluetooth/IOplusBluetoothManagerCallback;)Z
    .registers 6
    .param p1, "callAppName"    # Ljava/lang/String;
    .param p3, "callback"    # Landroid/bluetooth/IOplusBluetoothManagerCallback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Landroid/bluetooth/IOplusBluetoothManagerCallback;",
            ")Z"
        }
    .end annotation

    .line 697
    .local p2, "MonitorEvents":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v0, :cond_c

    .line 698
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v1, "enter registerBtMonitStateCallback"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 700
    :cond_c
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;->registerBtMonitStateCallback(Ljava/lang/String;Ljava/util/List;Landroid/bluetooth/IOplusBluetoothManagerCallback;)Z

    move-result v0

    return v0
.end method

.method public setContext(Landroid/content/Context;)V
    .registers 3
    .param p1, "context"    # Landroid/content/Context;

    .line 227
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    if-nez v0, :cond_6

    .line 228
    iput-object p1, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    .line 230
    :cond_6
    return-void
.end method

.method public unregisterBtMonitStateCallback(Ljava/lang/String;Ljava/util/List;Landroid/bluetooth/IOplusBluetoothManagerCallback;)Z
    .registers 6
    .param p1, "callAppName"    # Ljava/lang/String;
    .param p3, "callback"    # Landroid/bluetooth/IOplusBluetoothManagerCallback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Landroid/bluetooth/IOplusBluetoothManagerCallback;",
            ")Z"
        }
    .end annotation

    .line 704
    .local p2, "MonitorEvents":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    iget-boolean v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    if-eqz v0, :cond_c

    .line 705
    const-string v0, "OplusBluetoothManagerServiceExtImpl"

    const-string/jumbo v1, "enter unregisterBtMonitStateCallback"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 707
    :cond_c
    iget-object v0, p0, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mOplusBluetoothMonitorManager:Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;

    invoke-virtual {v0, p1, p2, p3}, Lcom/android/server/bluetooth/abnormaldetect/OplusBluetoothMonitorManager;->unregisterBtMonitStateCallback(Ljava/lang/String;Ljava/util/List;Landroid/bluetooth/IOplusBluetoothManagerCallback;)Z

    move-result v0

    return v0
.end method

.method public waitForBluetoothProcesseExit()Z
    .registers 26

    .line 545
    move-object/from16 v1, p0

    const-string v2, "com.android.bluetooth"

    const-string v3, "android.os.Process"

    iget-boolean v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->DBG:Z

    const-string v4, "OplusBluetoothManagerServiceExtImpl"

    if-eqz v0, :cond_12

    .line 546
    const-string/jumbo v0, "enter waitForBluetoothProcesseExit"

    invoke-static {v4, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 548
    :cond_12
    const/16 v5, 0x8

    .line 549
    .local v5, "maxRetryCount":I
    const/4 v6, -0x1

    .line 550
    .local v6, "bluetoothUid":I
    const/4 v7, 0x0

    .line 551
    .local v7, "existPid":Z
    const/4 v8, 0x0

    .line 552
    .local v8, "waitForCurrentProcess":Z
    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    .line 553
    const-string v9, "activity"

    invoke-virtual {v0, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Landroid/app/ActivityManager;

    .line 554
    .local v9, "activityManager":Landroid/app/ActivityManager;
    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mContext:Landroid/content/Context;

    const-string/jumbo v10, "user"

    invoke-virtual {v0, v10}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Landroid/os/UserManager;

    .line 556
    .local v10, "userManager":Landroid/os/UserManager;
    const/4 v11, 0x0

    .line 558
    .local v11, "pids":[I
    const/4 v12, 0x0

    const/4 v14, 0x1

    :try_start_31
    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string/jumbo v15, "getPidsForCommands"
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_38} :catch_56

    const/16 v16, 0x0

    :try_start_3a
    new-array v13, v14, [Ljava/lang/Class;

    const-class v17, [Ljava/lang/String;

    aput-object v17, v13, v16

    .line 559
    invoke-virtual {v0, v15, v13}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v13

    filled-new-array {v13}, [Ljava/lang/Object;

    move-result-object v13

    .line 560
    invoke-virtual {v0, v12, v13}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I
    :try_end_52
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_52} :catch_54

    move-object v11, v0

    .line 564
    goto :goto_76

    .line 561
    :catch_54
    move-exception v0

    goto :goto_59

    :catch_56
    move-exception v0

    const/16 v16, 0x0

    .line 562
    .local v0, "e":Ljava/lang/Exception;
    :goto_59
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 563
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "Error to call getPidsForCommands"

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v4, v13}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 565
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_76
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v13, v0

    .line 567
    .local v13, "pids_list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_7d
    array-length v15, v11

    if-ge v0, v15, :cond_8f

    .line 568
    const/4 v7, 0x1

    .line 569
    new-instance v15, Ljava/lang/Integer;

    aget v12, v11, v0

    invoke-direct {v15, v12}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v13, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 567
    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x0

    goto :goto_7d

    .line 572
    .end local v0    # "i":I
    :cond_8f
    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    invoke-virtual {v0, v13}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;->setTargetBluetoothProcess(Ljava/util/ArrayList;)V

    .line 574
    :goto_94
    const-wide/16 v18, 0x64

    if-ltz v5, :cond_e4

    if-eqz v7, :cond_e4

    if-eqz v11, :cond_e4

    array-length v0, v11

    if-lez v0, :cond_e4

    .line 575
    array-length v0, v11

    move/from16 v12, v16

    :goto_a2
    if-ge v12, v0, :cond_d1

    aget v15, v11, v12

    .line 576
    .local v15, "pid":I
    move/from16 v20, v14

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v21, v0

    const-string v0, "Waiting BT process to exit, pid = "

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v14, ", try count = "

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 575
    .end local v15    # "pid":I
    add-int/lit8 v12, v12, 0x1

    move/from16 v14, v20

    move/from16 v0, v21

    goto :goto_a2

    .line 578
    :cond_d1
    move/from16 v20, v14

    invoke-static/range {v18 .. v19}, Landroid/os/SystemClock;->sleep(J)V

    .line 579
    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;->isTargetBluetoothProcessDied()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    move v7, v0

    .line 580
    add-int/lit8 v5, v5, -0x1

    move/from16 v14, v20

    goto :goto_94

    .line 574
    :cond_e4
    move/from16 v20, v14

    .line 584
    if-eqz v9, :cond_1ed

    .line 585
    :try_start_e8
    array-length v0, v11

    move/from16 v12, v16

    :goto_eb
    if-ge v12, v0, :cond_1cb

    aget v14, v11, v12

    .line 586
    .local v14, "pid":I
    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v15

    move/from16 v21, v0

    const-string/jumbo v0, "getUidForPid"
    :try_end_f8
    .catchall {:try_start_e8 .. :try_end_f8} :catchall_1ce

    move-object/from16 v22, v3

    move/from16 v23, v5

    move/from16 v3, v20

    .end local v5    # "maxRetryCount":I
    .local v23, "maxRetryCount":I
    :try_start_fe
    new-array v5, v3, [Ljava/lang/Class;

    sget-object v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v3, v5, v16

    .line 587
    invoke-virtual {v15, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 588
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v0, v5, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    .line 586
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    move v6, v0

    .line 590
    iget-boolean v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIsBluetoothBinded:Z

    if-nez v0, :cond_1af

    const/4 v0, -0x1

    if-eq v6, v0, :cond_1af

    if-eqz v7, :cond_1af

    .line 591
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "BT process still exist pid = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", user id = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const v3, 0x186a0

    div-int v15, v6, v3

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v15, ", try force stop"

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 592
    if-eqz v10, :cond_186

    div-int v0, v6, v3

    invoke-virtual {v10, v0}, Landroid/os/UserManager;->isUserRunning(I)Z

    move-result v0

    if-eqz v0, :cond_186

    .line 593
    nop

    .line 594
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string/jumbo v15, "forceStopPackageAsUser"

    move/from16 v17, v3

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Class;

    const-class v24, Ljava/lang/String;

    aput-object v24, v3, v16

    sget-object v24, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x1

    aput-object v24, v3, v5

    invoke-virtual {v0, v15, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 596
    .local v0, "forceStopPackageAsUser":Ljava/lang/reflect/Method;
    invoke-virtual {v0, v5}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 597
    div-int v3, v6, v17

    .line 600
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v2, v3}, [Ljava/lang/Object;

    move-result-object v3

    .line 597
    invoke-virtual {v0, v9, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 601
    nop

    .end local v0    # "forceStopPackageAsUser":Ljava/lang/reflect/Method;
    goto :goto_18a

    .line 592
    :cond_186
    const/4 v5, 0x1

    .line 602
    invoke-static {v14}, Landroid/os/Process;->killProcess(I)V

    .line 604
    :goto_18a
    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBtSwitchRecorder:Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/dcs/OplusBtSwitchEventStats;->recordKillEvent()V

    .line 605
    invoke-static/range {v18 .. v19}, Landroid/os/SystemClock;->sleep(J)V

    .line 606
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "BT process exited = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    invoke-virtual {v3}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;->isTargetBluetoothProcessDied()Z

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1b0

    .line 590
    :cond_1af
    const/4 v5, 0x1

    .line 609
    :goto_1b0
    iget-boolean v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mIsBluetoothBinded:Z

    if-eqz v0, :cond_1bd

    iget-object v0, v1, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl;->mBluetoothProcessObserver:Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;

    invoke-virtual {v0}, Lcom/android/server/bluetooth/OplusBluetoothManagerServiceExtImpl$BluetoothProcessObserver;->isTargetBluetoothProcessDied()Z

    move-result v0
    :try_end_1ba
    .catchall {:try_start_fe .. :try_end_1ba} :catchall_1c9

    if-nez v0, :cond_1bd

    .line 610
    const/4 v8, 0x1

    .line 585
    .end local v14    # "pid":I
    :cond_1bd
    add-int/lit8 v12, v12, 0x1

    move/from16 v20, v5

    move/from16 v0, v21

    move-object/from16 v3, v22

    move/from16 v5, v23

    goto/16 :goto_eb

    .line 614
    :catchall_1c9
    move-exception v0

    goto :goto_1d1

    .line 585
    .end local v23    # "maxRetryCount":I
    .restart local v5    # "maxRetryCount":I
    :cond_1cb
    move/from16 v23, v5

    .end local v5    # "maxRetryCount":I
    .restart local v23    # "maxRetryCount":I
    goto :goto_1ef

    .line 614
    .end local v23    # "maxRetryCount":I
    .restart local v5    # "maxRetryCount":I
    :catchall_1ce
    move-exception v0

    move/from16 v23, v5

    .line 615
    .end local v5    # "maxRetryCount":I
    .local v0, "e":Ljava/lang/Throwable;
    .restart local v23    # "maxRetryCount":I
    :goto_1d1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "force stop error:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1f0

    .line 584
    .end local v0    # "e":Ljava/lang/Throwable;
    .end local v23    # "maxRetryCount":I
    .restart local v5    # "maxRetryCount":I
    :cond_1ed
    move/from16 v23, v5

    .line 616
    .end local v5    # "maxRetryCount":I
    .restart local v23    # "maxRetryCount":I
    :goto_1ef
    nop

    .line 617
    :goto_1f0
    return v8
.end method
