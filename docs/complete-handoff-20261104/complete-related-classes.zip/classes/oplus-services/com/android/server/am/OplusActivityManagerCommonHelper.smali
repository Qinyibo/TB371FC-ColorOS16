.class public Lcom/android/server/am/OplusActivityManagerCommonHelper;
.super Ljava/lang/Object;
.source "OplusActivityManagerCommonHelper.java"


# static fields
.field protected static DEBUG:Z


# instance fields
.field protected final mAms:Lcom/android/server/am/ActivityManagerService;

.field protected final mColorAmsEx:Lcom/android/server/am/IOplusActivityManagerServiceEx;

.field protected final mContext:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 29
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerCommonHelper;->DEBUG:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/android/server/am/IOplusActivityManagerServiceEx;)V
    .registers 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "amsEx"    # Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object p1, p0, Lcom/android/server/am/OplusActivityManagerCommonHelper;->mContext:Landroid/content/Context;

    .line 33
    iput-object p2, p0, Lcom/android/server/am/OplusActivityManagerCommonHelper;->mColorAmsEx:Lcom/android/server/am/IOplusActivityManagerServiceEx;

    .line 34
    if-eqz p2, :cond_10

    .line 35
    invoke-interface {p2}, Lcom/android/server/am/IOplusActivityManagerServiceEx;->getActivityManagerService()Lcom/android/server/am/ActivityManagerService;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerCommonHelper;->mAms:Lcom/android/server/am/ActivityManagerService;

    goto :goto_13

    .line 37
    :cond_10
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/am/OplusActivityManagerCommonHelper;->mAms:Lcom/android/server/am/ActivityManagerService;

    .line 39
    :goto_13
    return-void
.end method


# virtual methods
.method checkCodeValid(III)Z
    .registers 5
    .param p1, "code"    # I
    .param p2, "type"    # I
    .param p3, "group"    # I

    .line 42
    invoke-static {p1, p2, p3}, Loplus/util/OplusCommonConstants;->checkCodeValid(III)Z

    move-result v0

    return v0
.end method
