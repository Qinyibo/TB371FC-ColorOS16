.class public Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;
.super Ljava/lang/Object;
.source "RfcommConnectedSession.java"


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private volatile exit:Z

.field private final mAppUID:Ljava/lang/Integer;

.field private mInStream:Ljava/io/InputStream;

.field private mOutStream:Ljava/io/OutputStream;

.field private mReadSide:Landroid/os/ParcelFileDescriptor;

.field private final mRfCommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

.field private final mSocket:Landroid/bluetooth/BluetoothSocket;

.field private mWriteSide:Landroid/os/ParcelFileDescriptor;


# direct methods
.method public static synthetic $r8$lambda$-Z3cyz3yVnNIuBlaRqKRvs_llcw(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;Landroid/os/ParcelFileDescriptor;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->lambda$pipeInputStream$1(Landroid/os/ParcelFileDescriptor;)V

    return-void
.end method

.method public static synthetic $r8$lambda$xVFc_fuLuiPg1mYr-YoBKK2bVOo(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;Landroid/os/ParcelFileDescriptor;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->lambda$pipeOutputStream$0(Landroid/os/ParcelFileDescriptor;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    .line 34
    const-class v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/bluetooth/BluetoothSocket;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;Ljava/lang/Integer;)V
    .registers 7
    .param p1, "socket"    # Landroid/bluetooth/BluetoothSocket;
    .param p2, "manager"    # Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;
    .param p3, "appUID"    # Ljava/lang/Integer;

    .line 48
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mWriteSide:Landroid/os/ParcelFileDescriptor;

    .line 44
    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mReadSide:Landroid/os/ParcelFileDescriptor;

    .line 45
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit:Z

    .line 49
    iput-object p1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mSocket:Landroid/bluetooth/BluetoothSocket;

    .line 50
    iput-object p2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mRfCommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    .line 51
    iput-object p3, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mAppUID:Ljava/lang/Integer;

    .line 53
    :try_start_11
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mInStream:Ljava/io/InputStream;

    .line 54
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothSocket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mOutStream:Ljava/io/OutputStream;
    :try_end_1d
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_1d} :catch_1e

    .line 57
    goto :goto_26

    .line 55
    :catch_1e
    move-exception v0

    .line 56
    .local v0, "e":Ljava/io/IOException;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransport: Failed to get input/output stream"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 58
    .end local v0    # "e":Ljava/io/IOException;
    :goto_26
    return-void
.end method

.method private synthetic lambda$pipeInputStream$1(Landroid/os/ParcelFileDescriptor;)V
    .registers 4
    .param p1, "writeSide"    # Landroid/os/ParcelFileDescriptor;

    .line 86
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mInStream:Ljava/io/InputStream;

    new-instance v1, Landroid/os/ParcelFileDescriptor$AutoCloseOutputStream;

    invoke-direct {v1, p1}, Landroid/os/ParcelFileDescriptor$AutoCloseOutputStream;-><init>(Landroid/os/ParcelFileDescriptor;)V

    invoke-direct {p0, v0, v1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->performTransfer(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    return-void
.end method

.method private synthetic lambda$pipeOutputStream$0(Landroid/os/ParcelFileDescriptor;)V
    .registers 4
    .param p1, "readSide"    # Landroid/os/ParcelFileDescriptor;

    .line 68
    new-instance v0, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    invoke-direct {v0, p1}, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;-><init>(Landroid/os/ParcelFileDescriptor;)V

    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mOutStream:Ljava/io/OutputStream;

    invoke-direct {p0, v0, v1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->performTransfer(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    return-void
.end method

.method private performTransfer(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 10
    .param p1, "inputStream"    # Ljava/io/InputStream;
    .param p2, "outputStream"    # Ljava/io/OutputStream;

    .line 97
    const-string v0, "BluetoothTransport: Connection disconnect"

    const-string v1, "BluetoothTransport: Failed to close output stream"

    const-string v2, "BluetoothTransport: Failed to close input stream"

    const/16 v3, 0x400

    new-array v3, v3, [B

    .line 101
    .local v3, "buffer":[B
    :goto_a
    :try_start_a
    iget-boolean v4, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit:Z

    if-nez v4, :cond_1d

    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    move v5, v4

    .local v5, "bytes":I
    if-lez v4, :cond_1d

    .line 102
    const/4 v4, 0x0

    invoke-virtual {p2, v3, v4, v5}, Ljava/io/OutputStream;->write([BII)V

    .line 103
    invoke-static {v3, v4}, Ljava/util/Arrays;->fill([BB)V

    goto :goto_a

    .line 105
    .end local v5    # "bytes":I
    :cond_1d
    invoke-virtual {p2}, Ljava/io/OutputStream;->flush()V
    :try_end_20
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_20} :catch_45
    .catchall {:try_start_a .. :try_end_20} :catchall_43

    .line 110
    :try_start_20
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_20 .. :try_end_23} :catch_24

    .line 113
    goto :goto_2a

    .line 111
    :catch_24
    move-exception v4

    .line 112
    .local v4, "e":Ljava/io/IOException;
    sget-object v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v5, v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 115
    .end local v4    # "e":Ljava/io/IOException;
    :goto_2a
    :try_start_2a
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_2d
    .catch Ljava/io/IOException; {:try_start_2a .. :try_end_2d} :catch_2e

    .line 118
    :goto_2d
    goto :goto_34

    .line 116
    :catch_2e
    move-exception v2

    .line 117
    .local v2, "e":Ljava/io/IOException;
    :goto_2f
    sget-object v4, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v4, v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 121
    .end local v2    # "e":Ljava/io/IOException;
    :goto_34
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 122
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mRfCommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mSocket:Landroid/bluetooth/BluetoothSocket;

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mAppUID:Ljava/lang/Integer;

    invoke-virtual {v0, v1, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->manageSocketConnectionLost(Landroid/bluetooth/BluetoothSocket;Ljava/lang/Integer;)V

    .line 124
    goto :goto_5d

    .line 109
    :catchall_43
    move-exception v4

    goto :goto_5e

    .line 106
    :catch_45
    move-exception v4

    .line 107
    .restart local v4    # "e":Ljava/io/IOException;
    :try_start_46
    sget-object v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    const-string v6, "BluetoothTransport: input/output stream close"

    invoke-static {v5, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4d
    .catchall {:try_start_46 .. :try_end_4d} :catchall_43

    .line 110
    .end local v4    # "e":Ljava/io/IOException;
    :try_start_4d
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_50
    .catch Ljava/io/IOException; {:try_start_4d .. :try_end_50} :catch_51

    .line 113
    goto :goto_57

    .line 111
    :catch_51
    move-exception v4

    .line 112
    .restart local v4    # "e":Ljava/io/IOException;
    sget-object v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v5, v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 115
    .end local v4    # "e":Ljava/io/IOException;
    :goto_57
    :try_start_57
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_5a
    .catch Ljava/io/IOException; {:try_start_57 .. :try_end_5a} :catch_5b

    goto :goto_2d

    .line 116
    :catch_5b
    move-exception v2

    goto :goto_2f

    .line 125
    :goto_5d
    return-void

    .line 110
    :goto_5e
    :try_start_5e
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_61
    .catch Ljava/io/IOException; {:try_start_5e .. :try_end_61} :catch_62

    .line 113
    goto :goto_68

    .line 111
    :catch_62
    move-exception v5

    .line 112
    .local v5, "e":Ljava/io/IOException;
    sget-object v6, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v6, v2, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 115
    .end local v5    # "e":Ljava/io/IOException;
    :goto_68
    :try_start_68
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_6b
    .catch Ljava/io/IOException; {:try_start_68 .. :try_end_6b} :catch_6c

    .line 118
    goto :goto_72

    .line 116
    :catch_6c
    move-exception v2

    .line 117
    .restart local v2    # "e":Ljava/io/IOException;
    sget-object v5, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v5, v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 121
    .end local v2    # "e":Ljava/io/IOException;
    :goto_72
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 122
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mRfCommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mSocket:Landroid/bluetooth/BluetoothSocket;

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mAppUID:Ljava/lang/Integer;

    invoke-virtual {v0, v1, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->manageSocketConnectionLost(Landroid/bluetooth/BluetoothSocket;Ljava/lang/Integer;)V

    .line 124
    throw v4
.end method


# virtual methods
.method public exit()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 128
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    const-string v1, "BluetoothTransfer: actively close session"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->exit:Z

    .line 130
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mSocket:Landroid/bluetooth/BluetoothSocket;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothSocket;->close()V

    .line 131
    return-void
.end method

.method public getAppUID()Ljava/lang/Integer;
    .registers 2

    .line 134
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mAppUID:Ljava/lang/Integer;

    return-object v0
.end method

.method public isValidSession()Z
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mInStream:Ljava/io/InputStream;

    if-eqz v0, :cond_a

    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mOutStream:Ljava/io/OutputStream;

    if-eqz v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method

.method public pipeInputStream(Ljava/util/concurrent/ThreadPoolExecutor;)Landroid/os/ParcelFileDescriptor;
    .registers 5
    .param p1, "threadPoolExecutor"    # Ljava/util/concurrent/ThreadPoolExecutor;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 80
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mReadSide:Landroid/os/ParcelFileDescriptor;

    if-nez v0, :cond_1b

    .line 81
    invoke-static {}, Landroid/os/ParcelFileDescriptor;->createPipe()[Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    .line 82
    .local v0, "pipe":[Landroid/os/ParcelFileDescriptor;
    const/4 v1, 0x0

    aget-object v1, v0, v1

    iput-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mReadSide:Landroid/os/ParcelFileDescriptor;

    .line 83
    const/4 v1, 0x1

    aget-object v1, v0, v1

    .line 85
    .local v1, "writeSide":Landroid/os/ParcelFileDescriptor;
    new-instance v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession$$ExternalSyntheticLambda1;-><init>(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;Landroid/os/ParcelFileDescriptor;)V

    invoke-virtual {p1, v2}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 89
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mReadSide:Landroid/os/ParcelFileDescriptor;

    return-object v2

    .line 91
    .end local v0    # "pipe":[Landroid/os/ParcelFileDescriptor;
    .end local v1    # "writeSide":Landroid/os/ParcelFileDescriptor;
    :cond_1b
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    const-string v1, "BluetoothTransport: pipeInputStream duplicated"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 93
    const/4 v0, 0x0

    return-object v0
.end method

.method public pipeOutputStream(Ljava/util/concurrent/ThreadPoolExecutor;)Landroid/os/ParcelFileDescriptor;
    .registers 5
    .param p1, "threadPoolExecutor"    # Ljava/util/concurrent/ThreadPoolExecutor;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 62
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mWriteSide:Landroid/os/ParcelFileDescriptor;

    if-nez v0, :cond_1b

    .line 63
    invoke-static {}, Landroid/os/ParcelFileDescriptor;->createPipe()[Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    .line 64
    .local v0, "pipe":[Landroid/os/ParcelFileDescriptor;
    const/4 v1, 0x0

    aget-object v1, v0, v1

    .line 65
    .local v1, "readSide":Landroid/os/ParcelFileDescriptor;
    const/4 v2, 0x1

    aget-object v2, v0, v2

    iput-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mWriteSide:Landroid/os/ParcelFileDescriptor;

    .line 67
    new-instance v2, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0, v1}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession$$ExternalSyntheticLambda0;-><init>(Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;Landroid/os/ParcelFileDescriptor;)V

    invoke-virtual {p1, v2}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 71
    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->mWriteSide:Landroid/os/ParcelFileDescriptor;

    return-object v2

    .line 73
    .end local v0    # "pipe":[Landroid/os/ParcelFileDescriptor;
    .end local v1    # "readSide":Landroid/os/ParcelFileDescriptor;
    :cond_1b
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommConnectedSession;->TAG:Ljava/lang/String;

    const-string v1, "BluetoothTransport: pipeOutputStream duplicated"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 75
    const/4 v0, 0x0

    return-object v0
.end method
