.class Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;
.super Landroid/os/Handler;
.source "HansSceneManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/scene/HansSceneManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "HansMainHandler"
.end annotation


# instance fields
.field private mThreadId:I

.field final synthetic this$0:Lcom/android/server/hans/scene/HansSceneManager;


# direct methods
.method static bridge synthetic -$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/Object;J)V
    .registers 6

    invoke-direct/range {p0 .. p5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(IILjava/lang/Object;J)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;IILjava/lang/String;ILjava/lang/String;)V
    .registers 6

    invoke-direct/range {p0 .. p5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(IILjava/lang/String;ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msendMessage(Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;ILjava/lang/Object;J)V
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(ILjava/lang/Object;J)V

    return-void
.end method

.method public constructor <init>(Lcom/android/server/hans/scene/HansSceneManager;Landroid/os/Looper;I)V
    .registers 4
    .param p1, "this$0"    # Lcom/android/server/hans/scene/HansSceneManager;
    .param p2, "looper"    # Landroid/os/Looper;
    .param p3, "threadId"    # I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 3269
    iput-object p1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    .line 3270
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 3271
    iput p3, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->mThreadId:I

    .line 3272
    return-void
.end method

.method private sendMessage(IILjava/lang/Object;J)V
    .registers 7
    .param p1, "what"    # I
    .param p2, "args1"    # I
    .param p3, "object"    # Ljava/lang/Object;
    .param p4, "delay"    # J

    .line 3298
    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    .line 3299
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->what:I

    .line 3300
    iput p2, v0, Landroid/os/Message;->arg1:I

    .line 3301
    iput-object p3, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 3302
    invoke-virtual {p0, v0, p4, p5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 3303
    return-void
.end method

.method private sendMessage(IILjava/lang/String;ILjava/lang/String;)V
    .registers 9
    .param p1, "what"    # I
    .param p2, "resumedUid"    # I
    .param p3, "resumedPkg"    # Ljava/lang/String;
    .param p4, "lastResumedUid"    # I
    .param p5, "lastResumedPkg"    # Ljava/lang/String;

    .line 3279
    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    .line 3280
    .local v0, "message":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->what:I

    .line 3281
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 3282
    .local v1, "data":Landroid/os/Bundle;
    const-string/jumbo v2, "resumedUid"

    invoke-virtual {v1, v2, p2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 3283
    const-string/jumbo v2, "resumedPkg"

    invoke-virtual {v1, v2, p3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3284
    const-string/jumbo v2, "lastResumedUid"

    invoke-virtual {v1, v2, p4}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 3285
    const-string/jumbo v2, "lastResumedPkg"

    invoke-virtual {v1, v2, p5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3286
    invoke-virtual {v0, v1}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 3287
    invoke-virtual {p0, v0}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(Landroid/os/Message;)Z

    .line 3288
    return-void
.end method

.method private sendMessage(ILjava/lang/Object;J)V
    .registers 6
    .param p1, "what"    # I
    .param p2, "object"    # Ljava/lang/Object;
    .param p3, "delay"    # J

    .line 3291
    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    .line 3292
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->what:I

    .line 3293
    iput-object p2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 3294
    invoke-virtual {p0, v0, p3, p4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 3295
    return-void
.end method

.method private triggerFreezeFromAlarm(Landroid/os/Message;)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;

    .line 3677
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isScreenOn()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 3678
    return-void

    .line 3680
    :cond_b
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3681
    .local v0, "uid":I
    const/16 v1, 0x2710

    if-lt v0, v1, :cond_39

    .line 3682
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3683
    .local v1, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-nez v1, :cond_1a

    .line 3684
    return-void

    .line 3686
    :cond_1a
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 3687
    :try_start_1f
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v3

    if-eqz v3, :cond_34

    .line 3688
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v3

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v4

    invoke-virtual {v3, v4}, Lcom/android/server/hans/states/HansAppStateMachine;->notifyLcdOffAlarm(I)V

    .line 3690
    :cond_34
    monitor-exit v2

    .line 3691
    return-void

    .line 3690
    :catchall_36
    move-exception v3

    monitor-exit v2
    :try_end_38
    .catchall {:try_start_1f .. :try_end_38} :catchall_36

    throw v3

    .line 3694
    .end local v1    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_39
    const/4 v1, -0x1

    if-ne v0, v1, :cond_55

    .line 3695
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/4 v2, 0x2

    invoke-static {v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3696
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    const-string/jumbo v2, "lcdoff_alarm"

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 3697
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-static {v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fputmLcdOffTriggerTime(Lcom/android/server/hans/scene/HansSceneManager;J)V

    .line 3699
    :cond_55
    return-void
.end method


# virtual methods
.method public getThreadId()I
    .registers 2

    .line 3275
    iget v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->mThreadId:I

    return v0
.end method

.method public handleMessage(Landroid/os/Message;)V
    .registers 14
    .param p1, "msg"    # Landroid/os/Message;

    .line 3307
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->FULL_DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_34

    .line 3308
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HansMainHandler handleMessage what="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    iget v3, p1, Landroid/os/Message;->what:I

    invoke-static {v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mgetMainHandlerMsgStr(Lcom/android/server/hans/scene/HansSceneManager;I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->fullLog(Ljava/lang/String;)V

    .line 3310
    :cond_34
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x4

    const-wide/16 v2, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, -0x1

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_834

    :pswitch_40
    goto/16 :goto_833

    .line 3665
    :pswitch_42
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v0

    if-eqz v0, :cond_833

    .line 3666
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Exit minSystem scene: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v2}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " because has switched to launcher for more than 30 seconds"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3668
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1}, Lcom/android/server/hans/scene/HansSceneManager;->getCurrentMinSystemScene()I

    move-result v1

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mexitMinSystemScene(Lcom/android/server/hans/scene/HansSceneManager;I)V

    goto/16 :goto_833

    .line 3650
    :pswitch_7d
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3651
    .local v0, "uid":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3652
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-nez v1, :cond_88

    .line 3653
    return-void

    .line 3655
    :cond_88
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 3657
    :try_start_8d
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->isFrozen()Z

    move-result v3

    if-nez v3, :cond_95

    .line 3658
    monitor-exit v2

    return-void

    .line 3660
    :cond_95
    monitor-exit v2
    :try_end_96
    .catchall {:try_start_8d .. :try_end_96} :catchall_9f

    .line 3662
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/am/OplusHansManager;->checkExecutingComponent(Lcom/android/server/hans/OplusHansPackage;)Z

    .line 3663
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto/16 :goto_833

    .line 3660
    .restart local v0    # "uid":I
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_9f
    move-exception v3

    :try_start_a0
    monitor-exit v2
    :try_end_a1
    .catchall {:try_start_a0 .. :try_end_a1} :catchall_9f

    throw v3

    .line 3647
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_a2
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->registerAudioFocusObserver()V

    .line 3648
    goto/16 :goto_833

    .line 3640
    :pswitch_ab
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3641
    .restart local v0    # "uid":I
    iget v1, p1, Landroid/os/Message;->arg2:I

    .line 3642
    .local v1, "adj":I
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmAdjTestSwitch(Lcom/android/server/hans/scene/HansSceneManager;)Z

    move-result v2

    if-nez v2, :cond_bc

    .line 3643
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v2, v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->updateMinAdjOfUid(II)V

    .line 3645
    .end local v0    # "uid":I
    .end local v1    # "adj":I
    :cond_bc
    goto/16 :goto_833

    .line 3635
    :pswitch_be
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3636
    .local v0, "enter":Z
    iget v1, p1, Landroid/os/Message;->arg1:I

    .line 3637
    .local v1, "sceneId":I
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v2, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3638
    .end local v0    # "enter":Z
    .end local v1    # "sceneId":I
    goto/16 :goto_833

    .line 3632
    :pswitch_cf
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/16 v1, 0x8

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3633
    goto/16 :goto_833

    .line 3627
    :pswitch_d8
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3628
    .local v0, "count":I
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getAppUsageMgsRepeateCount()I

    move-result v1

    if-lt v0, v1, :cond_e5

    return-void

    .line 3629
    :cond_e5
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mfilterWhitelistUidByAppUsage(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3630
    .end local v0    # "count":I
    goto/16 :goto_833

    .line 3621
    :pswitch_ec
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3622
    .local v0, "uid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    if-ne v0, v1, :cond_fd

    .line 3623
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->notifyAppGoBackground(I)V

    .line 3625
    .end local v0    # "uid":I
    :cond_fd
    goto/16 :goto_833

    .line 3616
    :pswitch_ff
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->updateWakelockProxyConfig()V

    .line 3617
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3618
    .local v0, "enter":Z
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/16 v2, 0x40

    invoke-virtual {v1, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3619
    .end local v0    # "enter":Z
    goto/16 :goto_833

    .line 3606
    :pswitch_117
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3607
    .local v0, "uid":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3608
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_12a

    .line 3609
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    const-string v3, "TcpRetransmission"

    invoke-virtual {v2, v1, v3}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleAllow(Lcom/android/server/hans/OplusHansPackage;Ljava/lang/String;)V

    .line 3611
    :cond_12a
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v2

    monitor-enter v2

    .line 3612
    :try_start_131
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v3}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 3613
    monitor-exit v2

    .line 3614
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    goto/16 :goto_833

    .line 3613
    .restart local v0    # "uid":I
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :catchall_141
    move-exception v3

    monitor-exit v2
    :try_end_143
    .catchall {:try_start_131 .. :try_end_143} :catchall_141

    throw v3

    .line 3602
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_144
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3603
    .restart local v0    # "uid":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const-string v2, "TcpRetransmission"

    const-string v3, ""

    invoke-virtual {v1, v0, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeAndTransState(ILjava/lang/String;Ljava/lang/String;)Lcom/android/server/hans/scene/HansSceneManager$Unfreezing;

    .line 3604
    .end local v0    # "uid":I
    goto/16 :goto_833

    .line 3597
    :pswitch_151
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3598
    .local v0, "enter":Z
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/16 v2, 0x20

    invoke-virtual {v1, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3599
    .end local v0    # "enter":Z
    goto/16 :goto_833

    .line 3560
    :pswitch_162
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v0

    const/16 v1, 0x13

    const-wide/16 v2, 0x5dc

    invoke-virtual {v0, v1, v2, v3}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessageDelayed(IJ)Z

    .line 3561
    goto/16 :goto_833

    .line 3581
    :pswitch_171
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "night deep doze mode deep sleep predict time changed: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    .line 3583
    invoke-static {v4}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mgetDeepSleepPredictTimeRangeString(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 3581
    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3584
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isNightDeepDozeEnable()Z

    move-result v0

    if-eqz v0, :cond_833

    .line 3587
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mrefreshNightDeepDozeTimeMs(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3588
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$msetEnterNightDeepDozeAlarm(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3589
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmNightDeepDozeAlarmExitTimeMs(Lcom/android/server/hans/scene/HansSceneManager;)J

    move-result-wide v0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_833

    .line 3592
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$msetExitNightDeepDozeAlarm(Lcom/android/server/hans/scene/HansSceneManager;)V

    goto/16 :goto_833

    .line 3578
    :pswitch_1b7
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mresetNetstate(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3579
    goto/16 :goto_833

    .line 3574
    :pswitch_1be
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3575
    .restart local v0    # "enter":Z
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/16 v2, 0x10

    invoke-virtual {v1, v2, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3576
    .end local v0    # "enter":Z
    goto/16 :goto_833

    .line 3571
    :pswitch_1cf
    invoke-direct {p0, p1}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->triggerFreezeFromAlarm(Landroid/os/Message;)V

    .line 3572
    goto/16 :goto_833

    .line 3567
    :pswitch_1d4
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3568
    .restart local v0    # "enter":Z
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v2, v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3569
    .end local v0    # "enter":Z
    goto/16 :goto_833

    .line 3563
    :pswitch_1e3
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 3564
    .restart local v0    # "enter":Z
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v4, v0}, Lcom/android/server/hans/scene/HansSceneManager;->handleSceneChanged(IZ)V

    .line 3565
    .end local v0    # "enter":Z
    goto/16 :goto_833

    .line 3557
    :pswitch_1f2
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mexitFastFreezeByHighload(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3558
    goto/16 :goto_833

    .line 3553
    :pswitch_1f9
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Landroid/util/ArrayMap;

    .line 3554
    .local v0, "uidMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mhandleHighload(Lcom/android/server/hans/scene/HansSceneManager;Landroid/util/ArrayMap;)V

    .line 3555
    .end local v0    # "uidMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Landroid/util/SparseArray<Landroid/util/ArraySet<Ljava/lang/Integer;>;>;>;"
    goto/16 :goto_833

    .line 3341
    :pswitch_204
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3342
    .local v0, "requestId":I
    iget v1, p1, Landroid/os/Message;->arg2:I

    .line 3343
    .local v1, "freezeTimeout":I
    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    .line 3344
    .local v2, "reason":Ljava/lang/String;
    iget-object v3, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v5

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/server/am/OplusHansManager;->getCurResumedPkgName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v5, v7, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$menterFastFreezer(Lcom/android/server/hans/scene/HansSceneManager;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3346
    .local v3, "ret":Ljava/lang/String;
    if-eq v0, v6, :cond_231

    .line 3347
    sget-object v5, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    invoke-static {v5}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v5

    check-cast v5, Lcom/android/server/am/IOplusOsenseCommonManager;

    const-string v6, "Freezer"

    invoke-interface {v5, v0, v4, v6, v3}, Lcom/android/server/am/IOplusOsenseCommonManager;->updateOSensePolicyInfo(IILjava/lang/String;Ljava/lang/String;)V

    .line 3350
    .end local v0    # "requestId":I
    .end local v1    # "freezeTimeout":I
    .end local v2    # "reason":Ljava/lang/String;
    .end local v3    # "ret":Ljava/lang/String;
    :cond_231
    goto/16 :goto_833

    .line 3545
    :pswitch_233
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/android/server/hans/OplusHansPackage;

    .line 3546
    .local v0, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_254

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-static {v3}, Landroid/os/UserHandle;->getUserId(I)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lcom/android/server/am/OplusHansManager;->isPreloadPkg(Ljava/lang/String;I)Z

    move-result v1

    if-eqz v1, :cond_254

    .line 3547
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mfreezeForPreload(Lcom/android/server/hans/scene/HansSceneManager;Lcom/android/server/hans/OplusHansPackage;)Lcom/android/server/hans/scene/HansSceneManager$Freezing;

    .line 3549
    .end local v0    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    :cond_254
    goto/16 :goto_833

    .line 3542
    :pswitch_256
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->updateSysBlackOrGrayPackage()V

    .line 3543
    goto/16 :goto_833

    .line 3403
    :pswitch_25d
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "DeepSleepOff: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3404
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "DeepSleepOff: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 3405
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/4 v1, 0x6

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3406
    goto/16 :goto_833

    .line 3537
    :pswitch_29d
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v2, "HansMainHandler MSG_HANS_DISABLED"

    invoke-virtual {v0, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3538
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mcancelFreezeForLcdOff(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3539
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3540
    goto/16 :goto_833

    .line 3473
    :pswitch_2b2
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3474
    .local v0, "uid":I
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/am/OplusHansManager;->removeAudioTopFocusStack(I)V

    .line 3475
    invoke-static {}, Lcom/android/server/hans/OplusTrafficStats;->getInstance()Lcom/android/server/hans/OplusTrafficStats;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/OplusTrafficStats;->handleUidGone(I)V

    .line 3476
    invoke-static {}, Lcom/android/server/hans/device/DeviceMonitor;->getInstance()Lcom/android/server/hans/device/DeviceMonitor;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/device/DeviceMonitor;->uidGone(I)V

    .line 3478
    invoke-static {}, Lcom/android/server/cpulimit/OplusCpuFeature;->getInstance()Lcom/android/server/cpulimit/OplusCpuFeature;

    move-result-object v1

    invoke-static {}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getInstance()Lcom/android/server/oplus/osense/resource/AppStatusManager;

    move-result-object v4

    invoke-virtual {v4, v0}, Lcom/android/server/oplus/osense/resource/AppStatusManager;->getPkgNameByUid(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v5, v0, v4, v7}, Lcom/android/server/cpulimit/OplusCpuFeature;->appSwitchEventToCLU(ZILjava/lang/String;Z)V

    .line 3479
    invoke-static {}, Lcom/android/server/hans/revival/AppRevivalManager;->getInstance()Lcom/android/server/hans/revival/AppRevivalManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/server/hans/revival/AppRevivalManager;->noteUidGone(I)V

    .line 3480
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 3482
    :try_start_2e8
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_305

    .line 3483
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_305
    .catchall {:try_start_2e8 .. :try_end_305} :catchall_490

    .line 3486
    :cond_305
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 3487
    nop

    .line 3488
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidAdjMap(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/HashMap;

    move-result-object v1

    monitor-enter v1

    .line 3489
    :try_start_316
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v4}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidAdjMap(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/HashMap;

    move-result-object v4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_333

    .line 3490
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v4}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidAdjMap(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/HashMap;

    move-result-object v4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3492
    :cond_333
    monitor-exit v1
    :try_end_334
    .catchall {:try_start_316 .. :try_end_334} :catchall_48d

    .line 3493
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v1

    if-nez v1, :cond_33f

    .line 3494
    return-void

    .line 3496
    :cond_33f
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3497
    .local v1, "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_454

    .line 3498
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v4

    const-string v5, "UidGone"

    invoke-virtual {v4, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->exit(Ljava/lang/String;)V

    .line 3499
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    .line 3501
    .local v4, "pkgName":Ljava/lang/String;
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "onUidGone(), "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " exit SM"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3502
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    const-string v6, "UID"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Gone] ["

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->addHistoryInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 3505
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansDBConfig;->isUidGoneRemoveAlarmEnable()Z

    move-result v5

    if-nez v5, :cond_3db

    .line 3506
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "onUidGone(),  keep: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " alarm"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_454

    .line 3508
    :cond_3db
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v5

    invoke-virtual {v5, v4, v0}, Lcom/android/server/am/OplusHansManager;->isAllowBootStart(Ljava/lang/String;I)Z

    move-result v5

    if-nez v5, :cond_429

    .line 3509
    const-class v5, Lcom/android/server/OplusAlarmManagerServiceInternal;

    .line 3510
    invoke-static {v5}, Lcom/android/server/LocalServices;->getService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/OplusAlarmManagerServiceInternal;

    .line 3511
    .local v5, "oplusAlarmManagerServiceInternal":Lcom/android/server/OplusAlarmManagerServiceInternal;
    if-eqz v5, :cond_41e

    .line 3512
    invoke-virtual {v5, v0, v4}, Lcom/android/server/OplusAlarmManagerServiceInternal;->removeKilledAppAlarms(ILjava/lang/String;)V

    .line 3513
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "onUidGone(), "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " alarm removed"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    goto :goto_428

    .line 3516
    :cond_41e
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v6

    const-string/jumbo v7, "onUidGone(), failed to remove alarm, OplusAlarmManagerService is null"

    invoke-virtual {v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->w(Ljava/lang/String;)V

    .line 3519
    .end local v5    # "oplusAlarmManagerServiceInternal":Lcom/android/server/OplusAlarmManagerServiceInternal;
    :goto_428
    goto :goto_454

    .line 3520
    :cond_429
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "onUidGone(), "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " is allowed boot start,  do not remove its alarm"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3526
    .end local v4    # "pkgName":Ljava/lang/String;
    :cond_454
    :goto_454
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v4

    invoke-virtual {v4, v0}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v4

    .line 3527
    .local v4, "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v4, :cond_48b

    .line 3528
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5

    .line 3529
    :try_start_463
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v6

    cmp-long v2, v6, v2

    if-lez v2, :cond_483

    .line 3530
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v9

    sub-long/2addr v7, v9

    invoke-virtual {v2, v3, v6, v7, v8}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyLiveTime(ILjava/lang/String;J)V

    .line 3532
    :cond_483
    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->resetState()V

    .line 3533
    monitor-exit v5

    goto :goto_48b

    :catchall_488
    move-exception v2

    monitor-exit v5
    :try_end_48a
    .catchall {:try_start_463 .. :try_end_48a} :catchall_488

    throw v2

    .line 3535
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v4    # "record":Lcom/android/server/hans/OplusHansPackage;
    :cond_48b
    :goto_48b
    goto/16 :goto_833

    .line 3492
    .restart local v0    # "uid":I
    :catchall_48d
    move-exception v2

    :try_start_48e
    monitor-exit v1
    :try_end_48f
    .catchall {:try_start_48e .. :try_end_48f} :catchall_48d

    throw v2

    .line 3486
    :catchall_490
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 3487
    throw v1

    .line 3438
    .end local v0    # "uid":I
    :pswitch_49b
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3439
    .restart local v0    # "uid":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 3441
    :try_start_4a6
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_4b4
    .catchall {:try_start_4a6 .. :try_end_4b4} :catchall_5c2

    if-eqz v1, :cond_4c0

    .line 3446
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 3442
    return-void

    .line 3444
    :cond_4c0
    :try_start_4c0
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmRunningUidSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_4cd
    .catchall {:try_start_4c0 .. :try_end_4cd} :catchall_5c2

    .line 3446
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 3447
    nop

    .line 3448
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const/16 v2, 0x3e9

    invoke-virtual {v1, v0, v2}, Lcom/android/server/hans/scene/HansSceneManager;->updateMinAdjOfUid(II)V

    .line 3449
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v1

    if-nez v1, :cond_4e9

    .line 3450
    return-void

    .line 3452
    :cond_4e9
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3454
    .restart local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_5a2

    .line 3455
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v3

    if-eq v2, v3, :cond_539

    .line 3456
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onUidActive(), uid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", pkgName="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", can enter SM"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3457
    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/states/HansAppStateMachine;->enter()V

    .line 3459
    :cond_539
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "onUidActive() update stay time, uid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", pkgName="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", U stay="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/server/hans/states/HansAppStateMachine;->updateCurStateEnterTime()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3460
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v2

    const-string v3, "UID"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Start] ["

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->addHistoryInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 3463
    :cond_5a2
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v2

    .line 3464
    .local v2, "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v2, :cond_5c0

    .line 3465
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 3466
    :try_start_5b1
    invoke-virtual {v2, v7}, Lcom/android/server/hans/OplusHansPackage;->setAlive(Z)V

    .line 3467
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    invoke-virtual {v2, v4, v5}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 3468
    monitor-exit v3

    goto :goto_5c0

    :catchall_5bd
    move-exception v4

    monitor-exit v3
    :try_end_5bf
    .catchall {:try_start_5b1 .. :try_end_5bf} :catchall_5bd

    throw v4

    .line 3471
    .end local v0    # "uid":I
    .end local v1    # "hansPkg":Lcom/android/server/hans/OplusHansPackage;
    .end local v2    # "record":Lcom/android/server/hans/OplusHansPackage;
    :cond_5c0
    :goto_5c0
    goto/16 :goto_833

    .line 3446
    .restart local v0    # "uid":I
    :catchall_5c2
    move-exception v1

    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHansMapWriteLock(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 3447
    throw v1

    .line 3430
    .end local v0    # "uid":I
    :pswitch_5cd
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 3431
    .restart local v0    # "uid":I
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v1, v0}, Lcom/android/server/hans/scene/HansSceneManager;->getHansPkgByUid(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v1

    .line 3432
    .local v1, "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v1, :cond_5de

    .line 3433
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/am/OplusHansManager;->setFirewallRuleInner(Lcom/android/server/hans/OplusHansPackage;)V

    .line 3435
    .end local v0    # "uid":I
    .end local v1    # "hansPackage":Lcom/android/server/hans/OplusHansPackage;
    :cond_5de
    goto/16 :goto_833

    .line 3408
    :pswitch_5e0
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/android/server/hans/OplusHansPackage;

    .line 3409
    .local v0, "checkCpn":Lcom/android/server/hans/OplusHansPackage;
    if-nez v0, :cond_5e7

    .line 3410
    return-void

    .line 3412
    :cond_5e7
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v1

    .line 3414
    .local v1, "uid":I
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getSM()Lcom/android/server/hans/states/HansAppStateMachine;

    move-result-object v2

    invoke-virtual {v2, v5}, Lcom/android/server/hans/states/HansAppStateMachine;->setFrozenActionKeepProxy(Z)V

    .line 3416
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/android/server/am/OplusHansManager;->checkExecutingComponent(Lcom/android/server/hans/OplusHansPackage;)Z

    move-result v2

    if-eqz v2, :cond_60c

    .line 3417
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v2

    .line 3418
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v7, v3}, Landroid/os/Handler;->removeEqualMessages(ILjava/lang/Object;)V

    .line 3419
    return-void

    .line 3423
    :cond_60c
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2, v0}, Lcom/android/server/am/OplusHansManager;->tryProxyWakeLock(Lcom/android/server/hans/OplusHansPackage;)Z

    move-result v2

    if-nez v2, :cond_626

    .line 3424
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v2

    .line 3425
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v7, v3}, Landroid/os/Handler;->removeEqualMessages(ILjava/lang/Object;)V

    .line 3426
    return-void

    .line 3428
    .end local v0    # "checkCpn":Lcom/android/server/hans/OplusHansPackage;
    .end local v1    # "uid":I
    :cond_626
    goto/16 :goto_833

    .line 3388
    :pswitch_628
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOff"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3389
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOff"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 3390
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOff"

    const-string v2, ""

    invoke-virtual {v0, v1, v6, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->putSysHealthLog(Ljava/lang/String;ILjava/lang/String;)V

    .line 3391
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fputmLastLcdOffTime(Lcom/android/server/hans/scene/HansSceneManager;J)V

    .line 3392
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmLcdOffSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneCombo;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fputmSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;Lcom/android/server/hans/scene/HansSceneCombo;)V

    .line 3393
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmLastLcdOffTime(Lcom/android/server/hans/scene/HansSceneManager;)J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$msetFirstFreezeForLcdOff(Lcom/android/server/hans/scene/HansSceneManager;J)V

    .line 3394
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 3395
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 3396
    .local v0, "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_689

    .line 3397
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 3398
    :try_start_67b
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmLastLcdOffTime(Lcom/android/server/hans/scene/HansSceneManager;)J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 3399
    monitor-exit v1

    goto :goto_689

    :catchall_686
    move-exception v2

    monitor-exit v1
    :try_end_688
    .catchall {:try_start_67b .. :try_end_688} :catchall_686

    throw v2

    .line 3401
    .end local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    :cond_689
    :goto_689
    goto/16 :goto_833

    .line 3356
    :pswitch_68b
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v0}, Lcom/android/server/hans/scene/HansSceneManager;->unfreezeDSSkipBtUids()V

    .line 3357
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOn"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->i(Ljava/lang/String;)V

    .line 3358
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOn"

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->addSYSInfo(Ljava/lang/String;)V

    .line 3359
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    const-string v1, "SrcOn"

    const-string v4, ""

    invoke-virtual {v0, v1, v6, v4}, Lcom/android/server/hans/OplusHansHistoryManager;->putSysHealthLog(Ljava/lang/String;ILjava/lang/String;)V

    .line 3360
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    invoke-static {v0, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fputmLastLcdOnTime(Lcom/android/server/hans/scene/HansSceneManager;J)V

    .line 3362
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmLcdOnSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneCombo;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fputmSceneCombo(Lcom/android/server/hans/scene/HansSceneManager;Lcom/android/server/hans/scene/HansSceneCombo;)V

    .line 3363
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mcancelFreezeForLcdOff(Lcom/android/server/hans/scene/HansSceneManager;)V

    .line 3364
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v0, v7}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyEventToSM(Lcom/android/server/hans/scene/HansSceneManager;I)V

    .line 3365
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    .line 3366
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getCurResumedUid()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansPackage(I)Lcom/android/server/hans/OplusHansPackage;

    move-result-object v0

    .line 3367
    .restart local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    if-eqz v0, :cond_70a

    .line 3368
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 3369
    :try_start_6e2
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v4

    cmp-long v4, v4, v2

    if-lez v4, :cond_705

    .line 3370
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v4

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v7

    .line 3371
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getEnterBgTime()J

    move-result-wide v10

    sub-long/2addr v8, v10

    .line 3370
    invoke-virtual {v4, v5, v7, v8, v9}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyLiveTime(ILjava/lang/String;J)V

    .line 3373
    invoke-virtual {v0, v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setEnterBgTime(J)V

    .line 3375
    :cond_705
    monitor-exit v1

    goto :goto_70a

    :catchall_707
    move-exception v2

    monitor-exit v1
    :try_end_709
    .catchall {:try_start_6e2 .. :try_end_709} :catchall_707

    throw v2

    .line 3377
    :cond_70a
    :goto_70a
    iget-object v1, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v1

    monitor-enter v1

    .line 3378
    :try_start_711
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_71b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_763

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    .line 3379
    .local v3, "uid":Ljava/lang/Integer;
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v4}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v4

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1e

    invoke-virtual {v4, v8, v5, v6, v7}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v4

    .line 3380
    .local v4, "ufzMsg":Landroid/os/Message;
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v5}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v5

    invoke-virtual {v5, v4}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(Landroid/os/Message;)Z

    .line 3381
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v5}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v5

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    const/16 v9, 0x1f

    invoke-virtual {v5, v9, v7, v6, v8}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v5

    .line 3382
    .local v5, "ufwMsg":Landroid/os/Message;
    iget-object v7, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v7}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v7

    invoke-virtual {v7, v5}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendMessage(Landroid/os/Message;)Z

    .line 3383
    nop

    .end local v3    # "uid":Ljava/lang/Integer;
    .end local v4    # "ufzMsg":Landroid/os/Message;
    .end local v5    # "ufwMsg":Landroid/os/Message;
    goto :goto_71b

    .line 3384
    :cond_763
    iget-object v2, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmTcpRetransmissionRestrictSet(Lcom/android/server/hans/scene/HansSceneManager;)Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    .line 3385
    monitor-exit v1

    .line 3386
    .end local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    goto/16 :goto_833

    .line 3385
    .restart local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    :catchall_76f
    move-exception v2

    monitor-exit v1
    :try_end_771
    .catchall {:try_start_711 .. :try_end_771} :catchall_76f

    throw v2

    .line 3352
    .end local v0    # "record":Lcom/android/server/hans/OplusHansPackage;
    :pswitch_772
    iget-object v0, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    const-string/jumbo v1, "exitFF"

    invoke-static {v0, v1}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mexitFastFreezer(Lcom/android/server/hans/scene/HansSceneManager;Ljava/lang/String;)V

    .line 3353
    goto/16 :goto_833

    .line 3312
    :pswitch_77c
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v0

    .line 3313
    .local v0, "data":Landroid/os/Bundle;
    if-nez v0, :cond_783

    .line 3314
    return-void

    .line 3316
    :cond_783
    const-string/jumbo v1, "resumedUid"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v1

    .line 3317
    .local v1, "curResumedUid":I
    const-string/jumbo v2, "resumedPkg"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 3318
    .local v2, "curResumedPkg":Ljava/lang/String;
    const-string/jumbo v3, "lastResumedUid"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v3

    .line 3319
    .local v3, "lastResumedUid":I
    const-string/jumbo v6, "lastResumedPkg"

    invoke-virtual {v0, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 3321
    .local v6, "lastResumedPkg":Ljava/lang/String;
    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v8, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->notifyAppGoForeground(ILjava/lang/String;)V

    .line 3323
    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v8, v3, v6}, Lcom/android/server/hans/scene/HansSceneManager;->notifyAppGoBackground(ILjava/lang/String;)V

    .line 3324
    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v8, v1, v2}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$mnotifyDependencyApp(Lcom/android/server/hans/scene/HansSceneManager;ILjava/lang/String;)V

    .line 3325
    iget-object v8, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v8, v5, v1}, Lcom/android/server/hans/scene/HansSceneManager;->removedUidFromWhitelistByUsage(ZI)V

    .line 3326
    invoke-static {}, Lcom/android/server/hans/app/AppUsageManager;->getInstance()Lcom/android/server/hans/app/AppUsageManager;

    move-result-object v8

    invoke-virtual {v8, v3, v6, v1, v2}, Lcom/android/server/hans/app/AppUsageManager;->notifyAppSwitch(ILjava/lang/String;ILjava/lang/String;)V

    .line 3327
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v8

    const-string v9, "SWI"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "] -> ["

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v9, v10}, Lcom/android/server/hans/OplusHansHistoryManager;->addHistoryInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 3329
    const-string v8, "com.oplus.camera"

    invoke-virtual {v2, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7fc

    .line 3330
    iget-object v5, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v5, v4, v7}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalImpScene(IZ)V

    goto :goto_809

    .line 3331
    :cond_7fc
    const-string v7, "com.oplus.camera"

    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_809

    .line 3332
    iget-object v7, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v7, v4, v5}, Lcom/android/server/hans/scene/HansSceneManager;->setThermalImpScene(IZ)V

    .line 3334
    :cond_809
    :goto_809
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-virtual {v4}, Lcom/android/server/hans/scene/HansSceneManager;->isInMinSystemScene()Z

    move-result v4

    if-eqz v4, :cond_832

    sget-object v4, Lcom/android/server/am/IOplusOsenseCommonManager;->DEFAULT:Lcom/android/server/am/IOplusOsenseCommonManager;

    .line 3335
    invoke-static {v4}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v4

    check-cast v4, Lcom/android/server/am/IOplusOsenseCommonManager;

    sget-object v5, Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;->STATUS_DEFAULT_LAUNCHER:Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;

    .line 3336
    invoke-interface {v4, v5, v1}, Lcom/android/server/am/IOplusOsenseCommonManager;->getAppStatus(Lcom/android/server/oplus/osense/OsenseConstants$AppStatusType;I)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_832

    .line 3337
    iget-object v4, p0, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->this$0:Lcom/android/server/hans/scene/HansSceneManager;

    invoke-static {v4}, Lcom/android/server/hans/scene/HansSceneManager;->-$$Nest$fgetmHandler(Lcom/android/server/hans/scene/HansSceneManager;)Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;

    move-result-object v4

    const/16 v5, 0x29

    const-wide/16 v7, 0x7530

    invoke-virtual {v4, v5, v7, v8}, Lcom/android/server/hans/scene/HansSceneManager$HansMainHandler;->sendEmptyMessageDelayed(IJ)Z

    .line 3339
    .end local v0    # "data":Landroid/os/Bundle;
    .end local v1    # "curResumedUid":I
    .end local v2    # "curResumedPkg":Ljava/lang/String;
    .end local v3    # "lastResumedUid":I
    .end local v6    # "lastResumedPkg":Ljava/lang/String;
    :cond_832
    nop

    .line 3674
    :cond_833
    :goto_833
    return-void

    :pswitch_data_834
    .packed-switch 0x1
        :pswitch_77c
        :pswitch_772
        :pswitch_68b
        :pswitch_628
        :pswitch_5e0
        :pswitch_5cd
        :pswitch_49b
        :pswitch_49b
        :pswitch_2b2
        :pswitch_29d
        :pswitch_40
        :pswitch_25d
        :pswitch_256
        :pswitch_40
        :pswitch_40
        :pswitch_233
        :pswitch_204
        :pswitch_1f9
        :pswitch_1f2
        :pswitch_1e3
        :pswitch_1d4
        :pswitch_1cf
        :pswitch_1be
        :pswitch_1b7
        :pswitch_171
        :pswitch_162
        :pswitch_151
        :pswitch_40
        :pswitch_40
        :pswitch_144
        :pswitch_117
        :pswitch_ff
        :pswitch_ec
        :pswitch_d8
        :pswitch_cf
        :pswitch_40
        :pswitch_be
        :pswitch_ab
        :pswitch_a2
        :pswitch_7d
        :pswitch_42
    .end packed-switch
.end method
