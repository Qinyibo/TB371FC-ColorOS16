.class public Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;
.super Ljava/lang/Object;
.source "OplusActivityManagerDynamicLogConfigFeature.java"

# interfaces
.implements Lcom/android/server/am/IOplusActivityManagerDynamicLogConfigFeature;


# static fields
.field private static final AGING_TEST:Z

.field private static DEBUG_PANIC:Z = false

.field private static final OCD_CONFIG_CLASS_INDEX:I = 0x3

.field private static final OCD_CONFIG_DEBUG_FLAGS_INDEX:I = 0x4

.field private static final OCD_CONFIG_INDEX_LENGTH:I = 0x5

.field private static final OCD_CONFIG_ON_INDEX:I = 0x1

.field private static final OCD_CONFIG_PROCESS_INDEX:I = 0x2

.field private static final TAG:Ljava/lang/String; = "ActivityManager"

.field private static mInstance:Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

.field private static final mLock:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 39
    const-string v0, "SPECIAL_OPLUS_CONFIG"

    invoke-static {v0}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->AGING_TEST:Z

    .line 40
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mLock:Ljava/lang/Object;

    .line 52
    const/4 v0, 0x0

    sput-object v0, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mInstance:Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

    .line 53
    const-string/jumbo v0, "persist.sys.assert.panic"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->DEBUG_PANIC:Z

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 55
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 56
    invoke-direct {p0}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->init()V

    .line 57
    return-void
.end method

.method private dynamicGetValue(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 7
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "pw"    # Ljava/io/PrintWriter;
    .param p3, "args"    # [Ljava/lang/String;

    .line 243
    array-length v0, p3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v2, :cond_20

    array-length v0, p3

    if-ne v0, v1, :cond_9

    goto :goto_20

    .line 247
    :cond_9
    const-string/jumbo v0, "get_value usage:"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 248
    const-string v0, "dumpsys activity get_value"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 249
    const-string/jumbo v0, "or"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 250
    const-string v0, "dumpsys activity get_value variable"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    goto :goto_31

    .line 244
    :cond_20
    :goto_20
    array-length v0, p3

    if-ne v0, v1, :cond_26

    aget-object v0, p3, v2

    goto :goto_28

    :cond_26
    const-string v0, ""

    .line 245
    .local v0, "strVariable":Ljava/lang/String;
    :goto_28
    new-instance v1, Lcom/android/server/oplus/DumpObject;

    invoke-direct {v1}, Lcom/android/server/oplus/DumpObject;-><init>()V

    invoke-virtual {v1, p2, p1, v0}, Lcom/android/server/oplus/DumpObject;->dumpValue(Ljava/io/PrintWriter;Ljava/lang/Object;Ljava/lang/String;)V

    .line 246
    .end local v0    # "strVariable":Ljava/lang/String;
    nop

    .line 252
    :goto_31
    return-void
.end method

.method private dynamicallyConfigLogTag(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 15
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "pw"    # Ljava/io/PrintWriter;
    .param p3, "args"    # [Ljava/lang/String;
    .param p4, "opti"    # I

    .line 103
    const/4 v0, 0x0

    .line 104
    .local v0, "tag":Ljava/lang/String;
    const/4 v1, 0x0

    .line 106
    .local v1, "on":Z
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dynamicallyConfigLogTag, opti:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", args.length:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    array-length v3, p3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 107
    const/4 v2, 0x0

    .local v2, "index":I
    :goto_24
    array-length v3, p3

    if-ge v2, v3, :cond_4c

    .line 108
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "dynamicallyConfigLogTag, args["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "]:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    aget-object v4, p3, v2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 107
    add-int/lit8 v2, v2, 0x1

    goto :goto_24

    .line 111
    .end local v2    # "index":I
    :cond_4c
    array-length v2, p3

    const/4 v3, 0x3

    if-eq v2, v3, :cond_59

    .line 112
    const-string v2, "********** Invalid argument! Get detail help as bellow: **********"

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 113
    invoke-direct {p0, p2}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->logoutTagConfigHelp(Ljava/io/PrintWriter;)V

    .line 114
    return-void

    .line 117
    :cond_59
    const/4 v2, 0x1

    aget-object v0, p3, v2

    .line 118
    const/4 v2, 0x2

    aget-object v2, p3, v2

    const-string v3, "1"

    invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    .line 120
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dynamicallyConfigLogTag, tag:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", on:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 121
    const-string v2, "broadcast"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_ef

    .line 124
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dl Ams bc, A:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v3, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v4, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_BACKGROUND:Z

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v4, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_LIGHT:Z

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 128
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST:Z

    .line 129
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_BACKGROUND:Z

    .line 130
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_LIGHT:Z

    .line 134
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "dl Ams bc, B:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v4, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST:Z

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v4, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_BACKGROUND:Z

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-boolean v3, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_LIGHT:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    goto/16 :goto_222

    .line 138
    :cond_ef
    const-string/jumbo v2, "oplusbroadcast"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_fa

    goto/16 :goto_222

    .line 141
    :cond_fa
    const-string/jumbo v2, "service"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    const-string v4, "ActiveServices"

    if-eqz v2, :cond_11b

    .line 143
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_SERVICE:Z

    .line 144
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_SERVICE_EXECUTING:Z

    .line 145
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_MU:Z

    .line 146
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BACKGROUND_CHECK:Z

    .line 147
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_FOREGROUND_SERVICE:Z

    .line 149
    if-eqz p1, :cond_222

    .line 150
    invoke-virtual {p1}, Lcom/android/server/am/ActivityManagerService;->getWrapper()Lcom/android/server/am/IActivityManagerServiceWrapper;

    move-result-object v2

    invoke-interface {v2, v4, v3, v1}, Lcom/android/server/am/IActivityManagerServiceWrapper;->dynamicalConfigLog(Ljava/lang/String;Landroid/app/IApplicationThread;Z)V

    goto/16 :goto_222

    .line 152
    :cond_11b
    const-string/jumbo v2, "provider"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_12a

    .line 154
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROVIDER:Z

    .line 155
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_MU:Z

    goto/16 :goto_222

    .line 156
    :cond_12a
    const-string v2, "backup"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_136

    .line 158
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BACKUP:Z

    goto/16 :goto_222

    .line 159
    :cond_136
    const-string/jumbo v2, "process"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_145

    .line 160
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROCESSES:Z

    .line 161
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROCESS_OBSERVERS:Z

    goto/16 :goto_222

    .line 162
    :cond_145
    const-string/jumbo v2, "other"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const-string v5, "DEBUG"

    const-string v6, "android.view.ViewRootImpl"

    const-string/jumbo v7, "localLOGV,DEBUG_BROADCAST,DEBUG_SERVICE,DEBUG_MESSAGES,DEBUG_MEMORY_TRIM,DEBUG_BROADCAST_LIGHT,DEBUG_CONFIGURATION,DEBUG_PROVIDER"

    const-string v8, "android.app.ActivityThread"

    const-string v9, "all_app"

    if-eqz v2, :cond_18c

    .line 164
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_POWER:Z

    .line 165
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_OOM_ADJ:Z

    .line 166
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_LRU:Z

    .line 179
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    invoke-virtual {v2, v1, v9, v8, v7}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 181
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    const-string v3, "android.content.res.ResourcesImpl"

    const-string v4, "DEBUG_LOAD,DEBUG_CONFIG"

    invoke-virtual {v2, v1, v9, v3, v4}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 182
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    const-string v3, "DEBUG_LOAD,DEBUG_CONFIGURATION"

    invoke-virtual {v2, v1, v9, v6, v3}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 183
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    const-string v3, "android.app.ResourcesManager"

    invoke-virtual {v2, v1, v9, v3, v5}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 185
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/server/am/WmDynamicalLogManager;->runConfigUpdateListener(Z)V

    goto/16 :goto_222

    .line 187
    :cond_18c
    const-string/jumbo v2, "fw"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_19e

    .line 189
    invoke-static {}, Lcom/android/server/wm/OplusFloatingWindowHelper;->getInstance()Lcom/android/server/wm/OplusFloatingWindowHelper;

    move-result-object v2

    invoke-virtual {v2, p2, p3}, Lcom/android/server/wm/OplusFloatingWindowHelper;->dump(Ljava/io/PrintWriter;[Ljava/lang/String;)Z

    goto/16 :goto_222

    .line 191
    :cond_19e
    const-string v2, "ams_all"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1e8

    .line 192
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_ANR:Z

    .line 193
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BACKGROUND_CHECK:Z

    .line 194
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BACKUP:Z

    .line 195
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST:Z

    .line 196
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_BACKGROUND:Z

    .line 197
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_LIGHT:Z

    .line 198
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_BROADCAST_DEFERRAL:Z

    .line 199
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_COMPACTION:Z

    .line 200
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_FREEZER:Z

    .line 201
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_LRU:Z

    .line 202
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_MU:Z

    .line 203
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_NETWORK:Z

    .line 204
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_OOM_ADJ:Z

    .line 205
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_OOM_ADJ_REASON:Z

    .line 206
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_POWER:Z

    .line 207
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_POWER_QUICK:Z

    .line 208
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROCESS_OBSERVERS:Z

    .line 209
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROCESSES:Z

    .line 210
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PROVIDER:Z

    .line 211
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PSS:Z

    .line 212
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_SERVICE:Z

    .line 213
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_FOREGROUND_SERVICE:Z

    .line 214
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_SERVICE_EXECUTING:Z

    .line 215
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_UID_OBSERVERS:Z

    .line 216
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_USAGE_STATS:Z

    .line 217
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_PERMISSIONS_REVIEW:Z

    .line 218
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_ALLOWLISTS:Z

    .line 219
    sput-boolean v1, Lcom/android/server/am/ActivityManagerDebugConfig;->DEBUG_ALL:Z

    .line 222
    if-eqz p1, :cond_222

    .line 223
    invoke-virtual {p1}, Lcom/android/server/am/ActivityManagerService;->getWrapper()Lcom/android/server/am/IActivityManagerServiceWrapper;

    move-result-object v2

    invoke-interface {v2, v4, v3, v1}, Lcom/android/server/am/IActivityManagerServiceWrapper;->dynamicalConfigLog(Ljava/lang/String;Landroid/app/IApplicationThread;Z)V

    goto :goto_222

    .line 225
    :cond_1e8
    const-string v2, "app_all"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_205

    .line 226
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v2

    .line 227
    .local v2, "wmdlm":Lcom/android/server/am/WmDynamicalLogManager;
    invoke-virtual {v2, v1, v9, v8, v7}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 230
    const-string v3, "DEBUG_CONFIGURATION,DEBUG_LAYOUT,DEBUG_DIALOG,DEBUG_DRAW,DEBUG_ORIENTATION"

    invoke-virtual {v2, v1, v9, v6, v3}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 232
    const-string v3, "android.view.InsetsController"

    invoke-virtual {v2, v1, v9, v3, v5}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    invoke-virtual {v2, v1}, Lcom/android/server/am/WmDynamicalLogManager;->runConfigUpdateListener(Z)V

    .line 234
    .end local v2    # "wmdlm":Lcom/android/server/am/WmDynamicalLogManager;
    goto :goto_222

    :cond_205
    const-string/jumbo v2, "opluseap"

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_216

    .line 235
    invoke-static {}, Lcom/android/server/am/OplusEapManager;->getInstance()Lcom/android/server/am/OplusEapManager;

    move-result-object v2

    invoke-virtual {v2, p2, p3}, Lcom/android/server/am/OplusEapManager;->dumpsys(Ljava/io/PrintWriter;[Ljava/lang/String;)V

    goto :goto_222

    .line 236
    :cond_216
    invoke-static {p2, p3, p4}, Lcom/android/server/wm/ActivityTaskManagerDynamicLogConfig;->dynamicallyConfigLogTag(Ljava/io/PrintWriter;[Ljava/lang/String;I)Z

    move-result v2

    if-nez v2, :cond_222

    .line 237
    const-string v2, "Failed! Invalid argument! Type cmd for help: dumpsys activity log"

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 238
    return-void

    .line 240
    :cond_222
    :goto_222
    return-void
.end method

.method private dynamicallyOCDConfig(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;I)V
    .registers 13
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "pw"    # Ljava/io/PrintWriter;
    .param p3, "args"    # [Ljava/lang/String;
    .param p4, "opti"    # I

    .line 332
    const/4 v0, 0x0

    .line 333
    .local v0, "on":Z
    const/4 v1, 0x0

    .line 334
    .local v1, "processName":Ljava/lang/String;
    const/4 v2, 0x0

    .line 335
    .local v2, "configType":Ljava/lang/String;
    const/4 v3, 0x0

    .line 337
    .local v3, "debugFlags":Ljava/lang/String;
    :try_start_4
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "dynamicallyOCDConfig, opti:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ", args.length:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    array-length v5, p3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 338
    const/4 v4, 0x0

    .local v4, "index":I
    :goto_26
    array-length v5, p3

    const/4 v6, 0x0

    if-ge v4, v5, :cond_76

    .line 339
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "dynamicallyOCDConfig, args["

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "]:"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    aget-object v7, p3, v4

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p2, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 341
    packed-switch v4, :pswitch_data_bc

    goto :goto_73

    .line 352
    :pswitch_50
    aget-object v5, p3, v4

    .line 353
    .end local v3    # "debugFlags":Ljava/lang/String;
    .local v5, "debugFlags":Ljava/lang/String;
    move-object v3, v5

    goto :goto_73

    .line 349
    .end local v5    # "debugFlags":Ljava/lang/String;
    .restart local v3    # "debugFlags":Ljava/lang/String;
    :pswitch_54
    aget-object v5, p3, v4

    .line 350
    .end local v2    # "configType":Ljava/lang/String;
    .local v5, "configType":Ljava/lang/String;
    move-object v2, v5

    goto :goto_73

    .line 346
    .end local v5    # "configType":Ljava/lang/String;
    .restart local v2    # "configType":Ljava/lang/String;
    :pswitch_58
    aget-object v5, p3, v4

    .line 347
    .end local v1    # "processName":Ljava/lang/String;
    .local v5, "processName":Ljava/lang/String;
    move-object v1, v5

    goto :goto_73

    .line 343
    .end local v5    # "processName":Ljava/lang/String;
    .restart local v1    # "processName":Ljava/lang/String;
    :pswitch_5c
    const-string v5, "1"

    aget-object v7, p3, v4

    invoke-virtual {v5, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_71

    const-string/jumbo v5, "on"

    aget-object v7, p3, v4

    invoke-virtual {v5, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_72

    :cond_71
    const/4 v6, 0x1

    .line 344
    .end local v0    # "on":Z
    .local v6, "on":Z
    :cond_72
    move v0, v6

    .line 338
    .end local v6    # "on":Z
    .restart local v0    # "on":Z
    :goto_73
    add-int/lit8 v4, v4, 0x1

    goto :goto_26

    .line 359
    .end local v4    # "index":I
    :cond_76
    array-length v4, p3

    const/4 v5, 0x5

    if-ne v4, v5, :cond_b0

    if-eqz v2, :cond_b0

    if-eqz v1, :cond_b0

    if-nez v3, :cond_81

    goto :goto_b0

    .line 366
    :cond_81
    const/4 v4, 0x0

    .line 367
    .local v4, "className":Ljava/lang/String;
    const-string v5, "debug"

    invoke-virtual {v5, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8e

    .line 368
    const-string v5, "com.oplus.dispatch.OCDDebugConfig"

    move-object v4, v5

    goto :goto_a2

    .line 369
    :cond_8e
    const-string v5, "dump"

    invoke-virtual {v5, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_9a

    .line 370
    const-string v5, "OCDDump"

    move-object v4, v5

    goto :goto_a2

    .line 372
    :cond_9a
    const-string v5, "Invalid className!\n"

    invoke-virtual {p2, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 373
    invoke-direct {p0, p2}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->onOCDConfigHelp(Ljava/io/PrintWriter;)V

    .line 376
    :goto_a2
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v5

    .line 377
    .local v5, "wmdlm":Lcom/android/server/am/WmDynamicalLogManager;
    invoke-virtual {v5, v0, v1, v4, v3}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 378
    invoke-virtual {v5, v0}, Lcom/android/server/am/WmDynamicalLogManager;->runConfigUpdateListener(Z)V

    .line 379
    invoke-virtual {v5, v6, v1, v4, v3}, Lcom/android/server/am/WmDynamicalLogManager;->setOneshotLogConfig(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 381
    .end local v0    # "on":Z
    .end local v1    # "processName":Ljava/lang/String;
    .end local v2    # "configType":Ljava/lang/String;
    .end local v3    # "debugFlags":Ljava/lang/String;
    .end local v4    # "className":Ljava/lang/String;
    .end local v5    # "wmdlm":Lcom/android/server/am/WmDynamicalLogManager;
    goto :goto_ba

    .line 361
    .restart local v0    # "on":Z
    .restart local v1    # "processName":Ljava/lang/String;
    .restart local v2    # "configType":Ljava/lang/String;
    .restart local v3    # "debugFlags":Ljava/lang/String;
    :cond_b0
    :goto_b0
    const-string v4, "Invalid argument!\n"

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 362
    invoke-direct {p0, p2}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->onOCDConfigHelp(Ljava/io/PrintWriter;)V
    :try_end_b8
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_b8} :catch_b9

    .line 363
    return-void

    .line 380
    .end local v0    # "on":Z
    .end local v1    # "processName":Ljava/lang/String;
    .end local v2    # "configType":Ljava/lang/String;
    .end local v3    # "debugFlags":Ljava/lang/String;
    :catch_b9
    move-exception v0

    .line 382
    :goto_ba
    return-void

    nop

    :pswitch_data_bc
    .packed-switch 0x1
        :pswitch_5c
        :pswitch_58
        :pswitch_54
        :pswitch_50
    .end packed-switch
.end method

.method public static getInstance()Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;
    .registers 2

    .line 60
    sget-object v0, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mLock:Ljava/lang/Object;

    monitor-enter v0

    .line 61
    :try_start_3
    sget-object v1, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mInstance:Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

    if-nez v1, :cond_e

    .line 62
    new-instance v1, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

    invoke-direct {v1}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;-><init>()V

    sput-object v1, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mInstance:Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

    .line 64
    :cond_e
    sget-object v1, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->mInstance:Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;

    monitor-exit v0

    return-object v1

    .line 65
    :catchall_12
    move-exception v1

    monitor-exit v0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_12

    throw v1
.end method

.method private init()V
    .registers 3

    .line 69
    const-string v0, "ActivityManager"

    const-string v1, "OplusActivityManagerDynamicLogConfigFeature init."

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 70
    return-void
.end method

.method private logoutTagConfigHelp(Ljava/io/PrintWriter;)V
    .registers 4
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 255
    const-string v0, "********************** Help begin:**********************"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 257
    const-string v0, "1 Activity life circle:DEBUG_SWITCH | DEBUG_PAUSE DEBUG_RESULTS | DEBUG_CLEANUP | DEBUG_STATES"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 258
    const-string v0, "cmd: dumpsys activity log life 0/1"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 259
    const-string v0, "----------------------------------"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 261
    const-string v1, "2 App visibility:DEBUG_VISIBILITY | DEBUG_TRANSITION | DEBUG_FOCUS"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 262
    const-string v1, "cmd: dumpsys activity log visibility 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 263
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 265
    const-string v1, "3 Config process:DEBUG_CONFIGURATION"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 266
    const-string v1, "cmd: dumpsys activity log config 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 267
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 269
    const-string v1, "4 Task manage:DEBUG_TASKS | DEBUG_CLEANUP | DEBUG_ADD_REMOVE | DEBUG_SAVED_STATE"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 270
    const-string v1, "cmd: dumpsys activity log task 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 271
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 273
    const-string v1, "5 Broadcast manage:DEBUG_BROADCAST | DEBUG_BROADCAST_BACKGROUND | DEBUG_BROADCAST_LIGHT"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 274
    const-string v1, "cmd: dumpsys activity log broadcast 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 275
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 277
    const-string v1, "6 Service manage:DEBUG_SERVICE | DEBUG_SERVICE_EXECUTING | DEBUG_MU | ActiveServices\'s Log"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 278
    const-string v1, "cmd: dumpsys activity log service 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 279
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 281
    const-string v1, "7 Provider manage:DEBUG_PROVIDER | DEBUG_URI_PERMISSION | DEBUG_MU"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 282
    const-string v1, "cmd: dumpsys activity log provider 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 283
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 285
    const-string v1, "8 backup manage:DEBUG_BACKUP"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 286
    const-string v1, "cmd: dumpsys activity log backup 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 287
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 289
    const-string v1, "9 stack manager log:Ams stack & ActivityStackSupervisor & ActivityStack"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 290
    const-string v1, "cmd: dumpsys activity log stack 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 291
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 293
    const-string v1, "10 process manage:DEBUG_PROCESSES | DEBUG_PROCESS_OBSERVERS"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 294
    const-string v1, "cmd: dumpsys activity log process 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 295
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 297
    const-string v1, "11 oplusBroadcast manage:DEBUG_JUMP_QUEUE | DEBUG_ADJUST_PB_REC_QUE | DEBUG_ADJUST_OB_REC_QUE | DEBUG_BROADCAST_FIREWALL "

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 298
    const-string v1, "cmd: dumpsys activity log oplusbroadcast 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 299
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 301
    const-string v1, "12 other not in common use:DEBUG_POWER | DEBUG_THUMBNAILS | DEBUG_OOM_ADJ | DEBUG_LOCKSCREEN | DEBUG_LRU | DEBUG_PSS "

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 302
    const-string v1, "cmd: dumpsys activity log other 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 303
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 305
    const-string v1, "13 fstrim:DEBUG_FSTRIM"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 306
    const-string v1, "cmd: dumpsys activity log fstrim 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 307
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 309
    const-string v1, "14 fstrim:DEBUG_PERMISSION"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 310
    const-string v1, "cmd: dumpsys activity log permission 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 311
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 313
    const-string v1, "15 junk:DEBUG_JUNK"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 314
    const-string v1, "cmd: dumpsys activity log junk 0/1"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 315
    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 317
    const-string v0, "********************** Help end.  **********************"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 318
    return-void
.end method

.method private onOCDConfigHelp(Ljava/io/PrintWriter;)V
    .registers 3
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 385
    const-string v0, "OCD Help options:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 386
    const-string v0, "  use adb command to open OCD log"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 387
    const-string v0, "  => adb shell dumpsys activity ocd_config (1(on)/0(off)) (pid or processName) (debug/OCDDump) (DEBUG_***,DEBUG_***)\n"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 389
    const-string v0, "  1) open com.ocd.test\'s OCD debug log:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 390
    const-string v0, "  adb shell dumpsys activity ocd_config on com.ocd.test debug DEBUG_WARNING,DEBUG_DISPATCH\n"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 392
    const-string v0, "  2) OCD dump in com.ocd.test:"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 393
    const-string v0, "  adb shell dumpsys activity ocd_config on com.ocd.test dump 1"

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 394
    return-void
.end method


# virtual methods
.method public doDump(Lcom/android/server/am/ActivityManagerService;Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;I)Z
    .registers 9
    .param p1, "ams"    # Lcom/android/server/am/ActivityManagerService;
    .param p2, "cmd"    # Ljava/lang/String;
    .param p3, "fd"    # Ljava/io/FileDescriptor;
    .param p4, "pw"    # Ljava/io/PrintWriter;
    .param p5, "args"    # [Ljava/lang/String;
    .param p6, "opti"    # I

    .line 74
    const/4 v0, 0x1

    .line 78
    .local v0, "handle":Z
    const-string/jumbo v1, "log"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 79
    invoke-direct {p0, p1, p4, p5, p6}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->dynamicallyConfigLogTag(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_3a

    .line 80
    :cond_e
    const-string/jumbo v1, "get_value"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1b

    .line 81
    invoke-direct {p0, p1, p4, p5}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->dynamicGetValue(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    goto :goto_3a

    .line 82
    :cond_1b
    const-string/jumbo v1, "oplus_wm_log"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    .line 83
    invoke-static {}, Lcom/android/server/am/WmDynamicalLogManager;->getInstance()Lcom/android/server/am/WmDynamicalLogManager;

    move-result-object v1

    invoke-virtual {v1, p4, p5}, Lcom/android/server/am/WmDynamicalLogManager;->dumpsys(Ljava/io/PrintWriter;[Ljava/lang/String;)V

    goto :goto_3a

    .line 86
    :cond_2c
    const-string/jumbo v1, "ocd_config"

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_39

    .line 87
    invoke-direct {p0, p1, p4, p5, p6}, Lcom/android/server/am/OplusActivityManagerDynamicLogConfigFeature;->dynamicallyOCDConfig(Lcom/android/server/am/ActivityManagerService;Ljava/io/PrintWriter;[Ljava/lang/String;I)V

    goto :goto_3a

    .line 90
    :cond_39
    const/4 v0, 0x0

    .line 92
    :goto_3a
    return v0
.end method

.method public enableDefaultLogIfNeed()V
    .registers 1

    .line 99
    return-void
.end method
