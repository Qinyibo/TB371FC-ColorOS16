.class public Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;
.super Ljava/lang/Object;
.source "RfcommServerRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private volatile exit:Z

.field private final mAppUID:Ljava/lang/Integer;

.field private final mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

.field private final mRfcommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

.field private mServerSocket:Landroid/bluetooth/BluetoothServerSocket;

.field private final mServiceName:Ljava/lang/String;

.field private final mServiceUuid:Ljava/util/UUID;

.field private mSocket:Landroid/bluetooth/BluetoothSocket;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 32
    const-class v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/util/UUID;Ljava/lang/Integer;Ljava/lang/String;Landroid/bluetooth/BluetoothAdapter;Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;)V
    .registers 7
    .param p1, "uuid"    # Ljava/util/UUID;
    .param p2, "appUID"    # Ljava/lang/Integer;
    .param p3, "name"    # Ljava/lang/String;
    .param p4, "bluetoothAdapter"    # Landroid/bluetooth/BluetoothAdapter;
    .param p5, "rfcommOemManager"    # Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    .line 50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit:Z

    .line 43
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    .line 51
    iput-object p5, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mRfcommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    .line 52
    iput-object p2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mAppUID:Ljava/lang/Integer;

    .line 53
    iput-object p3, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServiceName:Ljava/lang/String;

    .line 54
    iput-object p1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServiceUuid:Ljava/util/UUID;

    .line 55
    iput-object p4, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    .line 56
    return-void
.end method


# virtual methods
.method public exit()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 83
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit:Z

    .line 84
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServerSocket:Landroid/bluetooth/BluetoothServerSocket;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothServerSocket;->close()V

    .line 85
    return-void
.end method

.method public getAddress()Ljava/lang/String;
    .registers 2

    .line 92
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v0

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getAppUID()Ljava/lang/Integer;
    .registers 2

    .line 88
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mAppUID:Ljava/lang/Integer;

    return-object v0
.end method

.method public run()V
    .registers 4

    .line 60
    nop

    :cond_1
    :goto_1
    iget-boolean v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->exit:Z

    if-nez v0, :cond_5d

    .line 62
    const/4 v0, 0x0

    :try_start_6
    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    .line 63
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServerSocket:Landroid/bluetooth/BluetoothServerSocket;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothServerSocket;->accept()Landroid/bluetooth/BluetoothSocket;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_10} :catch_11

    .line 66
    goto :goto_19

    .line 64
    :catch_11
    move-exception v0

    .line 65
    .local v0, "e":Ljava/io/IOException;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransfer: Socket\'s accept() method failed or disable rfcomm server"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 67
    .end local v0    # "e":Ljava/io/IOException;
    :goto_19
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    if-eqz v0, :cond_1

    .line 70
    sget-object v0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "BluetoothTransfer: Accepted Socket:\nremote device name: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    .line 73
    invoke-virtual {v2}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\nremote device address: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    .line 76
    invoke-virtual {v2}, Landroid/bluetooth/BluetoothSocket;->getRemoteDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v2

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 70
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mRfcommOemManager:Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;

    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mSocket:Landroid/bluetooth/BluetoothSocket;

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mAppUID:Ljava/lang/Integer;

    invoke-virtual {v0, v1, v2}, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommOemManager;->manageAcceptedSocket(Landroid/bluetooth/BluetoothSocket;Ljava/lang/Integer;)V

    goto :goto_1

    .line 80
    :cond_5d
    return-void
.end method

.method public startListen()Z
    .registers 4

    .line 98
    :try_start_0
    iget-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mBluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;

    iget-object v1, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServiceName:Ljava/lang/String;

    iget-object v2, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServiceUuid:Ljava/util/UUID;

    invoke-virtual {v0, v1, v2}, Landroid/bluetooth/BluetoothAdapter;->listenUsingRfcommWithServiceRecord(Ljava/lang/String;Ljava/util/UUID;)Landroid/bluetooth/BluetoothServerSocket;

    move-result-object v0
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_a} :catch_f

    .line 102
    .local v0, "tmpServerSocket":Landroid/bluetooth/BluetoothServerSocket;
    nop

    .line 103
    iput-object v0, p0, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->mServerSocket:Landroid/bluetooth/BluetoothServerSocket;

    .line 104
    const/4 v1, 0x1

    return v1

    .line 99
    .end local v0    # "tmpServerSocket":Landroid/bluetooth/BluetoothServerSocket;
    :catch_f
    move-exception v0

    .line 100
    .local v0, "e":Ljava/io/IOException;
    sget-object v1, Lcom/android/server/deviceexperiences/brokerrfcomm/RfcommServerRunnable;->TAG:Ljava/lang/String;

    const-string v2, "BluetoothTransfer: Socket\'s listen() method failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 101
    const/4 v1, 0x0

    return v1
.end method
