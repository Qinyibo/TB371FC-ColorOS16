.class Lcom/android/server/hans/states/StateMachine$SmHandler;
.super Landroid/os/Handler;
.source "StateMachine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/states/StateMachine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "SmHandler"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;,
        Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;,
        Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;
    }
.end annotation


# static fields
.field private static final mQuitObj:Ljava/lang/Object;


# instance fields
.field private mDbg:Z

.field private mDeferredMessages:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/os/Message;",
            ">;"
        }
    .end annotation
.end field

.field private mDestState:Lcom/android/server/hans/states/State;

.field private mHaltingState:Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

.field private mInitialState:Lcom/android/server/hans/states/State;

.field private mIsConstructionCompleted:Z

.field private mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

.field private mQuittingState:Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

.field private mSm:Lcom/android/server/hans/states/StateMachine;

.field private mStateInfo:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Lcom/android/server/hans/states/State;",
            "Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;",
            ">;"
        }
    .end annotation
.end field

.field private mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

.field private mStateStackTopIndex:I

.field private mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

.field private mTempStateStackCount:I


# direct methods
.method static bridge synthetic -$$Nest$fgetmDbg(Lcom/android/server/hans/states/StateMachine$SmHandler;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmHaltingState(Lcom/android/server/hans/states/StateMachine$SmHandler;)Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mHaltingState:Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmSm(Lcom/android/server/hans/states/StateMachine$SmHandler;)Lcom/android/server/hans/states/StateMachine;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$maddState(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/states/StateMachine$SmHandler;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mcompleteConstruction(Lcom/android/server/hans/states/StateMachine$SmHandler;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->completeConstruction()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mdeferMessage(Lcom/android/server/hans/states/StateMachine$SmHandler;Landroid/os/Message;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->deferMessage(Landroid/os/Message;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mgetCurrentState(Lcom/android/server/hans/states/StateMachine$SmHandler;)Lcom/android/server/hans/states/IState;
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->getCurrentState()Lcom/android/server/hans/states/IState;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mgetProcessedMessageInfo(Lcom/android/server/hans/states/StateMachine$SmHandler;I)Lcom/android/server/hans/states/StateMachine$ProcessedMessageInfo;
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->getProcessedMessageInfo(I)Lcom/android/server/hans/states/StateMachine$ProcessedMessageInfo;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mgetProcessedMessagesCount(Lcom/android/server/hans/states/StateMachine$SmHandler;)I
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->getProcessedMessagesCount()I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mgetProcessedMessagesSize(Lcom/android/server/hans/states/StateMachine$SmHandler;)I
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->getProcessedMessagesSize()I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$misDbg(Lcom/android/server/hans/states/StateMachine$SmHandler;)Z
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->isDbg()Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$misQuit(Lcom/android/server/hans/states/StateMachine$SmHandler;Landroid/os/Message;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->isQuit(Landroid/os/Message;)Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mquit(Lcom/android/server/hans/states/StateMachine$SmHandler;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->quit()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDbg(Lcom/android/server/hans/states/StateMachine$SmHandler;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->setDbg(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialState(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/State;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->setInitialState(Lcom/android/server/hans/states/State;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetProcessedMessagesSize(Lcom/android/server/hans/states/StateMachine$SmHandler;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->setProcessedMessagesSize(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mtransitionTo(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/IState;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->transitionTo(Lcom/android/server/hans/states/IState;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    .line 229
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuitObj:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>(Landroid/os/Looper;Lcom/android/server/hans/states/StateMachine;)V
    .registers 5
    .param p1, "looper"    # Landroid/os/Looper;
    .param p2, "sm"    # Lcom/android/server/hans/states/StateMachine;

    .line 697
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 226
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    .line 232
    new-instance v0, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-direct {v0}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    .line 241
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    .line 250
    new-instance v0, Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;-><init>(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/StateMachine-IA;)V

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mHaltingState:Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

    .line 253
    new-instance v0, Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

    invoke-direct {v0, p0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;-><init>(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/StateMachine-IA;)V

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuittingState:Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

    .line 284
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    .line 294
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    .line 698
    iput-object p2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    .line 700
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mHaltingState:Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

    invoke-direct {p0, v0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 701
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuittingState:Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

    invoke-direct {p0, v0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 702
    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Looper;Lcom/android/server/hans/states/StateMachine;Lcom/android/server/hans/states/StateMachine-IA;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lcom/android/server/hans/states/StateMachine$SmHandler;-><init>(Landroid/os/Looper;Lcom/android/server/hans/states/StateMachine;)V

    return-void
.end method

.method private final addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    .registers 8
    .param p1, "state"    # Lcom/android/server/hans/states/State;
    .param p2, "parent"    # Lcom/android/server/hans/states/State;

    .line 660
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    const-string v1, "StateMachine"

    if-eqz v0, :cond_33

    .line 661
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "addStateInternal: E state="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ",parent="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 662
    if-nez p2, :cond_24

    const-string v2, ""

    goto :goto_28

    :cond_24
    invoke-virtual {p2}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v2

    :goto_28
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 661
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 664
    :cond_33
    const/4 v0, 0x0

    .line 665
    .local v0, "parentStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    const/4 v2, 0x0

    if-eqz p2, :cond_46

    .line 666
    iget-object v3, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v3, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object v0, v3

    check-cast v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 667
    if-nez v0, :cond_46

    .line 669
    invoke-direct {p0, p2, v2}, Lcom/android/server/hans/states/StateMachine$SmHandler;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    move-result-object v0

    .line 672
    :cond_46
    iget-object v3, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v3, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 673
    .local v3, "stateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    if-nez v3, :cond_5b

    .line 674
    new-instance v4, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    invoke-direct {v4, p0, v2}, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;-><init>(Lcom/android/server/hans/states/StateMachine$SmHandler;Lcom/android/server/hans/states/StateMachine-IA;)V

    move-object v3, v4

    .line 675
    iget-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v2, p1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 679
    :cond_5b
    iget-object v2, v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    if-eqz v2, :cond_6d

    iget-object v2, v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    if-ne v2, v0, :cond_64

    goto :goto_6d

    .line 681
    :cond_64
    new-instance v1, Ljava/lang/RuntimeException;

    const-string/jumbo v2, "state already added"

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 683
    :cond_6d
    :goto_6d
    iput-object p1, v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    .line 684
    iput-object v0, v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 685
    const/4 v2, 0x0

    iput-boolean v2, v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->active:Z

    .line 686
    iget-boolean v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v2, :cond_8e

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "addStateInternal: X stateInfo: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 687
    :cond_8e
    return-object v3
.end method

.method private final cleanupAfterQuitting()V
    .registers 3

    .line 409
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-virtual {v0}, Lcom/android/server/hans/states/StateMachine;->quitting()V

    .line 410
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-static {v0}, Lcom/android/server/hans/states/StateMachine;->-$$Nest$fgetmSmThread(Lcom/android/server/hans/states/StateMachine;)Landroid/os/HandlerThread;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1a

    .line 412
    invoke-virtual {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    .line 413
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/StateMachine;->-$$Nest$fputmSmThread(Lcom/android/server/hans/states/StateMachine;Landroid/os/HandlerThread;)V

    .line 416
    :cond_1a
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-static {v0, v1}, Lcom/android/server/hans/states/StateMachine;->-$$Nest$fputmSmHandler(Lcom/android/server/hans/states/StateMachine;Lcom/android/server/hans/states/StateMachine$SmHandler;)V

    .line 417
    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    .line 418
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-virtual {v0}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->cleanup()V

    .line 419
    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 420
    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 421
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    .line 422
    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mInitialState:Lcom/android/server/hans/states/State;

    .line 423
    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    .line 424
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 425
    return-void
.end method

.method private final completeConstruction()V
    .registers 7

    .line 431
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    const-string v1, "StateMachine"

    if-eqz v0, :cond_b

    const-string v0, "completeConstruction: E"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 437
    :cond_b
    const/4 v0, 0x0

    .line 438
    .local v0, "maxDepth":I
    iget-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_16
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 439
    .local v3, "si":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    const/4 v4, 0x0

    .line 440
    .local v4, "depth":I
    move-object v5, v3

    .local v5, "i":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    :goto_24
    if-eqz v5, :cond_2b

    .line 441
    iget-object v5, v5, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 440
    add-int/lit8 v4, v4, 0x1

    goto :goto_24

    .line 443
    .end local v5    # "i":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    :cond_2b
    if-ge v0, v4, :cond_2e

    .line 444
    move v0, v4

    .line 446
    .end local v3    # "si":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    .end local v4    # "depth":I
    :cond_2e
    goto :goto_16

    .line 447
    :cond_2f
    iget-boolean v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v2, :cond_49

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "completeConstruction: maxDepth="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 449
    :cond_49
    new-array v2, v0, [Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iput-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 450
    new-array v2, v0, [Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iput-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 451
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->setupInitialStateStack()V

    .line 457
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mIsConstructionCompleted:Z

    .line 458
    const/4 v2, 0x0

    invoke-direct {p0, v2}, Lcom/android/server/hans/states/StateMachine$SmHandler;->invokeEnterMethods(I)V

    .line 463
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->performTransitions()V

    .line 465
    iget-boolean v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v2, :cond_67

    const-string v2, "completeConstruction: X"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 466
    :cond_67
    return-void
.end method

.method private final deferMessage(Landroid/os/Message;)V
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .line 718
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_1e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "deferMessage: msg="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p1, Landroid/os/Message;->what:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "StateMachine"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 721
    :cond_1e
    invoke-virtual {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 722
    .local v0, "newMsg":Landroid/os/Message;
    invoke-virtual {v0, p1}, Landroid/os/Message;->copyFrom(Landroid/os/Message;)V

    .line 724
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 725
    return-void
.end method

.method private final getCurrentState()Lcom/android/server/hans/states/IState;
    .registers 3

    .line 647
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v0, v0, v1

    iget-object v0, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    return-object v0
.end method

.method private final getProcessedMessageInfo(I)Lcom/android/server/hans/states/StateMachine$ProcessedMessageInfo;
    .registers 3
    .param p1, "index"    # I

    .line 765
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-virtual {v0, p1}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->get(I)Lcom/android/server/hans/states/StateMachine$ProcessedMessageInfo;

    move-result-object v0

    return-object v0
.end method

.method private final getProcessedMessagesCount()I
    .registers 2

    .line 760
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-virtual {v0}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->count()I

    move-result v0

    return v0
.end method

.method private final getProcessedMessagesSize()I
    .registers 2

    .line 755
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-virtual {v0}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->size()I

    move-result v0

    return v0
.end method

.method private final invokeEnterMethods(I)V
    .registers 5
    .param p1, "stateStackEnteringIndex"    # I

    .line 528
    move v0, p1

    .local v0, "i":I
    :goto_1
    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    if-gt v0, v1, :cond_3f

    .line 529
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v1, :cond_2c

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "invokeEnterMethods: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    aget-object v2, v2, v0

    iget-object v2, v2, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v2}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "StateMachine"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 530
    :cond_2c
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    aget-object v1, v1, v0

    iget-object v1, v1, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v1}, Lcom/android/server/hans/states/State;->enter()V

    .line 531
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    aget-object v1, v1, v0

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->active:Z

    .line 528
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 533
    .end local v0    # "i":I
    :cond_3f
    return-void
.end method

.method private final invokeExitMethods(Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;)V
    .registers 5
    .param p1, "commonStateInfo"    # Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 514
    nop

    :goto_1
    iget v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    if-ltz v0, :cond_49

    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v0, v0, v1

    if-eq v0, p1, :cond_49

    .line 516
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v0, v0, v1

    iget-object v0, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    .line 517
    .local v0, "curState":Lcom/android/server/hans/states/State;
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v1, :cond_36

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "invokeExitMethods: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "StateMachine"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 518
    :cond_36
    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->exit()V

    .line 519
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v1, v1, v2

    const/4 v2, 0x0

    iput-boolean v2, v1, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->active:Z

    .line 520
    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    .line 521
    .end local v0    # "curState":Lcom/android/server/hans/states/State;
    goto :goto_1

    .line 522
    :cond_49
    return-void
.end method

.method private final isDbg()Z
    .registers 2

    .line 740
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    return v0
.end method

.method private final isQuit(Landroid/os/Message;)Z
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .line 735
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_d

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    sget-object v1, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuitObj:Ljava/lang/Object;

    if-ne v0, v1, :cond_d

    const/4 v0, 0x1

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    return v0
.end method

.method private final moveDeferredMessageAtFrontOfQueue()V
    .registers 5

    .line 545
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .local v0, "i":I
    :goto_8
    if-ltz v0, :cond_37

    .line 546
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Message;

    .line 547
    .local v1, "curMsg":Landroid/os/Message;
    iget-boolean v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v2, :cond_31

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "moveDeferredMessageAtFrontOfQueue; what="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v1, Landroid/os/Message;->what:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "StateMachine"

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 548
    :cond_31
    invoke-virtual {p0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    .line 545
    .end local v1    # "curMsg":Landroid/os/Message;
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    .line 550
    .end local v0    # "i":I
    :cond_37
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDeferredMessages:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 551
    return-void
.end method

.method private final moveTempStateStackToStateStack()I
    .registers 8

    .line 561
    iget v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    add-int/lit8 v0, v0, 0x1

    .line 562
    .local v0, "startingIndex":I
    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    add-int/lit8 v1, v1, -0x1

    .line 563
    .local v1, "i":I
    move v2, v0

    .line 564
    .local v2, "j":I
    :goto_9
    const-string v3, "StateMachine"

    if-ltz v1, :cond_3f

    .line 565
    iget-boolean v4, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v4, :cond_32

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "moveTempStackToStateStack: i="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ",j="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 566
    :cond_32
    iget-object v3, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget-object v4, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    aget-object v4, v4, v1

    aput-object v4, v3, v2

    .line 567
    add-int/lit8 v2, v2, 0x1

    .line 568
    add-int/lit8 v1, v1, -0x1

    goto :goto_9

    .line 571
    :cond_3f
    add-int/lit8 v4, v2, -0x1

    iput v4, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    .line 572
    iget-boolean v4, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v4, :cond_80

    .line 573
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "moveTempStackToStateStack: X mStateStackTop="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v5, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ",startingIndex="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ",Top="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v6, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v5, v5, v6

    iget-object v5, v5, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    .line 575
    invoke-virtual {v5}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 573
    invoke-static {v3, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 577
    :cond_80
    return v0
.end method

.method private performTransitions()V
    .registers 4

    .line 354
    const/4 v0, 0x0

    .line 355
    .local v0, "destState":Lcom/android/server/hans/states/State;
    :goto_1
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    if-eqz v1, :cond_28

    .line 356
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v1, :cond_11

    const-string v1, "StateMachine"

    const-string/jumbo v2, "handleMessage: new destination call exit"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 362
    :cond_11
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    .line 363
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    .line 370
    invoke-direct {p0, v0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->setupTempStateStackWithStatesToEnter(Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    move-result-object v1

    .line 372
    .local v1, "commonStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    invoke-direct {p0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->invokeExitMethods(Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;)V

    .line 373
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->moveTempStateStackToStateStack()I

    move-result v2

    .line 374
    .local v2, "stateStackEnteringIndex":I
    invoke-direct {p0, v2}, Lcom/android/server/hans/states/StateMachine$SmHandler;->invokeEnterMethods(I)V

    .line 383
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->moveDeferredMessageAtFrontOfQueue()V

    .line 384
    .end local v1    # "commonStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    .end local v2    # "stateStackEnteringIndex":I
    goto :goto_1

    .line 390
    :cond_28
    if-eqz v0, :cond_3b

    .line 391
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuittingState:Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

    if-ne v0, v1, :cond_32

    .line 392
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->cleanupAfterQuitting()V

    goto :goto_3b

    .line 394
    :cond_32
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mHaltingState:Lcom/android/server/hans/states/StateMachine$SmHandler$HaltingState;

    if-ne v0, v1, :cond_3b

    .line 400
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-virtual {v1}, Lcom/android/server/hans/states/StateMachine;->halting()V

    .line 403
    :cond_3b
    :goto_3b
    return-void
.end method

.method private final processMsg(Landroid/os/Message;)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;

    .line 474
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v0, v0, v1

    .line 475
    .local v0, "curStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    const-string/jumbo v2, "processMsg: "

    const-string v3, "StateMachine"

    if-eqz v1, :cond_29

    .line 476
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v4}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 478
    :cond_29
    :goto_29
    iget-object v1, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v1, p1}, Lcom/android/server/hans/states/State;->processMessage(Landroid/os/Message;)Z

    move-result v1

    if-nez v1, :cond_65

    .line 482
    iget-object v0, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 483
    if-nez v0, :cond_46

    .line 487
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mSm:Lcom/android/server/hans/states/StateMachine;

    invoke-virtual {v1, p1}, Lcom/android/server/hans/states/StateMachine;->unhandledMessage(Landroid/os/Message;)V

    .line 488
    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->isQuit(Landroid/os/Message;)Z

    move-result v1

    if-eqz v1, :cond_65

    .line 489
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuittingState:Lcom/android/server/hans/states/StateMachine$SmHandler$QuittingState;

    invoke-direct {p0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->transitionTo(Lcom/android/server/hans/states/IState;)V

    goto :goto_65

    .line 493
    :cond_46
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v1, :cond_29

    .line 494
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v4}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_29

    .line 501
    :cond_65
    :goto_65
    if-eqz v0, :cond_77

    .line 502
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    aget-object v1, v1, v2

    iget-object v1, v1, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    .line 503
    .local v1, "orgState":Lcom/android/server/hans/states/State;
    iget-object v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    iget-object v3, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->state:Lcom/android/server/hans/states/State;

    invoke-virtual {v2, p1, v3, v1}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->add(Landroid/os/Message;Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)V

    .line 504
    .end local v1    # "orgState":Lcom/android/server/hans/states/State;
    goto :goto_7d

    .line 505
    :cond_77
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2, v2}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->add(Landroid/os/Message;Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)V

    .line 507
    :goto_7d
    return-void
.end method

.method private final quit()V
    .registers 3

    .line 729
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_c

    const-string v0, "StateMachine"

    const-string/jumbo v1, "quit:"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 730
    :cond_c
    const/4 v0, -0x1

    sget-object v1, Lcom/android/server/hans/states/StateMachine$SmHandler;->mQuitObj:Ljava/lang/Object;

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->sendMessage(Landroid/os/Message;)Z

    .line 731
    return-void
.end method

.method private final setDbg(Z)V
    .registers 2
    .param p1, "dbg"    # Z

    .line 745
    iput-boolean p1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    .line 746
    return-void
.end method

.method private final setInitialState(Lcom/android/server/hans/states/State;)V
    .registers 4
    .param p1, "initialState"    # Lcom/android/server/hans/states/State;

    .line 706
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_21

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setInitialState: initialState"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "StateMachine"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 707
    :cond_21
    iput-object p1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mInitialState:Lcom/android/server/hans/states/State;

    .line 708
    return-void
.end method

.method private final setProcessedMessagesSize(I)V
    .registers 3
    .param p1, "maxSize"    # I

    .line 750
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mProcessedMessages:Lcom/android/server/hans/states/StateMachine$ProcessedMessages;

    invoke-virtual {v0, p1}, Lcom/android/server/hans/states/StateMachine$ProcessedMessages;->setSize(I)V

    .line 751
    return-void
.end method

.method private final setupInitialStateStack()V
    .registers 4

    .line 626
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_23

    .line 627
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setupInitialStateStack: E mInitialState="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mInitialState:Lcom/android/server/hans/states/State;

    .line 628
    invoke-virtual {v1}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 627
    const-string v1, "StateMachine"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 631
    :cond_23
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mInitialState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 632
    .local v0, "curStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    const/4 v1, 0x0

    :goto_2e
    iput v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    if-eqz v0, :cond_3f

    .line 633
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    aput-object v0, v1, v2

    .line 634
    iget-object v0, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 632
    iget v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    add-int/lit8 v1, v1, 0x1

    goto :goto_2e

    .line 638
    :cond_3f
    const/4 v1, -0x1

    iput v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateStackTopIndex:I

    .line 640
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->moveTempStateStackToStateStack()I

    .line 641
    return-void
.end method

.method private final setupTempStateStackWithStatesToEnter(Lcom/android/server/hans/states/State;)Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    .registers 6
    .param p1, "destState"    # Lcom/android/server/hans/states/State;

    .line 598
    const/4 v0, 0x0

    iput v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    .line 599
    iget-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mStateInfo:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    .line 610
    .local v0, "curStateInfo":Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;
    :goto_b
    if-eqz v0, :cond_1e

    iget-boolean v1, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->active:Z

    if-nez v1, :cond_1e

    .line 611
    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStack:[Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    iget v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    aput-object v0, v1, v2

    .line 612
    iget-object v0, v0, Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;->parentStateInfo:Lcom/android/server/hans/states/StateMachine$SmHandler$StateInfo;

    goto :goto_b

    .line 615
    :cond_1e
    iget-boolean v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v1, :cond_47

    .line 616
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setupTempStateStackWithStatesToEnter: X mTempStateStackCount="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mTempStateStackCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",curStateInfo: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "StateMachine"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 619
    :cond_47
    return-object v0
.end method

.method private final transitionTo(Lcom/android/server/hans/states/IState;)V
    .registers 4
    .param p1, "destState"    # Lcom/android/server/hans/states/IState;

    .line 712
    move-object v0, p1

    check-cast v0, Lcom/android/server/hans/states/State;

    iput-object v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    .line 713
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_27

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "StateMachine.transitionTo EX destState"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDestState:Lcom/android/server/hans/states/State;

    invoke-virtual {v1}, Lcom/android/server/hans/states/State;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "StateMachine"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 714
    :cond_27
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;

    .line 325
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    const-string v1, "StateMachine"

    if-eqz v0, :cond_1f

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "handleMessage: E msg.what="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 330
    :cond_1f
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mIsConstructionCompleted:Z

    if-nez v0, :cond_3a

    .line 331
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "The start method not called, ignore msg: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 332
    return-void

    .line 339
    :cond_3a
    invoke-direct {p0, p1}, Lcom/android/server/hans/states/StateMachine$SmHandler;->processMsg(Landroid/os/Message;)V

    .line 340
    invoke-direct {p0}, Lcom/android/server/hans/states/StateMachine$SmHandler;->performTransitions()V

    .line 342
    iget-boolean v0, p0, Lcom/android/server/hans/states/StateMachine$SmHandler;->mDbg:Z

    if-eqz v0, :cond_4a

    const-string/jumbo v0, "handleMessage: X"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 343
    :cond_4a
    return-void
.end method
