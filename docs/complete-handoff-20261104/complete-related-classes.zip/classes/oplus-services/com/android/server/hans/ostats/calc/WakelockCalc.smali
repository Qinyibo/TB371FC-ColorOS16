.class public Lcom/android/server/hans/ostats/calc/WakelockCalc;
.super Ljava/lang/Object;
.source "WakelockCalc.java"

# interfaces
.implements Lcom/android/server/hans/ostats/calc/Calc;


# static fields
.field public static final MAX_POWER:D = 9.223372036854776E18

.field private static volatile sInstance:Lcom/android/server/hans/ostats/calc/WakelockCalc;


# instance fields
.field private WAKELOCK_WEIGHT:D


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    const-wide/high16 v0, 0x402e000000000000L    # 15.0

    iput-wide v0, p0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->WAKELOCK_WEIGHT:D

    return-void
.end method

.method public static getInstance()Lcom/android/server/hans/ostats/calc/WakelockCalc;
    .registers 2

    .line 20
    sget-object v0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->sInstance:Lcom/android/server/hans/ostats/calc/WakelockCalc;

    if-nez v0, :cond_17

    .line 21
    const-class v0, Lcom/android/server/hans/ostats/calc/WakelockCalc;

    monitor-enter v0

    .line 22
    :try_start_7
    sget-object v1, Lcom/android/server/hans/ostats/calc/WakelockCalc;->sInstance:Lcom/android/server/hans/ostats/calc/WakelockCalc;

    if-nez v1, :cond_12

    .line 23
    new-instance v1, Lcom/android/server/hans/ostats/calc/WakelockCalc;

    invoke-direct {v1}, Lcom/android/server/hans/ostats/calc/WakelockCalc;-><init>()V

    sput-object v1, Lcom/android/server/hans/ostats/calc/WakelockCalc;->sInstance:Lcom/android/server/hans/ostats/calc/WakelockCalc;

    .line 25
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 27
    :cond_17
    :goto_17
    sget-object v0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->sInstance:Lcom/android/server/hans/ostats/calc/WakelockCalc;

    return-object v0
.end method

.method private noteWakeLockStart(I)V
    .registers 7
    .param p1, "uid"    # I

    .line 74
    const/16 v0, 0x2710

    if-ge p1, v0, :cond_5

    .line 75
    return-void

    .line 77
    :cond_5
    invoke-static {}, Lcom/android/server/hans/ostats/OplusBatteryStatsManager;->getInstance()Lcom/android/server/hans/ostats/OplusBatteryStatsManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/ostats/OplusBatteryStatsManager;->getUidState(I)Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;

    move-result-object v0

    .line 78
    .local v0, "uidState":Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;
    const-string v1, "Calc"

    if-eqz v0, :cond_61

    iget-boolean v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mMultiPkg:Z

    if-eqz v2, :cond_16

    goto :goto_61

    .line 82
    :cond_16
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    if-nez v2, :cond_25

    .line 83
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    new-instance v3, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    invoke-direct {v3}, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;-><init>()V

    iput-object v3, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    .line 85
    :cond_25
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v2, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    if-nez v2, :cond_38

    .line 86
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    new-instance v3, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    invoke-direct {v3}, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;-><init>()V

    iput-object v3, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    .line 88
    :cond_38
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v2, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;->start(J)V

    .line 89
    invoke-static {}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->getInstance()Lcom/android/server/hans/ostats/utils/OStatsLogger;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "noteWakeLockStart uid = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    return-void

    .line 79
    :cond_61
    :goto_61
    invoke-static {}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->getInstance()Lcom/android/server/hans/ostats/utils/OStatsLogger;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "noteWakeLockStart no match uid = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    return-void
.end method

.method private noteWakeLockStop(I)V
    .registers 7
    .param p1, "uid"    # I

    .line 93
    const/16 v0, 0x2710

    if-ge p1, v0, :cond_5

    .line 94
    return-void

    .line 96
    :cond_5
    invoke-static {}, Lcom/android/server/hans/ostats/OplusBatteryStatsManager;->getInstance()Lcom/android/server/hans/ostats/OplusBatteryStatsManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/server/hans/ostats/OplusBatteryStatsManager;->getUidStateOrNull(I)Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;

    move-result-object v0

    .line 97
    .local v0, "uidState":Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;
    const-string v1, "Calc"

    if-eqz v0, :cond_32

    iget-boolean v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mMultiPkg:Z

    if-eqz v2, :cond_16

    goto :goto_32

    .line 99
    :cond_16
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    if-eqz v2, :cond_4d

    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v2, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    if-eqz v2, :cond_4d

    .line 100
    iget-object v2, v0, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$UidState;->mCurPkg:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;

    iget-object v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v2, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;->stop(J)V

    goto :goto_4d

    .line 98
    :cond_32
    :goto_32
    invoke-static {}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->getInstance()Lcom/android/server/hans/ostats/utils/OStatsLogger;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "noteWakeLockStop no match uid = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    :cond_4d
    :goto_4d
    invoke-static {}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->getInstance()Lcom/android/server/hans/ostats/utils/OStatsLogger;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "noteWakeLockStop uid = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lcom/android/server/hans/ostats/utils/OStatsLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 103
    return-void
.end method


# virtual methods
.method public calc(Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;JJJ)V
    .registers 13
    .param p1, "pkgState"    # Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;
    .param p2, "curTime"    # J
    .param p4, "upTime"    # J
    .param p6, "period"    # J

    .line 37
    iget-object v0, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    if-eqz v0, :cond_48

    iget-object v0, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v0, v0, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    if-eqz v0, :cond_48

    .line 38
    iget-object v0, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v0, v0, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    iget-wide v1, p0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->WAKELOCK_WEIGHT:D

    invoke-virtual {v0, p2, p3, v1, v2}, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;->readDeltaPower(JD)D

    move-result-wide v0

    .line 39
    .local v0, "power":D
    const-wide/16 v2, 0x0

    cmpl-double v2, v0, v2

    if-lez v2, :cond_48

    .line 40
    const-wide/high16 v2, 0x43e0000000000000L    # 9.223372036854776E18

    cmpl-double v2, v0, v2

    if-lez v2, :cond_29

    .line 41
    const-wide/high16 v0, 0x43e0000000000000L    # 9.223372036854776E18

    .line 42
    iget-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevData:Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;

    iget-object v2, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevData;->mWakelockWatch:Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;

    invoke-virtual {v2, p2, p3}, Lcom/android/server/hans/ostats/utils/PowerUtils$StopWatchPower;->stop(J)V

    .line 44
    :cond_29
    iget-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevPower:Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;

    if-nez v2, :cond_34

    .line 45
    new-instance v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;

    invoke-direct {v2}, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;-><init>()V

    iput-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevPower:Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;

    .line 47
    :cond_34
    iget-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevPower:Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;

    iget-wide v3, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;->mWakelockPower:D

    add-double/2addr v3, v0

    iput-wide v3, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;->mWakelockPower:D

    .line 48
    iget-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mStateTime:Lcom/android/server/hans/ostats/OplusBatteryStatsManager$StateTime;

    iget-boolean v2, v2, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$StateTime;->mIsFg:Z

    if-eqz v2, :cond_48

    .line 49
    iget-object v2, p1, Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;->mDevPower:Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;

    iget-wide v3, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;->mForePower:D

    add-double/2addr v3, v0

    iput-wide v3, v2, Lcom/android/server/hans/ostats/utils/PowerUtils$DevPower;->mForePower:D

    .line 53
    .end local v0    # "power":D
    :cond_48
    return-void
.end method

.method public calc(Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;JJZ)V
    .registers 15
    .param p1, "pkgState"    # Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;
    .param p2, "curTime"    # J
    .param p4, "upTime"    # J
    .param p6, "change"    # Z

    .line 32
    const-wide/16 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-wide v2, p2

    move-wide v4, p4

    .end local p1    # "pkgState":Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;
    .end local p2    # "curTime":J
    .end local p4    # "upTime":J
    .local v1, "pkgState":Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;
    .local v2, "curTime":J
    .local v4, "upTime":J
    invoke-virtual/range {v0 .. v7}, Lcom/android/server/hans/ostats/calc/WakelockCalc;->calc(Lcom/android/server/hans/ostats/OplusBatteryStatsManager$PkgState;JJJ)V

    .line 33
    return-void
.end method

.method public dump()Ljava/lang/String;
    .registers 4

    .line 62
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "WAKELOCK_WEIGHT = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->WAKELOCK_WEIGHT:D

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public init(JJLcom/android/internal/os/PowerProfile;)V
    .registers 8
    .param p1, "curTime"    # J
    .param p3, "upTime"    # J
    .param p5, "powerProfile"    # Lcom/android/internal/os/PowerProfile;

    .line 57
    const-string v0, "cpu.idle"

    invoke-virtual {p5, v0}, Lcom/android/internal/os/PowerProfile;->getAveragePower(Ljava/lang/String;)D

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/hans/ostats/calc/WakelockCalc;->WAKELOCK_WEIGHT:D

    .line 58
    return-void
.end method

.method public noteWakeLock(IILjava/lang/String;Ljava/lang/String;IZ)V
    .registers 7
    .param p1, "uid"    # I
    .param p2, "pid"    # I
    .param p3, "name"    # Ljava/lang/String;
    .param p4, "historyName"    # Ljava/lang/String;
    .param p5, "type"    # I
    .param p6, "start"    # Z

    .line 66
    if-eqz p6, :cond_6

    .line 67
    invoke-direct {p0, p1}, Lcom/android/server/hans/ostats/calc/WakelockCalc;->noteWakeLockStart(I)V

    goto :goto_9

    .line 69
    :cond_6
    invoke-direct {p0, p1}, Lcom/android/server/hans/ostats/calc/WakelockCalc;->noteWakeLockStop(I)V

    .line 71
    :goto_9
    return-void
.end method
