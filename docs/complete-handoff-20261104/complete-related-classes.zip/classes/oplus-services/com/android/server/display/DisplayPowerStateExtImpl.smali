.class public Lcom/android/server/display/DisplayPowerStateExtImpl;
.super Ljava/lang/Object;
.source "DisplayPowerStateExtImpl.java"

# interfaces
.implements Lcom/android/server/display/IDisplayPowerStateExt;
.implements Lcom/android/server/display/util/BrightnessThermal$ThermalListener;


# static fields
.field private static final SCREEN_BRIGHTNESS:Landroid/util/IntProperty;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/IntProperty<",
            "Lcom/android/server/display/DisplayPowerState;",
            ">;"
        }
    .end annotation
.end field

.field private static final TAG:Ljava/lang/String; = "DisplayPowerStateExtImpl"


# instance fields
.field private mDps:Lcom/android/server/display/DisplayPowerState;

.field private mIsAodStatus:Z

.field private mTemperaturePair:Landroid/util/Pair;

.field private mThermal:Lcom/android/server/display/util/BrightnessThermal;

.field private mUseUx:Z

.field private mUxTemperatureLimit:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 35
    new-instance v0, Lcom/android/server/display/DisplayPowerStateExtImpl$1;

    const-string/jumbo v1, "screenBrightness"

    invoke-direct {v0, v1}, Lcom/android/server/display/DisplayPowerStateExtImpl$1;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/server/display/DisplayPowerStateExtImpl;->SCREEN_BRIGHTNESS:Landroid/util/IntProperty;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 5
    .param p1, "base"    # Ljava/lang/Object;

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 47
    const/4 v0, 0x0

    .line 52
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 47
    iput-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mIsAodStatus:Z

    .line 49
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mThermal:Lcom/android/server/display/util/BrightnessThermal;

    .line 50
    const/16 v2, 0x258

    iput v2, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUxTemperatureLimit:I

    .line 51
    iput-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUseUx:Z

    .line 52
    new-instance v0, Landroid/util/Pair;

    invoke-direct {v0, v1, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mTemperaturePair:Landroid/util/Pair;

    .line 55
    move-object v0, p1

    check-cast v0, Lcom/android/server/display/DisplayPowerState;

    iput-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mDps:Lcom/android/server/display/DisplayPowerState;

    .line 56
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isSupportAnimationUX()Z

    move-result v0

    if-eqz v0, :cond_35

    .line 57
    new-instance v0, Lcom/android/server/display/util/BrightnessThermal;

    invoke-direct {v0}, Lcom/android/server/display/util/BrightnessThermal;-><init>()V

    iput-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mThermal:Lcom/android/server/display/util/BrightnessThermal;

    .line 58
    iget-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mThermal:Lcom/android/server/display/util/BrightnessThermal;

    invoke-virtual {v0, p0}, Lcom/android/server/display/util/BrightnessThermal;->register(Lcom/android/server/display/util/BrightnessThermal$ThermalListener;)V

    .line 60
    :cond_35
    return-void
.end method

.method public static getScreenBrightness()Landroid/util/IntProperty;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/IntProperty<",
            "Lcom/android/server/display/DisplayPowerState;",
            ">;"
        }
    .end annotation

    .line 63
    sget-object v0, Lcom/android/server/display/DisplayPowerStateExtImpl;->SCREEN_BRIGHTNESS:Landroid/util/IntProperty;

    return-object v0
.end method

.method private useUx4Brightness()Z
    .registers 2

    .line 95
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isSupportAnimationUX()Z

    move-result v0

    if-nez v0, :cond_c

    .line 96
    const/4 v0, 0x0

    return v0

    .line 98
    :cond_c
    iget-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUseUx:Z

    return v0
.end method


# virtual methods
.method public getAodStatus()Z
    .registers 2

    .line 83
    iget-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mIsAodStatus:Z

    return v0
.end method

.method public notifyThermalStatus(II)V
    .registers 6
    .param p1, "status"    # I
    .param p2, "temperature"    # I

    .line 103
    iput p2, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUxTemperatureLimit:I

    .line 104
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getAnimationUX()I

    move-result v0

    .line 105
    .local v0, "nAnimationUX":I
    iget v1, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUxTemperatureLimit:I

    if-le v1, v0, :cond_12

    .line 106
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUseUx:Z

    goto :goto_15

    .line 108
    :cond_12
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUseUx:Z

    .line 110
    :goto_15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v1

    iput-object v1, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mTemperaturePair:Landroid/util/Pair;

    .line 111
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "notifyThermalStatus status="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " temp="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " uxTemp="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " ux="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mUseUx:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "DisplayPowerStateExtImpl"

    invoke-static {v2, v1}, Lcom/android/server/display/feature/ambience/utils/AmbienceLog;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    return-void
.end method

.method public setAodStatus(Z)V
    .registers 4
    .param p1, "isAod"    # Z

    .line 68
    iget-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mIsAodStatus:Z

    if-eq v0, p1, :cond_42

    .line 69
    iget-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mDps:Lcom/android/server/display/DisplayPowerState;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerState;->getWrapper()Lcom/android/server/display/IDisplayPowerStateWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerStateWrapper;->getDebug()Z

    move-result v0

    if-eqz v0, :cond_29

    .line 70
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setAodStatus: isAod="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "DisplayPowerStateExtImpl"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 72
    :cond_29
    iput-boolean p1, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mIsAodStatus:Z

    .line 73
    iget-boolean v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mIsAodStatus:Z

    if-eqz v0, :cond_42

    .line 74
    iget-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mDps:Lcom/android/server/display/DisplayPowerState;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerState;->getWrapper()Lcom/android/server/display/IDisplayPowerStateWrapper;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lcom/android/server/display/IDisplayPowerStateWrapper;->setScreenReady(Z)V

    .line 76
    iget-object v0, p0, Lcom/android/server/display/DisplayPowerStateExtImpl;->mDps:Lcom/android/server/display/DisplayPowerState;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerState;->getWrapper()Lcom/android/server/display/IDisplayPowerStateWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerStateWrapper;->scheduleScreenUpdate()V

    .line 79
    :cond_42
    return-void
.end method

.method public setDisplayThreadSched(II)V
    .registers 5
    .param p1, "tid"    # I
    .param p2, "prio"    # I

    .line 89
    invoke-static {p1, p2}, Landroid/os/Process;->setThreadPriority(II)V

    .line 90
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "set DisplayThread tid="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " sched prio="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "DisplayPowerStateExtImpl"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    return-void
.end method

.method public setUxThread()V
    .registers 4

    .line 117
    invoke-static {}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->getInstance()Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/config/global/OplusDisplayGlobalConfig;->isSupportBrightnessThreadPriority()Z

    move-result v0

    if-eqz v0, :cond_13

    .line 118
    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v0

    const/16 v1, -0xf

    invoke-static {v0, v1}, Landroid/os/Process;->setThreadPriority(II)V

    .line 121
    :cond_13
    invoke-direct {p0}, Lcom/android/server/display/DisplayPowerStateExtImpl;->useUx4Brightness()Z

    move-result v0

    if-nez v0, :cond_1a

    .line 122
    return-void

    .line 125
    :cond_1a
    const/16 v0, 0x82

    .line 126
    .local v0, "value":I
    invoke-static {v0}, Lcom/android/server/display/util/OplusBrightnessUtils;->setUxThreadValueByFile(I)Z

    .line 127
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "setUx:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "->"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "DisplayPowerStateExtImpl"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 128
    return-void
.end method
