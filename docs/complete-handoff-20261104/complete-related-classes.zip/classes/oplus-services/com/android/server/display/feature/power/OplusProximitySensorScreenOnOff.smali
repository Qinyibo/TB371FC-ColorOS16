.class public final Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
.super Ljava/lang/Object;
.source "OplusProximitySensorScreenOnOff.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;,
        Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;,
        Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;
    }
.end annotation


# static fields
.field private static final COVER_MODE_CLOSED:Ljava/lang/String; = "closed"

.field private static final COVER_MODE_OPEN:Ljava/lang/String; = "open"

.field private static final COVER_MODE_STATE_CLOSED:I = 0x1

.field private static final COVER_MODE_STATE_OPEN:I = 0x0

.field private static final COVER_MODE_STATE_UNKNOWN:I = -0x1

.field private static final COVER_MODE_UNKNOWN:Ljava/lang/String; = "unknown"

.field private static final OPLUS_PSENSOR_LIST:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final PROXIMITY_NEGATIVE:I = 0x0

.field private static final PROXIMITY_POSITIVE:I = 0x1

.field private static final PROXIMITY_UNKNOWN:I = -0x1

.field private static final SCREEN_STATE_OFF:Ljava/lang/String; = "screen_state_off"

.field private static final TAG:Ljava/lang/String; = "OplusProximitySensorScreenOnOff"

.field private static final THEIA_APP_ID:I = 0x4e98

.field private static final THEIA_EVENT_ID:Ljava/lang/String; = "Theia"

.field private static final THEIA_IDENTIFIER_ID:Ljava/lang/String; = "pSensorScreenoff"

.field private static final THEIA_LOG_TAG:Ljava/lang/String; = "CriticalLog"

.field private static final TIMEOUT_SCREEN_ON_CPU_BOOST:I = 0x1f4

.field private static final TYPE_OPLUS_POCKET_SENSOR:I = 0x1fa2683

.field private static final TYPE_OPLUS_PSENSOR_QCOM:I = 0x1fa267b

.field private static final WAKELOCK_CUSTOM_NEGATIVE:I = 0x65

.field private static final WAKELOCK_CUSTOM_POSITIVE:I = 0x64

.field private static sFeatureKeepGameScreenOnSupport:Z

.field private static sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;


# instance fields
.field private mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

.field private mContext:Landroid/content/Context;

.field private mCoverExcutor:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;

.field private mCoverModeState:I

.field private mCoverStateCallback:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;

.field private mCurrentProximity:I

.field private mCurrentProximityEnable:Z

.field private mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

.field private mDpcHandler:Landroid/os/Handler;

.field private mHandler:Landroid/os/Handler;

.field private mIsPositiveForceSuspend:Z

.field private mIsScreenOffByProximityPositive:Z

.field private mLastUseProximityForceSuspend:Z

.field private final mOnProximityNegativeSuspendRunnable:Ljava/lang/Runnable;

.field private final mOnProximityPositiveSuspendRunnable:Ljava/lang/Runnable;

.field private mOplusDebug:Z

.field private mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

.field private mPMS:Lcom/android/server/power/PowerManagerService;

.field private mPendingPocketProxEnable:Z

.field private mPocketEnableLock:Ljava/lang/Object;

.field private mPocketProxEnable:Z

.field private final mPocketProxEnableTokens:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;",
            ">;"
        }
    .end annotation
.end field

.field private mPocketSensor:Landroid/hardware/Sensor;

.field private mProximityEventHandled:Z

.field private final mProximityNegativeResetRunnable:Ljava/lang/Runnable;

.field private mPsensor:Landroid/hardware/Sensor;

.field private mScreenOnCpuBoostHelper:Lcom/android/server/oplus/ScreenOnCpuBoostHelper;

.field private mSensorListener:Landroid/hardware/SensorEventListener;

.field private mSensorManager:Landroid/hardware/SensorManager;

.field private mSuspendBlockerIdProxNegative:Ljava/lang/String;

.field private mSuspendBlockerIdProxPositive:Ljava/lang/String;

.field private mTempPocketEnable:Z

.field private mUseProximityForceSuspend:Z


# direct methods
.method static bridge synthetic -$$Nest$fgetmContext(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I
    .registers 1

    iget p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmCurrentProximity(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)I
    .registers 1

    iget p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximity:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmCurrentProximityEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximityEnable:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmDisplayPowerController(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/display/DisplayPowerController;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmOplusDebug(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmPMS(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Lcom/android/server/power/PowerManagerService;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmPocketEnableLock(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmPocketProxEnableTokens(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)Ljava/util/List;
    .registers 1

    iget-object p0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputmCoverModeState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;I)V
    .registers 2

    iput p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmIsPositiveForceSuspend(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsPositiveForceSuspend:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmPendingPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPendingPocketProxEnable:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmPocketProxEnable(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$mchangeSensor(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->changeSensor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mfindIndexPocketToken(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Landroid/os/IBinder;)I
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->findIndexPocketToken(Landroid/os/IBinder;)I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mformatCoverState(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;I)Ljava/lang/String;
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->formatCoverState(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mproximityNegativeReset(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->proximityNegativeReset()V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 79
    new-instance v0, Ljava/util/ArrayList;

    .line 80
    const v1, 0x1fa267b

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Integer;

    move-result-object v1

    .line 79
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sput-object v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->OPLUS_PSENSOR_LIST:Ljava/util/ArrayList;

    .line 85
    const/4 v0, 0x0

    sput-boolean v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sFeatureKeepGameScreenOnSupport:Z

    .line 87
    const/4 v0, 0x0

    sput-object v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Lcom/android/server/display/DisplayPowerController;Landroid/os/Handler;)V
    .registers 9
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "dpc"    # Lcom/android/server/display/DisplayPowerController;
    .param p3, "handler"    # Landroid/os/Handler;

    .line 135
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 89
    new-instance v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$1;

    invoke-direct {v0, p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$1;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    iput-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityNegativeResetRunnable:Ljava/lang/Runnable;

    .line 102
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    .line 104
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsScreenOffByProximityPositive:Z

    .line 105
    const-string/jumbo v1, "persist.sys.assert.panic"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    .line 106
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    .line 107
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsPositiveForceSuspend:Z

    .line 109
    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    .line 110
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    .line 111
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mTempPocketEnable:Z

    .line 112
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximityEnable:Z

    .line 113
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPendingPocketProxEnable:Z

    .line 114
    const/4 v1, -0x1

    iput v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    .line 115
    iput v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximity:I

    .line 125
    const-string v1, "[0]custom prox positive"

    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSuspendBlockerIdProxPositive:Ljava/lang/String;

    .line 126
    const-string v1, "[0]custom prox negative"

    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSuspendBlockerIdProxNegative:Ljava/lang/String;

    .line 127
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    .line 128
    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPsensor:Landroid/hardware/Sensor;

    .line 129
    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    .line 130
    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    .line 131
    new-instance v2, Ljava/lang/Object;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    .line 674
    new-instance v2, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;

    invoke-direct {v2, p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$2;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    iput-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOnProximityPositiveSuspendRunnable:Ljava/lang/Runnable;

    .line 699
    new-instance v2, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;

    invoke-direct {v2, p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$3;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;)V

    iput-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOnProximityNegativeSuspendRunnable:Ljava/lang/Runnable;

    .line 136
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    .line 137
    iput-object p2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    .line 138
    new-instance v2, Lcom/android/server/oplus/ScreenOnCpuBoostHelper;

    invoke-direct {v2}, Lcom/android/server/oplus/ScreenOnCpuBoostHelper;-><init>()V

    iput-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mScreenOnCpuBoostHelper:Lcom/android/server/oplus/ScreenOnCpuBoostHelper;

    .line 139
    invoke-static {}, Lcom/android/server/power/PowerManagerThread;->get()Lcom/android/server/power/PowerManagerThread;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/power/PowerManagerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    .line 140
    .local v2, "looper":Landroid/os/Looper;
    new-instance v3, Landroid/os/Handler;

    invoke-direct {v3, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mHandler:Landroid/os/Handler;

    .line 141
    new-instance v3, Landroid/os/Handler;

    invoke-virtual {p3}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDpcHandler:Landroid/os/Handler;

    .line 142
    new-instance v3, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDpcHandler:Landroid/os/Handler;

    invoke-direct {v3, v4}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;-><init>(Landroid/os/Handler;)V

    iput-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverExcutor:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;

    .line 143
    new-instance v3, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;

    invoke-direct {v3, p0, v1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff-IA;)V

    iput-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverStateCallback:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;

    .line 144
    invoke-static {}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->getInstance()Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    move-result-object v1

    iput-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    .line 145
    sget-object v1, Lcom/android/server/content/IOplusFeatureConfigManagerInternal;->DEFAULT:Lcom/android/server/content/IOplusFeatureConfigManagerInternal;

    new-array v0, v0, [Ljava/lang/Object;

    invoke-static {v1, v0}, Landroid/common/OplusFeatureCache;->getOrCreate(Landroid/common/IOplusCommonFeature;[Ljava/lang/Object;)Landroid/common/IOplusCommonFeature;

    move-result-object v0

    check-cast v0, Lcom/android/server/content/IOplusFeatureConfigManagerInternal;

    .line 146
    const-string/jumbo v1, "oplus.software.game.keep_screen_on_during_call"

    invoke-interface {v0, v1}, Lcom/android/server/content/IOplusFeatureConfigManagerInternal;->hasFeature(Ljava/lang/String;)Z

    move-result v0

    sput-boolean v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sFeatureKeepGameScreenOnSupport:Z

    .line 148
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string v1, "OplusProximitySensorScreenOnOff "

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 149
    return-void
.end method

.method private changeSensor()V
    .registers 6

    .line 578
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    if-nez v0, :cond_b

    .line 579
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string v1, "change fail there no pocket sensor"

    invoke-static {v0, v1}, Landroid/util/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 581
    :cond_b
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    .line 582
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    const/4 v1, 0x3

    if-eqz v0, :cond_23

    .line 583
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDpcHandler:Landroid/os/Handler;

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    goto :goto_2e

    .line 585
    :cond_23
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPsensor:Landroid/hardware/Sensor;

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDpcHandler:Landroid/os/Handler;

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    .line 587
    :goto_2e
    return-void
.end method

.method private findIndexPocketToken(Landroid/os/IBinder;)I
    .registers 5
    .param p1, "token"    # Landroid/os/IBinder;

    .line 631
    const/4 v0, -0x1

    .line 632
    .local v0, "index":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_2
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1b

    .line 633
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;

    iget-object v2, v2, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->mToken:Landroid/os/IBinder;

    if-ne v2, p1, :cond_18

    .line 634
    move v0, v1

    .line 635
    goto :goto_1b

    .line 632
    :cond_18
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 638
    .end local v1    # "i":I
    :cond_1b
    :goto_1b
    return v0
.end method

.method private findPocketSensor(Landroid/hardware/SensorManager;)V
    .registers 7
    .param p1, "sensorManager"    # Landroid/hardware/SensorManager;

    .line 514
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    if-eqz v0, :cond_5

    .line 515
    return-void

    .line 517
    :cond_5
    const v0, 0x1fa2683

    invoke-virtual {p1, v0}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    move-result-object v1

    .line 518
    .local v1, "sensors":Ljava/util/List;, "Ljava/util/List<Landroid/hardware/Sensor;>;"
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    if-nez v2, :cond_1b

    .line 519
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "findPocketSensor: not find: 33171075"

    invoke-static {v0, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 520
    return-void

    .line 522
    :cond_1b
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_35

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/hardware/Sensor;

    .line 523
    .local v3, "sensor":Landroid/hardware/Sensor;
    invoke-virtual {v3}, Landroid/hardware/Sensor;->getType()I

    move-result v4

    if-ne v0, v4, :cond_34

    .line 524
    iput-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    .line 525
    goto :goto_35

    .line 527
    .end local v3    # "sensor":Landroid/hardware/Sensor;
    :cond_34
    goto :goto_1f

    .line 528
    :cond_35
    :goto_35
    return-void
.end method

.method private formatCoverState(I)Ljava/lang/String;
    .registers 4
    .param p1, "state"    # I

    .line 427
    packed-switch p1, :pswitch_data_24

    .line 434
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "unknown:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 429
    :pswitch_1c
    const-string v0, "closed"

    return-object v0

    .line 431
    :pswitch_1f
    const-string/jumbo v0, "open"

    return-object v0

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1f
        :pswitch_1c
    .end packed-switch
.end method

.method public static getInstance()Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
    .registers 2

    .line 152
    const-class v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    monitor-enter v0

    .line 153
    :try_start_3
    sget-object v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    monitor-exit v0

    return-object v1

    .line 154
    :catchall_7
    move-exception v1

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public static getInstance(Landroid/content/Context;Lcom/android/server/display/DisplayPowerController;Landroid/os/Handler;)Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;
    .registers 5
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "dpc"    # Lcom/android/server/display/DisplayPowerController;
    .param p2, "handler"    # Landroid/os/Handler;

    .line 158
    const-class v0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    monitor-enter v0

    .line 159
    :try_start_3
    sget-object v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    if-nez v1, :cond_e

    .line 160
    new-instance v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    invoke-direct {v1, p0, p1, p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;-><init>(Landroid/content/Context;Lcom/android/server/display/DisplayPowerController;Landroid/os/Handler;)V

    sput-object v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    .line 162
    :cond_e
    sget-object v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sInstance:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;

    monitor-exit v0

    return-object v1

    .line 163
    :catchall_12
    move-exception v1

    monitor-exit v0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_12

    throw v1
.end method

.method private proximityNegativeReset()V
    .registers 4

    .line 721
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    if-eqz v0, :cond_31

    .line 722
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    invoke-virtual {v0}, Lcom/android/server/power/PowerManagerService;->getWrapper()Lcom/android/server/power/IPowerManagerServiceWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/power/IPowerManagerServiceWrapper;->getLock()Ljava/lang/Object;

    move-result-object v0

    .line 723
    .local v0, "lock":Ljava/lang/Object;
    monitor-enter v0

    .line 724
    :try_start_f
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "onProximityNegativeForceReset"

    invoke-static {v1, v2}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 725
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    invoke-virtual {v1}, Lcom/android/server/power/PowerManagerService;->getWrapper()Lcom/android/server/power/IPowerManagerServiceWrapper;

    move-result-object v1

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Lcom/android/server/power/IPowerManagerServiceWrapper;->setProximityPositive(Z)V

    .line 726
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    invoke-virtual {v1}, Lcom/android/server/power/PowerManagerService;->getWrapper()Lcom/android/server/power/IPowerManagerServiceWrapper;

    move-result-object v1

    invoke-interface {v1, v2}, Lcom/android/server/power/IPowerManagerServiceWrapper;->setInterceptedPowerKeyForProximity(Z)V

    .line 727
    monitor-exit v0
    :try_end_2b
    .catchall {:try_start_f .. :try_end_2b} :catchall_2e

    .line 728
    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsPositiveForceSuspend:Z

    goto :goto_31

    .line 727
    :catchall_2e
    move-exception v1

    :try_start_2f
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_2f .. :try_end_30} :catchall_2e

    throw v1

    .line 730
    .end local v0    # "lock":Ljava/lang/Object;
    :cond_31
    :goto_31
    return-void
.end method

.method private static proximityToString(I)Ljava/lang/String;
    .registers 2
    .param p0, "state"    # I

    .line 733
    packed-switch p0, :pswitch_data_12

    .line 741
    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 739
    :pswitch_8
    const-string v0, "Positive"

    return-object v0

    .line 737
    :pswitch_b
    const-string v0, "Negative"

    return-object v0

    .line 735
    :pswitch_e
    const-string v0, "Unknown"

    return-object v0

    nop

    :pswitch_data_12
    .packed-switch -0x1
        :pswitch_e
        :pswitch_b
        :pswitch_8
    .end packed-switch
.end method

.method private sendOnProximityNegativeSuspendWithWakelock()V
    .registers 4

    .line 664
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    .line 665
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->getWakelockController()Lcom/android/server/display/WakelockController;

    move-result-object v0

    .line 666
    .local v0, "wakelockController":Lcom/android/server/display/WakelockController;
    if-eqz v0, :cond_1a

    .line 667
    const/16 v1, 0x65

    invoke-virtual {v0, v1}, Lcom/android/server/display/WakelockController;->acquireWakelock(I)Z

    goto :goto_22

    .line 669
    :cond_1a
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "sendOnProximityNegativeSuspendWithWakelock: callbacks is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 671
    :goto_22
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOnProximityNegativeSuspendRunnable:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 672
    return-void
.end method

.method private sendOnProximityPositiveSuspendWithWakelock()V
    .registers 4

    .line 653
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    .line 654
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->getWakelockController()Lcom/android/server/display/WakelockController;

    move-result-object v0

    .line 655
    .local v0, "wakelockController":Lcom/android/server/display/WakelockController;
    if-eqz v0, :cond_1a

    .line 656
    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Lcom/android/server/display/WakelockController;->acquireWakelock(I)Z

    goto :goto_22

    .line 658
    :cond_1a
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "sendOnProximityPositiveSuspendWithWakelock: callbacks is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 660
    :goto_22
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOnProximityPositiveSuspendRunnable:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 661
    return-void
.end method

.method private sendProximityNegativeReset()V
    .registers 4

    .line 642
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    .line 643
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->getWakelockController()Lcom/android/server/display/WakelockController;

    move-result-object v0

    .line 644
    .local v0, "wakelockController":Lcom/android/server/display/WakelockController;
    if-eqz v0, :cond_1a

    .line 645
    const/16 v1, 0x65

    invoke-virtual {v0, v1}, Lcom/android/server/display/WakelockController;->acquireWakelock(I)Z

    goto :goto_22

    .line 647
    :cond_1a
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "sendOnProximityPositiveSuspendWithWakelock: callbacks is null"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 649
    :goto_22
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityNegativeResetRunnable:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 650
    return-void
.end method


# virtual methods
.method public applyOplusProximitySensorLocked(Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;IZZZI)Z
    .registers 14
    .param p1, "powerRequest"    # Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;
    .param p2, "proximity"    # I
    .param p3, "proximitySensorEnabled"    # Z
    .param p4, "waitingForNegativeProximity"    # Z
    .param p5, "screenOffBecauseOfProximity"    # Z
    .param p6, "state"    # I

    .line 184
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    monitor-enter v0

    .line 185
    :try_start_3
    iput p2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximity:I

    .line 186
    iput-boolean p3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximityEnable:Z

    .line 187
    monitor-exit v0
    :try_end_8
    .catchall {:try_start_3 .. :try_end_8} :catchall_1dd

    .line 188
    iget-boolean v0, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->useProximitySensor:Z

    const/4 v1, 0x0

    if-nez v0, :cond_f

    .line 189
    iput-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsScreenOffByProximityPositive:Z

    .line 191
    :cond_f
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    if-nez v0, :cond_1b

    .line 192
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    invoke-static {v0, v1}, Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;->getInstance(Landroid/content/Context;Z)Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    .line 194
    :cond_1b
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    if-eqz v0, :cond_33

    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    invoke-virtual {v0}, Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;->getCastStatus()Z

    move-result v0

    if-eqz v0, :cond_33

    .line 195
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_4e

    .line 196
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string v2, "Cast is on"

    invoke-static {v0, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4e

    .line 198
    :cond_33
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    if-nez v0, :cond_4e

    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsPositiveForceSuspend:Z

    if-nez v0, :cond_4e

    .line 199
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    monitor-enter v0

    .line 200
    :try_start_3e
    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPendingPocketProxEnable:Z

    if-eqz v2, :cond_49

    if-nez p2, :cond_49

    .line 201
    iput-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPendingPocketProxEnable:Z

    .line 202
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->changeSensor()V

    .line 204
    :cond_49
    monitor-exit v0

    .line 205
    return v1

    .line 204
    :catchall_4b
    move-exception v1

    monitor-exit v0
    :try_end_4d
    .catchall {:try_start_3e .. :try_end_4d} :catchall_4b

    throw v1

    .line 207
    :cond_4e
    :goto_4e
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_59

    .line 208
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string v2, "applyOplusProximitySensorLocked"

    invoke-static {v0, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 211
    :cond_59
    iget-boolean v0, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->useProximitySensor:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_ad

    .line 212
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 213
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0, v2}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setProximitySensorEnabled(Z)V

    .line 214
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    if-nez v0, :cond_9f

    .line 215
    const-string v0, "OplusProximitySensorScreenOnOff"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "mProximity = "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->proximityToString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 216
    if-ne p2, v2, :cond_96

    .line 217
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sendOnProximityPositiveSuspendWithWakelock()V

    goto :goto_9b

    .line 218
    :cond_96
    if-nez p2, :cond_9b

    .line 219
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sendOnProximityNegativeSuspendWithWakelock()V

    .line 224
    :cond_9b
    :goto_9b
    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    goto/16 :goto_1dc

    .line 226
    :cond_9f
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_1dc

    .line 227
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v1, "the last proximity event has been handled"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_1dc

    .line 232
    :cond_ad
    if-eqz p3, :cond_1d9

    .line 233
    const-string v0, "OplusProximitySensorScreenOnOff"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "useProximitySensor = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-boolean v4, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->useProximitySensor:Z

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", waitingForNegativeProximity = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", target state = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", proximity = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", current state = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    iget-object v4, v4, Lcom/android/server/display/DisplayPowerController;->mDpcExt:Lcom/android/server/display/IOplusDisplayPowerControllerExt;

    .line 237
    invoke-interface {v4}, Lcom/android/server/display/IOplusDisplayPowerControllerExt;->getScreenState()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 233
    invoke-static {v0, v3}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 239
    const/4 v0, 0x4

    const/4 v3, 0x3

    if-eqz p4, :cond_123

    if-ne p2, v2, :cond_123

    if-eq p6, v2, :cond_110

    if-eq p6, v3, :cond_110

    if-eq p6, v0, :cond_110

    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    iget-object v4, v4, Lcom/android/server/display/DisplayPowerController;->mDpcExt:Lcom/android/server/display/IOplusDisplayPowerControllerExt;

    .line 244
    invoke-interface {v4}, Lcom/android/server/display/IOplusDisplayPowerControllerExt;->getScreenState()I

    move-result v4

    if-eq v4, v2, :cond_123

    .line 245
    :cond_110
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 246
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0, v2}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setProximitySensorEnabled(Z)V

    goto/16 :goto_1dc

    .line 248
    :cond_123
    const-string v4, "OplusProximitySensorScreenOnOff"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "mPowerRequest.useProximitySensor = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-boolean v6, p1, Landroid/hardware/display/DisplayManagerInternal$DisplayPowerRequest;->useProximitySensor:Z

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", waitingForNegativeProximity = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", target state = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", current state = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    iget-object v6, v6, Lcom/android/server/display/DisplayPowerController;->mDpcExt:Lcom/android/server/display/IOplusDisplayPowerControllerExt;

    .line 251
    invoke-interface {v6}, Lcom/android/server/display/IOplusDisplayPowerControllerExt;->getScreenState()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 248
    invoke-static {v4, v5}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 252
    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v4}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v4

    invoke-interface {v4}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v4

    .line 253
    invoke-virtual {v4}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v4

    invoke-interface {v4, v1}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setProximitySensorEnabled(Z)V

    .line 256
    iget-object v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    const-string/jumbo v5, "power"

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/PowerManager;

    .line 259
    .local v4, "pm":Landroid/os/PowerManager;
    if-eq p6, v2, :cond_1a7

    if-eq p6, v3, :cond_1a7

    if-eq p6, v0, :cond_1a7

    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    iget-object v0, v0, Lcom/android/server/display/DisplayPowerController;->mDpcExt:Lcom/android/server/display/IOplusDisplayPowerControllerExt;

    .line 261
    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerExt;->getScreenState()I

    move-result v0

    if-ne v0, v2, :cond_1a7

    .line 264
    invoke-virtual {v4, v1}, Landroid/os/PowerManager;->isInteractive(I)Z

    move-result v0

    if-eqz v0, :cond_1a7

    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    if-eqz v0, :cond_1a3

    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCastManagerWrapper:Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;

    .line 265
    invoke-virtual {v0}, Lcom/oplus/exsystemservice/castmanager/CastManagerWrapper;->getCastStatus()Z

    move-result v0

    if-eqz v0, :cond_1a3

    goto :goto_1a7

    .line 270
    :cond_1a3
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sendProximityNegativeReset()V

    goto :goto_1b2

    .line 267
    :cond_1a7
    :goto_1a7
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v1, "turn on lcd light due to proximity released"

    invoke-static {v0, v1}, Landroid/util/Slog;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 268
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sendOnProximityNegativeSuspendWithWakelock()V

    .line 272
    :goto_1b2
    const/4 p5, 0x0

    .line 273
    const/4 p4, 0x0

    .line 274
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 275
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0, p5}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setScreenOffBecauseOfProximity(Z)V

    .line 276
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 277
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0, p4}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setWaitingForNegativeProximity(Z)V

    .line 278
    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    .line 279
    .end local v4    # "pm":Landroid/os/PowerManager;
    goto :goto_1dc

    .line 283
    :cond_1d9
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->proximityNegativeReset()V

    .line 287
    :cond_1dc
    :goto_1dc
    return v2

    .line 187
    :catchall_1dd
    move-exception v1

    :try_start_1de
    monitor-exit v0
    :try_end_1df
    .catchall {:try_start_1de .. :try_end_1df} :catchall_1dd

    throw v1
.end method

.method public dump(Ljava/io/PrintWriter;)V
    .registers 5
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 746
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    monitor-enter v0

    .line 747
    :try_start_3
    const-string v1, ""

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 748
    const-string v1, "OplusProximitySensorScreenOnOff:"

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 749
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  mCurrentProximity="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximity:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 750
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  mCurrentProximityEnable="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximityEnable:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 751
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  mPocketProxEnable="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 752
    monitor-exit v0
    :try_end_56
    .catchall {:try_start_3 .. :try_end_56} :catchall_87

    .line 753
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mIsPositiveForceSuspend="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsPositiveForceSuspend:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 754
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  mProximityEventHandled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 755
    return-void

    .line 752
    :catchall_87
    move-exception v1

    :try_start_88
    monitor-exit v0
    :try_end_89
    .catchall {:try_start_88 .. :try_end_89} :catchall_87

    throw v1
.end method

.method public getUseProximityForceSuspendState(I)Z
    .registers 3
    .param p1, "displayId"    # I

    .line 326
    if-eqz p1, :cond_4

    .line 327
    const/4 v0, 0x0

    return v0

    .line 329
    :cond_4
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    return v0
.end method

.method public interceptProximityEvent()Z
    .registers 6

    .line 373
    const/4 v0, 0x0

    .line 374
    .local v0, "intercept":Z
    iget v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    const/4 v2, 0x1

    const-string v3, "cover mode = "

    const-string v4, "OplusProximitySensorScreenOnOff"

    if-ne v1, v2, :cond_27

    .line 375
    const/4 v0, 0x1

    .line 376
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", intercept proximity event"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 378
    :cond_27
    iget-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v1, :cond_4b

    .line 379
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", intercept = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 381
    :cond_4b
    return v0
.end method

.method public isGameModeOn()Z
    .registers 6

    .line 357
    const/4 v0, 0x0

    .line 358
    .local v0, "isGameModeOn":Z
    sget-boolean v1, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->sFeatureKeepGameScreenOnSupport:Z

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_18

    .line 359
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string/jumbo v4, "game_landscape_mode"

    invoke-static {v1, v4, v3}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-ne v1, v2, :cond_27

    .line 361
    const/4 v0, 0x1

    goto :goto_27

    .line 364
    :cond_18
    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v4, "debug_gamemode_value"

    invoke-static {v1, v4, v3}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-ne v1, v2, :cond_27

    .line 366
    const/4 v0, 0x1

    .line 369
    :cond_27
    :goto_27
    return v0
.end method

.method public isProximityPositive()Z
    .registers 2

    .line 300
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsScreenOffByProximityPositive:Z

    return v0
.end method

.method public isSilentRebootFirstGoToSleep(I)Z
    .registers 5
    .param p1, "displayId"    # I

    .line 533
    const/4 v0, 0x0

    if-eqz p1, :cond_4

    .line 534
    return v0

    .line 536
    :cond_4
    sget-object v1, Lcom/android/server/power/IOplusSilentRebootManager;->DEFAULT:Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-interface {v1}, Lcom/android/server/power/IOplusSilentRebootManager;->getSilenceGotoSleep()Z

    move-result v1

    if-eqz v1, :cond_3a

    .line 537
    sget-object v1, Lcom/android/server/power/IOplusSilentRebootManager;->DEFAULT:Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-interface {v1, v0}, Lcom/android/server/power/IOplusSilentRebootManager;->setSilenceGotoSleep(Z)V

    .line 538
    const-string v1, "FirstGoToSleep"

    const-string v2, "OplusProximitySensorScreenOnOff"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 539
    sget-object v1, Lcom/android/server/power/IOplusSilentRebootManager;->DEFAULT:Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-static {v1}, Landroid/common/OplusFeatureCache;->get(Landroid/common/IOplusCommonFeature;)Landroid/common/IOplusCommonFeature;

    move-result-object v1

    check-cast v1, Lcom/android/server/power/IOplusSilentRebootManager;

    invoke-interface {v1}, Lcom/android/server/power/IOplusSilentRebootManager;->isSilenceFlagOpen()Z

    move-result v1

    if-eqz v1, :cond_3a

    .line 540
    const-string/jumbo v0, "silent sleep"

    invoke-static {v2, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 541
    const/4 v0, 0x1

    return v0

    .line 544
    :cond_3a
    return v0
.end method

.method public isSupportCoverMode()Z
    .registers 4

    .line 420
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    invoke-virtual {v0}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    invoke-virtual {v0}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->isSupported()Z

    move-result v0

    if-eqz v0, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    .line 421
    .local v0, "result":Z
    :goto_13
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "support = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    invoke-virtual {v2}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->isSupported()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", enable = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    .line 422
    invoke-virtual {v2}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->isEnabled()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 421
    const-string v2, "OplusProximitySensorScreenOnOff"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 423
    return v0
.end method

.method public isUseProximityForceSuspendStateChanged(I)Z
    .registers 5
    .param p1, "displayId"    # I

    .line 343
    const/4 v0, 0x0

    if-eqz p1, :cond_4

    .line 344
    return v0

    .line 346
    :cond_4
    iget-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mLastUseProximityForceSuspend:Z

    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    if-eq v1, v2, :cond_1c

    .line 347
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mLastUseProximityForceSuspend:Z

    .line 348
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_1a

    .line 349
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v1, "isUseProximityForceSuspendStateChanged"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 351
    :cond_1a
    const/4 v0, 0x1

    return v0

    .line 353
    :cond_1c
    return v0
.end method

.method public onProximityDebounceTimeArrived(II)V
    .registers 14
    .param p1, "displayId"    # I
    .param p2, "proximity"    # I

    .line 304
    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ne p2, v1, :cond_6

    move v2, v1

    goto :goto_7

    :cond_6
    move v2, v0

    :goto_7
    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mIsScreenOffByProximityPositive:Z

    .line 305
    const-string v2, "OplusProximitySensorScreenOnOff"

    if-ne p2, v1, :cond_29

    .line 306
    nop

    .line 310
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    .line 306
    const v3, 0x18bb5

    const/16 v4, 0x4e98

    const-string v5, "CriticalLog"

    const-string v6, "Theia"

    const-string/jumbo v9, "screen_state_off"

    const-string/jumbo v10, "pSensorScreenoff"

    invoke-static/range {v3 .. v10}, Lcom/oplus/android/internal/util/OplusFrameworkStatsLog;->write(IILjava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)V

    .line 313
    const-string v1, "dispatch positive screen off"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 315
    :cond_29
    if-eqz p1, :cond_2c

    .line 316
    return-void

    .line 318
    :cond_2c
    const-string/jumbo v1, "onProximityDebounceTimeArrived"

    invoke-static {v2, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 320
    iput-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mProximityEventHandled:Z

    .line 322
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mScreenOnCpuBoostHelper:Lcom/android/server/oplus/ScreenOnCpuBoostHelper;

    const/16 v1, 0x1f4

    invoke-virtual {v0, v1}, Lcom/android/server/oplus/ScreenOnCpuBoostHelper;->acquireCpuBoost(I)V

    .line 323
    return-void
.end method

.method public registerCallback()V
    .registers 4

    .line 399
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_c

    .line 400
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v1, "register cover callback"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 402
    :cond_c
    invoke-virtual {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->isSupportCoverMode()Z

    move-result v0

    if-nez v0, :cond_13

    .line 403
    return-void

    .line 405
    :cond_13
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverExcutor:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverModeExcutor;

    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverStateCallback:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;

    invoke-virtual {v0, v1, v2}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->registerCallback(Ljava/util/concurrent/Executor;Lcom/oplus/hardware/devicecase/OplusDeviceCaseStateCallback;)V

    .line 406
    return-void
.end method

.method public registerPSensor(Landroid/hardware/SensorManager;Landroid/hardware/SensorEventListener;ILandroid/os/Handler;Landroid/hardware/Sensor;)Z
    .registers 14
    .param p1, "sensorManager"    # Landroid/hardware/SensorManager;
    .param p2, "listener"    # Landroid/hardware/SensorEventListener;
    .param p3, "samplingPeriodUs"    # I
    .param p4, "handler"    # Landroid/os/Handler;
    .param p5, "psensor"    # Landroid/hardware/Sensor;

    .line 459
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPsensor:Landroid/hardware/Sensor;

    if-nez v0, :cond_6

    .line 460
    iput-object p5, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPsensor:Landroid/hardware/Sensor;

    .line 462
    :cond_6
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    if-nez v0, :cond_c

    .line 463
    iput-object p2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorListener:Landroid/hardware/SensorEventListener;

    .line 465
    :cond_c
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    if-nez v0, :cond_12

    .line 466
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mSensorManager:Landroid/hardware/SensorManager;

    .line 468
    :cond_12
    invoke-direct {p0, p1}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->findPocketSensor(Landroid/hardware/SensorManager;)V

    .line 469
    invoke-static {}, Lcom/android/server/power/OplusPowerManagerHelper;->getProximityLockFromInCallUiValueLocked()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_50

    .line 470
    invoke-static {}, Lcom/android/server/power/OplusPowerManagerHelper;->getGoogleDialerValueLocked()Z

    move-result v0

    if-eqz v0, :cond_23

    goto :goto_50

    .line 496
    :cond_23
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    monitor-enter v0

    .line 497
    :try_start_26
    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    iput-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mTempPocketEnable:Z

    .line 498
    iget-boolean v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mTempPocketEnable:Z

    if-eqz v2, :cond_42

    .line 499
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    if-eqz v2, :cond_39

    .line 500
    iget-object v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketSensor:Landroid/hardware/Sensor;

    invoke-virtual {p1, p2, v2, p3, p4}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    .line 501
    monitor-exit v0

    return v1

    .line 503
    :cond_39
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "registerPSensor: not find any pocketSensor"

    invoke-static {v1, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4a

    .line 506
    :cond_42
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "registerPSensor: not in incallui or google dialer or pocket, use original psensor"

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 508
    :goto_4a
    monitor-exit v0

    goto/16 :goto_d0

    :catchall_4d
    move-exception v1

    monitor-exit v0
    :try_end_4f
    .catchall {:try_start_26 .. :try_end_4f} :catchall_4d

    throw v1

    .line 471
    :cond_50
    :goto_50
    const/4 v0, 0x0

    .line 472
    .local v0, "oplusSensor":Landroid/hardware/Sensor;
    sget-object v2, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->OPLUS_PSENSOR_LIST:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_57
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_c1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 473
    .local v3, "type":I
    invoke-virtual {p1, v3}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    move-result-object v4

    .line 474
    .local v4, "sensors":Ljava/util/List;, "Ljava/util/List<Landroid/hardware/Sensor;>;"
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    if-nez v5, :cond_8b

    .line 475
    const-string v5, "OplusProximitySensorScreenOnOff"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "registerPSensor: not find: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 476
    goto :goto_57

    .line 478
    :cond_8b
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_8f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_a4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/hardware/Sensor;

    .line 479
    .local v6, "sensor":Landroid/hardware/Sensor;
    invoke-virtual {v6}, Landroid/hardware/Sensor;->getType()I

    move-result v7

    if-ne v3, v7, :cond_a3

    .line 480
    move-object v0, v6

    .line 481
    goto :goto_a4

    .line 483
    .end local v6    # "sensor":Landroid/hardware/Sensor;
    :cond_a3
    goto :goto_8f

    .line 484
    :cond_a4
    :goto_a4
    if-eqz v0, :cond_c0

    .line 485
    const-string v2, "OplusProximitySensorScreenOnOff"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "registerPSensor: find: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 486
    goto :goto_c1

    .line 488
    .end local v3    # "type":I
    .end local v4    # "sensors":Ljava/util/List;, "Ljava/util/List<Landroid/hardware/Sensor;>;"
    :cond_c0
    goto :goto_57

    .line 489
    :cond_c1
    :goto_c1
    if-eqz v0, :cond_c7

    .line 490
    invoke-virtual {p1, p2, v0, p3, p4}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    .line 491
    return v1

    .line 493
    :cond_c7
    const-string v1, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v2, "registerPSensor: not find any oplus psensors"

    invoke-static {v1, v2}, Landroid/util/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 495
    .end local v0    # "oplusSensor":Landroid/hardware/Sensor;
    nop

    .line 510
    :goto_d0
    const/4 v0, 0x0

    return v0
.end method

.method public setCoverModeState(Ljava/lang/String;)V
    .registers 6
    .param p1, "state"    # Ljava/lang/String;

    .line 385
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, -0x1

    sparse-switch v0, :sswitch_data_2e

    :cond_a
    goto :goto_20

    :sswitch_b
    const-string/jumbo v0, "open"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    move v0, v2

    goto :goto_21

    :sswitch_16
    const-string v0, "closed"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    move v0, v1

    goto :goto_21

    :goto_20
    move v0, v3

    :goto_21
    packed-switch v0, :pswitch_data_38

    .line 393
    iput v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    goto :goto_2d

    .line 390
    :pswitch_27
    iput v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    .line 391
    goto :goto_2d

    .line 387
    :pswitch_2a
    iput v2, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    .line 388
    nop

    .line 396
    :goto_2d
    return-void

    :sswitch_data_2e
    .sparse-switch
        -0x50ea1e94 -> :sswitch_16
        0x34264a -> :sswitch_b
    .end sparse-switch

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_2a
        :pswitch_27
    .end packed-switch
.end method

.method public setPocketWhenProx(ZLandroid/os/IBinder;)V
    .registers 8
    .param p1, "enable"    # Z
    .param p2, "token"    # Landroid/os/IBinder;

    .line 549
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketEnableLock:Ljava/lang/Object;

    monitor-enter v0

    .line 550
    :try_start_3
    iget-boolean v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    if-ne p1, v1, :cond_9

    .line 551
    monitor-exit v0

    return-void

    .line 553
    :cond_9
    const-string v1, "OplusProximitySensorScreenOnOff"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "old enable = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", new enable = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", token = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 554
    const/4 v1, 0x0

    .line 555
    .local v1, "pocketProxToken":Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;
    iput-boolean p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    .line 556
    invoke-direct {p0, p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->findIndexPocketToken(Landroid/os/IBinder;)I

    move-result v2

    .line 557
    .local v2, "index":I
    iget-boolean v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnable:Z

    if-eqz v3, :cond_51

    .line 558
    if-gez v2, :cond_5e

    .line 559
    new-instance v3, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;

    invoke-direct {v3, p0, p2}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;-><init>(Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;Landroid/os/IBinder;)V

    move-object v1, v3

    .line 560
    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_5e

    .line 563
    :cond_51
    if-ltz v2, :cond_5e

    .line 564
    iget-object v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPocketProxEnableTokens:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;

    invoke-virtual {v3}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;->unlinkToDeath()V

    .line 567
    :cond_5e
    :goto_5e
    iget-boolean v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximityEnable:Z

    if-eqz v3, :cond_6d

    .line 568
    iget v3, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCurrentProximity:I

    const/4 v4, 0x1

    if-ne v3, v4, :cond_6a

    .line 569
    iput-boolean v4, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPendingPocketProxEnable:Z

    goto :goto_6d

    .line 571
    :cond_6a
    invoke-direct {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->changeSensor()V

    .line 574
    .end local v1    # "pocketProxToken":Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$PocketProxToken;
    .end local v2    # "index":I
    :cond_6d
    :goto_6d
    monitor-exit v0

    .line 575
    return-void

    .line 574
    :catchall_6f
    move-exception v1

    monitor-exit v0
    :try_end_71
    .catchall {:try_start_3 .. :try_end_71} :catchall_6f

    throw v1
.end method

.method public setPowerManagerService(Lcom/android/server/power/PowerManagerService;)V
    .registers 2
    .param p1, "pms"    # Lcom/android/server/power/PowerManagerService;

    .line 291
    iput-object p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mPMS:Lcom/android/server/power/PowerManagerService;

    .line 292
    return-void
.end method

.method public setScreenOffBecauseOfProximity(Z)V
    .registers 3
    .param p1, "screenOffBecauseOfProximity"    # Z

    .line 295
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mDisplayPowerController:Lcom/android/server/display/DisplayPowerController;

    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerController;->getWrapper()Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/display/IOplusDisplayPowerControllerWrapper;->getDisplayPowerProximityStateController()Lcom/android/server/display/DisplayPowerProximityStateController;

    move-result-object v0

    .line 296
    invoke-virtual {v0}, Lcom/android/server/display/DisplayPowerProximityStateController;->getWrapper()Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/android/server/display/IDisplayPowerProximityStateControllerWrapper;->setScreenOffBecauseOfProximity(Z)V

    .line 297
    return-void
.end method

.method public setUseProximityForceSuspend(ZI)V
    .registers 5
    .param p1, "enable"    # Z
    .param p2, "displayId"    # I

    .line 333
    if-eqz p2, :cond_3

    .line 334
    return-void

    .line 336
    :cond_3
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    if-eq v0, p1, :cond_20

    .line 337
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "setUseProximityForceSuspend: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OplusProximitySensorScreenOnOff"

    invoke-static {v1, v0}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 339
    :cond_20
    iput-boolean p1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mUseProximityForceSuspend:Z

    .line 340
    return-void
.end method

.method public unregisterCallback()V
    .registers 3

    .line 409
    iget-boolean v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDebug:Z

    if-eqz v0, :cond_c

    .line 410
    const-string v0, "OplusProximitySensorScreenOnOff"

    const-string/jumbo v1, "unregister cover callback"

    invoke-static {v0, v1}, Landroid/util/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 412
    :cond_c
    invoke-virtual {p0}, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->isSupportCoverMode()Z

    move-result v0

    if-nez v0, :cond_13

    .line 413
    return-void

    .line 415
    :cond_13
    iget-object v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mOplusDeviceCaseManager:Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;

    iget-object v1, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverStateCallback:Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff$CoverStateCallback;

    invoke-virtual {v0, v1}, Lcom/oplus/hardware/devicecase/OplusDeviceCaseManager;->unregisterCallback(Lcom/oplus/hardware/devicecase/OplusDeviceCaseStateCallback;)V

    .line 416
    const/4 v0, -0x1

    iput v0, p0, Lcom/android/server/display/feature/power/OplusProximitySensorScreenOnOff;->mCoverModeState:I

    .line 417
    return-void
.end method
