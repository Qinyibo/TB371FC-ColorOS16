.class public Lcom/android/server/hans/OplusHansWatchDog;
.super Ljava/lang/Object;
.source "OplusHansWatchDog.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;,
        Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    }
.end annotation


# static fields
.field private static final COMPLETED:I = 0x0

.field private static final OVERDUE:I = 0x3

.field private static final START_DELAY_TIME:J = 0x1388L

.field private static final TAG:Ljava/lang/String; = "OplusHansWatchDog"

.field private static final WAITED_HALF:I = 0x2

.field private static final WAITING:I = 0x1

.field private static sCheckInterval:J

.field private static sDefaultTimeout:J

.field private static volatile sInstance:Lcom/android/server/hans/OplusHansWatchDog;


# instance fields
.field private isStarted:Z

.field private isStopped:Z

.field private final mHandlerCheckers:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;",
            ">;"
        }
    .end annotation
.end field

.field private final mLock:Ljava/lang/Object;

.field private mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;


# direct methods
.method static bridge synthetic -$$Nest$fgetmLock(Lcom/android/server/hans/OplusHansWatchDog;)Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mrunCheck(Lcom/android/server/hans/OplusHansWatchDog;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/OplusHansWatchDog;->runCheck()V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetsDefaultTimeout()J
    .registers 2

    sget-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    return-wide v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 40
    const-wide/32 v0, 0x9c40

    sput-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    .line 41
    sget-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    const-wide/16 v2, 0x2

    div-long/2addr v0, v2

    sput-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sCheckInterval:J

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 59
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    .line 51
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    .line 52
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStopped:Z

    .line 54
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    .line 57
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    .line 59
    return-void
.end method

.method private describeCheckersLocked(Ljava/util/List;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 359
    .local p1, "checkers":Ljava/util/List;, "Ljava/util/List<Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 360
    .local v0, "builder":Ljava/lang/StringBuilder;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "size: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 361
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_29
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_4a

    .line 362
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    if-lez v2, :cond_3a

    .line 363
    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 365
    :cond_3a
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->describeBlockedStateLocked()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 361
    add-int/lit8 v1, v1, 0x1

    goto :goto_29

    .line 367
    .end local v1    # "i":I
    :cond_4a
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private evaluateCheckerCompletionLocked()I
    .registers 5

    .line 288
    const/4 v0, 0x0

    .line 289
    .local v0, "state":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_2
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1d

    .line 290
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 291
    .local v2, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getCompletionStateLocked()I

    move-result v3

    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 289
    .end local v2    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 293
    .end local v1    # "i":I
    :cond_1d
    return v0
.end method

.method public static getDefaultTimeout()J
    .registers 2

    .line 393
    sget-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    return-wide v0
.end method

.method private getHalfBlockedCheckersLocked()Ljava/util/ArrayList;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;",
            ">;"
        }
    .end annotation

    .line 348
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 349
    .local v0, "checkers":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;>;"
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_6
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_22

    .line 350
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 351
    .local v2, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->isHalfOverdueLocked()Z

    move-result v3

    if-eqz v3, :cond_1f

    .line 352
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 349
    .end local v2    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    :cond_1f
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 355
    .end local v1    # "i":I
    :cond_22
    return-object v0
.end method

.method public static getInstance()Lcom/android/server/hans/OplusHansWatchDog;
    .registers 2

    .line 62
    sget-object v0, Lcom/android/server/hans/OplusHansWatchDog;->sInstance:Lcom/android/server/hans/OplusHansWatchDog;

    if-nez v0, :cond_17

    .line 63
    const-class v0, Lcom/android/server/hans/OplusHansWatchDog;

    monitor-enter v0

    .line 64
    :try_start_7
    sget-object v1, Lcom/android/server/hans/OplusHansWatchDog;->sInstance:Lcom/android/server/hans/OplusHansWatchDog;

    if-nez v1, :cond_12

    .line 65
    new-instance v1, Lcom/android/server/hans/OplusHansWatchDog;

    invoke-direct {v1}, Lcom/android/server/hans/OplusHansWatchDog;-><init>()V

    sput-object v1, Lcom/android/server/hans/OplusHansWatchDog;->sInstance:Lcom/android/server/hans/OplusHansWatchDog;

    .line 67
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 69
    :cond_17
    :goto_17
    sget-object v0, Lcom/android/server/hans/OplusHansWatchDog;->sInstance:Lcom/android/server/hans/OplusHansWatchDog;

    return-object v0
.end method

.method private logE(Ljava/lang/String;)V
    .registers 5
    .param p1, "msg"    # Ljava/lang/String;

    .line 459
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "OplusHansWatchDog : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->e(Ljava/lang/String;)V

    .line 460
    return-void
.end method

.method private logW(Ljava/lang/String;)V
    .registers 5
    .param p1, "msg"    # Ljava/lang/String;

    .line 455
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "OplusHansWatchDog : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->w(Ljava/lang/String;)V

    .line 456
    return-void
.end method

.method private runCheck()V
    .registers 11

    .line 240
    const-string v0, "Hans Watchdog run()"

    invoke-virtual {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog;->logD(Ljava/lang/String;)V

    .line 241
    :goto_5
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_69

    .line 242
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    monitor-enter v0

    .line 243
    :try_start_d
    sget-wide v2, Lcom/android/server/hans/OplusHansWatchDog;->sCheckInterval:J

    .line 246
    .local v2, "timeout":J
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_10
    iget-object v5, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_26

    .line 247
    iget-object v5, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 248
    .local v5, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->scheduleCheckLocked()V

    .line 246
    .end local v5    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    add-int/lit8 v4, v4, 0x1

    goto :goto_10

    .line 255
    .end local v4    # "i":I
    :cond_26
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4
    :try_end_2a
    .catchall {:try_start_d .. :try_end_2a} :catchall_66

    .line 256
    .local v4, "start":J
    :goto_2a
    const-wide/16 v6, 0x0

    cmp-long v6, v2, v6

    if-lez v6, :cond_44

    .line 258
    :try_start_30
    iget-object v6, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    invoke-virtual {v6, v2, v3}, Ljava/lang/Object;->wait(J)V
    :try_end_35
    .catch Ljava/lang/InterruptedException; {:try_start_30 .. :try_end_35} :catch_36
    .catchall {:try_start_30 .. :try_end_35} :catchall_66

    .line 262
    goto :goto_3a

    .line 260
    :catch_36
    move-exception v6

    .line 261
    .local v6, "e":Ljava/lang/InterruptedException;
    :try_start_37
    invoke-virtual {v6}, Ljava/lang/InterruptedException;->printStackTrace()V

    .line 263
    .end local v6    # "e":Ljava/lang/InterruptedException;
    :goto_3a
    sget-wide v6, Lcom/android/server/hans/OplusHansWatchDog;->sCheckInterval:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    sub-long/2addr v8, v4

    sub-long v2, v6, v8

    goto :goto_2a

    .line 266
    :cond_44
    invoke-direct {p0}, Lcom/android/server/hans/OplusHansWatchDog;->evaluateCheckerCompletionLocked()I

    move-result v6

    .line 267
    .local v6, "waitState":I
    if-nez v6, :cond_4c

    .line 269
    monitor-exit v0

    goto :goto_5

    .line 270
    :cond_4c
    if-ne v6, v1, :cond_50

    .line 272
    monitor-exit v0

    goto :goto_5

    .line 273
    :cond_50
    const/4 v1, 0x2

    if-ne v6, v1, :cond_59

    .line 274
    const-string v7, "WAITED_HALF"

    invoke-direct {p0, v1, v7}, Lcom/android/server/hans/OplusHansWatchDog;->watchdogWaitBlockedLocked(ILjava/lang/String;)V

    goto :goto_5f

    .line 277
    :cond_59
    const-string v1, "OVERDUE"

    const/4 v7, 0x3

    invoke-direct {p0, v7, v1}, Lcom/android/server/hans/OplusHansWatchDog;->watchdogWaitBlockedLocked(ILjava/lang/String;)V

    .line 279
    :goto_5f
    const-string v1, "Hans Watchdog End"

    invoke-virtual {p0, v1}, Lcom/android/server/hans/OplusHansWatchDog;->logD(Ljava/lang/String;)V

    .line 280
    .end local v2    # "timeout":J
    .end local v4    # "start":J
    .end local v6    # "waitState":I
    monitor-exit v0

    goto :goto_5

    :catchall_66
    move-exception v1

    monitor-exit v0
    :try_end_68
    .catchall {:try_start_37 .. :try_end_68} :catchall_66

    throw v1

    .line 282
    :cond_69
    iput-boolean v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStopped:Z

    .line 283
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    .line 284
    const-string v0, "Hans Watchdog Break"

    invoke-direct {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 285
    return-void
.end method

.method private setDefaultTimeout(J)V
    .registers 8
    .param p1, "defaultTimeout"    # J

    .line 397
    sget-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    .line 398
    return-void

    .line 400
    :cond_7
    sput-wide p1, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    .line 401
    sget-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    const-wide/16 v2, 0x2

    div-long/2addr v0, v2

    sput-wide v0, Lcom/android/server/hans/OplusHansWatchDog;->sCheckInterval:J

    .line 402
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    monitor-enter v0

    .line 403
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_14
    :try_start_14
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2c

    .line 404
    iget-object v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 405
    .local v2, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    sget-wide v3, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    invoke-static {v2, v3, v4}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->-$$Nest$msetWaitMax(Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;J)V

    .line 403
    .end local v2    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    .line 407
    .end local v1    # "i":I
    :cond_2c
    monitor-exit v0

    .line 408
    return-void

    .line 407
    :catchall_2e
    move-exception v1

    monitor-exit v0
    :try_end_30
    .catchall {:try_start_14 .. :try_end_30} :catchall_2e

    throw v1
.end method

.method private watchdogWaitBlockedLocked(ILjava/lang/String;)V
    .registers 19
    .param p1, "state"    # I
    .param p2, "tag"    # Ljava/lang/String;

    .line 298
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct {v0}, Lcom/android/server/hans/OplusHansWatchDog;->getHalfBlockedCheckersLocked()Ljava/util/ArrayList;

    move-result-object v3

    .line 299
    .local v3, "blockedCheckersLocked":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;>;"
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    .line 300
    .local v4, "size":I
    const-string v5, "Hans Watchdog "

    if-nez v4, :cond_2d

    .line 301
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " Blocked, But blockedCheckers is empty\uff0c"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 302
    return-void

    .line 305
    :cond_2d
    const-string/jumbo v6, "ro.oplus.image.my_engineering.type"

    const-string v7, ""

    invoke-static {v6, v7}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "aging"

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    .line 306
    .local v6, "isAgingVersion":Z
    invoke-direct {v0, v3}, Lcom/android/server/hans/OplusHansWatchDog;->describeCheckersLocked(Ljava/util/List;)Ljava/lang/String;

    move-result-object v7

    .line 307
    .local v7, "describeCheckersLocked":Ljava/lang/String;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " Blocked: "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " , check interval: "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    sget-wide v8, Lcom/android/server/hans/OplusHansWatchDog;->sCheckInterval:J

    invoke-virtual {v5, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 308
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansWatchDog;->logCheckers()V

    .line 310
    new-instance v5, Ljava/lang/StringBuilder;

    const/16 v8, 0x200

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 311
    .local v5, "stackTraceInfo":Ljava/lang/StringBuilder;
    const/4 v8, 0x0

    .local v8, "i":I
    :goto_75
    if-ge v8, v4, :cond_f8

    .line 312
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 313
    .local v9, "bhc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "BlockedThread # "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " # maxTimeMs # "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    .line 314
    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getWaitMax()J

    move-result-wide v11

    invoke-virtual {v10, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " # "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    .line 316
    .local v10, "info":Ljava/lang/String;
    invoke-direct {v0, v10}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 317
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 319
    if-nez v6, :cond_ea

    .line 320
    const/4 v11, 0x2

    if-eq v1, v11, :cond_f2

    .line 321
    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->getThread()Ljava/lang/Thread;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v11

    .line 322
    .local v11, "stackTrace":[Ljava/lang/StackTraceElement;
    array-length v12, v11

    const/4 v13, 0x0

    :goto_c1
    if-ge v13, v12, :cond_e9

    aget-object v14, v11, v13

    .line 323
    .local v14, "stackTraceElement":Ljava/lang/StackTraceElement;
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "    at "

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 324
    const-string v2, ", at "

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 322
    .end local v14    # "stackTraceElement":Ljava/lang/StackTraceElement;
    add-int/lit8 v13, v13, 0x1

    move-object/from16 v2, p2

    goto :goto_c1

    .line 326
    .end local v11    # "stackTrace":[Ljava/lang/StackTraceElement;
    :cond_e9
    goto :goto_f2

    .line 328
    :cond_ea
    const-string v2, " no stack trace for agingtest."

    .line 329
    .end local v10    # "info":Ljava/lang/String;
    .local v2, "info":Ljava/lang/String;
    invoke-direct {v0, v2}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 330
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 311
    .end local v2    # "info":Ljava/lang/String;
    .end local v9    # "bhc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    :cond_f2
    :goto_f2
    add-int/lit8 v8, v8, 0x1

    move-object/from16 v2, p2

    goto/16 :goto_75

    .line 334
    .end local v8    # "i":I
    :cond_f8
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 336
    .local v2, "stackString":Ljava/lang/String;
    if-nez v6, :cond_105

    .line 337
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v8

    invoke-virtual {v8, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->uploadHansWatchDogData(Ljava/lang/String;)V

    .line 339
    :cond_105
    const/4 v8, 0x3

    if-ne v1, v8, :cond_121

    .line 340
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/server/hans/OplusHansDBConfig;->isHansWatchDogDisableHansEnable()Z

    move-result v9

    if-eqz v9, :cond_121

    .line 341
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v9

    .line 342
    invoke-virtual {v9, v8, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/Message;->sendToTarget()V

    .line 345
    :cond_121
    return-void
.end method


# virtual methods
.method public addThread(Landroid/os/Handler;)V
    .registers 10
    .param p1, "thread"    # Landroid/os/Handler;

    .line 101
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 102
    :try_start_3
    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    .line 103
    .local v5, "name":Ljava/lang/String;
    iget-object v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    new-instance v2, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    sget-wide v6, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_21

    move-object v3, p0

    move-object v4, p1

    .end local p1    # "thread":Landroid/os/Handler;
    .local v4, "thread":Landroid/os/Handler;
    :try_start_18
    invoke-direct/range {v2 .. v7}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;-><init>(Lcom/android/server/hans/OplusHansWatchDog;Landroid/os/Handler;Ljava/lang/String;J)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    nop

    .end local v5    # "name":Ljava/lang/String;
    monitor-exit v1

    .line 105
    return-void

    .line 104
    .end local v4    # "thread":Landroid/os/Handler;
    .restart local p1    # "thread":Landroid/os/Handler;
    :catchall_21
    move-exception v0

    move-object v4, p1

    move-object p1, v0

    .end local p1    # "thread":Landroid/os/Handler;
    .restart local v4    # "thread":Landroid/os/Handler;
    :goto_24
    monitor-exit v1
    :try_end_25
    .catchall {:try_start_18 .. :try_end_25} :catchall_26

    throw p1

    :catchall_26
    move-exception v0

    move-object p1, v0

    goto :goto_24
.end method

.method public dump(Ljava/io/PrintWriter;)V
    .registers 6
    .param p1, "pw"    # Ljava/io/PrintWriter;

    .line 371
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "HansWatchDog running: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/server/hans/OplusHansWatchDog;->isHansWatchdogRunning()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 372
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "DefaultTimeout: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-wide v1, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 373
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_33
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_6b

    .line 374
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 375
    .local v1, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "mHandlerCheckers "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": \n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 373
    .end local v1    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    add-int/lit8 v0, v0, 0x1

    goto :goto_33

    .line 377
    .end local v0    # "i":I
    :cond_6b
    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;

    .line 411
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    .line 412
    .local v0, "info":Ljava/lang/String;
    iget v1, p1, Landroid/os/Message;->what:I

    const/4 v2, 0x0

    packed-switch v1, :pswitch_data_a6

    goto/16 :goto_a4

    .line 438
    :pswitch_c
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->hansEnabled()Z

    move-result v1

    if-nez v1, :cond_a4

    .line 439
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2, v0}, Lcom/android/server/am/OplusHansManager;->notifyHansEnableByWatchDog(ZLjava/lang/String;)V

    .line 440
    const-string/jumbo v1, "notifyHansEnable"

    invoke-direct {p0, v1}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    goto/16 :goto_a4

    .line 430
    :pswitch_26
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->hansEnabled()Z

    move-result v1

    if-eqz v1, :cond_a4

    .line 431
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1, v2, v0}, Lcom/android/server/am/OplusHansManager;->notifyHansEnableByWatchDog(ZLjava/lang/String;)V

    .line 432
    const-string/jumbo v1, "notifyHansDisable"

    invoke-direct {p0, v1}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 433
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v1

    .line 434
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansDBConfig;->getHansWatchDogDisableHansTime()J

    move-result-wide v2

    const/4 v4, 0x4

    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_a4

    .line 414
    :pswitch_52
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansDBConfig;->getHansWatchDogDefaultTimeout()J

    move-result-wide v3

    invoke-direct {p0, v3, v4}, Lcom/android/server/hans/OplusHansWatchDog;->setDefaultTimeout(J)V

    .line 415
    const-string v1, "Hans Watchdog init()"

    invoke-virtual {p0, v1}, Lcom/android/server/hans/OplusHansWatchDog;->logD(Ljava/lang/String;)V

    .line 417
    :try_start_62
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    if-eqz v1, :cond_76

    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->isAlive()Z

    move-result v1

    if-eqz v1, :cond_76

    .line 418
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->interrupt()V

    .line 419
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    .line 421
    :cond_76
    new-instance v1, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    invoke-direct {v1, p0}, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;-><init>(Lcom/android/server/hans/OplusHansWatchDog;)V

    iput-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    .line 422
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    const-string v3, "HansWatchdogThread"

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->setName(Ljava/lang/String;)V

    .line 423
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mThread:Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansWatchDog$HansWatchdogThread;->start()V
    :try_end_89
    .catch Ljava/lang/Exception; {:try_start_62 .. :try_end_89} :catch_8a

    .line 427
    goto :goto_a4

    .line 424
    :catch_8a
    move-exception v1

    .line 425
    .local v1, "e":Ljava/lang/Exception;
    iput-boolean v2, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    .line 426
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "HansWatchdogThread start fail, e="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/android/server/hans/OplusHansWatchDog;->logE(Ljava/lang/String;)V

    .line 428
    .end local v1    # "e":Ljava/lang/Exception;
    nop

    .line 446
    :cond_a4
    :goto_a4
    return-void

    nop

    :pswitch_data_a6
    .packed-switch 0x2
        :pswitch_52
        :pswitch_26
        :pswitch_c
    .end packed-switch
.end method

.method public isHansWatchdogRunning()Z
    .registers 2

    .line 389
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    if-eqz v0, :cond_a

    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStopped:Z

    if-nez v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method

.method public logCheckers()V
    .registers 5

    .line 380
    const-string v0, "dumpCheckers: "

    invoke-direct {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 381
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "DefaultTimeout: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-wide v1, Lcom/android/server/hans/OplusHansWatchDog;->sDefaultTimeout:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 382
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1e
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_58

    .line 383
    iget-object v1, p0, Lcom/android/server/hans/OplusHansWatchDog;->mHandlerCheckers:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;

    .line 384
    .local v1, "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "mHandlerCheckers "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": \n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "OplusHansWatchDog"

    invoke-virtual {v1, v3}, Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 382
    .end local v1    # "hc":Lcom/android/server/hans/OplusHansWatchDog$HandlerChecker;
    add-int/lit8 v0, v0, 0x1

    goto :goto_1e

    .line 386
    .end local v0    # "i":I
    :cond_58
    return-void
.end method

.method public logD(Ljava/lang/String;)V
    .registers 5
    .param p1, "msg"    # Ljava/lang/String;

    .line 449
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v0

    if-eqz v0, :cond_20

    .line 450
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "OplusHansWatchDog : "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 452
    :cond_20
    return-void
.end method

.method public start()V
    .registers 5

    .line 77
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansDBConfig;->isHansWatchDogEnable()Z

    move-result v0

    if-eqz v0, :cond_26

    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    if-nez v0, :cond_26

    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStopped:Z

    if-eqz v0, :cond_26

    .line 78
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    .line 79
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStopped:Z

    .line 81
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v0

    .line 82
    const/4 v1, 0x2

    const-wide/16 v2, 0x1388

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    .line 84
    :cond_26
    return-void
.end method

.method public stop()V
    .registers 3

    .line 91
    iget-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    if-eqz v0, :cond_26

    .line 92
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/server/hans/OplusHansWatchDog;->isStarted:Z

    .line 93
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_21

    .line 94
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->getNativeServiceHandler()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    .line 96
    :cond_21
    const-string v0, "Hans Watchdog stop()"

    invoke-direct {p0, v0}, Lcom/android/server/hans/OplusHansWatchDog;->logW(Ljava/lang/String;)V

    .line 98
    :cond_26
    return-void
.end method
