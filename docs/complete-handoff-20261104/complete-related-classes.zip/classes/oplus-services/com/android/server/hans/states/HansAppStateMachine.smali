.class public Lcom/android/server/hans/states/HansAppStateMachine;
.super Lcom/android/server/hans/states/StateMachine;
.source "HansAppStateMachine.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;,
        Lcom/android/server/hans/states/HansAppStateMachine$RunningState;,
        Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;,
        Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;
    }
.end annotation


# static fields
.field private static final CMD_BASE:I = 0x64

.field private static final CMD_DEEPSLEEP_OFF:I = 0x6d

.field private static final CMD_DELAY_FREEZE:I = 0x72

.field public static final CMD_ENTER_SM:I = 0x14

.field private static final CMD_EXIT_SM:I = 0x69

.field private static final CMD_FORCE_TRANSITION_RtoM_NO_IMP:I = 0x71

.field private static final CMD_FORCE_TRANSITION_SM:I = 0x70

.field public static final CMD_FREEZE:I = 0x15

.field private static final CMD_FastFreezer_Exit:I = 0x66

.field private static final CMD_HIGH_LOADING:I = 0x6e

.field private static final CMD_LCD_OFF_ALARM:I = 0x67

.field private static final CMD_LCD_ON:I = 0x65

.field public static final CMD_MtoF:I = 0x8

.field private static final CMD_RM_ALL_MESSAGES:I = 0x6f

.field private static final CMD_RtoF_SUPER_FREEZE:I = 0x73

.field public static final CMD_RtoM:I = 0x4

.field private static final CMD_UNFREEZE:I = 0x6b

.field public static final DEFAULT_NAME:Ljava/lang/String; = "Default"

.field public static final DEFAULT_STATE:I = 0x0

.field public static final FROZEN_NAME:Ljava/lang/String; = "Frozen"

.field public static final FROZEN_STATE:I = 0x3

.field public static final MIDDLE_NAME:Ljava/lang/String; = "Middle"

.field public static final MIDDLE_STATE:I = 0x2

.field public static final RUNNING_NAME:Ljava/lang/String; = "Running"

.field public static final RUNNING_STATE:I = 0x1

.field public static final UNKNOWN_NAME:Ljava/lang/String; = "unknown state"

.field public static final UNKNOWN_STATE:I = -0x1


# instance fields
.field private mCurStateEnterTimeMs:J

.field private mDefaultState:Lcom/android/server/hans/states/State;

.field private mFrozenState:Lcom/android/server/hans/states/State;

.field private mHansDb:Lcom/android/server/hans/OplusHansDBConfig;

.field private mHansHistoryManager:Lcom/android/server/hans/OplusHansHistoryManager;

.field private mHansImportance:Lcom/android/server/hans/OplusHansImportance;

.field private mHansPkg:Lcom/android/server/hans/OplusHansPackage;

.field private mImportanceCheckCount:I

.field private mMiddleState:Lcom/android/server/hans/states/State;

.field private mMtoFinFastFreeze:Z

.field private mRtoFinFastFreeze:Z

.field private mRtoFinFastFrzOnSuperFZMode:Z

.field private mRtoMinFastFreeze:Z

.field private mRunningState:Lcom/android/server/hans/states/State;

.field private mUnfreezeReason:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetmDefaultState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mDefaultState:Lcom/android/server/hans/states/State;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmFrozenState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHansDb(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansDBConfig;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansDb:Lcom/android/server/hans/OplusHansDBConfig;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHansHistoryManager(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansHistoryManager;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansHistoryManager:Lcom/android/server/hans/OplusHansHistoryManager;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHansImportance(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansImportance;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansImportance:Lcom/android/server/hans/OplusHansImportance;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmHansPkg(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/OplusHansPackage;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;)I
    .registers 1

    iget p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mImportanceCheckCount:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmMiddleState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMtoFinFastFreeze:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmRtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoFinFastFreeze:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmRtoFinFastFrzOnSuperFZMode(Lcom/android/server/hans/states/HansAppStateMachine;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoFinFastFrzOnSuperFZMode:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoMinFastFreeze:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmRunningState(Lcom/android/server/hans/states/HansAppStateMachine;)Lcom/android/server/hans/states/State;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRunningState:Lcom/android/server/hans/states/State;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mUnfreezeReason:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputmImportanceCheckCount(Lcom/android/server/hans/states/HansAppStateMachine;I)V
    .registers 2

    iput p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mImportanceCheckCount:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmMtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMtoFinFastFreeze:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmRtoFinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoFinFastFreeze:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmRtoFinFastFrzOnSuperFZMode(Lcom/android/server/hans/states/HansAppStateMachine;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoFinFastFrzOnSuperFZMode:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmRtoMinFastFreeze(Lcom/android/server/hans/states/HansAppStateMachine;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRtoMinFastFreeze:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmUnfreezeReason(Lcom/android/server/hans/states/HansAppStateMachine;Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mUnfreezeReason:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$mcheckDelayFreeze(Lcom/android/server/hans/states/HansAppStateMachine;JJLjava/lang/String;)Landroid/util/Pair;
    .registers 6

    invoke-direct/range {p0 .. p5}, Lcom/android/server/hans/states/HansAppStateMachine;->checkDelayFreeze(JJLjava/lang/String;)Landroid/util/Pair;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mcheckExistingQuotaTask(Lcom/android/server/hans/states/HansAppStateMachine;ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/android/server/hans/states/HansAppStateMachine;->checkExistingQuotaTask(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mgetLcdOffSkipImportance(Lcom/android/server/hans/states/HansAppStateMachine;)I
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getLcdOffSkipImportance()I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mrecordEnterSMTime(Lcom/android/server/hans/states/HansAppStateMachine;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->recordEnterSMTime(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveAllMessagesExceptEnterSM(Lcom/android/server/hans/states/HansAppStateMachine;)V
    .registers 1

    invoke-direct {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->removeAllMessagesExceptEnterSM()V

    return-void
.end method

.method public constructor <init>(Lcom/android/server/hans/OplusHansPackage;Landroid/os/Looper;)V
    .registers 5
    .param p1, "pkg"    # Lcom/android/server/hans/OplusHansPackage;
    .param p2, "looper"    # Landroid/os/Looper;

    .line 138
    const-string v0, "HansAppStateMachine"

    invoke-direct {p0, v0, p2}, Lcom/android/server/hans/states/StateMachine;-><init>(Ljava/lang/String;Landroid/os/Looper;)V

    .line 88
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mCurStateEnterTimeMs:J

    .line 101
    const/4 v0, 0x0

    iput v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mImportanceCheckCount:I

    .line 139
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansHistoryManager:Lcom/android/server/hans/OplusHansHistoryManager;

    .line 140
    invoke-static {}, Lcom/android/server/hans/OplusHansDBConfig;->getInstance()Lcom/android/server/hans/OplusHansDBConfig;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansDb:Lcom/android/server/hans/OplusHansDBConfig;

    .line 141
    invoke-static {}, Lcom/android/server/hans/OplusHansImportance;->getInstance()Lcom/android/server/hans/OplusHansImportance;

    move-result-object v0

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansImportance:Lcom/android/server/hans/OplusHansImportance;

    .line 142
    iput-object p1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    .line 143
    new-instance v0, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;

    invoke-direct {v0, p0}, Lcom/android/server/hans/states/HansAppStateMachine$DefaultState;-><init>(Lcom/android/server/hans/states/HansAppStateMachine;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mDefaultState:Lcom/android/server/hans/states/State;

    .line 144
    new-instance v0, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-direct {v0, p0, v1}, Lcom/android/server/hans/states/HansAppStateMachine$RunningState;-><init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRunningState:Lcom/android/server/hans/states/State;

    .line 145
    new-instance v0, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-direct {v0, p0, v1}, Lcom/android/server/hans/states/HansAppStateMachine$MiddleState;-><init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    .line 146
    new-instance v0, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-direct {v0, p0, v1}, Lcom/android/server/hans/states/HansAppStateMachine$FrozenState;-><init>(Lcom/android/server/hans/states/HansAppStateMachine;Lcom/android/server/hans/OplusHansPackage;)V

    iput-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    .line 147
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mDefaultState:Lcom/android/server/hans/states/State;

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->addState(Lcom/android/server/hans/states/State;)V

    .line 148
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRunningState:Lcom/android/server/hans/states/State;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mDefaultState:Lcom/android/server/hans/states/State;

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)V

    .line 149
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRunningState:Lcom/android/server/hans/states/State;

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)V

    .line 150
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->addState(Lcom/android/server/hans/states/State;Lcom/android/server/hans/states/State;)V

    .line 151
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mDefaultState:Lcom/android/server/hans/states/State;

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->setInitialState(Lcom/android/server/hans/states/State;)V

    .line 152
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->start()V

    .line 153
    return-void
.end method

.method private checkDelayFreeze(JJLjava/lang/String;)Landroid/util/Pair;
    .registers 12
    .param p1, "curTime"    # J
    .param p3, "lastUnFreezerTime"    # J
    .param p5, "lastUnFreezeReason"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/Boolean;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .line 995
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    move-wide v1, p1

    move-wide v3, p3

    move-object v5, p5

    .end local p1    # "curTime":J
    .end local p3    # "lastUnFreezerTime":J
    .end local p5    # "lastUnFreezeReason":Ljava/lang/String;
    .local v1, "curTime":J
    .local v3, "lastUnFreezerTime":J
    .local v5, "lastUnFreezeReason":Ljava/lang/String;
    invoke-virtual/range {v0 .. v5}, Lcom/android/server/am/OplusHansManager;->checkDelayFreeze(JJLjava/lang/String;)Landroid/util/Pair;

    move-result-object p1

    return-object p1
.end method

.method private checkExistingQuotaTask(ILjava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "uid"    # I
    .param p2, "pkgName"    # Ljava/lang/String;
    .param p3, "importanceReason"    # Ljava/lang/String;

    .line 1010
    const-string/jumbo v0, "transient_task"

    invoke-virtual {v0, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 1011
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->notifyAppResQuota(ILjava/lang/String;)V

    .line 1013
    :cond_10
    return-void
.end method

.method private getLcdOffSkipImportance()I
    .registers 3

    .line 1016
    const v0, 0x465ba02

    or-int/lit16 v0, v0, 0xe1d

    .line 1017
    .local v0, "importance":I
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isExpRegion()Z

    move-result v1

    if-eqz v1, :cond_12

    .line 1018
    const/high16 v1, 0x100000

    or-int/2addr v0, v1

    .line 1020
    :cond_12
    return v0
.end method

.method public static getStateId(Ljava/lang/String;)I
    .registers 7
    .param p0, "stateName"    # Ljava/lang/String;

    .line 116
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, -0x1

    sparse-switch v0, :sswitch_data_3e

    :cond_c
    goto :goto_35

    :sswitch_d
    const-string v0, "Frozen"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    move v0, v1

    goto :goto_36

    :sswitch_17
    const-string v0, "Running"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    move v0, v3

    goto :goto_36

    :sswitch_21
    const-string v0, "Default"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    move v0, v4

    goto :goto_36

    :sswitch_2b
    const-string v0, "Middle"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    move v0, v2

    goto :goto_36

    :goto_35
    move v0, v5

    :goto_36
    packed-switch v0, :pswitch_data_50

    .line 122
    return v5

    .line 120
    :pswitch_3a
    return v1

    .line 119
    :pswitch_3b
    return v2

    .line 118
    :pswitch_3c
    return v3

    .line 117
    :pswitch_3d
    return v4

    :sswitch_data_3e
    .sparse-switch
        -0x76a43a4b -> :sswitch_2b
        -0x40b391df -> :sswitch_21
        -0x40585261 -> :sswitch_17
        0x7dedfec0 -> :sswitch_d
    .end sparse-switch

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_3d
        :pswitch_3c
        :pswitch_3b
        :pswitch_3a
    .end packed-switch
.end method

.method public static getStateName(I)Ljava/lang/String;
    .registers 2
    .param p0, "state"    # I

    .line 106
    packed-switch p0, :pswitch_data_14

    .line 112
    const-string/jumbo v0, "unknown state"

    return-object v0

    .line 110
    :pswitch_7
    const-string v0, "Frozen"

    return-object v0

    .line 109
    :pswitch_a
    const-string v0, "Middle"

    return-object v0

    .line 108
    :pswitch_d
    const-string v0, "Running"

    return-object v0

    .line 107
    :pswitch_10
    const-string v0, "Default"

    return-object v0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_10
        :pswitch_d
        :pswitch_a
        :pswitch_7
    .end packed-switch
.end method

.method private recordEnterSMTime(Z)V
    .registers 12
    .param p1, "enter"    # Z

    .line 855
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 856
    if-eqz p1, :cond_13

    .line 857
    :try_start_9
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/android/server/hans/OplusHansPackage;->setEnterSMTime(J)V

    goto :goto_42

    .line 858
    :cond_13
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v1}, Lcom/android/server/hans/OplusHansPackage;->getEnterSMTime()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-lez v1, :cond_42

    .line 859
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->getInstance()Lcom/android/server/hans/OplusHansHistoryManager;

    move-result-object v1

    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v2

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-object v8, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v8}, Lcom/android/server/hans/OplusHansPackage;->getEnterSMTime()J

    move-result-wide v8

    sub-long/2addr v6, v8

    invoke-virtual {v1, v2, v5, v6, v7}, Lcom/android/server/hans/OplusHansHistoryManager;->notifyEnterSMTime(ILjava/lang/String;J)V

    .line 860
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v1, v3, v4}, Lcom/android/server/hans/OplusHansPackage;->setEnterSMTime(J)V

    .line 862
    :cond_42
    :goto_42
    monitor-exit v0

    .line 863
    return-void

    .line 862
    :catchall_44
    move-exception v1

    monitor-exit v0
    :try_end_46
    .catchall {:try_start_9 .. :try_end_46} :catchall_44

    throw v1
.end method

.method private removeAllMessagesExceptEnterSM()V
    .registers 5

    .line 866
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/16 v1, 0x14

    invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    .line 867
    .local v0, "hasMessageEnterSM":Z
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->removeAllMessages()V

    .line 868
    if-eqz v0, :cond_4d

    .line 869
    invoke-virtual {p0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(I)V

    .line 870
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v1

    if-eqz v1, :cond_4d

    .line 871
    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansHistoryManager:Lcom/android/server/hans/OplusHansHistoryManager;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "uid="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", pkg="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v3}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " removeAllMessagesExceptEnterSM."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 874
    :cond_4d
    return-void
.end method


# virtual methods
.method public addOrRemoveActionProxyFlags(ZI)V
    .registers 4
    .param p1, "add"    # Z
    .param p2, "proxyFlagMask"    # I

    .line 162
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/hans/states/action/Action;->addOrRemoveActionProxyFlags(ZI)V

    .line 163
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/android/server/hans/states/action/Action;->addOrRemoveActionProxyFlags(ZI)V

    .line 164
    return-void
.end method

.method public delayToFrozen(Ljava/lang/String;I)V
    .registers 5
    .param p1, "reason"    # Ljava/lang/String;
    .param p2, "duration"    # I

    .line 988
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_19

    .line 989
    invoke-virtual {p0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->removeMessages(I)V

    .line 990
    const/16 v0, 0x72

    const/4 v1, -0x1

    invoke-virtual {p0, v0, p2, v1, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 992
    :cond_19
    return-void
.end method

.method public enter()V
    .registers 2

    .line 940
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v0

    if-nez v0, :cond_b

    .line 941
    return-void

    .line 943
    :cond_b
    const/16 v0, 0x14

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(I)V

    .line 944
    return-void
.end method

.method public exit(Ljava/lang/String;)V
    .registers 3
    .param p1, "reason"    # Ljava/lang/String;

    .line 947
    const/16 v0, 0x69

    invoke-virtual {p0, v0, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 948
    return-void
.end method

.method public exitSmFirstly(Ljava/lang/String;)V
    .registers 3
    .param p1, "reason"    # Ljava/lang/String;

    .line 951
    const/16 v0, 0x6f

    invoke-virtual {p0, v0, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageAtFrontOfQueue(Landroid/os/Message;)V

    .line 952
    return-void
.end method

.method public forceEnterFrozen()V
    .registers 2

    .line 897
    const/16 v0, 0x15

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(I)V

    .line 898
    return-void
.end method

.method public forceTransitionRtoMnoImp(Ljava/lang/String;)V
    .registers 4
    .param p1, "reason"    # Ljava/lang/String;

    .line 889
    const/16 v0, 0x71

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1, v1, p1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 890
    return-void
.end method

.method public forceTransitionState(ILjava/lang/String;)V
    .registers 5
    .param p1, "desState"    # I
    .param p2, "reason"    # Ljava/lang/String;

    .line 882
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurStateId()I

    move-result v0

    if-eq v0, p1, :cond_10

    .line 883
    const/16 v0, 0x70

    const/4 v1, -0x1

    invoke-virtual {p0, v0, p1, v1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 885
    :cond_10
    return-void
.end method

.method public getCurState()Ljava/lang/String;
    .registers 2

    .line 955
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurrentState()Lcom/android/server/hans/states/IState;

    move-result-object v0

    invoke-interface {v0}, Lcom/android/server/hans/states/IState;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCurStateEnterTime()J
    .registers 3

    .line 970
    iget-wide v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mCurStateEnterTimeMs:J

    return-wide v0
.end method

.method public getCurStateId()I
    .registers 2

    .line 959
    invoke-virtual {p0}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurState()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/server/hans/states/HansAppStateMachine;->getStateId(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public getCurStateStayTimeStr(J)Ljava/lang/String;
    .registers 8
    .param p1, "currentTimeMillis"    # J

    .line 978
    iget-wide v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mCurStateEnterTimeMs:J

    sub-long v0, p1, v0

    .line 979
    .local v0, "stayTimeMs":J
    const-wide/16 v2, 0x3e8

    div-long v2, v0, v2

    .line 980
    .local v2, "stayTimeS":J
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method public getUpTimeDuration()J
    .registers 5

    .line 974
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mCurStateEnterTimeMs:J

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method isImportantForSM(Z)Z
    .registers 3
    .param p1, "checkedQuotaTask"    # Z

    .line 126
    const-string v0, ""

    invoke-virtual {p0, p1, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->isImportantForSM(ZLjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method isImportantForSM(ZLjava/lang/String;)Z
    .registers 5
    .param p1, "checkedQuotaTask"    # Z
    .param p2, "transReason"    # Ljava/lang/String;

    .line 130
    invoke-static {}, Lcom/android/server/hans/scene/HansSceneManager;->getInstance()Lcom/android/server/hans/scene/HansSceneManager;

    move-result-object v0

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v0, v1, p1, p2}, Lcom/android/server/hans/scene/HansSceneManager;->isImportantForSceneCombo(Lcom/android/server/hans/OplusHansPackage;ZLjava/lang/String;)Z

    move-result v0

    return v0
.end method

.method isInImportanceList(I)Z
    .registers 4
    .param p1, "flags"    # I

    .line 134
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansImportance:Lcom/android/server/hans/OplusHansImportance;

    iget-object v1, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v0, v1, p1}, Lcom/android/server/hans/OplusHansImportance;->isImportantPkg(Lcom/android/server/hans/OplusHansPackage;I)Z

    move-result v0

    return v0
.end method

.method public notifyDeepsleepOff(I)V
    .registers 4
    .param p1, "curResumedUid"    # I

    .line 929
    const/16 v0, 0x6d

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 930
    return-void
.end method

.method public notifyFastFreezerExit()V
    .registers 2

    .line 901
    const/16 v0, 0x66

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(I)V

    .line 902
    return-void
.end method

.method public notifyHighLoading(I)V
    .registers 4
    .param p1, "curResumedUid"    # I

    .line 933
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v0

    if-nez v0, :cond_b

    .line 934
    return-void

    .line 936
    :cond_b
    const/16 v0, 0x6e

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 937
    return-void
.end method

.method public notifyLcdOffAlarm(I)V
    .registers 13
    .param p1, "curResumedUid"    # I

    .line 910
    invoke-static {}, Lcom/android/server/am/OplusHansManager;->getInstance()Lcom/android/server/am/OplusHansManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/am/OplusHansManager;->isReady()Z

    move-result v0

    if-nez v0, :cond_b

    .line 911
    return-void

    .line 913
    :cond_b
    invoke-static {}, Lcom/android/server/hans/scene/OplusBgSceneManager;->getInstance()Lcom/android/server/hans/scene/OplusBgSceneManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/scene/OplusBgSceneManager;->isDeepSleep()Z

    move-result v0

    if-nez v0, :cond_20

    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    .line 914
    invoke-virtual {v0}, Lcom/android/server/hans/OplusHansPackage;->getAppClass()I

    move-result v0

    const/16 v1, 0x10

    if-ne v0, v1, :cond_20

    .line 915
    return-void

    .line 917
    :cond_20
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 918
    .local v0, "now":J
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v2}, Lcom/android/server/hans/OplusHansPackage;->getUnFreezeTime()J

    move-result-wide v2

    sub-long v2, v0, v2

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansDb:Lcom/android/server/hans/OplusHansDBConfig;

    iget-object v5, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    .line 919
    invoke-virtual {v5}, Lcom/android/server/hans/OplusHansPackage;->getUid()I

    move-result v5

    iget-object v6, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v6}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v6

    iget-object v7, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v7}, Lcom/android/server/hans/OplusHansPackage;->getAppType()I

    move-result v7

    iget-object v8, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v8}, Lcom/android/server/hans/OplusHansPackage;->getBgTime()J

    move-result-wide v8

    const-string v10, ""

    invoke-virtual/range {v4 .. v10}, Lcom/android/server/hans/OplusHansDBConfig;->getMtoFCheckTime(ILjava/lang/String;IJLjava/lang/String;)J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-gez v2, :cond_75

    .line 920
    invoke-static {}, Lcom/android/server/hans/OplusHansHistoryManager;->DEBUG_LOG()Z

    move-result v2

    if-eqz v2, :cond_74

    .line 921
    iget-object v2, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansHistoryManager:Lcom/android/server/hans/OplusHansHistoryManager;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mHansPkg:Lcom/android/server/hans/OplusHansPackage;

    invoke-virtual {v4}, Lcom/android/server/hans/OplusHansPackage;->getPkgName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " is active now, delay to FROZEN_STATE"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/server/hans/OplusHansHistoryManager;->d(Ljava/lang/String;)V

    .line 923
    :cond_74
    return-void

    .line 925
    :cond_75
    const/16 v2, 0x67

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v2, v3}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {p0, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 926
    return-void
.end method

.method public notifyLcdOn(I)V
    .registers 4
    .param p1, "curResumedUid"    # I

    .line 905
    const/16 v0, 0x65

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessage(Landroid/os/Message;)V

    .line 906
    return-void
.end method

.method public setFrozenActionKeepProxy(Z)V
    .registers 3
    .param p1, "keepProxy"    # Z

    .line 999
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/states/action/FrozenAction;

    invoke-virtual {v0, p1}, Lcom/android/server/hans/states/action/FrozenAction;->setFrozenActionKeepProxy(Z)V

    .line 1000
    return-void
.end method

.method public shouldFrozenActionKeepProxy()Z
    .registers 2

    .line 1003
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    check-cast v0, Lcom/android/server/hans/states/action/FrozenAction;

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/FrozenAction;->shouldFrozenActionKeepProxy()Z

    move-result v0

    return v0
.end method

.method public transitionRtoF(ILjava/lang/String;)V
    .registers 6
    .param p1, "delay"    # I
    .param p2, "reason"    # Ljava/lang/String;

    .line 893
    const/16 v0, 0x73

    invoke-virtual {p0, v0, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    int-to-long v1, p1

    invoke-virtual {p0, v0, v1, v2}, Lcom/android/server/hans/states/HansAppStateMachine;->sendMessageDelayed(Landroid/os/Message;J)V

    .line 894
    return-void
.end method

.method public unfreezeTo(ILjava/lang/String;)V
    .registers 3
    .param p1, "destState"    # I
    .param p2, "reason"    # Ljava/lang/String;

    .line 878
    invoke-virtual {p0, p1, p2}, Lcom/android/server/hans/states/HansAppStateMachine;->forceTransitionState(ILjava/lang/String;)V

    .line 879
    return-void
.end method

.method public updateActionProxyFlag()V
    .registers 2

    .line 156
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mRunningState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->updateActionProxyFlag()V

    .line 157
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mMiddleState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->updateActionProxyFlag()V

    .line 158
    iget-object v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mFrozenState:Lcom/android/server/hans/states/State;

    invoke-virtual {v0}, Lcom/android/server/hans/states/State;->getAction()Lcom/android/server/hans/states/action/Action;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/server/hans/states/action/Action;->updateActionProxyFlag()V

    .line 159
    return-void
.end method

.method public updateCurStateEnterTime()Ljava/lang/String;
    .registers 4

    .line 963
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 964
    .local v0, "curTimeMs":J
    invoke-virtual {p0, v0, v1}, Lcom/android/server/hans/states/HansAppStateMachine;->getCurStateStayTimeStr(J)Ljava/lang/String;

    move-result-object v2

    .line 965
    .local v2, "stayTimeStr":Ljava/lang/String;
    iput-wide v0, p0, Lcom/android/server/hans/states/HansAppStateMachine;->mCurStateEnterTimeMs:J

    .line 966
    return-object v2
.end method
