.class final Lcom/android/server/hans/binderproxy/IApplicationThreadProxy$ProxyTransaction;
.super Lcom/android/server/hans/binderproxy/Transaction;
.source "IApplicationThreadProxy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "ProxyTransaction"
.end annotation


# direct methods
.method constructor <init>(Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;ILandroid/os/Parcel;)V
    .registers 4
    .param p1, "this$0"    # Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;
    .param p2, "code"    # I
    .param p3, "data"    # Landroid/os/Parcel;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 45
    invoke-direct {p0, p2, p3}, Lcom/android/server/hans/binderproxy/Transaction;-><init>(ILandroid/os/Parcel;)V

    .line 46
    return-void
.end method


# virtual methods
.method public isEqual(Lcom/android/server/hans/binderproxy/Transaction;)Z
    .registers 4
    .param p1, "t"    # Lcom/android/server/hans/binderproxy/Transaction;

    .line 55
    iget v0, p1, Lcom/android/server/hans/binderproxy/Transaction;->mCode:I

    invoke-static {}, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;->-$$Nest$sfgetTRANSACTION_setProcessState()I

    move-result v1

    if-ne v0, v1, :cond_d

    .line 56
    invoke-super {p0, p1}, Lcom/android/server/hans/binderproxy/Transaction;->isEqual(Lcom/android/server/hans/binderproxy/Transaction;)Z

    move-result v0

    return v0

    .line 58
    :cond_d
    const/4 v0, 0x0

    return v0
.end method

.method public isLegalCode(I)Z
    .registers 3
    .param p1, "code"    # I

    .line 50
    invoke-static {}, Lcom/android/server/hans/binderproxy/IApplicationThreadProxy;->-$$Nest$sfgetTRANSACTION_setProcessState()I

    move-result v0

    if-ne p1, v0, :cond_8

    const/4 v0, 0x1

    goto :goto_9

    :cond_8
    const/4 v0, 0x0

    :goto_9
    return v0
.end method
